(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-detail-chunk"],{

/***/ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _regeneratorValues; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/core-js/modules/es.error.cause.js");
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");








function _regeneratorValues(e) {
  if (null != e) {
    var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"],
      r = 0;
    if (t) return t.call(e);
    if ("function" == typeof e.next) return e;
    if (!isNaN(e.length)) return {
      next: function next() {
        return e && r >= e.length && (e = void 0), {
          value: e && e[r++],
          done: !e
        };
      }
    };
  }
  throw new TypeError(Object(_typeof_js__WEBPACK_IMPORTED_MODULE_7__["default"])(e) + " is not iterable");
}


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ModuleDetailHeader',
  props: {
    entity: {
      type: Object,
      default: null
    },
    title: {
      type: String,
      default: ''
    },
    showNew: {
      type: Boolean,
      default: true
    },
    showCalendar: {
      type: Boolean,
      default: false
    },
    showPrint: {
      type: Boolean,
      default: true
    },
    showDelete: {
      type: Boolean,
      default: true
    },
    showSave: {
      type: Boolean,
      default: true
    },
    showCancel: {
      type: Boolean,
      default: true
    },
    showToggle: {
      type: Boolean,
      default: false
    },
    showLock: {
      type: Boolean,
      default: false
    },
    value: null,
    showPricePartsMsg: {
      type: Boolean,
      default: false
    },
    showQuoteTemplate: {
      type: Boolean,
      default: false
    },
    quoteTemplateDisabled: {
      type: Boolean,
      default: true
    },
    applyRepairerTemplate: {
      type: Boolean,
      default: false
    },
    showConvert: {
      type: Boolean,
      default: false
    },
    quoteCancelled: {
      type: Boolean,
      default: false
    },
    showAutoSave: {
      type: Boolean,
      default: false
    },
    autoSaveLocked: {
      type: Boolean,
      default: false
    },
    autoSaveEnabled: {
      type: Boolean,
      default: true
    },
    manualSaveEnabled: {
      type: Boolean,
      default: false
    },
    isAutoSaveSaving: {
      type: Boolean,
      default: false
    },
    autoSaveStatus: {
      type: String,
      default: ''
    },
    isSaving: {
      type: Boolean,
      default: false
    },
    isLoading: {
      type: Boolean,
      default: false
    },
    unsavedChanges: {
      type: Boolean,
      default: false
    },
    hasAutoSaveFailed: {
      type: Boolean,
      default: false
    },
    showAdditionalQuoteButtons: {
      type: Boolean,
      default: false
    },
    showAdditionalQuote: {
      type: Boolean,
      default: false
    },
    showCreditorStatement: {
      type: Boolean,
      default: false
    },
    showDebtorStatement: {
      type: Boolean,
      default: false
    },
    showAdvancePaymentEntry: {
      type: Boolean,
      default: false
    },
    showAdvanceReceiptEntry: {
      type: Boolean,
      default: false
    },
    showFactorInvoice: {
      type: Boolean,
      default: false
    },
    showFactorSelectedInvoice: {
      type: Boolean,
      default: false
    },
    showBankUnDepositedFunds: {
      type: Boolean,
      default: false
    },
    buttonsEnabled: {
      type: Boolean,
      default: true
    }
  },
  data: function data() {
    return {
      serviceError: false,
      access: {},
      showSideMenu: true
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
    buttonCSS: function buttonCSS() {
      return 'has-text-' + this.$theme.name;
    },
    hasMoreActions: function hasMoreActions() {
      return this.showPrint || this.showDelete || this.showLock || this.showQuoteTemplate || this.showMessages || this.autoSaveEnabled && this.entity && !this.entity.isNew && !this.hasAutoSaveFailed;
    }
  }, Object(vuex__WEBPACK_IMPORTED_MODULE_4__["mapGetters"])(['licenceExpired'])),
  watch: {
    $route: function $route(to, from) {
      this.setAccess();
    }
  },
  created: function created() {
    var _this = this;
    _components_EventBus__WEBPACK_IMPORTED_MODULE_3__["default"].$on('serviceError', function (data) {
      _this.handleBusEvent(data);
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AutoHideSideMenu, function (data) {
      _this.handleSideMenuEvent(data);
    });
  },
  mounted: function mounted() {
    this.setAccess();
  },
  methods: {
    addNew: function addNew() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].AddNew);
    },
    print: function print() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Print);
    },
    trash: function trash() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Delete);
    },
    save: function save() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Save);
    },
    manualSave: function manualSave() {
      if (!this.buttonsEnabled) return;
      this.$emit('manual-save-request');
    },
    toggleAutoSave: function toggleAutoSave() {
      this.$emit('toggle-auto-save');
    },
    cancel: function cancel() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Cancel);
    },
    toggleSide: function toggleSide() {
      this.showSideMenu = !this.showSideMenu;
      this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].ToggleSideMenu, this.showSideMenu);
    },
    handleBusEvent: function handleBusEvent(data) {
      this.serviceError = data === _components_http_status__WEBPACK_IMPORTED_MODULE_2__["default"].NOT_FOUND;
    },
    handleSideMenuEvent: function handleSideMenuEvent(data) {
      this.showSideMenu = !data;
    },
    toggleReadOnly: function toggleReadOnly() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Lock);
    },
    viewPricePartsMsg: function viewPricePartsMsg() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].PriceParts);
    },
    handleMoreButtonHover: function handleMoreButtonHover() {
      this.$emit('more-button-hover');
      this.handleBurgerButton();
    },
    handleBurgerButton: function handleBurgerButton() {
      if (this.showQuoteTemplate) {
        this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].PreApplyQuoteTemplateCheck);
      }
    },
    applyQuoteTemplate: function applyQuoteTemplate() {
      if (!this.quoteTemplateDisabled) {
        this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ApplyQuoteTemplate);
      }
    },
    calendar: function calendar() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Calendar);
    },
    convert: function convert() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].Convert);
    },
    setAccess: function setAccess() {
      if (this.$route && this.$route.meta) {
        if (this.$route.meta.access) this.access = this.$route.meta.access;else this.access = {};
      }
    },
    saveTemplateFromQuote: function saveTemplateFromQuote() {
      this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].saveTemplateFromQuote);
    },
    newAdditionalQuote: function newAdditionalQuote() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].NewAdditionalQuote);
    },
    copyQuote: function copyQuote() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].CopyQuote);
    },
    exportQuote: function exportQuote() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ExportQuote);
    },
    viewCreditorStatement: function viewCreditorStatement() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ViewCreditorStatement);
    },
    viewDebtorStatement: function viewDebtorStatement() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ViewDebtorStatement);
    },
    viewAdvancePaymentEntry: function viewAdvancePaymentEntry() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ViewAdvancePaymentEntry);
    },
    viewAdvanceReceiptEntry: function viewAdvanceReceiptEntry() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ViewAdvanceReceiptEntry);
    },
    factorInvoice: function factorInvoice() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].FactorInvoice);
    },
    factorSelectedInvoice: function factorSelectedInvoice() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].FactorSelectedInvoice);
    },
    viewBankUnDepositedFunds: function viewBankUnDepositedFunds() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].AppDetailHeaderButtonClicked, _enums__WEBPACK_IMPORTED_MODULE_5__["AppHeaderButtonTypes"].ViewBankUnDepositedFunds);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.string.split.js */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_11__);












/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ModuleSubNav',
  props: {
    menuItems: {
      type: Array,
      default: function _default() {
        return [];
      },
      validator: function validator(items) {
        return items.every(function (item) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(item) === 'object' && typeof item.label === 'string';
        });
      }
    },
    menuItemsMore: {
      type: Array,
      default: function _default() {
        return [];
      },
      validator: function validator(items) {
        return items.every(function (item) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(item) === 'object' && typeof item.label === 'string';
        });
      }
    },
    showOnlyVisible: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    visibleMenuItems: function visibleMenuItems() {
      if (this.showOnlyVisible) {
        return this.menuItems.filter(function (item) {
          return item.visible !== false;
        });
      }
      return this.menuItems;
    },
    visibleMoreItems: function visibleMoreItems() {
      if (this.showOnlyVisible) {
        return this.menuItemsMore.filter(function (item) {
          return item.visible !== false;
        });
      }
      return this.menuItemsMore;
    },
    hasMoreItems: function hasMoreItems() {
      return this.visibleMoreItems.length > 0;
    }
  },
  methods: {
    handleItemClick: function handleItemClick(item, event) {
      if (item.disabled) {
        event.preventDefault();
        return;
      } else {
        this.$emit('item-click', item);
      }
    },
    handleMoreItemClick: function handleMoreItemClick(item) {
      this.$emit('item-click', item);
      // Close the dropdown after clicking an item
      if (this.$refs.tippyMoreMenu && this.$refs.tippyMoreMenu.tip) {
        this.$refs.tippyMoreMenu.tip.hide();
      }
    },
    handleMobileMoreItemClick: function handleMobileMoreItemClick(item) {
      this.$emit('item-click', item);
      // Close the dropdown after clicking an item
      if (this.$refs.tippyMobileMoreMenu && this.$refs.tippyMobileMoreMenu.tip) {
        this.$refs.tippyMobileMoreMenu.tip.hide();
      }
    },
    handleCustomAction: function handleCustomAction(item, actionType) {
      for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        args[_key - 2] = arguments[_key];
      }
      this.$emit('custom-action', {
        item: item,
        actionType: actionType,
        args: args
      });
    },
    getDefaultIcon: function getDefaultIcon(label) {
      // Return default icons based on label
      var iconMap = {
        'Header': 'account_circle',
        'Quoting': 'edit_document',
        'Parts': 'car_tag',
        'Invoice': 'receipt_long',
        'Excess': 'receipt',
        'Assessments': 'verified_user',
        'Images': 'imagesmode',
        'Summary': 'summarize',
        'PNET': 'data_table',
        'AudaBridge': 'data_table',
        'AudaNet': 'data_table',
        'ORM': 'message',
        'RepX': 'analytics',
        'ARNIE': 'smart_toy',
        'EstImage': 'photo_library',
        'Rates & Markups': 'percent',
        'Remarks': 'sticky_note_2',
        'Annotations': 'edit',
        'Comms': 'mark_as_unread',
        'Docs': 'docs',
        'Other Labour': 'work'
      };

      // Extract the base label (remove any additional text after spaces or slashes)
      var baseLabel = label.split(/[\/\s]/)[0];
      if (iconMap[baseLabel]) {
        return iconMap[baseLabel];
      }
      if (iconMap[label]) {
        return iconMap[label];
      }
      var foundKey = Object.keys(iconMap).find(function (key) {
        return label.startsWith(key);
      });
      if (foundKey) {
        return iconMap[foundKey];
      }
      return 'more_horiz';
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteBanner',
  props: {
    bannerVisible: {
      type: Boolean,
      default: true
    },
    title: {
      type: String,
      default: 'Quote Editing Locked'
    },
    message: {
      type: String,
      default: 'Editing is disabled while a payment authorisation is in progress.'
    },
    type: {
      type: String,
      default: 'warning' // warning, danger, info, success
    },
    icon: {
      type: String,
      default: '' // optional override
    }
  },
  computed: {
    bannerClass: function bannerClass() {
      var typeMap = {
        warning: 'has-background-warning is-warning has-text-dark',
        danger: 'has-background-danger is-danger has-text-white',
        info: 'has-background-info is-info has-text-dark',
        success: 'has-background-success is-success has-text-white'
      };
      return typeMap[this.type] || typeMap['warning'];
    },
    iconClass: function iconClass() {
      if (this.icon) return this.icon;
      var iconMap = {
        warning: 'warning',
        danger: 'dangerous',
        info: 'info',
        success: 'check_circle'
      };
      return iconMap[this.type] || iconMap['warning'];
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_BulmaModal_BaseModalEx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/BulmaModal/BaseModalEx */ "./src/components/BulmaModal/BaseModalEx.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _services_QuoteTemplateService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/services/QuoteTemplateService */ "./src/services/QuoteTemplateService.js");
/* harmony import */ var _views_quotetemplate_columns_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/views/quotetemplate/columns.js */ "./src/views/quotetemplate/columns.js");
/* harmony import */ var _enums_QuoteTemplateTypes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums/QuoteTemplateTypes */ "./src/enums/QuoteTemplateTypes.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteTemplateApplyModal',
  components: {
    BaseModalEx: _components_BulmaModal_BaseModalEx__WEBPACK_IMPORTED_MODULE_12__["default"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'fadeIn'
    },
    animationOut: {
      type: String,
      default: 'fadeOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end'
    },
    quoteTimesType: {
      type: String,
      default: ''
    },
    vehicleBodyId: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      filter: {
        name: '',
        sortColumn: _views_quotetemplate_columns_js__WEBPACK_IMPORTED_MODULE_15__["QuoteTemplateListColumns"][0].name,
        sortOrder: _views_quotetemplate_columns_js__WEBPACK_IMPORTED_MODULE_15__["QuoteTemplateListColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 200
      },
      isActive: this.active || false,
      finishFetchingTemplates: false,
      selectedBodyId: null,
      selectedTemplate: null,
      templates: null
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_13__["mapGetters"])('vehicleOptions', {
    storeBodyShapes: 'bodyShapes'
  })), {}, {
    bodyShapes: function bodyShapes() {
      return this.storeBodyShapes;
    },
    bodyShape: function bodyShape() {
      var _this = this;
      if (!this.vehicleBodyId) return null;
      var _this$bodyShapes$filt = this.bodyShapes.filter(function (shape) {
          return shape.id == _this.vehicleBodyId;
        }),
        _this$bodyShapes$filt2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_this$bodyShapes$filt, 1),
        shape = _this$bodyShapes$filt2[0];
      return shape.name;
    },
    isTemplateListNonEmpty: function isTemplateListNonEmpty() {
      if (this.templates) {
        return this.templates.length > 0;
      }
      return false;
    },
    isTemplateSelected: function isTemplateSelected() {
      return this.selectedTemplate !== null;
    },
    label: function label() {
      if (this.quoteTimesType == 'LTAR' || this.quoteTimesType == 'NTAR') {
        return "Please select a ".concat(this.quoteTimesType, " template");
      }
      return 'Please select a template (LTAR/NTAR options are excluded)';
    },
    quoteTemplateTypeKeys: function quoteTemplateTypeKeys() {
      return _enums_QuoteTemplateTypes__WEBPACK_IMPORTED_MODULE_16__["QuoteTemplateTypeKeys"];
    }
  }),
  watch: {
    active: function active(value) {
      this.isActive = value;
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this2.$showSpinner();
            _this2.finishFetchingTemplates = false;
            _context.n = 1;
            return _this2.getQuoteTemplates();
          case 1:
            _this2.finishFetchingTemplates = true;
            _this2.$hideSpinner();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    add: function add() {
      this.$emit('add', this.selectedTemplate.templateId);
      this.close();
    },
    close: function close() {
      this.isActive = false;
      this.$emit('update:active', false);
    },
    matchingTimesType: function matchingTimesType(quoteTimesType, templateTimesType) {
      return quoteTimesType === 'LTAR' && templateTimesType === 'LTAR' || quoteTimesType === 'NTAR' && templateTimesType === 'NTAR' || quoteTimesType !== 'LTAR' && quoteTimesType !== 'NTAR' && templateTimesType && templateTimesType !== 'NTAR' && templateTimesType !== 'LTAR';
    },
    getQuoteTemplates: function getQuoteTemplates() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var quoteTemplates, quoteRepairerTemplates, quoteRepairerTemplatesWithoutLabour, quoteRepairerTemplatesWithLabour;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _services_QuoteTemplateService__WEBPACK_IMPORTED_MODULE_14__["default"].getQuoteTemplates(_this3.filter);
            case 1:
              quoteTemplates = _context2.v;
              quoteRepairerTemplates = quoteTemplates.filter(function (template) {
                return template.quoteType == _this3.quoteTemplateTypeKeys.Repairer;
              });
              quoteRepairerTemplatesWithoutLabour = quoteRepairerTemplates.filter(function (template) {
                return template.timesType == null && template.bodyId == null || template.timesType == null && template.bodyId === _this3.vehicleBodyId || template.bodyId == null && _this3.matchingTimesType(_this3.quoteTimesType, template.timesType);
              });
              quoteRepairerTemplatesWithLabour = quoteRepairerTemplates.filter(function (template) {
                return template.bodyId === _this3.vehicleBodyId && _this3.matchingTimesType(_this3.quoteTimesType, template.timesType);
              });
              _this3.templates = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(quoteRepairerTemplatesWithLabour), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(quoteRepairerTemplatesWithoutLabour));
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./columns */ "./src/components/Sms/columns.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _SmsService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./SmsService */ "./src/components/Sms/SmsService.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SmsMessage',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["UnsavedModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["ConfirmModal"]
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_12__["FocusInserted"]
  },
  props: {
    value: null,
    enableSave: false,
    active: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      isNew: false,
      isEdit: false,
      isDeleted: false,
      isBack: false,
      isClose: false,
      isEnableSave: false,
      isMessageEntered: true,
      isUnsavedModalActive: false,
      isConfirmModalActive: false,
      isEmpty: false,
      totalRows: 0,
      entitySummaries: {},
      entity: {
        id: '',
        message: ''
      },
      selected: {
        id: '',
        message: ''
      },
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 5
      },
      oriMsg: '',
      selectedRow: null,
      isTableLoading: false
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"];
    }
  },
  created: function created() {
    this.smsMessage = '';
    this.getData();
    this.isEnableSave = this.enableSave;
  },
  methods: {
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _context.n = 1;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    enterMessage: function enterMessage() {
      this.isMessageEntered = this.smsMessage !== '';
      if (this.isMessageEntered) {
        this.isEnableSave = true;
      }
    },
    reset: function reset() {
      this.isNew = false;
      this.isDeleted = false;
      this.isEdit = false;
      this.isUnsavedModalActive = false;
      this.isConfirmModalActive = false;
      this.entity.id = '';
      this.entity.message = '';
      this.oriMsg = this.smsMessage = '';
      this.isEnableSave = false;
    },
    add: function add() {
      this.reset();
      this.selectedRow = '';
      this.isMessageEntered = false;
      this.isEnableSave = true;
      this.isNew = true;
    },
    back: function back() {
      if (this.oriMsg !== this.smsMessage) {
        this.isBack = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('back');
      }
    },
    close: function close() {
      if (this.oriMsg !== this.smsMessage) {
        this.isClose = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('close', true);
      }
    },
    editMessage: function editMessage(entity, index) {
      // add new -> edit message
      if (this.oriMsg !== this.smsMessage) {
        this.isEdit = true;
        this.isUnsavedModalActive = true;
        // edit message
      } else {
        this.isNew = false;
        this.isEdit = true;
        this.isEnableSave = true;
        this.entity.id = entity.id;
        this.entity.message = entity.message;
        this.oriMsg = entity.message;
        this.smsMessage = entity.message;
        this.smsMessage.FocusInserted;
        this.isMessageEntered = this.smsMessage !== '';
        this.isEnableSave = true;
        this.$emit('save-button', true);
      }
    },
    deleteMessage: function deleteMessage(id, index, msg) {
      this.isDeleted = true;
      if (!this.isEdit) {
        this.entity.id = id;
      }
      if (!this.isEdit && this.oriMsg !== this.smsMessage && this.entity.id !== this.selected.id) {
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
        this.isUnsavedModalActive = true;
      } else if (this.smsMessage != msg && this.smsMessage != '' && this.isNew) {
        this.isUnsavedModalActive = true;
        // } else if (this.isEdit && this.selected.id !== id) {
        // edit msg then delete on same msg or other msg
      } else if (this.isEdit && this.isDeleted && this.oriMsg !== this.smsMessage && this.entity.id !== id) {
        this.isUnsavedModalActive = true;
      } else {
        this.entity.id = id;
        this.entity.message = msg;
        this.isNew = false; // set to false when add new message is empty and then click on delete
        this.isEdit = false; // set to false when no change on edit message and then click on delete
        this.isConfirmModalActive = true;
      }
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!confirmDelete) {
                _context2.n = 5;
                break;
              }
              _context2.p = 1;
              _context2.n = 2;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].deleteEntity(_this2.selected.id);
            case 2:
              _this2.getData();
              _this2.isEnableSave = false;
              _this2.isMessageEntered = true;
              // for edit then edit same message and
              // for add new then highlight and delete other message
              if (!_this2.isNew && !_this2.isEdit && _this2.isDeleted || !_this2.isNew && !_this2.isEdit && _this2.entity.id == _this2.selected.id || !_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.reset();
              }
              _this2.selectedRow = '';
              _this2.$emit('save-button', false);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t.response.status);
              _this2.$notification.openMessageXhrError('SMS Message', _t);
              return _context2.a(2, false);
            case 4:
              _context2.n = 6;
              break;
            case 5:
              if (!_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.isConfirmModalActive = false;
                _this2.selectedRow = _this2.entitySummaries.indexOf(_this2.entitySummaries.find(function (i) {
                  return i.message === _this2.oriMsg;
                }));
              } else {
                _this2.reset();
                _this2.$emit('save-button', false);
              }
            case 6:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    cancel: function cancel() {
      this.reset();
      this.selectedRow = '';
    },
    saveSms: function saveSms() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!_this3.isNew) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _this3.save(true);
            case 1:
              _context3.n = 3;
              break;
            case 2:
              if (!_this3.isEdit) {
                _context3.n = 3;
                break;
              }
              _context3.n = 3;
              return _this3.save(false);
            case 3:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    save: function save(isNew) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var newMsg, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              newMsg = _this4.smsMessage;
              _this4.isEmpty = false;
              if (!(newMsg == '')) {
                _context4.n = 1;
                break;
              }
              _this4.isEmpty = true;
              _this4.$notification.openNotificationWithType('danger', 'SMS Message', 'Validation errors. Please fix before saving');
              return _context4.a(2, false);
            case 1:
              if (!(_this4.oriMsg == newMsg && _this4.entity.id == _this4.selected.id)) {
                _context4.n = 2;
                break;
              }
              _this4.$notification.openNotificationWithType('warning', 'SMS Message', 'No changes detected. Not saved');
              return _context4.a(2, false);
            case 2:
              _context4.p = 2;
              _this4.$showSpinner('Saving...');
              // add new message
              if (!isNew) {
                _context4.n = 5;
                break;
              }
              _this4.entity.id = 0;
              _this4.entity.message = newMsg;
              _context4.n = 3;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].postEntity(_this4.entity);
            case 3:
              _context4.n = 4;
              return _this4.getData();
            case 4:
              // wait to get latest order after add
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.message === newMsg;
              })); // get latest index for case NOT from save continue
              // edit message
              _context4.n = 8;
              break;
            case 5:
              _this4.entity.message = newMsg;
              _context4.n = 6;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].putEntity(_this4.entity);
            case 6:
              _context4.n = 7;
              return _this4.getData();
            case 7:
              // wait to get latest order after edit
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.id === _this4.selected.id;
              })); // get latest index for case NOT from save continue
            case 8:
              _this4.reset();
              _this4.$notification.success('SMS Message', 'Save successful');
              _this4.$emit('save-button', false);
              return _context4.a(2, true);
            case 9:
              _context4.p = 9;
              _t2 = _context4.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t2.response.status);
              _this4.$notification.openMessageXhrError('SMS Message', _t2);
              return _context4.a(2, false);
            case 10:
              _context4.p = 10;
              _this4.$hideSpinner();
              return _context4.f(10);
            case 11:
              return _context4.a(2);
          }
        }, _callee4, null, [[2, 9, 10, 11]]);
      }))();
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (!(_this5.isNew && _this5.isDeleted)) {
                _context5.n = 3;
                break;
              }
              _context5.n = 1;
              return _this5.deleteEntity(true);
            case 1:
              _context5.n = 2;
              return _this5.save(true);
            case 2:
              _this5.reset();
              _context5.n = 11;
              break;
            case 3:
              if (!(_this5.isEdit && _this5.isDeleted)) {
                _context5.n = 6;
                break;
              }
              _context5.n = 4;
              return _this5.deleteEntity(true);
            case 4:
              _context5.n = 5;
              return _this5.save(false);
            case 5:
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = false;
              _context5.n = 11;
              break;
            case 6:
              if (!(_this5.isNew && _this5.isEdit)) {
                _context5.n = 8;
                break;
              }
              _context5.n = 7;
              return _this5.save(true);
            case 7:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              _this5.smsMessage = _this5.selected.message;
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for case add new then edit, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 8:
              if (!(!_this5.isNew && _this5.isEdit)) {
                _context5.n = 10;
                break;
              }
              _context5.n = 9;
              return _this5.save(false);
            case 9:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              if (_this5.isEmpty) {
                _this5.smsMessage = '';
              } else {
                _this5.smsMessage = _this5.selected.message;
              }
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for edit then edit others, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 10:
              if (!(_this5.isNew && !_this5.isEdit && !_this5.Deleted)) {
                _context5.n = 11;
                break;
              }
              _context5.n = 11;
              return _this5.save(true);
            case 11:
              // isEmpty is to check if msg empty then it not allow back to SmsSend
              if (_this5.isBack && !_this5.isEmpty) {
                _this5.$emit('back');
              }
              if (_this5.isClose && !_this5.isEmpty) {
                _this5.$emit('close', true);
              }
            case 12:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    skipSave: function skipSave() {
      if (this.isBack) {
        this.$emit('back');
      } else if (this.isClose) {
        this.$emit('close', true);
      } else if (this.isDeleted) {
        this.deleteEntity(true);
        this.reset();
      } else if (this.isEdit) {
        this.isUnsavedModalActive = false;
        this.smsMessage = this.selected.message;
        this.smsMessage.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.smsMessage;
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
      } else if (this.isNew) {
        this.isUnsavedModalActive = false;
        this.smsMessage = this.selected.message;
        this.smsMessage.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.smsMessage;
      }
    },
    closeModal: function closeModal() {
      var _this6 = this;
      this.isDeleted = false;
      this.isBack = false;
      this.isClose = false;
      this.isUnsavedModalActive = false;
      if (this.isEnableSave) {
        this.smsMessage.FocusInserted;
        this.selectedRow = this.entitySummaries.indexOf(this.entitySummaries.find(function (i) {
          return i.id === _this6.entity.id;
        }));
      }
    },
    highlightSelected: function highlightSelected(entity, index, event) {
      this.selectedRow = index;
      this.selected = entity;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.getData();
    },
    insertTag: function insertTag(myValue) {
      var myField = document.getElementById('smsMessage');
      if (document.selection) {
        myField.focus();
        var sel = document.selection.createRange();
        sel.text = myValue;
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
      } else {
        myField.value += myValue;
      }
      this.smsMessage = myField.value;
      this.enterMessage();
      myField.focus();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsModal.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _SmsSend__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SmsSend */ "./src/components/Sms/SmsSend.vue");
/* harmony import */ var _SmsMessage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SmsMessage */ "./src/components/Sms/SmsMessage.vue");






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SmsModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__["BaseModalEx"],
    SmsSend: _SmsSend__WEBPACK_IMPORTED_MODULE_4__["default"],
    SmsMessage: _SmsMessage__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    },
    iconName: {
      type: String,
      default: 'mdi-message-text'
    }
  },
  data: function data() {
    return {
      smsDetails: null,
      isActive: false,
      enableSave: false,
      isSendSms: true,
      isEnteringSmsInfo: false,
      isSendSmsModalActive: true,
      isSmsMessageModalActive: false,
      smsModalHeader: ''
    };
  },
  computed: {
    enableSend: function enableSend() {
      return this.isEnteringSmsInfo;
    }
  },
  created: function created() {
    this.smsDetails = this.value;
    if (this.isSendSms) {
      this.smsModalHeader = 'Send SMS';
    } else {
      this.smsModalHeader = 'SMS Message';
    }
  },
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    editTemplate: function editTemplate() {
      this.isSendSmsModalActive = false;
      this.isSmsMessageModalActive = true;
      this.isSendSms = false;
      this.enableSave = false;
      this.smsModalHeader = 'SMS Message';
    },
    send: function send() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _this.$refs.smsSend.send();
            case 1:
              _this.$emit('update:active', false);
              _this.$emit('close');
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    close: function close(isClose) {
      if (isClose) {
        this.$emit('update:active', false);
        this.$emit('close');
      } else {
        this.$refs.smsMessage.close();
      }
    },
    add: function add() {
      this.enableSave = true;
      this.$refs.smsMessage.add();
    },
    back: function back() {
      this.$refs.smsMessage.back();
    },
    save: function save() {
      this.$refs.smsMessage.saveSms();
    },
    cancel: function cancel() {
      this.$refs.smsMessage.cancel();
      this.enableSave = false;
    },
    backToSmsSend: function backToSmsSend() {
      this.smsModalHeader = 'Send SMS';
      this.isSendSms = true;
      this.isSendSmsModalActive = true;
      this.isSmsMessageModalActive = false;
    },
    setEnableSave: function setEnableSave(isShow) {
      this.enableSave = isShow;
    },
    smsDetailsEntered: function smsDetailsEntered(isEnableSend) {
      this.isEnteringSmsInfo = isEnableSend;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsSend.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _SmsService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./SmsService */ "./src/components/Sms/SmsService.js");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SmsSend',
  components: {
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_7__["TheMask"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_9___default.a
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_8__["FocusInserted"]
  },
  props: {
    enableSend: false,
    value: null,
    active: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      isValidMobile: false,
      isMessageEntered: false,
      smsDetails: null,
      smsMessage: '',
      phoneNoTokens: {
        P: {
          pattern: /[0-9, ()\-+]/
        }
      },
      phoneNoMask: Array(31).join('P'),
      // length of phoneNo field in database
      messages: [],
      selectedMessage: null,
      isMessageLoading: false,
      messageFilter: {
        message: '',
        pageIndex: 1,
        pageSize: 999
      }
    };
  },
  created: function created() {
    this.smsDetails = this.value;
    this.getSmsMessageDropdown();
    this.messageFilter.message = this.value.message;
    this.smsMessage = this.value.message;
    if (this.value.mobile !== '') {
      this.isValidMobile = true;
    } else {
      this.isValidMobile = false;
    }
    if (this.value.message !== '') {
      this.isMessageEntered = true;
    } else {
      this.isMessageEntered = false;
    }
    this.$emit('smsdetails-entered', this.isMessageEntered && this.isValidMobile);
  },
  mounted: function mounted() {},
  methods: {
    enterMobile: function enterMobile(mobileNumber) {
      this.isValidMobile = mobileNumber !== '';
      this.smsDetails.mobile = mobileNumber;
      this.$emit('smsdetails-entered', this.isMessageEntered && this.isValidMobile);
    },
    enterMessage: function enterMessage() {
      this.isMessageEntered = this.smsMessage !== '';
      this.smsDetails.message = this.smsMessage;
      this.$emit('smsdetails-entered', this.isMessageEntered && this.isValidMobile);
    },
    send: function send() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.$showSpinner('Sending...');
              _context.p = 1;
              _context.n = 2;
              return _SmsService__WEBPACK_IMPORTED_MODULE_10__["default"].sendSms(_this.smsDetails);
            case 2:
              _this.$notification.openNotificationWithType('success', 'Send SMS', 'Message Sent');
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('Send SMS', _t);
            case 4:
              _context.p = 4;
              _this.$hideSpinner();
              return _context.f(4);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    },
    getSmsMessageDropdown: function getSmsMessageDropdown() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isMessageLoading = true;
              _context2.n = 1;
              return _SmsService__WEBPACK_IMPORTED_MODULE_10__["default"].getSmsMessageDropdownProto(_this2.messageFilter);
            case 1:
              _this2.messages = _context2.v;
              if (_this2.messageFilter.message !== '') {
                _this2.selectedMessage = _this2.messages.find(function (c) {
                  return c.message === _this2.messageFilter.message;
                });
              }
              _this2.isMessageLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    selectMessage: function selectMessage(selected) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.messageFilter.message = selected.message;
              _this3.smsMessage = selected.message;
              _this3.enterMessage();
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    removeMessage: function removeMessage() {
      this.messageFilter.message = '';
      this.smsMessage = '';
      this.enterMessage();
      this.getSmsMessageDropdown();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _QuoteDetailSummary__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./QuoteDetailSummary */ "./src/views/quote/QuoteDetailSummary.vue");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _QuoteFiltersMixins__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./QuoteFiltersMixins */ "./src/views/quote/QuoteFiltersMixins.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _views_quotetemplate_QuoteTemplateService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/views/quotetemplate/QuoteTemplateService */ "./src/views/quotetemplate/QuoteTemplateService.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _views_vehicle_VehicleService__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/views/vehicle/VehicleService */ "./src/views/vehicle/VehicleService.js");




































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteDetail',
  inject: ['$vv'],
  components: {
    QuoteDetailSummary: _QuoteDetailSummary__WEBPACK_IMPORTED_MODULE_17__["default"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_19___default.a,
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_29__["BulmaAutocomplete"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_20__["DateTimeFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_20__["NumberFiltersMixin"], _QuoteFiltersMixins__WEBPACK_IMPORTED_MODULE_22__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_28__["default"], _mixins__WEBPACK_IMPORTED_MODULE_34__["QuoteLabourMixin"], _mixins__WEBPACK_IMPORTED_MODULE_34__["QuoteOtherLabourMixin"]],
  props: {
    value: null,
    vehicle: null,
    nextLineNumber: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      quoteDate: null,
      jobStart: null,
      jobEnd: null,
      excess: 0,
      // authorisedDate: null,
      innerValue: null,
      vehicles: [],
      // Vehicle arrays for dropdown
      selectedVehicle: null,
      isVehicleLoading: false,
      vehicleFilter: {
        vehicleId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        rego: '',
        pageIndex: 1,
        pageSize: 50
      },
      vehicleButtonLoading: false,
      insurers: [],
      selectedInsurer: null,
      isInsurerLoading: false,
      insurerFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        assetName: '',
        showCustomer: false,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      insurerButtonLoading: false,
      quoters: [],
      selectedQuoteDate: null,
      selectedJobStart: null,
      selectedJobEnd: null,
      selectedJobStartEnd: null,
      selectedAuthorisedDate: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      modelConfig: {
        start: {
          timeAdjust: '08:00:00'
        },
        end: {
          timeAdjust: '08:00:00'
        }
      },
      dragValue: null,
      ntarLtarStatus: ''
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    jobStageTypes: function jobStageTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["JobStageTypes"];
    },
    hasVehicleSelected: function hasVehicleSelected() {
      return this.selectedVehicle && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_26___default()(this.selectedVehicle);
    },
    vehicleButtonIconClass: function vehicleButtonIconClass() {
      return {
        'mdi-pencil': this.hasVehicleSelected,
        'mdi-plus': !this.hasVehicleSelected
      };
    },
    vehicleButtonClass: function vehicleButtonClass() {
      return {
        'is-primary': this.hasVehicleSelected,
        'is-success': !this.hasVehicleSelected,
        'is-loading': this.vehicleButtonLoading
      };
    },
    hasInsurerSelected: function hasInsurerSelected() {
      return this.selectedInsurer && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_26___default()(this.selectedInsurer);
    },
    insurerButtonIconClass: function insurerButtonIconClass() {
      return {
        'mdi-pencil': this.hasInsurerSelected,
        'mdi-plus': !this.hasInsurerSelected
      };
    },
    insurerButtonClass: function insurerButtonClass() {
      return {
        'is-primary': this.hasInsurerSelected,
        'is-success': !this.hasInsurerSelected,
        'is-loading': this.insurerButtonLoading
      };
    },
    filteredQuoters: function filteredQuoters() {
      var _this = this;
      return this.quoters.filter(function (option) {
        return option.toString().toLowerCase().indexOf(_this.innerValue.quoter.toLowerCase()) >= 0;
      });
    },
    invoice: function invoice() {
      return this.innerValue.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Quote;
      });
    },
    excessInvoice: function excessInvoice() {
      return this.innerValue.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess;
      });
    },
    labourTimeTypes: function labourTimeTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["LabourTimeTypes"];
    },
    canChangeReadOnly: function canChangeReadOnly() {
      return this.$userInfo.isSupportUser || this.$userInfo.isCustomerAdministrator;
    },
    selectDragAttribute: function selectDragAttribute() {
      return {
        popover: {
          visibility: 'hover',
          isInteractive: false // Defaults to true when using slot
        }
      };
    },
    quotingMethodTypes: function quotingMethodTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["QuotingMethodTypes"];
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = newVal;
      },
      deep: true
    },
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    // authorisedDate: function(newVal, oldVal) {
    //   // console.log(newVal === '__/__/____')
    //   if (newVal && newVal !== '__/__/____') {
    //     const date = DateTime.fromFormat(newVal, getLocaleDateFormat(this.$userInfo.locale), { locale: this.$userInfo.locale })
    //     if (date.isValid) {
    //       this.innerValue.authorisedDate = date.toISO({ includeOffset: false, suppressMilliseconds: true }) + 'Z'
    //     } else {
    //       this.innerValue.authorisedDate = undefined
    //     }
    //   } else {
    //     this.innerValue.authorisedDate = null
    //   }
    // },
    rrTotal: function rrTotal(newVal) {
      this.innerValue.rrTotal = this.rrTotal;
    },
    repairTotal: function repairTotal(newVal) {
      this.innerValue.repairTotal = this.repairTotal;
    },
    rwaTotal: function rwaTotal(newVal) {
      this.innerValue.rwaTotal = this.rwaTotal;
    },
    paintTotal: function paintTotal(newVal) {
      this.innerValue.paintTotal = this.paintTotal;
    },
    cdTotal: function cdTotal(newVal) {
      this.innerValue.cdTotal = this.cdTotal;
    },
    crushTotal: function crushTotal(newVal) {
      this.innerValue.crushTotal = this.crushTotal;
    },
    mechTotal: function mechTotal(newVal) {
      this.innerValue.mechTotal = this.mechTotal;
    },
    fgTotal: function fgTotal(newVal) {
      this.innerValue.fgTotal = this.fgTotal;
    },
    'innerValue.quotingMethod': function innerValueQuotingMethod(newVal, oldVal) {
      if (oldVal) {
        var vm = this;
        // Recalculates labours
        this.innerValue.labours.forEach(function (item, index) {
          if (vm.innerValue.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_21__["QuotingMethodTypes"].Hour) {
            if (item.rev !== '1') {
              var rate = vm.getRate(item.itemType);
              item.rate = rate;
            }
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
            // item.rate = 1
          }
        });
        // Recalculates other labours
        this.innerValue.others.forEach(function (item, index) {
          if (vm.innerValue.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_21__["QuotingMethodTypes"].Hour) {
            if (item.rev !== '1') {
              var rate = vm.getRate(item.itemType);
              item.rate = rate;
            }
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
          }
        });
        // Recalculates OPG
        this.innerValue.opgs.forEach(function (item, index) {
          if (item.rev !== '1') {
            var rate = vm.getRate(item.opgCode);
            item.rate = rate;
          }
          if (vm.innerValue.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_21__["QuotingMethodTypes"].Hour) {
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
          }
        });
      }
    },
    selectedQuoteDate: function selectedQuoteDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.quoteDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.quoteDate = null;
      }
    },
    selectedJobStart: function selectedJobStart(newVal, oldVal) {
      if (newVal) {
        this.innerValue.jobStart = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.jobStart = null;
      }
    },
    selectedJobEnd: function selectedJobEnd(newVal, oldVal) {
      if (newVal) {
        this.innerValue.jobEnd = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.jobEnd = null;
      }
    },
    selectedJobStartEnd: function selectedJobStartEnd(newVal, oldVal) {
      if (newVal) {
        this.innerValue.jobStart = newVal.start.toISOString().split('.')[0] + 'Z';
        this.innerValue.jobEnd = newVal.end.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.jobEnd = null;
        this.innerValue.jobStart = null;
      }
    },
    selectedAuthorisedDate: function selectedAuthorisedDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.authorisedDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.authorisedDate = null;
      }
    },
    'innerValue.vehicleId': function innerValueVehicleId(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.getNtarLtarStatus();
      }
    }
  },
  created: function created() {
    this.innerValue = this.value;
    this.excess = this.innerValue.excess;
    this.quoteDate = new Date("".concat(this.innerValue.quoteDate));
    this.selectedQuoteDate = new Date("".concat(this.innerValue.quoteDate));
    if (this.innerValue.jobStart) {
      this.selectedJobStartEnd = {};
      this.jobStart = new Date("".concat(this.innerValue.jobStart));
      this.selectedJobStart = new Date("".concat(this.innerValue.jobStart));
      this.selectedJobStartEnd.start = new Date("".concat(this.innerValue.jobStart));
    }
    if (this.innerValue.jobEnd) {
      this.jobEnd = new Date("".concat(this.innerValue.jobEnd));
      this.selectedJobEnd = new Date("".concat(this.innerValue.jobEnd));
      this.selectedJobStartEnd.end = new Date("".concat(this.innerValue.jobEnd));
    }
    // this.authorisedDate = new Date(`${this.innerValue.authorisedDate}`).toLocaleDateString(this.$userInfo.locale)
    if (this.innerValue.authorisedDate) {
      this.selectedAuthorisedDate = new Date("".concat(this.innerValue.authorisedDate));
    }
    // this.authorisedDate = DateTime.fromISO(this.innerValue.authorisedDate)
    //   .setLocale(this.$userInfo.locale)
    //   .toLocaleString()

    this.vehicleFilter.vehicleId = this.innerValue.vehicleId;
    this.insurerFilter.assetId = this.innerValue.insurerId;
    this.getVehicleDropdown();
    this.getInsurerDropdown();
    this.getQuoters();
    this.getNtarLtarStatus();
  },
  mounted: function mounted() {
    this.$vv.detailGroup.$touch();
    // const vehicleInputElement = document.getElementById('quote-vehicle-multiselect')
    // vehicleInputElement.style.cssText = `${vehicleInputElement.style.cssText}; text-transform: uppercase;`
  },
  methods: {
    onSelectQuoteDate: function onSelectQuoteDate(date, dateNow) {
      this.innerValue.quoteDate = dateNow.toISOString().split('.')[0] + 'Z';
    },
    onSelectJobStartDate: function onSelectJobStartDate(date, dateNow) {
      this.innerValue.jobStart = dateNow.toISOString().split('.')[0] + 'Z';
    },
    onSelectJobEndDate: function onSelectJobEndDate(date, dateNow) {
      this.innerValue.jobEnd = dateNow.toISOString().split('.')[0] + 'Z';
    },
    getVehicleDropdown: function getVehicleDropdown() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this2.isVehicleLoading = true;
              _context.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getVehicleDropdownProto(_this2.vehicleFilter);
            case 1:
              _this2.vehicles = _context.v;
              if (_this2.vehicleFilter.vehicleId !== _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty()) {
                _this2.selectedVehicle = _this2.vehicles.find(function (c) {
                  return c.vehicleId === _this2.innerValue.vehicleId;
                });
              }
              _this2.isVehicleLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getVehicleDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_25___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.isVehicleLoading = true;
              this.vehicleFilter.rego = query;
              _context2.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getVehicleDropdownProto(this.vehicleFilter);
            case 1:
              this.vehicles = _context2.v;
              this.isVehicleLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectVehicle: function selectVehicle(selected) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.innerValue.vehicleId = selected.vehicleId;
              _this3.innerValue.customerId = selected.customerId;
              _this3.removeQuoteCustomer();
              _this3.removeQuoteVehicle();
              _this3.getQuoteCustomer({
                id: selected.customerId,
                refresh: false
              });
              _this3.getQuoteVehicle({
                id: selected.vehicleId,
                refresh: true
              });
              _this3.vehicleFilter.vehicleId = selected.vehicleId;
              _this3.vehicleFilter.rego = '';
              _context3.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getVehicleDropdownProto(_this3.vehicleFilter);
            case 1:
              _this3.vehicles = _context3.v;
              _this3.$vv.detailGroup.$touch();
              // this.$v.entity.vehicleId.$touch()
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    removeVehicle: function removeVehicle() {
      this.$vv.detailGroup.$touch();
      this.vehicleFilter.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.innerValue.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.$vv.detailGroup.$touch();
      // this.$v.entity.vehicleId.$touch()
      this.getVehicleDropdown();
    },
    getInsurerDropdown: function getInsurerDropdown() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isInsurerLoading = true;
              _context4.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getInsurerDropdownProto(_this4.insurerFilter);
            case 1:
              _this4.insurers = _context4.v;
              if (_this4.insurerFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty()) {
                _this4.selectedInsurer = _this4.insurers.find(function (c) {
                  return c.assetId === _this4.innerValue.insurerId;
                });
              }
              _this4.isInsurerLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    getInsurerDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_25___default()(/*#__PURE__*/function () {
      var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              this.isInsurerLoading = true;
              this.insurerFilter.assetName = query;
              _context5.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getInsurerDropdownProto(this.insurerFilter);
            case 1:
              this.insurers = _context5.v;
              this.isInsurerLoading = false;
            case 2:
              return _context5.a(2);
          }
        }, _callee5, this);
      }));
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }(), 500),
    selectInsurer: function selectInsurer(selected) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var isItemsEmpty;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              isItemsEmpty = _this5.innerValue.labours.length === 0 && _this5.innerValue.parts.length === 0 && _this5.innerValue.others.length === 0 && _this5.innerValue.opgs.length === 0 && _this5.innerValue.miscs.length === 0 && _this5.innerValue.sublets.length === 0; // if (this.innerValue.isNew) {
              //   this.innerValue.miscs.splice(0, this.innerValue.miscs.length)
              // }
              if (!(isItemsEmpty || _this5.innerValue.isNew)) {
                _context6.n = 2;
                break;
              }
              // Update insurer related values when there are no items
              // const labourTypes = await QuoteService.getLabourTypes()
              _this5.$showSpinner();
              // const startTime = new Date()
              _context6.n = 1;
              return _this5.getQuoteInsurer({
                id: selected.assetId,
                refresh: true
              });
            case 1:
              // const endTime = new Date()
              // let timeDiff = endTime - startTime
              // // timeDiff /= 1000
              // const seconds = Math.round(timeDiff)
              // console.log(`${seconds} ms`)
              _this5.$hideSpinner();
              // Update quote
              _this5.innerValue.insurerId = selected.assetId;
              _this5.innerValue.newMarkup = _this5.quoteInsurer.newMarkup;
              _this5.innerValue.usedMarkup = _this5.quoteInsurer.usedMarkup;
              _this5.innerValue.recoreMarkup = _this5.quoteInsurer.recoreMarkup;
              _this5.innerValue.afterMarketMarkup = _this5.quoteInsurer.afterMarketMarkup;
              _this5.innerValue.exchangeMarkup = _this5.quoteInsurer.exchangeMarkup;
              _this5.innerValue.reconditionedMarkup = _this5.quoteInsurer.reconditionedMarkup;
              _this5.innerValue.parallelMarkup = _this5.quoteInsurer.parallelMarkup;
              _this5.innerValue.shopRate = _this5.quoteInsurer.shopRate;
              _this5.innerValue.labourType = _this5.quoteInsurer.labourType;
              _this5.innerValue.excessWithGst = _this5.quoteInsurer.excessGST;
              _this5.innerValue.verRtrm = Math.max.apply(Math, _this5.quoteInsurer.insurerConsumables.map(function (c) {
                return c.versionNo;
              }));
              // Update quote rates
              _this5.addInsurerLabourRates(_this5.quoteInsurer);
              // Add or update automatic items to quote
              _this5.addInsurerAutoItems(_this5.quoteInsurer);
              // Add or update template items to quote
              _this5.addInsurerTemplateItems(_this5.quoteInsurer);
            case 2:
              _this5.innerValue.insurerId = selected.assetId;
              _this5.insurerFilter.assetId = selected.assetId;
              _this5.insurerFilter.assetName = '';
              _context6.n = 3;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getInsurerDropdownProto(_this5.insurerFilter);
            case 3:
              _this5.insurers = _context6.v;
              _this5.$vv.detailGroup.$touch();
              // this.$v.entity.insurerId.$touch()
            case 4:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    removeInsurer: function removeInsurer() {
      this.insurerFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.innerValue.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.$vv.detailGroup.$touch();
      // this.$v.entity.insurerId.$touch()
      this.getInsurerDropdown();
    },
    authorisedDateInput: function authorisedDateInput(args) {
      this.$vv.detailGroup.$touch();
      // this.$v.entity.authorisedDate.$touch()
    },
    onEditAddInsurer: function onEditAddInsurer() {
      this.insurerButtonLoading = true;
      this.setInsurerReturnRoute(this.$route);
      if (this.value.insurerId !== _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty()) {
        this.editStoreInsurer(this.value.insurerId);
      } else {
        var payload = new _classes__WEBPACK_IMPORTED_MODULE_31__["InsurerPayload"](this.insurerFilter.assetName);
        this.addStoreInsurer(payload);
      }
    },
    onEditAddVehicle: function onEditAddVehicle() {
      this.vehicleButtonLoading = true;
      this.setVehicleReturnRoute(this.$route);
      if (this.value.vehicleId !== _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty()) {
        this.editStoreVehicle(this.value.vehicleId);
      } else {
        var payload = {
          rego: this.vehicleFilter.rego
        };
        this.addStoreVehicle(payload);
      }
    },
    getQuoters: function getQuoters() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _context7.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getQuoters();
            case 1:
              _this6.quoters = _context7.v;
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    getRate: function getRate(code) {
      var _this7 = this;
      var rateObject = null;
      if (code === _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].PAINT) {
        rateObject = this.innerValue.rates.find(function (i) {
          return i.labourCodeId === _this7.vehicle.paintGroup;
        });
      } else {
        rateObject = this.innerValue.rates.find(function (i) {
          return i.labourCodeId === code;
        });
      }
      var rate = !this.isNtar ? rateObject.rate : this.innerValue.shopRate;
      return rate;
    },
    addInsurerLabourRates: function addInsurerLabourRates(insurer) {
      var vm = this;
      var isInsurerNtar = insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_21__["LabourTimeTypes"].NTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_21__["LabourTimeTypes"].LTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_21__["LabourTimeTypes"].eMTA;
      insurer.insurerLabourRates.forEach(function (ir) {
        var index = vm.innerValue.rates.findIndex(function (qr) {
          return qr.labourCodeId === ir.labourCode;
        });
        if (index > -1) {
          vm.innerValue.rates[index].rate = isInsurerNtar ? insurer.shopRate : ir.rate;
        } else {
          var labourType = vm.$labourTypes.find(function (t) {
            return t.labourTypeCode === ir.labourType;
          });
          var newRate = {
            rate: isInsurerNtar ? insurer.shopRate : ir.rate,
            quoteVersion: 0,
            quoteId: vm.innerValue.quoteId,
            labourCodeId: ir.labourCode,
            labourTypeId: labourType.labourTypeId,
            deleted: false,
            createdBy: '',
            createdDate: '',
            modifiedBy: '',
            modifiedDate: '',
            isNew: true,
            isDeleted: false
          };
          vm.innerValue.rates.splice(vm.innerValue.rates.length, 1, newRate);
        }
      });
    },
    addInsurerAutoItems: function addInsurerAutoItems(insurer) {
      if (insurer.insurerAutoItems && insurer.insurerAutoItems.length > 0) {
        var vm = this;
        var lineNumber = this.nextLineNumber;
        insurer.insurerAutoItems.forEach(function (autoItem) {
          var currentItem = vm.innerValue.miscs.find(function (i) {
            return i.itemDesc === autoItem.itemDesc && i.itemNo === autoItem.itemNo;
          });
          if (!currentItem) {
            var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__["QuoteItemModel"](vm.innerValue.quoteId, autoItem.itemNo, autoItem.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].MISC);
            newItem.value = autoItem.price;
            newItem.reportOnly = autoItem.reportOnly;
            newItem.sortNo = vm.innerValue.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(vm.innerValue.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            newItem.lineNumber = lineNumber;
            vm.innerValue.miscs.splice(vm.innerValue.miscs.length, 1, newItem);
            console.log(lineNumber);
            lineNumber++;
            vm.innerValue.lines++;
          } else {
            currentItem.value = autoItem.price;
            currentItem.reportOnly = autoItem.reportOnly;
          }
        });
      }
    },
    addInsurerTemplateItems: function addInsurerTemplateItems(insurer) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var templateItems, vm;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].validGuid(insurer.templateId)) {
                _context8.n = 2;
                break;
              }
              _context8.n = 1;
              return _views_quotetemplate_QuoteTemplateService__WEBPACK_IMPORTED_MODULE_32__["default"].getQuoteTemplateItems(insurer.templateId);
            case 1:
              templateItems = _context8.v;
              if (templateItems && templateItems.length > 0) {
                vm = _this8;
                templateItems.forEach(function (templateItem) {
                  var currentItem = vm.innerValue.miscs.find(function (i) {
                    return i.itemDesc === templateItem.itemDesc && i.itemNo === templateItem.itemNo && i.itemType === templateItem.itemType;
                  });
                  if (!currentItem) {
                    var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__["QuoteItemModel"](vm.innerValue.quoteId, templateItem.itemNo, templateItem.itemDesc, templateItem.itemType);
                    newItem.value = templateItem.value;
                    newItem.reportOnly = templateItem.reportOnly;
                    newItem.sortNo = templateItem.sortNo;
                    // let sortNo
                    switch (templateItem.itemType) {
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].RR:
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].REP:
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].RWA:
                        newItem.rate = vm.getLabourRate(templateItem.itemType);
                        vm.innerValue.labours.splice(vm.innerValue.labours.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].PAINT:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerValue.labours.splice(vm.innerValue.labours.length, 1, newItem);
                        // sortNo = vm.innerValue.labours.length ? Math.max(...vm.innerValue.labours.map(i => i.sortNo)) + 1 : 1
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].OPG:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerValue.opgs.splice(vm.innerValue.opgs.length, 1, newItem);
                        // sortNo = vm.innerValue.opgs.length ? Math.max(...vm.innerValue.opgs.map(i => i.sortNo)) + 1 : 1
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].MECH:
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].CD:
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].CRUSH:
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].FIBER:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerValue.others.splice(vm.innerValue.others.length, 1, newItem);
                        // sortNo = vm.innerValue.others.length ? Math.max(...vm.innerValue.others.map(i => i.sortNo)) + 1 : 1
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].PART:
                        vm.innerValue.parts.splice(vm.innerValue.parts.length, 1, newItem);
                        // sortNo = vm.innerValue.parts.length ? Math.max(...vm.innerValue.parts.map(i => i.sortNo)) + 1 : 1
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].MISC:
                        vm.innerValue.miscs.splice(vm.innerValue.miscs.length, 1, newItem);
                        // sortNo = vm.innerValue.labours.length ? Math.max(...vm.innerValue.labours.map(i => i.sortNo)) + 1 : 1
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_21__["ItemCategoryTypes"].SUBL:
                        vm.innerValue.sublets.splice(vm.innerValue.sublets.length, 1, newItem);
                        // sortNo = vm.innerValue.sublets.length ? Math.max(...vm.innerValue.sublets.map(i => i.sortNo)) + 1 : 1
                        break;
                    }
                    // newItem.sortNo = templateItem.sortNo // || sortNo
                  } else {
                    currentItem.value = templateItem.value;
                    currentItem.itemType = templateItem.itemType;
                    currentItem.reportOnly = templateItem.reportOnly;
                    currentItem.sortNo = templateItem.sortNo;
                  }
                });
              }
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    toggleActive: function toggleActive(active) {
      if (this.$licenceExpired) return;
      this.innerValue.deleted = !this.innerValue.deleted;
    },
    resetJobStartEnd: function resetJobStartEnd() {
      if (this.selectedJobStartEnd !== null) {
        this.selectedJobStartEnd = null;
      }
    },
    calculateExcess: function calculateExcess() {
      if (this.innerValue.excessWithGst && this.excess !== this.innerValue.excess) {
        var gstModel = new _classes__WEBPACK_IMPORTED_MODULE_31__["GstModel"](this.innerValue.gstRate);
        var excess = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.excess / gstModel.multiplier);
        this.excess = excess;
        this.innerValue.excess = excess;
      } else if (this.excess !== this.innerValue.excess) {
        this.innerValue.excess = this.excess;
      }
    },
    toogleReadOnly: function toogleReadOnly() {
      if (this.$licenceExpired) return;
      if (this.canChangeReadOnly) {
        this.innerValue.readOnly = !this.innerValue.readOnly;
        this.innerValue.readOnlyStatuses.splice(this.innerValue.subQuoteNo, 1, this.innerValue.readOnly);
      }
    },
    getLabourRate: function getLabourRate(code) {
      if (!this.innerValue.rates) {
        return {};
      }
      var rate = this.isNtar ? this.innerValue.rates[0] : this.innerValue.rates.find(function (i) {
        return i.labourCodeId === code;
      });
      return !rate ? 0 : rate.rate;
    },
    getNoOfDays: function getNoOfDays(startDate, endDate) {
      var d1 = luxon__WEBPACK_IMPORTED_MODULE_27__["DateTime"].fromISO(startDate.toISOString());
      var d2 = luxon__WEBPACK_IMPORTED_MODULE_27__["DateTime"].fromISO(endDate.toISOString());
      return d2.diff(d1, 'days').toObject().days + 1;
    },
    getNtarLtarStatus: function getNtarLtarStatus() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _context9.n = 1;
              return _views_vehicle_VehicleService__WEBPACK_IMPORTED_MODULE_35__["default"].getNtarLtarStatusById(_this9.innerValue.vehicleId);
            case 1:
              _this9.ntarLtarStatus = _context9.v;
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    jobStartEndDragEvent: function jobStartEndDragEvent(event) {
      this.dragValue = event;
    },
    jobStartEndInputEvent: function jobStartEndInputEvent(event) {},
    quoteDateInputEvent: function quoteDateInputEvent(event) {
      this.selectedQuoteDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    authorisedDateInputEvent: function authorisedDateInputEvent(event) {
      this.selectedAuthorisedDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components_ModuleSubNav__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/ModuleSubNav */ "./src/components/ModuleSubNav/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/services */ "./src/services/index.js");




























var _createNamespacedHelp = Object(vuex__WEBPACK_IMPORTED_MODULE_26__["createNamespacedHelpers"])('quoteContentCounts'),
  mapGetters = _createNamespacedHelp.mapGetters,
  mapActions = _createNamespacedHelp.mapActions;
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteSubNav',
  inject: ['$vv'],
  components: {
    ModuleSubNav: _components_ModuleSubNav__WEBPACK_IMPORTED_MODULE_22__["default"]
  },
  props: {
    value: null,
    insurer: {
      type: Object,
      default: function _default() {
        return null;
      }
    },
    ormUnreadMessageCount: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      showJobNoteRemarks: false
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, mapGetters(['imageCount', 'documentCount', 'smsUnreadCount', 'whatsAppUnreadCount', 'emailUnreadCount', 'commsTotalCount', 'remarkUnreadCount', 'imageUnreadCount', 'documentUnreadCount'])), {}, {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    visibleMenuItems: function visibleMenuItems() {
      var _this = this;
      return this.menuItems.filter(function (item) {
        return item.visible;
      }).map(function (item) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, item), {}, {
          // Convert badgeClass object to string for ModuleSubNav
          badgeClass: _this.convertBadgeClass(item.badgeClass)
        });
      });
    },
    visibleMoreMenuItems: function visibleMoreMenuItems() {
      var _this2 = this;
      return this.menuItemsMore.filter(function (item) {
        return item.visible;
      }).map(function (item) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, item), {}, {
          // Convert badgeClass object to string for ModuleSubNav
          badgeClass: _this2.convertBadgeClass(item.badgeClass)
        });
      });
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_23__["default"];
    },
    quotingMethodTypes: function quotingMethodTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_24__["QuotingMethodTypes"];
    },
    enableItemRoutes: function enableItemRoutes() {
      return _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].validGuid(this.value.insurerId) && _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].validGuid(this.value.vehicleId);
    },
    pnetAudanetMenuText: function pnetAudanetMenuText() {
      var _this$value$audatex;
      if (!this.value.isAudaNet) return '';
      var taskType = (_this$value$audatex = this.value.audatex) === null || _this$value$audatex === void 0 ? void 0 : _this$value$audatex.taskType;
      if (taskType) {
        return this.value.isAudaBridge ? "".concat(taskType) : "/".concat(taskType);
      }
      return '/AudaNet';
    },
    others: function others() {
      return this.value.others.filter(function (i) {
        return !i.deleted && i.itemType !== 'MECH';
      });
    },
    invoice: function invoice() {
      return this.value.invoices.find(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].Quote && !i.deleted;
      });
    },
    excessInvoice: function excessInvoice() {
      return this.value.invoices.find(function (i) {
        return (i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].Excess || i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].OwnerContribution) && !i.deleted;
      });
    },
    unreadCount: function unreadCount() {
      return this.smsUnreadCount + this.whatsAppUnreadCount + this.emailUnreadCount;
    },
    hasNewImages: function hasNewImages() {
      // Per-user unread state from QuoteContentLastRead, not the notification feed. The old
      // rule counted only QuoteImageUploadedIncoming - anonymous customer uploads - and
      // was quote-wide, so one person opening the tab cleared it for the whole shop.
      // FQ-3087 asks for per-user, and for a colleague's upload to count too.
      return this.imageUnreadCount > 0;
    },
    remarkCount: function remarkCount() {
      if (!this.value) return 0;
      var activeCount = function activeCount(remarks, remarkTypeId) {
        return (remarks || []).filter(function (r) {
          return !r.isDeleted && r.remarkTypeId === remarkTypeId;
        }).length;
      };
      return activeCount(this.value.remarks, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark) + activeCount(this.value.printedRemarks, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].PrintedRemark) + (this.showJobNoteRemarks ? activeCount(this.value.jobNoteRemarks, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].JobNote) : 0);
    },
    menuItems: function menuItems() {
      var _this$insurer;
      var isNew = this.value.isNew;
      return [{
        label: 'Header',
        route: {
          name: this.routeTypes.QuoteHeader.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: false,
        visible: true,
        badgeClass: {
          'has-badge-danger has-badge-small has-badge-rounded': this.$v.estimateJobStartEnd.$error || this.$v.quoteHeaderGroup.$error || this.$v.ormHeaderGroup.$error || this.$v.audaNetHeaderGroup.$error || this.$v.ormSummaryGroup.$error
        },
        badge: this.$v.estimateJobStartEnd.$error || this.$v.quoteHeaderGroup.$error || this.$v.ormHeaderGroup.$error || this.$v.audaNetHeaderGroup.$error || this.$v.ormSummaryGroup.$error ? '' : null
      }, {
        label: 'Quoting',
        route: {
          name: this.routeTypes.QuoteBuilder.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: true,
        badgeClass: {
          'has-badge-rounded has-badge-medium has-badge-danger': true
        },
        badge: null
      }, {
        label: 'Parts',
        route: {
          name: this.routeTypes.QuotePartsControl.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: true,
        badgeClass: {
          'has-badge-rounded has-badge-medium has-badge-danger': true
        },
        badge: null
      }, {
        label: 'Images',
        route: {
          name: this.routeTypes.QuoteImages.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true,
        badgeClass: {
          'has-badge-info has-badge-rounded has-badge-medium': this.imageCount
        },
        badge: this.imageCount ? this.imageCount : null,
        hasNewContent: this.hasNewImages
      }, {
        label: 'Assessments',
        route: {
          name: this.routeTypes.AuthoriseView.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: this.value.isAssessmentEnabled,
        badgeClass: {
          'has-badge-rounded has-badge-medium has-badge-danger': true
        },
        badge: null
      }, {
        label: this.value.isAudaBridge ? this.pnetAudanetMenuText : "PNET".concat(this.pnetAudanetMenuText),
        route: {
          name: this.routeTypes.QuotePnetAudanet.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: this.value.audatex || this.value.pnet
      }, {
        label: 'ORM',
        route: {
          name: this.routeTypes.QuoteOrm.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: this.value.orm || false,
        badgeClass: {
          'has-badge-rounded has-badge-medium has-badge-info': this.ormUnreadMessageCount > 0
        },
        badge: this.ormUnreadMessageCount > 0 ? this.ormUnreadMessageCount : null,
        hasNewContent: this.ormUnreadMessageCount > 0
      }, {
        label: 'ARNIE',
        route: {
          name: this.routeTypes.QuoteArnie.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: this.value.arnieCount
      }, {
        label: 'EstImage',
        route: {
          name: this.routeTypes.QuoteEstImage.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: (_this$insurer = this.insurer) === null || _this$insurer === void 0 ? void 0 : _this$insurer.estimage,
        badgeClass: {
          'has-badge-rounded has-badge-medium has-badge-danger': true
        },
        badge: null
      }, {
        label: 'Summary',
        route: {
          name: this.routeTypes.QuoteSummary.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true,
        badgeClass: null,
        //{ 'has-badge-danger has-badge-small has-badge-rounded': this.$v.ormSummaryGroup.$error || this.$v.estimateJobStartEnd.$error },
        badge: null //this.$v.ormSummaryGroup.$error || this.$v.estimateJobStartEnd.$error ? '' : null
      }, {
        label: 'Invoice',
        route: {
          name: this.value.isAssessmentEnabled ? this.routeTypes.QuoteAssessmentInvoice.name : this.routeTypes.QuoteInvoice.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: true,
        //badgeClass: { 'has-badge-rounded has-badge-medium has-badge-icon-check': !!(this.invoice) },
        badgeClass: function badgeClass() {
          var classes = this.getInvoiceBadgeClass('Invoice');
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({
            'has-badge-rounded has-badge-small has-badge-icon-check': !!this.invoice
          }, classes);
        },
        badge: this.invoice ? '✓' : null
      }, {
        label: 'Excess',
        route: {
          name: this.routeTypes.QuoteExcessInvoice.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: true,
        badgeClass: function badgeClass() {
          var classes = this.getInvoiceBadgeClass('Excess');
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({
            'has-badge-rounded has-badge-small has-badge-icon-check': !!this.excessInvoice
          }, classes);
        },
        badge: this.excessInvoice ? '✓' : null
      }, {
        label: 'Docs',
        route: {
          name: this.routeTypes.QuoteDocuments.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true,
        badgeClass: {
          'has-badge-info has-badge-rounded has-badge-medium': this.documentCount
        },
        badge: this.documentCount ? this.documentCount : null,
        hasNewContent: this.documentUnreadCount > 0
      }, {
        label: 'Comms',
        route: {
          name: this.routeTypes.QuoteCommunications.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true,
        badgeClass: {
          'has-badge-info has-badge-rounded has-badge-medium': this.commsTotalCount
        },
        badge: this.commsTotalCount ? this.commsTotalCount : null,
        hasNewContent: this.unreadCount > 0
      }, {
        label: 'Remarks',
        route: {
          name: this.routeTypes.QuoteRemarks.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true,
        badgeClass: {
          'has-badge-info has-badge-rounded has-badge-medium': this.remarkCount
        },
        badge: this.remarkCount ? this.remarkCount : null,
        hasNewContent: this.remarkUnreadCount > 0
      }, {
        label: 'Rates & Markups',
        route: {
          name: this.routeTypes.QuoteRatesMarkups.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true
      }, {
        label: 'Annotations',
        route: {
          name: this.routeTypes.QuoteAnnotations.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: true
      }, {
        label: 'Other Labour',
        route: {
          name: this.routeTypes.QuoteOtherLabour.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: !this.enableItemRoutes || isNew,
        visible: !!this.others.length,
        badgeClass: {
          'has-badge-info has-badge-rounded has-badge-medium': this.others.length
        },
        badge: this.others.length ? this.others.length : null
      }, {
        label: 'RepX',
        route: {
          name: this.routeTypes.QuoteRepx.name,
          params: {
            quoteId: this.$route.params.quoteId
          },
          query: this.$route.query
        },
        disabled: isNew,
        visible: this.value.repx
      }];
    },
    menuItemsMore: function menuItemsMore() {
      // const isNew = this.value.isNew
      return [];
    }
  }),
  watch: {
    // Switching to a supplementary keeps this component alive - the route name is the
    // same and only the quoteId param changes, so created() does not run again. Starting
    // the counts there instead would leave them describing the quote the user left, with
    // no poll to correct it. Watching the prop also covers the notification bell, which
    // pushes straight from one quote to another.
    'value.quoteId': {
      handler: function handler(quoteId) {
        if (!quoteId) return;
        this.startContentCounts(quoteId);
      },
      immediate: true
    }
  },
  created: function created() {
    var _this3 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this3.getPlanningPlusActiveStatus();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    var _this4 = this;
    // Counts changed underneath us - a refresh is cheaper to reason about than
    // trusting a number passed through an event.
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].ImageCountChanged, function () {
      return _this4.refreshContentCounts();
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].DocumentCountChanged, function () {
      return _this4.refreshContentCounts();
    });
    // Raised by QuoteView when the SMS modal closes, which may or may not have sent
    // anything - it carries no count, it just asks for a re-read.
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].CommsCountChanged, function () {
      return _this4.refreshContentCounts();
    });
    // A sender that already knows the new total passes it; one that only knows
    // something changed passes nothing, and we go and read it.
    // Each tab clears its own indicator on open rather than waiting out the poll.
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].RemarksRead, function () {
      return _this4.markContentRead('remarks');
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].ImagesRead, function () {
      return _this4.markContentRead('images');
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].DocumentsRead, function () {
      return _this4.markContentRead('documents');
    });
    // Comms clears one channel at a time, so the payload names which one.
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].CommsRead, function (channel) {
      if (channel === _enums__WEBPACK_IMPORTED_MODULE_24__["CommunicationTypes"].SMS) _this4.markContentRead('sms');else if (channel === _enums__WEBPACK_IMPORTED_MODULE_24__["CommunicationTypes"].WhatsApp) _this4.markContentRead('whatsApp');else if (channel === _enums__WEBPACK_IMPORTED_MODULE_24__["CommunicationTypes"].Email) _this4.markContentRead('email');
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].ImageCountChanged);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].DocumentCountChanged);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].CommsCountChanged);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].RemarksRead);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].ImagesRead);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].DocumentsRead);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].CommsRead);
    this.stopContentCounts();
  },
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({
    convertBadgeClass: function convertBadgeClass(badgeClass) {
      if (!badgeClass) return '';
      var resolved = typeof badgeClass === 'function' ? badgeClass.call(this) : badgeClass;
      if (typeof resolved === 'string') return resolved;
      if (Array.isArray(resolved)) {
        var parts = [];
        resolved.forEach(function (entry) {
          if (!entry) return;
          if (typeof entry === 'string') {
            parts.push(entry);
          } else if (Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(entry) === 'object') {
            parts.push(Object.keys(entry).filter(function (key) {
              return entry[key];
            }).join(' '));
          }
        });
        return parts.filter(Boolean).join(' ').trim();
      }
      if (Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(resolved) === 'object') {
        return Object.keys(resolved).filter(function (key) {
          return resolved[key];
        }).join(' ');
      }
      return '';
    },
    handleItemClick: function handleItemClick(item) {
      this.goToRoute(item.route, item.disabled);
    },
    handleCustomAction: function handleCustomAction(payload) {
      // Handle custom actions emitted from ModuleSubNav slots
      var item = payload.item,
        actionType = payload.actionType,
        args = payload.args;
      this.$emit('custom-action', {
        item: item,
        actionType: actionType,
        args: args
      });
    },
    goToRoute: function goToRoute(route, isDisabled) {
      if (isDisabled) {
        this.$toast.open({
          message: 'Please create the quote to make changes',
          type: 'is-warning',
          position: 'is-top'
        });
        return;
      }
      this.$router.push(route);
    }
  }, mapActions({
    startContentCounts: 'start',
    stopContentCounts: 'stop',
    refreshContentCounts: 'refresh',
    markContentRead: 'markRead'
  })), {}, {
    getPlanningPlusActiveStatus: function getPlanningPlusActiveStatus() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var externalSettings, planningPlusExternalSetting;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_27__["CompanySettingService"].getCompanyExternalSettings();
            case 1:
              externalSettings = _context2.v;
              planningPlusExternalSetting = externalSettings.find(function (i) {
                return i.settingName === _enums__WEBPACK_IMPORTED_MODULE_24__["ExternalSettingTypes"].SETTING_PLANNINGPLUS;
              });
              _this5.showJobNoteRemarks = !!parseInt(planningPlusExternalSetting === null || planningPlusExternalSetting === void 0 ? void 0 : planningPlusExternalSetting.property5); // Active property
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    handleClickImageBreakOut: function handleClickImageBreakOut() {
      var _this6 = this;
      var baseUri =  false ? undefined : "".concat("/v2", "/");
      var newWindow = window.open("".concat(baseUri, "quotes/").concat(this.value.quoteId, "/imagesbreakout?uninterruptedview=true"), 'Imageviewer', {
        width: 1600,
        height: 900,
        left: 0,
        top: 0,
        fullscreen: 'yes',
        title: 'Image Breakout'
      });
      if (newWindow) {
        var timer = setInterval(function () {
          if (newWindow.closed) {
            clearInterval(timer);
            if (_this6.$router.currentRoute.name == _route_types__WEBPACK_IMPORTED_MODULE_23__["default"].QuoteImages.name) {
              _this6.$emit('reload-quote-images');
            }
          }
        }, 500);
      }
    },
    getInvoiceBadgeClass: function getInvoiceBadgeClass(type) {
      var classes = {};
      if (type === 'Invoice') {
        if (this.$v.entity.invoices.$error) {
          var errors = Object.values(this.$v.entity['invoices'].$each.$iter).filter(function (r) {
            return r.$anyError;
          });
          errors.forEach(function (item) {
            if (item.$model.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].Quote) {
              classes['has-badge-danger'] = true;
            }
          });
        } else if (this.invoice && this.invoice.isNew) {
          classes['has-badge-gold'] = true;
        } else {
          classes['has-badge-success'] = true;
        }
      }
      if (type === 'Excess') {
        if (this.$v.entity.invoices.$error) {
          var _errors = Object.values(this.$v.entity['invoices'].$each.$iter).filter(function (r) {
            return r.$anyError;
          });
          _errors.forEach(function (item) {
            if (item.$model.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].Excess || item.$model.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_24__["InvoiceTypes"].OwnerContribution) {
              classes['has-badge-danger'] = true;
            }
          });
        } else if (this.excessInvoice && this.excessInvoice.isNew) {
          classes['has-badge-gold'] = true;
        } else {
          classes['has-badge-success'] = true;
        }
      }
      return classes;
    }
  })
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_flat_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.array.flat.js */ "./node_modules/core-js/modules/es.array.flat.js");
/* harmony import */ var core_js_modules_es_array_flat_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_flat_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.array.unscopables.flat.js */ "./node_modules/core-js/modules/es.array.unscopables.flat.js");
/* harmony import */ var core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_map_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.map.js */ "./node_modules/core-js/modules/es.map.js");
/* harmony import */ var core_js_modules_es_map_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_map_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.promise.all-settled.js */ "./node_modules/core-js/modules/es.promise.all-settled.js");
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _QuoteValidation__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./QuoteValidation */ "./src/views/quote/QuoteValidation.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _views_insurer_route_types__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(/*! @/views/insurer/route-types */ "./src/views/insurer/route-types.js");
/* harmony import */ var _views_vehicle_route_types__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(/*! @/views/vehicle/route-types */ "./src/views/vehicle/route-types.js");
/* harmony import */ var _views_vehicle_route_types__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(_views_vehicle_route_types__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _components_Sms__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(/*! @/components/Sms */ "./src/components/Sms/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(/*! ./services */ "./src/views/quote/services/index.js");
/* harmony import */ var _components_XmlViewer__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(/*! @/components/XmlViewer */ "./src/components/XmlViewer/index.js");
/* harmony import */ var _components_QuoteTemplateModal_QuoteTemplateApplyModal__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(/*! @/components/QuoteTemplateModal/QuoteTemplateApplyModal */ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue");
/* harmony import */ var _views_booking_route_types__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(/*! @/views/booking/route-types */ "./src/views/booking/route-types.js");
/* harmony import */ var _views_repx_RepxService__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(/*! @/views/repx/RepxService */ "./src/views/repx/RepxService.js");
/* harmony import */ var _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(/*! ../ormmessage/OrmMessageService */ "./src/views/ormmessage/OrmMessageService.js");
/* harmony import */ var _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(/*! @/components/QuoteBuilderSidebar.vue */ "./src/components/QuoteBuilderSidebar.vue");
/* harmony import */ var _components_VehicleButterfly__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(/*! @/components/VehicleButterfly */ "./src/components/VehicleButterfly/index.js");
/* harmony import */ var _components_ModuleDetailHeader__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(/*! @/components/ModuleDetailHeader */ "./src/components/ModuleDetailHeader/index.js");
/* harmony import */ var _QuoteSubNav__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(/*! ./QuoteSubNav */ "./src/views/quote/QuoteSubNav.vue");
/* harmony import */ var _helpers_QuoteAutoSaveHelper__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(/*! ./helpers/QuoteAutoSaveHelper */ "./src/views/quote/helpers/QuoteAutoSaveHelper.js");
/* harmony import */ var _helpers_PartsCheckSyncPartHelper__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(/*! ./helpers/PartsCheckSyncPartHelper */ "./src/views/quote/helpers/PartsCheckSyncPartHelper.js");
/* harmony import */ var _components_QuoteBanner_QuoteBanner_vue__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(/*! @/components/QuoteBanner/QuoteBanner.vue */ "./src/components/QuoteBanner/QuoteBanner.vue");
/* harmony import */ var _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(/*! @/components/BulmaMessage/BulmaMessage.vue */ "./src/components/BulmaMessage/BulmaMessage.vue");
/* harmony import */ var _sentry_vue__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(/*! @sentry/vue */ "./node_modules/@sentry/vue/build/esm/index.js");
































































































// Serialize deep-diff results to a JSON string so the full pending-change detail survives
// Sentry's normalizeDepth truncation (which otherwise renders nested values as [Array]/[DiffNew]).
function stringifyDiff(diffs) {
  if (!diffs) return null;
  try {
    var str = JSON.stringify(diffs);
    return str && str.length > 10000 ? str.slice(0, 10000) + '…(truncated)' : str;
  } catch (e) {
    return String(diffs);
  }
}

// PCK-153: a failed quote save only raised a toast, so what actually failed was never recorded.
// Report it with the failing request and its body so the cause can be found in Sentry.
function reportSaveFailure(error, step, extra) {
  try {
    var config = error && error.config;
    var requestBody = config && config.data;
    _sentry_vue__WEBPACK_IMPORTED_MODULE_89__["captureException"](error, {
      tags: {
        feature: 'quote-save',
        step: step,
        status: error && error.response && error.response.status
      },
      extra: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_6__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_6__["default"])({}, extra), {}, {
        request: config ? "".concat((config.method || '').toUpperCase(), " ").concat(config.url) : null,
        requestBody: typeof requestBody === 'string' && requestBody.length > 10000 ? requestBody.slice(0, 10000) + '…(truncated)' : requestBody,
        responseBody: stringifyDiff(error && error.response && error.response.data)
      })
    });
  } catch (telemetryError) {
    console.error('Failed to report quote save failure to Sentry:', telemetryError);
  }
}
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteView',
  components: {
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_61__["UnsavedModal"],
    PrintOptionsModal: _components__WEBPACK_IMPORTED_MODULE_65__["PrintOptionsModal"],
    InvoicePrintOptionsModal: _components__WEBPACK_IMPORTED_MODULE_65__["InvoicePrintOptionsModal"],
    SmsModal: _components_Sms__WEBPACK_IMPORTED_MODULE_71__["SmsModal"],
    CopyQuoteModal: _components__WEBPACK_IMPORTED_MODULE_65__["CopyQuoteModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_61__["ConfirmModal"],
    QuoteExportModal: _components__WEBPACK_IMPORTED_MODULE_65__["QuoteExportModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_61__["SaveConflictModal"],
    XmlViewerModal: _components_XmlViewer__WEBPACK_IMPORTED_MODULE_76__["XmlViewerModal"],
    QuoteTemplateApplyModal: _components_QuoteTemplateModal_QuoteTemplateApplyModal__WEBPACK_IMPORTED_MODULE_77__["default"],
    QuoteBuilderSidebar: _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__["default"],
    VehicleButterflyModal: _components_VehicleButterfly__WEBPACK_IMPORTED_MODULE_82__["VehicleButterflyModal"],
    ModuleDetailHeader: _components_ModuleDetailHeader__WEBPACK_IMPORTED_MODULE_83__["default"],
    QuoteSubNav: _QuoteSubNav__WEBPACK_IMPORTED_MODULE_84__["default"],
    QuoteBanner: _components_QuoteBanner_QuoteBanner_vue__WEBPACK_IMPORTED_MODULE_87__["default"],
    BulmaMessage: _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_88__["default"]
  },
  mixins: [_QuoteValidation__WEBPACK_IMPORTED_MODULE_53__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_56__["default"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteLabourMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteOtherLabourMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuotePartMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteOpgMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteMiscMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteSubletMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuoteNotificationMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["ScreenMixin"], _mixins__WEBPACK_IMPORTED_MODULE_70__["QuotePresenceMixin"]],
  props: {
    returnUrl: {
      type: String,
      default: ''
    },
    invoiceType: {
      type: Number,
      default: 1
    },
    currentsubquote: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      entity: null,
      entityMainQuote: null,
      isSkipSave: false,
      isSaveContinue: false,
      isUnsavedModalActive: false,
      isQuoteTemplateModalActive: false,
      isSaveConflictModalActive: false,
      toRoute: null,
      isPrintOptionsActive: false,
      isInvoicePrintOptionsActive: false,
      isSmsModalActive: false,
      isQuoteExportModalActive: false,
      smsDetails: null,
      isCopyQuoteModalActive: false,
      isConfirmModalActive: false,
      isRestoreAllConfirmModalActive: false,
      isNavigationWarningModalActive: false,
      navigationWarningMessage: '',
      navigationWarningAction: null,
      skipNextNavWarning: false,
      skipNextUnsavedModal: false,
      leaveWithUnsavedErrors: false,
      exportType: 'text',
      imageIds: [],
      fabActions: [],
      audanetSetting: null,
      pnetSetting: null,
      vehicle: null,
      customer: null,
      insurer: null,
      isCustomerCreateModifyModalActive: false,
      customerSaveAction: '',
      customerModalSelection: 'create',
      pricePartsReturnRoute: null,
      isHeaderButtonHided: false,
      isXmlViewerModalActive: false,
      messageType: '',
      quoteTemplateDisabled: true,
      supplementaryQuotes: null,
      isSaving: false,
      isLoading: false,
      templateQuoteItemCount: 0,
      // for orm quotes only
      ormUnreadMessageCount: 0,
      // Stable baseline for header autosave diffs (deep ers often provide an unusable oldVal).
      headerAutosaveBaseline: {
        vehicle: null,
        customer: null,
        insurer: null
      },
      suppressHeaderAutosave: false,
      headerAutosaveToken: 0,
      headerAutosaveInFlight: false,
      headerSavingPanels: {
        vehicle: false,
        customer: false,
        insurer: false,
        booking: false
      },
      /// autosave status object
      autoSaveStatus: {
        isSaving: false,
        isEditing: false,
        isDiffChanged: false,
        isFailed: false,
        failMessage: ''
      },
      autoSaveFailureCount: 0,
      autoSaveFailureLimit: 1,
      autoSaveDisabled: false,
      autoSaveEnabledToggle: true,
      showHorizontalMenu: true,
      selectedMenu: _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__["MENU_MODES"].VEHICLE,
      // Butterfly modal state
      isButterflyModalActive: false,
      selectedArea: null,
      selectedSubSections: [],
      // Vehicle Butterfly modal state
      isVehicleButterflyModalActive: false,
      // selectedVehicleSections: []

      showCustomOption: true,
      innerJobNSubJobStageCompositeKey: null,
      availableItemsType: 'PARTS',
      initialQuoteCustomer: null,
      affectedQuotesCount: 0,
      derivedItemUpdateDepth: 0
    };
  },
  computed: {
    // Autosave is on for every company; it is only switched off per quote (e.g. after failures)
    // or when the licence has expired.
    autoSaveEnabled: function autoSaveEnabled() {
      return !this.autoSaveDisabled && !this.$licenceExpired;
    },
    // When autosave is on, show the manual Save button only for companies opted into keeping it.
    // Companies with the setting false (the default) have the button removed entirely.
    autoSaveManualSaveEnabled: function autoSaveManualSaveEnabled() {
      var _this$$company;
      return ((_this$$company = this.$company) === null || _this$$company === void 0 || (_this$$company = _this$$company.setting) === null || _this$$company === void 0 ? void 0 : _this$$company.autoSaveManualSaveEnabled) === true;
    },
    // Autosave is enabled AND can actually save this quote. New quotes are never
    // autosaved (every pipeline guards on isAnyEntityNew), so navigation guards must fall
    // back to the unsaved-changes prompt for them instead of assuming autosave covers it.
    autoSaveActiveForQuote: function autoSaveActiveForQuote() {
      return this.autoSaveEnabled && !!this.entity && !this.entity.isNew;
    },
    // hide if curretroute is quoteBuilder
    hideSaveButton: function hideSaveButton() {
      return this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
    },
    showSaveButton: function showSaveButton() {
      if (!this.entity || this.readOnlyView) return false;
      if (this.autoSaveStatus.isFailed) return true;

      // Show save button when autosave is disabled
      if (!this.autoSaveEnabled) return true;
      return !this.isHeaderButtonHided;
    },
    quoteSaveStatus: function quoteSaveStatus() {
      if (this.autoSaveStatus.isFailed) return 'Autosave failed';
      if (!this.entity || !this.entity.modifiedDate) return 'Not saved yet';
      if (!!this.snapshotDiff) return 'Unsaved changes';
      var savedDate = new Date(this.entity.modifiedDate + 'Z');
      return 'Saved on ' + savedDate.toLocaleString('en-AU', {
        timeZone: 'Australia/Brisbane',
        hour12: true,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      });
    },
    totalExGst: function totalExGst() {
      if (this.entity) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.entity.rrTotal + this.entity.repairTotal + this.entity.rwaTotal + this.entity.paintTotal + this.entity.partTotal + this.entity.opgTotal + this.entity.fgTotal + this.entity.crushTotal + this.entity.cdTotal + this.entity.mechTotal + this.entity.miscTotal + this.entity.sublTotal);
      }
    },
    gst: function gst() {
      if (this.entity) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.totalExGst * (this.entity.gstRate / 100));
      }
    },
    totalIncGst: function totalIncGst() {
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.totalExGst + this.gst);
    },
    maxLineNumber: function maxLineNumber() {
      var numbers = [Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.labours.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.parts.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.opgs.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.others.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.miscs.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.sublets.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0]))];
      return numbers;
    },
    nextLineNumber: function nextLineNumber() {
      // return this.entity.lines
      var numbers = [Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.labours.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.parts.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.opgs.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.others.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.miscs.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(this.entity.sublets.filter(function (i) {
        return !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber;
      })).concat([0])), this.entity.lines - 1];
      return Math.max.apply(Math, numbers) + 1;
    },
    validateError: function validateError() {
      this.$v.quoteHeaderGroup.$touch();
      this.$v.customer.companyName.$touch();
      this.$v.customer.firstname.$touch();
      this.$v.customer.lastname.$touch();

      // Base (non-ORM) validators only. ORM-only validators (entity.odometer,
      // jobStart, jobEnd, damageSeverity, refuseBookRepairReason,
      // repairLateReason, claimNo ORM sub-rules, vehicle.bodyId2/buildMonth/
      // buildYear/paintCode, the ormMaxLength sub-rules on vehicle.rego and
      // customer.companyName) are intentionally excluded so ORM validation can
      // never block normal Save/autosave. ORM rules are enforced only by the
      // ORM submit gate in QuoteOrm.vue (Send Quote / Send Tax Invoice).
      var baseEntityError = this.$v.entity.quoteId.$error || this.$v.entity.vehicleId.$error || this.$v.entity.insurerId.$error || this.$v.entity.customerId.$error || this.$v.entity.quoter.$error || this.$v.entity.authorisedDate.$error || this.$v.entity.labours.$anyError || this.$v.entity.others.$anyError || this.$v.entity.parts.$anyError || this.$v.entity.opgs.$anyError || this.$v.entity.miscs.$anyError || this.$v.entity.sublets.$anyError || this.$v.entity.invoices.$anyError || this.$v.entity.claimNo.$dirty && !this.$v.entity.claimNo.required;

      // Generic data-integrity rule for ALL quotes (not ORM-specific): job
      // start must not be after job end. Evaluated directly from entity data
      // and decoupled from the ORM jobStart/jobEnd validators so a non-ORM
      // quote still cannot be saved with the dates reversed (parity with
      // pre-change behaviour), without pulling ORM-only validation back into
      // the Save gate or touching/dirtying the ORM validators.
      var jobDatesOutOfOrder = !!(this.entity && this.entity.jobStart && this.entity.jobEnd) && this.entity.jobStart > this.entity.jobEnd;
      return baseEntityError || jobDatesOutOfOrder || this.$v.vehicle.rego.$dirty && !this.$v.vehicle.rego.required || this.$v.vehicle.model.$error || this.$v.vehicle.bodyId.$error || this.$v.vehicle.paintGroup.$error || this.$v.customer.companyName.$dirty && (!this.$v.customer.companyName.required || !this.$v.customer.companyName.isNotWhitespaceOnly) || this.$v.customer.firstname.$error || this.$v.customer.lastname.$error || this.$v.customer.emails.$error || this.$v.customer.contacts.$error || this.$v.insurer.name.$error;
    },
    invoice: function invoice() {
      return this.entity.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].Quote;
      });
    },
    excessInvoice: function excessInvoice() {
      return this.entity.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].Excess;
      });
    },
    ocInvoice: function ocInvoice() {
      return this.entity.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].OwnerContribution;
      });
    },
    isInvoiced: function isInvoiced() {
      return this.entity && this.entity.invoices && this.entity.invoices.length > 0;
    },
    isNtar: function isNtar() {
      if (this.entity) {
        return this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].NTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].LTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].eMTA;
      }
    },
    isEmta: function isEmta() {
      return this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].eMTA;
    },
    isRacq: function isRacq() {
      return this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].RACQ;
    },
    deleteQuoteMessage: function deleteQuoteMessage() {
      var quoteRef = "".concat(this.entity.prefix).concat(this.entity.quoteNo).concat(this.entity.suffix);
      if (this.entity.subQuoteNo === 0) {
        if (this.entity.subQuoteNos.length === 1) {
          return quoteRef;
        }
        return "".concat(quoteRef, " and all supplementary quotes");
      } else if (this.entity.subQuoteNo > 0) {
        return "".concat(quoteRef, "/").concat(this.entity.subQuoteNo);
      }
      return quoteRef;
    },
    deleteQuoteToastMessage: function deleteQuoteToastMessage() {
      if (!this.entity) return '';
      // Keep existing main-quote message as-is, but prefix supplementary quotes.
      return this.entity.subQuoteNo > 0 ? "Supplementary Quote ".concat(this.deleteQuoteMessage) : this.deleteQuoteMessage;
    },
    insurerDefaultEmail: function insurerDefaultEmail() {
      var defaultEmail = this.quoteInsurer.emails.find(function (e) {
        return e.isDefault;
      });
      if (defaultEmail) {
        return defaultEmail.address;
      } else {
        return '';
      }
    },
    showNewAdditional: function showNewAdditional() {
      if (this.entity && this.entity.isAssessmentEnabled) {
        return false;
      }
      if (this.entity && this.entity.isPnet === true && this.entity.audatex === null && this.entity.pnet !== null) {
        if (this.entity.pnet.authorityNo !== null && this.entity.pnet.authorityNo !== '') return true;else return false;
      } else {
        return this.entity && (!this.entity.isAudaNet && !this.entity.isAudaBridge || (this.audanetSetting.property4 === '1' || this.audanetSetting.property4.toLowerCase() === 'true' || this.audanetSetting.property4.toLowerCase() === '') && (this.entity.isAudaNet || this.entity.isAudaBridge));
      }
    },
    // isAudanet() {
    //   return this.pnetSetting !== null && this.pnetSetting.property5 === '4.1'
    // },
    // isAudaBridge() {
    //   return this.entity.audatex !== null && this.entity.audatex.taskType === 'AudaBridge'
    // }
    uninterruptedView: function uninterruptedView() {
      return this.$route.query.uninterruptedview === 'true';
    },
    canChangeReadOnly: function canChangeReadOnly() {
      return this.$userInfo.isSupportUser || this.$userInfo.isCustomerAdministrator;
    },
    hasUnsavedQuoteChanges: function hasUnsavedQuoteChanges() {
      if (this.snapshotDiff) return true;
      // Only trust `isDiffChanged` while autosave is running: the entity watcher that clears it
      // is gated on `!entity.readOnly`, so locking the quote leaves it stuck true.
      return this.autoSaveActiveForQuote && Boolean(this.autoSaveStatus.isDiffChanged);
    },
    isQuoteSaveInProgress: function isQuoteSaveInProgress() {
      return Boolean(this.isSaving || this.autoSaveStatus.isSaving || this.headerAutosaveInFlight);
    },
    showQuoteActionButton: function showQuoteActionButton() {
      // FQ-3037: deliberately not gated on `entity.readOnly`. Integrations (EstImage, PNET)
      // lock a quote as soon as an authority is loaded, and FQ-2955's lock gate then hid
      // New Additional Quote / Copy Quote / Export Quote — none of which edit this quote —
      // forcing users to unlock before starting a supplementary. Unpersisted state hides them
      // instead: all three read the quote server-side or navigate away from it.
      return this.entity && !this.entity.isNew && !this.hasUnsavedQuoteChanges && !this.isQuoteSaveInProgress && !this.uninterruptedView && !(this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePartsControl.name) && !(this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePriceParts.name);
    },
    canViewPricePartsMsg: function canViewPricePartsMsg() {
      return this.$userInfo.isSupportUser && this.entity && this.entity.parts.filter(function (p) {
        return p.partStatus == 'Imp' || p.partStatus == 'Exp' || p.partStatus == 'Pord';
      }).length > 0;
    },
    quoteNoRef: function quoteNoRef() {
      return "".concat(this.entity.prefix).concat(this.entity.quoteNo).concat(this.entity.suffix);
    },
    isRepx: function isRepx() {
      return this.entity && !!this.entity.repx;
    },
    showLock: function showLock() {
      if (!this.entity || this.entity.isNew) {
        return false;
      }
      if (this.entity.isAssessmentEnabled) {
        // Show unlock button for locked quotes, hide for unlocked quotes
        return this.entity.readOnly;
      }
      return true;
    },
    isQuoteCancelledByInsurer: function isQuoteCancelledByInsurer() {
      if (this.entity.estimage) {
        return this.entity.estimage.quoteStatus === 'Cancelled';
      } else if (this.entity.orm) {
        //Quote_Job_Cancelled = 80
        return this.entity.orm.quoteStatusID === 80;
      } else if (this.entity.pnet) {
        return this.entity.pnet.quoteStatusID === 60;
      } else if (this.entity.audatex) {
        return this.entity.audatex.businessStatusText === 'Cancelled';
      }
    },
    showQuoteTemplate: function showQuoteTemplate() {
      return this.entity && !this.entity.isNew && !this.entity.deleted && !this.entity.readOnly && this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
    },
    isQuoteBuilder: function isQuoteBuilder() {
      return this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
    },
    isQuoteEditable: function isQuoteEditable() {
      //for orm quote with invoice submitted and assessment enabled, make it read only
      var quoteEditable = this.entity && !this.entity.isNew && !this.entity.deleted && !this.entity.readOnly && !this.$licenceExpired;
      // console.log('quoteEditable', quoteEditable, 'ormEditable', ormEditable)
      return quoteEditable && this.isOrmEditedQuote;
    },
    isOrmEditedQuote: function isOrmEditedQuote() {
      var ormEditable = this.entity && this.entity.orm && this.entity.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_55__["OrmQuoteStatusTypes"].QuoteInvoiceSubmitted && this.entity.isAssessmentEnabled ? false : true;
      return ormEditable;
    },
    isDollarQuoteOrm: function isDollarQuoteOrm() {
      return !!(this.entity && this.entity.orm && this.entity.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_55__["QuotingMethodTypes"].Dollar);
    },
    hasFlexiShopIntegration: function hasFlexiShopIntegration() {
      return this.planningSetting && this.planningSetting.password;
    },
    // jobNSubJobStageCompositeKey() {
    //   if (this.entity) {
    //     let jobStage = this.entity.jobStage
    //     if (jobStage) {
    //       let subJobStage = this.entity.subJobStage || ''
    //       return jobStage + '|' + subJobStage
    //     }
    //   }
    //   return ''
    // },
    jobNSubJobStageCompositeName: function jobNSubJobStageCompositeName() {
      var _this = this;
      // if (this.entity.isNew) {
      //   return '-'
      // }
      if (this.innerJobNSubJobStageCompositeKey) {
        if (this.jobNSubJobStages && Array.isArray(this.jobNSubJobStages)) {
          var jobNSubJobStage = this.jobNSubJobStages.find(function (j) {
            return j.compositeKey === _this.innerJobNSubJobStageCompositeKey;
          });
          if (jobNSubJobStage) {
            return jobNSubJobStage.compositeName;
          }
        }
        if (this.jobStages && Array.isArray(this.jobStages)) {
          var jobStageKey = this.innerJobNSubJobStageCompositeKey.split('|')[0];
          var jobStage = this.jobStages.find(function (j) {
            return j.stage == jobStageKey;
          });
          if (jobStage) {
            return jobStage.description;
          }
        }
      }
      return '';
    },
    isAuthorised: function isAuthorised() {
      return this.entity && !this.entity.isNew && this.entity.authorisedBy;
    },
    jobNSubJobStagesOptions: function jobNSubJobStagesOptions() {
      var _this2 = this;
      if (!this.jobNSubJobStages) return [];
      var isDisableParentWithSub = !!this.isRepx;
      var groupedStages = {};

      // Group job stages and sub job stages
      this.jobNSubJobStages.forEach(function (option) {
        var jobStageId = option.jobStageId;
        var jobStageName = option.jobStageName;
        if (!groupedStages[jobStageId]) {
          // Get sort key from jobStages array
          var jobStageInfo = _this2.jobStages ? _this2.jobStages.find(function (js) {
            return js.stage === jobStageId;
          }) : null;
          var jobStageSortKey = jobStageInfo ? jobStageInfo.sortKey : 999;
          groupedStages[jobStageId] = {
            jobStageId: jobStageId,
            jobStageName: jobStageName,
            jobStageSortKey: jobStageSortKey,
            mainStage: {
              compositeKey: "".concat(jobStageId, "|"),
              compositeName: jobStageName,
              disabled: false
            },
            subStages: []
          };
        }

        // If this option has a sub job stage, add it to the subStages array
        if (option.subJobStageId && option.subJobStageId !== '') {
          groupedStages[jobStageId].subStages.push(option);
          // If there are sub stages, disable the parent stage if needed
          if (isDisableParentWithSub) {
            groupedStages[jobStageId].mainStage.disabled = true;
          }
        }
      });

      // Convert to array and sort by jobStageSortKey
      var sortedGroups = Object.values(groupedStages).sort(function (a, b) {
        return (a.jobStageSortKey || 999) - (b.jobStageSortKey || 999);
      });

      // Sort sub stages within each group by sortKey
      sortedGroups.forEach(function (group) {
        group.subStages.sort(function (a, b) {
          return (a.sortKey || 999) - (b.sortKey || 999);
        });
      });
      return sortedGroups;
    },
    customerAndVehicleMakeModelMaxLength: function customerAndVehicleMakeModelMaxLength() {
      if (this.isScreenBelow(this.BULMA_BREAKPOINTS.FULLHD)) {
        return 0;
      } else if (this.isScreenBelow(this.BULMA_BREAKPOINTS.XXL)) {
        return 10;
      } else if (this.isScreenAbove(this.BULMA_BREAKPOINTS.XXL)) {
        return 20;
      }
    },
    isNewCustomerPrompt: function isNewCustomerPrompt() {
      var customerDiff = deep_diff__WEBPACK_IMPORTED_MODULE_74__["DeepDiff"].diff(this.customer, this.initialQuoteCustomer);
      var isPerson = this.currentCustomerSnapshot && this.currentCustomerSnapshot.isPerson;
      if (customerDiff) {
        var paths = customerDiff.map(function (d) {
          return d.path;
        }).flat();
        var prompt = paths.includes('firstname') || paths.includes('lastname') || paths.includes('phones');
        if (!isPerson) {
          prompt = paths.includes('companyName');
        }
        return prompt;
      }
      return false;
    },
    isMainQuote: function isMainQuote() {
      return this.entity && this.entity.subQuoteNo === 0;
    }
  },
  watch: {
    'entity.labours': {
      handler: function handler(newVal, oldVal) {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.paintTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.paintTotal);
        this.entity.rrTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.rrTotal);
        this.entity.repairTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.repairTotal);
        this.entity.rwaTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.rwaTotal);
        this.entity.labourTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.labourTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        this.scheduleItemsSave();
      },
      deep: true
    },
    'entity.others': {
      handler: function handler() {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.cdTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.cdTotal);
        this.entity.crushTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.crushTotal);
        this.entity.mechTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.mechTotal);
        this.entity.fgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.fgTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        this.scheduleItemsSave();
      },
      deep: true
    },
    'entity.parts': {
      handler: function handler() {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.partTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.partTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        this.scheduleItemsSave();
      },
      deep: true
    },
    'entity.opgs': {
      handler: function handler() {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.opgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.opgTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        // opgs are not part of the managed item set, so no save is scheduled here.
      },
      deep: true
    },
    'entity.miscs': {
      handler: function handler() {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.miscTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.miscTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        this.scheduleItemsSave();
      },
      deep: true
    },
    'entity.sublets': {
      handler: function handler() {
        var derivedGuard = this.getDerivedItemGuard();
        this.entity.sublTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(this.subletTotal);
        if (derivedGuard.shouldSkipWatcher() || this._isAutosaveRefreshing) {
          return;
        }
        this.scheduleItemsSave();
      },
      deep: true
    },
    entity: {
      handler: function handler(newVal, oldVal) {
        // Skip snapshot update during autosave entity refresh — saveSnapshot is called
        // explicitly by debouncedEntityRefresh after the entity is fully reconstructed.
        if (!this._isAutosaveRefreshing) {
          if (this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name) {
            // On QuoteBuilder, batch rapid snapshot updates — see _throttledSnapshotUpdate below.
            this._throttledSnapshotUpdate();
          } else {
            // On other quote routes, update synchronously so the entity watcher's
            // DeepDiff.diff(baseSnapshot, currentSnapshot) check sees the latest state
            // and can trigger autoSaveQuote correctly.
            this.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.entity));
          }
        }
        if (!oldVal) return;
        var keysToWatch = ['totalExGst', 'excess', 'ownersContribution', 'discount', 'excessWithGst'];
        var hasChanged = keysToWatch.some(function (key) {
          return newVal[key] !== oldVal[key];
        });
        if (hasChanged) this.calculateTotalPayableIncGst();

        // trigger auto save on the entity, if not in quote items page,
        // as the quote items page will auto save the entity lite version
        if (this.$route.name !== _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name) {
          // if the quote is not new, then auto save the quote
          if (!this.entity.isNew && !this.entity.readOnly && !this.isLoading) {
            var quoteDiff = deep_diff__WEBPACK_IMPORTED_MODULE_74__["DeepDiff"].diff(this.baseSnapshot, this.currentSnapshot);
            if (!quoteDiff) {
              if (!this.hasPendingAutoSaveDiffs()) {
                // Deliberately does not clear `isSaving`: this watcher runs before the render,
                // so clearing it here wiped the spinner for a save already in flight (unlock).
                this.setAutoSaveState({
                  isEditing: false
                });
              }
              return;
            }
            this.setAutoSaveState({
              isEditing: true
            });
            // Rates & Markups saves on field blur via QuoteRatesMarkups.vue (handleFieldBlur/handleRateBlur).
            // Annotations save on field blur via QuoteAnnotations.vue (handleAnnotationBlur).
            // All other non-builder routes (e.g. header panels) save on panel blur via queueHeaderAutosave.
          }
        }
      },
      deep: true
    },
    'entity.subQuoteNo': {
      handler: function () {
        var _handler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context) {
            while (1) switch (_context.n) {
              case 0:
                _context.n = 1;
                return this.getMainQuoteEntity();
              case 1:
                if (this.entityMainQuote && this.entity.subQuoteNo > 0) {
                  // update excessWithGst in the additional quote to match the value in the main quote
                  this.entity.excessWithGst = this.entityMainQuote.excessWithGst;
                }
              case 2:
                return _context.a(2);
            }
          }, _callee, this);
        }));
        function handler(_x, _x2) {
          return _handler.apply(this, arguments);
        }
        return handler;
      }()
    },
    labourTotal: function labourTotal(newVal, oldVal) {
      // console.log(this.previousQuoteId, newVal, oldVal, (newVal && !oldVal), (!newVal && oldVal))
      if (this.previousQuoteId !== '' && this.previousQuoteId !== this.entity.quoteId) {
        return;
      }
      // if ((newVal && !oldVal) || (!newVal && oldVal)) {
      //   console.log('labourTotal return')
      //   return
      // }
      if (!this.entity.readOnly && this.isRacq && !isNaN(oldVal)) {
        // RACQ Consumables percentage
        this.addUpdateRacqConsumable();
        this.addUpdateRepairPanelConsumable();
        this.addUpdatePaintConsumable();
        this.addUpdatePaintMaterial();
        this.addUpdateSetupColourMatch1();

        // just for paint items with OPG code
        // if (this.entity.labours.some((l) => l.opgCode !== null && l.opgCode !== '')) {
        this.addUpdateOpgPaintMaterials();
        this.addUpdateSetupColourMatch2();
        // }
        this.addUpdateM3PlusAllowances();
        this.showToast('NTAR consumables & paint material items updated', 'success', 'bottom');
        this.scheduleItemsSave();
      } else if (!this.entity.readOnly && this.isNtar && !isNaN(oldVal)) {
        // NTAR Consumables
        this.addUpdateRepairPanelConsumable();
        this.addUpdatePaintConsumable();
        this.addUpdatePaintMaterial();
        this.addUpdateSetupColourMatch1();
        this.addUpdateOpgPaintMaterials();
        this.addUpdateSetupColourMatch2();
        this.addUpdateM3PlusAllowances();
        this.showToast('NTAR consumables & paint material items updated', 'success', 'bottom');
        this.scheduleItemsSave();
      }
    },
    opgTotal: function opgTotal(newVal, oldVal) {
      // console.log('opgTotal', newVal, oldVal)
      if (this.previousQuoteId !== '' && this.previousQuoteId !== this.entity.quoteId) {
        return;
      }
      // if ((newVal && !oldVal) || (!newVal && oldVal)) {
      //   return
      // }
      if (!this.entity.readOnly && this.isRacq && !isNaN(oldVal)) {
        // RACQ Consumables percentage
        this.addUpdateRacqConsumable();
        this.scheduleItemsSave();
      } else if (!this.entity.readOnly && this.isNtar && !isNaN(oldVal)) {
        // console.log('opgTotal isNtar')
        this.addUpdatePaintConsumable();
        this.addUpdatePaintMaterial();
        this.addUpdateSetupColourMatch1();
        this.addUpdateOpgPaintMaterials();
        this.addUpdateSetupColourMatch2();
        this.addUpdateM3PlusAllowances();
        this.showToast('NTAR consumables & paint material items updated', 'success', 'bottom');
        this.scheduleItemsSave();
      }
    },
    weldHourTotal: function weldHourTotal(newVal, oldVal) {
      if (this.previousQuoteId !== '' && this.previousQuoteId !== this.entity.quoteId) {
        return;
      }
      // if ((newVal && !oldVal) || (!newVal && oldVal)) {
      //   return
      // }
      if (!this.entity.readOnly && (this.isEmta || this.isNtar) && !isNaN(oldVal)) {
        // eMTA R&R Welded Allowances
        this.addUpdateWeldAllowance();
        this.scheduleItemsSave();
      }
    },
    totalExGst: function totalExGst(newVal) {
      if (this.entity && !this.readOnlyView) {
        this.entity.totalExGst = newVal;
      }
    },
    totalIncGst: function totalIncGst(newVal) {
      if (this.entity && !this.readOnlyView) {
        this.entity.totalIncGst = newVal;
      }
    },
    showNewAdditional: function showNewAdditional(newVal) {
      if (newVal) {
        this.fabActions.splice(1, 0, {
          name: 'newAdditional',
          icon: 'plus-outline',
          color: '#c14747',
          tooltip: 'New Additional'
        });
      } else {
        this.fabActions = this.fabActions.filter(function (fabAction) {
          return fabAction.name !== 'newAdditional';
        });
      }
    },
    // showNewAdditional(newVal) {
    //   if (newVal) {
    //     this.fabActions.splice(1, 0, {
    //       name: 'newAdditional',
    //       icon: 'plus-outline',
    //       color: '#c14747',
    //       tooltip: 'New Additional'
    //     })
    //   } else {
    //     this.fabActions = this.fabActions.filter((fabAction) => fabAction.name !== 'newAdditional')
    //   }
    // },
    vehicle: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.saveVehicleSnapshot(this.vehicle);
          if (this.suppressHeaderAutosave) {
            // During refresh, just keep the baseline aligned.
            this.headerAutosaveBaseline.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.vehicle);
            return;
          }
        }
      },
      deep: true
    },
    customer: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.saveCustomerSnapshot(this.customer);
          this.vehicle.customer = {
            key: this.customer.id,
            value: this.customer.fullname
          };
          if (this.suppressHeaderAutosave) {
            // During refresh, just keep the baseline aligned.
            this.headerAutosaveBaseline.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.customer);
            return;
          }
        }
      },
      deep: true
    },
    insurer: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.saveInsurerSnapshot(this.insurer);
          if (this.suppressHeaderAutosave) {
            // During refresh, just keep the baseline aligned.
            this.headerAutosaveBaseline.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.insurer);
            return;
          }
        }
      },
      deep: true
    },
    isNtar: function isNtar(newVal) {
      if (this.entity && this.isNtar) {
        this.getNtarLoadingItems();
        this.getNtarOtherLoadingItems();
        this.getNtarLoadingValues();
      }
    },
    // change price parts return route based on if the user is in QuotePartsControl or QuoteSelections
    $route: function $route(to, from) {
      if (to.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePartsControl.name) {
        this.pricePartsReturnRoute = _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePartsControl.name;
      } else if (to.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name) {
        this.pricePartsReturnRoute = _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
      }
    },
    selectedMenu: function selectedMenu(newVal) {
      if (this.$refs.routerView && this.$refs.routerView.handleToggleAvaliableItems) {
        if (newVal === _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__["MENU_MODES"].MANUAL) {
          this.$refs.routerView.showQuoteItem();
        } else if (newVal === _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__["MENU_MODES"].TEMPLATES) {
          this.$refs.routerView.showTemplates();
        } else if (newVal === _components_QuoteBuilderSidebar_vue__WEBPACK_IMPORTED_MODULE_81__["MENU_MODES"].VEHICLE) {
          this.$refs.routerView.showQuoteBuilder();
        }
      }
    },
    'entity.jobStage': function entityJobStage(newVal, oldVal) {
      this.setInnerJobNSubJobStageCompositeKey();
    },
    'entity.subJobStage': function entitySubJobStage(newVal, oldVal) {
      this.setInnerJobNSubJobStageCompositeKey();
    }
  },
  // errorCaptured(err, vm, info) {
  //   console.log(err)
  // },
  created: function created() {
    var _this3 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee2() {
      var autoSaveHelper;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            // Initialize AutoSave Helper
            autoSaveHelper = Object(_helpers_QuoteAutoSaveHelper__WEBPACK_IMPORTED_MODULE_85__["createAutoSaveHelper"])(_this3);
            _this3.autoSaveHelper = autoSaveHelper;

            // Bind helper methods to this instance (overriding potential mixin conflicts or placeholders)
            _this3.autoSaveQuote = autoSaveHelper.autoSaveQuote;
            _this3.autoUpdateQuoteHeader = autoSaveHelper.autoUpdateQuoteHeader;
            _this3.scheduleItemsSave = autoSaveHelper.scheduleItemsSave;
            _this3.runItemsSave = autoSaveHelper.runItemsSave;
            _this3.hasPendingItemsSave = autoSaveHelper.hasPendingItemsSave;
            _this3.stopQuoteItemsEditDeferMonitor = autoSaveHelper.stopQuoteItemsEditDeferMonitor;
            _this3.queueHeaderAutosave = autoSaveHelper.queueHeaderAutosave;
            _this3.hasPendingAutoSaveWork = autoSaveHelper.hasPendingAutoSaveWork;
            _this3.hasPendingAutoSaveDiffs = autoSaveHelper.hasPendingAutoSaveDiffs;
            _this3.registerAutoSaveFailure = autoSaveHelper.registerAutoSaveFailure;
            _this3.resetAutoSaveFailures = autoSaveHelper.resetAutoSaveFailures;
            _this3.setAutoSaveState = autoSaveHelper.setAutoSaveState;
            _this3.isValidItemAutoSave = autoSaveHelper.isValidItemAutoSave;
            _this3.deleteEmptyLineItems = autoSaveHelper.deleteEmptyLineItems;
            _this3.saveQuoteAfterHeaderChangeNow = autoSaveHelper.saveQuoteAfterHeaderChangeNow;
            _this3.hasHeaderQuoteIdChanges = autoSaveHelper.hasHeaderQuoteIdChanges;
            _this3.autoSave = autoSaveHelper.autoSave;
            _this3.saveQuoteAndContinue = autoSaveHelper.saveQuoteAndContinue;
            _this3.hasEmptyLineItems = autoSaveHelper.hasEmptyLineItems;
            _this3.handleNavigationWarningConfirm = autoSaveHelper.handleNavigationWarningConfirm;
            _this3.handleNavigationWarningCancel = autoSaveHelper.handleNavigationWarningCancel;
            _this3.getExpandedQuoteItemId = autoSaveHelper.getExpandedQuoteItemId;
            _this3.getFocusedItemInfo = autoSaveHelper.getFocusedItemInfo;
            _this3.findItemIdByLineAndType = autoSaveHelper.findItemIdByLineAndType;
            _this3.saveLiteHeaderNow = autoSaveHelper.saveLiteHeaderNow;
            _this3.saveJobStageNow = autoSaveHelper.saveJobStageNow;
            _this3.saveReadOnlyNow = autoSaveHelper.saveReadOnlyNow;
            _this3.saveAssessmentEnabledNow = autoSaveHelper.saveAssessmentEnabledNow;
            _this3.debouncedSaveHeader = autoSaveHelper.debouncedSaveHeader;
            _this3.debouncedEntityRefresh = autoSaveHelper.debouncedEntityRefresh;

            // Non-reactive flag: set by debouncedEntityRefresh before replacing vm.entity so that
            // the entity watcher and item-array watchers can skip redundant work during refresh.
            _this3._isAutosaveRefreshing = false;

            // Performance throttle — the entity watcher fires on every keystroke; running a full cloneDeep +
            // Vuex mutation + snapshotDiff recomputation (4× DeepDiff) on each one is too expensive.
            // This batches rapid changes into a single snapshot update via a 300ms trailing delay.
            _this3._throttledSnapshotUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_58___default()(function () {
              _this3.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this3.entity));
            }, 300);
            _context2.n = 1;
            return _this3.getCompanyExternalSetting();
          case 1:
            _this3.getAudanetPnetSetting();
            // this.setupFabButtons()
            _this3.getStandardLabourItems();
            _context2.n = 2;
            return _this3.getEntity();
          case 2:
            _context2.n = 3;
            return _this3.getMainQuoteEntity();
          case 3:
            if (_this3.returnUrl) {
              _this3.persistQueries();
              _this3.replaceRoute(_this3.$route.params.quoteId);
            }
            _this3.getJobNSubJobStages();
            _context2.n = 4;
            return _this3.loadButterflySelections();
          case 4:
            _this3.setInnerJobNSubJobStageCompositeKey();
            _this3.setInitialQuoteCustomer();
          case 5:
            return _context2.a(2);
        }
      }, _callee2);
    }))();
  },
  mounted: function mounted() {
    var _this4 = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntityReload, /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee3() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            _context3.n = 1;
            return _this4.getEntity(true);
          case 1:
            _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntityReloaded);
          case 2:
            return _context3.a(2);
        }
      }, _callee3);
    })));
    // Image changes are already saved by the image endpoints, which also stamp the quote as
    // modified server-side. A full save here would send this window's whole copy of the quote,
    // and from an out-of-date window (e.g. the images pop-out) overwrite newer changes.
    this.$eventHub.$on("".concat(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ImageCountChanged, "UpdateQuote"), /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee4() {
      var imageIds;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            _context4.n = 1;
            return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getImageIds(_this4.entity.quoteId);
          case 1:
            imageIds = _context4.v;
            _this4.entity.imageIds = imageIds;
            // Rebase imageIds only, so the refreshed list doesn't read as an unsaved change.
            _this4.setBaseSnapshotFields({
              entity: {
                imageIds: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(imageIds)
              },
              fields: ['imageIds']
            });
            _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ImageCountChanged, imageIds.length);
          case 2:
            return _context4.a(2);
        }
      }, _callee4);
    })));
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ToggleSideMenu, this.handleToggleSideMenu);
    window.addEventListener('beforeunload', this.handleBeforeUnload);
    // Explicit save trigger for mutations the deep watchers can't catch (e.g. in-place sortNo).
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveQuoteItems, function () {
      _this4.$nextTick(function () {
        return _this4.scheduleItemsSave();
      });
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveRatesMarkupsStatus, /*#__PURE__*/function () {
      var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee5(status) {
        var _this4$currentSnapsho;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this4.setAutoSaveState(status);
              if (!(!status.isSaving && !status.isFailed)) {
                _context5.n = 2;
                break;
              }
              _context5.n = 1;
              return _this4.getLiteStoreItem(_this4.entity.quoteId);
            case 1:
              if ((_this4$currentSnapsho = _this4.currentSnapshot) !== null && _this4$currentSnapsho !== void 0 && _this4$currentSnapsho.modifiedDate) {
                _this4.entity.modifiedDate = _this4.currentSnapshot.modifiedDate;
              }
              _this4.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this4.entity));
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }));
      return function (_x3) {
        return _ref3.apply(this, arguments);
      };
    }());
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveAnnotationsStatus, /*#__PURE__*/function () {
      var _ref4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee6(status) {
        var _this4$currentSnapsho2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this4.setAutoSaveState(status);
              if (!(!status.isSaving && !status.isFailed)) {
                _context6.n = 2;
                break;
              }
              _context6.n = 1;
              return _this4.getLiteStoreItem(_this4.entity.quoteId);
            case 1:
              if ((_this4$currentSnapsho2 = _this4.currentSnapshot) !== null && _this4$currentSnapsho2 !== void 0 && _this4$currentSnapsho2.modifiedDate) {
                _this4.entity.modifiedDate = _this4.currentSnapshot.modifiedDate;
              }
              _this4.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this4.entity));
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }));
      return function (_x4) {
        return _ref4.apply(this, arguments);
      };
    }());
  },
  beforeDestroy: function beforeDestroy() {
    // Cancel any pending autosave operations
    if (this.autoUpdateQuoteHeader && typeof this.autoUpdateQuoteHeader.cancel === 'function') {
      this.autoUpdateQuoteHeader.cancel();
    }
    if (this.scheduleItemsSave && typeof this.scheduleItemsSave.cancel === 'function') {
      this.scheduleItemsSave.cancel();
    }
    if (this.debouncedSaveHeader && typeof this.debouncedSaveHeader.flush === 'function') {
      this.debouncedSaveHeader.flush();
    }
    if (this.debouncedEntityRefresh && typeof this.debouncedEntityRefresh.cancel === 'function') {
      this.debouncedEntityRefresh.cancel();
    }
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntityReload);
    if (lodash_isEmpty__WEBPACK_IMPORTED_MODULE_59___default()(this.returnRoute)) {
      this.setReadOnlyView(false);
    }
    this.$eventHub.$off("".concat(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ImageCountChanged, "UpdateQuote"));
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ToggleSideMenu, this.handleToggleSideMenu);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveQuoteItems);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveRatesMarkupsStatus);
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].AutoSaveAnnotationsStatus);
    window.removeEventListener('beforeunload', this.handleBeforeUnload);
    if (this.stopQuoteItemsEditDeferMonitor) {
      this.stopQuoteItemsEditDeferMonitor();
    }
  },
  methods: {
    toggleAutoSave: function toggleAutoSave() {
      // Autosave is disabled
    },
    // Warn before unload while an items save is still pending/in-flight.
    handleBeforeUnload: function handleBeforeUnload(e) {
      if (this.hasPendingItemsSave && this.hasPendingItemsSave()) {
        e.preventDefault();
        e.returnValue = '';
        return '';
      }
    },
    // PNET/AudaNet edits are entity-only (no vehicle/customer/insurer diffs), so
    // queueHeaderAutosave falls through to autoSaveQuote() — the same path claimNo and
    // the other entity-only header fields take. Deferred a tick because the entity
    // watcher has to commit the new snapshot before queueHeaderAutosave reads
    // snapshotDiff, otherwise the blur can be dropped as a no-op.
    onPnetComponentBlur: function onPnetComponentBlur() {
      var _this5 = this;
      this.$nextTick(function () {
        return _this5.queueHeaderAutosave();
      });
    },
    onRemarksSaveStateChange: function onRemarksSaveStateChange(isSaving) {
      if (this.setAutoSaveState) this.setAutoSaveState({
        isSaving: isSaving
      });
    },
    onRemarksSaved: function onRemarksSaved() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee7() {
        var _this6$currentSnapsho;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _context7.n = 1;
              return _this6.getLiteStoreItem(_this6.entity.quoteId);
            case 1:
              if ((_this6$currentSnapsho = _this6.currentSnapshot) !== null && _this6$currentSnapsho !== void 0 && _this6$currentSnapsho.modifiedDate) {
                _this6.entity.modifiedDate = _this6.currentSnapshot.modifiedDate;
              }
              // getLiteStoreItem resets both snapshots to the server-fetched storage entity.
              // The live entity may differ in client-only fields (e.g. isNew on new remarks).
              // Advancing both snapshots to match the live entity prevents the entity watcher
              // from detecting those differences as unsaved changes.
              _this6.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this6.entity));
              _this6.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this6.entity));
              _context7.n = 2;
              return _this6.$nextTick();
            case 2:
              if (!_this6.hasPendingAutoSaveDiffs()) {
                _this6.setAutoSaveState({
                  isEditing: false,
                  isSaving: false
                });
              }
            case 3:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    handleManualSaveRequest: function handleManualSaveRequest() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee8() {
        var saved;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              try {
                _sentry_vue__WEBPACK_IMPORTED_MODULE_89__["captureMessage"]('Manual save button clicked (autosave on)', {
                  level: 'info',
                  tags: {
                    feature: 'autosave',
                    action: 'manual_save_click'
                  },
                  extra: {
                    autoSaveEnabled: _this7.autoSaveEnabled,
                    isSaving: _this7.autoSaveStatus.isSaving,
                    isEditing: _this7.autoSaveStatus.isEditing,
                    unsavedChanges: _this7.autoSaveStatus.isDiffChanged,
                    isFailed: _this7.autoSaveStatus.isFailed,
                    failMessage: _this7.autoSaveStatus.failMessage,
                    autoSaveFailureCount: _this7.autoSaveFailureCount,
                    quoteSaveStatus: _this7.quoteSaveStatus,
                    quoteId: _this7.entity && _this7.entity.quoteId,
                    quoteNo: _this7.quoteNoRef,
                    // Pending changes at the moment manual save was used (deep-diffs as JSON strings).
                    // Tells us what autosave had not persisted yet.
                    snapshotDiff: stringifyDiff(_this7.snapshotDiff),
                    snapshotDiffCustomer: stringifyDiff(_this7.snapshotDiffCustomer),
                    snapshotDiffVehicle: stringifyDiff(_this7.snapshotDiffVehicle),
                    snapshotDiffInsurer: stringifyDiff(_this7.snapshotDiffInsurer)
                  }
                });
              } catch (telemetryError) {
                console.error('Failed to report manual save to Sentry:', telemetryError);
              }
              if (!_this7.autoSaveStatus.isSaving) {
                _context8.n = 1;
                break;
              }
              return _context8.a(2);
            case 1:
              _context8.n = 2;
              return _this7.save(false, true, false, true);
            case 2:
              saved = _context8.v;
              if (saved) {
                _this7.resetAutoSaveFailures();
                _this7.setAutoSaveState({
                  isFailed: false,
                  isEditing: false
                });
              }
            case 3:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    getDerivedItemGuard: function getDerivedItemGuard() {
      var _this8 = this;
      return {
        shouldSkipWatcher: function shouldSkipWatcher() {
          return _this8.derivedItemUpdateDepth > 0;
        },
        run: function run(callback) {
          _this8.derivedItemUpdateDepth += 1;
          try {
            return typeof callback === 'function' ? callback() : undefined;
          } finally {
            _this8.derivedItemUpdateDepth = Math.max(0, _this8.derivedItemUpdateDepth - 1);
          }
        }
      };
    },
    getSupplementaryQuotes: function getSupplementaryQuotes() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _context9.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getSupplementaryQuoteTotals(_this9.$route.params.quoteId);
            case 1:
              _this9.supplementaryQuotes = _context9.v;
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    calculateTotalPayableIncGst: function calculateTotalPayableIncGst() {
      var _this$entity$excess, _this$entity$discount;
      var grandTotal = this.entity.subQuoteNos.length > 1 ? this.calculateGrandTotal(this.entity.totalExGst, (this.supplementaryQuotes || []).map(function (q) {
        return q.totalExGst;
      })) : this.entity.totalExGst;
      var excess = (_this$entity$excess = this.entity.excess) !== null && _this$entity$excess !== void 0 ? _this$entity$excess : 0;
      var discount = (_this$entity$discount = this.entity.discount) !== null && _this$entity$discount !== void 0 ? _this$entity$discount : 0;
      var invTotalExGst = !this.entity.excessWithGst ? grandTotal - discount : grandTotal - (excess + discount);
      var total = invTotalExGst * (this.entity.gstRate / 100 + 1);
      var ownerContributionWithGST = this.entity.ownersContribution * (this.entity.gstRate / 100 + 1);
      var totalPayableIncGst = this.entity.excessWithGst ? total - ownerContributionWithGST : total - this.entity.excess - ownerContributionWithGST;
      return totalPayableIncGst;
    },
    calculateGrandTotal: function calculateGrandTotal(mainCategorytotal, supplementaryCategoryTotalsArray) {
      var suppCategoryTotal = supplementaryCategoryTotalsArray.reduce(function (total, suppTotal) {
        return total + suppTotal;
      }, 0);
      return mainCategorytotal + suppCategoryTotal;
    },
    handleToggleSideMenu: function handleToggleSideMenu(val) {
      this.showHorizontalMenu = !this.showHorizontalMenu;
    },
    formatJobStage: function formatJobStage(value) {
      if (value.toLowerCase() === 'none') {
        return '-- Job Stage --';
      } else {
        return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
          return str.toUpperCase();
        });
      }
    },
    displayJobStage: function displayJobStage(jobNSubJobStage) {
      var hasSubJobStage = !!jobNSubJobStage.subJobStageId;
      var name = hasSubJobStage ? jobNSubJobStage.subJobStageName || jobNSubJobStage.compositeName : jobNSubJobStage.compositeName;
      if (name.toLowerCase() === '' || name == null) {
        return hasSubJobStage ? '-- Sub Job Stage --' : '-- Job Stage --';
      } else {
        name = this.formatJobStage(name);
      }
      return hasSubJobStage ? "   ".concat(name) : name;
    },
    handleJobNSubJobStageChanged: function handleJobNSubJobStageChanged() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee0() {
        var _this0$innerJobNSubJo, _this0$innerJobNSubJo2, jobStageId, subJobStageId;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              if (!_this0.$licenceExpired) {
                _context0.n = 1;
                break;
              }
              return _context0.a(2);
            case 1:
              if (_this0.innerJobNSubJobStageCompositeKey) {
                _context0.n = 2;
                break;
              }
              return _context0.a(2);
            case 2:
              _this0$innerJobNSubJo = _this0.innerJobNSubJobStageCompositeKey.split('|'), _this0$innerJobNSubJo2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_this0$innerJobNSubJo, 2), jobStageId = _this0$innerJobNSubJo2[0], subJobStageId = _this0$innerJobNSubJo2[1];
              _this0.entity.jobStage = parseInt(jobStageId);
              _this0.entity.subJobStage = subJobStageId || '';
              _context0.n = 3;
              return _this0.saveJobStageNow();
            case 3:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    getUnreadOrmMessageCount: function getUnreadOrmMessageCount() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee1() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (_this1.entity.orm) {
                _context1.n = 1;
                break;
              }
              return _context1.a(2);
            case 1:
              _context1.n = 2;
              return _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_80__["default"].unreadMessageCount(_this1.entity.quoteId);
            case 2:
              _this1.ormUnreadMessageCount = _context1.v;
            case 3:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    // this function is called when the user changes the default paint group in the header
    updateQuoteItemsDefaultPaintGroup: function updateQuoteItemsDefaultPaintGroup(val, oldVal) {
      var _this10 = this;
      var itemsToChange = this.entity.labours.filter(function (l) {
        return l.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && (l.opgCode == null || l.opgCode == '' || l.opgCode == oldVal);
      });
      // we get ids of items that are already authorised (paint items) and get their quoteItemId
      var authorisedItemsId = [];
      var submittedItemsId = [];
      this.entity.quoteAssessments.forEach(function (assessment) {
        var _assessment$authorise, _assessment$submitted;
        if (!!(assessment !== null && assessment !== void 0 && assessment.isAuthorised) && !!(assessment !== null && assessment !== void 0 && (_assessment$authorise = assessment.authorisedAssessment) !== null && _assessment$authorise !== void 0 && (_assessment$authorise = _assessment$authorise.assessmentQuoteItems) !== null && _assessment$authorise !== void 0 && _assessment$authorise.length)) {
          assessment.authorisedAssessment.assessmentQuoteItems.forEach(function (item) {
            if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && (item.opgCode == null || item.opgCode == '' || item.opgCode == oldVal)) {
              authorisedItemsId.push(item.quoteItemId);
            }
          });
        }
        if (!!(assessment !== null && assessment !== void 0 && (_assessment$submitted = assessment.submittedAssessment) !== null && _assessment$submitted !== void 0 && (_assessment$submitted = _assessment$submitted.assessmentQuoteItems) !== null && _assessment$submitted !== void 0 && _assessment$submitted.length)) {
          assessment.submittedAssessment.assessmentQuoteItems.forEach(function (item) {
            submittedItemsId.push(item.quoteItemId);
          });
        }
      });
      itemsToChange.forEach(function (item) {
        // if item is already authorised, do not change it
        if (!authorisedItemsId.includes(item.quoteItemId) && !submittedItemsId.includes(item.quoteItemId)) {
          item.opgCode = val;
        }
      });
      this.$nextTick(function () {
        _this10.onOpgCodeChanged();
      });
    },
    onPrintInvoice: function onPrintInvoice() {
      this.onHeaderButtonClicked(_enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Print);
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      var _this11 = this;
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Print:
          console.log(this.snapshotDiff);
          if (this.snapshotDiff) {
            this.$unSavedModal.open({
              skipDisabled: true,
              onSkipSave: function onSkipSave() {},
              onCancel: function onCancel() {},
              onSaveContinue: function () {
                var _onSaveContinue = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee10() {
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context10) {
                    while (1) switch (_context10.n) {
                      case 0:
                        _context10.n = 1;
                        return _this11.save();
                      case 1:
                        _this11.onHeaderButtonClicked(_enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Print);
                      case 2:
                        return _context10.a(2);
                    }
                  }, _callee10);
                }));
                function onSaveContinue() {
                  return _onSaveContinue.apply(this, arguments);
                }
                return onSaveContinue;
              }()
            });
            return;
          }
          if (this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteInvoice.name) {
            // Print invoice
            if (this.invoice) {
              // print Malaysia invoice
              if (this.$company.info.countryCode === 'MY') {
                this.printMyInvoice();
              } else {
                this.isInvoicePrintOptionsActive = true;
              }
            } else {
              // this.$toast.open({
              //   message: 'Nothing to print. Please create invoice first',
              //   type: 'is-danger'
              // })
              this.$notification.error('', 'Nothing to print. Please create invoice first');
            }
          } else if (this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteExcessInvoice.name) {
            // Print excess invoice
            if (this.excessInvoice) {
              this.printExcessInvoice();
            } else {
              // this.$toast.open({
              //   message: 'Nothing to print. Please create excess invoice first',
              //   type: 'is-danger'
              // })
              this.$notification.error('', 'Nothing to print. Please create excess invoice first');
            }
            if (!this.entity.excessWithGst && this.ocInvoice) {
              this.printOcInvoice();
            }
          } else {
            this.isPrintOptionsActive = true;
          }
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Delete:
          this.isConfirmModalActive = true;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Lock:
          this.toggleReadOnly();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].PriceParts:
          this.viewPartsCheckRequest();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].PreApplyQuoteTemplateCheck:
          this.checkBeforeQuoteTemplateApplication();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].ApplyQuoteTemplate:
          this.applyQuoteTemplate();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Calendar:
          this.$router.push(_views_booking_route_types__WEBPACK_IMPORTED_MODULE_78__["default"].CalendarView.path);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].NewAdditionalQuote:
          this.newAdditional();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].CopyQuote:
          this.showCopyQuoteModal();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].ExportQuote:
          this.exportQuote();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].Restore:
          this.restoreQuote();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_55__["AppHeaderButtonTypes"].EnableAssessmentHistory:
          this.toggleAssessmentHistory();
          break;
      }
    },
    restoreQuote: function restoreQuote() {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee11() {
        var quoteRef, _yield$QuoteService$i, exists, isOrphanSuppRestore, isMainRestore, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context11) {
          while (1) switch (_context11.p = _context11.n) {
            case 0:
              if (!_this12.$licenceExpired) {
                _context11.n = 1;
                break;
              }
              return _context11.a(2);
            case 1:
              quoteRef = "".concat(_this12.entity.prefix).concat(_this12.entity.quoteNo).concat(_this12.entity.suffix) + (_this12.entity.subQuoteNo === 0 ? '' : "/".concat(_this12.entity.subQuoteNo));
              _context11.p = 2;
              _context11.n = 3;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].isQuoteNoExists(quoteRef);
            case 3:
              _yield$QuoteService$i = _context11.v;
              exists = _yield$QuoteService$i.data;
              if (!exists) {
                _context11.n = 4;
                break;
              }
              _this12.$notification.openNotificationWithType('danger', 'Restore Quote', "Cannot restore: an active quote with the same number \"".concat(quoteRef, "\" already exists."));
              return _context11.a(2);
            case 4:
              _context11.n = 6;
              break;
            case 5:
              _context11.p = 5;
              _t = _context11.v;
              console.log(_t);
            case 6:
              isOrphanSuppRestore = _this12.entity.subQuoteNo > 0 && _this12.entityMainQuote && _this12.entityMainQuote.deleted;
              isMainRestore = _this12.entity.subQuoteNo === 0;
              if (!(isOrphanSuppRestore || isMainRestore)) {
                _context11.n = 7;
                break;
              }
              _this12.isRestoreAllConfirmModalActive = true;
              return _context11.a(2);
            case 7:
              _this12.entity.deleted = false;
            case 8:
              return _context11.a(2);
          }
        }, _callee11, null, [[2, 5]]);
      }))();
    },
    confirmRestoreAll: function confirmRestoreAll(confirm) {
      if (this.$licenceExpired) return;
      this.isRestoreAllConfirmModalActive = false;
      if (confirm) {
        this.entity.deleted = false;
      }
    },
    toggleAssessmentHistory: function toggleAssessmentHistory() {
      if (this.$licenceExpired) return;
      this.entity.isAssessmentEnabled = !this.entity.isAssessmentEnabled;
      this.saveAssessmentEnabledNow();
      if (this.$route.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].AuthoriseView.name) {
        if (!this.entity.isAssessmentEnabled) {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteHeader.name,
            params: {
              quoteId: this.$route.params.quoteId
            },
            query: this.$route.query
          });
        }
      }
    },
    checkBeforeQuoteTemplateApplication: function checkBeforeQuoteTemplateApplication() {
      this.quoteTemplateDisabled = this.validateError;
    },
    applyQuoteTemplate: function applyQuoteTemplate() {
      this.isQuoteTemplateModalActive = true;
    },
    hideHeaderButtons: function hideHeaderButtons(isHide) {
      this.isHeaderButtonHided = isHide;
    },
    // targetQuoteId: pass the destination quote id when calling from a navigation guard —
    // inside beforeRouteUpdate the navigation is not yet confirmed, so this.$route still
    // points to the OLD route and must not be used to decide which quote to load.
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this13 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee12() {
        var reset, silent, targetQuoteId, routeQuoteId, snapshotMatchesRoute, updateSource, isCopyImages;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              silent = _arguments.length > 1 && _arguments[1] !== undefined ? _arguments[1] : false;
              targetQuoteId = _arguments.length > 2 && _arguments[2] !== undefined ? _arguments[2] : null;
              if (!silent) _this13.$showSpinner();
              _this13.isLoading = true;
              routeQuoteId = targetQuoteId || _this13.$route.params.quoteId;
              if (reset) {
                _this13.clearSessionStorage();
                _this13.clearSnapshots(routeQuoteId);
                _this13.clearHeaders();
                _this13.clearInvoiceState();
              }
              // Load when there is no cached snapshot, OR when the cached snapshot belongs to a
              // different quote than the one being routed to. The snapshot store is a single global
              // slot, so a stale snapshot from a previously-viewed quote (e.g. resurrected by a
              // late autosave/refresh) would otherwise be cloned here, showing the wrong quote.
              snapshotMatchesRoute = _this13.currentSnapshot && String(_this13.currentSnapshot.quoteId).toLowerCase() === String(routeQuoteId).toLowerCase();
              if (snapshotMatchesRoute) {
                _context12.n = 1;
                break;
              }
              _context12.n = 1;
              return _this13.getStoreItem(routeQuoteId);
            case 1:
              _this13.entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this13.currentSnapshot);

              //Show update notificatin
              if (_this13.entity.doesQuoteAutoUpdated) {
                updateSource = '';
                if (_this13.entity.audatex) {
                  updateSource = 'AudaNet/AudaBridge';
                }
                _this13.$notification.openNotificationWithType('success', '', "Quote updated from ".concat(updateSource, "."), 5000);
              }

              // Reset isCopyQuote to trigger unsaved changes modal
              if (_this13.entity.isCopyQuote) {
                isCopyImages = _this13.entity.copyImageQuoteId !== _components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].empty();
                _this13.entity.isCopyQuote = false;
                if (_this13.autoSaveActiveForQuote) {
                  // With autosave on the copy is persisted automatically, so don't prompt to save.
                  // Persist + fully reload (see saveCopiedQuoteWithAutosave) so all server-synced state
                  // (real item ids, copied images, assessments) is correctly set.
                  _this13.$notification.openNotificationWithType('success', '', "Copy quote successful.".concat(isCopyImages ? ' Images will appear shortly.' : ''), 5000);
                  // Defer to a macrotask so the persist+reload runs after this getEntity call returns,
                  // avoiding re-entrancy into getEntity from within itself.
                  setTimeout(function () {
                    return _this13.saveCopiedQuoteWithAutosave();
                  }, 0);
                } else {
                  _this13.$notification.openNotificationWithType('success', '', "Copy quote successful. Please remember to save quote.".concat(isCopyImages ? ' Images will appear after saving quote.' : ''), 5000);
                }
              }
              if (_this13.isNtar || _this13.Emta) {
                _this13.getNtarLoadingItems();
                _this13.getNtarOtherLoadingItems();
                _this13.getNtarLoadingValues();
              }
              // this.setAudaNetLock(this.entity.isAudaNet && !this.$user.info.isSupportUser && !this.$user.info.isCustomerAdministrator)
              // if (!this.entity.isNew) {
              //   // Get and store vehicle in vuex store quotes/quoteVehicle
              //   this.getQuoteVehicle(this.entity.vehicleId)
              //   // Get and store vehicle in vuex store quotes/quoteCustomer
              //   this.getQuoteCustomer(this.entity.customerId)

              // this.$resetSpinner()
              _context12.n = 2;
              return _this13.getQuoteAssests();
            case 2:
              if (!_this13.entity.orm) {
                _context12.n = 4;
                break;
              }
              _context12.n = 3;
              return _this13.getOrmUnreadPaymentAuthorisedMessage();
            case 3:
              _this13.getUnreadOrmMessageCount();
            case 4:
              // ORM-specific validation must fire only when the user submits the quote
              // at the ORM page (Send Quote / Send Tax Invoice in QuoteOrm.vue). It is
              // intentionally NOT touched on load so opening an existing ORM quote does
              // not surface ORM errors or block normal Save/autosave.

              if (!silent) _this13.$resetSpinner();
              _this13.isLoading = false;
            case 5:
              return _context12.a(2);
          }
        }, _callee12);
      }))();
    },
    getOrmUnreadPaymentAuthorisedMessage: function getOrmUnreadPaymentAuthorisedMessage() {
      var _this14 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee13() {
        var currentMessageNo, expectedMessageNo, messages, latestMessage, _this14$$notification, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context13) {
          while (1) switch (_context13.p = _context13.n) {
            case 0:
              _context13.p = 0;
              currentMessageNo = parseInt(_this14.entity.orm.messageNo, 10) || 0;
              expectedMessageNo = currentMessageNo + 1;
              _context13.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_54__["OrmService"].getMessages(_this14.entity.claimNo, _this14.entity.vehicleRego, _enums__WEBPACK_IMPORTED_MODULE_55__["MessageTypes"].QML_PaymentAuthorised);
            case 1:
              messages = _context13.v;
              if (!(!messages || messages.length === 0)) {
                _context13.n = 2;
                break;
              }
              return _context13.a(2);
            case 2:
              latestMessage = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(messages).sort(function (a, b) {
                return b.ormMessageNo - a.ormMessageNo;
              })[0];
              console.log('expectedMessageNo:', expectedMessageNo, latestMessage);
              if (!(latestMessage && expectedMessageNo === latestMessage.ormMessageNo && latestMessage.statusId === 30)) {
                _context13.n = 5;
                break;
              }
              _context13.n = 3;
              return _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_80__["default"].loadMessage({
                messageId: latestMessage.messageId,
                messageTypeId: latestMessage.messageTypeId,
                quoteId: _this14.entity.quoteId
              });
            case 3:
              // Reload the page data to reflect the updated ORM status
              console.log('ORM message loaded successfully, refreshing entity data...');
              _context13.n = 4;
              return _this14.getEntity(true);
            case 4:
              (_this14$$notification = _this14.$notification) === null || _this14$$notification === void 0 || _this14$$notification.success('ORM Message', 'Payment authorised message loaded successfully');
            case 5:
              _context13.n = 7;
              break;
            case 6:
              _context13.p = 6;
              _t2 = _context13.v;
              console.error('Failed to load ORM payment authorised message:', _t2);
            case 7:
              return _context13.a(2);
          }
        }, _callee13, null, [[0, 6]]);
      }))();
    },
    getQuoteAssests: function getQuoteAssests() {
      var _arguments2 = arguments,
        _this15 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee14() {
        var isNew, _this15$insurer, promises;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context14) {
          while (1) switch (_context14.n) {
            case 0:
              isNew = _arguments2.length > 0 && _arguments2[0] !== undefined ? _arguments2[0] : false;
              if (!_this15.entity.isNew) {
                _context14.n = 2;
                break;
              }
              _context14.n = 1;
              return Promise.all([_this15.getNewVehicle(), _this15.getNewCustomer(), _this15.getNewInsurer()]);
            case 1:
              _this15.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentVehicleSnapshot);
              _this15.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentCustomerSnapshot);
              _this15.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentInsurerSnapshot);

              // Ensure IDs are linked if they were missing (and we generated new ones)
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.vehicleId) && _this15.vehicle) {
                _this15.entity.vehicleId = _this15.vehicle.id;
              }
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.customerId) && _this15.customer) {
                _this15.entity.customerId = _this15.customer.id;
              }

              // Establish baseline for header autosave diffs
              _this15.headerAutosaveBaseline.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.vehicle);
              _this15.headerAutosaveBaseline.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.customer);
              _this15.headerAutosaveBaseline.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.insurer);
              _this15.entity.vehicleId = _this15.quoteVehicle.id;
              _this15.entity.customerId = _this15.quoteCustomer.id;
              _this15.entity.insurerId = _this15.quoteInsurer.insurerId;
              _this15.entity.driveable = _this15.$company.setting.driveableDefault;
              _this15.entity.jobStage = _enums__WEBPACK_IMPORTED_MODULE_55__["JobStageTypes"].ToBeQuoted;
              _this15.entity.quoteAssessments = [];
              _context14.n = 4;
              break;
            case 2:
              promises = [];
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.vehicleId)) {
                // Get and store vehicle in vuex store quotes/quoteVehicle
                promises.splice(promises.length, 1, _this15.getQuoteVehicle({
                  id: _this15.entity.vehicleId,
                  refresh: true
                }));
                // this.getQuoteVehicle({ id: this.entity.vehicleId, refresh: reset })
              } else {
                promises.splice(promises.length, 1, _this15.getNewVehicle());
              }
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.customerId)) {
                // Get and store vehicle in vuex store quotes/quoteVehicle
                promises.splice(promises.length, 1, _this15.getQuoteCustomer({
                  id: _this15.entity.customerId,
                  refresh: true
                }));
                // this.getQuoteCustomer({ id: this.entity.customerId, refresh: reset })
              } else {
                promises.splice(promises.length, 1, _this15.getNewCustomer());
              }
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.insurerId)) {
                promises.splice(promises.length, 1, _this15.getQuoteInsurer({
                  id: _this15.entity.insurerId,
                  refresh: true
                }));
              } else {
                //  the insurerId is not valid guid, get a new insurer, when quote is made using PWA app and insurer is left blank.
                promises.splice(promises.length, 1, _this15.getNewInsurer());
              }
              _context14.n = 3;
              return Promise.all(promises);
            case 3:
              console.log('getEntity Promise.all');
              _this15.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentVehicleSnapshot);
              if (_this15.vehicle) _this15.vehicle.isNew = false;
              _this15.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentCustomerSnapshot);
              _this15.vehicle.customer = {
                key: _this15.customer.id,
                value: _this15.customer.fullname
              };
              _this15.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.currentInsurerSnapshot);

              // The customer link + isNew normalization above is applied to the live vehicle
              // only (which the watcher mirrors into currentVehicleSnapshot). Quotes created
              // from the ORM feed store the vehicle without this customer link, so the baseline
              // (quoteVehicle) would otherwise diverge and the quote shows unsaved changes on
              // load. Realign the baseline to the normalized vehicle so the display-only link
              // is not counted as an edit; genuine user edits afterwards still register.
              _this15.setQuoteVehicle(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.vehicle));

              // Ensure IDs are linked if they were missing (and we generated new ones)
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.vehicleId) && _this15.vehicle) {
                _this15.entity.vehicleId = _this15.vehicle.id;
              }
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(_this15.entity.customerId) && _this15.customer) {
                _this15.entity.customerId = _this15.customer.id;
              }

              // Establish baseline for header autosave diffs
              _this15.headerAutosaveBaseline.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.vehicle);
              _this15.headerAutosaveBaseline.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.customer);
              _this15.headerAutosaveBaseline.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this15.insurer);
              _this15.setInitialQuoteCustomer();
              console.log("".concat(_this15.$options.name, " - ").concat(_this15.vehicle.modifiedDate));
              console.log("".concat(_this15.$options.name, " - ").concat(_this15.customer.modifiedDate));
              console.log("".concat(_this15.$options.name, " - ").concat((_this15$insurer = _this15.insurer) === null || _this15$insurer === void 0 ? void 0 : _this15$insurer.modifiedDate));
            case 4:
              return _context14.a(2);
          }
        }, _callee14);
      }))();
    },
    getMainQuoteEntity: function getMainQuoteEntity() {
      var _this16 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee15() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context15) {
          while (1) switch (_context15.n) {
            case 0:
              if (!(_this16.entity && _this16.entity.subQuoteNo > 0)) {
                _context15.n = 2;
                break;
              }
              _context15.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getMainQuoteEntity("".concat(_this16.entity.prefix).concat(_this16.entity.quoteNo).concat(_this16.entity.suffix));
            case 1:
              _this16.entityMainQuote = _context15.v;
              _context15.n = 3;
              break;
            case 2:
              _this16.entityMainQuote = null;
            case 3:
              return _context15.a(2);
          }
        }, _callee15);
      }))();
    },
    // savedAssets records which header assets reached the database, so a failed save can reload them (PCK-153)
    saveQuoteAssets: function saveQuoteAssets() {
      var _arguments3 = arguments,
        _this17 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee16() {
        var isNew, savedAssets, promises, results, failed, _e$response, msg, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context16) {
          while (1) switch (_context16.p = _context16.n) {
            case 0:
              isNew = _arguments3.length > 0 && _arguments3[0] !== undefined ? _arguments3[0] : false;
              savedAssets = _arguments3.length > 1 && _arguments3[1] !== undefined ? _arguments3[1] : {};
              promises = [];
              _context16.p = 1;
              if (!_this17.customer.isNew) {
                _context16.n = 3;
                break;
              }
              // promises.splice(promises.length, 1, CustomerService.postCustomer(this.customer))
              console.log(_this17.customer);
              _this17.assignMissingCustomerItemIds();
              _context16.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_54__["CustomerService"].postCustomer(_this17.customer);
            case 2:
              savedAssets.customer = true;
              _this17.setCustomerState(false);
              _this17.setInitialQuoteCustomer();
              _this17.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              _context16.n = 5;
              break;
            case 3:
              if (!_this17.snapshotDiffCustomer) {
                _context16.n = 5;
                break;
              }
              _context16.n = 4;
              return _services__WEBPACK_IMPORTED_MODULE_54__["CustomerService"].putCustomer(_this17.customer, _this17.snapshotDiffCustomer);
            case 4:
              savedAssets.customer = true;
            case 5:
              // Mark each asset saved as soon as its own request succeeds. Waiting for all of them left a
              // saved vehicle as isNew when the insurer failed, and the retry POSTed it again (PCK-153)
              if (_this17.vehicle.isNew) {
                promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_54__["VehicleService"].postEntity(_this17.vehicle).then(function () {
                  _this17.vehicle.isNew = false;
                  savedAssets.vehicle = true;
                }));
              } else if (_this17.snapshotDiffVehicle) {
                _this17.vehicle.excludeQuoteId = _this17.entity.quoteId;
                promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_54__["VehicleService"].putEntity(_this17.vehicle, _this17.snapshotDiffVehicle, true).then(function () {
                  savedAssets.vehicle = true;
                }));
              }
              if (_this17.insurer.isNew) {
                promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_54__["InsurerService"].postInsurer(_this17.insurer).then(function () {
                  _this17.insurer.isNew = false;
                  savedAssets.insurer = true;
                }));
              } else if (_this17.snapshotDiffInsurer) {
                promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_54__["InsurerService"].putInsurer(_this17.insurer, _this17.snapshotDiffInsurer, true).then(function () {
                  savedAssets.insurer = true;
                }));
              }
              if (!(promises.length > 0)) {
                _context16.n = 7;
                break;
              }
              _context16.n = 6;
              return Promise.allSettled(promises);
            case 6:
              results = _context16.v;
              failed = results.find(function (r) {
                return r.status === 'rejected';
              });
              if (!failed) {
                _context16.n = 7;
                break;
              }
              throw failed.reason;
            case 7:
              return _context16.a(2, true);
            case 8:
              _context16.p = 8;
              _t3 = _context16.v;
              _this17.customerSaveAction = '';
              msg = ((_e$response = _t3.response) === null || _e$response === void 0 || (_e$response = _e$response.data) === null || _e$response === void 0 ? void 0 : _e$response.message) || _t3.message;
              _this17.$notification.openNotificationWithType('danger', 'Quote Assets', msg);
              reportSaveFailure(_t3, 'quote-assets', {
                quoteId: _this17.entity && _this17.entity.quoteId,
                isNewQuote: isNew,
                savedAssets: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_6__["default"])({}, savedAssets)
              });
              _context16.n = 9;
              return _this17.refreshSavedQuoteAssets(savedAssets);
            case 9:
              return _context16.a(2, false);
          }
        }, _callee16, null, [[1, 8]]);
      }))();
    },
    // A failed save can leave some header assets saved and others not. Reload the saved ones so the
    // local copies, their ids, ModifiedDate and the diff baselines match the database, otherwise the
    // retry PUTs stale data and fails (NRE on unknown ids, or 409 from AssertModified) (PCK-153)
    refreshSavedQuoteAssets: function refreshSavedQuoteAssets() {
      var _arguments4 = arguments,
        _this18 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee18() {
        var savedAssets, reload, _yield$Promise$all, _yield$Promise$all2, customerReloaded, vehicleReloaded, insurerReloaded;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context18) {
          while (1) switch (_context18.n) {
            case 0:
              savedAssets = _arguments4.length > 0 && _arguments4[0] !== undefined ? _arguments4[0] : {};
              reload = /*#__PURE__*/function () {
                var _ref5 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee17(isSaved, fetch) {
                  var _t4;
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context17) {
                    while (1) switch (_context17.p = _context17.n) {
                      case 0:
                        if (isSaved) {
                          _context17.n = 1;
                          break;
                        }
                        return _context17.a(2, false);
                      case 1:
                        _context17.p = 1;
                        _context17.n = 2;
                        return fetch();
                      case 2:
                        return _context17.a(2, true);
                      case 3:
                        _context17.p = 3;
                        _t4 = _context17.v;
                        console.error('Failed to reload saved quote asset:', _t4);
                        return _context17.a(2, false);
                    }
                  }, _callee17, null, [[1, 3]]);
                }));
                return function reload(_x5, _x6) {
                  return _ref5.apply(this, arguments);
                };
              }();
              _context18.n = 1;
              return Promise.all([reload(savedAssets.customer, function () {
                return _this18.getQuoteCustomer({
                  id: _this18.customer.id,
                  refresh: true
                });
              }), reload(savedAssets.vehicle, function () {
                return _this18.getQuoteVehicle({
                  id: _this18.vehicle.id,
                  refresh: true
                });
              }), reload(savedAssets.insurer, function () {
                return _this18.getQuoteInsurer({
                  id: _this18.insurer.insurerId,
                  refresh: true
                });
              })]);
            case 1:
              _yield$Promise$all = _context18.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_yield$Promise$all, 3);
              customerReloaded = _yield$Promise$all2[0];
              vehicleReloaded = _yield$Promise$all2[1];
              insurerReloaded = _yield$Promise$all2[2];
              // Same normalisation as getEntity()
              if (customerReloaded) {
                _this18.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.currentCustomerSnapshot);
                _this18.setInitialQuoteCustomer();
                _this18.headerAutosaveBaseline.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.customer);
              }
              if (vehicleReloaded) {
                _this18.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.currentVehicleSnapshot);
                _this18.vehicle.isNew = false;
              }
              if (customerReloaded || vehicleReloaded) {
                _this18.vehicle.customer = {
                  key: _this18.customer.id,
                  value: _this18.customer.fullname
                };
              }
              if (vehicleReloaded) {
                _this18.setQuoteVehicle(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.vehicle));
                _this18.headerAutosaveBaseline.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.vehicle);
              }
              if (insurerReloaded) {
                _this18.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.currentInsurerSnapshot);
                _this18.headerAutosaveBaseline.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this18.insurer);
              }

              // The header panels hold their own clones and only re-clone on EntitySaved. Without this the
              // next edit pushes the pre-reload copy (stale ids) back over the reloaded one (PCK-153).
              // Wait a tick so the panels receive the reloaded objects as props before they re-clone.
              if (!(customerReloaded || vehicleReloaded || insurerReloaded)) {
                _context18.n = 3;
                break;
              }
              _context18.n = 2;
              return _this18.$nextTick();
            case 2:
              _this18.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
            case 3:
              return _context18.a(2);
          }
        }, _callee18);
      }))();
    },
    save: function save() {
      var _arguments5 = arguments,
        _this19 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee19() {
        var isDelete, showNoChangeMessage, routeToPriceParts, showSpinner, title, savedAssets, response, isCustomerInfoChanged, isSuccess, _isSuccess, attachments, count, _t5;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context19) {
          while (1) switch (_context19.p = _context19.n) {
            case 0:
              isDelete = _arguments5.length > 0 && _arguments5[0] !== undefined ? _arguments5[0] : false;
              showNoChangeMessage = _arguments5.length > 1 && _arguments5[1] !== undefined ? _arguments5[1] : true;
              routeToPriceParts = _arguments5.length > 2 && _arguments5[2] !== undefined ? _arguments5[2] : false;
              showSpinner = _arguments5.length > 3 && _arguments5[3] !== undefined ? _arguments5[3] : true;
              if (!_this19.$licenceExpired) {
                _context19.n = 1;
                break;
              }
              return _context19.a(2, false);
            case 1:
              // check and delete empty line items
              // that were just added
              _this19.purgeNewEmptyLineItems();
              title = 'Repairer Quote';
              if (!_this19.validateError) {
                _context19.n = 2;
                break;
              }
              // this.logValidationErrors()
              _this19.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              _this19.showItemsValidationErrors();
              return _context19.a(2, false);
            case 2:
              savedAssets = {};
              _context19.p = 3;
              /// part of auto save
              _this19.isSaving = true;
              showSpinner ? _this19.$showSpinner('Saving...') : null;
              _this19.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this19.entity));
              _context19.n = 4;
              return _this19.triggerIsNewOwnerPrompt();
            case 4:
              isCustomerInfoChanged = _context19.v;
              if (!((!_this19.vehicle.isNew || !_this19.customer.isNew) && isCustomerInfoChanged)) {
                _context19.n = 5;
                break;
              }
              _this19.isCustomerCreateModifyModalActive = true;
              return _context19.a(2, false);
            case 5:
              _context19.n = 6;
              return _this19.assignLineNumbers();
            case 6:
              if (!_this19.entity.isNew) {
                _context19.n = 10;
                break;
              }
              _this19.isCustomerCreateModifyModalActive = false;
              _context19.n = 7;
              return _this19.saveQuoteAssets(_this19.entity.isNew, savedAssets);
            case 7:
              isSuccess = _context19.v;
              if (isSuccess) {
                _context19.n = 8;
                break;
              }
              return _context19.a(2, false);
            case 8:
              _context19.n = 9;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].postEntity(_this19.entity);
            case 9:
              response = _context19.v;
              _context19.n = 15;
              break;
            case 10:
              if (!_this19.snapshotDiff) {
                _context19.n = 14;
                break;
              }
              _context19.n = 11;
              return _this19.saveQuoteAssets(false, savedAssets);
            case 11:
              _isSuccess = _context19.v;
              if (_isSuccess) {
                _context19.n = 12;
                break;
              }
              return _context19.a(2, false);
            case 12:
              _context19.n = 13;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].putEntity(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this19.entity), _this19.snapshotDiff);
            case 13:
              response = _context19.v;
              _context19.n = 15;
              break;
            case 14:
              if (showNoChangeMessage) {
                // this.$toast.open('warning', 'No changes. Not saved')
                _this19.$notification.warning('', 'No changes. Not saved');
              }
            case 15:
              _this19.isSaving = false;
              showSpinner ? _this19.$hideSpinner() : null;
              if (!_this19.isSaveContinue) {
                _context19.n = 16;
                break;
              }
              // this.$toast.open('success', isDelete ? `${this.quoteNoRef} deleted` : `Quote ${this.quoteNoRef} saved`)
              if (!_this19._suppressSaveToast) _this19.$notification.success('', isDelete ? "".concat(_this19.deleteQuoteToastMessage, " deleted") : "Quote ".concat(_this19.quoteNoRef, " saved"));
              _context19.n = 20;
              break;
            case 16:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_67__["default"].NO_CONTENT)) {
                _context19.n = 18;
                break;
              }
              _context19.n = 17;
              return _this19.getEntity(true);
            case 17:
              // this.$toast.open('success', isDelete ? `${this.quoteNoRef} deleted` : `Quote ${this.quoteNoRef} saved`)
              if (!_this19._suppressSaveToast) _this19.$notification.success('', isDelete ? "".concat(_this19.deleteQuoteToastMessage, " deleted") : "Quote ".concat(_this19.quoteNoRef, " saved"));
              _context19.n = 20;
              break;
            case 18:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_67__["default"].CREATED)) {
                _context19.n = 20;
                break;
              }
              _context19.n = 19;
              return _this19.getEntity(true);
            case 19:
              // this.$toast.open('success', `New quote ${this.quoteNoRef} added`)
              if (!_this19._suppressSaveToast) _this19.$notification.success('', "New quote ".concat(_this19.quoteNoRef, " added"));
            case 20:
              _this19.setInitialQuoteCustomer();
              _this19.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              _this19.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ImageCountChanged, _this19.entity.imageIds.length);
              _context19.n = 21;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getQuoteAttachments(_this19.entity.quoteId);
            case 21:
              attachments = _context19.v;
              count = Object.values(attachments.data).reduce(function (total, row) {
                return total + Object.values(row.quoteAttachments).length;
              }, 0);
              _this19.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].DocumentCountChanged, count);
              if (!!routeToPriceParts) {
                _this19.$router.push({
                  name: _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePriceParts.name
                });
              }
              _this19.resetAutoSaveFailures();
              if (_this19.setAutoSaveState) _this19.setAutoSaveState({
                isFailed: false,
                isEditing: false,
                isSaving: false
              });
              return _context19.a(2, true);
            case 22:
              _context19.p = 22;
              _t5 = _context19.v;
              _this19.$hideSpinner();
              console.log(_t5);
              if (_t5.response && _t5.response.request && _t5.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_67__["default"].CONFLICT) {
                _this19.isSaveConflictModalActive = true;
              } else if (_t5.response) {
                _this19.$notification.openMessageXhrError(title, _t5);
              } else {
                _this19.$notification.openNotificationWithType('danger', title, _t5.message);
              }
              reportSaveFailure(_t5, 'quote', {
                quoteId: _this19.entity && _this19.entity.quoteId,
                quoteNo: _this19.quoteNoRef,
                isNewQuote: _this19.entity && _this19.entity.isNew,
                savedAssets: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_6__["default"])({}, savedAssets)
              });
              // The quote failed but its header assets may already be saved - reload them so the retry works (PCK-153)
              _context19.n = 23;
              return _this19.refreshSavedQuoteAssets(savedAssets);
            case 23:
              return _context19.a(2, false);
            case 24:
              _context19.p = 24;
              _this19.customerSaveAction = '';
              _this19.isSaving = false;
              _this19.$hideSpinner();
              return _context19.f(24);
            case 25:
              return _context19.a(2);
          }
        }, _callee19, null, [[3, 22, 24, 25]]);
      }))();
    },
    // After copying into an existing quote with autosave on, persist the copy and fully reload so
    // all server-synced state (real item ids, copied images, quote assessments) is correctly set.
    // Reuses the standard save() path (which reloads via getEntity(true)); the generic "saved"
    // toast is suppressed because the copy-success toast was already shown.
    saveCopiedQuoteWithAutosave: function saveCopiedQuoteWithAutosave() {
      var _this20 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee20() {
        var _t6;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context20) {
          while (1) switch (_context20.p = _context20.n) {
            case 0:
              _context20.p = 0;
              _this20._suppressSaveToast = true;
              _context20.n = 1;
              return _this20.save(false, false, false, false);
            case 1:
              _context20.n = 3;
              break;
            case 2:
              _context20.p = 2;
              _t6 = _context20.v;
              console.error('Failed to persist copied quote', _t6);
            case 3:
              _context20.p = 3;
              _this20._suppressSaveToast = false;
              return _context20.f(3);
            case 4:
              return _context20.a(2);
          }
        }, _callee20, null, [[0, 2, 3, 4]]);
      }))();
    },
    purgeNewEmptyLineItems: function purgeNewEmptyLineItems() {
      // Remove (NEW) empty line items before saving to avoid validation errors, lines that don't have itemDesc or value and were just added.
      // Also remove never-synced deleted items (isNew && deleted): the server has no row for
      // them, and the full PUT would otherwise INSERT them as live items (UpdateQuoteItems adds
      // every IsNew item and never sets the Deleted column). Mirrors the items autosave, which
      // drops them from its payload and the live arrays.
      var keep = function keep(i) {
        return !(i.isNew && i.deleted) && (!i.isNew || i.isNew && (i.itemDesc !== '' || i.value !== 0));
      };
      this.entity.labours = this.entity.labours.filter(keep);
      this.entity.parts = this.entity.parts.filter(keep);
      this.entity.others = this.entity.others.filter(keep);
      this.entity.miscs = this.entity.miscs.filter(keep);
      this.entity.sublets = this.entity.sublets.filter(keep);
    },
    triggerIsNewOwnerPrompt: function triggerIsNewOwnerPrompt() {
      var _this21 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee21() {
        var prompt, affectedQuotes;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context21) {
          while (1) switch (_context21.n) {
            case 0:
              // const customerDiff = DeepDiff.diff(this.quoteCustomer, this.initialQuoteCustomer)
              // const isPerson = this.currentCustomerSnapshot.isPerson
              prompt = _this21.isNewCustomerPrompt && !_this21.customerSaveAction;
              if (!prompt) {
                _context21.n = 2;
                break;
              }
              _this21.customerModalSelection = 'create';
              _context21.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getQuotesByVehicle(_this21.entity.quoteId, _this21.vehicle.id, _this21.vehicle.customer.key);
            case 1:
              affectedQuotes = _context21.v;
              _this21.affectedQuotesCount = affectedQuotes.length;
              return _context21.a(2, true);
            case 2:
              _this21.affectedQuotesCount = 0;
            case 3:
              return _context21.a(2, false);
          }
        }, _callee21);
      }))();
    },
    handleCustomerModalSave: function handleCustomerModalSave() {
      var _this22 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee22() {
        var dest;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context22) {
          while (1) switch (_context22.n) {
            case 0:
              if (!(_this22.customerModalSelection === 'create')) {
                _context22.n = 2;
                break;
              }
              _context22.n = 1;
              return _this22.createVehicleCustomer();
            case 1:
              _context22.n = 3;
              break;
            case 2:
              _context22.n = 3;
              return _this22.modifyCustomer();
            case 3:
              if (!_this22.toRoute) {
                _context22.n = 5;
                break;
              }
              dest = _this22.toRoute;
              _this22.toRoute = null;
              _context22.n = 4;
              return _this22.$nextTick();
            case 4:
              _this22.$router.push({
                name: dest.name,
                params: dest.params,
                query: dest.query
              }).catch(function () {});
            case 5:
              return _context22.a(2);
          }
        }, _callee22);
      }))();
    },
    handleCustomerModalCancel: function handleCustomerModalCancel() {
      var _this23 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee23() {
        var dest;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context23) {
          while (1) switch (_context23.n) {
            case 0:
              _this23.isCustomerCreateModifyModalActive = false;
              _context23.n = 1;
              return _this23.getEntity(true);
            case 1:
              _context23.n = 2;
              return _this23.getQuoteAssests();
            case 2:
              if (_this23.setAutoSaveState) {
                _this23.setAutoSaveState({
                  isEditing: false,
                  isSaving: false,
                  isFailed: false
                });
              }
              _this23.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              if (!_this23.toRoute) {
                _context23.n = 4;
                break;
              }
              dest = _this23.toRoute;
              _this23.toRoute = null;
              _context23.n = 3;
              return _this23.$nextTick();
            case 3:
              _this23.$router.push({
                name: dest.name,
                params: dest.params,
                query: dest.query
              }).catch(function () {});
            case 4:
              return _context23.a(2);
          }
        }, _callee23);
      }))();
    },
    setCustomerState: function setCustomerState(isNew) {
      var _this24 = this;
      if (!this.customer) return;
      this.customer.isNew = isNew;

      // Only a new customer gets new ids. After a save the server holds the ids we sent,
      // so regenerating them here makes the next PUT reference rows that don't exist (PCK-153)
      var newId = function newId(currentId) {
        return isNew ? _this24.$guid.newGuid() : currentId;
      };

      // Helper function to safely update arrays
      var updateItems = function updateItems(items) {
        if (Array.isArray(items)) {
          items.forEach(function (item) {
            if (item) {
              item.isNew = isNew;
              item.id = newId(item.id);
            }
          });
        }
      };

      // Update addresses
      updateItems(this.customer.addresses);

      // Update contacts and their nested items
      if (Array.isArray(this.customer.contacts)) {
        this.customer.contacts.forEach(function (obj) {
          if (obj) {
            obj.isNew = isNew;
            obj.id = newId(obj.id);
            if (obj.contact) {
              obj.contact.isNew = isNew;
              // The server creates the contact under the outer id but looks it up by contact.id on
              // update, so a new contact must share one id or its edits are dropped after a half-save (PCK-153)
              obj.contact.id = isNew ? obj.id : obj.contact.id;
              updateItems(obj.contact.addresses);
              updateItems(obj.contact.emails);
              updateItems(obj.contact.phones);
            }
          }
        });
      }

      // Update emails
      updateItems(this.customer.emails);

      // Update phones
      updateItems(this.customer.phones);
    },
    // The server keeps the ids we send but invents one for a null id (phones/emails/addresses added in
    // the panel start with id: null), which we never learn. Assign them before the POST so the copy we
    // keep afterwards references real rows and can be PUT on a retry (PCK-153)
    assignMissingCustomerItemIds: function assignMissingCustomerItemIds() {
      var _this25 = this;
      if (!this.customer) return;
      var fill = function fill(items) {
        if (Array.isArray(items)) {
          items.forEach(function (item) {
            if (item && !item.id) {
              item.id = _this25.$guid.newGuid();
            }
          });
        }
      };
      fill(this.customer.addresses);
      fill(this.customer.emails);
      fill(this.customer.phones);
      if (Array.isArray(this.customer.contacts)) {
        this.customer.contacts.forEach(function (obj) {
          if (obj && obj.contact) {
            fill(obj.contact.addresses);
            fill(obj.contact.emails);
            fill(obj.contact.phones);
          }
        });
      }
    },
    createVehicleCustomer: function createVehicleCustomer() {
      var _this26 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee24() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context24) {
          while (1) switch (_context24.n) {
            case 0:
              _this26.isCustomerCreateModifyModalActive = false;
              _this26.customerSaveAction = 'create';
              _this26.customer.id = _this26.$guid.newGuid();
              _this26.setCustomerState(true);
              _this26.vehicle.customer.key = _this26.customer.id;
              _this26.vehicle.customer.value = _this26.customer.fullname;
              _this26.vehicle.isNew = true;
              _this26.vehicle.id = _this26.$guid.newGuid();
              _this26.entity.customerId = _this26.customer.id;
              _this26.entity.vehicleId = _this26.vehicle.id;
              console.log('createVehicleCustomer', _this26.customer);
              _context24.n = 1;
              return _this26.save();
            case 1:
              return _context24.a(2);
          }
        }, _callee24);
      }))();
    },
    modifyCustomer: function modifyCustomer() {
      var _this27 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee25() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context25) {
          while (1) switch (_context25.n) {
            case 0:
              _this27.isCustomerCreateModifyModalActive = false;
              _this27.customerSaveAction = 'modify';
              _context25.n = 1;
              return _this27.save();
            case 1:
              return _context25.a(2);
          }
        }, _callee25);
      }))();
    },
    delete: function _delete() {
      this.entity.deleted = true;
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.entity));
      // Skip unsaved modal if autosave is active for this quote (new quotes are never autosaved)
      if (!this.autoSaveActiveForQuote && this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue && !this.readOnlyView) {
        // console.log(this.snapshotDiff)
        this.isUnsavedModalActive = true;
      } else {
        if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_59___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else if (this.returnUrl) {
          window.location.href = "".concat("").concat(this.returnUrl);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteListView.name
          });
        }
      }
    },
    printExcessInvoice: function printExcessInvoice() {
      var params = {
        QuoteID: this.entity.quoteId,
        InvoiceNo: this.excessInvoice.invoiceNo,
        InvoiceDate: this.formatDateLocale(this.excessInvoice.invoiceDate, this.$userInfo.locale),
        InsurerID: this.entity.insurerId,
        CustomerID: this.excessInvoice.assetId,
        //this.entity.customerId,
        CompanyID: this.entity.companyId,
        ExcessAmount: "".concat(this.excessInvoice.excessAmount),
        OwnerContributionAmt: "".concat(this.excessInvoice.ownerContribution),
        ExtraCharge: "".concat(this.excessInvoice.extraCharge),
        InvoiceID: this.excessInvoice.invoiceId
      };
      // const query = this.$lzstring.compressToEncodedURIComponent(
      //   Object.keys(params)
      //     .map(e => `${e}=${params[e]}`)
      //     .join('&')
      // )
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["KeyValuePairModel"].convertToKeyValuePairs(params);
      var parameterId = this.$guid.newGuid();
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_62__["Emailer"]();
      emailer.assetId = this.entity.quoteId;
      emailer.assetType = _enums__WEBPACK_IMPORTED_MODULE_55__["EmailAssetTypes"].Quote;
      emailer.remark = "Excess Invoice ".concat(this.excessInvoice.prefix).concat(this.excessInvoice.invoiceNo).concat(this.excessInvoice.suffix);
      emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Insurer];
      emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_55__["RemarkTypes"].OtherSystemRemark;
      emailer.subject = "Excess Invoice ".concat(this.excessInvoice.prefix).concat(this.excessInvoice.invoiceNo).concat(this.excessInvoice.suffix, " - Quote No: ").concat(this.entity.quoteNo || 'NA', " - Claim No: ").concat(this.entity.claimNo || 'NA', " - Rego: ").concat(this.entity.vehicleRego || 'NA');

      // emailer.subject = `Excess Invoice ${this.excessInvoice.prefix}${this.excessInvoice.invoiceNo}${this.excessInvoice.suffix}`
      emailer.reportName = "Excess-Invoice_".concat(this.excessInvoice.prefix).concat(this.excessInvoice.invoiceNo).concat(this.excessInvoice.suffix);
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
      var routeData = this.$router.resolve({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_63__["default"].PrintPreview.name,
        params: {
          reportName: this.entity.excessWithGst ? 'rptExcessInvoiceWithGST' : 'rptExcessInvoice'
        },
        query: {
          parameterId: parameterId,
          emailerId: emailer.id,
          isNewTab: true
        }
      });
      window.open(routeData.href, '_blank');
    },
    printOcInvoice: function printOcInvoice() {
      var params = {
        QuoteID: this.entity.quoteId,
        InvoiceNo: this.ocInvoice.invoiceNo,
        InvoiceDate: this.formatDateLocale(this.ocInvoice.invoiceDate, this.$userInfo.locale),
        InsurerID: this.entity.insurerId,
        CustomerID: this.entity.customerId,
        CompanyID: this.entity.companyId,
        OwnerContributionAmt: "".concat(this.ocInvoice.ownerContribution),
        ExtraCharge: "".concat(this.ocInvoice.extraCharge),
        InvoiceID: this.ocInvoice.invoiceId
      };
      // const query = this.$lzstring.compressToEncodedURIComponent(
      //   Object.keys(params)
      //     .map(e => `${e}=${params[e]}`)
      //     .join('&')
      // )
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["KeyValuePairModel"].convertToKeyValuePairs(params);
      var parameterId = this.$guid.newGuid();
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_62__["Emailer"]();
      emailer.assetId = this.entity.quoteId;
      emailer.assetType = _enums__WEBPACK_IMPORTED_MODULE_55__["EmailAssetTypes"].Quote;
      emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Insurer];
      emailer.remark = "Owner Contribution Invoice ".concat(this.ocInvoice.prefix).concat(this.ocInvoice.invoiceNo).concat(this.ocInvoice.suffix);
      emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_55__["RemarkTypes"].OtherSystemRemark;
      emailer.subject = "Owner Contribution Invoice ".concat(this.ocInvoice.prefix).concat(this.ocInvoice.invoiceNo).concat(this.ocInvoice.suffix);
      emailer.reportName = "Owner-Contribution-Invoice_".concat(this.ocInvoice.prefix).concat(this.ocInvoice.invoiceNo).concat(this.ocInvoice.suffix);
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
      var routeData = this.$router.resolve({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_63__["default"].PrintPreview.name,
        params: {
          reportName: 'rptExcessInvoiceOwnerContribution'
        },
        query: {
          parameterId: parameterId,
          emailerId: emailer.id,
          isNewTab: true
        }
      });
      window.open(routeData.href, '_blank');
    },
    printMyInvoice: function printMyInvoice() {
      var reportName = 'rptInvoiceMy';
      var params = {
        QuoteID: this.entity.quoteId,
        InvoiceNo: this.invoice ? "".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix, "/").concat(this.invoice.invoiceType) : '',
        InvoiceDate: this.formatDateLocale(this.invoice.invoiceDate, this.$userInfo.locale),
        InsurerID: this.entity.insurerId,
        CustomerID: this.entity.customerId,
        CompanyID: this.entity.companyId,
        InvoiceID: this.invoice.invoiceId,
        timezoneoffset: this.$filters.getSiteTimezoneOffset()
      };
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["KeyValuePairModel"].convertToKeyValuePairs(params);
      var parameterId = this.$guid.newGuid();
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_62__["Emailer"]();
      emailer.assetId = this.entity.quoteId;
      emailer.assetType = _enums__WEBPACK_IMPORTED_MODULE_55__["EmailAssetTypes"].Quote;
      emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_55__["AssetTypes"].Insurer];
      emailer.remark = "Invoice ".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix);
      emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_55__["RemarkTypes"].OtherSystemRemark;
      emailer.subject = "Invoice ".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix, " - Quote No: ").concat(this.entity.quoteNo || 'NA', " - Claim No: ").concat(this.entity.claimNo || 'NA', " - Rego: ").concat(this.entity.vehicleRego || 'NA');
      // emailer.subject = `Invoice ${this.invoice.prefix}${this.invoice.invoiceNo}${this.invoice.suffix}`
      emailer.reportName = "Invoice_".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix);
      _store_utils__WEBPACK_IMPORTED_MODULE_64__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
      var routeData = this.$router.resolve({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_63__["default"].PrintPreview.name,
        params: {
          reportName: reportName
        },
        query: {
          parameterId: parameterId,
          emailerId: emailer.id,
          isNewTab: true
        }
      });
      window.open(routeData.href, '_blank');
    },
    formatDateLocale: function formatDateLocale(value, locale) {
      var format = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '2-digit';
      var date = new Date(Date.parse("".concat(value)));
      var options = {
        year: 'numeric',
        month: format,
        day: '2-digit'
      };
      if (Intl) {
        return Intl.DateTimeFormat(locale, options).format(date);
      } else {
        return date.toLocaleDateString(locale, options);
      }
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this28 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee26() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context26) {
          while (1) switch (_context26.n) {
            case 0:
              _this28.isUnsavedModalActive = false;
              _this28.isSaveContinue = true;
              _context26.n = 1;
              return _this28.save();
            case 1:
              _this28.isSaveContinue = _context26.v;
              if (_this28.isSaveContinue) {
                _this28.cancel();
              }
            case 2:
              return _context26.a(2);
          }
        }, _callee26);
      }))();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
      this.isPrintOptionsActive = false;
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quote|returnUrl"), this.returnUrl);
      }
      if (this.invoiceType) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quote|invoiceType"), this.invoiceType);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quote|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quote|invoiceType"));
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        invoiceType: this.invoiceType
      });
      this.$router.replace({
        name: this.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].Quote || this.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].Gst ? _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteInvoice.name : _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteExcessInvoice.name,
        params: {
          quoteId: id
        },
        meta: newMeta
      });
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    newAdditional: function newAdditional() {
      var _this29 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee27() {
        var canStartAdditional;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context27) {
          while (1) switch (_context27.n) {
            case 0:
              canStartAdditional = !_this29.entity.orm ? true : _this29.entity.invoices.some(function (i) {
                return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_55__["InvoiceTypes"].Quote && !i.deleted && (_this29.entity.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_55__["OrmQuoteStatusTypes"].QuoteInvoiceSubmitted || _enums__WEBPACK_IMPORTED_MODULE_55__["OrmQuoteStatusTypes"].PaymentAuthorised);
              });
              if (canStartAdditional) {
                _this29.setReturnRoute(_this29.$route);
                _this29.addStoreSupplementaryItem(_this29.entity.quoteNo);
              } else {
                _this29.$notification.openNotificationWithType('danger', 'Repairer Quote',
                //eslint-disable-next-line
                "Variation for ORM quote should be done on main quote if it's not already invoiced", 6000);
              }
            case 1:
              return _context27.a(2);
          }
        }, _callee27);
      }))();
    },
    exportQuote: function exportQuote() {
      this.isQuoteExportModalActive = true;
    },
    closeQuoteExportModal: function closeQuoteExportModal() {
      var _this30 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee28() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context28) {
          while (1) switch (_context28.n) {
            case 0:
              _this30.isQuoteExportModalActive = false;
              _context28.n = 1;
              return _this30.getEntity(true);
            case 1:
              _this30.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntityReloaded);
            case 2:
              return _context28.a(2);
          }
        }, _callee28);
      }))();
    },
    showCopyQuoteModal: function showCopyQuoteModal() {
      var _this31 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee29() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context29) {
          while (1) switch (_context29.n) {
            case 0:
              _context29.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getImageIds(_this31.entity.quoteId);
            case 1:
              _this31.imageIds = _context29.v;
              _this31.isCopyQuoteModalActive = true;
            case 2:
              return _context29.a(2);
          }
        }, _callee29);
      }))();
    },
    copyQuote: function copyQuote(destinationId, isCopyImages, isOverwrite) {
      // console.log('copy', destinationId, isCopyImages)
      this.isCopyQuoteModalActive = false;
      this.copyStoreQuote({
        sourceId: this.entity.quoteId,
        destinationId: destinationId,
        isCopyImages: isCopyImages,
        isOverwrite: isOverwrite
      });
    },
    sendSms: function sendSms() {
      var jobStart = new Date(this.entity.jobStart).toLocaleDateString(this.$userInfo.locale);
      var mobile = '';
      mobile = this.quoteCustomer.phones.find(function (a) {
        return a.type === _enums__WEBPACK_IMPORTED_MODULE_55__["PhoneTypes"].Mobile.toString();
      });
      if (mobile == undefined) {
        mobile = '';
      } else {
        mobile = mobile.no;
      }
      this.smsDetails = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["SmsSendMessageModel"](this.entity.quoteId, this.quoteCustomer.fullname, this.quoteVehicle.rego, jobStart, this.entity.excess, mobile);
      this.isSmsModalActive = true;
    },
    closeSmsModal: function closeSmsModal() {
      this.isSmsModalActive = false;
      // The modal reports closing whether or not an SMS went out, so signal
      // without a count and let the task bar re-read it.
      this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].CommsCountChanged);
    },
    changeQuote: function changeQuote(subQuote) {
      // console.log(subQuote.key)
      this.$router.push({
        name: this.$route.name,
        params: {
          quoteId: subQuote.value
        }
      });
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      var _this32 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee30() {
        var isSuppQuote, vm, quoteIds;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context30) {
          while (1) switch (_context30.n) {
            case 0:
              _this32.isConfirmModalActive = false;
              if (!confirmDelete) {
                _context30.n = 2;
                break;
              }
              isSuppQuote = _this32.entity.subQuoteNo > 0;
              if (_this32.entity.subQuoteNo === 0 && _this32.entity.subQuoteNos.length > 1) {
                // Delete all supplementary quotes
                vm = _this32;
                quoteIds = _this32.entity.subQuoteNos.filter(function (q) {
                  return q.key !== vm.entity.subQuoteNo;
                }).map(function (q) {
                  return q.value;
                });
                _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].deleteMultipleEntities(quoteIds);
              }
              _this32.entity.deleted = true;
              _context30.n = 1;
              return _this32.save(true);
            case 1:
              if (isSuppQuote) {
                _this32.$router.push({
                  name: _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteHeader.name,
                  params: {
                    quoteId: _this32.entityMainQuote.quoteId
                  }
                });
              }
            case 2:
              return _context30.a(2);
          }
        }, _callee30);
      }))();
    },
    getAudanetPnetSetting: function getAudanetPnetSetting() {
      var _this33 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee31() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context31) {
          while (1) switch (_context31.n) {
            case 0:
              _context31.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getExternalSetting('audatex');
            case 1:
              _this33.audanetSetting = _context31.v;
              _context31.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getExternalSetting('pnet');
            case 2:
              _this33.pnetSetting = _context31.v;
            case 3:
              return _context31.a(2);
          }
        }, _callee31);
      }))();
    },
    deleteItem: function deleteItem(item, items) {
      if (item.isNew) {
        var itemIndex = items.map(function (obj) {
          return obj.quoteItemId;
        }).indexOf(item.quoteItemId);
        if (itemIndex >= 0) {
          items.splice(itemIndex, 1);
        }
      } else {
        item.deleted = true;
        item.isDeleted = true;
        item.itemStatus = _enums__WEBPACK_IMPORTED_MODULE_55__["QuoteItemStatusTypes"].Deleted;
      }
    },
    onOpgCodeChanged: function onOpgCodeChanged() {
      if (!this.entity.readOnly && this.isRacq) {
        // RACQ Consumables percentage
        this.addUpdateRacqConsumable();
        this.scheduleItemsSave();
      } else if (!this.entity.readOnly && this.isNtar) {
        // console.log('opgTotal isNtar')
        this.addUpdatePaintConsumable();
        this.addUpdatePaintMaterial();
        this.addUpdateM3PlusAllowances();
        this.addUpdateSetupColourMatch1();
        this.addUpdateOpgPaintMaterials();
        this.addUpdateSetupColourMatch2();
        this.scheduleItemsSave();
      }
    },
    addUpdateRacqConsumable: function addUpdateRacqConsumable() {
      var _this34 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        var total = _this34.labourTotal + _this34.opgTotal;
        var racqConsumable = _this34.quoteInsurer.insurerConsumables.find(function (c) {
          return c.typeID === 4;
        });
        var percentage = racqConsumable.value;
        var consumableAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(total * percentage / 100);
        // console.log('RACQ Consumable =', consumableAmount)
        var miscItem = _this34.entity.miscs.find(function (i) {
          return i.itemNo === racqConsumable.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        if (consumableAmount > 0) {
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this34.quoteId, racqConsumable.itemNo, 'Total Consumables', _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this34.nextLineNumber;
            miscItem.value = consumableAmount;
            miscItem.sortNo = _this34.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this34.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this34.entity.miscs.splice(_this34.entity.miscs.length, 1, miscItem);
            // this.showToast('RACQ consumable item added', 'success', 'bottom')
          } else {
            miscItem.value = consumableAmount;
            // this.showToast('RACQ consumable item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this34.deleteItem(miscItem, _this34.entity.miscs);
          // this.showToast('RACQ consumable item delete', 'danger', 'bottom')
        }
      });
    },
    addUpdateWeldAllowance: function addUpdateWeldAllowance() {
      var _this35 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        var weldAllowance = _this35.quoteInsurer.insurerConsumables.find(function (c) {
          return c.typeID === 5;
        });
        if (_this35.isNtar) {
          var standardItem = _this35.standardLabourItems.find(function (i) {
            return i.itemNo === weldAllowance.itemNo;
          });
          weldAllowance.description = standardItem.itemDesc;
        }
        var miscItem = _this35.entity.miscs.find(function (i) {
          return i.itemNo === weldAllowance.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        var weldAllowanceAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(_this35.weldHourTotal * weldAllowance.value);
        if (weldAllowanceAmount > 0) {
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this35.quoteId, weldAllowance.itemNo, weldAllowance.description, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this35.nextLineNumber;
            miscItem.value = weldAllowanceAmount;
            miscItem.sortNo = _this35.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this35.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this35.entity.miscs.splice(_this35.entity.miscs.length, 1, miscItem);
            // this.showToast('eMTA Weld Allowance item added', 'success', 'bottom')
          } else {
            miscItem.value = weldAllowanceAmount;
            // this.showToast('eMTA Weld Allowance item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this35.deleteItem(miscItem, _this35.entity.miscs);
          // this.showToast('eMTA Weld Allowance item deleted', 'danger', 'bottom')
        }
      });
    },
    addUpdateRepairPanelConsumable: function addUpdateRepairPanelConsumable() {
      var _this36 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        // NTAR Panel Consumable. Per repair hour. ItemNo 9991
        var rtrmVersion = _this36.entity.verRtrm ? _this36.entity.verRtrm : Math.max.apply(Math, _this36.quoteInsurer.insurerConsumables.map(function (c) {
          return c.versionNo;
        }));
        var repairConsumable = _this36.quoteInsurer.insurerConsumables.find(function (c) {
          return c.typeID === 1 && c.versionNo === rtrmVersion;
        });
        var hours = _this36.entity.labours.filter(function (i) {
          return !i.deleted && !i.reportOnly && (i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP || i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RWA);
        }).reduce(function (total, item) {
          return total + item.hourValue;
        }, 0);
        var consumableAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(hours * repairConsumable.value);
        var miscItem = _this36.entity.miscs.find(function (i) {
          return i.itemNo === repairConsumable.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        console.log('Update Repair Consumable -> ', 'Version : ', rtrmVersion, 'Consumable Amount: ', consumableAmount);
        if (consumableAmount > 0) {
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this36.quoteId, repairConsumable.itemNo, repairConsumable.description, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this36.nextLineNumber;
            miscItem.value = consumableAmount;
            miscItem.sortNo = _this36.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this36.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this36.entity.miscs.splice(_this36.entity.miscs.length, 1, miscItem);
            // this.showToast('Panel Consumables item added', 'success', 'bottom')
          } else {
            miscItem.value = consumableAmount;
            // this.showToast('Panel Consumables item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this36.deleteItem(miscItem, _this36.entity.miscs);
          // this.showToast('Panel Consumables item deleted', 'danger', 'bottom')
        }
      });
    },
    addUpdatePaintConsumable: function addUpdatePaintConsumable() {
      var _this37 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        // NTAR Paint Consumable. Per paing hour. ItemNo 9992
        var rtrmVersion = _this37.entity.verRtrm ? _this37.entity.verRtrm : Math.max.apply(Math, _this37.quoteInsurer.insurerConsumables.map(function (c) {
          return c.versionNo;
        }));
        var paintConsumable = _this37.quoteInsurer.insurerConsumables.find(function (c) {
          return c.typeID === 3 && c.versionNo === rtrmVersion;
        });
        var hours = _this37.entity.labours
        // eslint-disable-next-line no-unexpected-multiline
        .filter(function (i) {
          return !i.deleted && !i.reportOnly && (i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT || i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].OPG) && i.opgCode === _this37.vehicle.paintGroup;
        }).reduce(function (total, item) {
          return total + item.hourValue;
        }, 0);
        var amount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(hours * paintConsumable.value);
        var miscItem = _this37.entity.miscs.find(function (i) {
          return i.itemNo === paintConsumable.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        console.log('Update Paint Consumable -> ', 'Version : ', rtrmVersion, 'Consumable Amount: ', amount);
        if (amount > 0) {
          var presentAsItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemPresentAsModel"]('PAINM', '', Math.max(100, 0));
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this37.quoteId, paintConsumable.itemNo, paintConsumable.description, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this37.nextLineNumber;
            miscItem.value = amount;
            miscItem.sortNo = _this37.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this37.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this37.entity.miscs.splice(_this37.entity.miscs.length, 1, miscItem);
            // this.showToast('Paint Consumables item added', 'success', 'bottom')
            miscItem.presentAs.push(presentAsItem);
          } else {
            miscItem.value = amount;
            // this.showToast('Paint Consumables item updated', 'success', 'bottom')
            if (miscItem.presentAs === null) {
              miscItem.presentAs = [];
              miscItem.presentAs.push(presentAsItem);
            }
          }
        } else if (miscItem) {
          _this37.deleteItem(miscItem, _this37.entity.miscs);
          // this.showToast('Paint Consumables item deleted', 'danger', 'bottom')
        }
      });
    },
    addUpdatePaintMaterial: function addUpdatePaintMaterial() {
      var _this38 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        // NTAR Paint Materia. Per paint hour
        var rtrmVersion = _this38.entity.verRtrm ? _this38.entity.verRtrm : Math.max.apply(Math, _this38.quoteInsurer.insurerConsumables.map(function (c) {
          return c.versionNo;
        }));

        // Use the live edited vehicle (this.vehicle), NOT the store baseline (this.quoteVehicle).
        // quoteVehicle only refreshes on reload, so after a header paint-group change (e.g. S2->M2)
        // it stays stale and this lookup would resolve the OLD group's material item (SO-1901).
        var paintMaterial = _this38.quoteInsurer.insurerPaintMaterials.find(function (c) {
          return c.type === _this38.vehicle.paintGroup && c.versionNo === rtrmVersion;
        });
        var hours = _this38.entity.labours
        // eslint-disable-next-line no-unexpected-multiline
        .filter(function (i) {
          return !i.deleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && i.opgCode === _this38.vehicle.paintGroup;
        }).reduce(function (total, item) {
          return total + item.hourValue;
        }, 0);
        var amount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(hours * paintMaterial.value);
        console.log('addUpdatePaintMaterial', hours, amount);
        var miscItem = _this38.entity.miscs.find(function (i) {
          return i.itemNo === paintMaterial.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        console.log('Update Paint Material -> ', 'Version : ', rtrmVersion, 'Consumable Amount: ', amount);
        if (amount > 0) {
          var presentAsItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemPresentAsModel"]('PAINM', '', Math.max(100, 0));
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this38.quoteId, paintMaterial.itemNo, "PAINT MATERIALS ".concat(paintMaterial.type), _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this38.nextLineNumber;
            miscItem.value = amount;
            miscItem.sortNo = _this38.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this38.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this38.entity.miscs.splice(_this38.entity.miscs.length, 1, miscItem);
            // this.showToast('Paint Material item added', 'success', 'bottom')
            miscItem.presentAs.push(presentAsItem);
          } else {
            miscItem.value = amount;
            if (miscItem.presentAs === null) {
              miscItem.presentAs = [];
              miscItem.presentAs.push(presentAsItem);
            }
            // this.showToast('Paint Material item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this38.deleteItem(miscItem, _this38.entity.miscs);
          // this.showToast('Paint Material item deleted', 'danger', 'bottom')
        }
      });
    },
    addUpdateM3PlusAllowances: function addUpdateM3PlusAllowances() {
      var _this39 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        // this.vehicle is the live edited value; this.quoteVehicle is a stale baseline (see SO-1901).
        if (_this39.vehicle.paintGroup === _enums__WEBPACK_IMPORTED_MODULE_55__["PaintGroupTypes"].M3 && _this39.vehicle.paintGroupPlus && _this39.isNtar) {
          var _this39$entity$miscs;
          var rtrmVersion = _this39.entity.verRtrm ? _this39.entity.verRtrm : Math.max.apply(Math, _this39.quoteInsurer.insurerConsumables.map(function (c) {
            return c.versionNo;
          }));
          var m3plus = _this39.quoteInsurer.insurerPaintMaterials.find(function (c) {
            return c.type === 'M3Plus' && c.versionNo === rtrmVersion;
          });

          // M3+ Allowances. Per paint hour
          var allowanceRate = m3plus ? m3plus.value : 0.32;
          var itemNo = m3plus ? m3plus.itemNo : '9970';
          var paintHours = _this39.entity.labours
          // eslint-disable-next-line no-unexpected-multiline
          .filter(function (i) {
            return !i.deleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && i.opgCode === _this39.vehicle.paintGroup;
          }).reduce(function (total, item) {
            return total + item.hourValue;
          }, 0);
          var paintRate = _this39.entity.rates[0];
          var allowanceHours = allowanceRate * paintHours;
          var allowance = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(allowanceHours * paintRate.rate);
          var miscItem = (_this39$entity$miscs = _this39.entity.miscs) === null || _this39$entity$miscs === void 0 ? void 0 : _this39$entity$miscs.find(function (i) {
            return i.itemNo === itemNo && !i.deleted && !i.deleteOtherItem;
          });
          console.log(_this39.$options.name, paintRate, paintHours, allowance, allowanceRate);
          console.log('Update M3Plus Material -> ', 'Version : ', rtrmVersion, 'Consumable Amount: ', allowance, 'misc item', miscItem);
          if (!miscItem && allowance > 0) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this39.entity.quoteId, itemNo, 'M3+ Allowances', _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this39.nextLineNumber;
            miscItem.value = allowance;
            miscItem.sortNo = _this39.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this39.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this39.$nextTick(function () {
              _this39.entity.miscs.splice(_this39.entity.miscs.length, 1, miscItem);
            });
          } else if (allowance > 0) {
            miscItem.value = allowance;
          } else if (miscItem && allowance === 0) {
            _this39.deleteItem(miscItem, _this39.entity.miscs);
          }
        }
      });
    },
    addUpdateSetupColourMatch1: function addUpdateSetupColourMatch1() {
      var _this40 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        var standardItem = _this40.standardLabourItems.find(function (i) {
          return i.itemNo === '9998';
        });
        var hours = _this40.entity.labours
        // eslint-disable-next-line no-unexpected-multiline
        .filter(function (i) {
          return !i.deleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && i.opgCode === _this40.vehicle.paintGroup;
        }).reduce(function (total, item) {
          return total + item.hourValue;
        }, 0);
        var miscItem = _this40.entity.miscs.find(function (i) {
          return i.itemNo === standardItem.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        var isOtherPaintGroup = _this40.entity.labours.some(function (i) {
          return !i.deleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT && i.opgCode !== _this40.vehicle.paintGroup;
        });

        // only show setup colour match 1 if there are paint hours and no other paint group
        if (hours > 0 && !isOtherPaintGroup) {
          var setupHour = _this40.quoteInsurer.insurerSpecialRates.find(function (i) {
            return i.itemNo === '9998';
          });
          var value = setupHour ? setupHour.value : standardItem.rrHour;
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this40.quoteId, standardItem.itemNo, standardItem.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this40.nextLineNumber;
            miscItem.value = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(value * _this40.entity.shopRate);
            miscItem.sortNo = _this40.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this40.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this40.entity.miscs.splice(_this40.entity.miscs.length, 1, miscItem);
            // this.showToast('Setup Colour Match 1 item added', 'success', 'bottom')
          } else {
            miscItem.value = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(value * _this40.entity.shopRate);
            // this.showToast('Setup Colour Match 1 item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this40.deleteItem(miscItem, _this40.entity.miscs);
          // this.showToast('Setup Colour Match 1 item deleted', 'danger', 'bottom')
        }
      });
    },
    addUpdateOpgPaintMaterials: function addUpdateOpgPaintMaterials() {
      var _this41 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        var paintMaterials = _this41.quoteInsurer.insurerPaintMaterials;
        var _loop = function _loop() {
          var paintMaterial = paintMaterials[i];
          // console.log(paintMaterial.itemNo)
          var paintLayer = paintMaterial.type;
          var amount = _this41.entity.labours
          // eslint-disable-next-line no-unexpected-multiline
          .filter(function (i) {
            return !i.deleted && !i.reportOnly && i.opgCode === paintLayer && i.opgCode !== _this41.vehicle.paintGroup;
          }).reduce(function (total, item) {
            return total + item.hourValue * paintMaterial.value;
          }, 0);
          var miscItem = _this41.entity.miscs.find(function (i) {
            return i.itemNo === paintMaterial.itemNo && !i.deleted && !i.deleteOtherItem;
          });
          if (amount > 0) {
            if (!miscItem) {
              miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this41.quoteId, paintMaterial.itemNo, "PAINT MATERIALS ".concat(paintMaterial.type), _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
              miscItem.lineNumber = _this41.nextLineNumber;
              miscItem.value = amount;
              miscItem.sortNo = _this41.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this41.entity.miscs.map(function (i) {
                return i.sortNo;
              }))) + 1 : 1;
              _this41.entity.miscs.splice(_this41.entity.miscs.length, 1, miscItem);
            } else {
              if (paintMaterial.type === _this41.vehicle.paintGroup) {
                miscItem.value += amount;
              } else {
                miscItem.value = amount;
              }
            }
            // Compare against the live edited group (this.vehicle), NOT the stale store baseline
            // (this.quoteVehicle). Otherwise, after a paint-group change, the old group's material
            // line is never removed and duplicates alongside the new group's (SO-1901).
          } else if (miscItem && paintMaterial.type !== _this41.vehicle.paintGroup && !_this41.vehicle.paintGroupPlus) {
            _this41.deleteItem(miscItem, _this41.entity.miscs);
          }
        };
        for (var i = 0; i < paintMaterials.length; i++) {
          _loop();
        }
      });
    },
    addUpdateSetupColourMatch2: function addUpdateSetupColourMatch2() {
      var _this42 = this;
      var derivedGuard = this.getDerivedItemGuard();
      derivedGuard.run(function () {
        var standardItem = _this42.standardLabourItems.find(function (i) {
          return i.itemNo === '9999';
        });
        var miscItem = _this42.entity.miscs.find(function (i) {
          return i.itemNo === standardItem.itemNo && !i.deleted && !i.deleteOtherItem;
        });
        var hours = _this42.entity.labours
        // eslint-disable-next-line no-unexpected-multiline
        .filter(function (i) {
          return !i.deleted && !i.reportOnly && i.opgCode !== _this42.vehicle.paintGroup;
        }).reduce(function (total, item) {
          return total + item.hourValue;
        }, 0);
        if (_this42.entity.labours.length > 0 && hours > 0) {
          var setupHour = _this42.quoteInsurer.insurerSpecialRates.find(function (i) {
            return i.itemNo === '9999';
          });
          var value = setupHour ? setupHour.value : standardItem.rrHour;
          if (!miscItem) {
            miscItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this42.quoteId, standardItem.itemNo, standardItem.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            miscItem.lineNumber = _this42.nextLineNumber;
            miscItem.value = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(value * _this42.entity.shopRate);
            miscItem.sortNo = _this42.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this42.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            _this42.entity.miscs.splice(_this42.entity.miscs.length, 1, miscItem);
            // this.showToast('Setup Colour Match 2 item added', 'success', 'bottom')
          } else {
            miscItem.value = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(value * _this42.entity.shopRate);
            // this.showToast('Setup Colour Match 2 item updated', 'success', 'bottom')
          }
        } else if (miscItem) {
          _this42.deleteItem(miscItem, _this42.entity.miscs);
          // this.showToast(`Setup Colour Match 2 item deleted`, 'danger', 'bottom')
        }
      });
    },
    // async setupFabButtons() {
    //   this.fabActions.splice(this.fabActions.length, 1, {
    //     name: 'copyQuote',
    //     icon: 'content-copy',
    //     color: '#a8a145',
    //     tooltip: 'Copy Quote'
    //   })
    //   // this.fabActions.splice(this.fabActions.length, 1, {
    //   //   name: 'newAdditional',
    //   //   icon: 'plus-outline',
    //   //   color: '#c14747',
    //   //   tooltip: 'New Additional'
    //   // })
    //   this.fabActions.splice(this.fabActions.length, 1, {
    //     name: 'exportQuote',
    //     icon: 'export',
    //     color: '#2c5ba5',
    //     tooltip: 'Export'
    //   })
    // },
    showItemsValidationErrors: function showItemsValidationErrors() {
      if (this.$v.entity.labours.$invalid) {
        this.$v.entity.labours.$touch();
      }
      if (this.$v.entity.others.$invalid) {
        this.$v.entity.others.$touch();
      }
      if (this.$v.entity.parts.$invalid) {
        this.$v.entity.parts.$touch();
      }
      if (this.$v.entity.opgs.$invalid) {
        this.$v.entity.opgs.$touch();
      }
      if (this.$v.entity.miscs.$invalid) {
        this.$v.entity.miscs.$touch();
      }
      if (this.$v.entity.sublets.$invalid) {
        this.$v.entity.sublets.$touch();
      }
      if (this.$v.detailGroup.$invalid) {
        this.$v.detailGroup.$touch();
      }
      if (this.$v.vehicleCustomerGroup.$invalid) {
        this.$v.vehicleCustomerGroup.$touch();
      }
      if (this.$v.estimateJobStartEnd.$invalid) {
        this.$v.estimateJobStartEnd.$touch();
      }
    },
    labelize: function labelize(name) {
      return name.replace(/([A-Z])/g, ' $1').replace(/^./, function (s) {
        return s.toUpperCase();
      });
    },
    // logValidationErrors() {
    //   const errors = []
    //   // Helper function to get validation error types for a field
    //   const getValidationErrors = (field) => {
    //     if (!field || !field.$params) return []
    //     return Object.keys(field.$params).filter(key => field[key] === false)
    //   }
    //   // Entity fields validation - loop through all entity validation fields
    //   if (this.$v.entity) {
    //     Object.keys(this.$v.entity).forEach(key => {
    //       // Skip special Vuelidate properties and item arrays
    //       if (key.startsWith('$') || ['labours', 'parts', 'opgs', 'others', 'miscs', 'sublets', 'invoices'].includes(key)) {
    //         return
    //       }
    //       const field = this.$v.entity[key]
    //       if (field && field.$invalid) {
    //         const errorTypes = getValidationErrors(field)
    //         if (errorTypes.length > 0) {
    //           errors.push(`${this.labelize(key)}: ${errorTypes.join(', ')}`)
    //         }
    //       }
    //     })
    //   }
    //   // Vehicle fields validation - loop through all vehicle validation fields
    //   if (this.$v.vehicle) {
    //     Object.keys(this.$v.vehicle).forEach(key => {
    //       // Skip special Vuelidate properties
    //       if (key.startsWith('$')) return
    //       const field = this.$v.vehicle[key]
    //       if (field && field.$invalid) {
    //         const errorTypes = getValidationErrors(field)
    //         if (errorTypes.length > 0) {
    //           errors.push(`Vehicle ${this.labelize(key)}: ${errorTypes.join(', ')}`)
    //         }
    //       }
    //     })
    //   }
    //   // Customer fields validation - loop through all customer validation fields
    //   if (this.$v.customer) {
    //     Object.keys(this.$v.customer).forEach(key => {
    //       // Skip special Vuelidate properties and nested arrays
    //       if (key.startsWith('$') || ['emails', 'contacts', 'phones', 'addresses'].includes(key)) {
    //         return
    //       }
    //       const field = this.$v.customer[key]
    //       if (field && field.$invalid) {
    //         const errorTypes = getValidationErrors(field)
    //         if (errorTypes.length > 0) {
    //           errors.push(`Customer ${this.labelize(key)}: ${errorTypes.join(', ')}`)
    //         }
    //       }
    //     })
    //     // Customer emails validation
    //     if (this.$v.customer.emails && this.$v.customer.emails.$invalid) {
    //       const emailsIter = this.$v.customer.emails.$each.$iter
    //       Object.keys(emailsIter).forEach(index => {
    //         const emailField = emailsIter[index]
    //         if (emailField.address && emailField.address.$invalid) {
    //           errors.push(`Customer Email #${parseInt(index) + 1}: invalid email address`)
    //         }
    //       })
    //     }
    //     // Customer contacts validation
    //     if (this.$v.customer.contacts && this.$v.customer.contacts.$invalid) {
    //       const contactsIter = this.$v.customer.contacts.$each.$iter
    //       Object.keys(contactsIter).forEach(index => {
    //         const contact = contactsIter[index]
    //         if (contact.contact) {
    //           if (contact.contact.firstName && contact.contact.firstName.$invalid) {
    //             errors.push(`Customer Contact #${parseInt(index) + 1} First Name: required`)
    //           }
    //           if (contact.contact.lastName && contact.contact.lastName.$invalid) {
    //             errors.push(`Customer Contact #${parseInt(index) + 1} Last Name: required`)
    //           }
    //         }
    //       })
    //     }
    //   }
    //   // Insurer fields validation - loop through all insurer validation fields
    //   if (this.$v.insurer) {
    //     Object.keys(this.$v.insurer).forEach(key => {
    //       // Skip special Vuelidate properties
    //       if (key.startsWith('$')) return
    //       const field = this.$v.insurer[key]
    //       if (field && field.$invalid) {
    //         const errorTypes = getValidationErrors(field)
    //         if (errorTypes.length > 0) {
    //           errors.push(`Insurer ${this.labelize(key)}: ${errorTypes.join(', ')}`)
    //         }
    //       }
    //     })
    //   }
    //   // Items validation (labours, parts, etc.)
    //   const itemTypes = [
    //     { key: 'labours', name: 'Labour' },
    //     { key: 'parts', name: 'Part' },
    //     { key: 'opgs', name: 'OPG' },
    //     { key: 'others', name: 'Other Labour' },
    //     { key: 'miscs', name: 'Misc' },
    //     { key: 'sublets', name: 'Sublet' }
    //   ]
    //   itemTypes.forEach(itemType => {
    //     if (this.$v.entity[itemType.key] && this.$v.entity[itemType.key].$invalid) {
    //       const items = this.$v.entity[itemType.key].$each.$iter
    //       Object.keys(items).forEach(index => {
    //         const item = items[index]
    //         if (item.$invalid) {
    //           const itemData = this.entity[itemType.key][index]
    //           if (itemData && !itemData.deleted) {
    //             // Loop through all fields in the item
    //             Object.keys(item).forEach(fieldKey => {
    //               if (fieldKey.startsWith('$')) return
    //               const field = item[fieldKey]
    //               if (field && field.$invalid) {
    //                 const errorTypes = getValidationErrors(field)
    //                 if (errorTypes.length > 0) {
    //                   errors.push(`${itemType.name} Item #${parseInt(index) + 1} ${this.labelize(fieldKey)}: ${errorTypes.join(', ')}`)
    //                 }
    //               }
    //             })
    //           }
    //         }
    //       })
    //     }
    //   })
    //   // Log all errors to console
    //   if (errors.length > 0) {
    //     console.error('=== VALIDATION ERRORS ===')
    //     errors.forEach(error => console.error(`❌ ${error}`))
    //     console.error(`Total: ${errors.length} error(s)`)
    //   }
    // },
    conflictMerge: function conflictMerge() {
      var _this43 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee32() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context32) {
          while (1) switch (_context32.n) {
            case 0:
              _this43.entity.mergeOnConflict = true;
              _this43.isSaveConflictModalActive = false;
              _context32.n = 1;
              return _this43.save();
            case 1:
              return _context32.a(2);
          }
        }, _callee32);
      }))();
    },
    conflictReload: function conflictReload() {
      var _this44 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee33() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context33) {
          while (1) switch (_context33.n) {
            case 0:
              _this44.isSaveConflictModalActive = false;
              _context33.n = 1;
              return _this44.getEntity(true);
            case 1:
              _this44.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              // this.$nextTick(() => {
              //   this.$eventHub.$emit(EventHubTypes.EntitySaved)
              // })
            case 2:
              return _context33.a(2);
          }
        }, _callee33);
      }))();
    },
    selectVehicle: function selectVehicle(vehicleId, customerId) {
      var _this45 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee34() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context34) {
          while (1) switch (_context34.n) {
            case 0:
              _context34.n = 1;
              return Promise.all([_this45.getQuoteVehicle({
                id: vehicleId,
                refresh: true
              }), _this45.getQuoteCustomer({
                id: customerId,
                refresh: true
              })]);
            case 1:
              _this45.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this45.currentVehicleSnapshot);
              if (_this45.vehicle) _this45.vehicle.isNew = false;
              _this45.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this45.currentCustomerSnapshot);
              _this45.setInitialQuoteCustomer();
              _this45.$nextTick(function () {
                _this45.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              });
            case 2:
              return _context34.a(2);
          }
        }, _callee34);
      }))();
    },
    selectCustomer: function selectCustomer(id) {
      var _this46 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee35() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context35) {
          while (1) switch (_context35.n) {
            case 0:
              _context35.n = 1;
              return _this46.getQuoteCustomer({
                id: id,
                refresh: true
              });
            case 1:
              _this46.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this46.currentCustomerSnapshot);
              if (_this46.entity && _this46.entity.isNew && _this46.vehicle.isNew) {
                _this46.setInitialQuoteCustomer();
              }
              _this46.entity.customerId = _this46.customer.id;
              _this46.$nextTick(function () {
                setTimeout(function () {
                  _this46.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
                }, 500);
              });
            case 2:
              return _context35.a(2);
          }
        }, _callee35);
      }))();
    },
    selectInsurer: function selectInsurer(id) {
      var _this47 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee36() {
        var isItemsEmpty, _this47$insurer$quoti;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context36) {
          while (1) switch (_context36.n) {
            case 0:
              console.log("Insurer, ".concat(id, ", ").concat(_this47.entity.insurerId));
              _this47.entity.insurerId = id;
              _context36.n = 1;
              return _this47.getQuoteInsurer({
                id: id,
                refresh: true
              });
            case 1:
              _this47.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this47.currentInsurerSnapshot);
              isItemsEmpty = _this47.entity.labours.length === 0 && _this47.entity.parts.length === 0 && _this47.entity.others.length === 0 && _this47.entity.opgs.length === 0 && _this47.entity.miscs.length === 0 && _this47.entity.sublets.length === 0;
              if (!(isItemsEmpty || _this47.entity.isNew)) {
                _context36.n = 2;
                break;
              }
              _this47.entity.newMarkup = _this47.insurer.newMarkup;
              _this47.entity.usedMarkup = _this47.insurer.usedMarkup;
              _this47.entity.recoreMarkup = _this47.insurer.recoreMarkup;
              _this47.entity.afterMarketMarkup = _this47.insurer.afterMarketMarkup;
              _this47.entity.exchangeMarkup = _this47.insurer.exchangeMarkup;
              _this47.entity.reconditionedMarkup = _this47.insurer.reconditionedMarkup;
              _this47.entity.parallelMarkup = _this47.insurer.parallelMarkup;
              _this47.entity.shopRate = _this47.insurer.shopRate;
              _this47.entity.labourType = _this47.insurer.labourType;
              _this47.entity.excessWithGst = _this47.insurer.excessGST;
              _this47.entity.quotingMethod = (_this47$insurer$quoti = _this47.insurer.quotingMethod) !== null && _this47$insurer$quoti !== void 0 ? _this47$insurer$quoti : _enums__WEBPACK_IMPORTED_MODULE_55__["QuotingMethodTypes"].Hour;
              _this47.entity.verRtrm = Math.max.apply(Math, _this47.insurer.insurerConsumables.map(function (c) {
                return c.versionNo;
              }));
              // Update quote rates
              _this47.addInsurerLabourRates(_this47.insurer);
              // Add or update automatic items to quote
              _this47.addInsurerAutoItems(_this47.insurer);
              // Add or update template items to quote
              _context36.n = 2;
              return _this47.addInsurerTemplateItems(_this47.insurer);
            case 2:
              // update excessWthGST for an existing uninvoiced quote with items
              if (!isItemsEmpty && !_this47.entity.isNew && _this47.entity.invoices.length === 0) {
                _this47.entity.excessWithGst = _this47.insurer.excessGST;
              }
              _this47.$nextTick(function () {
                _this47.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              });
              if (_this47.insurer.estimage) {
                _this47.entity.isEstimage = true;
              } else {
                _this47.entity.isEstimage = false;
              }
            case 3:
              return _context36.a(2);
          }
        }, _callee36);
      }))();
    },
    addInsurerLabourRates: function addInsurerLabourRates(insurer) {
      var vm = this;
      var isInsurerNtar = insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].NTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].LTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_55__["LabourTimeTypes"].eMTA;
      insurer.insurerLabourRates.forEach(function (ir) {
        var index = vm.entity.rates.findIndex(function (qr) {
          return qr.labourCodeId === ir.labourCode;
        });
        if (index > -1) {
          vm.entity.rates[index].rate = isInsurerNtar ? insurer.shopRate : ir.rate;
        } else {
          var labourType = vm.$labourTypes.find(function (t) {
            return t.labourTypeCode === ir.labourType;
          });
          var newRate = {
            rate: isInsurerNtar ? insurer.shopRate : ir.rate,
            quoteVersion: 0,
            quoteId: vm.entity.quoteId,
            labourCodeId: ir.labourCode,
            labourTypeId: labourType.labourTypeId,
            deleted: false,
            createdBy: '',
            createdDate: '',
            modifiedBy: '',
            modifiedDate: '',
            isNew: true,
            isDeleted: false
          };
          vm.entity.rates.splice(vm.entity.rates.length, 1, newRate);
        }
      });
    },
    addInsurerAutoItems: function addInsurerAutoItems(insurer) {
      if (insurer.insurerAutoItems && insurer.insurerAutoItems.length > 0) {
        var vm = this;
        var lineNumber = this.nextLineNumber;
        insurer.insurerAutoItems.forEach(function (autoItem) {
          var currentItem = vm.entity.miscs.find(function (i) {
            return i.itemDesc === autoItem.itemDesc && i.itemNo === autoItem.itemNo;
          });
          if (!currentItem) {
            var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](vm.entity.quoteId, autoItem.itemNo, autoItem.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC);
            newItem.value = autoItem.price;
            newItem.reportOnly = autoItem.reportOnly;
            newItem.sortNo = vm.entity.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(vm.entity.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            newItem.lineNumber = lineNumber;
            vm.entity.miscs.splice(vm.entity.miscs.length, 1, newItem);
            lineNumber++;
            vm.entity.lines++;
          } else {
            currentItem.value = autoItem.price;
            currentItem.reportOnly = autoItem.reportOnly;
          }
        });
      }
    },
    addInsurerTemplateItems: function addInsurerTemplateItems(insurer) {
      var _this48 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee37() {
        var templateItems, vm, vehiclePaintGroup;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context37) {
          while (1) switch (_context37.n) {
            case 0:
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].validGuid(insurer.templateId)) {
                _context37.n = 2;
                break;
              }
              _context37.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_54__["QuoteTemplateService"].getQuoteTemplateItems(insurer.templateId);
            case 1:
              templateItems = _context37.v;
              if (templateItems && templateItems.length > 0) {
                vm = _this48;
                vehiclePaintGroup = _this48.vehicle.paintGroup;
                templateItems.forEach(function (templateItem) {
                  var currentItem = vm.entity.miscs.find(function (i) {
                    return i.itemDesc === templateItem.itemDesc && i.itemNo === templateItem.itemNo && i.itemType === templateItem.itemType;
                  });
                  if (!currentItem) {
                    var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](vm.entity.quoteId, templateItem.itemNo, templateItem.itemDesc, templateItem.itemType);
                    if (templateItem.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT) {
                      newItem.opgCode = !!templateItem.opgCode ? templateItem.opgCode : vehiclePaintGroup;
                    }
                    newItem.value = templateItem.value;
                    newItem.reportOnly = templateItem.reportOnly;
                    newItem.sortNo = templateItem.sortNo;
                    // let sortNo
                    switch (templateItem.itemType) {
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RR:
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP:
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RWA:
                        newItem.rate = vm.getLabourRate(templateItem.itemType);
                        vm.entity.labours.splice(vm.entity.labours.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.entity.labours.splice(vm.entity.labours.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].OPG:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.entity.opgs.splice(vm.entity.opgs.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MECH:
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].CD:
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].CRUSH:
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].FIBER:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.entity.others.splice(vm.entity.others.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PART:
                        vm.entity.parts.splice(vm.entity.parts.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC:
                        vm.entity.miscs.splice(vm.entity.miscs.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].SUBL:
                        vm.entity.sublets.splice(vm.entity.sublets.length, 1, newItem);
                        break;
                    }
                    // newItem.sortNo = templateItem.sortNo // || sortNo
                  } else {
                    currentItem.value = templateItem.value;
                    currentItem.itemType = templateItem.itemType;
                    currentItem.reportOnly = templateItem.reportOnly;
                    currentItem.sortNo = templateItem.sortNo;
                  }
                });
              }
            case 2:
              return _context37.a(2);
          }
        }, _callee37);
      }))();
    },
    getLabourRate: function getLabourRate(code) {
      if (!this.entity.rates) {
        return {};
      }
      var rate = this.isNtar ? this.entity.rates[0] : this.entity.rates.find(function (i) {
        return i.labourCodeId === code;
      });
      return !rate ? 0 : rate.rate;
    },
    /**
     *
     * @param useServerMaxLineNumber - defaults to true. If false, anchor new-item numbering to the
     * local synced max instead.
     * @returns {Promise<void>}
     */
    assignLineNumbers: function assignLineNumbers() {
      var _arguments6 = arguments,
        _this49 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee38() {
        var useServerMaxLineNumber, maxLineNo, collections, currentLineNumber, entityItems;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context38) {
          while (1) switch (_context38.n) {
            case 0:
              useServerMaxLineNumber = _arguments6.length > 0 && _arguments6[0] !== undefined ? _arguments6[0] : true;
              maxLineNo = _this49.entity.subQuoteNo * 1000;
              if (_this49.entity.isNew) {
                _context38.n = 3;
                break;
              }
              if (!useServerMaxLineNumber) {
                _context38.n = 2;
                break;
              }
              _context38.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getMaxLineNumber(_this49.entity.quoteId);
            case 1:
              maxLineNo = _context38.v;
              if (maxLineNo === 0) maxLineNo = _this49.entity.subQuoteNo * 1000;
              _context38.n = 3;
              break;
            case 2:
              // Local synced max: highest lineNumber already in use by non-new, non-deleted items
              // (those keep their numbers and won't be touched by the de-dupe loop below).
              collections = ['labours', 'others', 'parts', 'miscs', 'sublets', 'opgs'];
              maxLineNo = collections.reduce(function (max, key) {
                return (_this49.entity[key] || []).reduce(function (m, i) {
                  return i && !i.isNew && !i.deleted && (i.lineNumber || 0) > m ? i.lineNumber : m;
                }, max);
              }, _this49.entity.subQuoteNo * 1000);
            case 3:
              currentLineNumber = maxLineNo; // sort if not audanet to make sure line numbers are sequential and not duplicated
              if (!_this49.entity.isAudaNet && !_this49.entity.isAudaBridge) {
                entityItems = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this49.entity.labours), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this49.entity.others), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this49.entity.parts), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this49.entity.miscs), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this49.entity.sublets)).filter(function (i) {
                  return i.isNew;
                }).sort(function (a, b) {
                  return a.lineNumber - b.lineNumber;
                }); // manipulate the array to update the line numbers,
                // for example: a: 1, b: 2, c: 2, d: 3 will become a: 1, b: 2, c: 3, d: 4
                entityItems.forEach(function (item) {
                  if (item.lineNumber > currentLineNumber) {
                    currentLineNumber = item.lineNumber;
                  } else {
                    currentLineNumber++;
                  }
                  item.lineNumber = currentLineNumber;
                });
                // Only update entity.lines for non-Audanet quotes.
                // Audanet/Audatext quotes have lineNumber=0 for all items; getMaxLineNumber returns 0,
                // so currentLineNumber would be subQuoteNo*1000 and setting entity.lines to that value
                // creates a spurious diff that triggers an unnecessary (and failing) putEntity call.
                _this49.entity.lines = useServerMaxLineNumber ? currentLineNumber + 1 : Math.max(_this49.entity.lines || 0, currentLineNumber + 1);
              }
            case 4:
              return _context38.a(2);
          }
        }, _callee38);
      }))();
    },
    toggleReadOnly: function toggleReadOnly() {
      var _this50 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee39() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context39) {
          while (1) switch (_context39.n) {
            case 0:
              if (_this50.canChangeReadOnly) {
                _context39.n = 1;
                break;
              }
              return _context39.a(2);
            case 1:
              if (!_this50.autoSaveStatus.isSaving) {
                _context39.n = 2;
                break;
              }
              return _context39.a(2);
            case 2:
              _this50.entity.readOnly = !_this50.entity.readOnly;
              _this50.entity.readOnlyStatuses.splice(_this50.entity.subQuoteNo, 1, _this50.entity.readOnly);
              _this50.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this50.entity));
              if (_this50.autoSaveActiveForQuote) {
                // saveReadOnlyNow persists the lock immediately, so rebase it out of `snapshotDiff` —
                // only these two fields, or any other unsaved edit would be swallowed with it.
                _this50.setBaseSnapshotFields({
                  entity: {
                    readOnly: _this50.entity.readOnly,
                    readOnlyStatuses: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_this50.entity.readOnlyStatuses)
                  },
                  fields: ['readOnly', 'readOnlyStatuses']
                });
              }
              // With autosave off nothing is persisted here: the lock stays an unsaved change and the
              // manual Save carries it (the full quote PUT maps ReadOnly).
              _context39.n = 3;
              return _this50.saveReadOnlyNow();
            case 3:
              return _context39.a(2);
          }
        }, _callee39);
      }))();
    },
    deletePaintLoadingItemFromEntity: function deletePaintLoadingItemFromEntity(item, quoteEntity) {
      if (!item || !quoteEntity) return;
      if (item.isNew) {
        var itemIndex = quoteEntity.labours.findIndex(function (l) {
          return l.quoteItemId === item.quoteItemId;
        });
        if (itemIndex >= 0) {
          quoteEntity.labours.splice(itemIndex, 1);
        }
      } else {
        item.deleted = true;
        item.isDeleted = true;
        item.itemStatus = _enums__WEBPACK_IMPORTED_MODULE_55__["QuoteItemStatusTypes"].Deleted;
      }
    },
    getDefaultPaintItemForQuote: function getDefaultPaintItemForQuote(itemNo, quoteEntity) {
      var _this51 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee40() {
        var filter;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context40) {
          while (1) switch (_context40.n) {
            case 0:
              filter = {
                countryId: _components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].empty(),
                companyId: quoteEntity.companyId,
                query: itemNo,
                butterflyCode: '',
                scheduleId: _this51.vehicle.scheduleId || '',
                bodyId: _this51.vehicle.bodyId || '',
                bodySize: '',
                paintGroup: _this51.vehicle.paintGroup || '',
                variantId: 0,
                nvic: '',
                sortColumn: '',
                sortOrder: '',
                pageIndex: 1,
                pageSize: 1
              };
              return _context40.a(2, _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getAvailableLabourItems(filter, quoteEntity.labourType.toLowerCase()));
          }
        }, _callee40);
      }))();
    },
    downloadPartsCheckPrice: function downloadPartsCheckPrice() {
      var _this52 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee42() {
        var runDownload, result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context43) {
          while (1) switch (_context43.n) {
            case 0:
              // Flush/save any pending changes first (autosave on) before fetching prices, so a
              // dirty quote no longer dead-ends on the "Quote has changed" toast. The toast only
              // surfaces when autosave is genuinely disabled and there are unsaved changes.
              runDownload = /*#__PURE__*/function () {
                var _ref6 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee41() {
                  var clonedEntity, countryCode, priceUpdate, nextLineNumber, _iterator, _step, _loop2, _t7, _t8;
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context42) {
                    while (1) switch (_context42.p = _context42.n) {
                      case 0:
                        _this52.$showSpinner('Fetching prices...');
                        _context42.p = 1;
                        clonedEntity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(_this52.entity);
                        countryCode = _this52.$company.info.countryCode;
                        _context42.n = 2;
                        return _services__WEBPACK_IMPORTED_MODULE_75__["PartsCheckService"].getPartsCheckPrices(clonedEntity.quoteId);
                      case 2:
                        priceUpdate = _context42.v;
                        if (!(priceUpdate.parts.length > 0)) {
                          _context42.n = 12;
                          break;
                        }
                        nextLineNumber = _this52.nextLineNumber;
                        _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(priceUpdate.parts);
                        _context42.p = 3;
                        _loop2 = /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _loop2() {
                          var partsCheckPart, part;
                          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context41) {
                            while (1) switch (_context41.n) {
                              case 0:
                                partsCheckPart = _step.value;
                                if (!partsCheckPart.isNew) {
                                  _context41.n = 1;
                                  break;
                                }
                                part = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](clonedEntity.quoteId, partsCheckPart.itemNo, partsCheckPart.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PART);
                                part.sortNo = clonedEntity.parts.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(clonedEntity.parts.map(function (i) {
                                  return i.sortNo;
                                }))) + 1 : 1;
                                if (clonedEntity.isAudaNet) {
                                  part.lineNumber = 0;
                                } else {
                                  part.lineNumber = nextLineNumber;
                                }
                                if (clonedEntity.isAudanet) {
                                  part.rev = QuoteItemRevTypes.NonAudaNetPart;
                                }
                                _context41.n = 3;
                                break;
                              case 1:
                                part = clonedEntity.parts.find(function (i) {
                                  return i.quoteItemId === partsCheckPart.quoteItemId;
                                });
                                if (part) {
                                  _context41.n = 2;
                                  break;
                                }
                                return _context41.a(2, 1);
                              case 2:
                                part.itemStatus = part.itemStatus != 'A' ? 'C' : part.itemStatus;
                              case 3:
                                if (countryCode !== 'MY' || countryCode === 'MY' && partsCheckPart.isNew) {
                                  part.value = partsCheckPart.unitPrice;
                                  part.markupPercent = partsCheckPart.markupPercent;
                                  part.markupValue = partsCheckPart.markupPrice;
                                  part.mark = partsCheckPart.mark;
                                }
                                part.itemQuantity = partsCheckPart.quantity;
                                part.buyPrice = partsCheckPart.buyPrice;
                                part.partNo = partsCheckPart.partNo;
                                part.side = partsCheckPart.side;
                                part.extLineId = partsCheckPart.partsCheckId;
                                part.partsCheckReferenceNo = partsCheckPart.partsCheckReferenceNo;
                                part.partStatus = part.itemComment === 'Part price variance - Not Authorised/Invoiced?' && part.reportOnly === true ? '' : part.partStatus !== 'Pord' ? 'Imp' : part.partStatus; // don't update parts status for pending order
                                if (part.isNew) {
                                  if (countryCode === 'MY') {
                                    part.itemComment = 'Part added by supplier';
                                    part.reportOnly = true;
                                  } else {
                                    part.itemComment = partsCheckPart.itemComment;
                                    part.reportOnly = partsCheckPart.reportOnly;
                                  }
                                  clonedEntity.parts.splice(clonedEntity.parts.length, 1, part);
                                  if (!clonedEntity.isAudaNet) {
                                    clonedEntity.lines = clonedEntity.nextLineNumber + 1;
                                    nextLineNumber++;
                                  }
                                }
                                _context41.n = 4;
                                return Object(_helpers_PartsCheckSyncPartHelper__WEBPACK_IMPORTED_MODULE_86__["syncPartPaintLoading"])({
                                  partItem: part,
                                  quoteEntity: clonedEntity,
                                  nextLineNumber: _this52.nextLineNumber,
                                  ntarLoadingItems: _this52.ntarLoadingItems,
                                  quoteInsurer: _this52.quoteInsurer,
                                  getDefaultPaintItem: function getDefaultPaintItem(itemNo) {
                                    return _this52.getDefaultPaintItemForQuote(itemNo, clonedEntity);
                                  },
                                  deletePaintLoadingItem: function deletePaintLoadingItem(item) {
                                    return _this52.deletePaintLoadingItemFromEntity(item, clonedEntity);
                                  },
                                  defaultPaintGroup: _this52.vehicle.paintGroup
                                });
                              case 4:
                                return _context41.a(2);
                            }
                          }, _loop2);
                        });
                        _iterator.s();
                      case 4:
                        if ((_step = _iterator.n()).done) {
                          _context42.n = 7;
                          break;
                        }
                        return _context42.d(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_loop2()), 5);
                      case 5:
                        if (!_context42.v) {
                          _context42.n = 6;
                          break;
                        }
                        return _context42.a(3, 6);
                      case 6:
                        _context42.n = 4;
                        break;
                      case 7:
                        _context42.n = 9;
                        break;
                      case 8:
                        _context42.p = 8;
                        _t7 = _context42.v;
                        _iterator.e(_t7);
                      case 9:
                        _context42.p = 9;
                        _iterator.f();
                        return _context42.f(9);
                      case 10:
                        _this52.entity = clonedEntity;
                        _context42.n = 11;
                        return _this52.save();
                      case 11:
                        _this52.showSuccessToast('PartsCheck price updates downloaded', 5000);
                        _context42.n = 13;
                        break;
                      case 12:
                        // this.$toast.open({
                        //   message: 'There are no PartsCheck price updates',
                        //   type: 'is-warning',
                        //   queue: true,
                        //   duration: 5000
                        // })
                        _this52.$notification.openNotificationWithType('warning', '', 'There are no PartsCheck price updates', 5000);
                      case 13:
                        _context42.n = 15;
                        break;
                      case 14:
                        _context42.p = 14;
                        _t8 = _context42.v;
                      case 15:
                        _context42.p = 15;
                        _this52.$hideSpinner();
                        return _context42.f(15);
                      case 16:
                        return _context42.a(2);
                    }
                  }, _callee41, null, [[3, 8, 9, 10], [1, 14, 15, 16]]);
                }));
                return function runDownload() {
                  return _ref6.apply(this, arguments);
                };
              }();
              _context43.n = 1;
              return _this52.saveQuoteAndContinue(runDownload);
            case 1:
              result = _context43.v;
              if (!(result !== null && result !== void 0 && result.ok) && (result === null || result === void 0 ? void 0 : result.reason) === 'autosave-disabled') {
                _this52.showQuoteChangedToast();
              }
              _this52.updateStatusForQuote();
              _this52.$nextTick(function () {
                _this52.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].EntitySaved);
              });
            case 2:
              return _context43.a(2);
          }
        }, _callee42);
      }))();
    },
    updateStatusForQuote: function updateStatusForQuote() {
      var _this53 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee43() {
        var status, keys, preservedStatuses, mutated;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context44) {
          while (1) switch (_context44.n) {
            case 0:
              _context44.n = 1;
              return _this53.fetchStatusForNumbers();
            case 1:
              status = _context44.v;
              // filter keys that have a value of "Withdrawn"
              keys = Object.keys(status).filter(function (key) {
                return status[key] == 'Withdrawn';
              });
              if (!keys.length) {
                _context44.n = 2;
                break;
              }
              // Preserve priced (IMP/MPR) and pending-order (Pord) parts even if the ref came back Withdrawn —
              // the duplicate-quote-number case can surface a stale Withdrawn draft (see FQ-2816).
              preservedStatuses = ['IMP', 'MPR', 'PORD'];
              mutated = false;
              _this53.entity.parts.forEach(function (part) {
                if (!keys.includes(part.partsCheckReferenceNo.toString())) return;
                var current = (part.partStatus || '').toUpperCase();
                if (preservedStatuses.includes(current)) return;
                part.partStatus = '';
                mutated = true;
              });
              if (!mutated) {
                _context44.n = 2;
                break;
              }
              _this53.$notification.openNotificationWithType('success', '', 'Some parts have been withdrawn from PartsCheck. These can be priced and ordered again.', 5000);
              _context44.n = 2;
              return _this53.save();
            case 2:
              return _context44.a(2);
          }
        }, _callee43);
      }))();
    },
    viewPartsCheckRequest: function viewPartsCheckRequest() {
      this.messageType = 'PartsCheck';
      this.isXmlViewerModalActive = true;
    },
    // call to get status for a partscheck order, direct purchases and price parts
    getStatusForNumber: function getStatusForNumber(refNumber) {
      var _this54 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee44() {
        var quoteNo, status, _t9;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context45) {
          while (1) switch (_context45.p = _context45.n) {
            case 0:
              quoteNo = _this54.entity.prefix + _this54.entity.quoteNo + _this54.entity.suffix;
              _context45.p = 1;
              _context45.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_75__["PartsCheckService"].getQuotePartStatus(quoteNo, _this54.entity.subQuoteNo, refNumber);
            case 2:
              status = _context45.v;
              return _context45.a(2, {
                refNumber: refNumber,
                status: status
              });
            case 3:
              _context45.p = 3;
              _t9 = _context45.v;
              // Handle any errors if needed
              _this54.$notification.error('Error', 'Failed to get status for Quote Parts');
            case 4:
              return _context45.a(2);
          }
        }, _callee44, null, [[1, 3]]);
      }))();
    },
    fetchStatusForNumbers: function fetchStatusForNumbers() {
      var _this55 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee45() {
        var results, numbers, _iterator2, _step2, number, result, _t0;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context46) {
          while (1) switch (_context46.p = _context46.n) {
            case 0:
              results = {};
              numbers = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(new Set(_this55.entity.parts.map(function (i) {
                return i.partsCheckReferenceNo;
              })));
              _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(numbers);
              _context46.p = 1;
              _iterator2.s();
            case 2:
              if ((_step2 = _iterator2.n()).done) {
                _context46.n = 5;
                break;
              }
              number = _step2.value;
              _context46.n = 3;
              return _this55.getStatusForNumber(number);
            case 3:
              result = _context46.v;
              results[number] = result === null || result === void 0 ? void 0 : result.status;
            case 4:
              _context46.n = 2;
              break;
            case 5:
              _context46.n = 7;
              break;
            case 6:
              _context46.p = 6;
              _t0 = _context46.v;
              _iterator2.e(_t0);
            case 7:
              _context46.p = 7;
              _iterator2.f();
              return _context46.f(7);
            case 8:
              return _context46.a(2, results);
          }
        }, _callee45, null, [[1, 6, 7, 8]]);
      }))();
    },
    addNewQuoteItems: function addNewQuoteItems(existingItems, templateItems) {
      var _this56 = this;
      var existingItemsMap = new Map(existingItems.filter(function (i) {
        return !i.deleted;
      }).map(function (item) {
        return ["".concat(item.itemNo, "|").concat(item.itemDesc, "|").concat(item.itemType), item];
      }));
      var existingItemIds = new Set(existingItems.filter(function (i) {
        return !i.deleted && i.quoteItemId;
      }).map(function (item) {
        return item.quoteItemId;
      }));
      templateItems.forEach(function (templateItem) {
        var key = "".concat(templateItem.itemNo, "|").concat(templateItem.itemDesc, "|").concat(templateItem.itemType);
        // Check both by composite key and by quoteItemId if it exists
        if (existingItemsMap.has(key) || templateItem.quoteItemId && existingItemIds.has(templateItem.quoteItemId)) return;
        var newQuoteItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_72__["QuoteItemModel"](_this56.entity.quoteId, templateItem.itemNo, templateItem.itemDesc, templateItem.itemType);
        var rate = 0;

        // add correct line number and sort number
        newQuoteItem.lineNumber = _this56.nextLineNumber;
        newQuoteItem.sortNo = existingItems.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(existingItems.map(function (i) {
          return i.sortNo;
        }))) + 1 : 1;
        switch (templateItem.itemType) {
          case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RR:
            rate = _this56.isNtar ? _this56.entity.shopRate : _this56.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RR);
            break;
          case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP:
            rate = _this56.isNtar ? _this56.entity.shopRate : _this56.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP);
            break;
          case _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT:
            rate = _this56.isNtar ? _this56.entity.shopRate : _this56.getLabourRate(_this56.vehicle.paintGroup);
            break;
          default:
        }
        newQuoteItem.rate = rate !== null && rate !== void 0 ? rate : 0;
        // this.isNtar &&

        if (templateItem.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT || templateItem.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP || templateItem.itemType === _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RR) {
          // calculate dollar value
          if (_this56.entity.quotingMethod == _enums__WEBPACK_IMPORTED_MODULE_55__["QuotingMethodTypes"].Dollar) {
            var dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_60__["roundAwayFromZero"])(templateItem.value * newQuoteItem.rate);
            newQuoteItem.hourValue = dollarValue;
            newQuoteItem.dollarValue = dollarValue;
          } else {
            newQuoteItem.hourValue = templateItem.value;
            newQuoteItem.dollarValue = newQuoteItem.hourValue;
          }
        }
        newQuoteItem.reportOnly = templateItem.reportOnly;
        newQuoteItem.value = templateItem.value;
        if (templateItem.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT) {
          newQuoteItem.opgCode = _this56.vehicle.paintGroup;
        }
        existingItems.push(newQuoteItem);
        _this56.templateQuoteItemCount++;
      });
    },
    addRepairQuoteTemplateItems: function addRepairQuoteTemplateItems(id) {
      var _this57 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee46() {
        var templateItems, LABOUR_ITEM_TYPES, labourItems, miscItems, otherItems, subletItems;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context47) {
          while (1) switch (_context47.n) {
            case 0:
              _context47.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_54__["QuoteTemplateService"].getSortedQuoteTemplateItems(id);
            case 1:
              templateItems = _context47.v;
              LABOUR_ITEM_TYPES = new Set([_enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP, _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].RR]);
              labourItems = templateItems.filter(function (i) {
                return LABOUR_ITEM_TYPES.has(i.itemType);
              });
              miscItems = templateItems.filter(function (i) {
                return i.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MISC;
              });
              otherItems = templateItems.filter(function (i) {
                return i.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].MECH;
              });
              subletItems = templateItems.filter(function (i) {
                return i.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].SUBL;
              });
              _this57.addNewQuoteItems(_this57.entity.miscs, miscItems);
              _this57.addNewQuoteItems(_this57.entity.others, otherItems);
              _this57.addNewQuoteItems(_this57.entity.sublets, subletItems);
              if (_this57.isNtar) {
                _this57.getNtarTimesForTemplateLabour(labourItems);
              } else {
                _this57.addNewQuoteItems(_this57.entity.labours, labourItems);
                _this57.countNewQuoteItemNotification();
                _this57.templateQuoteItemCount = 0;
                _this57.$nextTick(function () {
                  _this57.updateQuoteItemsPage();
                });
              }
            case 2:
              return _context47.a(2);
          }
        }, _callee46);
      }))();
    },
    addRepairQuoteTemplateItemsCustom: function addRepairQuoteTemplateItemsCustom(obj) {
      var _this58 = this;
      console.log('obj from template', obj);

      // return

      this.addNewQuoteItems(this.entity.miscs, obj.miscItems);
      this.addNewQuoteItems(this.entity.others, obj.otherItems);
      this.addNewQuoteItems(this.entity.sublets, obj.subletItems);
      this.addNewQuoteItems(this.entity.parts, obj.partItems);
      if (this.isNtar) {
        this.getNtarTimesForTemplateLabour(obj.labourItems);
      } else {
        this.addNewQuoteItems(this.entity.labours, obj.labourItems);
        this.countNewQuoteItemNotification();
        this.templateQuoteItemCount = 0;
        this.$nextTick(function () {
          _this58.updateQuoteItemsPage();
          _this58.scheduleItemsSave();
        });
      }
    },
    // get labour times for a template when applying to a ntar quote
    getNtarTimesForTemplateLabour: function getNtarTimesForTemplateLabour(labourArr) {
      var _this59 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee47() {
        var filter, data;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context48) {
          while (1) switch (_context48.n) {
            case 0:
              console.log(_this59.entity);
              if (!(_this59.vehicle.ntarScheduleId == '' || _this59.vehicle.bodyId == '' || _this59.entity.labourType == '')) {
                _context48.n = 1;
                break;
              }
              return _context48.a(2, labourArr);
            case 1:
              filter = {
                countryId: _components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].empty(),
                companyId: _components_Guid__WEBPACK_IMPORTED_MODULE_73__["default"].empty(),
                query: '',
                butterflyCode: '',
                scheduleId: _this59.vehicle.ntarScheduleId || '',
                bodyId: _this59.vehicle.bodyId || '',
                bodySize: '',
                paintGroup: _this59.vehicle.paintGroup || '',
                variantId: 0,
                nvic: '',
                sortColumn: '',
                sortOrder: '',
                pageIndex: 1,
                pageSize: 999
              };
              _context48.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getAvailableLabourItems(filter, _this59.entity.labourType);
            case 2:
              data = _context48.v;
              labourArr.forEach(function (templateItem) {
                var labourItem = data.find(function (i) {
                  return i.itemNo == templateItem.itemNo;
                });
                if (labourItem) {
                  console.log('labourItem', labourItem);
                  templateItem.value = templateItem.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].PAINT ? labourItem.paintHour : templateItem.itemType == _enums__WEBPACK_IMPORTED_MODULE_55__["ItemCategoryTypes"].REP ? labourItem.repairHour : labourItem.rrHour;
                }
              });
              console.log('labourItems', labourArr);

              // return

              console.log('labourItems', labourArr);
              _this59.addNewQuoteItems(_this59.entity.labours, labourArr);
              _this59.countNewQuoteItemNotification();
              _this59.templateQuoteItemCount = 0;
              _this59.$nextTick(function () {
                _this59.updateQuoteItemsPage();
                _this59.scheduleItemsSave();
              });
            case 3:
              return _context48.a(2);
          }
        }, _callee47);
      }))();
    },
    // updates the data on quote items page so changes made from templates etc can be
    // reflected right away
    updateQuoteItemsPage: function updateQuoteItemsPage() {
      this.$eventHub.$emit('updateLabour');
      this.$eventHub.$emit('updateOthers');
      this.$eventHub.$emit('updateParts');
      this.$eventHub.$emit('updateMiscs');
      this.$eventHub.$emit('updateSublets');
    },
    countNewQuoteItemNotification: function countNewQuoteItemNotification() {
      if (!this.templateQuoteItemCount > 0) {
        // return this.$toast.open({
        //   message: 'No item added',
        //   type: 'is-warning',
        //   position: 'is-top',
        //   queue: false
        // })
        return this.$notification.warning('', 'No item added');
      }
      // return this.$toast.open({
      //   message: `${this.templateQuoteItemCount} Items added`,

      //   type: 'is-success',
      //   position: 'is-top',
      //   queue: false
      // })
      return this.$notification.success('', "".concat(this.templateQuoteItemCount, " Items added"));
    },
    reloadQuoteImages: function reloadQuoteImages() {
      if (this.$router.currentRoute.name == _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteImages.name) {
        if (this.$refs.currentChild.reload) {
          this.$refs.currentChild.reload();
        }
      }
    },
    handleSaveRepxRepairStages: function handleSaveRepxRepairStages(data) {
      var _this60 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee48() {
        var repxStageSetting, isSaved, isRepxStageSaved;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context49) {
          while (1) switch (_context49.n) {
            case 0:
              _context49.n = 1;
              return _views_repx_RepxService__WEBPACK_IMPORTED_MODULE_79__["default"].getRepxRepairStageSettings(data.Stage);
            case 1:
              repxStageSetting = _context49.v;
              if (repxStageSetting) {
                _this60.entity.jobStage = repxStageSetting.jobStage;
                _this60.entity.subJobStage = repxStageSetting.subJobStage;
              }
              _context49.n = 2;
              return _this60.save();
            case 2:
              isSaved = _context49.v;
              if (!isSaved) {
                _context49.n = 5;
                break;
              }
              if (!_this60.$refs.currentChild.saveRepxRepairStages) {
                _context49.n = 4;
                break;
              }
              _context49.n = 3;
              return _this60.$refs.currentChild.saveRepxRepairStages(data);
            case 3:
              isRepxStageSaved = _context49.v;
              //QuoteRepx
              console.log("isRepxStageSaved: ".concat(isRepxStageSaved));
              if (!isRepxStageSaved) {
                _context49.n = 4;
                break;
              }
              _context49.n = 4;
              return _this60.getEntity(true);
            case 4:
              _context49.n = 6;
              break;
            case 5:
              if (_this60.$refs.currentChild.resetSaveModal) {
                _this60.$refs.currentChild.resetSaveModal(); //QuoteRepx
              }
            case 6:
              return _context49.a(2);
          }
        }, _callee48);
      }))();
    },
    modifySelections: function modifySelections() {
      // Open butterfly modal for vehicle part selection
      // this.isButterflyModalActive = true
      this.isVehicleButterflyModalActive = true;
    },
    resetSelections: function resetSelections() {
      var _this61 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee49() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context50) {
          while (1) switch (_context50.n) {
            case 0:
              _this61.selectedSubSections = [];
              _this61.isVehicleButterflyModalActive = false;
              if (!(_this61.entity && _this61.entity.quoteId)) {
                _context50.n = 1;
                break;
              }
              _context50.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].updateQuoteButterfly(_this61.entity.quoteId, []);
            case 1:
              _context50.n = 2;
              return _this61.loadButterflySelections();
            case 2:
              return _context50.a(2);
          }
        }, _callee49);
      }))();
    },
    handleVehicleButterflyDone: function handleVehicleButterflyDone() {
      var _this62 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee50() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context51) {
          while (1) switch (_context51.n) {
            case 0:
              _this62.isVehicleButterflyModalActive = false;
              _context51.n = 1;
              return _this62.loadButterflySelections();
            case 1:
              return _context51.a(2);
          }
        }, _callee50);
      }))();
    },
    handleVehicleButterflyCancel: function handleVehicleButterflyCancel() {
      var _this63 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee51() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context52) {
          while (1) switch (_context52.n) {
            case 0:
              _this63.isVehicleButterflyModalActive = false;
              _context52.n = 1;
              return _this63.loadButterflySelections();
            case 1:
              return _context52.a(2);
          }
        }, _callee51);
      }))();
    },
    goToRoute: function goToRoute(route) {
      if (this.entity && !this.entity.isNew) {
        this.$router.push(route);
      }
    },
    getCompanyExternalSetting: function getCompanyExternalSetting() {
      var _this64 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee52() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context53) {
          while (1) switch (_context53.n) {
            case 0:
              _context53.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_54__["CompanyService"].getCompanyExternalSetting('Planning Plus');
            case 1:
              _this64.planningSetting = _context53.v;
            case 2:
              return _context53.a(2);
          }
        }, _callee52);
      }))();
    },
    loadButterflySelections: function loadButterflySelections() {
      var _this65 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee53() {
        var quoteButterfly, _this65$selectedSubSe, firstSelectedFound, newSelections;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context54) {
          while (1) switch (_context54.n) {
            case 0:
              if (!(_this65.entity && _this65.entity.quoteId)) {
                _context54.n = 2;
                break;
              }
              _context54.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getQuoteButterfly(_this65.entity.quoteId);
            case 1:
              quoteButterfly = _context54.v;
              if (quoteButterfly.length) {
                firstSelectedFound = false;
                newSelections = quoteButterfly.map(function (item) {
                  var isFilter = false;
                  if (!firstSelectedFound && item.isSelected) {
                    isFilter = true;
                    firstSelectedFound = true;
                  }
                  return {
                    partId: item.butterflyCode,
                    id: item.butterflyCode,
                    // Add id property for compatibility
                    partName: item.butterflyDesc,
                    area: item.area,
                    selected: item.isSelected,
                    sortOrder: item.sortOrder,
                    isFilter: isFilter
                  };
                });
                (_this65$selectedSubSe = _this65.selectedSubSections).splice.apply(_this65$selectedSubSe, [0, _this65.selectedSubSections.length].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_5__["default"])(newSelections)));
              } else {
                _this65.selectedSubSections.splice(0, _this65.selectedSubSections.length);
              }
            case 2:
              return _context54.a(2);
          }
        }, _callee53);
      }))();
    },
    setInnerJobNSubJobStageCompositeKey: function setInnerJobNSubJobStageCompositeKey() {
      console.log('setInnerJobNSubJobStageCompositeKey');
      if (this.entity) {
        var jobStage = this.entity.jobStage;
        if (jobStage) {
          var subJobStage = this.entity.subJobStage || '';
          this.innerJobNSubJobStageCompositeKey = jobStage + '|' + subJobStage;
        }
      }
    },
    filterByArea: function filterByArea(area) {
      this.selectedArea = area;
    },
    //TEMP check for GEMCan company - REMOVE AFTER ASSESSMENT HISTORY PHASE 2
    tempGemCan: function tempGemCan() {
      return this.$userInfo.isCustomerAdministrator && this.$company.info.companyId === 'a5ffbdc0-41d2-4e7f-8ecf-e51beac57e6b';
    },
    availableItemsTypeChanged: function availableItemsTypeChanged(type) {
      this.availableItemsType = type;
    },
    truncate: function truncate(str, maxLength) {
      var suffix = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '...';
      if (typeof str !== 'string') return '';
      if (maxLength === 0) return '';
      if (str.length === -1) return str;
      if (str.length <= maxLength) return str;
      return str.slice(0, maxLength - suffix.length) + suffix;
    },
    setInitialQuoteCustomer: function setInitialQuoteCustomer() {
      this.initialQuoteCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_57___default()(this.customer);
    } // hasChangesOutsideExpandedItem(quoteDiff, expandedItemId) {
    //   // Check if changes exist outside of the expanded/editing item
    //   const itemCollections = ['labours', 'parts', 'others', 'miscs', 'sublets', 'opgs']
    //   for (const diff of quoteDiff) {
    //     const path = diff.path
    //     if (!path || path.length === 0) continue
    //     const topLevelProperty = path[0]
    //     // If change is not in item collections, it's a change we want to save
    //     if (!itemCollections.includes(topLevelProperty)) {
    //       return true
    //     }
    //     // If change is in item collections, check if it's related to the expanded item
    //     if (path.length >= 2) {
    //       const itemIndex = path[1]
    //       const collection = this.entity[topLevelProperty]
    //       if (collection && collection[itemIndex]) {
    //         const item = collection[itemIndex]
    //         // If the change is not related to the expanded item, we should save
    //         if (item.quoteItemId !== expandedItemId) {
    //           return true
    //         }
    //       }
    //     }
    //   }
    //   return false
    // }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this66 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee54() {
      var isEditInsurer, isEditVehile, _this66$autoSaveStatu, isExistingQuote, canSave, hasUnsavedChanges, ok, _t1;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context55) {
        while (1) switch (_context55.p = _context55.n) {
          case 0:
            isEditInsurer = to.name === _views_insurer_route_types__WEBPACK_IMPORTED_MODULE_68__["default"].InsurerDetail.name;
            isEditVehile = to.name === _views_vehicle_route_types__WEBPACK_IMPORTED_MODULE_69___default.a.VehicleDetail.name;
            if (!(isEditInsurer || isEditVehile)) {
              _context55.n = 1;
              break;
            }
            next();
            return _context55.a(2);
          case 1:
            if (!_this66.isCustomerCreateModifyModalActive) {
              _context55.n = 2;
              break;
            }
            _this66.toRoute = to;
            next(false);
            return _context55.a(2);
          case 2:
            // Purge empty (blank) line items on leave — they are never persisted. Skipped for
            // new quotes: they may still get the unsaved-changes prompt below, and the draft
            // must not be mutated before the user decides to stay.
            if (_this66.autoSaveActiveForQuote) {
              _this66.deleteEmptyLineItems();
            }
            if (!(!_this66.skipNextNavWarning && _this66.autoSaveEnabled && _this66.autoSaveStatus.isFailed)) {
              _context55.n = 3;
              break;
            }
            // Show navigation warning if autosave failed
            _this66.$router.replace(from.path);
            _this66.toRoute = to;
            _this66.navigationWarningMessage = 'Autosave has failed. Would you like to try saving manually before navigating away, or skip and navigate away anyway?';
            _this66.navigationWarningAction = 'trySave';
            _this66.isNavigationWarningModalActive = true;
            return _context55.a(2);
          case 3:
            _this66.skipNextNavWarning = false;
            // Skip unsaved modal only when autosave actually covers this quote — new quotes are
            // never autosaved, so they must still get the prompt or the draft is silently lost.
            if (!(!_this66.autoSaveActiveForQuote && _this66.snapshotDiff && !_this66.isSkipSave && !_this66.isSaveContinue && !_this66.readOnlyView && !_this66.skipNextUnsavedModal)) {
              _context55.n = 4;
              break;
            }
            console.log(_this66.snapshotDiff);
            _this66.$router.replace(from.path);
            _this66.toRoute = to;
            _this66.isUnsavedModalActive = true;
            return _context55.a(2);
          case 4:
            _this66.skipNextUnsavedModal = false;

            // Force a save when leaving the quote (existing quotes only).
            // Use the QuoteView.save() method so the global loading spinner is shown.
            _context55.p = 5;
            isExistingQuote = !!_this66.entity && !_this66.entity.isNew;
            canSave = isExistingQuote && !_this66.readOnlyView && !_this66.isSkipSave && !_this66.isSaveContinue;
            hasUnsavedChanges = !!_this66.snapshotDiff || !!((_this66$autoSaveStatu = _this66.autoSaveStatus) !== null && _this66$autoSaveStatu !== void 0 && _this66$autoSaveStatu.isDiffChanged);
            if (!(canSave && hasUnsavedChanges)) {
              _context55.n = 9;
              break;
            }
            // Cancel any pending autosave calls and invalidate in-flight autosave pipelines.
            // We want navigation-leave to be a single, deliberate save via QuoteView.save().
            if (_this66.autoUpdateQuoteHeader && typeof _this66.autoUpdateQuoteHeader.cancel === 'function') _this66.autoUpdateQuoteHeader.cancel();
            if (_this66.scheduleItemsSave && typeof _this66.scheduleItemsSave.cancel === 'function') _this66.scheduleItemsSave.cancel();

            // Invalidate any already-started autosave promises so their callbacks won't clobber state.
            _this66.headerAutosaveToken += 1;
            _this66.headerAutosaveInFlight = false;
            if (_this66.stopQuoteItemsEditDeferMonitor) _this66.stopQuoteItemsEditDeferMonitor();

            // Clear autosave "saving" flag since we're taking over with a manual save.
            if (_this66.setAutoSaveState) _this66.setAutoSaveState({
              isSaving: false
            });
            _context55.n = 6;
            return _this66.save(false, false, false, true);
          case 6:
            ok = _context55.v;
            if (ok) {
              _context55.n = 9;
              break;
            }
            if (!_this66.isCustomerCreateModifyModalActive) {
              _context55.n = 7;
              break;
            }
            _this66.toRoute = to;
            next(false);
            return _context55.a(2);
          case 7:
            if (_this66.leaveWithUnsavedErrors) {
              _context55.n = 8;
              break;
            }
            // Save failed (e.g. validation errors) — ask user if they want to leave anyway
            next(false);
            _this66.toRoute = to;
            _this66.navigationWarningMessage = 'There are errors that could not be saved. Would you like to leave without saving, or stay to fix the errors?';
            _this66.navigationWarningAction = 'leaveWithErrors';
            _this66.isNavigationWarningModalActive = true;
            return _context55.a(2);
          case 8:
            // User already chose to leave with unsaved errors — reset flag and fall through to next()
            _this66.leaveWithUnsavedErrors = false;
          case 9:
            _context55.n = 11;
            break;
          case 10:
            _context55.p = 10;
            _t1 = _context55.v;
            // If the forced save throws, keep the user on the quote.
            console.error('Forced save on navigation failed:', _t1);
            next(false);
            return _context55.a(2);
          case 11:
            _this66.setReturnRoute({});
            _this66.clearSessionStorage();
            _this66.clearSnapshots(from.params.quoteId);
            _this66.clearHeaders();
            _this66.clearInvoiceState();
            next();
          case 12:
            return _context55.a(2);
        }
      }, _callee54, null, [[5, 10]]);
    }))();
  },
  beforeRouteUpdate: function beforeRouteUpdate(to, from, next) {
    var _this67 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee55() {
      var isWithinQuote, isWithinQuoteGroup, isPartsControlRoute, isQuoteBuilderRoute, isFromQuoteBuilder, isToQuoteHeader, _this67$autoSaveStatu, isExistingQuote, canSave, hasUnsavedChanges, saveStatus, imageIds, attachments, count;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context56) {
        while (1) switch (_context56.n) {
          case 0:
            console.log('beforeRouteUpdate');
            if (!_this67.isCustomerCreateModifyModalActive) {
              _context56.n = 1;
              break;
            }
            _this67.toRoute = to;
            next(false);
            return _context56.a(2);
          case 1:
            isWithinQuote = _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].hasOwnProperty(to.name) && to.params.quoteId === from.params.quoteId;
            isWithinQuoteGroup = _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].hasOwnProperty(to.name) && to.params.quoteId !== from.params.quoteId;
            isPartsControlRoute = to.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuotePartsControl.name;
            isQuoteBuilderRoute = to.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
            isFromQuoteBuilder = from.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteBuilder.name;
            isToQuoteHeader = to.name === _route_types__WEBPACK_IMPORTED_MODULE_52__["default"].QuoteHeader.name;
            if (!isWithinQuote) {
              _context56.n = 8;
              break;
            }
            console.log('isNextRouteWithinQuote');

            // Leaving the builder for ANY other tab: purge blank new lines and revert emptied
            // synced lines — they are never persisted. Must run before the snapshotDiff checks
            // below so they don't register as unsaved changes. Skipped for new quotes so the
            // draft isn't mutated before the unsaved-changes prompt.
            if (isFromQuoteBuilder && _this67.autoSaveActiveForQuote) {
              _this67.deleteEmptyLineItems();
            }

            // Hard save when navigating from the quoting builder back to the header
            if (!(isFromQuoteBuilder && isToQuoteHeader)) {
              _context56.n = 3;
              break;
            }
            isExistingQuote = !!_this67.entity && !_this67.entity.isNew;
            canSave = isExistingQuote && !_this67.readOnlyView && !_this67.isSkipSave && !_this67.isSaveContinue;
            hasUnsavedChanges = !!_this67.snapshotDiff || !!((_this67$autoSaveStatu = _this67.autoSaveStatus) !== null && _this67$autoSaveStatu !== void 0 && _this67$autoSaveStatu.isDiffChanged);
            if (!(canSave && hasUnsavedChanges)) {
              _context56.n = 2;
              break;
            }
            // Cancel any pending autosave calls and invalidate in-flight pipelines
            if (_this67.autoUpdateQuoteHeader && typeof _this67.autoUpdateQuoteHeader.cancel === 'function') _this67.autoUpdateQuoteHeader.cancel();
            if (_this67.scheduleItemsSave && typeof _this67.scheduleItemsSave.cancel === 'function') _this67.scheduleItemsSave.cancel();
            _this67.headerAutosaveToken += 1;
            _this67.headerAutosaveInFlight = false;
            if (_this67.stopQuoteItemsEditDeferMonitor) _this67.stopQuoteItemsEditDeferMonitor();
            if (_this67.setAutoSaveState) _this67.setAutoSaveState({
              isSaving: false
            });
            _context56.n = 2;
            return _this67.save(false, false, false, true);
          case 2:
            next();
            return _context56.a(2);
          case 3:
            if (!((isPartsControlRoute || isQuoteBuilderRoute) && _this67.snapshotDiff)) {
              _context56.n = 6;
              break;
            }
            _context56.n = 4;
            return _this67.save();
          case 4:
            saveStatus = _context56.v;
            if (!_this67.isCustomerCreateModifyModalActive) {
              _context56.n = 5;
              break;
            }
            _this67.toRoute = to;
            next(false);
            return _context56.a(2);
          case 5:
            if (!saveStatus && !_this67.$licenceExpired) {
              _this67.$notification.error('Error', 'Save failed. Save the quote before making changes in ' + to.name);
            }
            next();
            _context56.n = 7;
            break;
          case 6:
            next();
          case 7:
            _context56.n = 14;
            break;
          case 8:
            if (!isWithinQuoteGroup) {
              _context56.n = 14;
              break;
            }
            if (!(!_this67.autoSaveActiveForQuote && _this67.snapshotDiff && !_this67.isSkipSave && !_this67.isSaveContinue && !_this67.readOnlyView)) {
              _context56.n = 9;
              break;
            }
            console.log('switch', _this67.snapshotDiff);
            _this67.$router.replace(from.path);
            _this67.toRoute = to;
            _this67.isUnsavedModalActive = true;
            _context56.n = 14;
            break;
          case 9:
            // Switch quote without changing route
            console.log('switch');
            _this67.$showSpinner();
            _this67.setPreviousQuoteId(from.params.quoteId);
            _this67.isSkipSave = false;
            _this67.toRoute = null;
            _this67.clearSessionStorage();
            _this67.clearSnapshots(from.params.quoteId);
            // Only clear vehicle/customer/insurer headers when coming from outside the quote
            // module (e.g. quote list). Copy quote and new additional navigate from within a
            // quote route and pre-load their own headers, so clearing here would wipe freshly-
            // fetched data.
            if (!_route_types__WEBPACK_IMPORTED_MODULE_52__["default"].hasOwnProperty(from.name)) {
              _this67.clearHeaders();
            }
            _this67.clearInvoiceState();
            _context56.n = 10;
            return _this67.getStoreItem(to.params.quoteId);
          case 10:
            _context56.n = 11;
            return _this67.getEntity(false, false, to.params.quoteId);
          case 11:
            _context56.n = 12;
            return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getImageIds(_this67.entity.quoteId);
          case 12:
            imageIds = _context56.v;
            _this67.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].ImageCountChanged, imageIds.length);
            _context56.n = 13;
            return _QuoteService__WEBPACK_IMPORTED_MODULE_66__["default"].getQuoteAttachments(_this67.entity.quoteId);
          case 13:
            attachments = _context56.v;
            count = Object.values(attachments.data).reduce(function (total, row) {
              return total + Object.values(row.quoteAttachments).length;
            }, 0);
            _this67.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_55__["EventHubTypes"].DocumentCountChanged, count);
            _this67.$v.entity.$reset();
            if (!_this67.entity.isNew) {
              // console.log('switch hhh')
              _this67.setReturnRoute({});
            }
            _this67.$hideSpinner();
            next();
            _this67.setPreviousQuoteId('');
          case 14:
            return _context56.a(2);
        }
      }, _callee55);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("section", {
    staticClass: "hero hero-header has-sticky-module-header",
    class: "has-hero-text-".concat(_vm.$theme.name, " ", "theme-".concat(_vm.$theme.name))
  }, [_c("div", {
    staticClass: "hero-body paddingless hanger"
  }, [_c("nav", {
    staticClass: "navbar"
  }, [_c("div", {
    staticClass: "navbar-brand"
  }, [_c("div", {
    staticClass: "navbar-item is-hidden-desktop"
  }, [_c("div", {
    staticClass: "field is-grouped"
  }, [_vm._t("mobile-left", function () {
    return [_vm.showToggle ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft is-primary is-light",
      class: _vm.buttonCSS,
      attrs: {
        disabled: !_vm.buttonsEnabled,
        title: "Toggle Side Menu",
        "data-tooltip": "Toggle Side Menu"
      },
      on: {
        click: _vm.toggleSide
      }
    }, [_vm._m(0)])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isDelete && !_vm.serviceError && _vm.showCalendar ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "calendar",
        title: "Calendar",
        "data-tooltip": "Calendar"
      },
      on: {
        click: _vm.calendar
      }
    }, [_vm._m(1)])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isAdd && !_vm.serviceError && _vm.showNew ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "addnew",
        title: "Add New",
        "data-tooltip": "Add New"
      },
      on: {
        click: _vm.addNew
      }
    }, [_vm._m(2)])]) : _vm._e(), _vm.access.isPrint && !_vm.serviceError && _vm.showPrint ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "print",
        title: "Print",
        "data-tooltip": "Print"
      },
      on: {
        click: _vm.print
      }
    }, [_vm._m(3)])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isDelete && !_vm.serviceError && _vm.showDelete ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "delete",
        title: "Delete",
        "data-tooltip": "Delete"
      },
      on: {
        click: _vm.trash
      }
    }, [_vm._m(4)])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showSave && !(_vm.showAutoSave && _vm.entity && !_vm.entity.isNew) ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "save",
        title: "Save",
        "data-tooltip": "Save"
      },
      on: {
        click: _vm.save
      }
    }, [_vm._m(5)])]) : _vm._e(), _vm.showCancel ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "cancel",
        title: "Go Back",
        "data-tooltip": "Go Back"
      },
      on: {
        click: _vm.cancel
      }
    }, [_vm._m(6)])]) : _vm._e(), _vm.showLock ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button tooltip is-tooltip-topleft",
      class: _vm.buttonCSS,
      attrs: {
        id: "lock",
        disabled: _vm.isSaving || _vm.licenceExpired,
        "data-tooltip": _vm.licenceExpired ? "Disabled, as your licence has expired" : "Lock Manage"
      },
      on: {
        click: function click($event) {
          !_vm.isSaving && !_vm.licenceExpired && _vm.toggleReadOnly();
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "msr"
    }, [_vm._v(_vm._s(_vm.entity.readOnly ? "lock" : "lock_open"))])])])]) : _vm._e()];
  })], 2)]), _vm._m(7)]), _c("div", {
    staticClass: "navbar-start is-hidden-touch",
    attrs: {
      id: "detail-nav-menu"
    }
  }, [_vm.showToggle ? _c("div", {
    staticClass: "navbar-item"
  }, [_c("h1", {
    staticClass: "title"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined",
    class: _vm.buttonCSS,
    attrs: {
      disabled: !_vm.buttonsEnabled
    },
    on: {
      click: _vm.toggleSide
    }
  }, [_vm._m(8)])])]) : _vm._e(), _c("div", {
    staticClass: "navbar-item"
  }, [_vm._t("desktop-left")], 2)]), _vm.$slots["center"] ? _c("div", {
    staticClass: "navbar-item has-text-centered"
  }, [_vm._t("center")], 2) : _vm._e(), _c("div", {
    staticClass: "navbar-end is-hidden-touch"
  }, [_c("div", {
    staticClass: "navbar-item"
  }, [_c("div", {
    staticClass: "field is-grouped"
  }, [_vm._t("desktop-right", function () {
    return [!_vm.licenceExpired && _vm.access.isAdd && !_vm.serviceError && _vm.showCalendar ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-primary",
      class: _vm.buttonCSS,
      attrs: {
        id: "calendar"
      },
      on: {
        click: _vm.calendar
      }
    }, [_vm._m(9), _c("span", [_vm._v("Calendar")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isAdd && !_vm.serviceError && _vm.showNew ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-success",
      class: _vm.buttonCSS,
      attrs: {
        id: "addnew"
      },
      on: {
        click: _vm.addNew
      }
    }, [_vm._m(10), _c("span", [_vm._v("New")])])]) : _vm._e(), _vm.access.isPrint && !_vm.serviceError && _vm.showPrint && false ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-primary",
      class: _vm.buttonCSS,
      attrs: {
        id: "preview"
      },
      on: {
        click: _vm.print
      }
    }, [_vm._m(11), _c("span", [_vm._v("Preview")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isDelete && !_vm.serviceError && _vm.showDelete && false ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-danger",
      class: _vm.buttonCSS,
      attrs: {
        id: "delete"
      },
      on: {
        click: _vm.trash
      }
    }, [_vm._m(12), _c("span", [_vm._v("Delete")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showConvert ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-primary",
      class: _vm.buttonCSS,
      attrs: {
        id: "convert"
      },
      on: {
        click: _vm.convert
      }
    }, [_vm._m(13), _c("span", [_vm._v("Convert")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showSave && _vm.autoSaveEnabled && _vm.entity && !_vm.entity.isNew ? _c("div", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: _vm.autoSaveStatus,
          enabled: true
        },
        expression: "{ content: autoSaveStatus, enabled: true }"
      }],
      staticClass: "control is-flex is-flex-direction-row is-align-items-center mr-2"
    }, [_c("span", {
      staticClass: "material-symbols-rounded mr-2",
      class: {
        loading: _vm.isSaving && !_vm.hasAutoSaveFailed,
        "has-text-grey": (_vm.isSaving || _vm.unsavedChanges) && !_vm.hasAutoSaveFailed,
        "has-text-danger": _vm.hasAutoSaveFailed,
        "has-text-grey-light": !_vm.isSaving && !_vm.hasAutoSaveFailed && !_vm.unsavedChanges
      }
    }, [_vm._v(" " + _vm._s(_vm.isSaving ? "sync" : _vm.hasAutoSaveFailed ? "cloud_off" : "cloud_done") + " ")])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showSave && _vm.autoSaveLocked ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: _vm.hasAutoSaveFailed ? "Autosave failed - Click to save manually" : "",
          enabled: _vm.hasAutoSaveFailed
        },
        expression: "{ content: hasAutoSaveFailed ? 'Autosave failed - Click to save manually' : '', enabled: hasAutoSaveFailed }"
      }],
      staticClass: "button is-success",
      class: [_vm.buttonCSS],
      attrs: {
        id: "save"
      },
      on: {
        click: _vm.save
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "msr msr-18px"
    }, [_vm._v(_vm._s(_vm.hasAutoSaveFailed ? "cloud_off" : "save"))])]), _c("span", [_vm._v(_vm._s(_vm.hasAutoSaveFailed ? "Save Manually" : _vm.entity && _vm.entity.isNew ? "Create" : "Save"))])])]) : _vm._e(), _vm.showCancel ? _c("p", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-primary",
      class: _vm.buttonCSS,
      attrs: {
        id: "cancel"
      },
      on: {
        click: _vm.cancel
      }
    }, [_vm._m(14), _c("span", [_vm._v("Back")])])]) : _vm._e()];
  }), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasMoreActions,
      expression: "hasMoreActions"
    }],
    staticClass: "button px-2",
    attrs: {
      name: "headerMoreButtons"
    },
    on: {
      mouseenter: _vm.handleMoreButtonHover
    }
  }, [_vm._m(15)])], 2)])])])]), _vm._t("additional-content", function () {
    return [_vm.hasMoreActions ? _c("tippy", {
      ref: "tippyHeaderButtons",
      attrs: {
        to: "headerMoreButtons",
        trigger: "click",
        arrow: "",
        theme: "".concat(_vm.$theme.name),
        interactive: true,
        "max-width": 500
      }
    }, [_c("div", {
      staticClass: "menu more-menu"
    }, [_c("ul", {
      staticClass: "menu-list"
    }, [!_vm.licenceExpired && !_vm.serviceError && _vm.showCreditorStatement ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "viewCreditorStatement"
      },
      on: {
        click: _vm.viewCreditorStatement
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("request_page")])]), _c("span", [_vm._v("View Creditor Statement")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showDebtorStatement ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "viewDebtorStatement"
      },
      on: {
        click: _vm.viewDebtorStatement
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("request_page")])]), _c("span", [_vm._v("View Debtor Statement")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showAdvancePaymentEntry ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "viewAdvancePaymentEntry"
      },
      on: {
        click: _vm.viewAdvancePaymentEntry
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("request_page")])]), _c("span", [_vm._v("Advance Payment Entry")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showAdvanceReceiptEntry ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "viewAdvanceReceiptEntry"
      },
      on: {
        click: _vm.viewAdvanceReceiptEntry
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("request_page")])]), _c("span", [_vm._v("Advance Receipt Entry")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showFactorInvoice ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "factorInvoice"
      },
      on: {
        click: _vm.factorInvoice
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("receipt_long")])]), _c("span", [_vm._v("Factor Invoices")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showFactorSelectedInvoice ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "factorSelectedInvoice"
      },
      on: {
        click: _vm.factorSelectedInvoice
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("receipt_long")])]), _c("span", [_vm._v("Factor Selected Invoices")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showBankUnDepositedFunds ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "viewBankUnDepositedFunds"
      },
      on: {
        click: _vm.viewBankUnDepositedFunds
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("account_balance")])]), _c("span", [_vm._v("Bank Un-Deposited Funds")])])]) : _vm._e(), _vm.access.isPrint && !_vm.serviceError && _vm.showPrint ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "preview"
      },
      on: {
        click: _vm.print
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("print")])]), _c("span", [_vm._v("Preview")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showLock ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      class: {
        "has-text-grey-light": _vm.isSaving
      },
      attrs: {
        id: "lock"
      },
      on: {
        click: function click($event) {
          !_vm.isSaving && _vm.toggleReadOnly();
        }
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v(_vm._s(_vm.entity.readOnly ? "lock" : "lock_open"))])]), _c("span", [_vm._v(_vm._s(_vm.entity.readOnly ? "Unlock" : "Lock"))])])]) : _vm._e(), !_vm.serviceError && _vm.showPricePartsMsg ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "priceparts"
      },
      on: {
        click: _vm.viewPricePartsMsg
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("chat")])]), _c("span", [_vm._v("View Price Parts Messages")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showAdditionalQuoteButtons && _vm.showAdditionalQuote ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center pl-1",
      attrs: {
        id: "new_additional_quote"
      },
      on: {
        click: _vm.newAdditionalQuote
      }
    }, [_c("span", {
      staticClass: "msr msr-24px mr-1",
      staticStyle: {
        "font-size": "20px"
      }
    }, [_vm._v(" add ")]), _c("span", [_vm._v("New Additional Quote")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showAdditionalQuoteButtons ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center pl-1",
      attrs: {
        id: "copy_quote"
      },
      on: {
        click: _vm.copyQuote
      }
    }, [_c("span", {
      staticClass: "msr msr-24px mr-1",
      staticStyle: {
        "font-size": "20px"
      }
    }, [_vm._v(" content_copy ")]), _c("span", [_vm._v("Copy Quote")])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showAdditionalQuoteButtons ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center pl-1",
      attrs: {
        id: "export_quote"
      },
      on: {
        click: _vm.exportQuote
      }
    }, [_c("span", {
      staticClass: "msr msr-24px mr-1",
      staticStyle: {
        "font-size": "20px"
      }
    }, [_vm._v(" file_export ")]), _c("span", [_vm._v("Export Quote")])])]) : _vm._e(), !_vm.licenceExpired && !_vm.serviceError && _vm.showQuoteTemplate ? _c("li", [!_vm.quoteTemplateDisabled ? _c("div", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "quoteTemplate"
      },
      on: {
        click: _vm.saveTemplateFromQuote
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("add")])]), _c("span", [_vm._v("Save as Template")])])]) : _c("div", [_c("button", {
      staticClass: "is-flex is-align-items-center button is-white is-fullwidth pl-0 is-justify-content-flex-start",
      attrs: {
        id: "quoteTemplate",
        disabled: _vm.quoteTemplateDisabled
      }
    }, [_c("span", {
      staticClass: "icon ml-0"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("print")])]), _c("span", [_vm._v("Save as Template")])])])]) : _vm._e(), !_vm.licenceExpired && _vm.access.isDelete && !_vm.serviceError && _vm.showDelete && _vm.showPrint ? _c("div", {
      staticClass: "is-divider"
    }) : _vm._e(), !_vm.licenceExpired && _vm.access.isDelete && !_vm.serviceError && _vm.showDelete ? _c("li", [_c("a", {
      staticClass: "has-text-danger is-flex is-align-items-center",
      attrs: {
        id: "delete"
      },
      on: {
        click: _vm.trash
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("delete")])]), _c("span", [_vm._v("Delete")])])]) : _vm._e(), _vm._t("more-menu-items"), !_vm.licenceExpired && _vm.access.isEdit && !_vm.serviceError && _vm.showSave && _vm.autoSaveEnabled && _vm.manualSaveEnabled && _vm.entity && !_vm.entity.isNew && !_vm.hasAutoSaveFailed ? _c("li", [_c("a", {
      staticClass: "is-flex is-align-items-center",
      attrs: {
        id: "manualSave"
      },
      on: {
        click: _vm.manualSave
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "msr msr-20px"
    }, [_vm._v("save")])]), _c("span", [_vm._v("Save")])])]) : _vm._e()], 2)])]) : _vm._e()];
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("menu")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-calendar"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("add")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("print")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("delete")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("save")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr"
  }, [_vm._v("arrow_back")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "navbar-burger burger",
    attrs: {
      "data-target": "action-button-menu"
    }
  }, [_c("span"), _c("span"), _c("span")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("menu")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-calendar mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-18px"
  }, [_vm._v("add")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-18px"
  }, [_vm._v("print")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-18px"
  }, [_vm._v("delete")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-swap-horizontal mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-18px"
  }, [_vm._v("arrow_back")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-36px"
  }, [_vm._v("more_vert")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "module-subnav-container"
  }, [_c("div", {
    staticClass: "field is-grouped is-hidden-widescreen mobile-nav"
  }, [_vm._l(_vm.visibleMenuItems, function (item, index) {
    return _c("p", {
      key: "mobile-".concat(index),
      staticClass: "control"
    }, [item.route ? _c("router-link", {
      staticClass: "button tooltip is-tooltip-bottom is-small",
      class: {
        "is-disabled": item.disabled
      },
      attrs: {
        to: item.route,
        "active-class": "is-active",
        exact: item.exact !== false,
        title: item.label,
        "data-tooltip": item.label
      },
      nativeOn: {
        click: function click($event) {
          return _vm.handleItemClick(item, $event);
        }
      }
    }, [_c("span", {
      staticClass: "icon",
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_c("span", {
      staticClass: "mso mso-20px"
    }, [_vm._v(" " + _vm._s(item.icon || _vm.getDefaultIcon(item.label)) + " ")])])]) : _c("a", {
      staticClass: "button tooltip is-tooltip-bottom is-small",
      class: {
        "is-disabled": item.disabled
      },
      attrs: {
        title: item.label,
        "data-tooltip": item.label
      },
      on: {
        click: function click($event) {
          return _vm.handleItemClick(item, $event);
        }
      }
    }, [_c("span", {
      staticClass: "icon",
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_c("span", {
      staticClass: "mso mso-20px"
    }, [_vm._v(" " + _vm._s(item.icon || _vm.getDefaultIcon(item.label)) + " ")])])])], 1);
  }), _vm.hasMoreItems ? _c("p", {
    staticClass: "control"
  }, [_vm._m(0)]) : _vm._e()], 2), _c("ul", {
    staticClass: "menu-list horizontal is-hidden-mobile is-hidden-tablet-only is-hidden-desktop-only"
  }, [_vm._l(_vm.visibleMenuItems, function (item, index) {
    return _c("li", {
      key: index
    }, [item.route ? _c("router-link", {
      class: {
        "is-disabled": item.disabled
      },
      attrs: {
        to: item.route,
        "active-class": "is-active",
        exact: item.exact !== false
      },
      nativeOn: {
        click: function click($event) {
          $event.preventDefault();
          return _vm.handleItemClick(item, $event);
        }
      }
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center is-justify-content-space-between"
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center"
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-20px"
    }, [_vm._v(" " + _vm._s(item.icon || _vm.getDefaultIcon(item.label)) + " ")])]), _c("span", {
      staticClass: "ml-1",
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])])]) : _c("a", {
      class: {
        "is-disabled": item.disabled
      },
      on: {
        click: function click($event) {
          return _vm.handleItemClick(item, $event);
        }
      }
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center is-justify-content-space-between"
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center"
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-20px mr-2"
    }, [_vm._v(" " + _vm._s(item.icon || _vm.getDefaultIcon(item.label)) + " ")])]), _c("span", {
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])])]), _vm._t("menu-item-actions", null, {
      item: item,
      handleAction: _vm.handleCustomAction
    })], 2);
  }), _vm.hasMoreItems ? _c("li", {
    staticClass: "is-flex"
  }, [_c("div", {
    staticClass: "button is-small px-4 is-align-self-center moreMenuButton",
    class: "has-hero-button-text-".concat(_vm.$theme.name),
    staticStyle: {
      border: "none"
    },
    attrs: {
      name: "moreMenuButton"
    }
  }, [_vm._m(1)])]) : _vm._e()], 2), _vm.hasMoreItems ? _c("tippy", {
    ref: "tippyMoreMenu",
    attrs: {
      to: "moreMenuButton",
      trigger: "click",
      arrow: "",
      interactive: true,
      theme: "".concat(_vm.$theme.name),
      "max-width": 500
    }
  }, [_c("div", {
    staticClass: "menu more-menu"
  }, [_c("ul", {
    staticClass: "menu-list"
  }, _vm._l(_vm.visibleMoreItems, function (item, index) {
    return _c("li", {
      key: index
    }, [item.route ? _c("router-link", {
      class: {
        "is-disabled": item.disabled
      },
      attrs: {
        to: item.route,
        "active-class": "is-active",
        exact: item.exact !== false
      },
      nativeOn: {
        click: function click($event) {
          return _vm.handleMoreItemClick(item);
        }
      }
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center"
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "mso mso-20px"
    }, [_vm._v(_vm._s(item.icon || _vm.getDefaultIcon(item.label)))])]), _c("span", {
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])]) : _c("a", {
      staticClass: "is-flex is-align-items-center",
      class: {
        "is-disabled": item.disabled
      },
      on: {
        click: function click($event) {
          return _vm.handleMoreItemClick(item);
        }
      }
    }, [_c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "mso mso-20px"
    }, [_vm._v(_vm._s(item.icon || _vm.getDefaultIcon(item.label)))])]), _c("span", {
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])], 1);
  }), 0)])]) : _vm._e(), _vm.hasMoreItems ? _c("tippy", {
    ref: "tippyMobileMoreMenu",
    attrs: {
      to: "mobileMoreMenuButton",
      trigger: "click",
      arrow: "",
      interactive: true,
      "max-width": 500
    }
  }, [_c("div", {
    staticClass: "menu more-menu"
  }, [_c("ul", {
    staticClass: "menu-list"
  }, _vm._l(_vm.visibleMoreItems, function (item, index) {
    return _c("li", {
      key: index
    }, [item.route ? _c("router-link", {
      class: {
        "is-disabled": item.disabled
      },
      attrs: {
        to: item.route,
        "active-class": "is-active",
        exact: item.exact !== false
      },
      nativeOn: {
        click: function click($event) {
          return _vm.handleMobileMoreItemClick(item);
        }
      }
    }, [_c("span", {
      staticClass: "is-flex is-align-items-center"
    }, [item.icon ? _c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "mso mso-20px mr-2"
    }, [_vm._v(_vm._s(item.icon))])]) : _vm._e(), _c("span", {
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])]) : _c("a", {
      staticClass: "is-flex is-align-items-center",
      class: {
        "is-disabled": item.disabled
      },
      on: {
        click: function click($event) {
          return _vm.handleMobileMoreItemClick(item);
        }
      }
    }, [item.icon ? _c("span", {
      staticClass: "icon pr-3"
    }, [_c("span", {
      staticClass: "mso mso-20px mr-2"
    }, [_vm._v(_vm._s(item.icon))])]) : _vm._e(), _c("span", {
      class: [item.badgeClass, {
        "has-new-content": item.hasNewContent
      }],
      attrs: {
        "data-badge": item.badge
      }
    }, [_vm._v(_vm._s(item.label))])])], 1);
  }), 0)])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("a", {
    staticClass: "button is-small",
    attrs: {
      name: "mobileMoreMenuButton"
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px"
  }, [_vm._v("more_vert")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px"
  }, [_vm._v("more_vert")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.bannerVisible ? _c("div", {
    staticClass: "quote-banner mb-2",
    class: _vm.bannerClass,
    attrs: {
      id: "quote-banner"
    }
  }, [_c("div", {
    staticClass: "quote-banner-icon"
  }, [_c("span", {
    staticClass: "material-symbols-rounded mr-8"
  }, [_vm._v(_vm._s(_vm.iconClass))])]), _c("div", {
    staticClass: "quote-banner-content"
  }, [_c("span", {
    staticClass: "has-text-weight-bold is-size-8"
  }, [_vm._v(_vm._s(_vm.title))]), _c("span", {
    staticClass: "is-size-7"
  }, [_vm._v(_vm._s(_vm.message))])])]) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("div", {
    staticClass: "model-content"
  }, [_c("div", {
    staticClass: "modal-card"
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._t("text-title")], 2)]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("article", {
    staticClass: "message is-info"
  }, [_c("div", {
    staticClass: "message-body"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quote Labour Times")]), _c("span", {
    staticClass: "has-text-weight-bold has-text-primary"
  }, [_vm._v(_vm._s(_vm.quoteTimesType))])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vehicle Body Style")]), _c("span", {
    staticClass: "has-text-weight-bold has-text-primary"
  }, [_vm._v(_vm._s(_vm.bodyShape))])])])])]), _vm.finishFetchingTemplates && !_vm.isTemplateListNonEmpty ? _c("div", {
    staticClass: "field"
  }, [_c("span", {
    staticClass: "has-text-danger is-italic"
  }, [_c("i", {
    staticClass: "mdi mdi-alert-outline"
  }), _vm._v(" No templates available. Please contact your admin to create a new template under "), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Quote > Quote Template.")])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v(_vm._s(_vm.label))]), _c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedTemplate,
      expression: "selectedTemplate"
    }],
    attrs: {
      disabled: _vm.finishFetchingTemplates && !_vm.isTemplateListNonEmpty
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedTemplate = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.templates, function (template, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: template
      }
    }, [_vm._v(_vm._s(template.name))]);
  })], 2)])])]), _c("footer", {
    staticClass: "modal-card-foot",
    style: "justify-content: flex-".concat(_vm.buttonLocation)
  }, [_c("button", {
    staticClass: "button is-primary",
    attrs: {
      disabled: !_vm.isTemplateSelected
    },
    on: {
      click: _vm.add
    }
  }, [_vm._v("Apply")]), _c("button", {
    staticClass: "button",
    on: {
      click: _vm.close
    }
  }, [_vm._v("Close")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    attrs: {
      active: _vm.isActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (sms, index) {
    return _c("tr", {
      key: sms.id,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(sms, index, $event);
        }
      }
    }, [_c("td", {
      on: {
        dblclick: function dblclick($event) {
          return _vm.editMessage(sms, index);
        }
      }
    }, [_vm._v(_vm._s(sms.message))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        "data-tooltip": "Click to delete"
      },
      on: {
        click: function click($event) {
          return _vm.deleteMessage(sms.id, index, sms.message);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2), _vm.isEnableSave ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message :")]), _c("p", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }, {
      name: "model",
      rawName: "v-model",
      value: _vm.smsMessage,
      expression: "smsMessage"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": !_vm.isMessageEntered
    },
    attrs: {
      id: "smsMessage",
      placeholder: "Enter New Message Here..."
    },
    domProps: {
      value: _vm.smsMessage
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.smsMessage = $event.target.value;
      }, _vm.enterMessage]
    }
  }), _vm._v(" "), !_vm.isMessageEntered && _vm.isEnableSave ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Message is required.")]) : _vm._e()]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Insert : ")]), _c("div", [_c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[NAME]");
      }
    }
  }, [_c("span", [_vm._v("Name")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Rego"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[REGO]");
      }
    }
  }, [_c("span", [_vm._v("Rego")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Excess"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EXCESS]");
      }
    }
  }, [_c("span", [_vm._v("Excess")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated Start Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST START DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated Start Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated End Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST END DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated End Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Shop Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[SHOPNAME]");
      }
    }
  }, [_c("span", [_vm._v("Shop Name")])])])]) : _vm._e(), _vm.entity ? _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]) : _vm._e(), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Message Template")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Message Template "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.message)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 45,
      "min-height": 85,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v(_vm._s(_vm.smsModalHeader))])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_vm.isSendSmsModalActive ? _c("sms-send", {
    ref: "smsSend",
    attrs: {
      active: _vm.isSendSmsModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSendSmsModalActive = $event;
      },
      "smsdetails-entered": _vm.smsDetailsEntered
    },
    model: {
      value: _vm.smsDetails,
      callback: function callback($$v) {
        _vm.smsDetails = $$v;
      },
      expression: "smsDetails"
    }
  }) : _vm._e(), _vm.isSmsMessageModalActive ? _c("sms-message", {
    ref: "smsMessage",
    attrs: {
      active: _vm.isSmsMessageModalActive,
      "enable-save": _vm.enableSave
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSmsMessageModalActive = $event;
      },
      back: _vm.backToSmsSend,
      "save-button": _vm.setEnableSave,
      close: _vm.close
    }
  }) : _vm._e()], 1), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      width: "100%"
    },
    attrs: {
      align: "right"
    }
  }, [_vm.isSendSms ? _c("div", [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Edit message template"
    },
    on: {
      click: function click($event) {
        return _vm.editTemplate();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-18px"
  })]), _c("span", [_vm._v("Edit Template")])]), _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      disabled: !_vm.enableSend,
      "data-tooltip": "Send"
    },
    on: {
      click: function click($event) {
        return _vm.send();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-send mdi-18px"
  })]), _c("span", [_vm._v("Send")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.close(true);
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]), _c("span", [_vm._v("Close")])])]) : _c("div", [_vm.enableSave ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save changes"
    },
    on: {
      click: function click($event) {
        return _vm.save();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save mdi-18px"
  })]), _c("span", [_vm._v("Save")])]) : _vm._e(), _vm.enableSave ? _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel changes"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Cancel")])]) : _vm._e(), !_vm.enableSave ? _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Add new message template"
    },
    on: {
      click: function click($event) {
        return _vm.add();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-18px"
  })]), _c("span", [_vm._v("New Message")])]) : _vm._e(), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Back to Send SMS"
    },
    on: {
      click: _vm.back
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-arrow-left-bold mdi-18px"
  })]), _c("span", [_vm._v("Back")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.close(false);
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]), _c("span", [_vm._v("Close")])])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    attrs: {
      active: _vm.isActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Customer Name")]), _c("span", [_vm._v(_vm._s(_vm.smsDetails.customer))])])]), _c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Rego")]), _c("span", [_vm._v(_vm._s(_vm.smsDetails.rego))])])])]), _c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Mobile")]), _c("p", {
    staticClass: "control has-icons-left is-expanded"
  }, [_c("the-mask", {
    directives: [{
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }],
    staticClass: "input",
    class: {
      "is-danger": !_vm.isValidMobile
    },
    attrs: {
      mask: _vm.phoneNoMask,
      tokens: _vm.phoneNoTokens,
      placeholder: "Country Code + Number"
    },
    on: {
      input: _vm.enterMobile
    },
    model: {
      value: _vm.smsDetails.mobile,
      callback: function callback($$v) {
        _vm.$set(_vm.smsDetails, "mobile", $$v);
      },
      expression: "smsDetails.mobile"
    }
  }), _vm._m(0), !_vm.isValidMobile ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Mobile is required")]) : _vm._e()], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message")]), _c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      "track-by": "message",
      label: "message",
      placeholder: "Select Message",
      options: _vm.messages,
      loading: _vm.isMessageLoading,
      searchable: true,
      "allow-empty": true,
      "options-limit": _vm.messageFilter.pageSize
    },
    on: {
      select: _vm.selectMessage,
      remove: _vm.removeMessage
    },
    model: {
      value: _vm.selectedMessage,
      callback: function callback($$v) {
        _vm.selectedMessage = $$v;
      },
      expression: "selectedMessage"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.smsMessage,
      expression: "smsMessage"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": !_vm.isMessageEntered
    },
    attrs: {
      rows: "8",
      placeholder: "Enter Cutom Message Here..."
    },
    domProps: {
      value: _vm.smsMessage
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.smsMessage = $event.target.value;
      }, _vm.enterMessage]
    }
  }), _vm._v(" "), !_vm.isMessageEntered ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Message is required.")]) : _vm._e()])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-phone mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13__);














var render = function render() {
  var _vm$jobStages;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("fieldset", {
    staticClass: "quote-detail-fieldset",
    attrs: {
      disabled: _vm.$licenceExpired
    }
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v(" Details "), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.innerValue.isNew,
      expression: "!innerValue.isNew"
    }],
    staticClass: "icon has-text-info tooltip is-tooltip-info",
    class: [_vm.canChangeReadOnly && !_vm.$licenceExpired ? "readonly-pointer" : ""],
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : _vm.innerValue.readOnly ? "Quote is locked" : "Quote is unlocked"
    },
    on: {
      click: function click($event) {
        return _vm.toogleReadOnly();
      }
    }
  }, [_c("i", {
    staticClass: "icon mdi",
    class: [_vm.innerValue.readOnly ? "mdi-lock-outline" : "mdi-lock-open-outline"]
  })])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "tags"
  }, [_vm.invoice ? _c("span", {
    staticClass: "tag is-success is-pulled-right"
  }, [_vm._v("Inv " + _vm._s("".concat(_vm.invoice.prefix).concat(_vm.invoice.invoiceNo).concat(_vm.invoice.suffix, "/").concat(_vm.invoice.invoiceType)) + " dated " + _vm._s(_vm.$filters.formatDateLocale(_vm.invoice.invoiceDate, _vm.$userInfo.locale)))]) : _vm._e(), _vm.excessInvoice ? _c("span", {
    staticClass: "tag is-success is-pulled-right"
  }, [_vm._v("Excess Inv " + _vm._s("".concat(_vm.excessInvoice.prefix).concat(_vm.excessInvoice.invoiceNo).concat(_vm.excessInvoice.suffix, "/").concat(_vm.excessInvoice.invoiceType)) + " dated " + _vm._s(_vm.$filters.formatDateLocale(_vm.excessInvoice.invoiceDate, _vm.$userInfo.locale)))]) : _vm._e()])])]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quote No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      placeholder: "Quote No.",
      readonly: ""
    },
    domProps: {
      value: "".concat(_vm.innerValue.prefix).concat(_vm.innerValue.quoteNo).concat(_vm.innerValue.suffix)
    }
  })])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quote Date")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.quoteDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.quoteDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Quote Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedQuoteDate,
      callback: function callback($$v) {
        _vm.selectedQuoteDate = $$v;
      },
      expression: "selectedQuoteDate"
    }
  })], 1)]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns mb-0"
  }, [_vm._m(0), _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end py-2"
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.ntarLtarStatus,
      expression: "ntarLtarStatus"
    }],
    staticClass: "field"
  }, [_c("span", {
    staticClass: "tag is-success animate__animated animate__pulse animate__repeat-3 tooltip",
    attrs: {
      "data-tooltip": "".concat(_vm.ntarLtarStatus, " schedule and times found")
    }
  }, [_vm._v(_vm._s(_vm.ntarLtarStatus) + " Hours On")])])])]), _vm.readOnlyView ? _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.vehicle ? _vm.vehicle.rego : ""
    }
  })]), _c("div", {
    staticClass: "control",
    staticStyle: {
      "margin-top": "2.5px"
    }
  }, [_vm.selectedVehicle ? _c("span", {
    staticClass: "tag is-info is-medium"
  }, [_vm._v(_vm._s(_vm.vehicle ? _vm.vehicle.model.name.replace(/ +/g, " ") : ""))]) : _vm._e()])])]) : _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_vm.vehicles ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.vehicleId.$error
    },
    attrs: {
      id: "quote-vehicle-multiselect",
      disabled: _vm.$licenceExpired,
      "deselect-label": "Can't remove this value",
      "track-by": "vehicleId",
      label: "rego",
      placeholder: "Search By Rego...",
      options: _vm.vehicles,
      loading: _vm.isVehicleLoading,
      "internal-search": false,
      "options-limit": _vm.vehicleFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": false
    },
    on: {
      select: _vm.selectVehicle,
      remove: _vm.removeVehicle,
      "search-change": _vm.getVehicleDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "singleLabel",
      fn: function fn(_ref2) {
        var option = _ref2.option;
        return [_vm._v(" " + _vm._s(option.rego) + " "), _vm.selectedVehicle ? _c("span", {
          staticClass: "tag is-info is-pulled-right"
        }, [_vm._v(_vm._s(_vm.selectedVehicle.model))]) : _vm._e()];
      }
    }, {
      key: "option",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-pulled-right is-info"
        }, [_vm._v(" " + _vm._s(props.option.model) + " ")]), _c("span", [_vm._v(_vm._s(props.option.rego))])];
      }
    }], null, false, 4226320794),
    model: {
      value: _vm.selectedVehicle,
      callback: function callback($$v) {
        _vm.selectedVehicle = $$v;
      },
      expression: "selectedVehicle"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Vehicle not found.")])]) : _vm._e(), _vm.$v.entity && _vm.$v.entity.vehicleId.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Vehicle is required.")]) : _vm._e()], 1), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button",
    class: _vm.vehicleButtonClass,
    on: {
      click: function click($event) {
        return _vm.onEditAddVehicle();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: _vm.vehicleButtonIconClass
  })])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Insurer")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.quoteInsurer ? _vm.quoteInsurer.name : ""
    }
  })]) : _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Insurer")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_vm.insurers ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.insurerId.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Search By Name...",
      options: _vm.insurers,
      loading: _vm.isInsurerLoading,
      "internal-search": false,
      "options-limit": _vm.insurerFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": false,
      disabled: _vm.innerValue.readOnly || _vm.audanetLock || _vm.$licenceExpired
    },
    on: {
      select: _vm.selectInsurer,
      remove: _vm.removeInsurer,
      "search-change": _vm.getInsurerDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", [_vm._v(_vm._s(props.option.assetName))])];
      }
    }], null, false, 2645691248),
    model: {
      value: _vm.selectedInsurer,
      callback: function callback($$v) {
        _vm.selectedInsurer = $$v;
      },
      expression: "selectedInsurer"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Insurer not found.")])]) : _vm._e(), _vm.$v.entity && _vm.$v.entity.insurerId.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Insurer is required.")]) : _vm._e()], 1), _c("div", {
    staticClass: "control is-narrow"
  }, [_c("button", {
    staticClass: "button",
    class: _vm.insurerButtonClass,
    attrs: {
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    on: {
      click: function click($event) {
        return _vm.onEditAddInsurer();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: _vm.insurerButtonIconClass
  })])])])])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Labour Type")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.innerValue.labourType
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.labourType,
      expression: "innerValue.labourType"
    }],
    attrs: {
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "labourType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.labourTimeTypes, function (labourTime, prop) {
    return _c("option", {
      key: prop,
      domProps: {
        value: prop
      }
    }, [_vm._v(_vm._s(labourTime))]);
  }), 0)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quoter")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static is-capitalized",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.innerValue.quoter
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      placeholder: "Quoter",
      data: _vm.filteredQuoters,
      "keep-first": true,
      loading: false,
      "class-prop": "is-capitalized" + (!_vm.$v.entity.quoter.$error ? "" : " is-danger")
    },
    on: {
      input: function input($event) {
        return _vm.$v.detailGroup.$touch();
      }
    },
    model: {
      value: _vm.innerValue.quoter,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "quoter", $$v);
      },
      expression: "innerValue.quoter"
    }
  }), _vm.$v.entity && _vm.$v.entity.quoter.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Quoter is required.")]) : _vm._e()], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Job Stage")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: (_vm$jobStages = _vm.jobStages) === null || _vm$jobStages === void 0 || (_vm$jobStages = _vm$jobStages.find(function (j) {
        return j.stage === _vm.innerValue.jobStage;
      })) === null || _vm$jobStages === void 0 ? void 0 : _vm$jobStages.description
    }
  })]) : _c("div", {
    staticClass: "control is-expanded"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.jobStage,
      expression: "innerValue.jobStage"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "jobStage", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.jobStages, function (jobStage) {
    return _c("option", {
      key: jobStage.stage,
      domProps: {
        value: jobStage.stage
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatJobStage(jobStage.enumDescription)) + " ")]);
  }), 0)])])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Method")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.value.quotingMethod === _vm.quotingMethodTypes.Hour ? "Hour" : "Dollar"
    }
  })]) : _c("div", {
    staticClass: "control pt-1"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.quotingMethod,
      expression: "value.quotingMethod"
    }],
    attrs: {
      type: "radio",
      name: "rd-quotingMethod",
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    domProps: {
      value: "H",
      checked: _vm._q(_vm.value.quotingMethod, "H")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.value, "quotingMethod", "H");
      }
    }
  }), _vm._m(1)]), _c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.quotingMethod,
      expression: "value.quotingMethod"
    }],
    attrs: {
      type: "radio",
      name: "rd-quotingMethod",
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    domProps: {
      value: "D",
      checked: _vm._q(_vm.value.quotingMethod, "D")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.value, "quotingMethod", "D");
      }
    }
  }), _vm._m(2)])])])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Claim No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.claimNo,
      expression: "innerValue.claimNo"
    }],
    staticClass: "input is-uppercase",
    class: {
      "is-static": _vm.readOnlyView
    },
    attrs: {
      type: "text",
      placeholder: !_vm.readOnlyView ? "Claim No." : "",
      disabled: _vm.audanetLock
    },
    domProps: {
      value: _vm.innerValue.claimNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "claimNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Policy No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.policyNo,
      expression: "innerValue.policyNo"
    }],
    staticClass: "input is-uppercase",
    class: {
      "is-static": _vm.readOnlyView
    },
    attrs: {
      type: "text",
      placeholder: !_vm.readOnlyView ? "Policy No." : ""
    },
    domProps: {
      value: _vm.innerValue.policyNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "policyNo", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Authorised Date")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.authorisedDate, _vm.$userInfo.locale)
    }
  })]) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.authorisedDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref3) {
        var inputValue = _ref3.inputValue,
          inputEvents = _ref3.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Authorised Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedAuthorisedDate,
      callback: function callback($$v) {
        _vm.selectedAuthorisedDate = $$v;
      },
      expression: "selectedAuthorisedDate"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Assessor")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.assessorName,
      expression: "innerValue.assessorName"
    }],
    staticClass: "input is-capitalized",
    class: {
      "is-static": _vm.readOnlyView
    },
    attrs: {
      type: "text",
      placeholder: !_vm.readOnlyView ? "Assessor" : ""
    },
    domProps: {
      value: _vm.innerValue.assessorName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "assessorName", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess")]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-excessWtihGst"
    }
  }, [_vm._v("Excess with GST")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.excessWithGst,
      expression: "innerValue.excessWithGst"
    }],
    attrs: {
      id: "chk-excessWtihGst",
      type: "checkbox",
      disabled: _vm.innerValue.readOnly || _vm.readOnlyView || _vm.audanetLock
    },
    domProps: {
      checked: Array.isArray(_vm.innerValue.excessWithGst) ? _vm._i(_vm.innerValue.excessWithGst, null) > -1 : _vm.innerValue.excessWithGst
    },
    on: {
      change: function change($event) {
        var $$a = _vm.innerValue.excessWithGst,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.innerValue, "excessWithGst", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.innerValue, "excessWithGst", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.innerValue, "excessWithGst", $$c);
        }
      }
    }
  }), _vm._m(3)])])]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.excess, _vm.$userInfo.locale)
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Excess",
      precision: 2,
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    on: {
      blur: function blur($event) {
        return _vm.calculateExcess();
      }
    },
    model: {
      value: _vm.excess,
      callback: function callback($$v) {
        _vm.excess = $$v;
      },
      expression: "excess"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Owner's Contribution")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.innerValue.ownersContribution, _vm.$userInfo.locale)
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Owner's Contribution",
      precision: 2,
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    model: {
      value: _vm.innerValue.ownersContribution,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "ownersContribution", $$v);
      },
      expression: "innerValue.ownersContribution"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Discount on invoice")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.innerValue.discount, _vm.$userInfo.locale)
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      formats: "",
      placeholder: "Discount applied on invoice",
      precision: 2,
      disabled: _vm.innerValue.readOnly || _vm.audanetLock
    },
    model: {
      value: _vm.innerValue.discount,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "discount", $$v);
      },
      expression: "innerValue.discount"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Est. Start & End Date")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatDateLocale(_vm.innerValue.jobStart, _vm.$userInfo.locale)) + " - " + _vm._s(_vm.$filters.formatDateLocale(_vm.innerValue.jobEnd, _vm.$userInfo.locale)))])]) : _c("v-date-picker", {
    ref: "datepicker",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "select-attribute": _vm.selectDragAttribute,
      "drag-attribute": _vm.selectDragAttribute,
      "model-config": _vm.selectedJobStartEnd ? {} : _vm.modelConfig,
      timezone: _vm.$filters.getIanaTimezone(),
      "is-range": ""
    },
    on: {
      drag: function drag($event) {
        return _vm.jobStartEndDragEvent($event);
      },
      input: function input($event) {
        return _vm.jobStartEndInputEvent($event);
      }
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref4) {
        var inputValue = _ref4.inputValue,
          inputEvents = _ref4.inputEvents,
          isDragging = _ref4.isDragging;
        return [_c("div", {
          staticClass: "field-body is-align-items-center"
        }, [_c("div", {
          staticClass: "field mr-1 has-addons"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          class: {
            "has-text-grey": isDragging
          },
          attrs: {
            readonly: ""
          },
          domProps: {
            value: inputValue.start
          }
        }, inputEvents.start)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])]), _c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-arrow-right"
        })]), _c("div", {
          staticClass: "field ml-1 has-addons"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          class: {
            "has-text-grey": isDragging
          },
          attrs: {
            readonly: ""
          },
          domProps: {
            value: inputValue.end
          }
        }, inputEvents.end)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates"
          },
          on: {
            click: function click($event) {
              return _vm.resetJobStartEnd();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])])];
      }
    }, {
      key: "day-popover",
      fn: function fn(_ref5) {
        var format = _ref5.format;
        return _vm.dragValue ? _c("div", {}, [_c("div", [_vm._v(" " + _vm._s(format(_vm.dragValue ? _vm.dragValue.start : _vm.selectedJobStartEnd.start, "MMM D")) + " - " + _vm._s(format(_vm.dragValue ? _vm.dragValue.end : _vm.selectedJobStartEnd.end, "MMM D")) + " ")]), _c("div", {
          staticStyle: {
            display: "flex",
            "justify-content": "center",
            "align-items": "center",
            "padding-top": "3px"
          }
        }, [_c("span", {
          staticClass: "icon is-small",
          staticStyle: {
            color: "orange"
          }
        }, [_c("i", {
          staticClass: "mdi mdi-weather-sunny mdi-18px"
        })]), _c("span", {
          staticStyle: {
            "padding-left": "3px"
          }
        }, [_vm._v(_vm._s(_vm.getNoOfDays(_vm.dragValue ? _vm.dragValue.start : _vm.selectedJobStartEnd.start, _vm.dragValue ? _vm.dragValue.end : _vm.selectedJobStartEnd.end)) + " day" + _vm._s(_vm.getNoOfDays(_vm.dragValue ? _vm.dragValue.start : _vm.selectedJobStartEnd.start, _vm.dragValue ? _vm.dragValue.end : _vm.selectedJobStartEnd.end) > 1 ? "s" : "") + " ")])])]) : _vm._e();
      }
    }], null, true),
    model: {
      value: _vm.selectedJobStartEnd,
      callback: function callback($$v) {
        _vm.selectedJobStartEnd = $$v;
      },
      expression: "selectedJobStartEnd"
    }
  })], 1)])]), !_vm.innerValue.isNew && !_vm.readOnlyView && _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", [_c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": !_vm.innerValue.deleted
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(4), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": _vm.innerValue.deleted
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(5), _c("span", [_vm._v("In-Active")])])])]) : _vm._e()])])]), _c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Summary")]), _c("quote-detail-summary", {
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  })], 1)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column py-2"
  }, [_c("label", {
    staticClass: "label mb-0"
  }, [_vm._v("Vehicle")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", [_vm._v("Hour")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", [_vm._v("Dollar")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("section", {
    staticClass: "horizontal-menu-sticky",
    class: "has-hero-text-".concat(_vm.$theme.name, " ", "theme-".concat(_vm.$theme.name))
  }, [_c("div", {
    staticClass: "hero-body paddingless hanger"
  }, [_c("div", {
    staticClass: "horizontal-menu-container"
  }, [_c("module-sub-nav", {
    attrs: {
      "menu-items": _vm.visibleMenuItems,
      "menu-items-more": _vm.visibleMoreMenuItems
    },
    on: {
      "item-click": _vm.handleItemClick,
      "custom-action": _vm.handleCustomAction
    },
    scopedSlots: _vm._u([{
      key: "menu-item-actions",
      fn: function fn(_ref) {
        var item = _ref.item;
        return [item.label === "Images" && _vm.imageCount > 0 ? _c("span", {
          directives: [{
            name: "tippy",
            rawName: "v-tippy",
            value: {
              enabled: true
            },
            expression: "{ enabled: true }"
          }],
          staticClass: "icon breakout-icon-hover is-clickable",
          attrs: {
            content: "Image Breakout"
          },
          on: {
            click: function click($event) {
              $event.stopPropagation();
              $event.preventDefault();
              return _vm.handleClickImageBreakOut.apply(null, arguments);
            }
          }
        }, [_c("span", {
          staticClass: "mso mso-16px"
        }, [_vm._v("open_in_new")])]) : _vm._e()];
      }
    }])
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.entity && !_vm.uninterruptedView ? _c("module-detail-header", {
    attrs: {
      entity: _vm.entity,
      "show-new": false,
      "show-print": _vm.entity && !_vm.entity.isNew,
      "show-delete": _vm.entity && !_vm.entity.deleted && !_vm.entity.isNew && !_vm.readOnlyView && !_vm.isInvoiced,
      "show-save": _vm.showSaveButton,
      "auto-save-enabled": _vm.autoSaveEnabled,
      "manual-save-enabled": _vm.autoSaveManualSaveEnabled,
      "show-lock": _vm.showLock,
      "show-price-parts-msg": !_vm.entity.isNew && _vm.canViewPricePartsMsg,
      "show-quote-template": _vm.showQuoteTemplate,
      "quote-template-disabled": _vm.quoteTemplateDisabled,
      "quote-cancelled": _vm.isQuoteCancelledByInsurer,
      "show-auto-save": _vm.autoSaveEnabled,
      "auto-save-status": _vm.quoteSaveStatus,
      "is-saving": _vm.autoSaveStatus.isSaving || _vm.isSaving,
      "has-auto-save-failed": _vm.autoSaveStatus.isFailed,
      "unsaved-changes": _vm.autoSaveStatus.isDiffChanged,
      "auto-save-locked": _vm.entity && _vm.entity.isNew || !_vm.autoSaveEnabled || _vm.autoSaveStatus.isFailed,
      "show-calendar": _vm.isRepx,
      "show-additional-quote-buttons": _vm.showQuoteActionButton,
      "show-additional-quote": _vm.showNewAdditional,
      "show-toggle": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked,
      "manual-save-request": _vm.handleManualSaveRequest,
      "toggle-auto-save": _vm.toggleAutoSave
    },
    scopedSlots: _vm._u([{
      key: "desktop-left",
      fn: function fn() {
        return [_c("article", {
          staticClass: "horizontal-menu-article"
        }, [_c("span", {
          directives: [{
            name: "show",
            rawName: "v-show",
            value: _vm.$user.info.isSupportUser && _vm.hasFlexiShopIntegration,
            expression: "$user.info.isSupportUser && hasFlexiShopIntegration"
          }],
          staticClass: "icon is-synced-icon",
          class: [_vm.entity.isSynced ? "has-text-success" : "has-text-warning"]
        }, [_c("i", {
          staticClass: "mdi mdi-circle-medium mdi-36px"
        })]), _c("section", {
          staticClass: "quote-header-row"
        }, [_c("div", {
          staticClass: "quote-info is-flex"
        }, [_c("span", {
          staticClass: "is-5 is-flex is-align-items-center"
        }, [_c("span", {
          staticClass: "is-size-4 has-text-weight-bold mx-1"
        }, [_vm._v(" " + _vm._s([_vm.entity.prefix, _vm.entity.quoteNo, _vm.entity.suffix].join("") || "-") + " ")])])]), _c("div", {
          staticClass: "is-flex is-align-items-center"
        }, [_c("span", {
          staticClass: "is-flex tooltip is-tooltip-bottom",
          attrs: {
            "data-tooltip": "Authorised Quote"
          }
        }, [_vm.entity && !_vm.entity.isNew && _vm.isAuthorised ? _c("span", {
          staticClass: "mso mso-24px has-text-grey-light"
        }, [_vm._v(" shield ")]) : _vm._e()]), _vm.entity.isNew || _vm.readOnlyView ? _c("div", {
          staticClass: "ml-1"
        }, [_c("span", {
          staticClass: "tag is-rounded job-stage is-5"
        }, [_vm._v(_vm._s(_vm.jobNSubJobStageCompositeName))])]) : _c("div", {
          staticClass: "field ml-1",
          staticStyle: {
            "margin-bottom": "0"
          }
        }, [_c("div", {
          staticClass: "control",
          class: {
            "tooltip is-tooltip-bottom": _vm.$licenceExpired
          },
          attrs: {
            "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : null
          }
        }, [_c("div", {
          staticClass: "select job-stage-select"
        }, [_c("select", {
          directives: [{
            name: "model",
            rawName: "v-model",
            value: _vm.innerJobNSubJobStageCompositeKey,
            expression: "innerJobNSubJobStageCompositeKey"
          }],
          staticStyle: {
            "min-width": "150px"
          },
          attrs: {
            disabled: _vm.$licenceExpired
          },
          on: {
            change: [function ($event) {
              var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
                return o.selected;
              }).map(function (o) {
                var val = "_value" in o ? o._value : o.value;
                return val;
              });
              _vm.innerJobNSubJobStageCompositeKey = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
            }, _vm.handleJobNSubJobStageChanged]
          }
        }, [_vm._l(_vm.jobNSubJobStagesOptions, function (jobStageGroup) {
          return [jobStageGroup.subStages.length === 0 ? _c("option", {
            key: "main-".concat(jobStageGroup.jobStageId),
            domProps: {
              value: "".concat(jobStageGroup.mainStage.compositeKey)
            }
          }, [_vm._v(" " + _vm._s(_vm.formatJobStage(jobStageGroup.jobStageName)) + " ")]) : _vm._e(), jobStageGroup.subStages.length > 0 ? _c("optgroup", {
            key: "group-".concat(jobStageGroup.jobStageId),
            attrs: {
              label: _vm.formatJobStage(jobStageGroup.jobStageName)
            }
          }, [_vm.innerJobNSubJobStageCompositeKey === jobStageGroup.mainStage.compositeKey ? _c("option", {
            key: "parent-".concat(jobStageGroup.jobStageId),
            attrs: {
              disabled: ""
            },
            domProps: {
              value: "".concat(jobStageGroup.mainStage.compositeKey)
            }
          }, [_vm._v(" " + _vm._s(_vm.formatJobStage(jobStageGroup.jobStageName)) + " ")]) : _vm._e(), _vm._l(jobStageGroup.subStages, function (subStage) {
            return _c("option", {
              key: subStage.compositeKey,
              attrs: {
                disabled: subStage.disabled
              },
              domProps: {
                value: subStage.compositeKey
              }
            }, [_vm._v(" " + _vm._s(_vm.formatJobStage(subStage.subJobStageName)) + " ")]);
          })], 2) : _vm._e()];
        })], 2)])])])]), _vm.entity && _vm.entity.subQuoteNos && _vm.entity.subQuoteNos.length >= 1 && !_vm.entity.isNew && !_vm.entity.isAssessmentEnabled ? _c("div", {
          staticClass: "subquotes-tabs"
        }, [_c("div", {
          staticClass: "tags"
        }, [_c("span", {
          staticClass: "is-size-6 has-text-weight-semibold"
        }, [_vm._v("Quote:")]), _vm._l(_vm.entity.subQuoteNos, function (sub) {
          return _c("router-link", {
            key: sub.key,
            staticClass: "tag is-rounded",
            class: {
              "is-primary": sub.key === _vm.entity.subQuoteNo,
              "has-text-white": sub.key === _vm.entity.subQuoteNo,
              "is-disabled": _vm.entity.isNew && sub.key !== _vm.entity.subQuoteNo
            },
            attrs: {
              to: {
                name: _vm.$route.name,
                params: {
                  quoteId: sub.value
                },
                query: _vm.$route.query
              },
              exact: ""
            },
            nativeOn: {
              click: function click($event) {
                $event.preventDefault();
                return _vm.goToRoute({
                  name: _vm.$route.name,
                  params: {
                    quoteId: sub.value
                  },
                  query: _vm.$route.query
                });
              }
            }
          }, [_c("span", {
            directives: [{
              name: "show",
              rawName: "v-show",
              value: _vm.entity.readOnlyStatuses[sub.key],
              expression: "entity.readOnlyStatuses[sub.key]"
            }],
            staticClass: "icon is-small",
            staticStyle: {
              "margin-left": "0.1em",
              "margin-right": "0.1em"
            }
          }, [_c("i", {
            staticClass: "icon mdi mdi-lock-outline"
          })]), _c("span", {
            class: {
              "has-badge-warning has-badge-small has-badge-rounded has-badge-offset2": _vm.entity.isNew && sub.key === _vm.currentsubquote
            },
            attrs: {
              "data-badge": _vm.entity.isNew && sub.key === _vm.currentsubquote ? "" : null
            }
          }, [_vm._v(" " + _vm._s(sub.key === 0 ? "Main" : "Add-".concat(sub.key)) + " ")])]);
        })], 2)]) : _vm._e(), !_vm.entity.isNew ? _c("div", {
          staticClass: "is-flex quote-header-info thin-scrollbar"
        }, [_c("div", {
          staticClass: "is-flex is-hidden-desktop-only"
        }, [_vm.customer ? _c("div", {
          staticClass: "mr-5 is-flex is-align-items-center is-info tooltip is-tooltip-bottom",
          attrs: {
            "data-tooltip": _vm.customer.fullname
          }
        }, [_c("span", {
          staticClass: "mso mso-24px has-text-grey-light mr-1"
        }, [_vm._v("person")]), _c("span", {
          staticClass: "has-text-weight-semibold"
        }, [_vm._v(_vm._s(_vm.truncate(_vm.customer.fullname, _vm.customerAndVehicleMakeModelMaxLength)))])]) : _vm._e(), _vm.vehicle ? _c("div", {
          staticClass: "is-flex is-align-items-center is-info tooltip is-tooltip-bottom",
          attrs: {
            "data-tooltip": "".concat(_vm.vehicle.rego, " - ").concat(_vm.vehicle.model.name)
          }
        }, [_c("span", {
          staticClass: "mso mso-24px has-text-grey-light mr-1"
        }, [_vm._v("directions_car")]), _c("span", {
          staticClass: "has-text-weight-semibold"
        }, [_vm._v(_vm._s(_vm.truncate("".concat(_vm.vehicle.rego, " - ").concat(_vm.vehicle.model.name), _vm.customerAndVehicleMakeModelMaxLength)))])]) : _vm._e()]), _c("div", {
          staticClass: "is-flex",
          staticStyle: {
            gap: "0.7rem"
          }
        }, [_c("div", [_c("span", {
          staticClass: "is-size-6 has-text-weight-semibold"
        }, [_vm._v("Total "), _c("span", {
          staticClass: "subtext mr-2"
        }, [_vm._v("(Ex GST)")])]), _c("span", {
          staticClass: "has-text-success"
        }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalExGst, _vm.$userInfo.locale)))])]), _c("div", [_c("span", {
          staticClass: "is-size-6 has-text-weight-semibold"
        }, [_vm._v("Total "), _c("span", {
          staticClass: "subtext mr-2"
        }, [_vm._v("(Inc GST)")])]), _c("span", {
          staticClass: "has-text-success"
        }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalIncGst, _vm.$userInfo.locale)))])])]), _vm.entity && !_vm.entity.isNew && _vm.isPresenceEnabled ? _c("presence-avatar-stack", {
          staticClass: "ml-3",
          attrs: {
            "quote-id": String(_vm.entity.quoteId),
            "current-user": _vm.currentUserForPresence,
            "is-editing": _vm.autoSaveStatus.isEditing || _vm.autoSaveStatus.isDiffChanged,
            "active-tab": _vm.activeTab
          },
          on: {
            ready: _vm.onPresenceReady
          }
        }) : _vm._e()], 1) : _vm._e()])])];
      },
      proxy: true
    }, _vm.isQuoteCancelledByInsurer ? {
      key: "center",
      fn: function fn() {
        return [_c("span", {
          staticClass: "is-size-6 tag is-danger is-light"
        }, [_c("span", {
          staticClass: "mdi mdi-alert-outline mr-3"
        }), _c("span", {
          staticStyle: {
            "word-break": "break-word"
          }
        }, [_vm._v("Cancelled by insurer. Please copy the quote to work on it as a private job.")])])];
      },
      proxy: true
    } : null, {
      key: "more-menu-items",
      fn: function fn() {
        return [_vm.entity && !_vm.entity.isNew && _vm.entity.deleted ? _c("div", {
          staticClass: "is-divider"
        }) : _vm._e(), _vm.entity && !_vm.entity.isNew && _vm.entity.deleted ? _c("li", [_c("a", {
          staticClass: "is-flex is-align-items-center",
          class: _vm.$licenceExpired ? "has-text-grey-light tooltip is-tooltip-left" : "has-text-success",
          style: _vm.$licenceExpired ? "cursor: not-allowed" : null,
          attrs: {
            "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : null
          },
          on: {
            click: function click($event) {
              !_vm.$licenceExpired && _vm.onHeaderButtonClicked("restore");
            }
          }
        }, [_c("span", {
          staticClass: "mso mso-20px icon pr-3"
        }, [_vm._v(" restore_from_trash ")]), _c("span", [_vm._v("Restore")])])]) : _vm._e(), (_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator || _vm.tempGemCan) && _vm.isMainQuote ? _c("div") : _vm._e(), (_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator || _vm.tempGemCan) && _vm.isMainQuote ? _c("li", [_c("a", {
          staticClass: "is-flex is-align-items-center",
          class: {
            "has-text-grey-light tooltip is-tooltip-left": _vm.$licenceExpired
          },
          style: _vm.$licenceExpired ? "cursor: not-allowed" : null,
          attrs: {
            "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : null
          },
          on: {
            click: function click($event) {
              !_vm.$licenceExpired && _vm.onHeaderButtonClicked("enableAssessmentHistory");
            }
          }
        }, [_c("span", {
          staticClass: "mso mso-20px icon pr-3"
        }, [_vm._v(" " + _vm._s(_vm.entity.isAssessmentEnabled ? "check_box" : "check_box_outline_blank") + " ")]), _c("span", [_vm._v("Enable Assessment History")])])]) : _vm._e()];
      },
      proxy: true
    }], null, true)
  }) : _vm._e(), _vm.entity && !_vm.uninterruptedView && _vm.showHorizontalMenu ? _c("quote-sub-nav", {
    attrs: {
      value: _vm.entity,
      insurer: _vm.insurer,
      "orm-unread-message-count": _vm.ormUnreadMessageCount
    }
  }) : _vm._e(), !_vm.isOrmEditedQuote ? _c("QuoteBanner", {
    attrs: {
      title: "Quote Editing Locked",
      message: "Editing is disabled while a payment authorisation is in progress.",
      type: "warning",
      icon: "warning",
      "banner-visible": true
    }
  }) : _vm._e(), _vm.isDollarQuoteOrm ? _c("QuoteBanner", {
    attrs: {
      title: "Dollar Quote",
      message: "ORM does not accept Dollar quotes.",
      type: "warning",
      icon: "warning",
      "banner-visible": true
    }
  }) : _vm._e(), _c("div", {
    staticClass: "columns is-gapless quote-body"
  }, [_vm.isQuoteBuilder ? _c("div", {
    staticClass: "column is-narrow ml-3 mb-3"
  }, [_c("quote-builder-sidebar", {
    attrs: {
      "selected-menu": _vm.selectedMenu,
      "selected-sub-sections": _vm.selectedSubSections,
      "selected-area": _vm.selectedArea,
      "available-items-type": _vm.availableItemsType,
      "is-quote-editable": _vm.isQuoteEditable
    },
    on: {
      "update:selectedSubSections": function updateSelectedSubSections($event) {
        _vm.selectedSubSections = $event;
      },
      "update:selected-sub-sections": function updateSelectedSubSections($event) {
        _vm.selectedSubSections = $event;
      },
      "update:selectedArea": function updateSelectedArea($event) {
        _vm.selectedArea = $event;
      },
      "update:selected-area": function updateSelectedArea($event) {
        _vm.selectedArea = $event;
      },
      "update:selectedMenu": function updateSelectedMenu($event) {
        _vm.selectedMenu = $event;
      },
      modify: _vm.modifySelections,
      reset: _vm.resetSelections
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  })], 1) : _vm._e(), _c("div", {
    staticClass: "column mx-3 mt-0 mb-3"
  }, [_vm.entity && _vm.vehicle && _vm.customer && _vm.insurer ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "routerView",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name,
      vehicle: _vm.vehicle,
      customer: _vm.customer,
      insurer: _vm.insurer,
      "quote-cycle-time": _vm.entity.quoteCycleTime,
      "next-line-number": _vm.nextLineNumber,
      "read-only-view": _vm.readOnlyView,
      "audanet-lock": _vm.audanetLock,
      "price-parts-return-route": _vm.pricePartsReturnRoute,
      "snapshot-diff": _vm.snapshotDiff,
      "orm-unread-message-count": _vm.ormUnreadMessageCount,
      "show-quote-template": _vm.showQuoteTemplate,
      "selected-area": _vm.selectedArea,
      "selected-sub-sections": _vm.selectedSubSections,
      "is-new-customer-prompt": _vm.isNewCustomerPrompt,
      "header-saving-panels": _vm.headerSavingPanels,
      "is-quote-editable": _vm.isQuoteEditable,
      "auto-save-enabled": _vm.autoSaveEnabled
    },
    on: {
      "update:vehicle": function updateVehicle($event) {
        _vm.vehicle = $event;
      },
      "update:customer": function updateCustomer($event) {
        _vm.customer = $event;
      },
      "update:insurer": function updateInsurer($event) {
        _vm.insurer = $event;
      },
      "update:quoteCycleTime": function updateQuoteCycleTime($event) {
        return _vm.$set(_vm.entity, "quoteCycleTime", $event);
      },
      "update:quote-cycle-time": function updateQuoteCycleTime($event) {
        return _vm.$set(_vm.entity, "quoteCycleTime", $event);
      },
      onOpgCodeChanged: _vm.onOpgCodeChanged,
      "customer-component-blur": function customerComponentBlur($event) {
        return _vm.queueHeaderAutosave("customer");
      },
      "vehicle-component-blur": function vehicleComponentBlur($event) {
        return _vm.queueHeaderAutosave("vehicle");
      },
      "insurer-component-blur": function insurerComponentBlur($event) {
        return _vm.queueHeaderAutosave("insurer");
      },
      "booking-component-blur": function bookingComponentBlur($event) {
        return _vm.queueHeaderAutosave("booking");
      },
      "pnet-component-blur": _vm.onPnetComponentBlur,
      "remarks-save-state-change": _vm.onRemarksSaveStateChange,
      "remarks-saved": _vm.onRemarksSaved,
      updateQuoteItemsDefaultPaintGroup: _vm.updateQuoteItemsDefaultPaintGroup,
      getEntity: _vm.getEntity,
      "select-vehicle": _vm.selectVehicle,
      "select-customer": _vm.selectCustomer,
      "select-insurer": _vm.selectInsurer,
      save: _vm.save,
      printInvoice: _vm.onPrintInvoice,
      "hide-header-buttons": _vm.hideHeaderButtons,
      downloadPartsCheckPrice: _vm.downloadPartsCheckPrice,
      addRepairQuoteTemplateItems: function addRepairQuoteTemplateItems(id) {
        return _vm.addRepairQuoteTemplateItems(id);
      },
      handleAddTemplateItemsCustom: function handleAddTemplateItemsCustom(obj) {
        return _vm.addRepairQuoteTemplateItemsCustom(obj);
      },
      "save-repx-repair-stages": _vm.handleSaveRepxRepairStages,
      avaliableItemsTypeChanged: _vm.availableItemsTypeChanged,
      "update:selectedMenu": function updateSelectedMenu($event) {
        _vm.selectedMenu = $event;
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _vm.isPrintOptionsActive ? _c("print-options-modal", {
    attrs: {
      active: _vm.isPrintOptionsActive,
      "show-icon": true,
      "attach-disabled": false,
      "cancel-disabled": false,
      value: _vm.entity
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPrintOptionsActive = $event;
      },
      cancel: function cancel($event) {
        return _vm.closeModal();
      },
      ok: function ok($event) {
        return _vm.closeModal();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Print Options")])]) : _vm._e(), _vm.isInvoicePrintOptionsActive ? _c("invoice-print-options-modal", {
    attrs: {
      active: _vm.isInvoicePrintOptionsActive,
      "show-icon": true,
      "cancel-disabled": false,
      value: _vm.entity
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isInvoicePrintOptionsActive = $event;
      },
      ok: function ok($event) {
        _vm.isInvoicePrintOptionsActive = false;
      },
      cancel: function cancel($event) {
        _vm.isInvoicePrintOptionsActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Invoice Print Options")])]) : _vm._e(), _vm.isSmsModalActive ? _c("sms-modal", {
    attrs: {
      active: _vm.isSmsModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSmsModalActive = $event;
      },
      close: _vm.closeSmsModal
    },
    model: {
      value: _vm.smsDetails,
      callback: function callback($$v) {
        _vm.smsDetails = $$v;
      },
      expression: "smsDetails"
    }
  }) : _vm._e(), _vm.isCopyQuoteModalActive ? _c("copy-quote-modal", {
    attrs: {
      active: _vm.isCopyQuoteModalActive,
      "image-ids": _vm.imageIds
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCopyQuoteModalActive = $event;
      },
      copy: _vm.copyQuote,
      cancel: function cancel($event) {
        _vm.isCopyQuoteModalActive = false;
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e(), _vm.isQuoteExportModalActive ? _c("quote-export-modal", {
    attrs: {
      active: _vm.isQuoteExportModalActive,
      vehicle: _vm.quoteVehicle,
      "default-email": _vm.insurerDefaultEmail
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isQuoteExportModalActive = $event;
      },
      close: _vm.closeQuoteExportModal
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e(), _vm.isNavigationWarningModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isNavigationWarningModalActive,
      "ok-text": _vm.navigationWarningAction === "deleteEmpty" ? "Continue" : _vm.navigationWarningAction === "leaveWithErrors" ? "Leave Anyway" : "Try Manual Save",
      "cancel-text": _vm.navigationWarningAction === "deleteEmpty" ? "Keep Editing" : _vm.navigationWarningAction === "leaveWithErrors" ? "Stay to Fix" : "Skip Anyway"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isNavigationWarningModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.handleNavigationWarningConfirm();
      },
      cancel: function cancel($event) {
        return _vm.handleNavigationWarningCancel();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Navigation Warning")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(_vm._s(_vm.navigationWarningMessage))])]) : _vm._e(), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isQuoteDeletedByOtherActive,
      "ok-text": "Ok",
      "show-cancel": false
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isQuoteDeletedByOtherActive = $event;
      },
      ok: function ok($event) {
        return _vm.acknowledgeQuoteDeleted();
      },
      cancel: function cancel($event) {
        return _vm.acknowledgeQuoteDeleted();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Quote Deleted")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" This quote has been deleted by "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.quoteDeletedByName || "another user"))]), _vm._v(". You will be redirected to the quote list. ")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete " + _vm._s(_vm.entity.subQuoteNo > 0 ? "Supplementry" : "") + " Quote")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" " + _vm._s(_vm.entity.subQuoteNo > 0 ? "Supplementry" : "") + " Quote "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.deleteQuoteMessage)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e(), _vm.entity ? _c("BulmaMessage", {
    attrs: {
      type: "is-warning",
      title: "Restore Quote",
      closable: true
    },
    on: {
      close: function close($event) {
        return _vm.confirmRestoreAll(false);
      }
    },
    scopedSlots: _vm._u([{
      key: "footer",
      fn: function fn() {
        return [_c("button", {
          staticClass: "button is-danger",
          on: {
            click: function click($event) {
              return _vm.confirmRestoreAll(false);
            }
          }
        }, [_vm._v(" No ")]), _c("button", {
          staticClass: "button is-primary",
          on: {
            click: function click($event) {
              return _vm.confirmRestoreAll(true);
            }
          }
        }, [_vm._v(" Yes ")])];
      },
      proxy: true
    }], null, false, 1142565614),
    model: {
      value: _vm.isRestoreAllConfirmModalActive,
      callback: function callback($$v) {
        _vm.isRestoreAllConfirmModalActive = $$v;
      },
      expression: "isRestoreAllConfirmModalActive"
    }
  }, [_c("p", [_vm.entity.subQuoteNo > 0 ? [_vm._v(" Supplementaries cannot be restored without restoring the delete Main."), _c("br"), _c("br")] : _vm._e(), _vm._v(" Restore '"), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.prefix).concat(_vm.entity.quoteNo).concat(_vm.entity.suffix)) + " and all supplementary quotes")]), _vm._v("'? Continue ")], 2)]) : _vm._e(), _c("confirm-modal", {
    attrs: {
      active: _vm.isCustomerCreateModifyModalActive,
      "ok-text": "Save",
      "cancel-text": "Cancel"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCustomerCreateModifyModalActive = $event;
      },
      ok: _vm.handleCustomerModalSave,
      cancel: _vm.handleCustomerModalCancel
    }
  }, [_c("div", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Update Customer")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("div", {
    staticClass: "new-owner-prompt-container"
  }, [_c("p", {
    staticClass: "has-text-weight-bold mb-5"
  }, [_vm._v("You are about to update the customer details. What would you like to do?")]), _c("div", {
    staticClass: "field",
    class: "theme-".concat(_vm.$theme.name, " has-background-").concat(_vm.$theme.name)
  }, [_c("label", {
    staticClass: "custom-radio radio is-flex p-4 mb-3",
    class: [{
      "is-selected": _vm.customerModalSelection === "create"
    }, _vm.customerModalSelection === "create" && "has-text-".concat(_vm.$theme.name, "-invert")]
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.customerModalSelection,
      expression: "customerModalSelection"
    }],
    attrs: {
      type: "radio",
      value: "create"
    },
    domProps: {
      checked: _vm._q(_vm.customerModalSelection, "create")
    },
    on: {
      change: function change($event) {
        _vm.customerModalSelection = "create";
      }
    }
  }), _c("span", {
    staticClass: "check"
  }), _c("span", {
    staticClass: "control-label ml-3"
  }, [_vm._v(" Create a new customer profile and assign the vehicle to them. A new vehicle record will be created with the same registration, linked to a new customer. ")])])]), _c("div", {
    staticClass: "field",
    class: "theme-".concat(_vm.$theme.name, " has-background-").concat(_vm.$theme.name)
  }, [_c("label", {
    staticClass: "custom-radio radio is-flex p-4",
    class: [{
      "is-selected": _vm.customerModalSelection === "modify"
    }, _vm.customerModalSelection === "modify" && "has-text-".concat(_vm.$theme.name, "-invert")]
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.customerModalSelection,
      expression: "customerModalSelection"
    }],
    attrs: {
      type: "radio",
      value: "modify"
    },
    domProps: {
      checked: _vm._q(_vm.customerModalSelection, "modify")
    },
    on: {
      change: function change($event) {
        _vm.customerModalSelection = "modify";
      }
    }
  }), _c("span", {
    staticClass: "check"
  }), _c("span", {
    staticClass: "control-label ml-3"
  }, [_vm._v(" Update the existing customer's details. All quotes "), _c("b", [_vm._v("( " + _vm._s(_vm.affectedQuotesCount) + " )")]), _vm._v(" with this registration will be updated with the customer information. ")])])])])])]), _vm.entity ? _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      merge: _vm.conflictMerge,
      reload: _vm.conflictReload,
      close: function close($event) {
        _vm.isSaveConflictModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Quote Conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Quote "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.prefix).concat(_vm.entity.quoteNo).concat(_vm.entity.suffix)))]), _vm._v(" is newer on the server. Reload/Merge/Cancel? "), _c("br"), _c("br"), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Reload")]), _vm._v(" - "), _c("span", {
    staticClass: "is-italic"
  }, [_vm._v("Reload quote and lose changes")]), _c("br"), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Merge")]), _vm._v(" - "), _c("span", {
    staticClass: "is-italic"
  }, [_vm._v("Local quote changes take precedence. Added items will be merged")]), _c("br")])]) : _vm._e(), _vm.isXmlViewerModalActive ? _c("xml-viewer-modal", {
    attrs: {
      active: _vm.isXmlViewerModalActive,
      "quote-id": _vm.entity.quoteId,
      "message-type": _vm.messageType
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isXmlViewerModalActive = $event;
      },
      close: function close($event) {
        _vm.isXmlViewerModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("View " + _vm._s(_vm.messageType) + " Messages")])]) : _vm._e(), _vm.isQuoteTemplateModalActive ? _c("quote-template-apply-modal", {
    attrs: {
      active: _vm.isQuoteTemplateModalActive,
      "quote-times-type": _vm.entity.labourType,
      "vehicle-body-id": _vm.vehicle.bodyId
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isQuoteTemplateModalActive = $event;
      },
      add: _vm.addRepairQuoteTemplateItems
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Apply Quote Template")])]) : _vm._e(), _vm.isVehicleButterflyModalActive ? _c("vehicle-butterfly-modal", {
    attrs: {
      active: _vm.isVehicleButterflyModalActive,
      entity: _vm.entity
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isVehicleButterflyModalActive = $event;
      },
      done: _vm.handleVehicleButterflyDone,
      cancel: _vm.handleVehicleButterflyCancel
    },
    model: {
      value: _vm.selectedSubSections,
      callback: function callback($$v) {
        _vm.selectedSubSections = $$v;
      },
      expression: "selectedSubSections"
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".navbar[data-v-323aba62] {\n  height: 52px;\n}\n.menu.more-menu[data-v-323aba62] {\n  min-width: 15rem !important;\n}\n.is-divider[data-v-323aba62] {\n  margin: 0.5rem 0;\n}\n.hanger[data-v-323aba62] {\n  margin: 0.75rem 0.75rem 0 0.75rem;\n  background-color: var(--background-color);\n  border-radius: 4px !important;\n  padding: 0.5rem;\n}\n.loading[data-v-323aba62] {\n  -webkit-animation: circle-9-loading-323aba62 1.5s infinite linear;\n          animation: circle-9-loading-323aba62 1.5s infinite linear;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5);\n}\n@-webkit-keyframes circle-9-loading-323aba62 {\n0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n}\n100% {\n    -webkit-transform: rotate(-360deg);\n            transform: rotate(-360deg);\n}\n}\n@keyframes circle-9-loading-323aba62 {\n0% {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n}\n100% {\n    -webkit-transform: rotate(-360deg);\n            transform: rotate(-360deg);\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".module-subnav-container[data-v-e3da92a2] {\n  width: 100%;\n  position: relative;\n  padding-top: 0.5rem;\n  border-top: solid 1px var(--divider-background-color);\n}\n.mobile-nav[data-v-e3da92a2] {\n  padding: 0.5rem 0rem;\n  -webkit-overflow-scrolling: touch;\n  margin-bottom: 0;\n}\n.mobile-nav .button[data-v-e3da92a2] {\n  min-width: auto;\n}\n.menu-list.horizontal[data-v-e3da92a2] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-wrap: nowrap;\n      flex-wrap: nowrap;\n  gap: 1rem;\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  white-space: nowrap;\n  min-width: -webkit-max-content;\n  min-width: -moz-max-content;\n  min-width: max-content;\n}\n.menu-list.horizontal li[data-v-e3da92a2] {\n  margin: 0;\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n  position: relative;\n}\n.menu-list.horizontal li a[data-v-e3da92a2] {\n  display: inline-block;\n  padding: 0.2rem 0;\n  text-decoration: none;\n  background-color: transparent;\n  border: none;\n  font-weight: 500;\n  position: relative;\n  font-size: clamp(0.1rem, 1vw, 0.9rem);\n  width: auto;\n}\n.menu-list.horizontal li a[data-v-e3da92a2]:hover {\n  background-color: transparent;\n  color: #3291EF;\n}\n.menu-list.horizontal li a.is-active[data-v-e3da92a2] {\n  background-color: transparent;\n  color: #3291EF;\n  font-weight: 600;\n  border-bottom: 2px solid #3291EF;\n}\n.menu-list.horizontal li a.is-disabled[data-v-e3da92a2] {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n.menu-list.horizontal [class*=has-badge-][data-v-e3da92a2] {\n  position: relative;\n  z-index: 25;\n}\n.menu-list.horizontal [class*=has-badge-][data-v-e3da92a2]::after {\n  content: attr(data-badge);\n  position: absolute;\n  top: -0.7em;\n  right: -1.2em;\n  display: inline-block;\n  min-width: 1em;\n  padding: 0.1em 0.3em;\n  font-size: 0.75em;\n  font-weight: bold;\n  line-height: 1;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: baseline;\n  z-index: 9999 !important;\n  pointer-events: none;\n  -webkit-transform: translateZ(0);\n          transform: translateZ(0);\n}\n.menu-list.horizontal [class*=has-badge-] [class*=has-badge-][data-v-e3da92a2]::after {\n  min-height: 1.15em;\n  font-size: 0.85em;\n}\n.menu-list.horizontal [class*=has-badge-].has-new-content[data-v-e3da92a2]::before {\n  content: \"\";\n  position: absolute;\n  top: calc(-0.525em - 1px);\n  right: calc(-0.9em - 1px);\n  width: 5px;\n  height: 5px;\n  border-radius: 50%;\n  background: hsl(346, 71%, 50%);\n  -webkit-transform: translate(50%, -50%);\n          transform: translate(50%, -50%);\n  z-index: 10000;\n  pointer-events: none;\n}\n.menu.more-menu[data-v-e3da92a2] {\n  min-width: 12rem !important;\n}\n.menu.more-menu .menu-list[data-v-e3da92a2] {\n  padding: 0;\n  margin: 0;\n  -webkit-border-start: none;\n          border-inline-start: none;\n}\n.menu.more-menu .menu-list a[data-v-e3da92a2] {\n  padding: 0.5rem 0.75rem;\n  border-radius: 4px;\n  text-decoration: none;\n  color: inherit;\n}\n.menu.more-menu .menu-list a.is-active[data-v-e3da92a2] {\n  border-bottom: 0 !important;\n}\n.is-disabled[data-v-e3da92a2] {\n  pointer-events: none;\n  opacity: 0.5;\n  cursor: not-allowed;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-banner[data-v-93b5493e] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  width: 100%;\n  height: 2.8rem;\n  padding: 0 0.8rem;\n  gap: 1rem;\n  z-index: 100;\n}\n.quote-banner-icon[data-v-93b5493e] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n}\n.quote-banner-content[data-v-93b5493e] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  text-align: center;\n  line-height: 1.5;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-6de06fcc] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-3c16462b] {\n  margin: 1.2em 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.is-uppercase[data-v-3210eb10] {\n  text-transform: uppercase;\n}\ninput.is-uppercase[data-v-3210eb10]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-3210eb10]::-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-3210eb10]:-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-3210eb10]:-ms-input-placeholder {\n  text-transform: none;\n}\n.is-divider[data-v-3210eb10] {\n  margin: 1.2em 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-detail-fieldset {\n  border: 0;\n  min-width: 0;\n}\n.quote-detail-fieldset:disabled a.button,\n.quote-detail-fieldset:disabled span.button {\n  pointer-events: none !important;\n}\n.quote-detail-fieldset:disabled .control:not(:has(.control)),\n.quote-detail-fieldset:disabled .buttons {\n  position: relative;\n}\n.quote-detail-fieldset:disabled .control:not(:has(.control)):hover::before,\n.quote-detail-fieldset:disabled .buttons:hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  left: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-detail-fieldset:disabled .buttons:hover::before {\n  left: 50%;\n  -webkit-transform: translate(-50%, 0.5rem);\n          transform: translate(-50%, 0.5rem);\n}\n#quote-vehicle-multiselect {\n  text-transform: uppercase !important;\n}\n.readonly-pointer {\n  cursor: pointer;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".horizontal-menu-sticky[data-v-7ea01482] {\n  position: sticky;\n  top: 64px;\n  z-index: 30;\n  padding: 0 0.75rem 0.75rem 0.75rem;\n}\n.horizontal-menu-container[data-v-7ea01482] {\n  width: 100%;\n  padding: 0 0.75rem 0.5rem 0.75rem;\n  position: relative;\n  min-width: -webkit-max-content;\n  min-width: -moz-max-content;\n  min-width: max-content;\n}\n.horizontal-menu-container[data-v-7ea01482] [class*=has-badge-] {\n  position: relative;\n  z-index: 25;\n}\n.horizontal-menu-container[data-v-7ea01482] [class*=has-badge-]::after {\n  position: absolute;\n  z-index: 30 !important;\n  pointer-events: none;\n}\n.horizontal-menu-container[data-v-7ea01482] .has-badge-medium::after {\n  min-height: 1.15em;\n  font-size: 0.85em;\n  margin-left: 0.25em;\n  z-index: 30 !important;\n}\n.horizontal-menu-container[data-v-7ea01482] .has-badge-small::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-medium::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-large::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-info::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-success::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-warning::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-danger::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-rounded::after,\n.horizontal-menu-container[data-v-7ea01482] .has-badge-icon-check::after {\n  z-index: 30 !important;\n  position: absolute !important;\n}\n@media screen and (max-width: 768px) {\n.horizontal-menu-sticky[data-v-7ea01482] {\n    -webkit-overflow-scrolling: touch;\n}\n}\n.hanger[data-v-7ea01482] {\n  background-color: var(--background-color);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".autosave-toggle-container[data-v-2a8ec124] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  gap: 0.5rem;\n  margin-bottom: 0;\n}\n.autosave-toggle-container .switch[type=checkbox]:checked + label[data-v-2a8ec124]::before {\n  background-color: hsl(171, 100%, 41%);\n}\n.autosave-toggle-container label[data-v-2a8ec124] {\n  margin-bottom: 0;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n}\n.horizontal-menu-article[data-v-2a8ec124] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.quote-header-row[data-v-2a8ec124] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.25rem 0;\n  gap: 1rem;\n}\n.quote-header-row > div[data-v-2a8ec124]:not(:last-child) {\n  border-right: 1px solid var(--divider-background-color);\n  padding-right: 1rem;\n}\n.quote-header-row .quote-info[data-v-2a8ec124] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  gap: 0;\n}\n.quote-header-row .quote-info .subtitle[data-v-2a8ec124] {\n  margin-bottom: 0 !important;\n}\n.quote-header-row .subquotes-tabs .tags[data-v-2a8ec124] {\n  margin-bottom: 0;\n  gap: 0.5rem;\n}\n.quote-header-row .subquotes-tabs .tags .tag[data-v-2a8ec124] {\n  font-size: 0.9em;\n  text-decoration: none;\n}\n.quote-header-row .subquotes-tabs .tags .tag.is-disabled[data-v-2a8ec124] {\n  opacity: 0.5;\n  cursor: not-allowed;\n  pointer-events: none;\n}\n.quote-body[data-v-2a8ec124] {\n  position: relative;\n}\n.is-synced-icon[data-v-2a8ec124] {\n  position: absolute;\n  margin-left: -0.8em;\n}\n.is-disabled[data-v-2a8ec124] {\n  cursor: not-allowed;\n  opacity: 0.5;\n  text-decoration: none;\n}\n.is-disabled a[data-v-2a8ec124] {\n  display: inline-block;\n  text-decoration: none;\n}\n.job-stage[data-v-2a8ec124] {\n  background-color: #f9bf00 !important;\n  border-radius: var(--bulma-radius-rounded) !important;\n  color: #000 !important;\n  font-size: 0.9em;\n}\n.job-stage-select select[data-v-2a8ec124] {\n  background-color: #f9bf00 !important;\n  border-radius: var(--bulma-radius-rounded) !important;\n  color: #000 !important;\n  font-size: 0.9em;\n}\n.job-stage-select select option[data-v-2a8ec124], .job-stage-select select optgroup[data-v-2a8ec124] {\n  background-color: var(--background-color);\n  color: var(--bulma-label-color);\n}\n.is-divider[data-v-2a8ec124] {\n  margin: 0.5rem 0;\n}\n.quote-header-info[data-v-2a8ec124] {\n  max-width: calc(100vw - 50rem);\n  gap: 1rem;\n}\n.quote-header-info > div[data-v-2a8ec124]:not(:last-child) {\n  border-right: 1px solid var(--divider-background-color);\n  padding-right: 1rem;\n}\n.quote-header-info div > span[data-v-2a8ec124] {\n  white-space: nowrap;\n}\n.thin-scrollbar[data-v-2a8ec124] {\n  scrollbar-width: thin;\n  scrollbar-color: #aaa transparent;\n}\n.thin-scrollbar[data-v-2a8ec124]::-webkit-scrollbar {\n  width: 6px;\n  height: 6px;\n}\n.thin-scrollbar[data-v-2a8ec124]::-webkit-scrollbar-track {\n  background: transparent;\n}\n.thin-scrollbar[data-v-2a8ec124]::-webkit-scrollbar-thumb {\n  background-color: #aaa;\n  border-radius: 20px;\n}\n.new-owner-prompt-container .field[data-v-2a8ec124] {\n  background-color: var(--bulma-background-color);\n  border-radius: 4px;\n  cursor: pointer;\n}\n.new-owner-prompt-container .custom-radio.radio input[type=radio] + .check[data-v-2a8ec124] {\n  height: 0.8em;\n  width: 1em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("f115e7b8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("90ca02c8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("0cffb7ee", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("bd1ea448", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("8e3af2a4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("dfab00d8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("c6a68100", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("a3317d18", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("36d18826", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/classes/viewmodels/Quote/QuoteLiteModel.js":
/*!********************************************************!*\
  !*** ./src/classes/viewmodels/Quote/QuoteLiteModel.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return QuoteLiteModel; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");


var QuoteLiteModel = /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function QuoteLiteModel(quoteObj) {
  Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, QuoteLiteModel);
  this.quoteId = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.quoteId;
  this.quoteNo = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.quoteNo;
  this.subQuoteNo = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.subQuoteNo;
  this.quoteDate = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.quoteDate;
  this.labourType = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.labourType;
  this.deleted = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.deleted;
  this.excessWithGst = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.excessWithGst;
  this.labourTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.labourTotal;
  this.partTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.partTotal;
  this.miscTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.miscTotal;
  this.authorisedAmount = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.authorisedAmount;
  this.rrTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.rrTotal;
  this.repairTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.repairTotal;
  this.paintTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.paintTotal;
  this.rwaTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.rwaTotal;
  this.fgTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.fgTotal;
  this.cdTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.cdTotal;
  this.crushTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.crushTotal;
  this.mechTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.mechTotal;
  this.sublTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.sublTotal;
  this.opgTotal = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.opgTotal;
  this.totalExGst = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.totalExGst;
  this.totalIncGst = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.totalIncGst;
  this.isAssessmentEnabled = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.isAssessmentEnabled;
  this.createdBy = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.createdBy;
  this.createdDate = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.createdDate;
  this.modifiedBy = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.modifiedBy;
  this.modifiedDate = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.modifiedDate;
  this.isNew = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.isNew;
  this.isDeleted = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.isDeleted;
  this.isDirty = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.isDirty;
  this.overwriteOnConflict = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.overwriteOnConflict;
  this.mergeOnConflict = quoteObj === null || quoteObj === void 0 ? void 0 : quoteObj.mergeOnConflict;
});


/***/ }),

/***/ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue":
/*!******************************************************************!*\
  !*** ./src/components/ModuleDetailHeader/ModuleDetailHeader.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true */ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true");
/* harmony import */ var _ModuleDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ModuleDetailHeader.vue?vue&type=script&lang=js */ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true */ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ModuleDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "323aba62",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/ModuleDetailHeader/ModuleDetailHeader.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleDetailHeader.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true":
/*!***************************************************************************************************************************!*\
  !*** ./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=style&index=0&id=323aba62&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_style_index_0_id_323aba62_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleDetailHeader/ModuleDetailHeader.vue?vue&type=template&id=323aba62&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleDetailHeader_vue_vue_type_template_id_323aba62_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/ModuleDetailHeader/index.js":
/*!****************************************************!*\
  !*** ./src/components/ModuleDetailHeader/index.js ***!
  \****************************************************/
/*! exports provided: default, ModuleDetailHeader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ModuleDetailHeader_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ModuleDetailHeader.vue */ "./src/components/ModuleDetailHeader/ModuleDetailHeader.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ModuleDetailHeader", function() { return _ModuleDetailHeader_vue__WEBPACK_IMPORTED_MODULE_0__["default"]; });


/* harmony default export */ __webpack_exports__["default"] = (_ModuleDetailHeader_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);


/***/ }),

/***/ "./src/components/ModuleSubNav/ModuleSubNav.vue":
/*!******************************************************!*\
  !*** ./src/components/ModuleSubNav/ModuleSubNav.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true */ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true");
/* harmony import */ var _ModuleSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ModuleSubNav.vue?vue&type=script&lang=js */ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true */ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ModuleSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "e3da92a2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/ModuleSubNav/ModuleSubNav.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js":
/*!******************************************************************************!*\
  !*** ./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleSubNav.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=style&index=0&id=e3da92a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_style_index_0_id_e3da92a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true":
/*!************************************************************************************************!*\
  !*** ./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ModuleSubNav/ModuleSubNav.vue?vue&type=template&id=e3da92a2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModuleSubNav_vue_vue_type_template_id_e3da92a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/ModuleSubNav/index.js":
/*!**********************************************!*\
  !*** ./src/components/ModuleSubNav/index.js ***!
  \**********************************************/
/*! exports provided: default, ModuleSubNav */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ModuleSubNav_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ModuleSubNav.vue */ "./src/components/ModuleSubNav/ModuleSubNav.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ModuleSubNav", function() { return _ModuleSubNav_vue__WEBPACK_IMPORTED_MODULE_0__["default"]; });


/* harmony default export */ __webpack_exports__["default"] = (_ModuleSubNav_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);


/***/ }),

/***/ "./src/components/QuoteBanner/QuoteBanner.vue":
/*!****************************************************!*\
  !*** ./src/components/QuoteBanner/QuoteBanner.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true */ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true");
/* harmony import */ var _QuoteBanner_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteBanner.vue?vue&type=script&lang=js */ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true */ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteBanner_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "93b5493e",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/QuoteBanner/QuoteBanner.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBanner.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true":
/*!*************************************************************************************************************!*\
  !*** ./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=style&index=0&id=93b5493e&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_style_index_0_id_93b5493e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true":
/*!**********************************************************************************************!*\
  !*** ./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBanner/QuoteBanner.vue?vue&type=template&id=93b5493e&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBanner_vue_vue_type_template_id_93b5493e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue":
/*!***********************************************************************!*\
  !*** ./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366 */ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366");
/* harmony import */ var _QuoteTemplateApplyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteTemplateApplyModal.vue?vue&type=script&lang=js */ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteTemplateApplyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js":
/*!***********************************************************************************************!*\
  !*** ./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteTemplateApplyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteTemplateApplyModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteTemplateApplyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366":
/*!*****************************************************************************************************!*\
  !*** ./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366 ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteTemplateModal/QuoteTemplateApplyModal.vue?vue&type=template&id=70a98366");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteTemplateApplyModal_vue_vue_type_template_id_70a98366__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/SmsMessage.vue":
/*!*******************************************!*\
  !*** ./src/components/Sms/SmsMessage.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsMessage.vue?vue&type=template&id=51878f34 */ "./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34");
/* harmony import */ var _SmsMessage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsMessage.vue?vue&type=script&lang=js */ "./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SmsMessage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Sms/SmsMessage.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsMessage.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34":
/*!*************************************************************************!*\
  !*** ./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34 ***!
  \*************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsMessage.vue?vue&type=template&id=51878f34 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessage.vue?vue&type=template&id=51878f34");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessage_vue_vue_type_template_id_51878f34__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/SmsModal.vue":
/*!*****************************************!*\
  !*** ./src/components/Sms/SmsModal.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true */ "./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true");
/* harmony import */ var _SmsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsModal.vue?vue&type=script&lang=js */ "./src/components/Sms/SmsModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true */ "./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SmsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6de06fcc",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Sms/SmsModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Sms/SmsModal.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/components/Sms/SmsModal.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true":
/*!**************************************************************************************************!*\
  !*** ./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=style&index=0&id=6de06fcc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_style_index_0_id_6de06fcc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true":
/*!***********************************************************************************!*\
  !*** ./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsModal.vue?vue&type=template&id=6de06fcc&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsModal_vue_vue_type_template_id_6de06fcc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/SmsSend.vue":
/*!****************************************!*\
  !*** ./src/components/Sms/SmsSend.vue ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsSend.vue?vue&type=template&id=3c16462b&scoped=true */ "./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true");
/* harmony import */ var _SmsSend_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsSend.vue?vue&type=script&lang=js */ "./src/components/Sms/SmsSend.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true */ "./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SmsSend_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3c16462b",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Sms/SmsSend.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Sms/SmsSend.vue?vue&type=script&lang=js":
/*!****************************************************************!*\
  !*** ./src/components/Sms/SmsSend.vue?vue&type=script&lang=js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsSend.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true":
/*!*************************************************************************************************!*\
  !*** ./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=style&index=0&id=3c16462b&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_style_index_0_id_3c16462b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true":
/*!**********************************************************************************!*\
  !*** ./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsSend.vue?vue&type=template&id=3c16462b&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsSend.vue?vue&type=template&id=3c16462b&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsSend_vue_vue_type_template_id_3c16462b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/SmsService.js":
/*!******************************************!*\
  !*** ./src/components/Sms/SmsService.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array-buffer.constructor.js */ "./node_modules/core-js/modules/es.array-buffer.constructor.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array-buffer.slice.js */ "./node_modules/core-js/modules/es.array-buffer.slice.js");
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array-buffer.detached.js */ "./node_modules/core-js/modules/es.array-buffer.detached.js");
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer.js */ "./node_modules/core-js/modules/es.array-buffer.transfer.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer-to-fixed-length.js */ "./node_modules/core-js/modules/es.array-buffer.transfer-to-fixed-length.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.typed-array.uint8-array.js */ "./node_modules/core-js/modules/es.typed-array.uint8-array.js");
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.typed-array.at.js */ "./node_modules/core-js/modules/es.typed-array.at.js");
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.typed-array.copy-within.js */ "./node_modules/core-js/modules/es.typed-array.copy-within.js");
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.typed-array.every.js */ "./node_modules/core-js/modules/es.typed-array.every.js");
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.typed-array.fill.js */ "./node_modules/core-js/modules/es.typed-array.fill.js");
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.typed-array.filter.js */ "./node_modules/core-js/modules/es.typed-array.filter.js");
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.typed-array.find.js */ "./node_modules/core-js/modules/es.typed-array.find.js");
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-index.js */ "./node_modules/core-js/modules/es.typed-array.find-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last.js */ "./node_modules/core-js/modules/es.typed-array.find-last.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last-index.js */ "./node_modules/core-js/modules/es.typed-array.find-last-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.typed-array.for-each.js */ "./node_modules/core-js/modules/es.typed-array.for-each.js");
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.typed-array.includes.js */ "./node_modules/core-js/modules/es.typed-array.includes.js");
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.typed-array.index-of.js */ "./node_modules/core-js/modules/es.typed-array.index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.typed-array.iterator.js */ "./node_modules/core-js/modules/es.typed-array.iterator.js");
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.typed-array.join.js */ "./node_modules/core-js/modules/es.typed-array.join.js");
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.typed-array.last-index-of.js */ "./node_modules/core-js/modules/es.typed-array.last-index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.typed-array.map.js */ "./node_modules/core-js/modules/es.typed-array.map.js");
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce.js */ "./node_modules/core-js/modules/es.typed-array.reduce.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce-right.js */ "./node_modules/core-js/modules/es.typed-array.reduce-right.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.typed-array.reverse.js */ "./node_modules/core-js/modules/es.typed-array.reverse.js");
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.typed-array.set.js */ "./node_modules/core-js/modules/es.typed-array.set.js");
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.typed-array.slice.js */ "./node_modules/core-js/modules/es.typed-array.slice.js");
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.typed-array.some.js */ "./node_modules/core-js/modules/es.typed-array.some.js");
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.typed-array.sort.js */ "./node_modules/core-js/modules/es.typed-array.sort.js");
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.typed-array.subarray.js */ "./node_modules/core-js/modules/es.typed-array.subarray.js");
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-locale-string.js */ "./node_modules/core-js/modules/es.typed-array.to-locale-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-reversed.js */ "./node_modules/core-js/modules/es.typed-array.to-reversed.js");
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-sorted.js */ "./node_modules/core-js/modules/es.typed-array.to-sorted.js");
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-string.js */ "./node_modules/core-js/modules/es.typed-array.to-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.typed-array.with.js */ "./node_modules/core-js/modules/es.typed-array.with.js");
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _services_protobuf_api__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/services/protobuf-api */ "./src/services/protobuf-api.js");













































/* harmony default export */ __webpack_exports__["default"] = ({
  getEntitySummaries: function getEntitySummaries(filter) {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var serialised, url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            serialised = _this.serialiseMessageFilter(filter);
            url = "/sms/list/".concat(serialised);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  serialiseMessageFilter: function serialiseMessageFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageFilter.proto */ "./src/assets/proto/sms/SmsMessageFilter.proto");
    var filterMessage = entityProto.SmsMessageFilter.SmsMessageFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_43___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  getSmsMessageDropdownProto: function getSmsMessageDropdownProto(filter) {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var serialised, result, proto, message, entity;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            serialised = encodeURIComponent(_this2.serialiseSmsMessageDropdownFilter(filter));
            _context2.n = 1;
            return Object(_services_protobuf_api__WEBPACK_IMPORTED_MODULE_44__["default"])("/sms/protobuf/sendsms/listcombo?filter=".concat(serialised));
          case 1:
            result = _context2.v;
            proto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageDropdown.proto */ "./src/assets/proto/sms/SmsMessageDropdown.proto");
            message = proto.SmsMessageDropdown.SmsMessageDropdownModel;
            entity = message.decode(new Uint8Array(result.data));
            return _context2.a(2, entity.assets);
        }
      }, _callee2);
    }))();
  },
  serialiseSmsMessageDropdownFilter: function serialiseSmsMessageDropdownFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageDropdownFilter.proto */ "./src/assets/proto/sms/SmsMessageDropdownFilter.proto");
    var filterMessage = entityProto.SmsMessageDropdownFilter.SmsMessageDropdownFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_43___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  sendSms: function sendSms(info) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].post('/sms/send', info);
          case 1:
            result = _context3.v;
            return _context3.a(2, result.data);
        }
      }, _callee3);
    }))();
  },
  postEntity: function postEntity(entity) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].post('/sms/new', entity);
  },
  putEntity: function putEntity(entity) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].put("/sms/".concat(entity.id), entity);
  },
  deleteEntity: function deleteEntity(id) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].delete('/sms/' + id);
  }
});

/***/ }),

/***/ "./src/components/Sms/columns.js":
/*!***************************************!*\
  !*** ./src/components/Sms/columns.js ***!
  \***************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Message Template', 'message', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ }),

/***/ "./src/components/Sms/index.js":
/*!*************************************!*\
  !*** ./src/components/Sms/index.js ***!
  \*************************************/
/*! exports provided: SmsSend, SmsMessage, SmsModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsSend__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsSend */ "./src/components/Sms/SmsSend.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SmsSend", function() { return _SmsSend__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _SmsModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsModal */ "./src/components/Sms/SmsModal.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SmsModal", function() { return _SmsModal__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _SmsMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SmsMessage */ "./src/components/Sms/SmsMessage.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SmsMessage", function() { return _SmsMessage__WEBPACK_IMPORTED_MODULE_2__["default"]; });






/***/ }),

/***/ "./src/components/VehicleButterfly/index.js":
/*!**************************************************!*\
  !*** ./src/components/VehicleButterfly/index.js ***!
  \**************************************************/
/*! exports provided: VehicleButterflySelector, VehicleButterflyModal, VehicleButterflyFilterModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleButterflySelector", function() { return VehicleButterflySelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleButterflyModal", function() { return VehicleButterflyModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleButterflyFilterModal", function() { return VehicleButterflyFilterModal; });
var VehicleButterflySelector = function VehicleButterflySelector(r) {
  return Promise.all(/*! require.ensure | vehicle-butterfly-chunk */[__webpack_require__.e(0), __webpack_require__.e("vehicle-butterfly-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./VehicleButterflySelector.vue */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var VehicleButterflyModal = function VehicleButterflyModal(r) {
  return Promise.all(/*! require.ensure | vehicle-butterfly-chunk */[__webpack_require__.e(0), __webpack_require__.e("vehicle-butterfly-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./VehicleButterflyModal.vue */ "./src/components/VehicleButterfly/VehicleButterflyModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var VehicleButterflyFilterModal = function VehicleButterflyFilterModal(r) {
  return Promise.all(/*! require.ensure | vehicle-butterfly-chunk */[__webpack_require__.e(0), __webpack_require__.e("vehicle-butterfly-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./VehicleButterflyFilterModal.vue */ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/components/XmlViewer/index.js":
/*!*******************************************!*\
  !*** ./src/components/XmlViewer/index.js ***!
  \*******************************************/
/*! exports provided: XmlViewerModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XmlViewerModal", function() { return XmlViewerModal; });
// import XmlViewerModal from './XmlViewerModal'
var XmlViewerModal = function XmlViewerModal(r) {
  return Promise.all(/*! require.ensure | xmlviewer-components-chunk */[__webpack_require__.e("audittrail-chunk~estimagemessage-chunk~estimagemessageview-chunk~ormmessage-chunk~ormmessageview-chu~f9dcd210"), __webpack_require__.e("audittrail-chunk~ormmessage-chunk~ormmessageview-chunk~pnetmessage-chunk~pnetmessageview-chunk~quote~6a43fb9b"), __webpack_require__.e("xmlviewer-components-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./XmlViewerModal.vue */ "./src/components/XmlViewer/XmlViewerModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/views/quote/QuoteDetail.vue":
/*!*****************************************!*\
  !*** ./src/views/quote/QuoteDetail.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true */ "./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true");
/* harmony import */ var _QuoteDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteDetail.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true */ "./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true");
/* harmony import */ var _QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss */ "./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3210eb10",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true":
/*!**************************************************************************************************!*\
  !*** ./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=0&id=3210eb10&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_0_id_3210eb10_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss":
/*!**************************************************************************************!*\
  !*** ./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=style&index=1&id=3210eb10&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_style_index_1_id_3210eb10_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true":
/*!***********************************************************************************!*\
  !*** ./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetail.vue?vue&type=template&id=3210eb10&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetail_vue_vue_type_template_id_3210eb10_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteOrmValidation.js":
/*!***********************************************!*\
  !*** ./src/views/quote/QuoteOrmValidation.js ***!
  \***********************************************/
/*! exports provided: ormValidationMessages, ormValidationRules, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ormValidationMessages", function() { return ormValidationMessages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ormValidationRules", function() { return ormValidationRules; });
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

var isOrm = function isOrm() {
  return this.entity != null && this.entity.orm != null;
};

// ORM-specific validation must fire ONLY while the user is submitting the quote
// at the ORM page (Send Quote / Send Tax Invoice). `isOrmValidation` is set
// true by validateJobStartEndForOrm() during those flows and reset afterwards
// (and intentionally left true on a FAILED submit so the user keeps seeing the
// errors). Gating every ORM rule behind this keeps ORM errors — and their
// inline messages — out of normal Save / autosave on an ORM quote.
var isOrmSubmit = function isOrmSubmit() {
  return isOrm.call(this) && this.isOrmValidation === true;
};
var ormValidationMessages = {
  claimNo: {
    ormRequired: 'Claim Number is required by ORM',
    ormMaxLength: 'Claim Number cannot exceed 15 characters'
  },
  companyName: {
    ormMaxLength: 'Company Name cannot exceed 45 characters'
  },
  paintCode: {
    ormMaxLength: 'Paint Code cannot exceed 10 characters'
  },
  rego: {
    ormMaxLength: 'Registration No. cannot exceed 9 characters'
  }
};
var ormValidationRules = {
  ormHeaderGroup: ['vehicle.bodyId2', 'vehicle.buildMonth', 'vehicle.buildYear', 'vehicle.transmissionType', 'vehicle.paintCode', 'vehicle.rego', 'customer.lastname', 'customer.firstname', 'customer.companyName', 'entity.claimNo', 'entity.damageSeverity'],
  ormSummaryGroup: ['entity.jobStart', 'entity.jobEnd', 'entity.quoter', 'entity.odometer', 'vehicle.colour', 'entity.refuseBookRepairReason'],
  repairLateGroup: ['entity.repairLateReason'],
  estimateJobStartEnd: ['entity.jobStart', 'entity.jobEnd'],
  entity: {
    odometer: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      validOdometer: function validOdometer(value) {
        if (!isOrmSubmit.call(this)) return true;
        return value > 0 && value <= 9999999;
      }
    },
    claimNo: {
      ormRequired: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 15;
      }
    },
    jobStart: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      bothRequired: function bothRequired() {
        if (!isOrmSubmit.call(this)) return true;
        return !!(this.entity.jobStart && this.entity.jobEnd);
      },
      validJobStart: function validJobStart(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (value && this.entity.jobEnd) {
          return value <= this.entity.jobEnd;
        }
        return true;
      }
    },
    jobEnd: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      bothRequired: function bothRequired() {
        if (!isOrmSubmit.call(this)) return true;
        return !!(this.entity.jobStart && this.entity.jobEnd);
      },
      validJobEnd: function validJobEnd(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (value && this.entity.jobStart) {
          return value >= this.entity.jobStart;
        }
        return true;
      }
    },
    damageSeverity: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        return isOrmSubmit.call(this) && this.insurer && this.insurer.damageSeverity;
      }),
      validDamageSeverity: function validDamageSeverity(value) {
        if (!isOrmSubmit.call(this)) return true;
        return value > 0 || !(this.insurer && this.insurer.damageSeverity);
      }
    },
    refuseBookRepairReason: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        if (!isOrmSubmit.call(this)) return false;
        if (this.entity.isRepairBooked == null || this.entity.isRepairBooked == undefined) return false;
        return !this.entity.isRepairBooked && this.entity.repx != null;
      })
    },
    repairLateReason: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        if (!isOrmSubmit.call(this)) return false;
        return this.entity.repx != null && this.entity.isArriveForInspection != null && this.entity.isArriveForInspection == false;
      })
    }
  },
  customer: {
    companyName: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 45;
      }
    }
  },
  vehicle: {
    bodyId2: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    buildMonth: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    buildYear: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    paintCode: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 10;
      }
    },
    rego: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 9;
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      isOrmValidation: false
    };
  },
  methods: {
    validateJobStartEndForOrm: function validateJobStartEndForOrm() {
      this.isOrmValidation = true;
      this.$v.entity.jobStart.$reset();
      this.$v.entity.jobEnd.$reset();
      this.$v.entity.jobStart.$touch();
      this.$v.entity.jobEnd.$touch();
    },
    touchOrmHeaderValidators: function touchOrmHeaderValidators() {
      this.$v.ormHeaderGroup.$touch();
      this.$v.entity.claimNo.$touch();
      this.$v.entity.damageSeverity.$touch();
      this.$v.vehicle.bodyId2.$touch();
      this.$v.vehicle.buildMonth.$touch();
      this.$v.vehicle.buildYear.$touch();
      this.$v.vehicle.transmissionType.$touch();
      this.$v.vehicle.paintCode.$touch();
      this.$v.vehicle.rego.$touch();
      this.$v.customer.companyName.$touch();
      this.$v.customer.firstname.$touch();
      this.$v.customer.lastname.$touch();
    },
    touchOrmSummaryValidators: function touchOrmSummaryValidators() {
      this.$v.ormSummaryGroup.$touch();
      this.$v.entity.quoter.$touch();
      this.$v.entity.odometer.$touch();
      this.$v.entity.refuseBookRepairReason.$touch();
      this.$v.vehicle.colour.$touch();
      this.$v.vehicle.paintCode.$touch();
      this.$v.customer.companyName.$touch();
      this.$v.customer.firstname.$touch();
      this.$v.customer.lastname.$touch();
    },
    resetOrmValidation: function resetOrmValidation() {
      this.isOrmValidation = false;
    }
  }
});

/***/ }),

/***/ "./src/views/quote/QuoteSubNav.vue":
/*!*****************************************!*\
  !*** ./src/views/quote/QuoteSubNav.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true */ "./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true");
/* harmony import */ var _QuoteSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteSubNav.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true */ "./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7ea01482",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteSubNav.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSubNav.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true":
/*!**************************************************************************************************!*\
  !*** ./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=style&index=0&id=7ea01482&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_style_index_0_id_7ea01482_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true":
/*!***********************************************************************************!*\
  !*** ./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSubNav.vue?vue&type=template&id=7ea01482&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSubNav_vue_vue_type_template_id_7ea01482_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteValidation.js":
/*!********************************************!*\
  !*** ./src/views/quote/QuoteValidation.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/merge */ "./node_modules/lodash/merge.js");
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_merge__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./QuoteOrmValidation */ "./src/views/quote/QuoteOrmValidation.js");






var dateValidator = function dateValidator(value) {
  if (value && value !== '__/__/____') {
    var date = luxon__WEBPACK_IMPORTED_MODULE_3__["DateTime"].fromISO(value);
    return date.isValid;
  } else {
    return value !== undefined;
  }
};
var customMinLength = function customMinLength(value, vehicle) {
  if (vehicle && vehicle.bodyId && vehicle.bodyId.toUpperCase() === 'O') {
    return true;
  } else if (value !== null || value != undefined) {
    return value.length >= 7 || value.length === 0;
  }
  return true;
};
var baseValidationRules = {
  detailGroup: ['entity.quoteId', 'entity.vehicleId', 'entity.insurerId', 'entity.quoter', 'entity.authorisedDate'],
  vehicleCustomerGroup: ['entity.customerId'],
  vehicleCustomerIsActiveGroup: ['quoteCustomer.active', 'quoteVehicle.isActive'],
  quoteHeaderGroup: ['entity.quoteId', 'entity.vehicleId', 'entity.insurerId', 'vehicle.rego', 'vehicle.model', 'vehicle.bodyId', 'vehicle.bodyId2', 'vehicle.paintGroup', 'customer.lastname', 'customer.firstname', 'customer.companyName', 'customer.emails', 'customer.contacts', 'insurer.name'],
  audaNetHeaderGroup: ['entity.claimNo'],
  entity: {
    quoteId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
    },
    quoter: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    vehicleId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
    },
    customerId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"],
      sameAsVehicle: function sameAsVehicle(value) {
        return this.vehicle && this.vehicle.customer ? value === this.vehicle.customer.key : true;
      }
    },
    insurerId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
    },
    authorisedDate: {
      validDate: dateValidator
    },
    labours: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        }
      }
    },
    others: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        }
      }
    },
    parts: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        partNo: {
          maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["maxLength"])(24)
        }
      }
    },
    opgs: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        }
      }
    },
    miscs: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        }
      }
    },
    sublets: {
      $each: {
        itemNo: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        },
        itemDesc: {
          required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
            return !model.deleted;
          })
        }
      }
    },
    invoices: {
      $each: {
        assetId: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
          validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
        }
      }
    },
    claimNo: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function () {
        return this.entity.audatex !== null && this.entity.audatex !== undefined;
      })
    }
  },
  vehicle: {
    rego: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    customer: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    model: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    bodyId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    bodyId2: {},
    paintGroup: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    vin: {
      customMinLength: customMinLength,
      maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["maxLength"])(17)
    },
    id: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
    },
    buildMonth: {},
    buildYear: {},
    colour: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    transmissionType: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    }
  },
  customer: {
    companyName: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
        return !model.isPerson;
      }),
      isNotWhitespaceOnly: function isNotWhitespaceOnly(value, model) {
        if (model.isPerson) return true;
        return typeof value === 'string' && value.trim().length > 0;
      }
    },
    firstname: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
        return model.isPerson;
      }),
      isNotWhitespaceOnly: function isNotWhitespaceOnly(value, model) {
        if (!model.isPerson) return true;
        return typeof value === 'string' && value.trim().length > 0;
      }
    },
    lastname: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (model) {
        return model.isPerson;
      }),
      isNotWhitespaceOnly: function isNotWhitespaceOnly(value, model) {
        if (!model.isPerson) return true;
        return typeof value === 'string' && value.trim().length > 0;
      }
    },
    emails: {
      $each: {
        address: {
          email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["email"]
        }
      }
    },
    contacts: {
      $each: {
        contact: {
          firstName: {
            required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (contactWrapper) {
              return true;
              console.log(contactWrapper);
              return contactWrapper.isDefault === true && contactWrapper.isDeleted === false;
            })
          },
          lastName: {
            required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["requiredIf"])(function (contactWrapper) {
              return true;
              return contactWrapper.isDefault === true && contactWrapper.isDeleted === false;
            })
          }
        }
      }
    }
  },
  insurer: {
    insurerId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_2__["guidValidator"]
    },
    name: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
    },
    abn: {
      minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["minLength"])(11),
      validAbn: _components_validators__WEBPACK_IMPORTED_MODULE_2__["abnValidator"]
    },
    arbn: {
      minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["minLength"])(9)
    }
  },
  quoteCustomer: {
    active: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      isActive: function isActive(value) {
        return value === true;
      }
    }
  },
  quoteVehicle: {
    isActive: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"],
      isActive: function isActive(value) {
        return value === true;
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  mixins: [_QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_5__["default"]],
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()({}, baseValidationRules, _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_5__["ormValidationRules"])
});

/***/ }),

/***/ "./src/views/quote/QuoteView.vue":
/*!***************************************!*\
  !*** ./src/views/quote/QuoteView.vue ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true */ "./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true");
/* harmony import */ var _QuoteView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteView.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true */ "./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2a8ec124",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteView.vue?vue&type=script&lang=js":
/*!***************************************************************!*\
  !*** ./src/views/quote/QuoteView.vue?vue&type=script&lang=js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true":
/*!************************************************************************************************!*\
  !*** ./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=style&index=0&id=2a8ec124&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_style_index_0_id_2a8ec124_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true":
/*!*********************************************************************************!*\
  !*** ./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteView.vue?vue&type=template&id=2a8ec124&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteView_vue_vue_type_template_id_2a8ec124_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/helpers/QuoteAutoSaveHelper.js":
/*!********************************************************!*\
  !*** ./src/views/quote/helpers/QuoteAutoSaveHelper.js ***!
  \********************************************************/
/*! exports provided: createAutoSaveHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createAutoSaveHelper", function() { return createAutoSaveHelper; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.flat-map.js */ "./node_modules/core-js/modules/es.array.flat-map.js");
/* harmony import */ var core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.array.unscopables.flat-map.js */ "./node_modules/core-js/modules/es.array.unscopables.flat-map.js");
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.promise.all-settled.js */ "./node_modules/core-js/modules/es.promise.all-settled.js");
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ../QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ../QuoteAutoSaveService */ "./src/views/quote/QuoteAutoSaveService.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _classes_viewmodels_Quote_QuoteLiteModel__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @/classes/viewmodels/Quote/QuoteLiteModel */ "./src/classes/viewmodels/Quote/QuoteLiteModel.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ../route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");



















































function createAutoSaveHelper(vm) {
  var quoteItemCollectionKeys = ['labours', 'parts', 'miscs', 'others', 'sublets'];
  var setAutoSaveState = function setAutoSaveState() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var isEditing = state.isEditing,
      isSaving = state.isSaving,
      isFailed = state.isFailed,
      failMessage = state.failMessage;
    if (typeof isEditing === 'boolean') {
      vm.autoSaveStatus.isEditing = isEditing;
      vm.autoSaveStatus.isDiffChanged = isEditing;
    }
    if (typeof isSaving === 'boolean') {
      vm.autoSaveStatus.isSaving = isSaving;
    }
    if (typeof isFailed === 'boolean') {
      vm.autoSaveStatus.isFailed = isFailed;
      if (!isFailed && typeof failMessage === 'undefined') {
        vm.autoSaveStatus.failMessage = '';
      }
    }
    if (typeof failMessage === 'string') {
      vm.autoSaveStatus.failMessage = failMessage;
    }
  };
  var isAnyEntityNew = function isAnyEntityNew() {
    return vm.entity && vm.entity.isNew || vm.customer && vm.customer.isNew || vm.vehicle && vm.vehicle.isNew || vm.insurer && vm.insurer.isNew;
  };
  var registerAutoSaveFailure = function registerAutoSaveFailure(failMessage) {
    vm.autoSaveFailureCount += 1;
    var shouldLock = !vm.autoSaveDisabled && vm.autoSaveFailureCount >= vm.autoSaveFailureLimit;
    if (shouldLock) {
      vm.autoSaveDisabled = true;
      if (vm.autoSaveQuote && typeof vm.autoSaveQuote.cancel === 'function') {
        vm.autoSaveQuote.cancel();
      }
      if (vm.autoUpdateQuoteHeader && typeof vm.autoUpdateQuoteHeader.cancel === 'function') {
        vm.autoUpdateQuoteHeader.cancel();
      }
      vm.$notification.openNotificationWithType('danger', 'Autosave Paused', 'Autosave has been paused due to repeated failures. Please check your connection and try saving manually.');
    }
  };
  var resetAutoSaveFailures = function resetAutoSaveFailures() {
    vm.autoSaveFailureCount = 0;
    if (vm.autoSaveDisabled && vm.autoSaveEnabledToggle) {
      vm.autoSaveDisabled = false;
    }
  };
  var hasPendingAutoSaveDiffs = function hasPendingAutoSaveDiffs() {
    return Boolean(vm.snapshotDiff || vm.snapshotDiffCustomer || vm.snapshotDiffVehicle || vm.snapshotDiffInsurer);
  };
  var hasPendingAutoSaveWork = function hasPendingAutoSaveWork() {
    return vm.autoSaveStatus.isSaving || vm.autoSaveStatus.isEditing || vm.headerAutosaveInFlight || hasPendingItemsSave();
  };
  var getExpandedQuoteItemId = function getExpandedQuoteItemId() {
    var expandedQuoteItem = document.querySelector('.quote-builder-item-row.is-selected');
    return expandedQuoteItem ? expandedQuoteItem.id : null;
  };
  var isAnyQuoteItemDropdownOpen = function isAnyQuoteItemDropdownOpen() {
    // Scope queries to the quote UI to avoid blocking unrelated dropdowns elsewhere in the app.
    // QuoteView renders quote content inside '.quote-body'.
    var scope = document.querySelector('.quote-body') || document;

    // Item description autocomplete (BulmaAutocomplete)
    try {
      var dropdownMenus = scope.querySelectorAll('.autocomplete .dropdown-menu');
      var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_6__["default"])(dropdownMenus),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var el = _step.value;
          if (!el) continue;
          var style = window.getComputedStyle(el);
          if (style && style.display !== 'none' && style.visibility !== 'hidden') {
            return true;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    } catch (e) {
      // no-op
    }

    // Sublet vendor dropdown (vue-multiselect)
    if (scope.querySelector('.multiselect--active')) {
      return true;
    }

    // Sublet type is a native <select>; we can't reliably detect "open", so treat focused as "open".
    var activeElement = document.activeElement;
    if (activeElement && activeElement.tagName === 'SELECT') {
      // Only treat selects within the quote UI as blocking.
      if (!activeElement.closest || !activeElement.closest('.quote-body')) return false;
      var id = activeElement.getAttribute('id') || '';
      if (id.endsWith('-sublet-type')) {
        return true;
      }
    }
    return false;
  };

  // True when the user is actively editing an input control inside a quote ITEM ROW
  // (textbox, textarea, native select, or contenteditable). Saving while a row control
  // is focused must be avoided: the post-save entity refresh re-renders the item rows,
  // which steals focus and closes any open dropdown mid-interaction. Scoped to the item
  // rows so editing in the butterfly/add panel or header fields doesn't block item saves.
  var isEditableElementFocused = function isEditableElementFocused() {
    var el = document.activeElement;
    if (!el || el === document.body) return false;
    if (typeof el.closest !== 'function' || !el.closest('.quote-builder-item-row')) return false;
    var tag = el.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
    if (el.isContentEditable) return true;
    return false;
  };

  // The user is "busy" — and a save must be deferred — while either an editable
  // control is focused or a custom dropdown (autocomplete / multiselect) is open.
  var isQuoteItemEditInProgress = function isQuoteItemEditInProgress() {
    return isEditableElementFocused() || isAnyQuoteItemDropdownOpen();
  };
  var getFocusedItemInfo = function getFocusedItemInfo() {
    var activeElement = document.activeElement;
    if (!activeElement || typeof activeElement.closest !== 'function') return null;

    // Determine which quote item row we're in.
    var rowEl = activeElement.closest('.quote-builder-item-row');
    var rowId = rowEl && rowEl.id ? rowEl.id : null;
    if (!rowId) return null;

    // Find the item across all item arrays.
    var allItems = quoteItemCollectionKeys.flatMap(function (key) {
      var _vm$entity;
      return ((_vm$entity = vm.entity) === null || _vm$entity === void 0 ? void 0 : _vm$entity[key]) || [];
    });
    var item = allItems.find(function (i) {
      return i && i.quoteItemId === rowId;
    });
    if (!item) return null;

    // Capture the id suffix of the focused field within the row.
    // Most quote-builder inputs use ids like `${quoteItemId}-itemDesc`, `${quoteItemId}-unit`, etc.
    // If the active element itself doesn't have the id, walk up the DOM within the row.
    var fieldElement = null;
    if (activeElement.id && activeElement.id.startsWith(rowId)) {
      fieldElement = activeElement;
    } else {
      var cursor = activeElement;
      while (cursor && cursor !== rowEl) {
        if (cursor.id && cursor.id.startsWith(rowId)) {
          fieldElement = cursor;
          break;
        }
        cursor = cursor.parentElement;
      }
    }
    var fieldSuffix = fieldElement && fieldElement.id ? fieldElement.id.substring(rowId.length) : '-itemDesc';
    return {
      lineNumber: item.lineNumber,
      itemType: item.itemType,
      itemDesc: item.itemDesc,
      // IMPORTANT: this suffix is concatenated by QuoteBuilderItemsView as `${newItemId}${fieldSuffix}`.
      // Keep the leading '-' so ids resolve correctly.
      fieldSuffix: fieldSuffix
    };
  };
  var findItemIdByLineAndType = function findItemIdByLineAndType(lineNumber, itemType) {
    var allItems = quoteItemCollectionKeys.flatMap(function (key) {
      var _vm$entity2;
      return ((_vm$entity2 = vm.entity) === null || _vm$entity2 === void 0 ? void 0 : _vm$entity2[key]) || [];
    });
    var item = allItems.find(function (i) {
      return i.lineNumber === lineNumber && i.itemType === itemType;
    });
    return item ? item.quoteItemId : null;
  };

  // Blank = null/undefined or whitespace-only. Blank-description items are never
  // autosaved; new ones are purged on tab leave and synced ones revert to last-saved.
  var isBlankItemDesc = function isBlankItemDesc(desc) {
    return desc === null || desc === undefined || String(desc).trim() === '';
  };
  var isValidItemAutoSave = function isValidItemAutoSave(item) {
    return !!item && !isBlankItemDesc(item.itemDesc);
  };
  var autoSaveQuoteAssets = /*#__PURE__*/function () {
    var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee() {
      var autoSaveEnabled, promises, savedAssets, preSave, results, failed, _e$response, msg, ignoreSaveFields, canReload, _t, _t2;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context) {
        while (1) switch (_context.p = _context.n) {
          case 0:
            autoSaveEnabled = vm.autoSaveEnabled && !vm.entity.isNew && !vm.entity.readOnly;
            promises = []; // Records which header assets reached the database, so a failed autosave can reload them (PCK-153)
            savedAssets = {}; // Copies taken before saving, so a failed autosave doesn't reload over edits made while it was in flight
            preSave = {
              customer: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.customer),
              vehicle: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.vehicle),
              insurer: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.insurer)
            };
            _context.p = 1;
            if (!vm.snapshotDiffCustomer) {
              _context.n = 3;
              break;
            }
            _context.n = 2;
            return _services__WEBPACK_IMPORTED_MODULE_45__["CustomerService"].putCustomer(vm.customer, vm.snapshotDiffCustomer, autoSaveEnabled ? true : false);
          case 2:
            savedAssets.customer = true;
          case 3:
            if (vm.snapshotDiffVehicle) {
              vm.vehicle.excludeQuoteId = vm.entity.quoteId;
              promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_45__["VehicleService"].putEntity(vm.vehicle, vm.snapshotDiffVehicle, autoSaveEnabled ? true : false).then(function () {
                savedAssets.vehicle = true;
              }));
            }
            if (vm.snapshotDiffInsurer) {
              promises.splice(promises.length, 1, _services__WEBPACK_IMPORTED_MODULE_45__["InsurerService"].putInsurer(vm.insurer, vm.snapshotDiffInsurer, autoSaveEnabled ? true : false).then(function () {
                savedAssets.insurer = true;
              }));
            }
            if (!(promises.length > 0)) {
              _context.n = 5;
              break;
            }
            _context.n = 4;
            return Promise.allSettled(promises);
          case 4:
            results = _context.v;
            failed = results.find(function (r) {
              return r.status === 'rejected';
            });
            if (!failed) {
              _context.n = 5;
              break;
            }
            throw failed.reason;
          case 5:
            return _context.a(2, true);
          case 6:
            _context.p = 6;
            _t = _context.v;
            vm.customerSaveAction = '';
            msg = ((_e$response = _t.response) === null || _e$response === void 0 || (_e$response = _e$response.data) === null || _e$response === void 0 ? void 0 : _e$response.message) || _t.message;
            vm.$notification.openNotificationWithType('danger', 'Quote Assets', msg);
            // Same as the manual save: reload the assets that did save, otherwise the next autosave
            // re-sends their now-saved new phones/emails/addresses as new (PCK-153). An asset edited
            // since the save started keeps the user's edits; a later autosave failure reloads it.
            // deepDiff and excludeQuoteId are written onto the asset by the save itself, so ignore them.
            ignoreSaveFields = function ignoreSaveFields(path, key) {
              return path.length === 0 && ['deepDiff', 'excludeQuoteId'].includes(key);
            };
            canReload = function canReload(key) {
              return !!savedAssets[key] && !deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(preSave[key], vm[key], ignoreSaveFields);
            };
            _context.p = 7;
            _context.n = 8;
            return vm.refreshSavedQuoteAssets({
              customer: canReload('customer'),
              vehicle: canReload('vehicle'),
              insurer: canReload('insurer')
            });
          case 8:
            _context.n = 10;
            break;
          case 9:
            _context.p = 9;
            _t2 = _context.v;
            // Must not escape: the caller only clears headerAutosaveInFlight when this returns
            console.error('Failed to reload quote assets after autosave failure:', _t2);
          case 10:
            return _context.a(2, false);
        }
      }, _callee, null, [[7, 9], [1, 6]]);
    }));
    return function autoSaveQuoteAssets() {
      return _ref.apply(this, arguments);
    };
  }();
  var hasHeaderQuoteIdChanges = function hasHeaderQuoteIdChanges() {
    if (!vm.entity || !vm.baseSnapshot) return false;
    var fields = ['vehicleId', 'customerId', 'insurerId'];
    return fields.some(function (field) {
      var _vm$baseSnapshot, _vm$entity3;
      return ((_vm$baseSnapshot = vm.baseSnapshot) === null || _vm$baseSnapshot === void 0 ? void 0 : _vm$baseSnapshot[field]) !== ((_vm$entity3 = vm.entity) === null || _vm$entity3 === void 0 ? void 0 : _vm$entity3[field]);
    });
  };
  var saveQuoteAfterHeaderChangeNow = /*#__PURE__*/function () {
    var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee2() {
      var _vm$vehicle, _vm$customer;
      var diff, isCustomerInfoChanged;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            if (!(!vm.entity || !vm.baseSnapshot)) {
              _context2.n = 1;
              break;
            }
            return _context2.a(2, true);
          case 1:
            if (!(vm.entity.readOnly || isAnyEntityNew())) {
              _context2.n = 2;
              break;
            }
            return _context2.a(2, true);
          case 2:
            if (!vm.validateError) {
              _context2.n = 3;
              break;
            }
            setAutoSaveState({
              isFailed: true,
              failMessage: 'Quote couldn\'t be saved due to validation errors.'
            });
            return _context2.a(2, false);
          case 3:
            // Save the quote itself (including any changes that the header selection caused,
            // e.g. insurer selection updating markups/rates/template items).
            diff = deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(vm.baseSnapshot, vm.entity, function (path, key) {
              return path.length === 0 && key === 'modifiedDate';
            });
            if (diff) {
              _context2.n = 4;
              break;
            }
            return _context2.a(2, true);
          case 4:
            _context2.n = 5;
            return vm.triggerIsNewOwnerPrompt();
          case 5:
            isCustomerInfoChanged = _context2.v;
            if (!(!((_vm$vehicle = vm.vehicle) !== null && _vm$vehicle !== void 0 && _vm$vehicle.isNew) && !((_vm$customer = vm.customer) !== null && _vm$customer !== void 0 && _vm$customer.isNew) && isCustomerInfoChanged)) {
              _context2.n = 6;
              break;
            }
            vm.isCustomerCreateModifyModalActive = true;
            return _context2.a(2, false);
          case 6:
            _context2.n = 7;
            return vm.assignLineNumbers(false);
          case 7:
            _context2.n = 8;
            return _QuoteService__WEBPACK_IMPORTED_MODULE_43__["default"].putEntity(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity), diff);
          case 8:
            // Mark saved locally by updating the base snapshot.
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            return _context2.a(2, true);
        }
      }, _callee2);
    }));
    return function saveQuoteAfterHeaderChangeNow() {
      return _ref2.apply(this, arguments);
    };
  }();
  var autoSave = /*#__PURE__*/function () {
    var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee3() {
      var isCustomerInfoChanged, _error$response, _t3;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context3) {
        while (1) switch (_context3.p = _context3.n) {
          case 0:
            _context3.p = 0;
            if (!vm.validateError) {
              _context3.n = 1;
              break;
            }
            console.error('Validation errors', vm.$v);
            return _context3.a(2, {
              status: 'failed',
              failMessage: 'Quote couldn\'t be saved due to validation errors.'
            });
          case 1:
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            _context3.n = 2;
            return vm.triggerIsNewOwnerPrompt();
          case 2:
            isCustomerInfoChanged = _context3.v;
            if (!(!vm.vehicle.isNew && !vm.customer.isNew && isCustomerInfoChanged)) {
              _context3.n = 3;
              break;
            }
            return _context3.a(2, {
              status: 'blocked'
            });
          case 3:
            _context3.n = 4;
            return vm.assignLineNumbers(false);
          case 4:
            if (vm.snapshotDiff) {
              _context3.n = 5;
              break;
            }
            return _context3.a(2, {
              status: 'no-diff'
            });
          case 5:
            _context3.n = 6;
            return _QuoteService__WEBPACK_IMPORTED_MODULE_43__["default"].putEntity(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity), vm.snapshotDiff);
          case 6:
            _context3.n = 7;
            return vm.getEntity(true, true);
          case 7:
            return _context3.a(2, {
              status: 'saved'
            });
          case 8:
            _context3.p = 8;
            _t3 = _context3.v;
            console.error('Quote auto save failed', _t3);
            if (!((_t3 === null || _t3 === void 0 || (_error$response = _t3.response) === null || _error$response === void 0 ? void 0 : _error$response.status) === 409)) {
              _context3.n = 9;
              break;
            }
            return _context3.a(2, {
              status: 'conflict'
            });
          case 9:
            return _context3.a(2, {
              status: 'error',
              failMessage: (_t3 === null || _t3 === void 0 ? void 0 : _t3.message) || 'Automatic quote save failed.'
            });
        }
      }, _callee3, null, [[0, 8]]);
    }));
    return function autoSave() {
      return _ref3.apply(this, arguments);
    };
  }();

  // Define autosave functions
  var autoSaveQuote = /*#__PURE__*/function () {
    var _ref4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee4() {
      var result, pending, _t4, _t5;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context4) {
        while (1) switch (_context4.p = _context4.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || isAnyEntityNew())) {
              _context4.n = 1;
              break;
            }
            return _context4.a(2);
          case 1:
            if (!isAnyQuoteItemDropdownOpen()) {
              _context4.n = 2;
              break;
            }
            setAutoSaveState({
              isEditing: true,
              isSaving: false
            });
            // Defer the header/entity autosave until any open quote-item dropdown closes.
            startQuoteAutosaveDropdownDeferredMonitor('quote:autoSaveQuote');
            return _context4.a(2);
          case 2:
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            _context4.p = 3;
            _context4.n = 4;
            return autoSave();
          case 4:
            result = _context4.v;
            _t4 = result === null || result === void 0 ? void 0 : result.status;
            _context4.n = _t4 === 'saved' ? 5 : _t4 === 'no-diff' ? 6 : _t4 === 'blocked' ? 7 : _t4 === 'conflict' ? 8 : _t4 === 'failed' ? 9 : _t4 === 'error' ? 9 : 10;
            break;
          case 5:
            resetAutoSaveFailures();
            pending = hasPendingAutoSaveDiffs();
            setAutoSaveState({
              isSaving: pending,
              isEditing: pending,
              isFailed: false
            });
            return _context4.a(3, 11);
          case 6:
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });
            return _context4.a(3, 11);
          case 7:
            setAutoSaveState({
              isSaving: false,
              isEditing: true
            });
            return _context4.a(3, 11);
          case 8:
            setAutoSaveState({
              isSaving: false,
              isEditing: true
            });
            vm.isSaveConflictModalActive = true;
            return _context4.a(3, 11);
          case 9:
            setAutoSaveState({
              isSaving: false,
              isEditing: true,
              isFailed: true,
              failMessage: result.failMessage || 'Automatic quote save failed.'
            });
            registerAutoSaveFailure(result === null || result === void 0 ? void 0 : result.failMessage);
            return _context4.a(3, 11);
          case 10:
            setAutoSaveState({
              isSaving: false
            });
          case 11:
            _context4.n = 13;
            break;
          case 12:
            _context4.p = 12;
            _t5 = _context4.v;
            console.error('Quote auto save failed', _t5);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t5 === null || _t5 === void 0 ? void 0 : _t5.message) || 'Automatic quote save failed.'
            });
          case 13:
            _context4.p = 13;
            vm.headerSavingPanels = {
              vehicle: false,
              customer: false,
              insurer: false,
              booking: false
            };
            return _context4.f(13);
          case 14:
            return _context4.a(2);
        }
      }, _callee4, null, [[3, 12, 13, 14]]);
    }));
    return function autoSaveQuote() {
      return _ref4.apply(this, arguments);
    };
  }();
  var autoUpdateQuoteHeader = /*#__PURE__*/function () {
    var _ref5 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee6(requestToken) {
      var toComparable, customerBaseline, vehicleBaseline, insurerBaseline, customerDiff, vehicleDiff, insurerDiff, isCustomerInfoChanged, ok, preRefreshVehicle, preRefreshCustomer, preRefreshInsurer, refreshPromises;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context6) {
        while (1) switch (_context6.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || isAnyEntityNew())) {
              _context6.n = 1;
              break;
            }
            return _context6.a(2);
          case 1:
            toComparable = function toComparable(value) {
              var cloned = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(value);
              if (cloned && Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_3__["default"])(cloned) === 'object') {
                delete cloned.modifiedDate;
              }
              return cloned;
            };
            customerBaseline = vm.headerAutosaveBaseline.customer || vm.quoteCustomer || vm.currentCustomerSnapshot;
            vehicleBaseline = vm.headerAutosaveBaseline.vehicle || vm.quoteVehicle || vm.currentVehicleSnapshot;
            insurerBaseline = vm.headerAutosaveBaseline.insurer || vm.quoteInsurer || vm.currentInsurerSnapshot;
            customerDiff = deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(toComparable(customerBaseline), toComparable(vm.customer));
            vehicleDiff = deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(toComparable(vehicleBaseline), toComparable(vm.vehicle));
            insurerDiff = deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(toComparable(insurerBaseline), toComparable(vm.insurer));
            if (!(!customerDiff && !vehicleDiff && !insurerDiff)) {
              _context6.n = 2;
              break;
            }
            if (!hasPendingAutoSaveDiffs()) {
              setAutoSaveState({
                isEditing: false,
                isSaving: false
              });
            }
            if (requestToken === vm.headerAutosaveToken) {
              vm.headerAutosaveInFlight = false;
            }
            return _context6.a(2);
          case 2:
            vm.headerSavingPanels = {
              vehicle: !!vehicleDiff,
              customer: !!customerDiff,
              insurer: !!insurerDiff,
              booking: false
            };
            _context6.n = 3;
            return vm.triggerIsNewOwnerPrompt();
          case 3:
            isCustomerInfoChanged = _context6.v;
            if (!(!vm.vehicle.isNew && !vm.customer.isNew && isCustomerInfoChanged)) {
              _context6.n = 4;
              break;
            }
            vm.isCustomerCreateModifyModalActive = true;
            vm.headerSavingPanels = {
              vehicle: false,
              customer: false,
              insurer: false,
              booking: false
            };
            setAutoSaveState({
              isEditing: true,
              isSaving: false
            });
            if (requestToken === vm.headerAutosaveToken) {
              vm.headerAutosaveInFlight = false;
            }
            return _context6.a(2);
          case 4:
            setAutoSaveState({
              isEditing: true,
              isSaving: true,
              isFailed: false
            });
            _context6.n = 5;
            return autoSaveQuoteAssets(false);
          case 5:
            ok = _context6.v;
            if (ok) {
              _context6.n = 6;
              break;
            }
            vm.headerSavingPanels = {
              vehicle: false,
              customer: false,
              insurer: false,
              booking: false
            };
            setAutoSaveState({
              isSaving: false,
              isFailed: true
            });
            // Keep isDiffChanged true so UI reflects unsaved header edits.
            registerAutoSaveFailure('Automatic header save failed.');
            if (requestToken === vm.headerAutosaveToken) {
              vm.headerAutosaveInFlight = false;
            }
            return _context6.a(2);
          case 6:
            // Refresh header assets from server, but don't clobber newer edits.
            vm.suppressHeaderAutosave = true;
            // Save pre-refresh state in case we need to revert
            preRefreshVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.vehicle);
            preRefreshCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.customer);
            preRefreshInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.insurer);
            try {
              refreshPromises = [];
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_48__["default"].validGuid(vm.entity.vehicleId)) {
                refreshPromises.push(vm.getQuoteVehicle({
                  id: vm.entity.vehicleId,
                  refresh: true
                }));
              }
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_48__["default"].validGuid(vm.entity.customerId)) {
                refreshPromises.push(vm.getQuoteCustomer({
                  id: vm.entity.customerId,
                  refresh: true
                }));
              }
              if (_components_Guid__WEBPACK_IMPORTED_MODULE_48__["default"].validGuid(vm.entity.insurerId)) {
                refreshPromises.push(vm.getQuoteInsurer({
                  id: vm.entity.insurerId,
                  refresh: true
                }));
              } else {
                refreshPromises.push(vm.getNewInsurer());
              }

              // Fire refresh in background without blocking UI. Mark as saved immediately.
              Promise.all(refreshPromises).then(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee5() {
                var vehicleChanged, customerChanged, insurerChanged, hasConcurrentHeaderEdits;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context5) {
                  while (1) switch (_context5.n) {
                    case 0:
                      if (!(requestToken !== vm.headerAutosaveToken)) {
                        _context5.n = 1;
                        break;
                      }
                      return _context5.a(2);
                    case 1:
                      // Detect concurrent user edits while refresh was in progress
                      vehicleChanged = !!deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(preRefreshVehicle, vm.vehicle);
                      customerChanged = !!deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(preRefreshCustomer, vm.customer);
                      insurerChanged = !!deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(preRefreshInsurer, vm.insurer);
                      hasConcurrentHeaderEdits = vehicleChanged || customerChanged || insurerChanged;
                      if (!hasConcurrentHeaderEdits) {
                        _context5.n = 2;
                        break;
                      }
                      return _context5.a(2);
                    case 2:
                      // No concurrent edits - safe to update from server
                      vm.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.currentVehicleSnapshot);
                      if (vm.vehicle) vm.vehicle.isNew = false;
                      vm.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.currentCustomerSnapshot);
                      vm.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.currentInsurerSnapshot);
                      if (vm.vehicle && vm.customer) {
                        vm.vehicle.customer = {
                          key: vm.customer.id,
                          value: vm.customer.fullname
                        };
                      }
                      vm.headerAutosaveBaseline.vehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.vehicle);
                      vm.headerAutosaveBaseline.customer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.customer);
                      vm.headerAutosaveBaseline.insurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.insurer);

                      // Check if we need to save quote due to header ID changes
                      // Header changes (e.g., insurer) may trigger template/markup changes that affect the quote
                      if (!hasHeaderQuoteIdChanges()) {
                        _context5.n = 3;
                        break;
                      }
                      vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
                      _context5.n = 3;
                      return saveQuoteAfterHeaderChangeNow();
                    case 3:
                      return _context5.a(2);
                  }
                }, _callee5);
              }))).catch(function (err) {
                console.error('Header refresh failed:', err);
                setAutoSaveState({
                  isFailed: true
                });
                registerAutoSaveFailure('Header refresh failed after save.');
              });

              // Mark as saved immediately since API call succeeded (don't wait for refresh)
              resetAutoSaveFailures();
              setAutoSaveState({
                isSaving: false,
                isEditing: false,
                isFailed: false
              });
            } finally {
              vm.suppressHeaderAutosave = false;
              vm.headerSavingPanels = {
                vehicle: false,
                customer: false,
                insurer: false,
                booking: false
              };
              if (requestToken === vm.headerAutosaveToken) {
                vm.headerAutosaveInFlight = false;
              }
            }
          case 7:
            return _context6.a(2);
        }
      }, _callee6);
    }));
    return function autoUpdateQuoteHeader(_x) {
      return _ref5.apply(this, arguments);
    };
  }();

  // Debounced header save — persists the latest computed totals once per editing burst.
  var debouncedSaveHeader = lodash_debounce__WEBPACK_IMPORTED_MODULE_41___default()(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee7() {
    var _vm$entity4;
    var quoteHeader, _t6;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context7) {
      while (1) switch (_context7.p = _context7.n) {
        case 0:
          if (!(!vm.autoSaveEnabled || isAnyEntityNew() || !((_vm$entity4 = vm.entity) !== null && _vm$entity4 !== void 0 && _vm$entity4.quoteId))) {
            _context7.n = 1;
            break;
          }
          return _context7.a(2);
        case 1:
          _context7.p = 1;
          quoteHeader = new _classes_viewmodels_Quote_QuoteLiteModel__WEBPACK_IMPORTED_MODULE_46__["default"](vm.entity);
          _context7.n = 2;
          return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveQuoteHeader(vm.entity.quoteId, quoteHeader);
        case 2:
          _context7.n = 4;
          break;
        case 3:
          _context7.p = 3;
          _t6 = _context7.v;
          console.error('Quote header auto save failed', _t6);
        case 4:
          return _context7.a(2);
      }
    }, _callee7, null, [[1, 3]]);
  })), 800);

  // Debounced entity refresh — swaps in the server's latest state ~1s after the last save.
  var debouncedEntityRefresh = lodash_debounce__WEBPACK_IMPORTED_MODULE_41___default()(function () {
    var itemTypes = quoteItemCollectionKeys;
    vm.getLiteStoreItem(vm.$route.params.quoteId).then(function () {
      var _vm$currentSnapshot;
      // Guard the watchers while we mutate vm.entity so they don't push a spurious diff.
      vm._isAutosaveRefreshing = true;
      if (vm.entity && (_vm$currentSnapshot = vm.currentSnapshot) !== null && _vm$currentSnapshot !== void 0 && _vm$currentSnapshot.modifiedDate) {
        vm.entity.modifiedDate = vm.currentSnapshot.modifiedDate;
      }

      // Unsaved changes present: re-baseline to the live entity instead of swapping it in,
      // so cosmetic server-shape diffs (createdBy/dates/ordering) don't read as "unsaved".
      if (deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(vm.baseSnapshot, vm.entity)) {
        // A save is pending — let it own the baseline; re-baselining now would mark its
        // unsaved changes (e.g. a drag-reorder) as already saved.
        if (hasPendingItemsSave()) {
          vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
          vm.$nextTick(function () {
            vm._isAutosaveRefreshing = false;
          });
          return;
        }
        // Strip isNew items so they're still treated as "added" by the next save.
        var newBaseSnapshot = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity);
        itemTypes.forEach(function (type) {
          if (Array.isArray(newBaseSnapshot[type])) {
            newBaseSnapshot[type] = newBaseSnapshot[type].filter(function (item) {
              return !(item !== null && item !== void 0 && item.isNew);
            });
          }
        });
        vm.setBaseSnapshot(newBaseSnapshot);
        vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
        vm.$nextTick(function () {
          vm._isAutosaveRefreshing = false;
        });
        return;
      }

      // Capture empty items before swap so they are preserved in the UI.
      var emptyItemsByType = {};
      itemTypes.forEach(function (type) {
        emptyItemsByType[type] = (vm.entity[type] || []).filter(function (item) {
          return item.isNew && (!item.itemDesc || item.itemDesc === '') && (!item.value || item.value === 0);
        });
      });
      vm.entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.currentSnapshot);

      // Restore empty items (they were not sent to the server).
      itemTypes.forEach(function (type) {
        var existingIds = new Set((vm.entity[type] || []).map(function (l) {
          return l.quoteItemId;
        }));
        var emptyItemsToRestore = emptyItemsByType[type].filter(function (item) {
          return !existingIds.has(item.quoteItemId);
        });
        vm.entity[type] = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(vm.entity[type] || []), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(emptyItemsToRestore));
      });
      vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
      vm.$nextTick(function () {
        vm._isAutosaveRefreshing = false;
      });
    }).catch(function (err) {
      console.error('Quote item refresh failed after save:', err);
      vm._isAutosaveRefreshing = false;
    });
  }, 1000);

  // ── Bulk quote-items autosave ─────────────────────────────────────────────
  // Debounced, single-flight PUT of the full managed item set. "Synced" = !item.isNew:
  // a new item deleted before it syncs is dropped; a synced item that is deleted is sent
  // with deleted=true; empty (blank itemDesc) items are kept in the UI but never sent.
  var _runItemsSave = /*#__PURE__*/function () {
    var _ref8 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee8() {
      var _vm$entity5;
      var revertedEmptyItems, payload, localRemovals, entitySnapshotForSave, saved, savedIds, baseline, _t7;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context8) {
        while (1) switch (_context8.p = _context8.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || isAnyEntityNew() || (_vm$entity5 = vm.entity) !== null && _vm$entity5 !== void 0 && _vm$entity5.readOnly)) {
              _context8.n = 1;
              break;
            }
            return _context8.a(2);
          case 1:
            if (!vm._isAutosaveRefreshing) {
              _context8.n = 2;
              break;
            }
            return _context8.a(2);
          case 2:
            if (!vm._itemsSaveInFlight) {
              _context8.n = 3;
              break;
            }
            vm._itemsSaveQueued = true;
            return _context8.a(2);
          case 3:
            if (!isQuoteItemEditInProgress()) {
              _context8.n = 4;
              break;
            }
            setAutoSaveState({
              isEditing: true,
              isSaving: false
            });
            vm._itemsSaveQueued = true;
            startQuoteItemsEditDeferMonitor();
            return _context8.a(2);
          case 4:
            vm._itemsSaveInFlight = true;
            vm._itemsSavePending = false;
            _context8.p = 5;
            _context8.n = 6;
            return vm.$nextTick();
          case 6:
            // An emptied synced item is never saved — revert it to its last-saved state now
            // so the post-save baseline (and sessionStorage) never carries the blank description.
            revertedEmptyItems = revertEmptySavedLineItems(); // Nothing changed since the last saved baseline → no-op.
            if (deep_diff__WEBPACK_IMPORTED_MODULE_42__["DeepDiff"].diff(vm.baseSnapshot, vm.entity)) {
              _context8.n = 7;
              break;
            }
            if (revertedEmptyItems) vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            if (!hasPendingAutoSaveDiffs()) setAutoSaveState({
              isEditing: false,
              isSaving: false
            });
            return _context8.a(2);
          case 7:
            _context8.n = 8;
            return vm.assignLineNumbers(false);
          case 8:
            // Build the full payload, and collect never-synced deleted items to drop locally.
            payload = [];
            localRemovals = {};
            quoteItemCollectionKeys.forEach(function (type) {
              var items = vm.entity[type] || [];
              items.forEach(function (item) {
                if (!item) return;
                if (item.deleted) {
                  if (!item.isNew) {
                    payload.push(item); // synced delete → tell the server to remove it
                  } else {
                    // Added then deleted before it ever synced → omit + remove from the live array.
                    (localRemovals[type] || (localRemovals[type] = [])).push(item.quoteItemId);
                  }
                } else if (isValidItemAutoSave(item)) {
                  payload.push(item); // add (isNew) or update; empty items stay in the UI, not sent
                }
              });
            });
            Object.keys(localRemovals).forEach(function (type) {
              var ids = new Set(localRemovals[type]);
              vm.entity[type] = (vm.entity[type] || []).filter(function (i) {
                return !ids.has(i.quoteItemId);
              });
            });
            if (!(payload.length === 0)) {
              _context8.n = 9;
              break;
            }
            // Only empty / never-synced-deleted items changed — just advance the snapshot.
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            if (!hasPendingAutoSaveDiffs()) setAutoSaveState({
              isEditing: false,
              isSaving: false
            });
            return _context8.a(2);
          case 9:
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            // Snapshot the state being sent before the await; the baseline is derived from this so
            // changes made during the in-flight save stay a diff and aren't lost.
            entitySnapshotForSave = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity);
            saved = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(payload);
            _context8.n = 10;
            return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveQuoteItems(vm.entity.quoteId, saved);
          case 10:
            // Mark the saved (non-deleted) items as synced on the live entity.
            savedIds = new Set(payload.filter(function (i) {
              return !i.deleted;
            }).map(function (i) {
              return i.quoteItemId;
            }));
            quoteItemCollectionKeys.forEach(function (type) {
              (vm.entity[type] || []).forEach(function (item) {
                if (item.isNew && savedIds.has(item.quoteItemId)) item.isNew = false;
              });
            });

            // Advance the baseline from the sent snapshot (isNew flattened, never-synced deletes dropped).
            baseline = entitySnapshotForSave;
            quoteItemCollectionKeys.forEach(function (type) {
              if (Array.isArray(baseline[type])) {
                baseline[type] = baseline[type].filter(function (i) {
                  return !(i.isNew && i.deleted);
                }).map(function (i) {
                  return i && savedIds.has(i.quoteItemId) ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, i), {}, {
                    isNew: false
                  }) : i;
                });
              }
            });
            _store_utils__WEBPACK_IMPORTED_MODULE_49__["default"].setStorage(baseline.quoteId, 'quote', baseline);
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(baseline));
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });

            // Persist computed header totals + reconcile from the server (both already debounced).
            debouncedSaveHeader();
            debouncedEntityRefresh();
            _context8.n = 12;
            break;
          case 11:
            _context8.p = 11;
            _t7 = _context8.v;
            console.error('Quote items bulk save failed', _t7);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t7 === null || _t7 === void 0 ? void 0 : _t7.message) || 'Automatic quote item save failed.'
            });
            registerAutoSaveFailure(_t7 === null || _t7 === void 0 ? void 0 : _t7.message);
          case 12:
            _context8.p = 12;
            vm._itemsSaveInFlight = false;
            if (vm._itemsSaveQueued) {
              vm._itemsSaveQueued = false;
              _runItemsSave();
            }
            return _context8.f(12);
          case 13:
            return _context8.a(2);
        }
      }, _callee8, null, [[5, 11, 12, 13]]);
    }));
    return function runItemsSave() {
      return _ref8.apply(this, arguments);
    };
  }();
  var runItemsSaveDebounced = lodash_debounce__WEBPACK_IMPORTED_MODULE_41___default()(_runItemsSave, 800);

  // Public entry point: called by the item-array watchers on every change.
  var scheduleItemsSave = function scheduleItemsSave() {
    var _vm$entity6;
    if (!vm.autoSaveEnabled || isAnyEntityNew() || (_vm$entity6 = vm.entity) !== null && _vm$entity6 !== void 0 && _vm$entity6.readOnly) return;
    if (vm._isAutosaveRefreshing) return;
    if (vm.$route && vm.$route.name !== _route_types__WEBPACK_IMPORTED_MODULE_47__["default"].QuoteBuilder.name) return;
    vm._itemsSavePending = true;
    setAutoSaveState({
      isEditing: true
    });
    runItemsSaveDebounced();
  };
  scheduleItemsSave.cancel = function () {
    runItemsSaveDebounced.cancel();
    vm._itemsSavePending = false;
  };
  scheduleItemsSave.flush = function () {
    runItemsSaveDebounced.flush();
  };

  // True while a bulk save is pending, in flight, or queued — used by the leave warning.
  var hasPendingItemsSave = function hasPendingItemsSave() {
    return !!(vm._itemsSavePending || vm._itemsSaveInFlight || vm._itemsSaveQueued);
  };

  // Re-fire the bulk save once the user is no longer mid-edit (field blurred / dropdown closed).
  var startQuoteItemsEditDeferMonitor = function startQuoteItemsEditDeferMonitor() {
    if (vm.quoteItemsEditDeferMonitor) return;
    vm.quoteItemsEditDeferMonitor = setInterval(function () {
      if (!vm.autoSaveEnabled || isAnyEntityNew() || vm.$route.name !== _route_types__WEBPACK_IMPORTED_MODULE_47__["default"].QuoteBuilder.name) {
        stopQuoteItemsEditDeferMonitor();
        return;
      }
      if (isQuoteItemEditInProgress()) return;
      stopQuoteItemsEditDeferMonitor();
      vm._itemsSaveQueued = false;
      vm.$nextTick(function () {
        return _runItemsSave();
      });
    }, 250);
  };
  var stopQuoteItemsEditDeferMonitor = function stopQuoteItemsEditDeferMonitor() {
    if (!vm.quoteItemsEditDeferMonitor) return;
    clearInterval(vm.quoteItemsEditDeferMonitor);
    vm.quoteItemsEditDeferMonitor = null;
  };
  var queueHeaderAutosave = function queueHeaderAutosave() {
    var panelName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
    if (!vm.autoSaveEnabled) return;
    if (!vm.entity || vm.readOnlyView || isAnyEntityNew()) return;
    if (vm.headerAutosaveInFlight) return;
    if (vm.isCustomerCreateModifyModalActive) return;
    if (vm.validateError) {
      vm.$notification.openNotificationWithType('danger', 'AutoSave Paused', 'Autosaved has been paused due to validation errors.');
      vm.showItemsValidationErrors();
      return false;
    }
    if (!hasPendingAutoSaveDiffs()) return;

    // Only proceed with the header asset pipeline when there are asset changes.
    // Entity-only changes (e.g. claimNo on insurer panel) are handled below.
    var hasAssetDiffs = vm.snapshotDiffCustomer || vm.snapshotDiffVehicle || vm.snapshotDiffInsurer;

    // If no asset diffs exist, nothing for the header pipeline to save.
    // Trigger an immediate entity save if entity fields changed (e.g. claimNo, policyNo on insurer panel).
    if (!hasAssetDiffs) {
      if (vm.snapshotDiff) {
        if (panelName) {
          vm.headerSavingPanels = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, vm.headerSavingPanels), {}, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, panelName, true));
        }
        autoSaveQuote();
      }
      return;
    }
    setAutoSaveState({
      isEditing: true
    });
    vm.headerAutosaveToken += 1;
    vm.headerAutosaveInFlight = true;
    autoUpdateQuoteHeader(vm.headerAutosaveToken);
  };
  var startQuoteAutosaveDropdownDeferredMonitor = function startQuoteAutosaveDropdownDeferredMonitor() {
    var source = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    if (vm.quoteAutosaveDropdownDeferredMonitor) return;
    vm.quoteAutosaveDropdownDeferredMonitor = setInterval(function () {
      if (!vm.autoSaveEnabled || isAnyEntityNew()) {
        stopQuoteAutosaveDropdownDeferredMonitor();
        return;
      }

      // Wait until dropdowns close.
      if (isAnyQuoteItemDropdownOpen()) return;
      stopQuoteAutosaveDropdownDeferredMonitor();
      // Re-queue the quote autosave.
      vm.$nextTick(function () {
        return autoSaveQuote(source ? "deferred:dropdown:".concat(source) : 'deferred:dropdown');
      });
    }, 250);
  };
  var stopQuoteAutosaveDropdownDeferredMonitor = function stopQuoteAutosaveDropdownDeferredMonitor() {
    if (!vm.quoteAutosaveDropdownDeferredMonitor) return;
    clearInterval(vm.quoteAutosaveDropdownDeferredMonitor);
    vm.quoteAutosaveDropdownDeferredMonitor = null;
  };

  // Revert synced (isNew=false) items whose description was blanked back to their
  // last-saved state from baseSnapshot. A blank description is never autosaved, so
  // leaving it on the live entity would contaminate the baseline / hard-save payload.
  // Returns true when at least one item was reverted.
  var revertEmptySavedLineItems = function revertEmptySavedLineItems() {
    if (!vm.entity || !vm.baseSnapshot) return false;
    var reverted = false;
    quoteItemCollectionKeys.forEach(function (key) {
      var items = vm.entity[key];
      if (!Array.isArray(items)) return;
      items.forEach(function (item, idx) {
        if (!item || item.isNew || item.deleted || !isBlankItemDesc(item.itemDesc)) return;
        var baseItem = (vm.baseSnapshot[key] || []).find(function (b) {
          return b && b.quoteItemId === item.quoteItemId;
        });
        if (baseItem && !isBlankItemDesc(baseItem.itemDesc)) {
          items.splice(idx, 1, lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(baseItem));
          reverted = true;
        }
      });
    });
    return reverted;
  };

  // Drop the entity.lines counter back to (highest line number still in use) + 1 so the
  // numbers freed by purged blank lines are reused by the next added item. Mirrors
  // nextLineNumber's collections/exclusions and assignLineNumbers' AudaNet guard and
  // subQuoteNo*1000 floor (supplementary quotes must not restart numbering below it).
  var resetLineNumberCounter = function resetLineNumberCounter() {
    if (vm.entity.isAudaNet || vm.entity.isAudaBridge) return;
    var lineNumbers = [].concat(quoteItemCollectionKeys, ['opgs']).flatMap(function (key) {
      return (vm.entity[key] || []).filter(function (i) {
        return i && !(i.isNew && i.deleted);
      }).map(function (i) {
        return i.lineNumber || 0;
      });
    });
    var maxUsed = Math.max.apply(Math, [(vm.entity.subQuoteNo || 0) * 1000].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(lineNumbers), [0]));
    vm.entity.lines = maxUsed + 1;
  };
  var deleteEmptyLineItems = function deleteEmptyLineItems() {
    if (!vm.entity) return;
    // Emptied synced items go back to their last-saved state instead of being deleted.
    revertEmptySavedLineItems();
    var purgedAny = false;
    quoteItemCollectionKeys.forEach(function (key) {
      if (!vm.entity[key]) return;
      var isPurgeable = function isPurgeable(i) {
        return isBlankItemDesc(i.itemDesc) && i.isNew && !i.deleted;
      };
      var purged = vm.entity[key].filter(isPurgeable);
      if (purged.length === 0) return;
      purgedAny = true;
      vm.entity[key] = vm.entity[key].filter(function (i) {
        return !isPurgeable(i);
      });
      // Sync each removal into AddItemsComponent's innerValue cache (same dance as the
      // trash-button delete), or its value-watcher preserve loop resurrects the purged
      // items and re-emits them to the parent while the add-items drawer is open.
      if (vm.$eventHub) {
        purged.forEach(function (item) {
          return vm.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_50__["EventHubTypes"].QuoteItemDeletedSync, item);
        });
      }
    });
    if (purgedAny) resetLineNumberCounter();
    // Update snapshot to clear diffs after deleting empty items
    vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
  };
  var handleNavigationWarningConfirm = function handleNavigationWarningConfirm() {
    // Delete empty items if that's the action
    if (vm.navigationWarningAction === 'deleteEmpty') {
      deleteEmptyLineItems();
      // Skip the next navigation warning and unsaved modal checks
      vm.skipNextNavWarning = true;
      vm.skipNextUnsavedModal = true;
      // Close the modal and navigate
      vm.isNavigationWarningModalActive = false;
      vm.$nextTick(function () {
        vm.$router.push(vm.toRoute);
      });
    } else if (vm.navigationWarningAction === 'trySave') {
      // Close the modal and try to save
      vm.isNavigationWarningModalActive = false;
      vm.save();
    } else if (vm.navigationWarningAction === 'leaveWithErrors') {
      // User chose to leave anyway despite save errors
      vm.leaveWithUnsavedErrors = true;
      vm.skipNextNavWarning = true;
      vm.skipNextUnsavedModal = true;
      vm.isNavigationWarningModalActive = false;
      vm.$nextTick(function () {
        vm.$router.push(vm.toRoute);
      });
    }
  };
  var handleNavigationWarningCancel = function handleNavigationWarningCancel() {
    if (vm.navigationWarningAction === 'trySave') {
      // User chose to skip anyway, navigate away despite autosave failure
      vm.skipNextNavWarning = true;
      vm.skipNextUnsavedModal = true;
      vm.isNavigationWarningModalActive = false;
      vm.$nextTick(function () {
        vm.$router.push(vm.toRoute);
      });
    } else {
      // User chose to keep editing
      vm.isNavigationWarningModalActive = false;
    }
  };
  var hasEmptyLineItems = function hasEmptyLineItems() {
    if (!vm.entity) return false;
    return quoteItemCollectionKeys.some(function (key) {
      var items = vm.entity[key];
      return items && items.some(function (i) {
        return !i.deleted && isBlankItemDesc(i.itemDesc) && i.isNew;
      });
    });
  };

  /**
   * Saves the quote first (if needed) and then executes the provided action.
   * When autosave is enabled and there are unsaved changes, it flushes all pending
   * autosave work and saves before continuing. When autosave is genuinely disabled,
   * it returns reason 'autosave-disabled' so the caller can warn the user to save manually.
   *
   * @param {Function} action - The async function to execute after saving
   * @returns {Promise<{ok: boolean, reason?: 'autosave-disabled'|'blocked'|'failed'}>}
   *   ok:true once the action has run; otherwise a reason describing why it could not.
   *   Only 'autosave-disabled' should surface the "please save" toast — 'blocked' (a
   *   modal/conflict is driving the UX) and 'failed' (the "Autosave Paused" notification
   *   already covers it) must stay silent so we never tell a user to save when there is
   *   no manual Save available.
   */
  var saveQuoteAndContinue = /*#__PURE__*/function () {
    var _ref9 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee9(action) {
      var result, _t8;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context9) {
        while (1) switch (_context9.p = _context9.n) {
          case 0:
            if (vm.snapshotDiff) {
              _context9.n = 2;
              break;
            }
            if (!(action && typeof action === 'function')) {
              _context9.n = 1;
              break;
            }
            _context9.n = 1;
            return action();
          case 1:
            return _context9.a(2, {
              ok: true
            });
          case 2:
            if (vm.autoSaveEnabled) {
              _context9.n = 3;
              break;
            }
            return _context9.a(2, {
              ok: false,
              reason: 'autosave-disabled'
            });
          case 3:
            if (!(vm.readOnlyView || isAnyEntityNew())) {
              _context9.n = 4;
              break;
            }
            return _context9.a(2, {
              ok: false,
              reason: 'blocked'
            });
          case 4:
            _context9.p = 4;
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });

            // Flush the debounced item save so it can't race the save below. autoSave()'s
            // putEntity persists the full entity (including the latest item edits) and then
            // reconciles assets via getEntity, so cancelling the debounce loses no work.
            scheduleItemsSave.cancel();
            _context9.n = 5;
            return autoSave();
          case 5:
            result = _context9.v;
            if (!((result === null || result === void 0 ? void 0 : result.status) === 'saved' || (result === null || result === void 0 ? void 0 : result.status) === 'no-diff')) {
              _context9.n = 7;
              break;
            }
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });

            // Execute the action after successful save
            if (!(action && typeof action === 'function')) {
              _context9.n = 6;
              break;
            }
            _context9.n = 6;
            return action();
          case 6:
            return _context9.a(2, {
              ok: true
            });
          case 7:
            if (!((result === null || result === void 0 ? void 0 : result.status) === 'blocked')) {
              _context9.n = 8;
              break;
            }
            // The new-owner / customer create-modify modal is driving the UX.
            setAutoSaveState({
              isSaving: false,
              isEditing: true
            });
            return _context9.a(2, {
              ok: false,
              reason: 'blocked'
            });
          case 8:
            if (!((result === null || result === void 0 ? void 0 : result.status) === 'conflict')) {
              _context9.n = 9;
              break;
            }
            // Server-side concurrent edit — surface the conflict modal, not the save toast.
            setAutoSaveState({
              isSaving: false,
              isEditing: true
            });
            vm.isSaveConflictModalActive = true;
            return _context9.a(2, {
              ok: false,
              reason: 'blocked'
            });
          case 9:
            // Save failed — the "Autosave Paused" notification covers this.
            setAutoSaveState({
              isSaving: false,
              isEditing: true,
              isFailed: true,
              failMessage: (result === null || result === void 0 ? void 0 : result.failMessage) || 'Automatic quote save failed.'
            });
            registerAutoSaveFailure(result === null || result === void 0 ? void 0 : result.failMessage);
            return _context9.a(2, {
              ok: false,
              reason: 'failed'
            });
          case 10:
            _context9.n = 12;
            break;
          case 11:
            _context9.p = 11;
            _t8 = _context9.v;
            console.error('Save and continue failed', _t8);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t8 === null || _t8 === void 0 ? void 0 : _t8.message) || 'Automatic quote save failed.'
            });
            return _context9.a(2, {
              ok: false,
              reason: 'failed'
            });
          case 12:
            return _context9.a(2);
        }
      }, _callee9, null, [[4, 11]]);
    }));
    return function saveQuoteAndContinue(_x2) {
      return _ref9.apply(this, arguments);
    };
  }();
  var saveLiteHeaderNow = /*#__PURE__*/function () {
    var _ref0 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee0() {
      var _vm$currentSnapshot2, quoteHeader, _t9;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context0) {
        while (1) switch (_context0.p = _context0.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || !vm.entity || vm.entity.isNew || vm.entity.readOnly)) {
              _context0.n = 1;
              break;
            }
            return _context0.a(2);
          case 1:
            _context0.p = 1;
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            quoteHeader = new _classes_viewmodels_Quote_QuoteLiteModel__WEBPACK_IMPORTED_MODULE_46__["default"](vm.entity);
            _context0.n = 2;
            return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveQuoteHeader(vm.entity.quoteId, quoteHeader);
          case 2:
            _context0.n = 3;
            return vm.getLiteStoreItem(vm.entity.quoteId);
          case 3:
            if ((_vm$currentSnapshot2 = vm.currentSnapshot) !== null && _vm$currentSnapshot2 !== void 0 && _vm$currentSnapshot2.modifiedDate) {
              vm.entity.modifiedDate = vm.currentSnapshot.modifiedDate;
            }
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            _context0.n = 5;
            break;
          case 4:
            _context0.p = 4;
            _t9 = _context0.v;
            console.error('Lite header save failed', _t9);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t9 === null || _t9 === void 0 ? void 0 : _t9.message) || 'Quote header save failed.'
            });
            registerAutoSaveFailure(_t9 === null || _t9 === void 0 ? void 0 : _t9.message);
          case 5:
            return _context0.a(2);
        }
      }, _callee0, null, [[1, 4]]);
    }));
    return function saveLiteHeaderNow() {
      return _ref0.apply(this, arguments);
    };
  }();
  var saveJobStageNow = /*#__PURE__*/function () {
    var _ref1 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee1() {
      var _vm$currentSnapshot3, _t0;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context1) {
        while (1) switch (_context1.p = _context1.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || vm.autoSaveDisabled || !vm.entity || vm.entity.isNew)) {
              _context1.n = 1;
              break;
            }
            return _context1.a(2);
          case 1:
            _context1.p = 1;
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            _context1.n = 2;
            return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveJobStage(vm.entity.quoteId, {
              jobStage: vm.entity.jobStage,
              subJobStage: vm.entity.subJobStage
            });
          case 2:
            _context1.n = 3;
            return vm.getLiteStoreItem(vm.entity.quoteId);
          case 3:
            if ((_vm$currentSnapshot3 = vm.currentSnapshot) !== null && _vm$currentSnapshot3 !== void 0 && _vm$currentSnapshot3.modifiedDate) {
              vm.entity.modifiedDate = vm.currentSnapshot.modifiedDate;
            }
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            _context1.n = 5;
            break;
          case 4:
            _context1.p = 4;
            _t0 = _context1.v;
            console.error('Job stage autosave failed', _t0);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t0 === null || _t0 === void 0 ? void 0 : _t0.message) || 'Job stage save failed.'
            });
            registerAutoSaveFailure(_t0 === null || _t0 === void 0 ? void 0 : _t0.message);
          case 5:
            return _context1.a(2);
        }
      }, _callee1, null, [[1, 4]]);
    }));
    return function saveJobStageNow() {
      return _ref1.apply(this, arguments);
    };
  }();
  var saveReadOnlyNow = /*#__PURE__*/function () {
    var _ref10 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee10() {
      var _vm$currentSnapshot4, _t1;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context10) {
        while (1) switch (_context10.p = _context10.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || vm.autoSaveDisabled || !vm.entity || vm.entity.isNew)) {
              _context10.n = 1;
              break;
            }
            return _context10.a(2);
          case 1:
            _context10.p = 1;
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            _context10.n = 2;
            return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveReadOnly(vm.entity.quoteId, {
              readOnly: vm.entity.readOnly
            });
          case 2:
            _context10.n = 3;
            return vm.getLiteStoreItem(vm.entity.quoteId);
          case 3:
            if ((_vm$currentSnapshot4 = vm.currentSnapshot) !== null && _vm$currentSnapshot4 !== void 0 && _vm$currentSnapshot4.modifiedDate) {
              vm.entity.modifiedDate = vm.currentSnapshot.modifiedDate;
            }
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            _context10.n = 5;
            break;
          case 4:
            _context10.p = 4;
            _t1 = _context10.v;
            console.error('Read-only autosave failed', _t1);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t1 === null || _t1 === void 0 ? void 0 : _t1.message) || 'Read-only save failed.'
            });
            registerAutoSaveFailure(_t1 === null || _t1 === void 0 ? void 0 : _t1.message);
          case 5:
            return _context10.a(2);
        }
      }, _callee10, null, [[1, 4]]);
    }));
    return function saveReadOnlyNow() {
      return _ref10.apply(this, arguments);
    };
  }();
  var saveAssessmentEnabledNow = /*#__PURE__*/function () {
    var _ref11 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee11() {
      var _vm$currentSnapshot5, _t10;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context11) {
        while (1) switch (_context11.p = _context11.n) {
          case 0:
            if (!(!vm.autoSaveEnabled || vm.autoSaveDisabled || !vm.entity || vm.entity.isNew)) {
              _context11.n = 1;
              break;
            }
            return _context11.a(2);
          case 1:
            _context11.p = 1;
            setAutoSaveState({
              isSaving: true,
              isFailed: false
            });
            _context11.n = 2;
            return _QuoteAutoSaveService__WEBPACK_IMPORTED_MODULE_44__["default"].saveAssessmentEnabled(vm.entity.quoteId, {
              isAssessmentEnabled: vm.entity.isAssessmentEnabled
            });
          case 2:
            _context11.n = 3;
            return vm.getLiteStoreItem(vm.entity.quoteId);
          case 3:
            if ((_vm$currentSnapshot5 = vm.currentSnapshot) !== null && _vm$currentSnapshot5 !== void 0 && _vm$currentSnapshot5.modifiedDate) {
              vm.entity.modifiedDate = vm.currentSnapshot.modifiedDate;
            }
            resetAutoSaveFailures();
            setAutoSaveState({
              isSaving: false,
              isEditing: false,
              isFailed: false
            });
            vm.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            vm.setBaseSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_40___default()(vm.entity));
            _context11.n = 5;
            break;
          case 4:
            _context11.p = 4;
            _t10 = _context11.v;
            console.error('Assessment history autosave failed', _t10);
            setAutoSaveState({
              isSaving: false,
              isFailed: true,
              failMessage: (_t10 === null || _t10 === void 0 ? void 0 : _t10.message) || 'Assessment history save failed.'
            });
            registerAutoSaveFailure(_t10 === null || _t10 === void 0 ? void 0 : _t10.message);
          case 5:
            return _context11.a(2);
        }
      }, _callee11, null, [[1, 4]]);
    }));
    return function saveAssessmentEnabledNow() {
      return _ref11.apply(this, arguments);
    };
  }();

  // Exposed methods
  return {
    autoSave: autoSave,
    // Exposed specifically for manual triggers if any
    autoSaveQuote: autoSaveQuote,
    autoUpdateQuoteHeader: autoUpdateQuoteHeader,
    scheduleItemsSave: scheduleItemsSave,
    runItemsSave: _runItemsSave,
    hasPendingItemsSave: hasPendingItemsSave,
    stopQuoteItemsEditDeferMonitor: stopQuoteItemsEditDeferMonitor,
    queueHeaderAutosave: queueHeaderAutosave,
    isValidItemAutoSave: isValidItemAutoSave,
    hasPendingAutoSaveWork: hasPendingAutoSaveWork,
    hasPendingAutoSaveDiffs: hasPendingAutoSaveDiffs,
    registerAutoSaveFailure: registerAutoSaveFailure,
    resetAutoSaveFailures: resetAutoSaveFailures,
    setAutoSaveState: setAutoSaveState,
    deleteEmptyLineItems: deleteEmptyLineItems,
    revertEmptySavedLineItems: revertEmptySavedLineItems,
    hasEmptyLineItems: hasEmptyLineItems,
    handleNavigationWarningConfirm: handleNavigationWarningConfirm,
    handleNavigationWarningCancel: handleNavigationWarningCancel,
    saveQuoteAfterHeaderChangeNow: saveQuoteAfterHeaderChangeNow,
    hasHeaderQuoteIdChanges: hasHeaderQuoteIdChanges,
    getExpandedQuoteItemId: getExpandedQuoteItemId,
    getFocusedItemInfo: getFocusedItemInfo,
    findItemIdByLineAndType: findItemIdByLineAndType,
    saveQuoteAndContinue: saveQuoteAndContinue,
    saveLiteHeaderNow: saveLiteHeaderNow,
    saveJobStageNow: saveJobStageNow,
    saveReadOnlyNow: saveReadOnlyNow,
    saveAssessmentEnabledNow: saveAssessmentEnabledNow,
    debouncedSaveHeader: debouncedSaveHeader,
    debouncedEntityRefresh: debouncedEntityRefresh
  };
}

/***/ }),

/***/ "./src/views/quotetemplate/QuoteTemplateService.js":
/*!*********************************************************!*\
  !*** ./src/views/quotetemplate/QuoteTemplateService.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  getQuoteTemplateItems: function getQuoteTemplateItems(templateId) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/quotetemplates/items/".concat(templateId);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  }
});

/***/ })

}]);
//# sourceMappingURL=quote-detail-chunk.js.map