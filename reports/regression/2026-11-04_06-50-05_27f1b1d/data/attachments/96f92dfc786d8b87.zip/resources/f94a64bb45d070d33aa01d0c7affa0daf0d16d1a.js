(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vehicle-butterfly-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _VehicleButterflySelector_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./VehicleButterflySelector.vue */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue");









/**
 * Butterfly picker for screens that only need `butterflyCode` values to filter an
 * available-items grid. Stateless - it loads and saves nothing.
 *
 * v-model is the selector's own selection items, NOT the flat codes the filter is
 * built from. Codes are lossy - they drop the area a part was picked in, and a code
 * such as Decal lives in three areas - so a codes round trip came back with areas and
 * sections the user never picked. Consumers project codes with `selectionItemsToCodes`
 * when they apply the filter, and hand this array straight back on the next open.
 */
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleButterflyFilterModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_6__["BaseModalEx"],
    VehicleButterflySelector: _VehicleButterflySelector_vue__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  props: {
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    }
  },
  data: function data() {
    return {
      isActive: this.active,
      selectedItems: this.value.map(function (item) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, item);
      }),
      // What to hand back on cancel, so the consumer can restore its previous filter.
      snapshot: this.value.map(function (item) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, item);
      }),
      screenWidth: window.innerWidth
    };
  },
  computed: {
    responsiveMinWidth: function responsiveMinWidth() {
      if (this.screenWidth < 768) {
        return 95; // Mobile
      } else if (this.screenWidth < 1024) {
        return 85; // Tablet
      } else if (this.screenWidth < 1440) {
        return 75; // Desktop
      } else {
        return 65; // Large screens
      }
    }
  },
  watch: {
    active: function active(val) {
      this.isActive = val;
    },
    selectedItems: {
      handler: function handler(val) {
        this.$emit('input', val);
      },
      deep: true
    }
  },
  mounted: function mounted() {
    window.addEventListener('resize', this.handleResize);
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.handleResize);
  },
  methods: {
    handleResize: function handleResize() {
      this.screenWidth = window.innerWidth;
    },
    reset: function reset() {
      // Clears the picker only. The filter itself is not applied until Done.
      if (this.$refs.vehicleButterflySelector) {
        this.$refs.vehicleButterflySelector.reset();
      }
      this.selectedItems = [];
    },
    cancel: function cancel() {
      this.$emit('cancel', this.snapshot);
      this.isActive = false;
    },
    done: function done() {
      this.$emit('done');
      this.isActive = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _VehicleButterflySelector_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./VehicleButterflySelector.vue */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleButterflyModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__["BaseModalEx"],
    VehicleButterflySelector: _VehicleButterflySelector_vue__WEBPACK_IMPORTED_MODULE_10__["default"]
  },
  props: {
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    entity: {
      type: Object,
      default: function _default() {}
    }
  },
  data: function data() {
    return {
      isActive: this.active,
      selectedItems: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.value),
      screenWidth: window.innerWidth
    };
  },
  computed: {
    responsiveMinWidth: function responsiveMinWidth() {
      if (this.screenWidth < 768) {
        return 95; // Mobile
      } else if (this.screenWidth < 1024) {
        return 85; // Tablet
      } else if (this.screenWidth < 1440) {
        return 75; // Desktop
      } else {
        return 65; // Large screens
      }
    }
  },
  watch: {
    active: function active(val) {
      this.isActive = val;
    }
  },
  mounted: function mounted() {
    window.addEventListener('resize', this.handleResize);
    // After mount, so the selector's ref exists and its diagram is already rendered.
    this.loadSelections();
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.handleResize);
  },
  methods: {
    handleResize: function handleResize() {
      this.screenWidth = window.innerWidth;
    },
    loadSelections: function loadSelections() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var rows;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_9__["default"].getQuoteButterfly(_this.entity.quoteId);
            case 1:
              rows = _context.v;
              _this.selectedItems = (rows || []).map(function (row) {
                return {
                  partId: row.butterflyCode,
                  partName: row.butterflyDesc,
                  area: row.area,
                  selected: row.isSelected,
                  sortOrder: row.sortOrder
                };
              });
              if (_this.$refs.vehicleButterflySelector) {
                _this.$refs.vehicleButterflySelector.hydrate(_this.selectedItems);
              }
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    reset: function reset() {
      // Call the reset method on the child VehicleButterflySelector component
      if (this.$refs.vehicleButterflySelector) {
        this.$refs.vehicleButterflySelector.reset();
      }
      // Clear local selectedItems as well
      this.selectedItems = [];
    },
    cancel: function cancel() {
      this.$emit('cancel');
      this.isActive = false;
    },
    done: function done() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var items;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              items = _this2.selectedItems.map(function (item) {
                return {
                  quoteId: _this2.entity.quoteId,
                  area: item.area,
                  butterflyCode: item.partId,
                  butterflyDesc: item.partName,
                  isSelected: item.selected,
                  // QuoteButterfly.SortOrder is NOT NULL, and an item only gets a compacted
                  // order if the user actually dragged it.
                  sortOrder: item.sortOrder || 999
                };
              });
              _context2.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_9__["default"].updateQuoteButterfly(_this2.entity.quoteId, items);
            case 1:
              _this2.$emit('done');
              _this2.isActive = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/views/quote/components/repairAreaGroupingData.js */ "./src/views/quote/components/repairAreaGroupingData.js");
/* harmony import */ var tippy_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! tippy.js */ "./node_modules/tippy.js/dist/tippy.esm.js");







































// Presentation only - this component never loads or saves anything. Wrappers own
// persistence and hand the current selection in through `value`.
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleButterflySelector',
  components: {
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_35___default.a
  },
  props: {
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    // Drag-to-sort. Only meaningful where the resulting sortOrder can be persisted.
    sortable: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      baseAreasParts: [],
      defaultAreas: Object.values(_views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["repairAreas"]),
      selectedItems: [],
      selectedAreas: [],
      selectedSections: [],
      hoveredArea: null,
      hoveredSection: null,
      selectedAreasParts: [],
      tooltipInstances: null
    };
  },
  computed: {
    selectedItemsCount: function selectedItemsCount() {
      var _this = this;
      return this.selectedAreas.reduce(function (total, area) {
        var _this$baseAreasParts$;
        var areaParts = ((_this$baseAreasParts$ = _this.baseAreasParts.find(function (ap) {
          return ap.area === area;
        })) === null || _this$baseAreasParts$ === void 0 ? void 0 : _this$baseAreasParts$.parts) || [];
        return total + areaParts.length;
      }, 0);
    },
    selectedItemsSelectedCount: function selectedItemsSelectedCount() {
      return this.selectedItems.filter(function (item) {
        return item.selected;
      }).length;
    }
  },
  // Deliberately no `value` watcher: every interaction emits `input`, so watching it
  // back in would loop. Wrappers control the lifecycle with v-if instead.
  created: function created() {
    this.constructAreaParts();
    this.hydrateFromValue(this.value);
  },
  mounted: function mounted() {
    this.initTippy();
  },
  beforeDestroy: function beforeDestroy() {
    if (this.tooltipInstances) {
      this.tooltipInstances.forEach(function (instance) {
        return instance.destroy();
      });
      this.tooltipInstances = null;
    }
  },
  methods: {
    initTippy: function initTippy() {
      this.tooltipInstances = Object(tippy_js__WEBPACK_IMPORTED_MODULE_37__["default"])('.has-tooltip');
    },
    constructAreaParts: function constructAreaParts() {
      var allAreas = Object(_views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["getAllRepairAreas"])();
      this.baseAreasParts = allAreas.map(function (areaData) {
        var parts = areaData.items.map(function (item) {
          return {
            partid: item.partId,
            partname: item.partName,
            sortOrder: item.sortOrder
          };
        }).sort(function (a, b) {
          return (a.sortOrder || 999) - (b.sortOrder || 999);
        });
        return {
          area: areaData.title,
          parts: parts
        };
      });
    },
    // Public: lets a wrapper populate the selection after an async load without
    // remounting, so the diagram renders straight away instead of waiting on the API.
    hydrate: function hydrate(items) {
      this.hydrateFromValue(items);
    },
    hydrateFromValue: function hydrateFromValue(items) {
      var _this2 = this;
      if (items && items.length) {
        this.selectedItems = items.map(function (item) {
          var area = item.area;
          var allSections = _this2.findAllSectionsForPart(item.partId, area);
          return {
            partId: item.partId,
            partName: item.partName,
            area: area,
            sections: allSections,
            // Store all sections
            selected: item.selected,
            areaSortNo: _this2.getFixedAreaSortOrder(area),
            sortOrder: item.sortOrder
          };
        });
        var selectedAreaNames = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(new Set(this.selectedItems.map(function (s) {
          return s.area;
        })));
        this.selectedAreas = selectedAreaNames;
        this.selectedSections = this.deriveSelectedSections();
        this.selectedAreasParts = selectedAreaNames.map(function (areaName) {
          var found = _this2.baseAreasParts.find(function (a) {
            return a.area === areaName;
          });
          if (found && found.parts.length > 0) {
            var selectedCodes = _this2.selectedItems.filter(function (s) {
              return s.area === areaName;
            }).map(function (s) {
              return s.partId;
            });
            var partsWithCheckedStatus = found.parts.map(function (part) {
              var matchedItem = _this2.selectedItems.find(function (s) {
                return s.area === areaName && s.partId === part.partid;
              });
              return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, part), {}, {
                checked: matchedItem ? matchedItem.selected : selectedCodes.includes(part.partid),
                selected: matchedItem ? matchedItem.selected : selectedCodes.includes(part.partid),
                sortOrder: matchedItem ? matchedItem.sortOrder : part.sortOrder
              });
            }).sort(function (a, b) {
              return (a.sortOrder || 999) - (b.sortOrder || 999);
            });
            return {
              name: areaName,
              items: partsWithCheckedStatus
            };
          }
          return null;
        }).filter(Boolean).sort(function (a, b) {
          var aOrder = _this2.getFixedAreaSortOrder(a.name);
          var bOrder = _this2.getFixedAreaSortOrder(b.name);
          return aOrder - bOrder;
        });
        this.sortCheckedPartsToTop();
        // No `input` emit here - hydrating is not a user edit, and emitting would make a
        // freshly opened selector look dirty.
      }
    },
    getFixedAreaSortOrder: function getFixedAreaSortOrder(areaName) {
      // Use the sortOrder from repairAreaGroupingData
      var allAreas = Object(_views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["getAllRepairAreas"])();
      var areaData = allAreas.find(function (area) {
        return area.title === areaName;
      });
      return areaData ? areaData.sortOrder : 999;
    },
    // A butterfly section is highlighted only when EVERY one of its parts is selected.
    // Deriving it as "any part selected" made codes that several sections share (Decal,
    // the sill and body-side panels, Rear Suspension) light up every section that lists
    // them, so re-opening the picker showed a handful of extra sections and areas.
    deriveSelectedSections: function deriveSelectedSections() {
      var _this3 = this;
      return Object.keys(_views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"]).filter(function (sectionName) {
        var sectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][sectionName];
        var sectionParts = sectionData && sectionData.items || [];
        return sectionParts.length > 0 && sectionParts.every(function (sectionPart) {
          return _this3.selectedItems.some(function (item) {
            return item.area === sectionData.area && item.partId === sectionPart.partId && item.selected;
          });
        });
      });
    },
    findAllSectionsForPart: function findAllSectionsForPart(partId, areaName) {
      // Find all sections that a part belongs to within a specific area
      return Object.keys(_views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"]).filter(function (sectionName) {
        var sectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][sectionName];
        return sectionData && sectionData.area === areaName && sectionData.items && sectionData.items.some(function (sectionPart) {
          return sectionPart.partId === partId;
        });
      });
    },
    mapCellToArea: function mapCellToArea(cellName) {
      if (this.defaultAreas.includes(cellName)) {
        return cellName;
      }

      // Use the imported sectionToAreaMapping from repairAreaGroupingData
      var sectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][cellName];
      return sectionData ? sectionData.area : 'Other';
    },
    toggleSection: function toggleSection(sectionName) {
      var _this4 = this;
      var areaName = this.mapCellToArea(sectionName);
      var sectionIndex = this.selectedSections.indexOf(sectionName);
      if (sectionIndex === -1) {
        // Select the section and its specific parts
        this.selectedSections.push(sectionName);
        this.addSectionParts(sectionName, areaName);
        // Ensure the area is shown in selectedAreasParts even if not all sections are selected
        this.ensureAreaIsDisplayed(areaName);
      } else {
        // Deselect the section and its specific parts
        this.selectedSections.splice(sectionIndex, 1);
        this.removeSectionParts(sectionName, areaName);
      }
      var areaIndex = this.selectedAreas.indexOf(areaName);
      var isNewArea = areaIndex === -1;
      if (isNewArea) {
        this.selectedAreas.push(areaName);
      }
      this.updateSelectedPartsDisplay();
      this.selectedSections = this.deriveSelectedSections();

      // Scroll to the newly added area after DOM update
      if (isNewArea && sectionIndex === -1) {
        this.$nextTick(function () {
          _this4.scrollToArea(areaName);
        });
      }
      this.$emit('input', this.selectedItems);
    },
    ensureAreaIsDisplayed: function ensureAreaIsDisplayed(areaName) {
      // Ensure the area is in selectedAreas for display purposes
      if (!this.selectedAreas.includes(areaName)) {
        this.selectedAreas.push(areaName);
      }
    },
    addSectionParts: function addSectionParts(sectionName, areaName) {
      var _this5 = this;
      // Add parts specific to this section
      var sectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][sectionName];
      if (sectionData && sectionData.items) {
        var areaSortNo = this.getFixedAreaSortOrder(areaName);
        sectionData.items.forEach(function (part) {
          var existingIndex = _this5.selectedItems.findIndex(function (item) {
            return item.area === areaName && item.partId === part.partId;
          });
          if (existingIndex === -1) {
            // Find all sections this part belongs to
            var allSections = _this5.findAllSectionsForPart(part.partId, areaName);
            // Add new part
            _this5.selectedItems.push({
              partId: part.partId,
              partName: part.partName,
              area: areaName,
              sections: allSections,
              // Store all sections
              areaSortNo: areaSortNo,
              selected: true,
              sortOrder: part.sortOrder || 999
            });
          } else {
            // Update existing part to ensure it's selected
            _this5.selectedItems[existingIndex].selected = true;
            // Update sections array
            var _allSections = _this5.findAllSectionsForPart(part.partId, areaName);
            _this5.selectedItems[existingIndex].sections = _allSections;
          }
        });
      }
    },
    removeSectionParts: function removeSectionParts(sectionName, areaName) {
      var _this6 = this;
      // Remove parts specific to this section, but only if they don't belong to other selected sections
      var sectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][sectionName];
      if (sectionData && sectionData.items) {
        var partIds = sectionData.items.map(function (part) {
          return part.partId;
        });
        partIds.forEach(function (partId) {
          // Check if this part belongs to any other selected section in the same area
          var otherSelectedSections = _this6.selectedSections.filter(function (section) {
            return section !== sectionName && _this6.mapCellToArea(section) === areaName;
          });
          var belongsToOtherSection = otherSelectedSections.some(function (otherSection) {
            var otherSectionData = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_36__["sectionToAreaMapping"][otherSection];
            return otherSectionData && otherSectionData.items && otherSectionData.items.some(function (item) {
              return item.partId === partId;
            });
          });
          if (!belongsToOtherSection) {
            // Remove the part completely if it doesn't belong to any other selected section
            _this6.selectedItems = _this6.selectedItems.filter(function (item) {
              return item.area !== areaName || item.partId !== partId;
            });
          } else {
            // Update the sections array to reflect remaining selected sections
            var itemIndex = _this6.selectedItems.findIndex(function (item) {
              return item.area === areaName && item.partId === partId;
            });
            if (itemIndex !== -1) {
              var allSections = _this6.findAllSectionsForPart(partId, areaName);
              _this6.selectedItems[itemIndex].sections = allSections;
            }
          }
        });
      }
    },
    addAreaParts: function addAreaParts(areaName) {
      var _this7 = this;
      var found = this.baseAreasParts.find(function (a) {
        return a.area === areaName;
      });
      if (found && found.parts.length > 0) {
        var areaSortNo = this.getFixedAreaSortOrder(areaName);
        found.parts.forEach(function (part) {
          var existingIndex = _this7.selectedItems.findIndex(function (item) {
            return item.area === areaName && item.partId === part.partid;
          });
          if (existingIndex === -1) {
            var selectedGroup = _this7.selectedAreasParts.find(function (sp) {
              return sp.name === areaName;
            });
            var partInGroup = selectedGroup === null || selectedGroup === void 0 ? void 0 : selectedGroup.items.find(function (item) {
              return item.partid === part.partid;
            });
            var isPartChecked = partInGroup ? partInGroup.checked : true;
            _this7.selectedItems.push({
              partId: part.partid,
              partName: part.partname,
              area: areaName,
              areaSortNo: areaSortNo,
              selected: isPartChecked,
              sortOrder: part.sortOrder || 999
            });
          }
        });
      }
    },
    removeAreaParts: function removeAreaParts(areaName) {
      this.selectedItems = this.selectedItems.filter(function (item) {
        return item.area !== areaName;
      });
    },
    updateSelectedPartsDisplay: function updateSelectedPartsDisplay() {
      var _this8 = this;
      this.selectedAreasParts = this.selectedAreas.map(function (areaName) {
        var areaPart = _this8.baseAreasParts.find(function (a) {
          return a.area === areaName;
        });
        if (areaPart && areaPart.parts.length > 0) {
          var existingGroup = _this8.selectedAreasParts.find(function (sp) {
            return sp.name === areaName;
          });
          var baseAreaParts = _this8.preserveUserPartOrder(areaPart.parts.map(function (part) {
            // Find if this part is in selectedItems
            var selectedItem = _this8.selectedItems.find(function (item) {
              return item.area === areaName && item.partId === part.partid;
            });
            return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, part), {}, {
              checked: !!(selectedItem && selectedItem.selected)
            });
          }), existingGroup);
          return {
            name: areaName,
            items: baseAreaParts
          };
        }
        return null;
      }).filter(Boolean).sort(function (a, b) {
        var aOrder = _this8.getFixedAreaSortOrder(a.name);
        var bOrder = _this8.getFixedAreaSortOrder(b.name);
        return aOrder - bOrder;
      });
      this.sortCheckedPartsToTop();
    },
    toggleCell: function toggleCell(cell) {
      var _this9 = this;
      if (!cell) return;
      var areaName = this.mapCellToArea(cell.name);
      var idx = this.selectedAreas.indexOf(areaName);
      if (idx === -1) {
        this.selectedAreas.push(areaName);
        this.addAreaParts(areaName);
        // Scroll to the newly added area after DOM update
        this.$nextTick(function () {
          _this9.scrollToArea(areaName);
        });
      } else {
        this.selectedAreas.splice(idx, 1);
        this.removeAreaParts(areaName);
      }
      this.updateSelectedPartsDisplay();
      this.updateSelectedSectionsBySelectedItems();
      this.$emit('input', this.selectedItems);
    },
    updateSelectedItems: function updateSelectedItems() {
      var _this0 = this;
      // Note: every displayed part lands in selectedItems, checked or not - `selected`
      // carries the checkbox state. Consumers must filter on it.
      this.selectedAreasParts.forEach(function (group) {
        group.items.forEach(function (item) {
          // Find all sections this part belongs to within the area
          var belongingSections = _this0.findAllSectionsForPart(item.partid, group.name);

          // Find if this part already exists in selectedItems
          var existingSelectedItem = _this0.selectedItems.find(function (selected) {
            return selected.area === group.name && selected.partId === item.partid;
          });
          if (existingSelectedItem) {
            // Update the 'selected' property to match item.checked
            existingSelectedItem.selected = item.checked;
            // Store all sections this part belongs to
            existingSelectedItem.sections = belongingSections;
          } else {
            _this0.selectedItems.push({
              partId: item.partid,
              partName: item.partname,
              area: group.name,
              sections: belongingSections,
              // Store all sections
              selected: item.checked,
              areaSortNo: _this0.getFixedAreaSortOrder(group.name),
              sortOrder: item.sortOrder || 999
            });
          }
        });
      });
      this.selectedSections = this.deriveSelectedSections();

      // Update selectedAreas to include areas that have any selected sections
      this.selectedSections.forEach(function (section) {
        var area = _this0.mapCellToArea(section);
        if (area && !_this0.selectedAreas.includes(area)) {
          _this0.selectedAreas.push(area);
        }
      });
      this.sortCheckedPartsToTop();
      this.$emit('input', this.selectedItems);
    },
    sortPartsByOrder: function sortPartsByOrder(parts) {
      return parts.sort(function (a, b) {
        return (a.sortOrder || 999) - (b.sortOrder || 999);
      });
    },
    preserveUserPartOrder: function preserveUserPartOrder(parts, existingGroup) {
      if (existingGroup && existingGroup.items && existingGroup.items.length > 0) {
        var existingOrder = existingGroup.items.map(function (item) {
          return item.partid;
        });
        return parts.sort(function (a, b) {
          var aIndex = existingOrder.indexOf(a.partid);
          var bIndex = existingOrder.indexOf(b.partid);
          if (aIndex !== -1 && bIndex !== -1) {
            return aIndex - bIndex;
          }
          if (aIndex !== -1) return -1;
          if (bIndex !== -1) return 1;
          return (a.sortOrder || 999) - (b.sortOrder || 999);
        });
      }
      return this.sortPartsByOrder(parts);
    },
    onPartDragEnd: function onPartDragEnd(group) {
      var _this1 = this;
      group.items.forEach(function (item, index) {
        item.sortOrder = index + 1;
        var selectedItem = _this1.selectedItems.find(function (si) {
          return si.partId === item.partid && si.area === group.name;
        });
        if (selectedItem) {
          selectedItem.sortOrder = index + 1;
        }
      });
      this.$emit('input', this.selectedItems);
    },
    onPartDragStart: function onPartDragStart(event) {
      event.stopPropagation();
    },
    onPartDragMove: function onPartDragMove(event) {
      event.stopPropagation();
    },
    isPartSelected: function isPartSelected(sectionName) {
      return this.selectedSections.includes(sectionName);
    },
    isPartHovered: function isPartHovered(sectionName) {
      return this.hoveredSection === sectionName;
    },
    onPathMouseEnter: function onPathMouseEnter(sectionName) {
      this.hoveredSection = sectionName;
      // Also set the hovered area for backward compatibility if needed
      var areaName = this.mapCellToArea(sectionName);
      this.hoveredArea = areaName;
    },
    onPathMouseLeave: function onPathMouseLeave() {
      this.hoveredSection = null;
      this.hoveredArea = null;
    },
    selectPartBySection: function selectPartBySection(sectionName) {
      this.toggleSection(sectionName);
    },
    isAreaSelected: function isAreaSelected(areaName) {
      return this.selectedAreas.includes(areaName);
    },
    toggleRepairArea: function toggleRepairArea(areaName) {
      var cell = {
        name: areaName
      };
      this.toggleCell(cell);
    },
    updateSelectedSectionsBySelectedItems: function updateSelectedSectionsBySelectedItems() {
      var _this10 = this;
      this.selectedSections = this.deriveSelectedSections();

      // Update selectedAreas to include areas that have any selected sections
      var newSelectedAreas = [];
      this.selectedSections.forEach(function (section) {
        var area = _this10.mapCellToArea(section);
        if (area && !newSelectedAreas.includes(area)) {
          newSelectedAreas.push(area);
        }
      });

      // Merge with existing selectedAreas to preserve areas that might have been added directly
      this.selectedAreas.forEach(function (area) {
        if (!newSelectedAreas.includes(area)) {
          newSelectedAreas.push(area);
        }
      });
      this.selectedAreas = newSelectedAreas;
    },
    selectAllInGroup: function selectAllInGroup(group) {
      // Select all parts in the specific group
      group.items.forEach(function (item) {
        item.checked = true;
      });
      this.updateSelectedItems();
    },
    selectNoneInGroup: function selectNoneInGroup(group) {
      // Deselect all parts in the specific group
      group.items.forEach(function (item) {
        item.checked = false;
      });
      this.updateSelectedItems();
    },
    areAllPartsSelectedInGroup: function areAllPartsSelectedInGroup(group) {
      // Check if all parts in the group are selected
      return group.items.length > 0 && group.items.every(function (item) {
        return item.checked;
      });
    },
    areNoPartsSelectedInGroup: function areNoPartsSelectedInGroup(group) {
      // Check if no parts in the group are selected
      return group.items.length === 0 || group.items.every(function (item) {
        return !item.checked;
      });
    },
    reset: function reset() {
      // Clear all selections
      this.selectedItems = [];
      this.selectedAreas = [];
      this.selectedSections = [];
      this.selectedAreasParts = [];
      this.hoveredArea = null;
      this.hoveredSection = null;

      // Emit the cleared selection
      this.$emit('input', this.selectedItems);
    },
    scrollToArea: function scrollToArea(areaName) {
      // Scroll to the specific area group block
      var refName = "group-".concat(areaName);
      var groupElement = this.$refs[refName];
      if (groupElement && groupElement[0]) {
        groupElement[0].scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    },
    sortCheckedPartsToTop: function sortCheckedPartsToTop() {
      this.selectedAreasParts.forEach(function (group) {
        if (group && group.items) {
          group.items.sort(function (a, b) {
            if (a.checked === b.checked) {
              if (!a.checked && !b.checked) {
                return (a.sortOrder || 999) - (b.sortOrder || 999);
              }
              return 0;
            }
            return a.checked ? -1 : 1;
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": _vm.responsiveMinWidth,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "fqi fqi-butterfly fqi-32px"
  })]) : _vm._e(), _c("span", [_vm._v("Butterfly Search")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("vehicle-butterfly-selector", {
    ref: "vehicleButterflySelector",
    model: {
      value: _vm.selectedItems,
      callback: function callback($$v) {
        _vm.selectedItems = $$v;
      },
      expression: "selectedItems"
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    staticStyle: {
      width: "100%",
      display: "flex",
      "justify-content": "space-between"
    }
  }, [_c("div", {
    staticStyle: {
      width: "100%"
    },
    attrs: {
      align: "right"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Reset"
    },
    on: {
      click: _vm.reset
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: _vm.cancel
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Cancel")])]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Done"
    },
    on: {
      click: _vm.done
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]), _c("span", [_vm._v("Done")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": _vm.responsiveMinWidth,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title is-flex-items-center"
  }, [_c("span", {
    staticClass: "mso mso-24px mr-1"
  }, [_vm._v("car_gear")]), _c("span", [_vm._v("Vehicle Butterfly Selector")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("vehicle-butterfly-selector", {
    ref: "vehicleButterflySelector",
    attrs: {
      sortable: ""
    },
    model: {
      value: _vm.selectedItems,
      callback: function callback($$v) {
        _vm.selectedItems = $$v;
      },
      expression: "selectedItems"
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    staticStyle: {
      width: "100%",
      display: "flex",
      "justify-content": "space-between"
    }
  }, [_c("div", {
    staticStyle: {
      width: "100%"
    },
    attrs: {
      align: "right"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Reset"
    },
    on: {
      click: _vm.reset
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: _vm.cancel
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Cancel")])]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Done"
    },
    on: {
      click: _vm.done
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]), _c("span", [_vm._v("Done")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_3__);




var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "selector-body"
  }, [_c("div", {
    staticClass: "columns is-variable is-3"
  }, [_c("div", {
    staticClass: "column is-3"
  }, [_c("div", {
    staticClass: "repair-section"
  }, [_c("div", {
    staticClass: "section-title mb-2"
  }, [_vm._v("Repair Section")]), _c("div", {
    staticClass: "is-4 mb-2"
  }, [_vm._v("Quick select zones of impact")]), _c("div", {
    staticClass: "repair-area-toggles"
  }, _vm._l(_vm.defaultAreas, function (area) {
    return _c("div", {
      key: area,
      staticClass: "repair-area-toggle mb-3"
    }, [_c("button", {
      class: ["button", "is-fullwidth", "repair-toggle-btn", {
        "is-primary": _vm.isAreaSelected(area)
      }],
      on: {
        click: function click($event) {
          return _vm.toggleRepairArea(area);
        }
      }
    }, [_c("span", [_vm._v(_vm._s(area) + " " + _vm._s(!area.toUpperCase().startsWith("TRIM") ? "Section" : ""))])])]);
  }), 0)])]), _c("div", {
    staticClass: "column is-5"
  }, [_c("div", {
    staticClass: "diagram-section"
  }, [_vm._m(0), _c("div", {
    staticClass: "vehicle-diagram pt-5"
  }, [_c("div", {
    staticClass: "vehicle-diagram-image"
  }, [_c("svg", {
    staticClass: "sedan-diagram clickable-svg",
    attrs: {
      version: "1.1",
      id: "sedan-svg",
      xmlns: "http://www.w3.org/2000/svg",
      "xmlns:xlink": "http://www.w3.org/1999/xlink",
      x: "0px",
      y: "0px",
      viewBox: "0 0 329.8 656.1",
      "xml:space": "preserve"
    }
  }, [_c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("FrontWindscreen"),
      hovered: _vm.isPartHovered("FrontWindscreen")
    },
    attrs: {
      id: "FrontWindscreen",
      "data-tippy-content": "Front Windscreen",
      d: "M164.3,185.4c52.8,1,78.6,10.6,90.7,18l9.6-49.7c0,0-13.7-25.1-100.5-26.7c-86.8,2.3-98.8,26.1-98.8,26.1l9.5,50.1C86.3,196.2,111.4,186.8,164.3,185.4z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("FrontWindscreen");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("FrontWindscreen");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("Turret"),
      hovered: _vm.isPartHovered("Turret")
    },
    attrs: {
      id: "Turret",
      "data-tippy-content": "Turret",
      d: "M254.1,208.1c-12.4-7.4-38.1-16.6-89.9-17.6c-51.2,1.3-76.4,10.2-88.4,17.2c2.8,23,23.8,199.2,11.6,282.4c13.4,5,38.7,11.6,78.8,12.3c40.2-1,65.4-7.9,78.7-12.9C231.6,403.6,250.3,244.9,254.1,208.1z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("Turret");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("Turret");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightCantRail"),
      hovered: _vm.isPartHovered("RightCantRail")
    },
    attrs: {
      id: "RightCantRail",
      "data-tippy-content": "Right Cant Rail",
      d: "M249.9,488c-5-35.1-4.9-83.1-3.7-129.3c0.1-2.7,2.1-121.7,22.6-204.5l9.9-7.3c-15.2,47-21.1,206.9-21.3,209.6c-1.2,46.2-0.3,92,4.7,127.1"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightCantRail");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightCantRail");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftCantRail"),
      hovered: _vm.isPartHovered("LeftCantRail")
    },
    attrs: {
      id: "LeftCantRail",
      "data-tippy-content": "Left Cant Rail",
      d: "M82.7,488.6c4.7-35.2,4.2-83.2,2.6-129.4c-0.2-2.7-3.1-121.6-24.3-204.3l-10-7.2c15.6,46.9,22.8,206.7,23,209.4c1.6,46.2,1,92-3.7,127.1"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftCantRail");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftCantRail");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftFrontDoor"),
      hovered: _vm.isPartHovered("LeftFrontDoor")
    },
    attrs: {
      id: "LeftFrontDoor",
      "data-tippy-content": "Left Front Door",
      d: "M0,192c0.4-6.9,3.1-13.5,7.6-18.7c5-5.9,14.8-7.8,21-8.3c-0.5-25.3-1.2-32.6-1.2-32.6l18.7,13.4c0,0,17.4,89.6,18.7,176.1h-1.9L31.6,322l-1.8-102.5c-0.3-13.2-0.5-24.7-0.7-35.3C15.4,190,0,192,0,192z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftFrontDoor");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftFrontDoor");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightFrontDoor"),
      hovered: _vm.isPartHovered("RightFrontDoor")
    },
    attrs: {
      id: "RightFrontDoor",
      "data-tippy-content": "Right Front Door",
      d: "M329.8,190.7c-0.5-6.9-3.2-13.5-7.7-18.7c-5.1-5.9-14.9-7.6-21-8.2c0.3-25.3,0.9-32.6,0.9-32.6l-18.6,13.6c0,0-16.7,89.7-17.2,176.2h1.9l31.3-0.1l1-102.5c0.2-13.2,0.3-24.7,0.4-35.3C314.4,188.8,329.8,190.7,329.8,190.7z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightFrontDoor");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightFrontDoor");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftRearDoor"),
      hovered: _vm.isPartHovered("LeftRearDoor")
    },
    attrs: {
      id: "LeftRearDoor",
      "data-tippy-content": "Left Rear Door",
      d: "M64.2,326.6c0,0,2.8,54,2,79.7c0,0.3,0,0.5,0,0.7c-0.3,30.1-3.1,56.5-4.6,75.6l-17.9-6.5c-4.8-22.2-9.1-49.9-10.2-77.3c-0.8-18.4-1.5-44.3-2.3-72.1L64.2,326.6z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftRearDoor");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftRearDoor");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightRearDoor"),
      hovered: _vm.isPartHovered("RightRearDoor")
    },
    attrs: {
      id: "RightRearDoor",
      "data-tippy-content": "Right Rear Door",
      d: "M265.6,325.8c0,0-2.4,54.1-1.3,79.7c0,0.3,0,0.5,0,0.7c0.5,30.1,3.6,56.5,5.2,75.6l17.9-6.7c4.6-22.2,8.7-50,9.6-77.4c0.6-18.4,1.2-44.3,1.7-72.1L265.6,325.8z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightRearDoor");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightRearDoor");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("FrontBumper"),
      hovered: _vm.isPartHovered("FrontBumper")
    },
    attrs: {
      id: "FrontBumper",
      "data-tippy-content": "Front Bumper",
      d: "M236.2,27.2c-4.1-8.8-7.2-15.1-8.7-17.2c-6.4-9-61.4-10-61.4-10h-0.3c0,0-55,1-61.4,10c-1.5,2.1-4.8,8.6-8.9,17.8C132.2,23.7,179.8,19.8,236.2,27.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("FrontBumper");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("FrontBumper");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightFrontLamps"),
      hovered: _vm.isPartHovered("RightFrontLamps")
    },
    attrs: {
      id: "RightFrontLamps",
      "data-tippy-content": "Right Front Lamps",
      d: "M269.7,32.2c-13.4-15.7-16.1-17.8-38.3-23.6c4.4,7.2,6.6,12.1,10,19.2C252.4,28.8,260.6,30.6,269.7,32.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightFrontLamps");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightFrontLamps");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftFrontLamps"),
      hovered: _vm.isPartHovered("LeftFrontLamps")
    },
    attrs: {
      id: "LeftFrontLamps",
      "data-tippy-content": "Left Front Lamps",
      d: "M60.1,32.2C73.5,16.5,76.2,14.4,98.4,8.6c-4.4,7.2-6.6,12.1-10,19.2C77.4,28.8,69.2,30.6,60.1,32.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftFrontLamps");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftFrontLamps");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightFrontGuard"),
      hovered: _vm.isPartHovered("RightFrontGuard")
    },
    attrs: {
      id: "RightFrontGuard",
      "data-tippy-content": "Right Front Guard",
      d: "M288.8,71.2c-1.9-6.2-4.7-12.8-8.4-19.4c-2.8-5.2-6-10.1-9.7-14.6l-0.1-0.1c-9.5-2.1-19.2-3.6-28.9-4.5c8.8,17.2,19.1,43.1,27.2,67c5,13.5,9.6,26.9,13,38.8l17.1-11.6C299,126.8,298.5,99.2,288.8,71.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightFrontGuard");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightFrontGuard");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftFrontGuard"),
      hovered: _vm.isPartHovered("LeftFrontGuard")
    },
    attrs: {
      id: "LeftFrontGuard",
      "data-tippy-content": "Left Front Guard",
      d: "M41,71.2c1.9-6.2,4.7-12.8,8.4-19.4c2.8-5.2,6-10.1,9.7-14.6l0.1-0.1c9.5-2.1,19.2-3.6,28.9-4.5c-8.8,17.2-19.1,43.1-27.2,67c-5,13.5-9.6,26.9-13,38.8l-17.1-11.6C30.8,126.8,31.3,99.2,41,71.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftFrontGuard");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftFrontGuard");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("Bonnet"),
      hovered: _vm.isPartHovered("Bonnet")
    },
    attrs: {
      id: "Bonnet",
      "data-tippy-content": "Bonnet",
      d: "M267.8,146.2l7.7-5.3C272,116,248.6,60,235.1,31.5C178.7,24.3,131,28,94.4,32.1C80.8,61,57.5,117,54.2,141.5l7.5,5.2c2.1-2.8,20.1-22.6,103.2-24.2C245,123.9,264.6,142.4,267.8,146.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("Bonnet");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("Bonnet");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftQuarterPanel"),
      hovered: _vm.isPartHovered("LeftQuarterPanel")
    },
    attrs: {
      id: "LeftQuarterPanel",
      "data-tippy-content": "Left Quarter Panel",
      d: "M43.2,481.2l18.4,6.3c0,0-3.5,34.1,11.8,132c0,0-12.9-6-17.2-12.3C56,607.3,32.4,531.3,43.2,481.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftQuarterPanel");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftQuarterPanel");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightQuarterPanel"),
      hovered: _vm.isPartHovered("RightQuarterPanel")
    },
    attrs: {
      id: "RightQuarterPanel",
      "data-tippy-content": "Right Quarter Panel",
      d: "M286.6,481.2l-18.4,6.3c0,0,3.5,34.1-11.8,132c0,0,12.9-6,17.2-12.3C273.8,607.3,297.4,531.3,286.6,481.2z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightQuarterPanel");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightQuarterPanel");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RearBumper"),
      hovered: _vm.isPartHovered("RearBumper")
    },
    attrs: {
      id: "RearBumper",
      "data-tippy-content": "Rear Bumper",
      d: "M165.2,632.8c-43.2,0.3-72.3-3.2-88.2-5.8c1.4,7.5,3.4,15.3,5.8,19.4c0,0,39.7,10.1,81.9,9.7h0.3c42.2,0.4,81.8-9.7,81.8-9.7c2.5-4.2,4.4-12.3,5.9-20C236.8,629.1,207.9,632.8,165.2,632.8z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RearBumper");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RearBumper");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RearWindscreen"),
      hovered: _vm.isPartHovered("RearWindscreen")
    },
    attrs: {
      id: "RearWindscreen",
      "data-tippy-content": "Rear Windscreen",
      d: "M164.5,552.2c-44.3,0.5-91.7-12.9-91.7-12.9c-5.8-12.6-3.4-51-3.4-51s30.9,18.2,95.3,17.7c64.4,0.5,95.3-17.7,95.3-17.7s3.4,38.4-2.5,51c0,0-48.3,13.4-92.6,12.9"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RearWindscreen");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RearWindscreen");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("Bootlid"),
      hovered: _vm.isPartHovered("Bootlid")
    },
    attrs: {
      id: "Bootlid",
      "data-tippy-content": "Bootlid",
      d: "M164.9,556.3h-0.3c-40.8,0.4-84-10.5-93.1-12.9c0.6,10.4,3.3,55.1,7.7,77.6c9.3,2.1,37.6,7.3,86.2,7c48.2,0,76.4-5.4,85.9-7.6c4.1-21.9,6.4-64.7,7-76.7C247.7,546.4,204.8,556.8,164.9,556.3z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("Bootlid");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("Bootlid");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("RightRearLamps"),
      hovered: _vm.isPartHovered("RightRearLamps")
    },
    attrs: {
      id: "RightRearLamps",
      "data-tippy-content": "Right Rear Lamps",
      d: "M257.1,625.8c-1.4,7.6-3.3,15.5-5.7,20.1c3.6-1.6,10.7-5,13.4-7.7c3.6-3.8,8.3-23,8.3-23S267,620.2,257.1,625.8z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("RightRearLamps");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("RightRearLamps");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  }), _c("path", {
    staticClass: "has-tooltip",
    class: {
      selected: _vm.isPartSelected("LeftRearLamps"),
      hovered: _vm.isPartHovered("LeftRearLamps")
    },
    attrs: {
      id: "LeftRearLamps",
      "data-tippy-content": "Left Rear Lamps",
      d: "M72.7,625.8c1.4,7.6,3.3,15.5,5.7,20.1c-3.6-1.6-10.7-5-13.4-7.7c-3.6-3.8-8.3-23-8.3-23S62.8,620.2,72.7,625.8z"
    },
    on: {
      click: function click($event) {
        return _vm.selectPartBySection("LeftRearLamps");
      },
      mouseenter: function mouseenter($event) {
        return _vm.onPathMouseEnter("LeftRearLamps");
      },
      mouseleave: _vm.onPathMouseLeave
    }
  })])])])])]), _c("div", {
    staticClass: "column is-4"
  }, [_c("div", {
    staticClass: "groups-section"
  }, [_c("div", {
    staticClass: "section-title is-6 mb-2 is-flex is-justify-content-space-between"
  }, [_c("span", [_vm._v("Selected Areas")]), _vm.selectedItems.length > 0 ? _c("span", {
    staticClass: "tag is-primary is-size-6 is-rounded has-text-white"
  }, [_vm._v(" " + _vm._s(_vm.selectedItemsSelectedCount) + " / " + _vm._s(_vm.selectedItemsCount) + " ")]) : _vm._e()]), _c("div", {
    staticClass: "groups-selection"
  }, [_vm.selectedAreasParts.length > 0 ? _c("div", {
    staticClass: "selected-groups"
  }, _vm._l(_vm.selectedAreasParts, function (group) {
    return _c("div", {
      key: group.name,
      ref: "group-".concat(group.name),
      refInFor: true,
      staticClass: "group-block"
    }, [_c("div", {
      staticClass: "group-title"
    }, [_c("span", {
      staticClass: "group-name"
    }, [_vm._v(_vm._s(group.name))]), _c("div", {
      staticClass: "group-actions ml-auto"
    }, [_c("button", {
      staticClass: "button is-small is-text",
      attrs: {
        disabled: _vm.areAllPartsSelectedInGroup(group),
        title: "Select All"
      },
      on: {
        click: function click($event) {
          return _vm.selectAllInGroup(group);
        }
      }
    }, [_vm._m(1, true)]), _c("button", {
      staticClass: "button is-small is-text",
      attrs: {
        disabled: _vm.areNoPartsSelectedInGroup(group),
        title: "Select None"
      },
      on: {
        click: function click($event) {
          return _vm.selectNoneInGroup(group);
        }
      }
    }, [_vm._m(2, true)])])]), _c("draggable", {
      staticClass: "draggable-parts",
      attrs: {
        options: {
          animation: 150,
          ghostClass: "ghost-part",
          chosenClass: "chosen-part",
          handle: ".part-handle",
          containment: "parent",
          preventOnFilter: false,
          forceFallback: true,
          fallbackClass: "fallback-part",
          disabled: !_vm.sortable
        }
      },
      on: {
        start: _vm.onPartDragStart,
        move: _vm.onPartDragMove,
        end: function end($event) {
          return _vm.onPartDragEnd(group);
        }
      },
      model: {
        value: group.items,
        callback: function callback($$v) {
          _vm.$set(group, "items", $$v);
        },
        expression: "group.items"
      }
    }, _vm._l(group.items, function (item) {
      return _c("div", {
        key: item.partid,
        staticClass: "group-item is-flex is-justify-content-space-between"
      }, [_c("div", {
        staticClass: "is-flex is-align-items-center",
        staticStyle: {
          width: "100%"
        }
      }, [_c("div", {
        staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
      }, [_c("input", {
        directives: [{
          name: "model",
          rawName: "v-model",
          value: item.checked,
          expression: "item.checked"
        }],
        attrs: {
          type: "checkbox"
        },
        domProps: {
          checked: Array.isArray(item.checked) ? _vm._i(item.checked, null) > -1 : item.checked
        },
        on: {
          change: [function ($event) {
            var $$a = item.checked,
              $$el = $event.target,
              $$c = $$el.checked ? true : false;
            if (Array.isArray($$a)) {
              var $$v = null,
                $$i = _vm._i($$a, $$v);
              if ($$el.checked) {
                $$i < 0 && _vm.$set(item, "checked", $$a.concat([$$v]));
              } else {
                $$i > -1 && _vm.$set(item, "checked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
              }
            } else {
              _vm.$set(item, "checked", $$c);
            }
          }, _vm.updateSelectedItems]
        }
      }), _c("div", {
        staticClass: "state"
      }, [_c("i", {
        staticClass: "icon mdi mdi-check"
      }), _c("label")])]), _c("span", {
        staticClass: "ml-2"
      }, [_vm._v(_vm._s(item.partname))])]), _vm.sortable ? _c("span", {
        staticClass: "mso mso-16px part-handle is-flex is-align-items-flex-end"
      }, [_vm._v("swap_vert")]) : _vm._e()]);
    }), 0)], 1);
  }), 0) : _c("section", {
    staticClass: "section"
  }, [_vm._m(3)])])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-flex is-align-items-center diagram-container"
  }, [_c("div", {
    staticClass: "section-title mb-2",
    staticStyle: {
      flex: "1",
      "text-align": "center"
    }
  }, [_vm._v("Butterfly")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-car-off"
  })]), _c("p", [_vm._v("There are no items in your list.")]), _c("p", [_vm._v("Start by selecting zones of impacts or areas from the vehicle butterfly.")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.is-flex-items-center[data-v-974ad2d4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.is-flex-items-center[data-v-29779dee] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.selector-body[data-v-a93c59a4] {\n  padding: 0 0 0 0;\n}\n.repair-section[data-v-a93c59a4] {\n  border-radius: 8px;\n  padding: 1rem;\n  height: 60vh;\n  overflow-y: auto;\n}\n.diagram-section[data-v-a93c59a4] {\n  border-radius: 8px;\n  padding: 1rem;\n  height: 60vh;\n  overflow-y: auto;\n}\n.vehicle-diagram .grid[data-v-a93c59a4] {\n  gap: 0.5rem;\n}\n.diagram-cell[data-v-a93c59a4] {\n  min-width: 80px;\n  min-height: 80px;\n  border-radius: 6px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  cursor: pointer;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  padding: 0.5rem;\n  text-align: center;\n  word-wrap: break-word;\n  font-size: clamp(0.1rem, 1vw, 1rem);\n}\n.diagram-cell.is-selected[data-v-a93c59a4] {\n  background: #1976d2;\n  color: #fff;\n}\n.diagram-cell.is-empty[data-v-a93c59a4] {\n  opacity: 0;\n  cursor: default;\n}\n.section-title[data-v-a93c59a4] {\n  font-weight: 600;\n  /* color: #1a5276; */\n  color: var(--text-color);\n  margin-bottom: 0.5rem;\n  font-size: 1.2rem;\n}\n.groups-section[data-v-a93c59a4] {\n  border-radius: 8px;\n  padding: 1rem;\n  -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.03);\n          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.03);\n}\n.groups-selection[data-v-a93c59a4] {\n  height: 55vh;\n  overflow-y: auto;\n  overflow-x: hidden;\n  position: relative;\n}\n.group-block[data-v-a93c59a4] {\n  margin-bottom: 1.5rem;\n  border-radius: 6px;\n  padding: 0.5rem;\n}\n.group-block[data-v-a93c59a4]:hover {\n  /* background-color: #fafbfc; */\n  background-color: var(--background-hover-color);\n}\n.group-title[data-v-a93c59a4] {\n  font-weight: 600;\n  /* color: #1976d2; */\n  color: var(--text-color);\n  margin-bottom: 0.5rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  border-radius: 0;\n  /* border-bottom: solid 1px #e7e7e7; */\n  border-bottom: solid 1px var(--border-color);\n  padding-bottom: 0.25rem;\n}\n.group-name[data-v-a93c59a4] {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n.group-actions[data-v-a93c59a4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  gap: 0.75rem;\n}\n.group-actions .button[data-v-a93c59a4] {\n  padding: 0.125rem 0.25rem;\n  height: auto;\n  min-height: 1.5rem;\n  border: none;\n  background: transparent;\n  color: var(--text-color);\n}\n.group-actions .button[data-v-a93c59a4]:hover:not(:disabled) {\n  background-color: var(--background-hover-color);\n  /* color: var(--text-color); */\n  color: #fff;\n}\n.group-actions .button[data-v-a93c59a4]:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n.group-item[data-v-a93c59a4] {\n  padding: 0.25rem;\n  margin-bottom: 0.25rem;\n  border-radius: 4px;\n}\n.group-item[data-v-a93c59a4]:hover {\n  /* background-color: #f8f9fa; */\n  background-color: var(--background-hover-color);\n}\n.group-item .checkbox[data-v-a93c59a4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  width: 100%;\n}\n.part-handle[data-v-a93c59a4] {\n  margin-right: 0.5rem;\n  /* color: #999; */\n  color: var(--text-color);\n  cursor: move;\n  font-size: 0.9em;\n}\n.part-handle[data-v-a93c59a4]:hover {\n  /* color: #1976d2; */\n  color: var(--text-color);\n}\n.draggable-parts[data-v-a93c59a4] {\n  min-height: 20px;\n  overflow: hidden;\n  position: relative;\n  contain: layout style;\n}\n.ghost-part[data-v-a93c59a4] {\n  opacity: 0.5;\n  /* background: #f0f8ff; */\n  background: var(--background-color);\n  /* border: 1px dashed #1976d2; */\n  border: 1px dashed var(--border-color);\n  border-radius: 4px;\n}\n.chosen-part[data-v-a93c59a4] {\n  background: #e3f2fd;\n  -webkit-box-shadow: 0 2px 4px rgba(25, 118, 210, 0.2);\n          box-shadow: 0 2px 4px rgba(25, 118, 210, 0.2);\n}\n.fallback-part[data-v-a93c59a4] {\n  background: #e3f2fd;\n  -webkit-box-shadow: 0 4px 8px rgba(25, 118, 210, 0.3);\n          box-shadow: 0 4px 8px rgba(25, 118, 210, 0.3);\n  border: 1px solid #1976d2;\n  border-radius: 4px;\n  z-index: 1000;\n  pointer-events: none;\n}\n.selector-footer[data-v-a93c59a4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  gap: 1rem;\n}\n.vehicle-diagram-image[data-v-a93c59a4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  width: 100%;\n  height: 48vh;\n}\n.sedan-diagram[data-v-a93c59a4] {\n  max-width: 100%;\n  max-height: 100%;\n  width: auto;\n  height: auto;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n.clickable-svg path[data-v-a93c59a4]:focus {\n  outline: none !important;\n}\n.clickable-svg path[data-v-a93c59a4] {\n  fill: #6c757d;\n  stroke: #6c757d;\n  stroke-width: 2;\n  cursor: pointer;\n}\n.clickable-svg path.hovered[data-v-a93c59a4] {\n  fill: #9ec5e9;\n  stroke: #9ec5e9;\n  stroke-width: 2;\n}\n.clickable-svg path.selected[data-v-a93c59a4] {\n  fill: #3291ef;\n  stroke: #3291ef;\n  stroke-width: 2;\n}\n.repair-area-toggles[data-v-a93c59a4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  gap: 0.5rem;\n}\n.repair-toggle-btn[data-v-a93c59a4] {\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  text-align: left;\n  border-radius: 6px;\n  padding: 0.5rem 0.75rem;\n}\n.repair-toggle-btn[data-v-a93c59a4]:hover {\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n}\n.repair-toggle-btn.is-primary[data-v-a93c59a4] {\n  background-color: #1976d2;\n  border-color: #1976d2;\n  color: white;\n}\n.repair-toggle-btn.is-light[data-v-a93c59a4] {\n  background-color: var(--background-color);\n  border-color: var(--border-color);\n  color: var(--text-color);\n  /* background-color: white; */\n  /* border-color: #dee2e6; */\n  /* color: #495057; */\n}\n\n/* .icon.is-filled.has-text-success { background-color: hsl(141, 71%, 48%); }\n.icon.is-filled.has-text-grey { background-color: hsl(0, 0%, 71%); } */\n\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("45c5a2ba", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2be14aca", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3279b946", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue":
/*!*************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true */ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true");
/* harmony import */ var _VehicleButterflyFilterModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleButterflyFilterModal.vue?vue&type=script&lang=js */ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css */ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleButterflyFilterModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "974ad2d4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VehicleButterfly/VehicleButterflyFilterModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyFilterModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css":
/*!*********************************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css ***!
  \*********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=style&index=0&id=974ad2d4&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_style_index_0_id_974ad2d4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true ***!
  \*******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyFilterModal.vue?vue&type=template&id=974ad2d4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyFilterModal_vue_vue_type_template_id_974ad2d4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyModal.vue":
/*!*******************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyModal.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true */ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true");
/* harmony import */ var _VehicleButterflyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleButterflyModal.vue?vue&type=script&lang=js */ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css */ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleButterflyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "29779dee",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VehicleButterfly/VehicleButterflyModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js":
/*!*******************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css":
/*!***************************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=style&index=0&id=29779dee&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_style_index_0_id_29779dee_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true":
/*!*************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflyModal.vue?vue&type=template&id=29779dee&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflyModal_vue_vue_type_template_id_29779dee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflySelector.vue":
/*!**********************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflySelector.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true");
/* harmony import */ var _VehicleButterflySelector_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleButterflySelector.vue?vue&type=script&lang=js */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css */ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleButterflySelector_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "a93c59a4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VehicleButterfly/VehicleButterflySelector.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js":
/*!**********************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflySelector.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css":
/*!******************************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=style&index=0&id=a93c59a4&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_style_index_0_id_a93c59a4_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true":
/*!****************************************************************************************************************!*\
  !*** ./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true ***!
  \****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VehicleButterfly/VehicleButterflySelector.vue?vue&type=template&id=a93c59a4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleButterflySelector_vue_vue_type_template_id_a93c59a4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=vehicle-butterfly-chunk.js.map