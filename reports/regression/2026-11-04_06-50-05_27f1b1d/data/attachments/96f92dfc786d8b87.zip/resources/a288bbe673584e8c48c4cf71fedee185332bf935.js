(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["printpreview-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./PrintPreviewAppDetailHeader */ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue");
/* harmony import */ var _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./PrintPreviewExportModal */ "./src/components/printpreview/PrintPreviewExportModal.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_ImageSelect__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/components/ImageSelect */ "./src/components/ImageSelect/index.js");
/* harmony import */ var _components_VueEmail__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/components/VueEmail */ "./src/components/VueEmail/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./storeMixin */ "./src/components/printpreview/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! mime-types */ "./node_modules/mime-types/index.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(mime_types__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @/views/quote/components/AttachmentSelect.vue */ "./src/views/quote/components/AttachmentSelect.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _services_emailLimits__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @/services/emailLimits */ "./src/services/emailLimits.js");
/* harmony import */ var _components_VueEmail_attachmentSizes__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/components/VueEmail/attachmentSizes */ "./src/components/VueEmail/attachmentSizes.js");









































// import _isEmpty from 'lodash/isEmpty'





// Temporary const for copyright message
var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreview',
  components: {
    PrintPreviewAppDetailHeader: _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_29__["default"],
    PrintPreviewExportModal: _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_31__["default"],
    VueEmail: _components_VueEmail__WEBPACK_IMPORTED_MODULE_34__["VueEmail"],
    VueEmailModal: _components_VueEmail__WEBPACK_IMPORTED_MODULE_34__["VueEmailModal"],
    ImageSelect: _components_ImageSelect__WEBPACK_IMPORTED_MODULE_33__["default"],
    AttachmentSelect: _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_41__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_36__["default"]],
  props: {
    reportName: {
      type: String,
      default: '',
      required: true
    },
    quoteIds: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      // PCK-213 - replaced by the API value in created(). Seeded with the fallback so the size
      // checks have a sane limit during the fetch rather than 0 or undefined.
      maxTotalAttachmentBytes: _services_emailLimits__WEBPACK_IMPORTED_MODULE_43__["FALLBACK_MAX_TOTAL_BYTES"],
      isSending: false,
      pdfBase64: '',
      pdfUrl: '',
      reportBytes: null,
      reportContentType: '',
      isExportModalActive: false,
      toolbarHeight: 0,
      isEmailModalActive: false,
      toEmails: [],
      ccEmails: [],
      bccEmails: [],
      emailer: null,
      isEnteringNewEmail: false,
      isNewBrowserTab: this.$route.query.isNewTab || false,
      isImageAttachActive: false,
      isDocAttachActive: false,
      selectedImageIds: [],
      selectedDocuments: [],
      // images: [],
      inputTagList: [],
      selectedImages: [],
      parameterId: this.$route.query.parameterId,
      parameters: null,
      cacheKey: '',
      allowedImageExtensions: ['.jpg', '.jpeg', '.png'],
      allowedDocumentExtensions: ['.pdf'],
      emailValidation: {
        canSend: true,
        isAttachmentSizeExceeded: false,
        totalSize: 0,
        errors: []
      }
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_4__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_42__["mapGetters"])({
    company: 'company/company'
  })), {}, {
    companyEnabledAutoCC: function companyEnabledAutoCC() {
      return this.company.setting ? this.company.setting.enabledAutoCC : false;
    },
    isAllowAutoCC: function isAllowAutoCC() {
      return this.companyEnabledAutoCC && this.$userInfo.email && !this.emailer.ccEmails.includes(this.$userInfo.email);
    },
    reportExtension: function reportExtension() {
      return mime_types__WEBPACK_IMPORTED_MODULE_38___default.a.extension(this.reportContentType);
    },
    enableSend: function enableSend() {
      return !this.isEnteringNewEmail && this.emailValidation.canSend;
    },
    enableAttach: function enableAttach() {
      return this.reportName === 'rptQuoteDollarHour' || this.reportName === 'rptQuoteDollarOnly' || this.reportName === 'rptQuoteDollarHourAdditionals' || this.reportName === 'rptQuoteDollarOnlyAdditionals' || this.reportName === 'rptPartsEnquiry' || this.reportName.startsWith('rptInvoice');
    },
    allAttachmentNames: function allAttachmentNames() {
      // Combine attachment names from attachments and customAttachments (avoid duplicates)
      var names = [];
      if (this.emailer && Array.isArray(this.emailer.attachments)) {
        var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.emailer.attachments),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var att = _step.value;
            if (typeof att === 'string') {
              names.push(att);
            } else if (att && att.fileName) {
              names.push(att.fileName);
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      if (this.emailer && Array.isArray(this.emailer.customAttachments)) {
        var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.emailer.customAttachments),
          _step2;
        try {
          for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
            var _att = _step2.value;
            if (_att && _att.fileName && !names.includes(_att.fileName)) {
              names.push(_att.fileName);
            }
          }
        } catch (err) {
          _iterator2.e(err);
        } finally {
          _iterator2.f();
        }
      }
      return names;
    },
    attachmentList: function attachmentList() {
      return Object(_components_VueEmail_attachmentSizes__WEBPACK_IMPORTED_MODULE_44__["buildAttachmentList"])(this.emailer, {
        reportName: this.emailer ? "".concat(this.emailer.reportName, ".").concat(this.reportExtension) : null,
        reportBytes: this.reportBytes
      });
    },
    totalAttachmentSize: function totalAttachmentSize() {
      return Object(_components_VueEmail_attachmentSizes__WEBPACK_IMPORTED_MODULE_44__["sumAttachmentSize"])(this.attachmentList);
    },
    isAttachmentSizeExceeded: function isAttachmentSizeExceeded() {
      return this.totalAttachmentSize > this.maxTotalAttachmentBytes;
    },
    combinedAttachments: function combinedAttachments() {
      return this.attachmentList;
    }
  }),
  watch: {
    $userInfo: function $userInfo(newVal, oldVal) {
      if (oldVal === null) {
        this.resetEmailer();
        // this.loadReport()
      }
    }
    // 'emailer.attachments': {
    //   handler: function (newVal, oldVal) {
    //     if (this.selectedImages.length > 0) {
    //       const difference = this.selectedImages.filter(function (image) {
    //         const index = newVal.findIndex((i) => {
    //           if (typeof i === 'string') {
    //             return i === image.fileName
    //           } else if (i && i.fileName) {
    //             return i.fileName === image.fileName
    //           }
    //           return false
    //         })
    //         return index === -1
    //       })
    //       if (!_isEmpty(difference)) {
    //         const imageIndex = this.selectedImages.findIndex((i) => i.fileName === difference[0].fileName)
    //         this.selectedImages.splice(imageIndex, 1)
    //         const idIndex = this.selectedImageIds.findIndex((id) => id === difference[0].quoteImageId)
    //         this.selectedImageIds.splice(idIndex, 1, Guid.empty())
    //       }
    //     }
    //   },
    //   deep: true
    // }
    // selectedImages: {
    //   handler: function (newVal, oldVal) {
    //     this.updateAttachmentList()
    //   },
    //   deep: true
    // },
    // selectedDocuments: {
    //   handler: function (newVal, oldVal) {
    //     this.updateAttachmentList()
    //   },
    //   deep: true
    // }
  },
  created: function created() {
    this.clearSessionStorage();
    this.checkCompanySetting();
    this.loadMaxAttachmentSize();
  },
  mounted: function mounted() {
    this.resetEmailer();
    this.loadReport();
  },
  methods: {
    loadMaxAttachmentSize: function loadMaxAttachmentSize() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return Object(_services_emailLimits__WEBPACK_IMPORTED_MODULE_43__["getMaxTotalAttachmentBytes"])();
            case 1:
              _this.maxTotalAttachmentBytes = _context.v;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    checkCompanySetting: function checkCompanySetting() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (_this2.company.setting) {
                _context2.n = 1;
                break;
              }
              _context2.n = 1;
              return _this2.$store.dispatch('company/getCompanySetting');
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case 'exportreport':
          this.showExportModal();
          break;
        case 'email':
          this.email();
          break;
        case 'print':
          this.print();
          break;
        case 'back':
          // this.removeEmailer(this.$route.query.emailerId)
          this.$router.go(-1);
          break;
      }
    },
    print: function print() {},
    email: function email() {
      if (this.$licenceExpired) return;
      this.isEmailModalActive = true;
    },
    exportReport: function exportReport(format) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$showSpinner();
              _this3.isExportModalActive = false;
              _context3.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].exportReportEx(_this3.$route.params.reportName, format, _this3.parameters);
            case 1:
              _this3.exportFormat = '';
              _this3.$hideSpinner();
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    showExportModal: function showExportModal(format) {
      this.isExportModalActive = true;
    },
    closeExportModal: function closeExportModal() {
      this.isExportModalActive = false;
    },
    loadReport: function loadReport() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var result, pdfBlob, mainNav, appHeader, pdfContainer, updatedEmailer, reportFileName, reportFileSize, existingReportIndex;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.$showSpinner();
              _this4.resetReportParameters();
              // console.log(this.parameters)
              // this.cacheKey = await PrintPreviewService.cacheParameters(this.parameters)
              // console.log(this.cacheKey)
              // const result = await PrintPreviewService.getReportDataEx(this.$route.params.reportName, ReportFormatTypes.pdf, this.cacheKey)
              _context4.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].postReportData(_this4.$route.params.reportName, _enums__WEBPACK_IMPORTED_MODULE_32__["ReportFormatTypes"].pdf, _this4.parameters);
            case 1:
              result = _context4.v;
              _this4.reportContentType = result.headers['content-type'].toLowerCase();
              pdfBlob = new Blob([result.data], {
                type: _this4.reportContentType
              });
              _this4.pdfUrl = URL.createObjectURL(pdfBlob);

              // Resize PDF viewer to fit
              mainNav = document.getElementById('main-nav-menu');
              appHeader = document.getElementById('app-detail-header');
              pdfContainer = document.getElementById('pdf-container');
              _this4.toolbarHeight = mainNav.offsetHeight + appHeader.offsetHeight;
              pdfContainer.style.height = window.innerHeight - mainNav.offsetHeight - appHeader.offsetHeight;
              //this.updateAttachmentList()
              updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(_this4.emailer);
              if (!updatedEmailer.customAttachments) {
                _this4.$set(updatedEmailer, 'customAttachments', []);
              }
              // Add report file if not already present
              reportFileName = "".concat(updatedEmailer.reportName, ".").concat(_this4.reportExtension);
              reportFileSize = (result.data || []).byteLength || 0;
              existingReportIndex = updatedEmailer.customAttachments.findIndex(function (att) {
                return att.fileName === reportFileName;
              });
              if (existingReportIndex === -1) {
                updatedEmailer.customAttachments.push({
                  fileName: reportFileName,
                  fileSize: reportFileSize,
                  fileBytes: result.data,
                  fileType: _this4.reportContentType
                });
              }

              // Update the emailer reference
              _this4.emailer = updatedEmailer;
              _this4.persistEmailer(); // Persist changes to session storage

              _this4.$hideSpinner();
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    sendEmail: function sendEmail() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _this5.$refs.emailer.send();
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    discardEmail: function discardEmail() {
      this.isEmailModalActive = false;
      this.isImageAttachActive = false;
      this.isDocAttachActive = false;
      this.selectedImageIds.splice(0, this.selectedImageIds.length);
      this.selectedImages.splice(0, this.selectedImages.length);
      this.resetEmailer();
    },
    attachMedia: function attachMedia() {},
    resetEmailer: function resetEmailer() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var sessionEmailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              sessionEmailer = _this6.retrieveEmailer() || _store_utils__WEBPACK_IMPORTED_MODULE_40__["default"].getLocalStorage(_this6.$route.query.emailerId, 'emailer'); // console.log(sessionEmailer)
              if (sessionEmailer) {
                _this6.emailer = sessionEmailer;
              } else {
                _this6.emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(_this6.getEmailer(_this6.$route.query.emailerId) || new _classes__WEBPACK_IMPORTED_MODULE_35__["Emailer"]());
              }
              _this6.emailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this6.$userInfo.companyName));
              _store_utils__WEBPACK_IMPORTED_MODULE_40__["default"].removeLocalStorage(_this6.$route.query.emailerId, 'emailer');
              _this6.persistEmailer();
              if (_this6.isAllowAutoCC) {
                _this6.emailer.ccEmails.push(_this6.$userInfo.email);
              }
              _this6.resetAttachement();
              //this.updateAttachmentList()
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    resetAttachement: function resetAttachement() {
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(this.emailer);
      if (updatedEmailer.quoteImageAttachments) {
        this.$set(updatedEmailer, 'quoteImageAttachments', []);
      }
      if (updatedEmailer.attachments) {
        this.$set(updatedEmailer, 'attachments', []);
      }
      //reset for customAttachments
      if (updatedEmailer.customAttachments) {
        this.$set(updatedEmailer, 'customAttachments', []);
      }
      //reset for quoteAttachments
      if (updatedEmailer.quoteAttachments) {
        this.$set(updatedEmailer, 'quoteAttachments', []);
      }
      this.emailer = updatedEmailer;
      this.persistEmailer();
      this.loadReport();
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(this.emailer));
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
    },
    sent: function sent() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        var remarkText, remark, quoteId, quoteRemark;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              if (!(_this7.emailer.assetId && _this7.emailer.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_39__["default"].empty())) {
                _context7.n = 2;
                break;
              }
              remarkText = "".concat(_this7.emailer.remark, " has been emailed to ").concat(_this7.emailer.toEmails.join(', '));
              remark = {
                remarkId: _components_Guid__WEBPACK_IMPORTED_MODULE_39__["default"].empty(),
                assetId: _this7.emailer.assetId,
                remarks: remarkText,
                remarkTypeId: _this7.emailer.remarkTypeId
              }; // console.log(remark)
              _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].postRemark(remark);
              if (!("".concat(_this7.emailer.subject).substring(0, 14) === 'Purchase Order')) {
                _context7.n = 2;
                break;
              }
              _context7.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].getQuote(_this7.emailer.assetId);
            case 1:
              quoteId = _context7.v;
              if (quoteId !== _components_Guid__WEBPACK_IMPORTED_MODULE_39__["default"].empty()) {
                quoteRemark = {
                  remarkId: _components_Guid__WEBPACK_IMPORTED_MODULE_39__["default"].empty(),
                  assetId: quoteId,
                  remarks: remarkText,
                  remarkTypeId: _this7.emailer.remarkTypeId
                };
                _PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].postRemark(quoteRemark);
              }
            case 2:
              _this7.discardEmail();
            case 3:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isEnteringNewEmail = newEmail;
    },
    handleValidationChanged: function handleValidationChanged(validation) {
      this.emailValidation = validation;
    },
    showAttachImage: function showAttachImage() {
      this.isImageAttachActive = true;
      this.isDocAttachActive = false;
      // Initialize selectedImages with current quoteImageAttachments if any
      this.selectedImages = this.emailer.quoteImageAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteImageAttachments) : [];
    },
    closeImageModal: function closeImageModal() {
      this.isImageAttachActive = false;
      // Reset selections if canceled - restore from emailer
      this.selectedImages = this.emailer.quoteImageAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteImageAttachments) : [];
    },
    confirmImageSelection: function confirmImageSelection() {
      // Create a deep clone of the emailer to avoid mutation issues
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(this.emailer);
      if (!updatedEmailer.quoteImageAttachments) {
        this.$set(updatedEmailer, 'quoteImageAttachments', []);
      }
      updatedEmailer.quoteImageAttachments = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.selectedImages);

      // Update the emailer reference
      this.emailer = updatedEmailer;
      this.isImageAttachActive = false;
      this.persistEmailer(); // Persist changes to session storage
    },
    onImagesSelected: function onImagesSelected(selectedImages) {
      this.selectedImages = selectedImages;
    },
    closeDocModal: function closeDocModal() {
      this.isDocAttachActive = false;
      // Reset selections if canceled - restore from emailer
      this.selectedDocuments = this.emailer.quoteAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteAttachments) : [];
    },
    confirmDocSelection: function confirmDocSelection() {
      // Create a deep clone of the emailer to avoid mutation issues
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(this.emailer);
      if (!updatedEmailer.quoteAttachments) {
        this.$set(updatedEmailer, 'quoteAttachments', []);
      }
      updatedEmailer.quoteAttachments = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.selectedDocuments);

      // Update the emailer reference
      this.emailer = updatedEmailer;
      this.isDocAttachActive = false;
      this.persistEmailer(); // Persist changes to session storage
    },
    onDocumentsSelected: function onDocumentsSelected(docs) {
      this.selectedDocuments = Array.isArray(docs) ? docs : [];
    },
    attachDocs: function attachDocs() {
      this.isDocAttachActive = true;
      this.isImageAttachActive = false;
      // Initialize selectedDocuments with current quoteAttachments if any
      this.selectedDocuments = this.emailer.quoteAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteAttachments) : [];
    },
    doneAttach: function doneAttach() {
      // Close both image and document selectors when "Done" is clicked
      if (this.isImageAttachActive) {
        this.confirmImageSelection();
      }
      if (this.isDocAttachActive) {
        this.confirmDocSelection();
      }
      this.isImageAttachActive = false;
      this.isDocAttachActive = false;
    },
    retrieveParameters: function retrieveParameters() {
      var json = sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
      return json ? JSON.parse(json) : '';
    },
    resetReportParameters: function resetReportParameters() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var sessionParameters;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              sessionParameters = _this8.retrieveParameters() || _store_utils__WEBPACK_IMPORTED_MODULE_40__["default"].getLocalStorage(_this8.$route.query.parameterId, _this8.$route.meta.pkey); // console.log('sessionParameters', sessionParameters)
              if (sessionParameters) {
                _this8.parameters = sessionParameters;
              } else {
                _this8.parameters = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(_this8.reportParameters);
              }
              // console.log(this.parameters, this.reportParameters)
              _store_utils__WEBPACK_IMPORTED_MODULE_40__["default"].removeLocalStorage(_this8.$route.query.parameterId, _this8.$route.meta.pkey);
              _this8.persistParameters();
            case 1:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    persistParameters: function persistParameters() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey), JSON.stringify(this.parameters));
    },
    onFileChange: function onFileChange(event) {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee9() {
        var files, _i, _files, file, arrayBuffer, fileObj;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              files = Array.from(event.target.files);
              _i = 0, _files = files;
            case 1:
              if (!(_i < _files.length)) {
                _context9.n = 4;
                break;
              }
              file = _files[_i];
              _context9.n = 2;
              return file.arrayBuffer();
            case 2:
              arrayBuffer = _context9.v;
              fileObj = {
                fileName: file.name,
                fileBytes: arrayBuffer,
                fileType: file.type
              };
              _this9.selectedImages.push(fileObj);
            case 3:
              _i++;
              _context9.n = 1;
              break;
            case 4:
              event.target.value = '';
            case 5:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    onAttachFiles: function onAttachFiles(files) {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee0() {
        var fileArray, maxSizeBytes, allowedExtensions, oversizedFiles, invalidTypeFiles, validFiles, _i2, _fileArray, file, fileName, fileExtension, fileSizeMB, fileList, allowedTypes, _fileList, _i3, _validFiles, _file, arrayBuffer, _fileSizeMB, fileObj;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              // Convert FileList or array-like to array
              fileArray = Array.from(files);
              if (!_this0.emailer.customAttachments) {
                _this0.$set(_this0.emailer, 'customAttachments', []);
              }

              // PCK-213 - a single file larger than the whole budget can never be sent, so this per-file
              // guard reuses the total cap instead of its own hardcoded 25MB.
              maxSizeBytes = _this0.maxTotalAttachmentBytes; // Define allowed file types
              allowedExtensions = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this0.allowedImageExtensions), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this0.allowedDocumentExtensions));
              oversizedFiles = [];
              invalidTypeFiles = [];
              validFiles = []; // Check file sizes and types
              _i2 = 0, _fileArray = fileArray;
            case 1:
              if (!(_i2 < _fileArray.length)) {
                _context0.n = 4;
                break;
              }
              file = _fileArray[_i2];
              fileName = file.name.toLowerCase();
              fileExtension = fileName.substring(fileName.lastIndexOf('.')); // Check file type
              if (allowedExtensions.includes(fileExtension)) {
                _context0.n = 2;
                break;
              }
              invalidTypeFiles.push(file.name);
              return _context0.a(3, 3);
            case 2:
              // Check file size
              if (file.size > maxSizeBytes) {
                fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
                oversizedFiles.push("".concat(file.name, " (").concat(fileSizeMB, "MB)"));
              } else {
                validFiles.push(file);
              }
            case 3:
              _i2++;
              _context0.n = 1;
              break;
            case 4:
              // Show error for invalid file types
              if (invalidTypeFiles.length > 0) {
                fileList = invalidTypeFiles.join(', ');
                allowedTypes = 'Images (jpg, jpeg, png) and Documents (pdf)';
                _this0.$notification.error('Invalid File Type', "The following files have unsupported file types and cannot be attached: ".concat(fileList, ". Only ").concat(allowedTypes, " are allowed."));
              }

              // Show error for oversized files
              if (oversizedFiles.length > 0) {
                _fileList = oversizedFiles.join(', ');
                _this0.$notification.error('File Size Error', "The following files exceed the ".concat(_this0.formatFileSize(maxSizeBytes), " size limit and cannot be attached: ").concat(_fileList));
              }

              // Process only valid files
              _i3 = 0, _validFiles = validFiles;
            case 5:
              if (!(_i3 < _validFiles.length)) {
                _context0.n = 8;
                break;
              }
              _file = _validFiles[_i3];
              _context0.n = 6;
              return _file.arrayBuffer();
            case 6:
              arrayBuffer = _context0.v;
              _fileSizeMB = (arrayBuffer.byteLength / (1024 * 1024)).toFixed(2);
              fileObj = {
                fileName: _file.name,
                fileBytes: arrayBuffer,
                fileType: _file.type,
                fileSize: arrayBuffer.byteLength,
                fileSizeMB: parseFloat(_fileSizeMB)
              }; // Add to customAttachments
              _this0.emailer.customAttachments.push(fileObj);
            case 7:
              _i3++;
              _context0.n = 5;
              break;
            case 8:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    formatFileSize: function formatFileSize(sizeInBytes) {
      if (!sizeInBytes || sizeInBytes === 0) {
        return '0 KB';
      }
      var units = ['Bytes', 'KB', 'MB', 'GB'];
      var size = sizeInBytes;
      var unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
      }
      return "".concat(size.toFixed(unitIndex === 0 ? 0 : 1), " ").concat(units[unitIndex]);
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.clearSessionStorage();
    this.removeEmailer(this.$route.query.emailerId);
    this.removeParameters(this.$route.query.parameterId);
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreviewAppDetailHeader',
  props: {
    title: {
      type: String,
      default: ''
    },
    showPrint: {
      type: Boolean,
      default: true
    },
    showEmail: {
      type: Boolean,
      default: true
    },
    showExport: {
      type: Boolean,
      default: true
    },
    showBack: {
      type: Boolean,
      default: true
    },
    showToggle: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      serviceError: false,
      access: {},
      showSideMenu: true
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
    buttonCSS: function buttonCSS() {
      return 'is-inverted';
    }
  }, Object(vuex__WEBPACK_IMPORTED_MODULE_8__["mapGetters"])(['licenceExpired'])),
  watch: {
    $route: function $route() {
      this.changeTitle();
    }
  },
  created: function created() {
    var _this = this;
    _components_EventBus__WEBPACK_IMPORTED_MODULE_7__["default"].$on('serviceError', function (data) {
      _this.handleBusEvent(data);
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AutoHideSideMenu, function (data) {
      _this.handleSideMenuEvent(data);
    });
  },
  mounted: function mounted() {
    if (this.$route && this.$route.meta && this.$route.meta.access) {
      this.access = this.$route.meta.access;
    }
    this.changeTitle();
  },
  methods: {
    print: function print() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AppDetailHeaderButtonClicked, 'print');
    },
    email: function email() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AppDetailHeaderButtonClicked, 'email');
    },
    exportreport: function exportreport() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AppDetailHeaderButtonClicked, 'exportreport');
    },
    back: function back() {
      this.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AppDetailHeaderButtonClicked, 'back');
    },
    toggleSide: function toggleSide() {
      this.showSideMenu = !this.showSideMenu;
      this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].ToggleSideMenu, this.showSideMenu);
    },
    handleBusEvent: function handleBusEvent(data) {
      this.serviceError = data === _components_http_status__WEBPACK_IMPORTED_MODULE_6__["default"].NOT_FOUND;
    },
    handleSideMenuEvent: function handleSideMenuEvent(data) {
      this.showSideMenu = !data;
    },
    changeTitle: function changeTitle() {
      var routes = this.$route.matched.slice();
      var title = '';
      routes.forEach(function (r, idx) {
        if (idx > 0) {
          title += ' ';
        }
        title += r.meta.title;
      });
      document.title = title; // parentRoute.meta.title
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreviewExportModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__["BaseModalEx"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    }
  },
  data: function data() {
    return {
      isActive: false,
      format: ''
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_3__["mapGetters"])(['licenceExpired'])), {}, {
    reportFormatTypes: function reportFormatTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_4__["ReportFormatTypes"];
    }
  }),
  watch: {
    active: function active(value) {
      this.isActive = value;
    }
  },
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    exportReport: function exportReport() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('exportReport', this.format);
    },
    close: function close() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./PrintPreviewAppDetailHeader */ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue");
/* harmony import */ var _PrintPreviewService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./PrintPreviewExportModal */ "./src/components/printpreview/PrintPreviewExportModal.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_ImageSelect__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/ImageSelect */ "./src/components/ImageSelect/index.js");
/* harmony import */ var _components_VueEmail__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/VueEmail */ "./src/components/VueEmail/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./storeMixin */ "./src/components/printpreview/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! mime-types */ "./node_modules/mime-types/index.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(mime_types__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34__);



































// import { isBrowser } from '@/components/utils/helpers'
// import Base64ArrayBuffer from '@/components/utils/Base64ArrayBuffer'

// Temporary const for copyright message
var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreviewOld',
  components: {
    PrintPreviewAppDetailHeader: _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_22__["default"],
    PrintPreviewExportModal: _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_24__["default"],
    VueEmail: _components_VueEmail__WEBPACK_IMPORTED_MODULE_27__["VueEmail"],
    VueEmailModal: _components_VueEmail__WEBPACK_IMPORTED_MODULE_27__["VueEmailModal"],
    ImageSelect: _components_ImageSelect__WEBPACK_IMPORTED_MODULE_26__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_29__["default"]],
  props: {
    reportName: {
      type: String,
      default: '',
      required: true
    }
  },
  data: function data() {
    return {
      isSending: false,
      pdfBase64: '',
      pdfUrl: '',
      reportBytes: null,
      reportContentType: '',
      isExportModalActive: false,
      toolbarHeight: 0,
      isEmailModalActive: false,
      toEmails: [],
      ccEmails: [],
      bccEmails: [],
      emailer: null,
      isEnteringNewEmail: false,
      isNewBrowserTab: this.$route.query.isNewTab || false,
      isImageAttachActive: false,
      selectedImageIds: [],
      // images: [],
      inputTagList: [],
      selectedImages: []
    };
  },
  computed: {
    reportExtension: function reportExtension() {
      return mime_types__WEBPACK_IMPORTED_MODULE_31___default.a.extension(this.reportContentType);
    },
    enableSend: function enableSend() {
      return this.emailer.toEmails.length > 0 && !this.isEnteringNewEmail;
    },
    enableAttach: function enableAttach() {
      return this.reportName === 'rptQuoteDollarHour' || this.reportName === 'rptQuoteDollarOnly' || this.reportName === 'rptQuoteDollarHourAdditionals' || this.reportName === 'rptQuoteDollarOnlyAdditionals';
    }
  },
  watch: {
    $userInfo: function $userInfo(newVal, oldVal) {
      console.log('watch $userInfo', oldVal);
      if (oldVal === null) {
        this.resetEmailer();
        // this.loadReport()
      }
    },
    'emailer.attachments': {
      handler: function handler(newVal, oldVal) {
        if (this.selectedImages.length > 0) {
          var difference = this.selectedImages.filter(function (image) {
            var index = newVal.findIndex(function (i) {
              return i === image.fileName;
            });
            return index === -1;
          });
          if (!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34___default()(difference)) {
            var imageIndex = this.selectedImages.findIndex(function (i) {
              return i.fileName === difference[0].fileName;
            });
            this.selectedImages.splice(imageIndex, 1);
            var idIndex = this.selectedImageIds.findIndex(function (id) {
              return id === difference[0].quoteImageId;
            });
            this.selectedImageIds.splice(idIndex, 1, _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty());
          }
        }
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {
    this.resetEmailer();
    this.loadReport();
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case 'exportreport':
          this.showExportModal();
          break;
        case 'email':
          this.email();
          break;
        case 'print':
          this.print();
          break;
        case 'back':
          // this.removeEmailer(this.$route.query.emailerId)
          this.$router.go(-1);
          break;
      }
    },
    print: function print() {},
    email: function email() {
      this.isEmailModalActive = true;
    },
    exportReport: function exportReport(format) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.$showSpinner();
              _this.isExportModalActive = false;
              _context.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_23__["default"].exportReport(_this.$route.params.reportName, format, _this.compressQuery());
            case 1:
              _this.exportFormat = '';
              _this.$hideSpinner();
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    showExportModal: function showExportModal(format) {
      this.isExportModalActive = true;
    },
    closeExportModal: function closeExportModal() {
      this.isExportModalActive = false;
    },
    loadReport: function loadReport() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var result, pdfBlob, mainNav, appHeader, pdfContainer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.$showSpinner();
              // if (isBrowser.chrome()) {
              //   // console.log('chrome')
              //   const result = await PrintPreviewService.getReportObject(this.$route.params.reportName, ReportFormatTypes.pdf, this.compressQuery())
              //   this.reportContentType = result.mimeType
              //   this.pdfBase64 = result.reportData
              //   this.reportBytes = Base64ArrayBuffer.decode(this.pdfBase64)
              // } else {
              _context2.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_23__["default"].getReportData(_this2.$route.params.reportName, _enums__WEBPACK_IMPORTED_MODULE_25__["ReportFormatTypes"].pdf, _this2.compressQuery());
            case 1:
              result = _context2.v;
              _this2.reportBytes = result.data;
              _this2.reportContentType = result.headers['content-type'].toLowerCase();
              // this.pdfBase64 = PrintPreviewService.convertToBase64(this.reportContentType, this.reportBytes)
              // }
              // const pdfDoc = document.getElementById('pdfDoc')
              // pdfDoc.data = URL.createObjectURL(pdfBlob)
              pdfBlob = new Blob([result.data], {
                type: _this2.reportContentType
              });
              _this2.pdfUrl = URL.createObjectURL(pdfBlob);

              // Resize PDF viewer to fit
              mainNav = document.getElementById('main-nav-menu');
              appHeader = document.getElementById('app-detail-header');
              pdfContainer = document.getElementById('pdf-container');
              _this2.toolbarHeight = mainNav.offsetHeight + appHeader.offsetHeight;
              pdfContainer.style.height = window.innerHeight - mainNav.offsetHeight - appHeader.offsetHeight;
              _this2.updateAttachmentList();
              _this2.$hideSpinner();
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    sendEmail: function sendEmail() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$refs.emailer.send();
              // this.discardEmail()
              // this.resetEmailer()
              // this.isEmailModalActive = false
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    discardEmail: function discardEmail() {
      this.isEmailModalActive = false;
      this.isImageAttachActive = false;
      this.selectedImageIds.splice(0, this.selectedImageIds.length);
      this.selectedImages.splice(0, this.selectedImages.length);
      this.resetEmailer();
    },
    attachMedia: function attachMedia() {},
    resetEmailer: function resetEmailer() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var sessionEmailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              sessionEmailer = _this4.retrieveEmailer() || _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].getLocalStorage(_this4.$route.query.emailerId, 'emailer'); // console.log(sessionEmailer)
              if (sessionEmailer) {
                _this4.emailer = sessionEmailer;
              } else {
                _this4.emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_30___default()(_this4.getEmailer(_this4.$route.query.emailerId) || new _classes__WEBPACK_IMPORTED_MODULE_28__["Emailer"]());
              }
              _this4.emailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this4.$userInfo.companyName));
              _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].removeLocalStorage(_this4.$route.query.emailerId, 'emailer');
              _this4.persistEmailer();
              _this4.updateAttachmentList();
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(this.emailer));
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
    },
    sent: function sent() {
      // 'sent' event from VueEmail component. Create email remark for asset e.g. QuickInvoice etc
      if (this.emailer.assetId && this.emailer.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty()) {
        var remarkText = "".concat(this.emailer.remark, " has been emailed to ").concat(this.emailer.toEmails.join(', '));
        var remark = {
          remarkId: _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty(),
          assetId: this.emailer.assetId,
          remarks: remarkText,
          remarkTypeId: this.emailer.remarkTypeId
        };
        // console.log(remark)
        _PrintPreviewService__WEBPACK_IMPORTED_MODULE_23__["default"].postRemark(remark);
      }
      this.discardEmail();
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isEnteringNewEmail = newEmail;
    },
    showAttachImage: function showAttachImage() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.isImageAttachActive = !_this5.isImageAttachActive;
              if (!_this5.isImageAttachActive) {
                _this5.updateAttachmentList();
              }
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    updateAttachmentList: function updateAttachmentList(imagesForSend) {
      this.emailer.attachments.splice(0, this.emailer.attachments.length);
      this.emailer.attachments.splice(this.emailer.attachments.length, 1, "".concat(this.emailer.reportName, ".").concat(this.reportExtension));
      for (var i = 0; i < this.selectedImages.length; i++) {
        this.emailer.attachments.splice(this.emailer.attachments.length, 1, this.selectedImages[i].fileName);
      }
    },
    compressQuery: function compressQuery() {
      return this.$route.query.query;
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.clearSessionStorage();
    this.removeEmailer(this.$route.query.emailerId);
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./PrintPreviewAppDetailHeader */ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue");
/* harmony import */ var _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./PrintPreviewExportModal */ "./src/components/printpreview/PrintPreviewExportModal.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_ImageSelect__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/ImageSelect */ "./src/components/ImageSelect/index.js");
/* harmony import */ var _components_VueEmail__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/VueEmail */ "./src/components/VueEmail/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./storeMixin */ "./src/components/printpreview/storeMixin.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! mime-types */ "./node_modules/mime-types/index.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(mime_types__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34__);




































// Temporary const for copyright message
var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreviewWithSideView',
  components: {
    PrintPreviewAppDetailHeader: _PrintPreviewAppDetailHeader__WEBPACK_IMPORTED_MODULE_24__["default"],
    PrintPreviewExportModal: _PrintPreviewExportModal__WEBPACK_IMPORTED_MODULE_26__["default"],
    VueEmail: _components_VueEmail__WEBPACK_IMPORTED_MODULE_29__["VueEmail"],
    VueEmailModal: _components_VueEmail__WEBPACK_IMPORTED_MODULE_29__["VueEmailModal"],
    ImageSelect: _components_ImageSelect__WEBPACK_IMPORTED_MODULE_28__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_30__["default"]],
  props: {
    reportName: {
      type: String,
      default: '',
      required: true
    },
    emailer: {
      type: [Object],
      required: true
    },
    parameters: {
      type: Array,
      required: true
    },
    parameterId: {
      type: String,
      default: '',
      required: true
    }
  },
  data: function data() {
    return {
      isSending: false,
      pdfBase64: '',
      reportBytes: null,
      reportContentType: '',
      isExportModalActive: false,
      pdfUrl: '',
      toolbarHeight: 0,
      isEmailModalActive: false,
      toEmails: [],
      ccEmails: [],
      bccEmails: [],
      isEnteringNewEmail: false,
      isNewBrowserTab: this.$route.query.isNewTab || false,
      isImageAttachActive: false,
      selectedImageIds: [],
      images: [],
      inputTagList: [],
      cacheKey: ''
    };
  },
  computed: {
    reportExtension: function reportExtension() {
      return mime_types__WEBPACK_IMPORTED_MODULE_31___default.a.extension(this.reportContentType);
    },
    enableSend: function enableSend() {
      return this.emailer.toEmails.length > 0 && !this.isEnteringNewEmail;
    },
    enableAttach: function enableAttach() {
      return this.reportName === 'rptQuoteDollarHour' || this.reportName === 'rptQuoteDollarOnly';
    }
  },
  watch: {
    reportName: {
      deep: true,
      handler: function handler() {
        this.loadReport();
      }
    },
    $userInfo: function $userInfo(newVal, oldVal) {
      console.log('watch $userInfo', oldVal);
      if (oldVal === null) {
        this.resetEmailer();
      }
    },
    'emailer.attachments': {
      handler: function handler(newVal, oldVal) {
        if (this.images.length > 0) {
          var difference = this.images.filter(function (image) {
            var index = newVal.findIndex(function (i) {
              return i === image.fileName;
            });
            return index === -1;
          });
          if (!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_34___default()(difference)) {
            var imageIndex = this.images.findIndex(function (i) {
              return i.fileName === difference[0].fileName;
            });
            this.images.splice(imageIndex, 1);
            var idIndex = this.selectedImageIds.findIndex(function (id) {
              return id === difference[0].quoteImageId;
            });
            this.selectedImageIds.splice(idIndex, 1, _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty());
          }
        }
      },
      deep: true
    },
    selectedImageIds: {
      handler: function handler(newVal, oldVal) {
        // console.log(newVal)
        // this.updateAttachmentList(newVal)
      }
    }
  },
  created: function created() {},
  mounted: function mounted() {
    this.resetEmailer();
    this.loadReport();
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case 'exportreport':
          this.showExportModal();
          break;
        case 'email':
          this.email();
          break;
        case 'print':
          //this.print()
          break;
        case 'back':
          this.$router.go(-1);
          break;
      }
    },
    email: function email() {
      this.isEmailModalActive = true;
    },
    exportReport: function exportReport(format) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.$showSpinner();
              _this.isExportModalActive = false;
              _context.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__["default"].exportReportEx(_this.reportName, format, _this.parameters);
            case 1:
              _this.exportFormat = '';
              _this.$hideSpinner();
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    showExportModal: function showExportModal(format) {
      this.isExportModalActive = true;
    },
    closeExportModal: function closeExportModal() {
      this.isExportModalActive = false;
    },
    loadReport: function loadReport() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var result, pdfBlob, mainNav, appHeader, pdfContainer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.$showSpinner();
              _this2.resetReportParameters();
              //console.log(this.parameters)
              _context2.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__["default"].cacheParameters(_this2.parameters);
            case 1:
              _this2.cacheKey = _context2.v;
              _context2.n = 2;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__["default"].postReportData(_this2.reportName, _enums__WEBPACK_IMPORTED_MODULE_27__["ReportFormatTypes"].pdf, _this2.parameters);
            case 2:
              result = _context2.v;
              _this2.reportBytes = result.data;
              _this2.reportContentType = result.headers['content-type'].toLowerCase();
              pdfBlob = new Blob([result.data], {
                type: _this2.reportContentType
              });
              _this2.pdfUrl = URL.createObjectURL(pdfBlob);
              // Resize PDF viewer to fit
              mainNav = document.getElementById('main-nav-menu');
              appHeader = document.getElementById('app-detail-header');
              pdfContainer = document.getElementById('pdf-container');
              _this2.toolbarHeight = mainNav.offsetHeight + appHeader.offsetHeight;
              pdfContainer.style.height = window.innerHeight - mainNav.offsetHeight - appHeader.offsetHeight;
              _this2.updateAttachmentList();
              _this2.$hideSpinner();
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    sendEmail: function sendEmail() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _this3.$refs.emailer.send();
            case 1:
              _this3.resetEmailer();
              _this3.isEmailModalActive = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    discardEmail: function discardEmail() {
      this.isEmailModalActive = false;
      this.isImageAttachActive = false;
      this.selectedImageIds.splice(0, this.selectedImageIds.length);
      this.images.splice(0, this.images.length);
      this.resetEmailer();
    },
    attachMedia: function attachMedia() {},
    resetEmailer: function resetEmailer() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.emailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this4.$userInfo.companyName));
              _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].removeLocalStorage(_this4.$route.query.emailerId, 'emailer');
              _this4.persistEmailer();
              _this4.updateAttachmentList();
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(this.emailer));
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
    },
    sent: function sent() {
      // 'sent' event from VueEmail component. Create email remark for asset e.g. QuickInvoice etc
      if (this.emailer.assetId && this.emailer.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty()) {
        var remarkText = "".concat(this.emailer.remark, " has been emailed to ").concat(this.emailer.toEmails.join(', '));
        var remark = {
          remarkId: _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty(),
          assetId: this.emailer.assetId,
          remarks: remarkText,
          remarkTypeId: this.emailer.remarkTypeId
        };
        // console.log(remark)
        _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__["default"].postRemark(remark);
      }
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isEnteringNewEmail = newEmail;
    },
    showAttachImage: function showAttachImage() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var vm, promises;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this5.isImageAttachActive = !_this5.isImageAttachActive;
              if (_this5.isImageAttachActive) {
                _context6.n = 2;
                break;
              }
              vm = _this5;
              _this5.images = new Array(_this5.selectedImageIds.filter(function (id) {
                return id !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
              }).length);
              promises = _this5.selectedImageIds.filter(function (id) {
                return id !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
              }).map(/*#__PURE__*/function () {
                var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5(id, index) {
                  var image;
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
                    while (1) switch (_context5.n) {
                      case 0:
                        _context5.n = 1;
                        return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_25__["default"].getImageDetail(id);
                      case 1:
                        image = _context5.v;
                        vm.images.splice(index, 1, image);
                      case 2:
                        return _context5.a(2);
                    }
                  }, _callee5);
                }));
                return function (_x, _x2) {
                  return _ref.apply(this, arguments);
                };
              }());
              _context6.n = 1;
              return Promise.all(promises);
            case 1:
              _this5.updateAttachmentList();
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    updateAttachmentList: function updateAttachmentList(imagesForSend) {
      this.emailer.attachments.splice(0, this.emailer.attachments.length);
      this.emailer.attachments.splice(this.emailer.attachments.length, 1, "".concat(this.emailer.reportName, ".").concat(this.reportExtension));
      for (var i = 0; i < this.images.length; i++) {
        this.emailer.attachments.splice(this.emailer.attachments.length, 1, this.images[i].fileName);
      }
    },
    retrieveParameters: function retrieveParameters() {
      var json = sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
      return json ? JSON.parse(json) : '';
    },
    resetReportParameters: function resetReportParameters() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].removeLocalStorage(_this6.parameterId, _this6.$route.meta.pkey);
              _this6.persistParameters();
            case 1:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    persistParameters: function persistParameters() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey), JSON.stringify(this.parameters));
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.clearSessionStorage();
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _PrintPreviewService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./storeMixin */ "./src/components/printpreview/storeMixin.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PrintPreviewWithoutHeader',
  components: {},
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_16__["default"]],
  props: {
    reportName: {
      type: String,
      default: '',
      required: true
    },
    parameters: {
      type: Array,
      required: true
    },
    parameterId: {
      type: String,
      default: '',
      required: true
    }
  },
  data: function data() {
    return {
      pdfBase64: '',
      pdfUrl: '',
      reportBytes: null,
      reportContentType: '',
      toolbarHeight: 0
    };
  },
  computed: {},
  watch: {},
  created: function created() {},
  mounted: function mounted() {
    this.loadReport();
  },
  methods: {
    loadReport: function loadReport() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var result, pdfBlob;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.$showSpinner();
              _this.resetReportParameters();
              _context.n = 1;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_14__["default"].cacheParameters(_this.parameters);
            case 1:
              _this.cacheKey = _context.v;
              _context.n = 2;
              return _PrintPreviewService__WEBPACK_IMPORTED_MODULE_14__["default"].postReportData(_this.reportName, _enums__WEBPACK_IMPORTED_MODULE_15__["ReportFormatTypes"].pdf, _this.parameters);
            case 2:
              result = _context.v;
              if (result && result.status === _components_http_status__WEBPACK_IMPORTED_MODULE_17__["default"].OK) {
                _this.$emit('loadFinish');
              }
              _this.reportBytes = result.data;
              _this.reportContentType = result.headers['content-type'].toLowerCase();
              pdfBlob = new Blob([result.data], {
                type: _this.reportContentType
              });
              _this.pdfUrl = URL.createObjectURL(pdfBlob);
              // Resize PDF viewer to fit
              //const mainNav = document.getElementById('main-nav-menu')
              //const appHeader = document.getElementById('app-detail-header')
              //const pdfContainer = document.getElementById('pdf-container')
              //this.toolbarHeight = mainNav.offsetHeight + appHeader.offsetHeight
              //pdfContainer.style.height = window.innerHeight - mainNav.offsetHeight - appHeader.offsetHeight
              //this.updateAttachmentList()
              _this.$hideSpinner();
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    resetReportParameters: function resetReportParameters() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _store_utils__WEBPACK_IMPORTED_MODULE_13__["default"].removeLocalStorage(_this2.parameterId, _this2.$route.meta.pkey);
              _this2.persistParameters();
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    persistParameters: function persistParameters() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey), JSON.stringify(this.parameters));
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("print-preview-app-detail-header", {
    attrs: {
      "show-toggle": false,
      "show-print": false,
      "show-back": !_vm.isNewBrowserTab
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    style: "height: calc(100vh - ".concat(_vm.toolbarHeight, "px); overflow: hidden;"),
    attrs: {
      id: "pdf-container",
      name: "pdf-container"
    }
  }, [_c("object", {
    staticClass: "pdf-document",
    attrs: {
      id: "pdfDoc",
      data: _vm.pdfUrl,
      type: "application/pdf"
    }
  }, [_c("embed", {
    staticClass: "pdf-document",
    attrs: {
      src: _vm.pdfUrl,
      type: "application/pdf"
    }
  })])]), _vm.isExportModalActive ? _c("print-preview-export-modal", {
    attrs: {
      active: _vm.isExportModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isExportModalActive = $event;
      },
      exportReport: _vm.exportReport,
      close: _vm.closeExportModal
    }
  }) : _vm._e(), _vm.isEmailModalActive ? _c("vue-email-modal", {
    attrs: {
      active: _vm.isEmailModalActive,
      "icon-name": "mdi-email-open",
      "icon-type": "primary",
      "enable-send": _vm.enableSend && !_vm.isImageAttachActive && !_vm.isDocAttachActive,
      "is-sending": _vm.isSending,
      "enable-attach": _vm.enableAttach,
      "toggle-attach-button": _vm.isImageAttachActive || _vm.isDocAttachActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEmailModalActive = $event;
      },
      send: _vm.sendEmail,
      discard: _vm.discardEmail,
      attach: _vm.attachMedia,
      "show-attach": _vm.showAttachImage,
      "attach-docs": _vm.attachDocs,
      "attach-files": _vm.onAttachFiles,
      "done-attach": _vm.doneAttach
    }
  }, [_c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.isEmailModalActive && !_vm.isImageAttachActive && !_vm.isDocAttachActive ? _c("vue-email", {
    ref: "emailer",
    attrs: {
      "report-bytes": _vm.reportBytes,
      "report-name": "".concat(_vm.emailer.reportName, ".").concat(_vm.reportExtension),
      "report-content-type": _vm.reportContentType,
      "quote-image-attachments": _vm.selectedImages,
      "quote-attachments": _vm.selectedDocuments,
      "asset-id": _vm.emailer.assetId
    },
    on: {
      "new-email": _vm.newEmailInput,
      sent: _vm.sent,
      "validation-changed": _vm.handleValidationChanged,
      "sending-changed": function sendingChanged($event) {
        _vm.isSending = $event;
      }
    },
    model: {
      value: _vm.emailer,
      callback: function callback($$v) {
        _vm.emailer = $$v;
      },
      expression: "emailer"
    }
  }) : _vm._e(), _vm.emailer && _vm.isImageAttachActive ? _c("image-select", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isImageAttachActive,
      expression: "isImageAttachActive"
    }],
    attrs: {
      "image-select-with-details": true,
      "quote-id": _vm.emailer.assetId,
      "quote-ids": _vm.quoteIds
    },
    on: {
      input: _vm.onImagesSelected
    },
    model: {
      value: _vm.selectedImages,
      callback: function callback($$v) {
        _vm.selectedImages = $$v;
      },
      expression: "selectedImages"
    }
  }) : _vm._e(), _vm.emailer && _vm.isDocAttachActive ? _c("attachment-select", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isDocAttachActive,
      expression: "isDocAttachActive"
    }],
    attrs: {
      "quote-id": _vm.emailer.assetId
    },
    on: {
      input: _vm.onDocumentsSelected
    },
    model: {
      value: _vm.selectedDocuments,
      callback: function callback($$v) {
        _vm.selectedDocuments = $$v;
      },
      expression: "selectedDocuments"
    }
  }) : _vm._e()], 1)]) : _vm._e(), _vm.isEmailModalActive && _vm.emailValidation.isAttachmentSizeExceeded ? _c("div", {
    staticClass: "notification is-danger is-light mt-2"
  }, [_vm._m(0), _c("span", [_vm._v(_vm._s(_vm.emailValidation.errors.join(" ")))])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-alert"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("section", {
    staticClass: "hero is-primary hero-header",
    class: "has-hero-text-".concat(_vm.$theme.name)
  }, [_c("div", {
    staticClass: "hero-body paddingless"
  }, [_c("nav", {
    staticClass: "navbar",
    attrs: {
      id: "app-detail-header"
    }
  }, [_c("div", {
    staticClass: "navbar-brand"
  }, [_c("div", {
    staticClass: "navbar-item is-hidden-desktop"
  }, [_c("div", {
    staticClass: "field is-grouped"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button tooltip is-tooltip is-tooltip-topleft is-primary",
    class: _vm.buttonCSS,
    attrs: {
      id: "toggle",
      title: "Toggle Side Menu",
      "data-tooltip": "Toggle Side Menu"
    },
    on: {
      click: _vm.toggleSide
    }
  }, [_vm._m(0)])]), !_vm.serviceError && _vm.showExport ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button tooltip is-tooltip-topleft is-success",
    class: _vm.buttonCSS,
    attrs: {
      id: "export",
      title: "Export",
      "data-tooltip": "Export"
    },
    on: {
      click: _vm.exportreport
    }
  }, [_vm._m(1)])]) : _vm._e(), !_vm.serviceError && _vm.showEmail ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button tooltip is-tooltip-topleft is-primary",
    class: _vm.buttonCSS,
    attrs: {
      id: "email",
      disabled: _vm.licenceExpired,
      "data-tooltip": _vm.licenceExpired ? "Disabled, as your licence has expired" : "Email"
    },
    on: {
      click: function click($event) {
        !_vm.licenceExpired && _vm.email();
      }
    }
  }, [_vm._m(2)])]) : _vm._e(), !_vm.serviceError && _vm.showPrint ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button tooltip is-tooltip-topleft",
    class: _vm.buttonCSS,
    attrs: {
      id: "print",
      title: "Print",
      "data-tooltip": "Print"
    },
    on: {
      click: _vm.print
    }
  }, [_vm._m(3)])]) : _vm._e()])]), _vm._m(4)]), _c("div", {
    staticClass: "navbar-start is-hidden-touch",
    attrs: {
      id: "detail-nav-menu"
    }
  }, [_c("div", {
    staticClass: "navbar-item"
  }, [_c("h1", {
    staticClass: "title has-text-weight-semibold"
  }, [_vm.showToggle ? _c("a", {
    staticClass: "button is-primary is-outlined",
    class: _vm.buttonCSS,
    on: {
      click: _vm.toggleSide
    }
  }, [_vm._m(5)]) : _vm._e(), _vm._l(_vm.$route.matched.slice(), function (route, idx) {
    return _c("span", {
      key: idx
    }, [idx > 0 ? _c("span", [_vm._m(6, true)]) : _vm._e(), _c("span", [_vm._v(" " + _vm._s(route.meta.title) + " ")])]);
  })], 2)])]), _c("div", {
    staticClass: "navbar-end is-hidden-touch"
  }, [_c("div", {
    staticClass: "navbar-item"
  }, [_c("div", {
    staticClass: "field is-grouped"
  }, [!_vm.serviceError && _vm.showExport ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-success",
    class: _vm.buttonCSS,
    attrs: {
      id: "export"
    },
    on: {
      click: _vm.exportreport
    }
  }, [_vm._m(7), _c("span", [_vm._v("Export")])])]) : _vm._e(), !_vm.serviceError && _vm.showEmail ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary",
    class: [_vm.buttonCSS, {
      "tooltip is-tooltip-bottom": _vm.licenceExpired
    }],
    attrs: {
      id: "email",
      disabled: _vm.licenceExpired,
      "data-tooltip": _vm.licenceExpired ? "Disabled, as your licence has expired" : null
    },
    on: {
      click: function click($event) {
        !_vm.licenceExpired && _vm.email();
      }
    }
  }, [_vm._m(8), _c("span", [_vm._v("Email")])])]) : _vm._e(), !_vm.serviceError && _vm.showPrint ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button",
    class: _vm.buttonCSS,
    attrs: {
      id: "print"
    },
    on: {
      click: _vm.print
    }
  }, [_vm._m(9), _c("span", [_vm._v("Print")])])]) : _vm._e(), _vm.showBack ? _c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary",
    class: _vm.buttonCSS,
    attrs: {
      id: "back"
    },
    on: {
      click: _vm.back
    }
  }, [_vm._m(10), _c("span", [_vm._v("Back")])])]) : _vm._e()])])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-menu"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-export"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-email"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-printer"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "navbar-burger burger",
    attrs: {
      "data-target": "action-button-menu"
    }
  }, [_c("span"), _c("span"), _c("span")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-menu mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-chevron-right"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-export mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-email mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-printer mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-arrow-left-bold mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 40,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _vm._v(" Export Report ")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("span", [_vm._v("Select export format")])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.format,
      expression: "format"
    }],
    staticClass: "is-checkradio",
    attrs: {
      id: _vm.reportFormatTypes.excel,
      type: "radio",
      name: _vm.reportFormatTypes.excel
    },
    domProps: {
      value: _vm.reportFormatTypes.excel,
      checked: _vm._q(_vm.format, _vm.reportFormatTypes.excel)
    },
    on: {
      change: function change($event) {
        _vm.format = _vm.reportFormatTypes.excel;
      }
    }
  }), _c("label", {
    attrs: {
      for: _vm.reportFormatTypes.excel
    }
  }, [_vm._v("Microsoft Excel")])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.format,
      expression: "format"
    }],
    staticClass: "is-checkradio",
    attrs: {
      id: _vm.reportFormatTypes.word,
      type: "radio",
      name: _vm.reportFormatTypes.word
    },
    domProps: {
      value: _vm.reportFormatTypes.word,
      checked: _vm._q(_vm.format, _vm.reportFormatTypes.word)
    },
    on: {
      change: function change($event) {
        _vm.format = _vm.reportFormatTypes.word;
      }
    }
  }), _c("label", {
    attrs: {
      for: _vm.reportFormatTypes.word
    }
  }, [_vm._v("Microsoft Word")])])])]), _c("footer", {
    staticClass: "modal-card-foot",
    style: "justify-content: flex-".concat(_vm.buttonLocation)
  }, [_c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Start export",
      disabled: !_vm.format
    },
    on: {
      click: function click($event) {
        return _vm.exportReport();
      }
    }
  }, [_vm._v("Export")]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.close();
      }
    }
  }, [_vm._v("Close")])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("print-preview-app-detail-header", {
    attrs: {
      "show-toggle": false,
      "show-print": false,
      "show-back": !_vm.isNewBrowserTab
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    style: "height: calc(100vh - ".concat(_vm.toolbarHeight, "px); overflow: hidden;"),
    attrs: {
      id: "pdf-container",
      name: "pdf-container"
    }
  }, [_c("object", {
    staticClass: "pdf-document",
    attrs: {
      id: "pdfDoc",
      data: _vm.pdfUrl,
      type: "application/pdf"
    }
  }, [_c("embed", {
    staticClass: "pdf-document",
    attrs: {
      src: _vm.pdfUrl,
      type: "application/pdf"
    }
  })])]), _vm.isExportModalActive ? _c("print-preview-export-modal", {
    attrs: {
      active: _vm.isExportModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isExportModalActive = $event;
      },
      exportReport: _vm.exportReport,
      close: _vm.closeExportModal
    }
  }) : _vm._e(), _vm.isEmailModalActive ? _c("vue-email-modal", {
    attrs: {
      active: _vm.isEmailModalActive,
      "icon-name": "mdi-email-open",
      "icon-type": "primary",
      "enable-send": _vm.enableSend && !_vm.isImageAttachActive,
      "is-sending": _vm.isSending,
      "enable-attach": _vm.enableAttach,
      "toggle-attach-button": _vm.isImageAttachActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEmailModalActive = $event;
      },
      send: _vm.sendEmail,
      discard: _vm.discardEmail,
      attach: _vm.attachMedia,
      "show-attach": _vm.showAttachImage
    }
  }, [_c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.isEmailModalActive ? _c("vue-email", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isImageAttachActive,
      expression: "!isImageAttachActive"
    }],
    ref: "emailer",
    attrs: {
      "report-bytes": _vm.reportBytes,
      "report-name": "".concat(_vm.emailer.reportName, ".").concat(_vm.reportExtension),
      "report-content-type": _vm.reportContentType,
      "quote-image-attachments": _vm.selectedImages
    },
    on: {
      "new-email": _vm.newEmailInput,
      sent: _vm.sent,
      "sending-changed": function sendingChanged($event) {
        _vm.isSending = $event;
      }
    },
    model: {
      value: _vm.emailer,
      callback: function callback($$v) {
        _vm.emailer = $$v;
      },
      expression: "emailer"
    }
  }) : _vm._e(), _vm.emailer && _vm.isImageAttachActive ? _c("image-select", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isImageAttachActive,
      expression: "isImageAttachActive"
    }],
    attrs: {
      "quote-id": _vm.emailer.assetId
    },
    model: {
      value: _vm.selectedImages,
      callback: function callback($$v) {
        _vm.selectedImages = $$v;
      },
      expression: "selectedImages"
    }
  }) : _vm._e()], 1)]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651 ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("print-preview-app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-print": false,
      "show-back": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm._t("side-bar")], 2), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    style: "height: calc(93vh - ".concat(_vm.toolbarHeight, "px); overflow: hidden;"),
    attrs: {
      id: "pdf-container",
      name: "pdf-container"
    }
  }, [_c("object", {
    staticStyle: {
      width: "100%",
      height: "100%"
    },
    attrs: {
      id: "pdfDoc",
      data: _vm.pdfUrl,
      type: "application/pdf"
    }
  })])])])])]), _vm.isExportModalActive ? _c("print-preview-export-modal", {
    attrs: {
      active: _vm.isExportModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isExportModalActive = $event;
      },
      exportReport: _vm.exportReport,
      close: _vm.closeExportModal
    }
  }) : _vm._e(), _vm.isEmailModalActive ? _c("vue-email-modal", {
    attrs: {
      active: _vm.isEmailModalActive,
      "icon-name": "mdi-email-open",
      "icon-type": "primary",
      "enable-send": _vm.enableSend && !_vm.isImageAttachActive,
      "is-sending": _vm.isSending,
      "enable-attach": _vm.enableAttach,
      "toggle-attach-button": _vm.isImageAttachActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEmailModalActive = $event;
      },
      send: _vm.sendEmail,
      discard: _vm.discardEmail,
      attach: _vm.attachMedia,
      "show-attach": _vm.showAttachImage
    }
  }, [_c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.isEmailModalActive ? _c("vue-email", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isImageAttachActive,
      expression: "!isImageAttachActive"
    }],
    ref: "emailer",
    attrs: {
      "report-bytes": _vm.reportBytes,
      "report-name": "".concat(_vm.emailer.reportName, ".").concat(_vm.reportExtension),
      "report-content-type": _vm.reportContentType,
      "quote-image-attachments": _vm.images,
      "asset-id": _vm.emailer.assetId
    },
    on: {
      "new-email": _vm.newEmailInput,
      sent: _vm.sent,
      "sending-changed": function sendingChanged($event) {
        _vm.isSending = $event;
      }
    },
    model: {
      value: _vm.emailer,
      callback: function callback($$v) {
        _vm.emailer = $$v;
      },
      expression: "emailer"
    }
  }) : _vm._e(), _vm.emailer && _vm.isImageAttachActive ? _c("image-select", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isImageAttachActive,
      expression: "isImageAttachActive"
    }],
    attrs: {
      "quote-id": _vm.emailer.assetId
    },
    model: {
      value: _vm.selectedImageIds,
      callback: function callback($$v) {
        _vm.selectedImageIds = $$v;
      },
      expression: "selectedImageIds"
    }
  }) : _vm._e()], 1)]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    style: "height: calc(93vh - ".concat(_vm.toolbarHeight, "px); overflow: hidden;"),
    attrs: {
      id: "pdf-container",
      name: "pdf-container"
    }
  }, [_c("object", {
    staticClass: "pdf-document",
    staticStyle: {
      width: "100%",
      height: "100%"
    },
    attrs: {
      id: "pdfDoc",
      data: _vm.pdfUrl,
      type: "application/pdf"
    }
  }, [_c("embed", {
    staticClass: "pdf-document",
    attrs: {
      src: _vm.pdfUrl,
      type: "application/pdf"
    }
  })])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "object.pdf-document[data-v-a67e53a2],\nembeb.pdf-document[data-v-a67e53a2] {\n  width: 100% !important;\n  height: 100% !important;\n}\n.attachment-status[data-v-a67e53a2] {\n  margin-top: 1rem;\n  padding: 1rem;\n  background-color: #f9f9f9;\n  border-radius: 4px;\n  border: 1px solid #e1e1e1;\n  /* Dark theme overrides */\n}\n.attachment-status .file-size-text[data-v-a67e53a2] {\n  color: #6b7280;\n  font-size: 0.85em;\n}\n.attachment-status .progress-container .progress[data-v-a67e53a2] {\n  height: 8px;\n  border-radius: 4px;\n}\n.attachment-status .progress-container .progress.is-danger[data-v-a67e53a2]::-webkit-progress-bar {\n  background-color: #f14668;\n}\n.attachment-status .progress-container .progress.is-success[data-v-a67e53a2]::-webkit-progress-bar {\n  background-color: #48c774;\n}\n.attachment-status .tag.is-small.is-light[data-v-a67e53a2] {\n  margin-right: 0.25rem;\n  margin-bottom: 0.25rem;\n  /* Dark theme support */\n  --bulma-tag-background-color: var(--bulma-scheme-main-bis, #fafafa);\n  --bulma-tag-color: var(--bulma-text, #4a4a4a);\n  background-color: var(--bulma-tag-background-color);\n  color: var(--bulma-tag-color);\n}\n@media (prefers-color-scheme: dark) {\n.attachment-status[data-v-a67e53a2] {\n    background-color: #2f2f2f;\n    border-color: #4a4a4a;\n}\n.attachment-status .file-size-text[data-v-a67e53a2] {\n    color: #9ca3af;\n}\n.attachment-status .tag.is-small.is-light[data-v-a67e53a2] {\n    --bulma-tag-background-color: var(--bulma-scheme-main-ter, #363636);\n    --bulma-tag-color: var(--bulma-text-invert, #ffffff);\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "object.pdf-document[data-v-3c332e28],\nembeb.pdf-document[data-v-3c332e28] {\n  width: 100% !important;\n  height: 100% !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("1bb4f7aa", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2b98051c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VueEmail/attachmentSizes.js":
/*!****************************************************!*\
  !*** ./src/components/VueEmail/attachmentSizes.js ***!
  \****************************************************/
/*! exports provided: buildAttachmentList, sumAttachmentSize, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buildAttachmentList", function() { return buildAttachmentList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sumAttachmentSize", function() { return sumAttachmentSize; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








/**
 * PCK-213 - one attachment size calculation for every sender.
 *
 * VueEmail and PrintPreview each had their own pair of totalAttachmentSize/combinedAttachments
 * computeds over the same emailer, with rules that had drifted: one deduped by filename and the
 * other did not, one counted the report from reportBytes unconditionally while the other matched
 * it by name, and the customAttachments chains differed. They could disagree about the same email.
 *
 * sizeOf returns null when a size cannot be established, rather than 0. Counting an unknown as
 * zero is what let an oversized send show a green meter.
 */

var nameOf = function nameOf(item) {
  return item && (item.fileName || item.filename || item.name) || null;
};
var sizeOf = function sizeOf(item) {
  if (!item) return null;
  if (item.fileBytes && typeof item.fileBytes.byteLength === 'number') return item.fileBytes.byteLength;
  if (typeof item.originalFileSize === 'number') return item.originalFileSize;
  if (typeof item.fileSize === 'number') return item.fileSize;
  return null;
};
function buildAttachmentList(emailer) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$reportName = _ref.reportName,
    reportName = _ref$reportName === void 0 ? null : _ref$reportName,
    _ref$reportBytes = _ref.reportBytes,
    reportBytes = _ref$reportBytes === void 0 ? null : _ref$reportBytes;
  var list = [];
  var seen = [];
  var add = function add(fileName, fileSize) {
    if (!fileName || seen.includes(fileName)) return;
    seen.push(fileName);
    list.push({
      fileName: fileName,
      fileSize: fileSize
    });
  };
  if (!emailer) return list;
  var reportSize = reportBytes ? reportBytes.byteLength || reportBytes.length || null : null;

  // `attachments` holds bare filename strings for senders that attach a generated report.
  // send()/sendExport() identify it with attachments.indexOf(reportName), so the same match
  // gives us its size. Other strings carry no size and stay null.
  if (Array.isArray(emailer.attachments)) {
    var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(emailer.attachments),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var att = _step.value;
        if (typeof att === 'string') add(att, att === reportName ? reportSize : null);else add(nameOf(att), sizeOf(att));
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  for (var _i = 0, _arr = ['customAttachments', 'quoteAttachments', 'quoteImageAttachments']; _i < _arr.length; _i++) {
    var key = _arr[_i];
    if (Array.isArray(emailer[key])) {
      var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(emailer[key]),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var item = _step2.value;
          add(nameOf(item), sizeOf(item));
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }
  return list;
}
function sumAttachmentSize(list) {
  return (list || []).reduce(function (total, item) {
    return total + (item.fileSize || 0);
  }, 0);
}
/* harmony default export */ __webpack_exports__["default"] = ({
  buildAttachmentList: buildAttachmentList,
  sumAttachmentSize: sumAttachmentSize
});

/***/ }),

/***/ "./src/components/printpreview/PrintPreview.vue":
/*!******************************************************!*\
  !*** ./src/components/printpreview/PrintPreview.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true */ "./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true");
/* harmony import */ var _PrintPreview_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreview.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true */ "./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PrintPreview_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "a67e53a2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreview.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js":
/*!******************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreview.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=style&index=0&id=a67e53a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_style_index_0_id_a67e53a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true":
/*!************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreview.vue?vue&type=template&id=a67e53a2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreview_vue_vue_type_template_id_a67e53a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue":
/*!*********************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewAppDetailHeader.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true */ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true");
/* harmony import */ var _PrintPreviewAppDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PrintPreviewAppDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "b36eed00",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreviewAppDetailHeader.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js":
/*!*********************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewAppDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewAppDetailHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true ***!
  \***************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewAppDetailHeader.vue?vue&type=template&id=b36eed00&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewAppDetailHeader_vue_vue_type_template_id_b36eed00_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/PrintPreviewExportModal.vue":
/*!*****************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewExportModal.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a */ "./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a");
/* harmony import */ var _PrintPreviewExportModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreviewExportModal.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PrintPreviewExportModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreviewExportModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewExportModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewExportModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewExportModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a":
/*!***********************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewExportModal.vue?vue&type=template&id=37c2c55a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewExportModal_vue_vue_type_template_id_37c2c55a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/PrintPreviewOld.vue":
/*!*********************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewOld.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true */ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true");
/* harmony import */ var _PrintPreviewOld_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreviewOld.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true */ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PrintPreviewOld_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3c332e28",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreviewOld.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewOld.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true":
/*!******************************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=style&index=0&id=3c332e28&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_style_index_0_id_3c332e28_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewOld.vue?vue&type=template&id=3c332e28&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewOld_vue_vue_type_template_id_3c332e28_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithSideView.vue":
/*!******************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithSideView.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651 */ "./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651");
/* harmony import */ var _PrintPreviewWithSideView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreviewWithSideView.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PrintPreviewWithSideView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreviewWithSideView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithSideView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewWithSideView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithSideView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651":
/*!************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651 ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithSideView.vue?vue&type=template&id=1f47d651");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithSideView_vue_vue_type_template_id_1f47d651__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithoutHeader.vue":
/*!*******************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithoutHeader.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994 */ "./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994");
/* harmony import */ var _PrintPreviewWithoutHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PrintPreviewWithoutHeader.vue?vue&type=script&lang=js */ "./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PrintPreviewWithoutHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/printpreview/PrintPreviewWithoutHeader.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js":
/*!*******************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithoutHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewWithoutHeader.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithoutHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994":
/*!*************************************************************************************************!*\
  !*** ./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994 ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/printpreview/PrintPreviewWithoutHeader.vue?vue&type=template&id=01641994");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PrintPreviewWithoutHeader_vue_vue_type_template_id_01641994__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/printpreview/storeMixin.js":
/*!***************************************************!*\
  !*** ./src/components/printpreview/storeMixin.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'printpreview';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    getEmailer: 'getEmailer',
    reportParameters: 'reportParameters'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addParameters: 'addParameters',
    removeParameters: 'removeParameters'
  }))
});

/***/ }),

/***/ "./src/services/byteUnits.js":
/*!***********************************!*\
  !*** ./src/services/byteUnits.js ***!
  \***********************************/
/*! exports provided: BYTES_PER_MB, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BYTES_PER_MB", function() { return BYTES_PER_MB; });
/**
 * PCK-213 - bytes in a megabyte. Size limits are stored and shown in MB but compared in bytes,
 * so this conversion appeared across the limit services and the uploaders.
 *
 * apps/pwa has its own copy: the two apps are separate builds with no module in common.
 */
var BYTES_PER_MB = 1024 * 1024;
/* harmony default export */ __webpack_exports__["default"] = ({
  BYTES_PER_MB: BYTES_PER_MB
});

/***/ }),

/***/ "./src/services/emailLimits.js":
/*!*************************************!*\
  !*** ./src/services/emailLimits.js ***!
  \*************************************/
/*! exports provided: FALLBACK_MAX_TOTAL_BYTES, getMaxTotalAttachmentBytes, resetEmailLimitsCache, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_MAX_TOTAL_BYTES", function() { return FALLBACK_MAX_TOTAL_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMaxTotalAttachmentBytes", function() { return getMaxTotalAttachmentBytes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetEmailLimitsCache", function() { return resetEmailLimitsCache; });
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.is-finite.js */ "./node_modules/core-js/modules/es.number.is-finite.js");
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_byteUnits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/services/byteUnits */ "./src/services/byteUnits.js");





/**
 * PCK-213 - the total email attachment cap, read from the API instead of hardcoded.
 *
 * The cap used to be written into VueEmail and PrintPreview as `25 * 1024 * 1024`, which
 * disagreed with what the server actually enforced, so the composer would happily accept an
 * email the send path then rejected. It now comes from a single Setting row that both ends read.
 *
 * Memoised because two components ask for it and the composer can be opened repeatedly; the cap
 * does not change within a page load.
 *
 * The fallback is deliberately a real limit rather than 0 or Infinity - one would block every
 * email, the other would block none. It matches MailgunService.DEFAULT_ATTACHMENT_TOTAL_SIZE_MB,
 * so an unreachable API degrades to the same number the server falls back to. The server is the
 * authority either way: it names the true limit in its rejection message.
 */

var FALLBACK_MAX_TOTAL_BYTES = 15 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_3__["BYTES_PER_MB"];
var cached = null;
function getMaxTotalAttachmentBytes() {
  if (!cached) {
    cached = _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get('/settings/emailattachmentlimit').then(function (response) {
      var bytes = response && response.data ? Number(response.data.maxTotalBytes) : NaN;
      return Number.isFinite(bytes) && bytes > 0 ? bytes : FALLBACK_MAX_TOTAL_BYTES;
    }).catch(function () {
      return FALLBACK_MAX_TOTAL_BYTES;
    });
  }
  return cached;
}

/** Test seam - drops the memoised result so each spec starts clean. */
function resetEmailLimitsCache() {
  cached = null;
}
/* harmony default export */ __webpack_exports__["default"] = ({
  getMaxTotalAttachmentBytes: getMaxTotalAttachmentBytes,
  resetEmailLimitsCache: resetEmailLimitsCache,
  FALLBACK_MAX_TOTAL_BYTES: FALLBACK_MAX_TOTAL_BYTES
});

/***/ })

}]);
//# sourceMappingURL=printpreview-chunk.js.map