(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-item-overview-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'NotificationBox',
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      notificationClass: 'noti-primary',
      textclass: 'has-text-primary',
      icon: 'mdi-check-circle-outline'
    };
  },
  created: function created() {
    this.getClass(this.type);
  },
  methods: {
    getClass: function getClass(type) {
      switch (type) {
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Success:
          this.notificationClass = 'noti-primary';
          this.icon = 'mdi-check-circle-outline';
          this.textclass = 'has-text-primary';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Warning:
          this.notificationClass = 'noti-warning';
          this.icon = 'mdi-bell-ring-outline';
          this.textclass = 'has-text-warning';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Error:
          this.notificationClass = 'noti-danger';
          this.icon = 'mdi-alert-circle-outline';
          this.textclass = 'has-text-danger';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Default:
          this.notificationClass = 'noti-default';
          this.icon = 'mdi-information-outline';
          this.textclass = 'has-text-current';
          break;
        default:
          break;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _mixins_QuoteItemsMixin__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./mixins/QuoteItemsMixin */ "./src/views/quote/mixins/QuoteItemsMixin.js");
/* harmony import */ var _mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./mixins/QuoteTotalsMethodMixin */ "./src/views/quote/mixins/QuoteTotalsMethodMixin.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/components/Notification/NotificationBox.vue */ "./src/components/Notification/NotificationBox.vue");














































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AuthoriseView',
  components: {
    AuthoriseLabour: _components__WEBPACK_IMPORTED_MODULE_34__["AuthoriseLabour"],
    AuthorisePart: _components__WEBPACK_IMPORTED_MODULE_34__["AuthorisePart"],
    AuthoriseOpg: _components__WEBPACK_IMPORTED_MODULE_34__["AuthoriseOpg"],
    AuthoriseSublet: _components__WEBPACK_IMPORTED_MODULE_34__["AuthoriseSublet"],
    AuthoriseMisc: _components__WEBPACK_IMPORTED_MODULE_34__["AuthoriseMisc"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_37__["ConfirmModal"],
    EditRatesModal: _components__WEBPACK_IMPORTED_MODULE_34__["EditRatesModal"],
    QuoteDetailAssessmentSummaryModal: _components__WEBPACK_IMPORTED_MODULE_34__["QuoteDetailAssessmentSummaryModal"],
    QuoteExportModal: _components__WEBPACK_IMPORTED_MODULE_34__["QuoteExportModal"],
    EstImageSendQuoteModal: _components__WEBPACK_IMPORTED_MODULE_34__["EstImageSendQuoteModal"],
    NotificationBox: _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_44__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_36__["default"], _mixins__WEBPACK_IMPORTED_MODULE_38__["QuoteAssessmentMixin"], _mixins_QuoteItemsMixin__WEBPACK_IMPORTED_MODULE_39__["default"], _mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_40__["default"]],
  props: {
    value: null,
    vehicle: null,
    insurer: null
  },
  data: function data() {
    return {
      innerValue: null,
      innerVehicle: null,
      editQuotedMode: false,
      editAuthorisedMode: false,
      selectedAssessment: null,
      draftAssessment: null,
      selectedAssessmentItems: null,
      selectedQuotedValue: 0,
      selectedAuthorisedValue: 0,
      isEditRateModalVisible: false,
      isRequestConfirmModalVisible: false,
      isRevertConfirmModalActive: false,
      isCancelAuthorityConfirmModalActive: false,
      isCancelRequestConfirmModalActive: false,
      isCategorySelected: [],
      isAllSelected: false,
      loading: false,
      isSummaryModalVisible: false,
      isQuoteExportModalActive: false,
      isEstimageSendModalActive: false,
      isConfrimManualAuthoriseModalActive: false
    };
  },
  computed: {
    assessments: function assessments() {
      if (this.innerValue) {
        return this.innerValue.quoteAssessments.filter(function (a) {
          return a.deleted !== true && a.isDeleted !== true;
        }).sort(function (a, b) {
          return a.subQuoteNo - b.subQuoteNo;
        });
      }
      return [];
    },
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"];
    },
    numItemsChanged: function numItemsChanged() {
      var _this$draftAssessment, _this$draftAssessment2;
      if (!((_this$draftAssessment = this.draftAssessment) !== null && _this$draftAssessment !== void 0 && _this$draftAssessment.submittedAssessment)) {
        return 0;
      }
      return (_this$draftAssessment2 = this.draftAssessment.submittedAssessment) === null || _this$draftAssessment2 === void 0 ? void 0 : _this$draftAssessment2.assessmentQuoteItems.length;
    },
    activeAssessment: function activeAssessment() {
      return this.assessments.find(function (a) {
        return a.deleted !== true && a.isDeleted !== true && (a.authorisedAssessment === null || a.authorisedAssessment.isDraft === true);
      });
    },
    isReadonly: function isReadonly() {
      if (this.value.orm && !this.$userInfo.isSupportUser && !this.$userInfo.isCustomerAdministrator && !this.$userInfo.isSystemAdministrator) {
        return true;
      }
      return false;
    },
    isAssessmentAuthorised: function isAssessmentAuthorised() {
      var _this$selectedAssessm;
      return ((_this$selectedAssessm = this.selectedAssessment) === null || _this$selectedAssessm === void 0 ? void 0 : _this$selectedAssessm.authorisedAssessment) && this.selectedAssessment.authorisedAssessment.isDraft !== true;
    },
    isAssessmentSubmitted: function isAssessmentSubmitted() {
      var _this$selectedAssessm2;
      return ((_this$selectedAssessm2 = this.selectedAssessment) === null || _this$selectedAssessm2 === void 0 ? void 0 : _this$selectedAssessm2.submittedAssessment) && this.selectedAssessment.submittedAssessment.isDraft !== true;
    },
    isQuoteAuthorised: function isQuoteAuthorised() {
      return this.assessments.some(function (a) {
        return a.authorisedAssessment && a.deleted !== true && a.authorisedAssessment.isDraft !== true;
      });
    },
    isPreviousQuoteAuthorised: function isPreviousQuoteAuthorised() {
      var _this$assessments;
      return ((_this$assessments = this.assessments[this.selectedAssessment.subQuoteNo - 1]) === null || _this$assessments === void 0 ? void 0 : _this$assessments.authorisedAssessment) || !this.assessments[this.selectedAssessment.subQuoteNo - 1];
    },
    hasAllItemChecked: function hasAllItemChecked() {
      return this.selectedAssessmentItems.filter(function (i) {
        return !i.isAdded || i.isAdded && !i.deleted;
      }).every(function (i) {
        return i.isSelected;
      });
    },
    totalAuthorisedColourClass: function totalAuthorisedColourClass() {
      if (this.selectedQuotedValue < this.selectedAuthorisedValue) {
        return 'has-text-success';
      } else if (this.selectedQuotedValue > this.selectedAuthorisedValue) {
        return 'has-text-danger';
      } else {
        return '';
      }
    },
    doesUserAllowedToAuthorise: function doesUserAllowedToAuthorise() {
      if (this.isEstimageEnabled || this.value.orm) {
        if (this.$userInfo.isSupportUser) {
          return true;
        }
        return false;
      }
      return true;
    },
    labourCategories: function labourCategories() {
      var labourTypes = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (type) {
        return type.category === 'Labour' || type.category === 'OtherLabour';
      });
      var companysItemCategory = this.$company.itemCategories.filter(function (ic) {
        return ic.enabled === true;
      }).filter(function (c) {
        return c.enabled === true && labourTypes.some(function (type) {
          return type.code === c.itemCategoryType;
        });
      }).map(function (c) {
        return c.itemCategoryType;
      });
      if (this.selectedAssessmentItems) {
        var missingItemTypes = this.selectedAssessmentItems.filter(function (item) {
          return !companysItemCategory.includes(item.itemType) && labourTypes.some(function (type) {
            return type.code === item.itemType;
          });
        }).map(function (item) {
          return item.itemType;
        });
        companysItemCategory = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(companysItemCategory), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(new Set(missingItemTypes)));
      }
      return companysItemCategory;
    },
    partCategories: function partCategories() {
      var partTypes = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (type) {
        return type.category === 'Part';
      });
      var companysItemCategory = this.$company.itemCategories.filter(function (c) {
        return c.enabled === true && partTypes.some(function (type) {
          return type.code === c.itemCategoryType;
        });
      }).map(function (c) {
        return c.itemCategoryType;
      });
      if (this.selectedAssessmentItems) {
        var missingItemTypes = this.selectedAssessmentItems.filter(function (item) {
          return !companysItemCategory.includes(item.itemType) && partTypes.some(function (type) {
            return type.code === item.itemType;
          });
        }).map(function (item) {
          return item.itemType;
        });
        companysItemCategory = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(companysItemCategory), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(new Set(missingItemTypes)));
      }
      return companysItemCategory;
    },
    // opgCategories() {
    //   const opgTypes = ItemCategoryCodeTypes.itemTypes.filter((type) => type.category === 'OPG')
    //   let companysItemCategory = this.$company.itemCategories
    //     .filter((c) => c.enabled === true && opgTypes.some((type) => type.code === c.itemCategoryType))
    //     .map((c) => c.itemCategoryType)
    //   if (this.selectedAssessmentItems) {
    //     const missingItemTypes = this.selectedAssessmentItems
    //       .filter((item) => !companysItemCategory.includes(item.itemType) && opgTypes.some((type) => type.code === item.itemType))
    //       .map((item) => item.itemType)
    //     companysItemCategory = [...companysItemCategory, ...new Set(missingItemTypes)]
    //   }
    //   return companysItemCategory
    // },
    miscCategories: function miscCategories() {
      var miscTypes = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (type) {
        return type.category === 'Misc';
      });
      var companysItemCategory = this.$company.itemCategories.filter(function (c) {
        return c.enabled === true && miscTypes.some(function (type) {
          return type.code === c.itemCategoryType;
        });
      }).map(function (c) {
        return c.itemCategoryType;
      });
      if (this.selectedAssessmentItems) {
        var missingItemTypes = this.selectedAssessmentItems.filter(function (item) {
          return !companysItemCategory.includes(item.itemType) && miscTypes.some(function (type) {
            return type.code === item.itemType;
          });
        }).map(function (item) {
          return item.itemType;
        });
        companysItemCategory = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(companysItemCategory), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(new Set(missingItemTypes)));
      }
      return companysItemCategory;
    },
    subletCategories: function subletCategories() {
      var subletTypes = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (type) {
        return type.category === 'Sublet';
      });
      var companysItemCategory = this.$company.itemCategories.filter(function (c) {
        return c.enabled === true && subletTypes.some(function (type) {
          return type.code === c.itemCategoryType;
        });
      }).map(function (c) {
        return c.itemCategoryType;
      });
      if (this.selectedAssessmentItems) {
        var missingItemTypes = this.selectedAssessmentItems.filter(function (item) {
          return !companysItemCategory.includes(item.itemType) && subletTypes.some(function (type) {
            return type.code === item.itemType;
          });
        }).map(function (item) {
          return item.itemType;
        });
        companysItemCategory = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(companysItemCategory), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(new Set(missingItemTypes)));
      }
      return companysItemCategory;
    },
    saved: function saved() {
      return this.value.isNew === false && this.value.isDirty === false;
    },
    insurerDefaultEmail: function insurerDefaultEmail() {
      var defaultEmail = this.insurer.emails.find(function (e) {
        return e.isDefault;
      });
      if (defaultEmail) {
        return defaultEmail.address;
      } else {
        return '';
      }
    },
    isEstimageEnabled: function isEstimageEnabled() {
      return this.$company.setting.estimageOnlineEnabled && this.value.isEstimage;
    },
    selectedAssessmentStatus: function selectedAssessmentStatus() {
      if (this.selectedAssessment.isInvoiced) {
        return 'invoiced';
      } else if (this.selectedAssessment.isAuthorised) {
        return 'authorised';
      } else if (this.selectedAssessment.isDraft) {
        return 'draft';
      } else {
        return 'submitted';
      }
    },
    nextSelectedAssessmentStatus: function nextSelectedAssessmentStatus() {
      var nextAssessment = this.assessments[this.selectedAssessment.subQuoteNo + 1];
      if (!nextAssessment) {
        return 'draft';
      } else if (nextAssessment.isInvoiced) {
        return 'invoiced';
      } else if (nextAssessment.IsAuthorised) {
        return 'authorised';
      } else {
        return 'submitted';
      }
    }
  },
  watch: {
    saved: function saved() {
      this.loading = true;
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(this.value);
      this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(this.vehicle);
      this.draftAssessment = this.createDraftAssessment();
      this.initialiseSelectedAssessment();
      this.isCategorySelected = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.map(function (c) {
        return {
          itemType: c.code,
          selected: false
        };
      });
      this.loading = false;
    },
    value: function value(newVal) {
      this.loading = true;
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(newVal);
      this.draftAssessment = this.createDraftAssessment();
      this.initialiseSelectedAssessment();
      this.loading = false;
    },
    vehicle: function vehicle(newVal) {
      this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(newVal);
    },
    selectedAssessment: {
      handler: function handler(newVal) {
        var _newVal$submittedAsse, _newVal$authorisedAss;
        this.selectedAssessmentItems = this.createAssessmentItemsList(newVal);
        this.selectedQuotedValue = this.calculateQuotedTotal(newVal === null || newVal === void 0 || (_newVal$submittedAsse = newVal.submittedAssessment) === null || _newVal$submittedAsse === void 0 ? void 0 : _newVal$submittedAsse.assessmentQuoteItems);
        this.selectedAuthorisedValue = this.calculateAuthorisedTotal(newVal === null || newVal === void 0 || (_newVal$authorisedAss = newVal.authorisedAssessment) === null || _newVal$authorisedAss === void 0 ? void 0 : _newVal$authorisedAss.assessmentQuoteItems);
      },
      deep: true
    },
    editAuthorisedMode: function editAuthorisedMode(newVal) {
      if (newVal) {
        this.selectedAuthorisedValue = 0;
      }
    },
    editQuotedMode: function editQuotedMode(newVal) {
      if (newVal) {
        this.selectedQuotedValue = 0;
      }
    },
    isCategorySelected: {
      handler: function handler(newVal) {
        this.isAllSelected = newVal.every(function (i) {
          return i.selected === true;
        });
      },
      deep: true
    },
    loading: function loading(newVal) {
      if (newVal === true) {
        this.$showSpinner();
      } else {
        this.$resetSpinner();
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.$emit('hide-header-buttons', false);
    next();
  },
  created: function created() {
    this.$emit('save', false, false);
    this.loading = true;
    this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(this.value);
    this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(this.vehicle);
    this.draftAssessment = this.createDraftAssessment();
    this.initialiseSelectedAssessment();
    this.isCategorySelected = _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.map(function (c) {
      return {
        itemType: c.code,
        selected: false
      };
    });
    this.loading = false;
  },
  updated: function updated() {},
  mounted: function mounted() {},
  methods: {
    initialiseSelectedAssessment: function initialiseSelectedAssessment() {
      if (this.activeAssessment) {
        this.selectedAssessment = this.activeAssessment;
      } else if (this.draftAssessment) {
        this.selectedAssessment = this.draftAssessment;
      } else if (this.assessments.length > 0) {
        this.selectedAssessment = this.assessments[this.assessments.length - 1];
      } else {
        this.selectedAssessment = null;
      }
    },
    selectAssessment: function selectAssessment(assessment) {
      this.selectedAssessment = assessment;
    },
    selectDraftAssessment: function selectDraftAssessment() {
      this.selectedAssessment = this.draftAssessment;
    },
    openSummaryModal: function openSummaryModal() {
      this.isSummaryModalVisible = true;
    },
    openEditRatesModal: function openEditRatesModal() {
      this.isEditRateModalVisible = true;
    },
    openRevertConfirmModal: function openRevertConfirmModal() {
      if (this.$licenceExpired) return;
      this.isRevertConfirmModalActive = true;
    },
    openCancelAuthorityConfirmModal: function openCancelAuthorityConfirmModal() {
      if (this.$licenceExpired) return;
      this.isCancelAuthorityConfirmModalActive = true;
    },
    openCancelRequestConfirmModal: function openCancelRequestConfirmModal() {
      if (this.$licenceExpired) return;
      this.isCancelRequestConfirmModalActive = true;
    },
    closeSendEstimage: function closeSendEstimage() {
      this.isEstimageSendModalActive = false;
      this.cancel();
    },
    openArnieSendQuoteModal: function openArnieSendQuoteModal() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.$showSpinner;
              _context.p = 1;
              _context.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].validateQuote(_this.innerValue.quoteId);
            case 2:
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.cancel();
            case 4:
              _context.p = 4;
              _this.$hideSpinner();
              return _context.f(4);
            case 5:
              _this.isQuoteExportModalActive = true;
            case 6:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    },
    closeArnieSendQuoteModal: function closeArnieSendQuoteModal() {
      this.isQuoteExportModalActive = false;
      this.cancel();
    },
    sentToArnie: function sentToArnie() {
      this.isQuoteExportModalActive = false;
      this.$emit('getEntity', true);
    },
    cancel: function cancel() {
      this.editQuotedMode = false;
      this.editAuthorisedMode = false;
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_35___default()(this.value);
      this.draftAssessment = this.createDraftAssessment();
      this.initialiseSelectedAssessment();
      this.$emit('hide-header-buttons', false);
    },
    editMode: function editMode(toAuthorise) {
      if (this.$licenceExpired) return;
      if (toAuthorise) {
        this.editAuthorisedMode = true;
        if (this.selectedAssessment.submittedAssessment.isDraft) {
          this.editQuotedMode = true;
        }
        if (!this.selectedAssessment.authorisedAssessment) {
          this.selectedAssessment.authorisedAssessment = this.createAssessmentDetails(this.selectedAssessment.submittedAssessment.assessmentQuoteItems, this.selectedAssessment.subQuoteNo, true, true);
        }
      } else {
        this.editQuotedMode = true;
      }
      this.$emit('hide-header-buttons', true);
    },
    confirmSendRequest: function confirmSendRequest() {
      if (this.hasAllItemChecked) {
        if (this.isEstimageEnabled) {
          this.isEstimageSendModalActive = true;
        } else if (this.insurer.arnie) {
          this.openArnieSendQuoteModal();
        } else {
          this.request();
        }
      }
    },
    revertToAuthority: function revertToAuthority() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.loading = true;
              _context2.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].revertToAuthorised(_this2.innerValue.quoteId);
            case 1:
              _this2.$emit('getEntity', true);
              _this2.isRevertConfirmModalActive = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    cancelAuthority: function cancelAuthority(merge) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.loading = true;
              _context3.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].cancelLastAuthority(_this3.innerValue.quoteId, merge);
            case 1:
              _this3.$emit('getEntity', true);
              _this3.isCancelAuthorityConfirmModalActive = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    cancelRequest: function cancelRequest(merge) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.loading = true;
              _context4.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].cancelLastRequest(_this4.innerValue.quoteId, merge);
            case 1:
              _this4.$emit('getEntity', true);
              _this4.isCancelRequestConfirmModalActive = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    authorise: function authorise() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (!_this5.hasAllItemChecked) {
                _context5.n = 2;
                break;
              }
              _this5.loading = true;
              _this5.selectedAssessment.claimNo = _this5.innerValue.claimNo;
              _context5.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].authoriseAssessment(_this5.innerValue.quoteId, _this5.selectedAssessment);
            case 1:
              _this5.$emit('getEntity', true);
              _this5.editAuthorisedMode = false;
              _this5.editQuotedMode = false;
              _this5.$emit('hide-header-buttons', false);
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    request: function request() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.loading = true;
              _context6.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].requestAuthorityAssessment(_this6.innerValue.quoteId, _this6.selectedAssessment);
            case 1:
              _this6.$emit('getEntity', true);
              _this6.editAuthorisedMode = false;
              _this6.editQuotedMode = false;
              _this6.$emit('hide-header-buttons', false);
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    sendEstImageQuote: function sendEstImageQuote(estimageObj) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        var _response$data, response, _response$data2, _response$data3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.p = _context7.n) {
            case 0:
              // this.loading = true
              _this7.$showSpinner('Sending...');
              estimageObj.assessment = _this7.selectedAssessment;
              _context7.p = 1;
              _context7.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_43__["EstImageService"].sendQuote(estimageObj);
            case 2:
              response = _context7.v;
              if (!(response !== null && response !== void 0 && (_response$data = response.data) !== null && _response$data !== void 0 && _response$data.error)) {
                _context7.n = 3;
                break;
              }
              if ((response === null || response === void 0 || (_response$data2 = response.data) === null || _response$data2 === void 0 ? void 0 : _response$data2.error) === 'REPAIRER_NOT_AUTHORIZED_TO_ADD_QUOTE' && _this7.$userInfo.isSupportUser) {
                _this7.isConfrimManualAuthoriseModalActive = true;
              } else {
                _this7.$notification.openNotificationWithType('danger', 'Error on Sending Quote to EstImage', response === null || response === void 0 || (_response$data3 = response.data) === null || _response$data3 === void 0 ? void 0 : _response$data3.details);
              }
              _context7.n = 5;
              break;
            case 3:
              _context7.n = 4;
              return _this7.request();
            case 4:
              _this7.cancel();
            case 5:
              _context7.p = 5;
              _this7.$hideSpinner();
              _this7.isEstimageSendModalActive = false;
              _this7.cancel();
              return _context7.f(5);
            case 6:
              return _context7.a(2);
          }
        }, _callee7, null, [[1,, 5, 6]]);
      }))();
    },
    manualSendQuoteEstImage: function manualSendQuoteEstImage() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this8.isConfrimManualAuthoriseModalActive = false;
              _context8.n = 1;
              return _this8.request();
            case 1:
              _this8.cancel();
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    applyRates: function applyRates(rates) {
      var _this9 = this;
      var items = [];
      if (this.editQuotedMode) {
        items.push.apply(items, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.selectedAssessment.submittedAssessment.assessmentQuoteItems));
      }
      if (this.editAuthorisedMode) {
        items.push.apply(items, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.selectedAssessment.authorisedAssessment.assessmentQuoteItems));
      }
      items.filter(function (i) {
        return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].RR;
      }).forEach(function (item) {
        var newRate = rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].RR;
        }).rate;
        var oldRate = _this9.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].RR;
        }).rate;
        _this9.updateRate(item, newRate, oldRate);
      });
      items.filter(function (i) {
        return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].MECH;
      }).forEach(function (item) {
        var newRate = rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].MECH;
        }).rate;
        var oldRate = _this9.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].MECH;
        }).rate;
        _this9.updateRate(item, newRate, oldRate);
      });
      items.filter(function (i) {
        return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].REP;
      }).forEach(function (item) {
        var newRate = rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].REP;
        }).rate;
        var oldRate = _this9.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_33__["LabourItemCodeTypes"].REP;
        }).rate;
        _this9.updateRate(item, newRate, oldRate);
      });
      items.filter(function (i) {
        return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].PAINT;
      }).forEach(function (item) {
        var newRate = rates.find(function (r) {
          return r.labourCodeId === _this9.innerVehicle.paintGroup;
        }).rate;
        var oldRate = _this9.innerValue.rates.find(function (r) {
          return r.labourCodeId === _this9.innerVehicle.paintGroup;
        }).rate;
        _this9.updateRate(item, newRate, oldRate);
      });
      this.innerValue.rates = rates;
      this.isEditRateModalVisible = false;
    },
    onSelectAllChanged: function onSelectAllChanged(event) {
      var _this0 = this;
      this.isCategorySelected.forEach(function (i, index) {
        _this0.isCategorySelected[index].selected = event.target.checked;
      });
    },
    onCategorySelectChange: function onCategorySelectChange(value, itemType) {
      this.isCategorySelected.find(function (i) {
        return i.itemType === itemType;
      }).selected = value;
    },
    updateRate: function updateRate(item, newRate, oldRate) {
      if (item.rate === oldRate) item.rate = newRate;
    },
    createDraftAssessment: function createDraftAssessment() {
      var items = this.getItemsChanged();
      var assessment = this.createAssessment(items, this.innerValue.quoteAssessments.length, this.innerValue.assessorName);
      return assessment;
    },
    getItemsChanged: function getItemsChanged() {
      var items = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.labours), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.others), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.parts), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.opgs), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.miscs), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.innerValue.sublets));
      var itemsChanged = this.itemsChanged(items, this.innerValue.quotingMethod);
      return itemsChanged;
    },
    createAssessmentItemsList: function createAssessmentItemsList(assessment) {
      var _this1 = this;
      if (!assessment.submittedAssessment && assessment.authorisedAssessment) {
        var items = assessment.authorisedAssessment.assessmentQuoteItems.filter(function (item) {
          return !item.isDeleted;
        }).map(function (item) {
          return {
            isSelected: item.isSelected,
            itemDesc: item.itemDesc,
            itemComment: item.itemComment,
            partNo: item.partNo,
            reportOnly: item.reportOnly,
            isAdded: item.isAdded,
            itemType: item.itemType,
            vendorName: item.vendorName,
            quoteItemId: item.quoteItemId,
            sortNo: _this1.getItemSortNo(item.quoteItemId, item.itemType) || item.sortNo,
            isQuoteItemDeleted: item.isQuoteItemDeleted,
            submittedItem: null,
            authorisedItem: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, item)
          };
        });
        return items.sort(function (a, b) {
          return a.sortNo - b.sortNo;
        });
      }
      if (!assessment.authorisedAssessment && assessment.submittedAssessment) {
        var _items = assessment.submittedAssessment.assessmentQuoteItems.filter(function (item) {
          return !item.isDeleted;
        }).map(function (item) {
          return {
            isSelected: item.isSelected,
            itemDesc: item.itemDesc,
            itemComment: item.itemComment,
            partNo: item.partNo,
            reportOnly: item.reportOnly,
            isAdded: item.isAdded,
            itemType: item.itemType,
            vendorName: item.vendorName,
            quoteItemId: item.quoteItemId,
            sortNo: _this1.getItemSortNo(item.quoteItemId, item.itemType) || item.sortNo,
            isQuoteItemDeleted: item.isQuoteItemDeleted,
            submittedItem: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, item),
            authorisedItem: null
          };
        });
        return _items.sort(function (a, b) {
          return a.sortNo - b.sortNo;
        });
      } else {
        var submittedItems = assessment.submittedAssessment.assessmentQuoteItems.filter(function (item) {
          return !item.isDeleted;
        });
        var authorisedItems = assessment.authorisedAssessment.assessmentQuoteItems.filter(function (item) {
          return !item.isDeleted;
        });
        var joinedItems = authorisedItems.reduce(function (acc, authorisedItem) {
          var submittedItem = submittedItems.find(function (i) {
            return i.quoteItemId === authorisedItem.quoteItemId;
          });
          acc.push({
            isSelected: authorisedItem.isSelected,
            itemDesc: authorisedItem.itemDesc,
            itemComment: authorisedItem.itemComment,
            partNo: authorisedItem.partNo,
            reportOnly: authorisedItem.reportOnly,
            isAdded: authorisedItem.isAdded,
            itemType: authorisedItem.itemType,
            isQuoteItemDeleted: authorisedItem.isQuoteItemDeleted,
            vendorName: authorisedItem.vendorName,
            quoteItemId: authorisedItem.quoteItemId,
            sortNo: _this1.getItemSortNo(authorisedItem.quoteItemId, authorisedItem.itemType) || authorisedItem.sortNo,
            submittedItem: submittedItem,
            authorisedItem: authorisedItem
          });
          return acc;
        }, []);
        return joinedItems.sort(function (a, b) {
          return a.sortNo - b.sortNo;
        });
      }
    },
    addItemToDraftAssessment: function addItemToDraftAssessment(item) {
      if (item.submittedItem) {
        item.submittedItem.lineNumber = this.innerValue.lines;
        item.submittedItem.itemNo = this.$filters.pad(item.submittedItem.lineNumber, 4);
        this.selectedAssessment.submittedAssessment.assessmentQuoteItems.push(item.submittedItem);
      }
      if (item.authorisedItem) {
        item.authorisedItem.lineNumber = this.innerValue.lines;
        item.authorisedItem.itemNo = this.$filters.pad(item.authorisedItem.lineNumber, 4);
        this.selectedAssessment.authorisedAssessment.assessmentQuoteItems.push(item.authorisedItem);
      }
      this.innerValue.lines++;
      // this.$toast.open({
      //   message: 'Item added',
      //   type: 'is-success',
      //   position: 'is-top',
      //   queue: false
      // })
      this.$notification.success('', 'Item added');
    },
    updateDraftAssessment: function updateDraftAssessment(item) {
      if (item.submittedItem && this.editQuotedMode) {
        if (item.isDeleted) {
          //remove deleted item
          this.selectedAssessment.submittedAssessment.assessmentQuoteItems = this.selectedAssessment.submittedAssessment.assessmentQuoteItems.filter(function (i) {
            return i.quoteItemId !== item.submittedItem.quoteItemId;
          });
        }
        var submittedAssessmentQuoteItem = this.selectedAssessment.submittedAssessment.assessmentQuoteItems.find(function (i) {
          return i.quoteItemId === item.submittedItem.quoteItemId;
        });
        if (submittedAssessmentQuoteItem) {
          this.updateDraftItemsValues(submittedAssessmentQuoteItem, item.submittedItem);
          this.updateDraftItemsCommonValues(submittedAssessmentQuoteItem, item);
        }
      }
      if (item.authorisedItem && this.editAuthorisedMode) {
        if (item.isDeleted) {
          this.selectedAssessment.authorisedAssessment.assessmentQuoteItems = this.selectedAssessment.authorisedAssessment.assessmentQuoteItems.filter(function (i) {
            return i.quoteItemId !== item.authorisedItem.quoteItemId;
          });
        }
        var authorisedAssessmentQuoteItem = this.selectedAssessment.authorisedAssessment.assessmentQuoteItems.find(function (i) {
          return i.quoteItemId === item.authorisedItem.quoteItemId;
        });
        if (authorisedAssessmentQuoteItem) {
          this.updateDraftItemsValues(authorisedAssessmentQuoteItem, item.authorisedItem);
          this.updateDraftItemsCommonValues(authorisedAssessmentQuoteItem, item);
        }
      }
    },
    updateDraftItemsValues: function updateDraftItemsValues(targetItem, sourceItem) {
      targetItem.buyPrice = sourceItem.buyPrice;
      targetItem.dollarValue = sourceItem.dollarValue;
      targetItem.hourValue = sourceItem.hourValue;
      targetItem.isQuoteItemDeleted = sourceItem.isQuoteItemDeleted;
      targetItem.isSelected = sourceItem.isSelected;
      targetItem.itemDesc = sourceItem.itemDesc;
      targetItem.itemComment = sourceItem.itemComment;
      targetItem.itemNo = sourceItem.itemNo;
      targetItem.itemQuantity = sourceItem.itemQuantity;
      targetItem.itemType = sourceItem.itemType;
      targetItem.lineNumber = sourceItem.lineNumber;
      targetItem.mark = sourceItem.mark;
      targetItem.markupValue = sourceItem.markupValue;
      targetItem.opgCode = sourceItem.opgCode;
      targetItem.partNo = sourceItem.partNo;
      targetItem.partSource = sourceItem.partSource;
      targetItem.rate = sourceItem.rate;
      targetItem.reportOnly = sourceItem.reportOnly;
      targetItem.value = sourceItem.value;
      targetItem.vendorName = sourceItem.vendorName;
    },
    updateDraftItemsCommonValues: function updateDraftItemsCommonValues(targetItem, sourceItem) {
      targetItem.reportOnly = sourceItem.reportOnly;
      targetItem.isAdded = sourceItem.isAdded;
      targetItem.itemDesc = sourceItem.itemDesc;
      targetItem.itemComment = sourceItem.itemComment;
      targetItem.partNo = sourceItem.partNo;
      targetItem.isSelected = sourceItem.isSelected;
      targetItem.isQuoteItemDeleted = sourceItem.isQuoteItemDeleted;
      targetItem.sortNo = sourceItem.sortNo;
      targetItem.quoteItemId = sourceItem.quoteItemId;
    },
    calculateQuotedTotal: function calculateQuotedTotal(items) {
      if (!items || items.length === 0) return 0;
      var total = 0;
      if (this.editQuotedMode) {
        total = this.calculateAssessmentItemsTotal(this.innerValue.quotingMethod, items.filter(function (i) {
          return i.isSelected;
        }));
      } else {
        total = this.calculateAssessmentItemsTotal(this.innerValue.quotingMethod, items);
      }
      return total;
    },
    calculateAuthorisedTotal: function calculateAuthorisedTotal(items) {
      if (!items || items.length === 0) return 0;
      var total = 0;
      if (this.editAuthorisedMode) {
        total = this.calculateAssessmentItemsTotal(this.innerValue.quotingMethod, items.filter(function (i) {
          return i.isSelected;
        }));
      } else {
        total = this.calculateAssessmentItemsTotal(this.innerValue.quotingMethod, items);
      }
      return total;
    },
    calculateAssessmentItemsTotal: function calculateAssessmentItemsTotal(quotingMethod, items) {
      var total = 0;
      // For EstImage quotes the authoritative line value is dollarValue (mirrors getItemValue/getItemDeltaValue),
      // captured in a local const so the plain reduce callbacks below can close over it.
      var isEstimage = this.innerValue.isEstimage;
      total += items.filter(function (i) {
        return !i.isQuoteItemDeleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].PART;
      }).reduce(function (subTotal, item) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_41__["roundAwayFromZero"])(subTotal + item.itemQuantity * item.markupValue);
      }, 0);
      total += items.filter(function (i) {
        return !i.isQuoteItemDeleted && !i.reportOnly && (i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].MISC || i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].SUBL);
      }).reduce(function (subTotal, item) {
        return subTotal + item.value;
      }, 0);
      total += items.filter(function (i) {
        return !i.isQuoteItemDeleted && !i.reportOnly && i.itemType === _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].OPG;
      }).reduce(function (subTotal, item) {
        return subTotal + (isEstimage || quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_33__["QuotingMethodTypes"].Dollar ? item.dollarValue : item.hourValue * item.rate);
      }, 0);
      total += items.filter(function (i) {
        return !i.isQuoteItemDeleted && !i.reportOnly && i.itemType !== _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].OPG && i.itemType !== _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].PART && i.itemType !== _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].MISC && i.itemType !== _enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryTypes"].SUBL;
      }).reduce(function (subTotal, item) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_41__["roundAwayFromZero"])(subTotal + (isEstimage || quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_33__["QuotingMethodTypes"].Dollar ? item.dollarValue : Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_41__["roundAwayFromZero"])(item.hourValue * item.rate)));
      }, 0);
      return total;
    },
    getItemSortNo: function getItemSortNo(quoteItemId, itemType) {
      var sortNo = null;
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Labour';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var item = this.innerValue.labours.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (item) sortNo = item.sortNo;
      }
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'OtherLabour';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var _item = this.innerValue.others.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (_item) sortNo = _item.sortNo;
      }
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Part';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var _item2 = this.innerValue.parts.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (_item2) sortNo = _item2.sortNo;
      }
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'OPG';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var _item3 = this.innerValue.opgs.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (_item3) sortNo = _item3.sortNo;
      }
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Misc';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var _item4 = this.innerValue.miscs.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (_item4) sortNo = _item4.sortNo;
      }
      if (_enums__WEBPACK_IMPORTED_MODULE_33__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Sublet';
      }).some(function (c) {
        return c.code === itemType;
      })) {
        var _item5 = this.innerValue.sublets.find(function (i) {
          return i.quoteItemId === quoteItemId;
        });
        if (_item5) sortNo = _item5.sortNo;
      }
      return sortNo;
    },
    lastAuthorisedQuoteLabel: function lastAuthorisedQuoteLabel(selectedAssessment) {
      var cap = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      if (selectedAssessment.subQuoteNo === 0) return null;
      var label = selectedAssessment.subQuoteNo === 1 ? 'Main' : "Supp-".concat(selectedAssessment.subQuoteNo - 1);
      return cap === true ? label.toUpperCase() : label;
    },
    currentAuthorisedQuoteLabel: function currentAuthorisedQuoteLabel(selectedAssessment) {
      var cap = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var label = selectedAssessment.subQuoteNo === 0 ? 'Main' : "Supp-".concat(selectedAssessment.subQuoteNo);
      return cap === true ? label.toUpperCase() : label;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _mixins_QuoteItemsMixin__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./mixins/QuoteItemsMixin */ "./src/views/quote/mixins/QuoteItemsMixin.js");
/* harmony import */ var _mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./mixins/QuoteTotalsMethodMixin */ "./src/views/quote/mixins/QuoteTotalsMethodMixin.js");






















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteItemsAuhtorise',
  components: {
    AuthoriseLabourOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseLabourOld"],
    AuthoriseOtherLabourOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseOtherLabourOld"],
    AuthorisePartOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthorisePartOld"],
    AuthoriseOpgOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseOpgOld"],
    AuthoriseMiscOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseMiscOld"],
    AuthoriseSubletOld: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseSubletOld"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_18__["ConfirmModal"],
    AuthoriseModal: _components__WEBPACK_IMPORTED_MODULE_15__["AuthoriseModal"],
    EditRatesModal: _components__WEBPACK_IMPORTED_MODULE_15__["EditRatesModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_17__["default"], _mixins__WEBPACK_IMPORTED_MODULE_19__["QuoteAssessmentMixin"], _mixins_QuoteItemsMixin__WEBPACK_IMPORTED_MODULE_20__["default"], _mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_21__["default"]],
  props: {
    value: null,
    vehicle: null
  },
  data: function data() {
    return {
      innerValue: null,
      innerVehicle: null,
      activeTab: '',
      isEditable: false,
      isEditableToAuthorise: false,
      isAuthoriseModalVisible: false,
      isEditRateModalVisible: false,
      isRevertConfirmModalActive: false,
      isCancelAuthorityConfirmModalActive: false,
      isCancelRequestConfirmModalActive: false,
      isRequestModalVisible: false,
      laboursAssessments: [],
      otherLaboursAssessments: [],
      partsAssessments: [],
      opgsAssessments: [],
      miscsAssessments: [],
      subletsAssessments: [],
      ratesAssessments: [],
      requestedValue: 0
    };
  },
  computed: {
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"];
    },
    hasPendingRequest: function hasPendingRequest() {
      var _this$lastQuoteAssess, _this$lastQuoteAssess2;
      return ((_this$lastQuoteAssess = this.lastQuoteAssessment) === null || _this$lastQuoteAssess === void 0 ? void 0 : _this$lastQuoteAssess.submittedAssessment) !== null && ((_this$lastQuoteAssess2 = this.lastQuoteAssessment) === null || _this$lastQuoteAssess2 === void 0 ? void 0 : _this$lastQuoteAssess2.authorisedAssessment) === null;
    },
    targetValue: function targetValue() {
      return this.hasPendingRequest ? this.requestedValue : this.totalSelectedItems;
    },
    isNtar: function isNtar() {
      return this.value && (this.value.labourType === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourTimeTypes"].NTAR || this.value.labourType === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourTimeTypes"].LTAR || this.value.labourType === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourTimeTypes"].eMTA);
    },
    isLabour: function isLabour() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT;
    },
    isOtherLabour: function isOtherLabour() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH || this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER;
    },
    isPart: function isPart() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART;
    },
    isOpg: function isOpg() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG;
    },
    isMisc: function isMisc() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC;
    },
    isSublet: function isSublet() {
      return this.activeTab === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL;
    },
    hasAssessment: function hasAssessment() {
      return this.innerValue.quoteAssessments.length > 0;
    },
    lastQuoteAssessment: function lastQuoteAssessment() {
      if (this.innerValue) {
        return this.innerValue.quoteAssessments[this.innerValue.quoteAssessments.length - 1];
      }
      return null;
    },
    rrItems: function rrItems() {
      var _this = this;
      if (this.hasPendingRequest) {
        var _this$innerValue;
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR;
        });
        var newItems = (_this$innerValue = this.innerValue) === null || _this$innerValue === void 0 ? void 0 : _this$innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR;
        }).filter(function (i) {
          return _this.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this.innerValue.quotingMethod);
        });
      }
    },
    rwaItems: function rwaItems() {
      var _this2 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA;
        });
        var newItems = this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA;
        }).filter(function (i) {
          return _this2.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this2.innerValue.quotingMethod);
        });
      }
    },
    repairItems: function repairItems() {
      var _this3 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP;
        });
        var newItems = this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP;
        }).filter(function (i) {
          return _this3.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this3.innerValue.quotingMethod);
        });
      }
    },
    paintItems: function paintItems() {
      var _this4 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT;
        });
        var newItems = this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.labours.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT;
        }).filter(function (i) {
          return _this4.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this4.innerValue.quotingMethod);
        });
      }
    },
    mechItems: function mechItems() {
      var _this5 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH;
        });
        var newItems = this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH;
        }).filter(function (i) {
          return _this5.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this5.innerValue.quotingMethod);
        });
      }
    },
    cdItems: function cdItems() {
      var _this6 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD;
        });
        var newItems = this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD;
        }).filter(function (i) {
          return _this6.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this6.innerValue.quotingMethod);
        });
      }
    },
    crushItems: function crushItems() {
      var _this7 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH;
        });
        var newItems = this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH;
        }).filter(function (i) {
          return _this7.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this7.innerValue.quotingMethod);
        });
      }
    },
    fgItems: function fgItems() {
      var _this8 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER;
        });
        var newItems = this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.others.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER;
        }).filter(function (i) {
          return _this8.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this8.innerValue.quotingMethod);
        });
      }
    },
    partItems: function partItems() {
      var _this9 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART;
        });
        var newItems = this.innerValue.parts.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.parts.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART;
        }).filter(function (i) {
          return _this9.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this9.innerValue.quotingMethod);
        });
      }
    },
    opgItems: function opgItems() {
      var _this0 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG;
        });
        var newItems = this.innerValue.opgs.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.opgs.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG;
        }).filter(function (i) {
          return _this0.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this0.innerValue.quotingMethod);
        });
      }
    },
    miscItems: function miscItems() {
      var _this1 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC;
        });
        var newItems = this.innerValue.miscs.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.miscs.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC;
        }).filter(function (i) {
          return _this1.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this1.innerValue.quotingMethod);
        });
      }
    },
    subletItems: function subletItems() {
      var _this10 = this;
      if (this.hasPendingRequest) {
        var submittedItems = this.lastQuoteAssessment.submittedAssessment.assessmentQuoteItems.filter(function (a) {
          return a.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL;
        });
        var newItems = this.innerValue.sublets.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL;
        }).filter(function (i) {
          return i.isAdded === true && i.deleted === false;
        });
        return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(submittedItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems));
      } else {
        return this.innerValue.sublets.filter(function (i) {
          return i.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL;
        }).filter(function (i) {
          return _this10.itemChanged(i, i.lastQuotedAssessment, i.lastAuthorisedAssessment, _this10.innerValue.quotingMethod);
        });
      }
    },
    selectedItems: function selectedItems() {
      return this.allActiveItems.filter(function (i) {
        return i.isSelected === true;
      });
    },
    totalSelectedItems: function totalSelectedItems() {
      if (this.selectedItems.length === 0) return 0;
      return this.calculateItemsTotal(this.value.quotingMethod, this.selectedItems);
    },
    requestAuthorityPending: function requestAuthorityPending() {
      if (!this.hasAssessment) return false;
      return this.lastQuoteAssessment.authorisedAssessment === null;
    },
    allActiveItems: function allActiveItems() {
      return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.rrItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.rwaItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.repairItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.paintItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.mechItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.cdItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.crushItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.fgItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.partItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.opgItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.miscItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.subletItems));
    },
    tabs: function tabs() {
      return this.companyItemTypes.filter(function (i) {
        return i.enabled === true;
      });
    },
    allItemSelected: {
      get: function get() {
        var result = this.allActiveItems.length > 0 && this.allActiveItems.every(function (i) {
          return i.isSelected === true;
        });
        return result;
      },
      set: function set(newValue) {
        this.allActiveItems.forEach(function (i) {
          i.isSelected = newValue;
        });
      }
    },
    targetValueColor: function targetValueColor() {
      if (this.targetValue > this.totalSelectedItems) {
        return 'has-text-danger';
      } else if (this.targetValue === this.totalSelectedItems) {
        return 'has-text-success';
      } else {
        return '';
      }
    }
  },
  watch: {
    value: function value(newVal) {
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default()(newVal);
    },
    vehicle: function vehicle(newVal) {
      this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default()(newVal);
    },
    innerValue: function innerValue(newVal) {
      this.getLabourItemsAssessments();
      this.getOtherLabourItemsAssessments();
      this.getPartItemsAssessments();
      this.getOpgItemsAssessments();
      this.getMiscItemsAssessments();
      this.getSubletItemsAssessments();
      this.selectInitialTab();
    }
  },
  created: function created() {
    this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default()(this.value);
    this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default()(this.vehicle);
    this.getLabourItemsAssessments();
    this.getOtherLabourItemsAssessments();
    this.getPartItemsAssessments();
    this.getOpgItemsAssessments();
    this.getMiscItemsAssessments();
    this.getSubletItemsAssessments();
    this.selectInitialTab();
  },
  updated: function updated() {},
  mounted: function mounted() {},
  methods: {
    onPageChange: function onPageChange() {},
    sort: function sort() {},
    tabClicked: function tabClicked(type) {
      this.activeTab = type;
    },
    selectInitialTab: function selectInitialTab() {
      if (this.activeTab !== '') return;
      if (this.rrItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR;
      } else if (this.rwaItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA;
      } else if (this.repairItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP;
      } else if (this.paintItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT;
      } else if (this.mechItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH;
      } else if (this.cdItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD;
      } else if (this.crushItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH;
      } else if (this.fgItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER;
      } else if (this.partItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART;
      } else if (this.opgItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG;
      } else if (this.miscItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC;
      } else if (this.subletItems.length > 0) {
        this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL;
      } else if (this.tabs.length > 0) {
        this.activeTab = this.tabs[0].itemCategoryType;
      } else {
        this.activeTab = '';
      }
    },
    editableQuote: function editableQuote(toAuthorise) {
      if (toAuthorise) {
        this.getTargetValue();
      }
      this.isEditable = !this.isEditable;
      this.isEditableToAuthorise = toAuthorise;
      this.$emit('save');
      // this.defaultSelectedItems()
    },
    openAuthoriseModal: function openAuthoriseModal() {
      this.isAuthoriseModalVisible = true;
    },
    openEditRatesModal: function openEditRatesModal() {
      this.isEditRateModalVisible = true;
    },
    openRevertConfirmModal: function openRevertConfirmModal() {
      this.isRevertConfirmModalActive = true;
    },
    openCancelAuthorityConfirmModal: function openCancelAuthorityConfirmModal() {
      this.isCancelAuthorityConfirmModalActive = true;
    },
    openCancelRequestConfirmModal: function openCancelRequestConfirmModal() {
      this.isCancelRequestConfirmModalActive = true;
    },
    cancel: function cancel() {
      this.isEditable = false;
      this.isEditableToAuthorise = false;
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_16___default()(this.value);
    },
    revertToAuthority: function revertToAuthority() {
      this.$emit('revert-authority', this.innerValue.quoteId);
      this.isRevertConfirmModalActive = false;
    },
    cancelAuthority: function cancelAuthority(merge) {
      this.$emit('cacnel-authority', this.innerValue.quoteId, merge);
      this.isCancelAuthorityConfirmModalActive = false;
    },
    cancelRequest: function cancelRequest(merge) {
      this.$emit('cacnel-request', this.innerValue.quoteId, merge);
      this.isCancelRequestConfirmModalActive = false;
    },
    authorise: function authorise() {
      var assessment = this.createAssessment(true);
      this.$emit('authorise-quote', this.innerValue.quoteId, assessment);
      this.isEditable = false;
      this.isEditableToAuthorise = false;
    },
    request: function request() {
      var assessment = this.createAssessment(false);
      this.$emit('request-authority-quote', this.innerValue.quoteId, assessment);
      this.isEditable = false;
      this.isEditableToAuthorise = false;
    },
    applyRates: function applyRates() {
      var _this11 = this;
      this.rrItems.forEach(function (i) {
        i.rate = _this11.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].RR;
        }).rate;
      });
      this.mechItems.forEach(function (i) {
        i.rate = _this11.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].MECH;
        }).rate;
      });
      this.repairItems.forEach(function (i) {
        i.rate = _this11.innerValue.rates.find(function (r) {
          return r.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].REP;
        }).rate;
      });
      this.paintItems.forEach(function (i) {
        i.rate = _this11.innerValue.rates.find(function (r) {
          return r.labourCodeId === _this11.innerVehicle.paintGroup;
        }).rate;
      });
      this.isEditRateModalVisible = false;
    },
    createAssessment: function createAssessment(authorise) {
      var assessment = {
        quoteId: this.innerValue.quoteId
      };
      if (authorise) {
        assessment.assessorName = this.innerValue.assessorName;
        assessment.submittedAssessment = this.createAssessmentDetails();
        assessment.authorisedAssessment = this.createAssessmentDetails();
      } else {
        assessment.assessorName = null;
        assessment.submittedAssessment = this.createAssessmentDetails();
        assessment.authorisedAssessment = null;
      }
      return assessment;
    },
    createAssessmentDetails: function createAssessmentDetails() {
      var assessmentDetail = {
        claimNo: this.innerValue.claimNo,
        excess: this.innerValue.excess,
        totalExGST: this.innerValue.totalExGst,
        assessmentQuoteItems: this.createAssessmentQuoteItems()
      };
      assessmentDetail.assessmentRates = {
        paintGroup: this.innerVehicle.paintGroup,
        labourRates: this.createAssessmentLabourRates(this.innerVehicle.paintGroup)
      };
      return assessmentDetail;
    },
    createAssessmentQuoteItems: function createAssessmentQuoteItems() {
      return this.selectedItems.map(function (i) {
        return {
          quoteItemid: i.quoteItemId,
          itemType: i.itemType,
          itemNo: i.itemNo,
          itemDesc: i.itemDesc,
          hourValue: i.hourValue,
          rate: i.rate,
          dollarValue: i.dollarValue,
          partNo: i.partNo,
          partSource: i.partSource,
          itemComment: i.itemComment,
          itemQuantity: i.itemQuantity,
          value: i.value,
          reportOnly: i.reportOnly,
          isQuoteItemDeleted: i.deleted || i.isDeleted,
          markupValue: i.markupValue,
          mark: i.mark,
          buyPrice: i.buyPrice,
          lineNumber: i.lineNumber,
          opgCode: i.opgCode
        };
      });
    },
    createAssessmentLabourRates: function createAssessmentLabourRates(paintGroup) {
      var rates = [];
      this.innerValue.rates.forEach(function (rate) {
        if (rate.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].RR || rate.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].MECH || rate.labourCodeId === _enums__WEBPACK_IMPORTED_MODULE_14__["LabourItemCodeTypes"].REP || rate.labourCodeId === paintGroup) {
          rates.push({
            labourCodeId: rate.labourCodeId,
            rate: rate.rate
          });
        }
      });
      return rates;
    },
    defaultSelectedItems: function defaultSelectedItems() {
      this.allActiveItems.forEach(function (i) {
        i.isSelected = false;
      });
    },
    lastAssessment: function lastAssessment(item) {
      var assessments = [];
      if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RR || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].RWA || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].REP || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PAINT) {
        var _this$laboursAssessme;
        assessments = (_this$laboursAssessme = this.laboursAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$laboursAssessme === void 0 ? void 0 : _this$laboursAssessme.assessments;
      } else if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MECH || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CD || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].CRUSH || item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].FIBER) {
        var _this$otherLaboursAss;
        assessments = (_this$otherLaboursAss = this.otherLaboursAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$otherLaboursAss === void 0 ? void 0 : _this$otherLaboursAss.assessments;
      } else if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].PART) {
        var _this$partsAssessment;
        assessments = (_this$partsAssessment = this.partsAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$partsAssessment === void 0 ? void 0 : _this$partsAssessment.assessments;
      } else if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].OPG) {
        var _this$opgsAssessments;
        assessments = (_this$opgsAssessments = this.opgsAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$opgsAssessments === void 0 ? void 0 : _this$opgsAssessments.assessments;
      } else if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].MISC) {
        var _this$miscsAssessment;
        assessments = (_this$miscsAssessment = this.miscsAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$miscsAssessment === void 0 ? void 0 : _this$miscsAssessment.assessments;
      } else if (item.itemType === _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"].SUBL) {
        var _this$subletsAssessme;
        assessments = (_this$subletsAssessme = this.subletsAssessments.find(function (a) {
          return a.quoteItemId === item.quoteItemId;
        })) === null || _this$subletsAssessme === void 0 ? void 0 : _this$subletsAssessme.assessments;
      }
      if (!assessments || assessments.length === 0) return [];
      return assessments[assessments.length - 1];
    },
    rateLastAssessment: function rateLastAssessment(rate) {
      var _this$ratesAssessment;
      var assessments = (_this$ratesAssessment = this.ratesAssessments.find(function (a) {
        return a.labourCodeId === rate.labourCodeId;
      })) === null || _this$ratesAssessment === void 0 ? void 0 : _this$ratesAssessment.assessments;
      if (!assessments || assessments.length === 0) return [];
      return assessments[assessments.length - 1];
    },
    getLabourItemsAssessments: function getLabourItemsAssessments() {
      this.laboursAssessments = this.getItemsAssessments(this.value.labours, this.value.quoteAssessments);
    },
    getOtherLabourItemsAssessments: function getOtherLabourItemsAssessments() {
      this.otherLaboursAssessments = this.getItemsAssessments(this.value.others, this.value.quoteAssessments);
    },
    getPartItemsAssessments: function getPartItemsAssessments() {
      this.partsAssessments = this.getItemsAssessments(this.value.parts, this.value.quoteAssessments);
    },
    getOpgItemsAssessments: function getOpgItemsAssessments() {
      this.opgsAssessments = this.getItemsAssessments(this.value.opgs, this.value.quoteAssessments);
    },
    getMiscItemsAssessments: function getMiscItemsAssessments() {
      this.miscsAssessments = this.getItemsAssessments(this.value.miscs, this.value.quoteAssessments);
    },
    getSubletItemsAssessments: function getSubletItemsAssessments() {
      this.subletsAssessments = this.getItemsAssessments(this.value.sublets, this.value.quoteAssessments);
    },
    showTab: function showTab(itemCategoryType) {
      var companyItemCategoryType = this.tabs.find(function (i) {
        return i.itemCategoryType === itemCategoryType;
      });
      if (companyItemCategoryType) return true;
      return false;
    },
    getTargetValue: function getTargetValue() {
      var _this$lastQuoteAssess3;
      var items = (_this$lastQuoteAssess3 = this.lastQuoteAssessment) === null || _this$lastQuoteAssess3 === void 0 ? void 0 : _this$lastQuoteAssess3.submittedAssessment.assessmentQuoteItems.filter(function (i) {
        return i.deleted !== true;
      });
      if (!items || items.length === 0) {
        this.requestedValue = 0;
      }
      if (this.lastQuoteAssessment) {
        this.requestedValue = this.calculateItemsTotal(this.innerValue.quotingMethod, items);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", [_c("div", {
    staticClass: "control is-flex is-align-items-center",
    class: [_vm.notificationClass, _vm.textclass, _vm.$theme.isDark ? "is-dark" : "is-light"]
  }, [_c("div", {
    staticClass: "mr-4"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: _vm.icon
  })])]), _vm._t("text-content")], 2)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm$selectedAssessmen3, _vm$selectedAssessmen4, _vm$assessments$, _vm$selectedAssessmen5, _vm$selectedAssessmen6, _vm$selectedAssessmen7, _vm$selectedAssessmen8, _vm$selectedAssessmen9, _vm$selectedAssessmen0, _vm$selectedAssessmen1;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns mb-0 pb-0"
  }, [_c("div", {
    staticClass: "column pb-0"
  }, [_c("p", {
    staticClass: "title mb-2"
  }, [_vm._v(" Assessments "), _c("button", {
    staticClass: "button is-small is-info ml-2 title-align",
    on: {
      click: _vm.openSummaryModal
    }
  }, [_vm._m(0), _c("span", [_vm._v(" View Summary ")])])])])]), _vm.assessments.length > 0 || _vm.numItemsChanged > 0 ? _c("div", [_c("div", {
    staticClass: "tabs"
  }, [_c("ul", [_vm._l(_vm.assessments, function (assessment) {
    var _vm$selectedAssessmen, _vm$selectedAssessmen2;
    return _c("li", {
      key: assessment.assessmentID,
      class: {
        "is-active": ((_vm$selectedAssessmen = _vm.selectedAssessment) === null || _vm$selectedAssessmen === void 0 ? void 0 : _vm$selectedAssessmen.assessmentID) === assessment.assessmentID,
        "tab-disabled": ((_vm$selectedAssessmen2 = _vm.selectedAssessment) === null || _vm$selectedAssessmen2 === void 0 ? void 0 : _vm$selectedAssessmen2.assessmentID) !== assessment.assessmentID && (_vm.editAuthorisedMode || _vm.editQuotedMode)
      }
    }, [_c("a", {
      on: {
        click: function click($event) {
          return _vm.selectAssessment(assessment);
        }
      }
    }, [_c("span", [_c("span", {
      staticClass: "has-badge-child-offset2"
    }, [_vm._v(_vm._s(_vm.currentAuthorisedQuoteLabel(assessment, true)))]), assessment !== null && assessment !== void 0 && assessment.authorisedAssessment && assessment.authorisedAssessment.isDraft !== true ? _c("span", {
      staticClass: "tag is-success icon"
    }, [_c("i", {
      staticClass: "mdi mdi-check"
    })]) : assessment !== null && assessment !== void 0 && assessment.submittedAssessment ? _c("span", {
      staticClass: "tag is-warning"
    }, [_vm._v(_vm._s(assessment.submittedAssessment ? assessment.submittedAssessment.assessmentQuoteItems.length : 0))]) : _vm._e()])])]);
  }), _vm.numItemsChanged > 0 ? _c("li", {
    class: {
      "is-active": ((_vm$selectedAssessmen3 = _vm.selectedAssessment) === null || _vm$selectedAssessmen3 === void 0 ? void 0 : _vm$selectedAssessmen3.assessmentID) === _vm.draftAssessment.assessmentID,
      "tab-disabled": ((_vm$selectedAssessmen4 = _vm.selectedAssessment) === null || _vm$selectedAssessmen4 === void 0 ? void 0 : _vm$selectedAssessmen4.assessmentID) !== _vm.draftAssessment.assessmentID && (_vm.editAuthorisedMode || _vm.editQuotedMode)
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.selectDraftAssessment();
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v(_vm._s(_vm.assessments.length === 0 ? "MAIN" : "SUPP-".concat(_vm.assessments.length)))]), _c("span", {
    staticClass: "tag",
    class: "is-".concat(_vm.$theme.name)
  }, [_vm._v(_vm._s(_vm.numItemsChanged))])])])]) : _vm._e()], 2), !((_vm$assessments$ = _vm.assessments[0]) !== null && _vm$assessments$ !== void 0 && _vm$assessments$.authorisedAssessment) && (_vm.editAuthorisedMode || _vm.editQuotedMode) ? _c("button", {
    staticClass: "button is-primary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Edit rates"
    },
    on: {
      click: _vm.openEditRatesModal
    }
  }, [_vm._m(1), _c("span", [_vm._v("Edit Rates")])]) : _vm._e()]), _c("div", {
    staticClass: "mt-2"
  }, [_c("div", {
    staticClass: "columns is-gapless mb-0"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", [_c("span", [_c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v(" " + _vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)) + " Requested Value: ")]), _c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.selectedQuotedValue, _vm.$userInfo.locale)) + " ")])]), _vm.selectedAssessment.authorisedAssessment ? _c("span", {
    staticClass: "ml-6"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v(" " + _vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)) + " Authorised Value: ")]), _c("span", {
    staticClass: "has-text-weight-semibold",
    class: _vm.totalAuthorisedColourClass
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.selectedAuthorisedValue, _vm.$userInfo.locale)) + " ")])]) : _vm._e()])]), !_vm.isReadonly ? _c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field mr-2"
  }, [_c("div", {
    staticClass: "buttons"
  }, [!(_vm.editAuthorisedMode || _vm.editQuotedMode) && _vm.isAssessmentSubmitted && (!_vm.isEstimageEnabled || _vm.$userInfo.isSupportUser) && !_vm.isAssessmentAuthorised ? _c("a", {
    staticClass: "button is-secondary tooltip is-tooltip-topright is-transparent",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Cancel the last request to authority"
    },
    on: {
      click: function click($event) {
        return _vm.openCancelRequestConfirmModal();
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("Cancel Request")])]) : _vm._e(), !(_vm.editAuthorisedMode || _vm.editQuotedMode) && _vm.isAssessmentAuthorised && _vm.selectedAssessment.subQuoteNo === _vm.assessments.length - 1 && _vm.selectedAssessment.isInvoiced !== true && (!_vm.isEstimageEnabled || _vm.$userInfo.isSupportUser) ? _c("a", {
    staticClass: "button is-secondary tooltip is-tooltip-topright is-transparent",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Cancel the last authority"
    },
    on: {
      click: function click($event) {
        return _vm.openCancelAuthorityConfirmModal();
      }
    }
  }, [_vm._m(3), _c("span", [_vm._v("Cancel " + _vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)) + " Authority")])]) : _vm._e(), !(_vm.editAuthorisedMode || _vm.editQuotedMode) && !_vm.isAssessmentSubmitted && !_vm.isAssessmentAuthorised && _vm.isQuoteAuthorised ? _c("a", {
    staticClass: "button is-secondary tooltip is-tooltip-topright is-transparent",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Revert to last authority"
    },
    on: {
      click: function click($event) {
        return _vm.openRevertConfirmModal();
      }
    }
  }, [_vm._m(4), _c("span", [_vm._v("Revert to " + _vm._s(_vm.lastAuthorisedQuoteLabel(_vm.selectedAssessment)))])]) : _vm._e(), _vm.editAuthorisedMode || _vm.editQuotedMode ? _c("a", {
    staticClass: "button is-secondary tooltip is-tooltip-topright is-transparent",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_vm._m(5), _c("span", [_vm._v("Cancel")])]) : _vm._e(), !(_vm.editAuthorisedMode || _vm.editQuotedMode) && (!_vm.isAssessmentSubmitted || _vm.isEstimageEnabled) && !_vm.isAssessmentAuthorised && _vm.isPreviousQuoteAuthorised ? _c("a", {
    staticClass: "button is-info is-outlined tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Submit request"
    },
    on: {
      click: function click($event) {
        return _vm.editMode(false);
      }
    }
  }, [!_vm.isAssessmentSubmitted ? _c("div", [_vm._m(6), _vm.insurer.arnie ? _c("span", [_vm._v("Send Request to Arnie")]) : _vm.isEstimageEnabled && !_vm.isAssessmentSubmitted ? _c("span", [_vm._v("Send Request to EstImage")]) : _c("span", [_vm._v("Request Authority")])]) : _vm._e(), _vm.isEstimageEnabled && _vm.isAssessmentSubmitted && !_vm.isAssessmentAuthorised ? _c("div", [_vm._m(7), _c("span", [_vm._v("Resend Request")])]) : _vm._e()]) : _vm._e(), !(_vm.editAuthorisedMode || _vm.editQuotedMode) && _vm.doesUserAllowedToAuthorise && (_vm.selectedAssessmentStatus === "submitted" || _vm.selectedAssessmentStatus === "draft" && !_vm.insurer.arnie && !_vm.isEstimageEnabled && _vm.isPreviousQuoteAuthorised || _vm.selectedAssessmentStatus === "authorised" && _vm.nextSelectedAssessmentStatus == "draft" && _vm.isEstimageEnabled) ? _c("a", {
    staticClass: "button is-info is-outlined tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Submit authorise"
    },
    on: {
      click: function click($event) {
        return _vm.editMode(true);
      }
    }
  }, [_vm._m(8), _vm.isAssessmentAuthorised && _vm.isEstimageEnabled ? _c("span", [_vm._v("Update Authority")]) : _c("span", [_vm._v("Authorise")])]) : _vm._e(), _vm.editAuthorisedMode ? _c("a", {
    staticClass: "button is-success tooltip is-tooltip-topright",
    attrs: {
      disabled: !_vm.hasAllItemChecked,
      "data-tooltip": "Autorise selected items"
    },
    on: {
      click: function click($event) {
        return _vm.authorise();
      }
    }
  }, [_vm._m(9), _c("span", [_vm._v("Confirm Authorise")])]) : _vm._e(), _vm.editQuotedMode && !_vm.editAuthorisedMode ? _c("a", {
    staticClass: "button is-success tooltip is-tooltip-topright",
    attrs: {
      disabled: !_vm.hasAllItemChecked,
      "data-tooltip": "Request selected items"
    },
    on: {
      click: function click($event) {
        return _vm.confirmSendRequest();
      }
    }
  }, [_vm._m(10), _c("span", [_vm._v("Confirm Send Request")])]) : _vm._e()])])])]) : _vm._e()]), _c("div", {
    staticClass: "columns mt-2"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quote Status:")]), _c("div", [_vm.selectedAssessment.isInvoiced ? _c("div", {
    staticClass: "tag is-success"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check-circle-outline"
  }), _vm._v(" Invoiced ")]) : _vm.isAssessmentAuthorised ? _c("div", {
    staticClass: "tag is-success"
  }, [_vm._v(" Authorised ")]) : _vm.isAssessmentSubmitted ? _c("div", {
    staticClass: "tag is-warning"
  }, [_vm._v(" Request Sent ")]) : _c("div", {
    staticClass: "tag",
    class: "is-".concat(_vm.$theme.name)
  }, [_vm._v(" Draft ")])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Claim Number:")]), _c("div", {
    staticClass: "control"
  }, [_vm.editAuthorisedMode ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.claimNo,
      expression: "innerValue.claimNo"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Claim No"
    },
    domProps: {
      value: _vm.innerValue.claimNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "claimNo", $event.target.value);
      }
    }
  }) : _c("div", [_vm._v(_vm._s(_vm.innerValue.claimNo))])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Date Requested:")]), _c("div", {
    staticClass: "control"
  }, [_c("div", [_vm._v(_vm._s((_vm$selectedAssessmen5 = _vm.selectedAssessment) !== null && _vm$selectedAssessmen5 !== void 0 && _vm$selectedAssessmen5.submittedAssessment ? _vm.$filters.formatDateTimezone((_vm$selectedAssessmen6 = _vm.selectedAssessment) === null || _vm$selectedAssessmen6 === void 0 || (_vm$selectedAssessmen6 = _vm$selectedAssessmen6.submittedAssessment) === null || _vm$selectedAssessmen6 === void 0 ? void 0 : _vm$selectedAssessmen6.createdDate, _vm.$userInfo.locale) : "-"))])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Date Authorised:")]), _c("div", {
    staticClass: "control"
  }, [_c("div", [_vm._v(_vm._s((_vm$selectedAssessmen7 = _vm.selectedAssessment) !== null && _vm$selectedAssessmen7 !== void 0 && _vm$selectedAssessmen7.authorisedAssessment ? _vm.$filters.formatDateTimezone((_vm$selectedAssessmen8 = _vm.selectedAssessment.authorisedDate) !== null && _vm$selectedAssessmen8 !== void 0 ? _vm$selectedAssessmen8 : (_vm$selectedAssessmen9 = _vm.selectedAssessment) === null || _vm$selectedAssessmen9 === void 0 || (_vm$selectedAssessmen9 = _vm$selectedAssessmen9.authorisedAssessment) === null || _vm$selectedAssessmen9 === void 0 ? void 0 : _vm$selectedAssessmen9.createdDate, _vm.$userInfo.locale) : "-"))])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Assessor Name:")]), _c("div", {
    staticClass: "control"
  }, [_vm.editAuthorisedMode ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedAssessment.assessorName,
      expression: "selectedAssessment.assessorName"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Assessor Name"
    },
    domProps: {
      value: _vm.selectedAssessment.assessorName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.selectedAssessment, "assessorName", $event.target.value);
      }
    }
  }) : _c("div", [_vm._v(_vm._s((_vm$selectedAssessmen0 = _vm.selectedAssessment) !== null && _vm$selectedAssessmen0 !== void 0 && _vm$selectedAssessmen0.assessorName ? _vm.selectedAssessment.assessorName : "-"))])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess Amount:")]), _c("div", {
    staticClass: "control"
  }, [_c("div", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.innerValue.excess, _vm.$userInfo.locale)))])])])])]), (_vm.editAuthorisedMode || _vm.editQuotedMode) && !_vm.isAllSelected ? _c("div", {
    staticClass: "is-fullwidth mb-3 select-all-box"
  }, [_c("div", {
    staticClass: "mr-3 ml-3 has-vertical-middle"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      value: _vm.isAllSelected
    },
    on: {
      change: _vm.onSelectAllChanged
    }
  }), _vm._m(11)])])]) : _vm._e(), _vm._l(_vm.labourCategories, function (itemType) {
    return _c("div", {
      key: itemType
    }, [itemType !== "PAINT" ? _c("authorise-labour", {
      key: _vm.selectedAssessment.assessmentID + itemType,
      staticClass: "mb-5",
      attrs: {
        value: _vm.innerValue,
        vehicle: _vm.innerVehicle,
        "assessment-items": _vm.selectedAssessmentItems,
        "item-type": itemType,
        "edit-authorised-mode": _vm.editAuthorisedMode,
        "edit-quoted-mode": _vm.editQuotedMode,
        "is-draft": _vm.selectedAssessment.isDraft,
        "select-all": _vm.isCategorySelected.find(function (i) {
          return i.itemType === itemType;
        }).selected
      },
      on: {
        "select-all-changed": _vm.onCategorySelectChange,
        "update-assessment-item": _vm.updateDraftAssessment,
        "add-assessment-item": _vm.addItemToDraftAssessment
      }
    }) : _vm._e(), itemType == "PAINT" ? _c("authorise-opg", {
      key: _vm.selectedAssessment.assessmentID + itemType,
      staticClass: "mb-5",
      attrs: {
        value: _vm.innerValue,
        vehicle: _vm.innerVehicle,
        "assessment-items": _vm.selectedAssessmentItems,
        "item-type": itemType,
        "edit-authorised-mode": _vm.editAuthorisedMode,
        "edit-quoted-mode": _vm.editQuotedMode,
        "is-draft": _vm.selectedAssessment.isDraft,
        "select-all": _vm.isCategorySelected.find(function (i) {
          return i.itemType === itemType;
        }).selected
      },
      on: {
        "select-all-changed": _vm.onCategorySelectChange,
        "update-assessment-item": _vm.updateDraftAssessment,
        "add-assessment-item": _vm.addItemToDraftAssessment
      }
    }) : _vm._e()], 1);
  }), _vm._l(_vm.partCategories, function (itemType) {
    return _c("div", {
      key: itemType
    }, [_c("authorise-part", {
      key: _vm.selectedAssessment.assessmentID + itemType,
      staticClass: "mb-5",
      attrs: {
        value: _vm.innerValue,
        vehicle: _vm.innerVehicle,
        "assessment-items": _vm.selectedAssessmentItems,
        "item-type": itemType,
        "edit-authorised-mode": _vm.editAuthorisedMode,
        "edit-quoted-mode": _vm.editQuotedMode,
        "is-draft": _vm.selectedAssessment.isDraft,
        "select-all": _vm.isCategorySelected.find(function (i) {
          return i.itemType === itemType;
        }).selected
      },
      on: {
        "select-all-changed": _vm.onCategorySelectChange,
        "update-assessment-item": _vm.updateDraftAssessment,
        "add-assessment-item": _vm.addItemToDraftAssessment
      }
    })], 1);
  }), _vm._l(_vm.miscCategories, function (itemType) {
    return _c("div", {
      key: itemType
    }, [_c("authorise-misc", {
      key: _vm.selectedAssessment.assessmentID + itemType,
      staticClass: "mb-5",
      attrs: {
        value: _vm.innerValue,
        vehicle: _vm.innerVehicle,
        "assessment-items": _vm.selectedAssessmentItems,
        "item-type": itemType,
        "edit-authorised-mode": _vm.editAuthorisedMode,
        "edit-quoted-mode": _vm.editQuotedMode,
        "is-draft": _vm.selectedAssessment.isDraft,
        "select-all": _vm.isCategorySelected.find(function (i) {
          return i.itemType === itemType;
        }).selected
      },
      on: {
        "select-all-changed": _vm.onCategorySelectChange,
        "update-assessment-item": _vm.updateDraftAssessment,
        "add-assessment-item": _vm.addItemToDraftAssessment
      }
    })], 1);
  }), _vm._l(_vm.subletCategories, function (itemType) {
    return _c("div", {
      key: itemType
    }, [_c("authorise-sublet", {
      key: _vm.selectedAssessment.assessmentID + itemType,
      staticClass: "mb-5",
      attrs: {
        value: _vm.innerValue,
        vehicle: _vm.innerVehicle,
        "assessment-items": _vm.selectedAssessmentItems,
        "item-type": itemType,
        "edit-authorised-mode": _vm.editAuthorisedMode,
        "edit-quoted-mode": _vm.editQuotedMode,
        "is-draft": _vm.selectedAssessment.isDraft,
        "select-all": _vm.isCategorySelected.find(function (i) {
          return i.itemType === itemType;
        }).selected
      },
      on: {
        "select-all-changed": _vm.onCategorySelectChange,
        "update-assessment-item": _vm.updateDraftAssessment,
        "add-assessment-item": _vm.addItemToDraftAssessment
      }
    })], 1);
  }), ((_vm$selectedAssessmen1 = _vm.selectedAssessmentItems) === null || _vm$selectedAssessmen1 === void 0 ? void 0 : _vm$selectedAssessmen1.length) === 0 ? _c("div", [_vm._m(12)]) : _vm._e()], 2)]) : _vm._e()])]), _vm.isEditRateModalVisible ? _c("edit-rates-modal", {
    attrs: {
      "show-icon": true,
      active: _vm.isEditRateModalVisible,
      "quote-values": _vm.innerValue,
      "vehicle-values": _vm.innerVehicle
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEditRateModalVisible = $event;
      },
      "apply-rates": _vm.applyRates,
      close: function close($event) {
        _vm.isEditRateModalVisible = false;
      }
    }
  }) : _vm._e(), _vm.isRequestConfirmModalVisible ? _c("confirm-modal", {
    attrs: {
      active: _vm.isRequestConfirmModalVisible,
      "ok-text": "Authorise",
      "ok-class": "is-success",
      "cancel-text": "Cancel"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRequestConfirmModalVisible = $event;
      },
      ok: function ok($event) {
        return _vm.authorise();
      },
      cancel: function cancel($event) {
        _vm.isRequestConfirmModalVisible = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Confirm to request")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Are you sure you want to request the selected items? ")])]) : _vm._e(), _vm.isRevertConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isRevertConfirmModalActive,
      "ok-text": "Revert to ".concat(_vm.lastAuthorisedQuoteLabel(_vm.selectedAssessment)),
      "ok-class": "is-danger",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRevertConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.revertToAuthority(true);
      },
      cancel: function cancel($event) {
        _vm.isRevertConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Revert to Authority")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("p", [_vm._v(" Are you sure you want to revert to the last authority? "), _c("strong", {
    staticClass: "has-text-danger"
  }, [_vm._v("All changes " + _vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)) + " will be lost.")])]), _c("br"), _c("ul", [_c("li", [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-delete"
  })]), _vm._v(" New items will be "), _c("strong", [_vm._v(" removed")]), _vm._v(". ")]), _c("li", [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-restore"
  })]), _vm._v(" Deleted items will be "), _c("strong", [_vm._v(" restored")]), _vm._v(". ")]), _c("li", [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-undo"
  })]), _vm._v(" Modified items will be "), _c("strong", [_vm._v("revert")]), _vm._v(" to original values. ")])])])]) : _vm._e(), _vm.isCancelAuthorityConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isCancelAuthorityConfirmModalActive,
      "show-close": true,
      "show-cancel": false,
      "cancel-text": "Revert to ".concat(_vm.lastAuthorisedQuoteLabel(_vm.selectedAssessment)),
      "cancel-class": "is-danger",
      "ok-class": "is-danger",
      "ok-text": "Cancel ".concat(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment), " Authority"),
      "close-text": "Close"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCancelAuthorityConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.cancelAuthority(true);
      },
      cancel: function cancel($event) {
        return _vm.cancelAuthority(false);
      },
      close: function close($event) {
        _vm.isCancelAuthorityConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Cancel last Authority")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("p", [_vm._v(" Are you sure you want to cancel "), _c("strong", [_vm._v(_vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)))]), _vm._v(" authority? ")])])]) : _vm._e(), _vm.isCancelRequestConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isCancelRequestConfirmModalActive,
      "show-close": true,
      "show-cancel": false,
      "cancel-text": "Revert to ".concat(_vm.lastAuthorisedQuoteLabel(_vm.selectedAssessment)),
      "cancel-class": "is-danger",
      "ok-class": "is-danger",
      "ok-text": "Cancel ".concat(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment), " Request"),
      "close-text": "Close"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCancelRequestConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.cancelRequest(true);
      },
      cancel: function cancel($event) {
        return _vm.cancelRequest(false);
      },
      close: function close($event) {
        _vm.isCancelRequestConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Cancel last Request")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("p", [_vm._v(" Are you sure you want to cancel "), _c("strong", [_vm._v(_vm._s(_vm.currentAuthorisedQuoteLabel(_vm.selectedAssessment)))]), _vm._v(" request? ")])])]) : _vm._e(), _vm.isConfrimManualAuthoriseModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfrimManualAuthoriseModalActive,
      "show-close": true,
      "show-cancel": false,
      "ok-class": "is-info",
      "ok-text": "Continue",
      "close-text": "Close"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfrimManualAuthoriseModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.manualSendQuoteEstImage();
      },
      close: function close($event) {
        _vm.isConfrimManualAuthoriseModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Important")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("notification-box", {
    staticClass: "mb-3",
    attrs: {
      type: "warning"
    }
  }, [_c("p", {
    staticClass: "is-size-6",
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("Please check all items in "), _c("b", [_vm._v("FlexiQuote")]), _vm._v(" and "), _c("b", [_vm._v("EstImage")]), _vm._v(" match.")])]), _c("p", [_vm._v(" Click continue to change the FlexiQuote quote status to "), _c("b", [_vm._v('"Request Sent"')]), _vm._v(". ")]), _c("p", [_c("b", [_vm._v("Please Note:")]), _vm._v(" The EstImage quote status will not be updated as the quote has already been sent in the system. ")]), _c("br")], 1)]) : _vm._e(), _vm.isSummaryModalVisible ? _c("quote-detail-assessment-summary-modal", {
    attrs: {
      "show-icon": true,
      active: _vm.isSummaryModalVisible,
      value: _vm.innerValue
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSummaryModalVisible = $event;
      },
      close: function close($event) {
        _vm.isSummaryModalVisible = false;
      }
    }
  }) : _vm._e(), _vm.isEstimageSendModalActive ? _c("est-image-send-quote-modal", {
    attrs: {
      active: _vm.isEstimageSendModalActive,
      value: _vm.innerValue,
      "modal-type": "SendQuoteWithConfirm",
      title: "Send Quote to EstImage",
      "icon-name": "mdi-upload"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEstimageSendModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeSendEstimage();
      },
      submit: _vm.sendEstImageQuote
    }
  }) : _vm._e(), _vm.isQuoteExportModalActive ? _c("quote-export-modal", {
    attrs: {
      active: _vm.isQuoteExportModalActive,
      vehicle: _vm.vehicle,
      "default-email": _vm.insurerDefaultEmail,
      "send-email-mode": true,
      assessment: _vm.selectedAssessment
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isQuoteExportModalActive = $event;
      },
      close: _vm.closeArnieSendQuoteModal,
      sent: _vm.sentToArnie
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-eye"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-undo"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-send"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-playlist-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-playlist-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-send"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", {
    staticClass: "has-text-info"
  }, [_vm._v("Select All Items")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("section", {
    staticClass: "mt-5 mb-3"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("There is no Item in this assessment.")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922 ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);



var render = function render() {
  var _vm$lastQuoteAssessme;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v(" Authorise Items ")]), _vm.isEditableToAuthorise ? _c("p", {
    staticClass: "subtitle"
  }, [_c("span", [_c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v(" Target Value: ")]), _c("span", {
    staticClass: "has-text-success has-text-weight-semibold"
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.targetValue, _vm.$userInfo.locale)) + " ")])]), _c("span", {
    staticClass: "ml-6"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v(" Value To Be Authorise: ")]), _c("span", {
    staticClass: "has-text-weight-semibold",
    class: _vm.targetValueColor
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.totalSelectedItems, _vm.$userInfo.locale)) + " ")])])]) : _vm._e(), _vm.isEditable ? _c("div", [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.allItemSelected,
      expression: "allItemSelected"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.allItemSelected) ? _vm._i(_vm.allItemSelected, null) > -1 : _vm.allItemSelected
    },
    on: {
      change: function change($event) {
        var $$a = _vm.allItemSelected,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.allItemSelected = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.allItemSelected = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.allItemSelected = $$c;
        }
      }
    }
  }), _vm._m(0)]), !_vm.allItemSelected && _vm.isEditableToAuthorise ? _c("p", {
    staticClass: "has-text-danger is-size-7"
  }, [_vm._v(" Please select all items for authorise. ")]) : _vm._e()]) : _vm._e()]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field mr-2"
  }, [_c("div", {
    staticClass: "buttons"
  }, [_vm.hasAssessment && !_vm.isEditable && _vm.requestAuthorityPending ? _c("button", {
    staticClass: "button is-secondary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Cancel the last request to authority"
    },
    on: {
      click: function click($event) {
        return _vm.openCancelRequestConfirmModal();
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Cancel Request")])]) : _vm._e(), _vm.hasAssessment && !_vm.isEditable && !_vm.requestAuthorityPending ? _c("button", {
    staticClass: "button is-secondary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Cancel the last authority"
    },
    on: {
      click: function click($event) {
        return _vm.openCancelAuthorityConfirmModal();
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("Cancel Authority")])]) : _vm._e(), _vm.hasAssessment && !_vm.isEditable && !_vm.requestAuthorityPending && _vm.allActiveItems.length > 0 ? _c("button", {
    staticClass: "button is-secondary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Revert to last authority"
    },
    on: {
      click: function click($event) {
        return _vm.openRevertConfirmModal();
      }
    }
  }, [_vm._m(3), _c("span", [_vm._v("Revert to Authority")])]) : _vm._e(), _vm.isEditable ? _c("button", {
    staticClass: "button is-secondary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_vm._m(4), _c("span", [_vm._v("Cancel")])]) : _vm._e(), !_vm.isEditable && !_vm.requestAuthorityPending && _vm.allActiveItems.length > 0 ? _c("button", {
    staticClass: "button is-info is-outlined tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Submit request"
    },
    on: {
      click: function click($event) {
        return _vm.editableQuote(false);
      }
    }
  }, [_vm._m(5), _c("span", [_vm._v("Request Authority")])]) : _vm._e(), !_vm.isEditable ? _c("button", {
    staticClass: "button is-info is-outlined tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Submit authorise"
    },
    on: {
      click: function click($event) {
        return _vm.editableQuote(true);
      }
    }
  }, [_vm._m(6), _c("span", [_vm._v("Authorise")])]) : _vm._e(), _vm.isEditable && _vm.isEditableToAuthorise ? _c("button", {
    staticClass: "button is-success tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.allItemSelected === false && _vm.hasPendingRequest || _vm.selectedItems.length === 0,
      "data-tooltip": "Autorise selected items"
    },
    on: {
      click: function click($event) {
        return _vm.openAuthoriseModal();
      }
    }
  }, [_vm._m(7), _c("span", [_vm._v("Confirm Authorise")])]) : _vm._e(), _vm.isEditable && !_vm.isEditableToAuthorise ? _c("button", {
    staticClass: "button is-success tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.selectedItems.length === 0,
      "data-tooltip": "Request selected items"
    },
    on: {
      click: _vm.request
    }
  }, [_vm._m(8), _c("span", [_vm._v("Confirm Request Authority")])]) : _vm._e()])])])])])]), _c("div", {
    staticClass: "tabs is-boxed"
  }, [_c("ul", [_c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("RR"),
      expression: "showTab('RR')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.RR
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.RR);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("R&R")]), _vm.rrItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.rrItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("RWA"),
      expression: "showTab('RWA')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.RWA
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.RWA);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("RWA")]), _vm.rwaItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.rwaItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("REP"),
      expression: "showTab('REP')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.REP
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.REP);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Repair")]), _vm.repairItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.repairItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("PAINT"),
      expression: "showTab('PAINT')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.PAINT
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.PAINT);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Paint")]), _vm.paintItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.paintItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("FIBER"),
      expression: "showTab('FIBER')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.FIBER
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.FIBER);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Fiber")]), _vm.fgItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.fgItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("CRUSH"),
      expression: "showTab('CRUSH')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.CRUSH
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.CRUSH);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Crush")]), _vm.crushItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.crushItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("CD"),
      expression: "showTab('CD')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.CD
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.CD);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("C&D")]), _vm.cdItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.cdItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("MECH"),
      expression: "showTab('MECH')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.MECH
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.MECH);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Mech")]), _vm.mechItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.mechItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("PART"),
      expression: "showTab('PART')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.PART
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.PART);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Part")]), _vm.partItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.partItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("OPG"),
      expression: "showTab('OPG')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.OPG
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.OPG);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("OPG")]), _vm.opgItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.opgItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("MISC"),
      expression: "showTab('MISC')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.MISC
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.MISC);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Misc")]), _vm.miscItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.miscItems.length
    }
  }) : _vm._e()])])]), _c("li", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showTab("SUBL"),
      expression: "showTab('SUBL')"
    }],
    class: {
      "is-active": _vm.activeTab === _vm.itemCategoryTypes.SUBL
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.itemCategoryTypes.SUBL);
      }
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Sublet")]), _vm.subletItems.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.subletItems.length
    }
  }) : _vm._e()])])])]), _vm.isEditableToAuthorise && (((_vm$lastQuoteAssessme = _vm.lastQuoteAssessment) === null || _vm$lastQuoteAssessme === void 0 ? void 0 : _vm$lastQuoteAssessme.subQuoteNo) === 0 && _vm.requestAuthorityPending || _vm.lastQuoteAssessment === null) ? _c("button", {
    staticClass: "button is-primary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Edit rates"
    },
    on: {
      click: _vm.openEditRatesModal
    }
  }, [_vm._m(9), _c("span", [_vm._v("Edit Rates")])]) : _vm._e()]), _vm.isLabour ? _c("authorise-labour-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.rrItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.rwaItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.repairItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.paintItems))
    }
  }) : _vm._e(), _vm.isOtherLabour ? _c("authorise-other-labour-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.mechItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.cdItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.crushItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.fgItems))
    }
  }) : _vm._e(), _vm.isPart ? _c("authorise-part-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.partItems)
    }
  }) : _vm._e(), _vm.isOpg ? _c("authorise-opg-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.opgItems)
    }
  }) : _vm._e(), _vm.isMisc ? _c("authorise-misc-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.miscItems)
    }
  }) : _vm._e(), _vm.isSublet ? _c("authorise-sublet-old", {
    attrs: {
      value: _vm.innerValue,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.innerValue.lines,
      "original-value": _vm.value,
      editable: _vm.isEditable,
      "item-type": _vm.activeTab,
      "items-list": Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_vm.subletItems)
    }
  }) : _vm._e()], 1)])])])]), _vm.isAuthoriseModalVisible ? _c("authorise-modal", {
    attrs: {
      "show-icon": true,
      active: _vm.isAuthoriseModalVisible,
      "quote-values": _vm.innerValue,
      "vehicle-values": _vm.innerVehicle,
      "selected-items": _vm.selectedItems,
      "total-selected-items": _vm.totalSelectedItems
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isAuthoriseModalVisible = $event;
      },
      authorise: function authorise($event) {
        return _vm.authorise();
      },
      close: function close($event) {
        _vm.isAuthoriseModalVisible = false;
      }
    }
  }) : _vm._e(), _vm.isEditRateModalVisible ? _c("edit-rates-modal", {
    attrs: {
      "show-icon": true,
      active: _vm.isEditRateModalVisible,
      "quote-values": _vm.innerValue,
      "vehicle-values": _vm.innerVehicle,
      "selected-items": _vm.selectedItems,
      "total-selected-items": _vm.totalSelectedItems
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEditRateModalVisible = $event;
      },
      "apply-rates": function applyRates($event) {
        return _vm.applyRates();
      },
      close: function close($event) {
        _vm.isEditRateModalVisible = false;
      }
    }
  }) : _vm._e(), _vm.isRequestModalVisible ? _c("confirm-modal", {
    attrs: {
      active: _vm.isRequestModalVisible,
      "ok-text": "Authorise",
      "ok-class": "is-success",
      "cancel-text": "Cancel"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRequestModalVisible = $event;
      },
      ok: function ok($event) {
        return _vm.authorise();
      },
      cancel: function cancel($event) {
        _vm.isRequestModalVisible = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Confirm to request")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Are you sure you want to request the selected items? ")])]) : _vm._e(), _vm.isRevertConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isRevertConfirmModalActive,
      "ok-text": "Revert to Authority",
      "ok-class": "is-success",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRevertConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.revertToAuthority(true);
      },
      cancel: function cancel($event) {
        _vm.isRevertConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Revert to Authority")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Are you sure you want to revert to the last authority? All changes since the last authority will be lost. ")])]) : _vm._e(), _vm.isCancelAuthorityConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isCancelAuthorityConfirmModalActive,
      "show-close": true,
      "cancel-text": "Discard Changes",
      "cancel-class": "is-warning",
      "ok-class": "is-success",
      "ok-text": "Merge Changes",
      "close-text": "Close"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCancelAuthorityConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.cancelAuthority(true);
      },
      cancel: function cancel($event) {
        return _vm.cancelAuthority(false);
      },
      close: function close($event) {
        _vm.isCancelAuthorityConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Cancel last Authority")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Do you want the changes made in the last authority to be merged or discarded? ")])]) : _vm._e(), _vm.isCancelRequestConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isCancelRequestConfirmModalActive,
      "show-close": true,
      "cancel-text": "Discard Changes",
      "cancel-class": "is-warning",
      "ok-class": "is-success",
      "ok-text": "Merge Changes",
      "close-text": "Close"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCancelRequestConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.cancelRequest(true);
      },
      cancel: function cancel($event) {
        return _vm.cancelRequest(false);
      },
      close: function close($event) {
        _vm.isCancelRequestConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Cancel last Request")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Do you want the changes made in the last request for authority to be merged or discarded? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", {
    staticClass: "has-text-info has-text-weight-semibold"
  }, [_vm._v("Select All Items")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-undo"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-send"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-playlist-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-playlist-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-send"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.noti-warning {\n  border: 1px solid #f9bf00;\n  border-radius: 4px;\n  /* background-color: #fffcf2; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-danger {\n  border: 2px solid #d73654;\n  border-radius: 4px;\n  /* background-color: #fff6f8; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-primary {\n  border: 2px solid #3291ef;\n  border-radius: 4px;\n  /* background-color: #f0f8ff; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default {\n  border: 1px solid #dbdbdb;\n  border-radius: 4px;\n  background-color: #f5f5f5;\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default.is-dark {\n  border-color: #4a4a4a;\n  background-color: #363636;\n}\n\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".tabs[data-v-7e8cd838] {\n  margin-bottom: 0;\n}\n.tab-disabled[data-v-7e8cd838] {\n  pointer-events: none;\n  cursor: default;\n  opacity: 0.5;\n}\n.tag[data-v-7e8cd838] {\n  border-radius: 10rem !important;\n}\n.tag .icon[data-v-7e8cd838] {\n  padding-left: 0.4rem;\n  padding-right: 0.4rem;\n}\n.select-all-box[data-v-7e8cd838] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  border: 1px solid hsl(204, 86%, 53%);\n  border-radius: 5px;\n  height: 3rem;\n}\n.is-gray[data-v-7e8cd838] {\n  background-color: #9c9c9c;\n  color: #fff;\n}\na.is-transparent[data-v-7e8cd838] {\n  background-color: transparent;\n  border: 1px solid;\n}\nbutton.title-align[data-v-7e8cd838] {\n  vertical-align: text-bottom;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7386d66a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("1a59004c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue":
/*!*********************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=template&id=dc876468 */ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony import */ var _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=script&lang=js */ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Notification/NotificationBox.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!*****************************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!***************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=template&id=dc876468 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/AuthoriseView.vue":
/*!*******************************************!*\
  !*** ./src/views/quote/AuthoriseView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true */ "./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true");
/* harmony import */ var _AuthoriseView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AuthoriseView.vue?vue&type=script&lang=js */ "./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true */ "./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AuthoriseView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7e8cd838",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/AuthoriseView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthoriseView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=style&index=0&id=7e8cd838&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_style_index_0_id_7e8cd838_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true":
/*!*************************************************************************************!*\
  !*** ./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/AuthoriseView.vue?vue&type=template&id=7e8cd838&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthoriseView_vue_vue_type_template_id_7e8cd838_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteItemsAuthorise.vue":
/*!*************************************************!*\
  !*** ./src/views/quote/QuoteItemsAuthorise.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteItemsAuthorise.vue?vue&type=template&id=b718a922 */ "./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922");
/* harmony import */ var _QuoteItemsAuthorise_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteItemsAuthorise.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteItemsAuthorise_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteItemsAuthorise.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteItemsAuthorise_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteItemsAuthorise.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteItemsAuthorise_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922":
/*!*******************************************************************************!*\
  !*** ./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922 ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteItemsAuthorise.vue?vue&type=template&id=b718a922 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteItemsAuthorise.vue?vue&type=template&id=b718a922");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteItemsAuthorise_vue_vue_type_template_id_b718a922__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/storeMixin.js":
/*!***************************************!*\
  !*** ./src/views/quote/storeMixin.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");













var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  created: function created() {
    this.getCompanyItemTypes();
    this.getJobStages(); // Store job stages in vuex
    // this.getExternalSetting('partscheck')
    //this.getSubJobStages() // Store job stages in vuex
    this.getJobNSubJobStages();
    this.getExternalSetting('partscheck');
    // if (this.$route.name !== QuoteRoutes.QuoteListView.name && this.value) {
    //   console.log('get vvvv')
    //   this.getQuoteVehicle(this.value.vehicleId)
    // }
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    companyItemTypes: 'companyItemTypes',
    currentVehicleSnapshot: 'currentVehicleSnapshot',
    currentCustomerSnapshot: 'currentCustomerSnapshot',
    currentInsurerSnapshot: 'currentInsurerSnapshot',
    quoteVehicle: 'quoteVehicle',
    quoteCustomer: 'quoteCustomer',
    quoteInsurer: 'quoteInsurer',
    emtaVehicleStore: 'emtaVehicle',
    standardLabourItems: 'standardLabourItems',
    ntarLoadingItems: 'ntarLoadingItems',
    ntarOtherLoadingItems: 'ntarOtherLoadingItems',
    ntarLoadingValues: 'ntarLoadingValues',
    jobStages: 'jobStages',
    subJobStages: 'subJobStages',
    jobNSubJobStages: 'jobNSubJobStages',
    repairDelayReasons: 'repairDelayReasons',
    partsCheckSettingExists: 'partsCheckSettingExists',
    readOnlyView: 'readOnlyView',
    previousQuoteId: 'previousQuoteId',
    audanetLock: 'audanetLock',
    snapshotDiffVehicle: 'snapshotDiffVehicle',
    snapshotDiffCustomer: 'snapshotDiffCustomer',
    snapshotDiffInsurer: 'snapshotDiffInsurer',
    partsCheckSetting: 'partsCheckSetting'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])(moduleName, ['load', 'getStoreItem', 'getLiteStoreItem', 'addStoreItem', 'addStoreSupplementaryItem', 'saveSnapshot', 'setBaseSnapshot', 'setBaseSnapshotFields', 'clearSnapshots', 'clearHeaders', 'setReturnRoute', 'getCompanyItemTypes', 'getQuoteVehicle', 'getNewVehicle', 'removeQuoteVehicle', 'getQuoteCustomer', 'getNewCustomer', 'removeQuoteCustomer', 'getEmtaVehicle', 'setEmtaVehicle', 'resetEmtaVehicle', 'clearInvoiceState', 'copyStoreQuote', 'getQuoteInsurer', 'getNewInsurer', 'setQuoteInsurer', 'removeQuoteInsurer', 'getStandardLabourItems', 'getNtarLoadingItems', 'getNtarOtherLoadingItems', 'removeLabourItems', 'getNtarLoadingValues', 'getJobStages', 'getSubJobStages', 'getJobNSubJobStages', 'removeJobStages', 'getExternalSetting', 'setReadOnlyView', 'setPreviousQuoteId', 'setAudaNetLock', 'setQuoteVehicle', 'saveVehicleSnapshot', 'saveCustomerSnapshot', 'saveInsurerSnapshot', 'resetJobNSubJobStages'])), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('insurers', {
    setInsurerReturnRoute: 'setReturnRoute',
    editStoreInsurer: 'editStoreItem',
    addStoreInsurer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('vehicles', {
    setVehicleReturnRoute: 'setReturnRoute',
    editStoreVehicle: 'editStoreItem',
    addStoreVehicle: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  })),
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(to, from, next) {
      var isQuoteRoutes;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            // remove quote vehicle, customer & insurer vuex objects when leaving quote pages
            isQuoteRoutes = Object.values(_route_types__WEBPACK_IMPORTED_MODULE_12__["default"]).filter(function (r) {
              return r.name !== _route_types__WEBPACK_IMPORTED_MODULE_12__["default"].QuoteListView.name;
            }).find(function (r) {
              return r.name === to.name;
            });
            if (!isQuoteRoutes) {
              this.resetEmtaVehicle();
              this.removeLabourItems();
            }
            next();
          case 1:
            return _context.a(2);
        }
      }, _callee, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ })

}]);
//# sourceMappingURL=quote-item-overview-chunk.js.map