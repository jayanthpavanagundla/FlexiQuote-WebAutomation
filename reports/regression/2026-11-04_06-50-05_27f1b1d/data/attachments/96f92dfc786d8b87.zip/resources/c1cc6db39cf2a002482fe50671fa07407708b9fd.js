(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["unscheduledmodel-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./UnscheduledModelService */ "./src/views/unscheduledmodel/UnscheduledModelService.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./storeMixin */ "./src/views/unscheduledmodel/storeMixin.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UnscheduledmodelDetail',
  inject: ['$vv'],
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_14___default.a
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_16__["FocusInserted"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_17__["default"]],
  props: {
    value: null,
    isNew: Boolean
  },
  data: function data() {
    return {
      months: {
        1: '01',
        2: '02',
        3: '03',
        4: '04',
        5: '05',
        6: '06',
        7: '07',
        8: '08',
        9: '09',
        10: '10',
        11: '11',
        12: '12'
      },
      pickBodyStyles: [],
      makes: [],
      selectedMake: null,
      isMakeLoading: false,
      makeFilter: {
        make: '',
        pageIndex: 1,
        pageSize: 50
      }
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    bodyStyles: function bodyStyles() {
      return this.storeBodyShapes;
    },
    picked: function picked() {
      return this.pickBodyStyles.filter(function (d) {
        return d.selected;
      }).length;
    },
    selectedBodies: function selectedBodies() {
      return this.pickBodyStyles.filter(function (d) {
        return d.selected;
      }).map(function (d) {
        return d.id;
      });
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    selectedBodies: {
      handler: function handler(newVal, oldVal) {
        var strBodies = '';
        for (var i = 0; i < newVal.length; i++) {
          strBodies = strBodies + newVal[i];
        }
        this.value.bodies = strBodies;
      },
      deep: true
    }
  },
  created: function created() {
    this.makeFilter.make = this.value.make;
    this.getMakeDropdown();
    this.pickBodyStyles = this.bodyStyles.map(function (d) {
      return {
        id: d.id,
        name: d.name
      };
    });
  },
  mounted: function mounted() {
    var _this = this;
    this.$v.detailGroup.$touch();
    if (!this.value.isNew && this.value.bodies != null) {
      this.pickBodyStyles = this.bodyStyles.map(function (d) {
        return {
          selected: _this.value.bodies.indexOf(d.id) > -1,
          id: d.id,
          name: d.name
        };
      });
    }
  },
  methods: {
    checkStartYear: function checkStartYear(e) {
      this.value.startYear = this.getYear(e.target.value);
    },
    checkEndYear: function checkEndYear(e) {
      this.value.endYear = this.getYear(e.target.value);
    },
    getYear: function getYear(year) {
      if (year.length < 4) {
        var strYear = "01/01/".concat(year);
        var newDate = new Date(strYear);
        return newDate.getFullYear();
      } else {
        return year;
      }
    },
    toggleActive: function toggleActive(active) {
      this.value.active = active;
      if (!active) {
        this.checkInUse();
      }
    },
    checkInUse: function checkInUse() {
      this.$emit('entityDelete');
    },
    getMakeDropdown: function getMakeDropdown() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var findMake, tag;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this2.isMakeLoading = true;
              _context.n = 1;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_13__["default"].getMakeDropdownProto(_this2.makeFilter);
            case 1:
              _this2.makes = _context.v;
              if (_this2.makeFilter.make !== '') {
                findMake = _this2.makes.find(function (c) {
                  return c.make === _this2.value.make.toUpperCase();
                });
                if (findMake != null) {
                  _this2.selectedMake = findMake;
                } else {
                  // edit for inactive model when make is not in dropdown (only active Make will display in the dropdown)
                  tag = {
                    rowNumber: 1,
                    make: _this2.makeFilter.make,
                    totalRows: 1
                  };
                  _this2.makes.splice(0, 0, tag);
                  _this2.makeFilter.make = tag.make;
                  _this2.selectedMake = tag;
                }
              }
              _this2.isMakeLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getMakeDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_12___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(query) {
        var findMake, tag;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.isMakeLoading = true;
              if (query != '') {
                this.makeFilter.make = query;
              }
              _context2.n = 1;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_13__["default"].getMakeDropdownProto(this.makeFilter);
            case 1:
              this.makes = _context2.v;
              findMake = this.makes.find(function (c) {
                return c.make === query.toUpperCase();
              });
              if (this.makes == '' || findMake == null) {
                tag = {
                  rowNumber: 0,
                  make: this.makeFilter.make.toUpperCase(),
                  totalRows: 0
                }; // this.makes.push(tag)
                this.makes.splice(0, 0, tag); // insert the item to array at first
                this.value.make = tag.make;
                this.makeFilter.make = tag.make;
              }
              this.isMakeLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectMake: function selectMake(selected) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.value.make = selected.make;
              _this3.makeFilter.make = selected.make;
              _context3.n = 1;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_13__["default"].getMakeDropdownProto(_this3.makeFilter);
            case 1:
              _this3.make = _context3.v;
              _this3.$v.entity.make.$touch();
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    removeMake: function removeMake() {
      this.makeFilter.make = '';
      this.value.make = '';
      this.$v.entity.make.$touch();
      this.getMakeDropdown();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/unscheduledmodel/route-types.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UnscheduledmodelSideMenu',
  inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_1__["default"];
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _UnscheduledModelSideMenu__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./UnscheduledModelSideMenu */ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue");
/* harmony import */ var _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./UnscheduledModelService */ "./src/views/unscheduledmodel/UnscheduledModelService.js");
/* harmony import */ var _UnscheduledModelValidation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./UnscheduledModelValidation */ "./src/views/unscheduledmodel/UnscheduledModelValidation.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./route-types */ "./src/views/unscheduledmodel/route-types.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./storeMixin */ "./src/views/unscheduledmodel/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UnscheduledModelView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__["default"]
  }, _UnscheduledModelSideMenu__WEBPACK_IMPORTED_MODULE_16__["default"].name, _UnscheduledModelSideMenu__WEBPACK_IMPORTED_MODULE_16__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["UnsavedModal"]), "SaveConflictModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["SaveConflictModal"]), "ConfirmModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["ConfirmModal"]),
  mixins: [_UnscheduledModelValidation__WEBPACK_IMPORTED_MODULE_18__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_25__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      deleteAndSave: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null // stores "to" route of beforeRouteLeave
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error;
    },
    entityName: function entityName() {
      return this.entity.model;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_27___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(this.entity));
        }
      }, 500),
      deep: true
    }
  },
  beforeDestroy: function beforeDestroy() {
    // this.clearSessionStorage()
    // this.clearSnapshots(this.entity.modelCustomId)
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.returnUrl) {
              _this.persistQueries();
              _this.replaceRoute(_this.$route.params.modelCustomId);
            }
            _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Print:
          this.print1();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Delete:
          this.deleteAndSave = true;
          this.deleteEntity(true, false, true);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.modelCustomId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.modelCustomId);
            case 2:
              _this2.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this2.currentSnapshot);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('', _t);
            case 4:
              _this2.$hideSpinner();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var title, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              title = 'Unscheduled Model';
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context3.a(2, false);
            case 1:
              _this3.snapshotDiff;
              _context3.p = 2;
              _this3.$showSpinner('Saving...');
              _this3.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this3.entity));
              if (!_this3.entity.isNew) {
                _context3.n = 4;
                break;
              }
              _context3.n = 3;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_17__["default"].postUnscheduledModel(_this3.entity);
            case 3:
              _context3.n = 7;
              break;
            case 4:
              if (!_this3.snapshotDiff) {
                _context3.n = 6;
                break;
              }
              _context3.n = 5;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_17__["default"].putUnscheduledModel(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this3.entity), _this3.snapshotDiff);
            case 5:
              _context3.n = 7;
              break;
            case 6:
              _this3.$notification.openNotificationWithType('warning', title, 'No changes detected. Not saved');
              return _context3.a(2, false);
            case 7:
              // await this.removeStoreItem(this.entity.id)
              _this3.$notification.success('Unscheduled Model', isDelete ? 'Unscheduled Model set to In-Active' : 'Save successful');
              if (_this3.isSaveContinue) {
                _context3.n = 8;
                break;
              }
              _context3.n = 8;
              return _this3.getEntity(true);
            case 8:
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 9:
              _context3.p = 9;
              _t2 = _context3.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_23__["default"].$emit('serviceError', _t2.response.status);
              if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_22__["default"].CONFLICT) {
                _this3.isSaveConflictModalActive = true;
              } else {
                _this3.$notification.openMessageXhrError('Unscheduled Model', _t2);
              }
              return _context3.a(2, false);
            case 10:
              _context3.p = 10;
              _this3.$hideSpinner();
              return _context3.f(10);
            case 11:
              return _context3.a(2);
          }
        }, _callee3, null, [[2, 9, 10, 11]]);
      }))();
    },
    deleteEntity: function deleteEntity(check, value, saveEntity) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var isInUse, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isConfirmModalActive = false;
              if (!check) {
                _context4.n = 2;
                break;
              }
              _context4.n = 1;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_17__["default"].assertUsed(_this4.entity.modelCustomId);
            case 1:
              _t3 = _context4.v;
              _context4.n = 3;
              break;
            case 2:
              _t3 = false;
            case 3:
              isInUse = _t3;
              if (isInUse) {
                _this4.isConfirmModalActive = true;
              } else {
                _this4.entity.active = value;
                if (saveEntity) {
                  _this4.save(true);
                }
              }
            case 4:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    onEntityDelete: function onEntityDelete() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var isInUse;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.deleteAndSave = false;
              _context5.n = 1;
              return _UnscheduledModelService__WEBPACK_IMPORTED_MODULE_17__["default"].assertUsed(_this5.entity.modelCustomId);
            case 1:
              isInUse = _context5.v;
              if (isInUse) {
                _this5.isConfirmModalActive = true;
              }
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(this.entity));
      if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28___default()(this.returnRoute)) {
        this.$router.push({
          path: this.returnRoute.path,
          query: this.returnRoute.query
        });
      } else if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        // const returnUrl = sessionStorage.getItem(this.returnUrlKey)
        // if it comes from url => redirect after save
        if (this.returnUrl) {
          if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
            this.isUnsavedModalActive = true;
          } else {
            this.clearSessionStorage();
            this.clearSnapshots(this.entity.id);
            this.$showSpinner('Returning...');
            this.redirectToQueryUrl(this.returnUrl);
          }
        } else {
          if (this.entity.isNew && this.isSkipSave) {
            // cleanup vuex store
            this.clearSnapshots(this.entity.id);
          }
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_19__["default"].UnscheduledModelListView.name,
            filter: this.filter,
            query: {
              filter: this.encodedFilter
            }
          });
        }
      }
    },
    print: function print() {
      var params = {
        reportname: 'rptUnscheduledModelDetail',
        ModelCustomID: this.entity.modelCustomId,
        CompanyID: this.$userInfo.companyId
      };
      var url = "".concat("", "/modules/reports/printpreview.aspx?") + Object.keys(params).map(function (e) {
        return "".concat(e, "=").concat(params[e]);
      }).join('&');
      window.open(url, '_blank');
    },
    saveContinue: function saveContinue() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isUnsavedModalActive = false;
              _this6.isSaveContinue = true;
              _context6.n = 1;
              return _this6.save();
            case 1:
              _this6.isSaveContinue = _context6.v;
              if (_this6.isSaveContinue) {
                _this6.cancel();
              }
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    print1: function print1() {
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        ModelCustomID: this.entity.modelCustomId
      });
      // const query = this.$lzstring.compressToEncodedURIComponent(
      //   Object.keys(params)
      //     .map(e => `${e}=${params[e]}`)
      //     .join('&')
      // )
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_31__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_30__["Emailer"]();
      var makemodel = "".concat(this.entity.make) + ' ' + "".concat(this.entity.model);
      emailer.assetId = this.entity.modelCustomId;
      emailer.subject = 'Unscheduled Model Details - ' + makemodel;
      emailer.reportName = makemodel;
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
      // window.open(printPreviewRoute.href, '_blank')
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
      this.toRoute = null;
    },
    reloadData: function reloadData() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this7.isSaveConflictModalActive = false;
              _this7.isSaveContinue = false;
              _context7.n = 1;
              return _this7.getEntity(true);
            case 1:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|unscheduledmodel|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|unscheduledmodel|type"), this.type);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|unscheduledmodel|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|unscheduledmodel|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_19__["default"].UnscheduledModelDetail.name,
        params: {
          modelCustomId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(this.entity));
    if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entity.modelCustomId);
      this.clearSessionStorage();
      this.clearRouteMeta();
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent is-8"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info")]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Make")]), _c("div", {
    staticClass: "control is-expanded desc-width"
  }, [_c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.make.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "make",
      label: "make",
      options: _vm.makes,
      loading: _vm.isMakeLoading,
      "internal-search": false,
      "options-limit": _vm.makeFilter.pageSize,
      placeholder: "Search or Add Make",
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectMake,
      remove: _vm.removeMake,
      "search-change": _vm.getMakeDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", [_vm._v(_vm._s(props.option.make))])];
      }
    }]),
    model: {
      value: _vm.selectedMake,
      callback: function callback($$v) {
        _vm.selectedMake = $$v;
      },
      expression: "selectedMake"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Make not found.")])]), _vm.$v.entity && _vm.$v.entity.make.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Make is required.")]) : _vm._e()], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Model")]), _c("div", {
    staticClass: "control desc-width"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.model,
      expression: "value.model"
    }],
    staticClass: "input is-capitalized",
    class: {
      "is-danger": _vm.$v.entity.model.$error
    },
    attrs: {
      name: "model",
      type: "text",
      placeholder: "Model",
      maxlength: "100"
    },
    domProps: {
      value: _vm.value.model
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "model", $event.target.value);
      }
    }
  }), _vm.$v.entity && !_vm.$v.entity.model.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Model is required.")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Cylinders")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      precision: 0,
      maxlength: "8"
    },
    model: {
      value: _vm.value.cylinders,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "cylinders", _vm._n($$v));
      },
      expression: "value.cylinders"
    }
  })], 1)])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Production Year")]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons"
  }, [_vm._m(0), _c("p", {
    staticClass: "control"
  }, [_c("span", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.startMonth,
      expression: "value.startMonth"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "startMonth", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("MM")]), _vm._l(_vm.months, function (m, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: key
      }
    }, [_vm._v(_vm._s(m))]);
  })], 2)])]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 2000",
      mask: ["####"]
    },
    nativeOn: {
      blur: function blur($event) {
        return _vm.checkStartYear.apply(null, arguments);
      }
    },
    model: {
      value: _vm.value.startYear,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "startYear", $$v);
      },
      expression: "value.startYear"
    }
  })], 1), _vm._m(1), _c("p", {
    staticClass: "control"
  }, [_c("span", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.endMonth,
      expression: "value.endMonth"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "endMonth", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("MM")]), _vm._l(_vm.months, function (m, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: key
      }
    }, [_vm._v(_vm._s(m))]);
  })], 2)])]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 2000",
      mask: ["####"]
    },
    nativeOn: {
      blur: function blur($event) {
        return _vm.checkEndYear.apply(null, arguments);
      }
    },
    model: {
      value: _vm.value.endYear,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "endYear", $$v);
      },
      expression: "value.endYear"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": _vm.value.active
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": !_vm.value.active
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(3), _c("span", [_vm._v("In-Active")])])])])])]), _c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Body Styles")]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Bodies   "), _c("small", [_vm._v("(" + _vm._s(_vm.picked) + "/" + _vm._s(_vm.pickBodyStyles.length) + " Selected)")])])]), _vm.$v.entity && !_vm.$v.entity.bodies.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Bodies is required")]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("ul", _vm._l(_vm.pickBodyStyles, function (b, index) {
    return _c("li", {
      key: index
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: b.selected,
        expression: "b.selected"
      }],
      staticClass: "is-checkradio",
      attrs: {
        type: "checkbox",
        id: index
      },
      domProps: {
        checked: Array.isArray(b.selected) ? _vm._i(b.selected, null) > -1 : b.selected
      },
      on: {
        change: function change($event) {
          var $$a = b.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(b, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(b, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(b, "selected", $$c);
          }
        }
      }
    }), _c("label", {
      attrs: {
        for: index
      }
    }, [_vm._v(_vm._s(b.name))])]);
  }), 0)])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-static",
    attrs: {
      disabled: ""
    }
  }, [_vm._v("From")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-static",
    attrs: {
      disabled: ""
    }
  }, [_vm._v("To")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" " + _vm._s(_vm.entityName) + " ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.UnscheduledModelDetail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.detailGroup.$error ? "" : null
    }
  }, [_vm._v(" Detail Info ")])])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.entity && !_vm.entity.isNew,
      "show-delete": _vm.entity && _vm.entity.active && !_vm.entity.isNew,
      "menu-code-name": _vm.$route.meta.id
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("unscheduledmodel-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": _vm.entityName
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name
    },
    on: {
      entityDelete: function entityDelete($event) {
        return _vm.onEntityDelete();
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(false, false, _vm.deleteAndSave);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false, true, false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unscheduled Model is in use")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.entityName))]), _vm._v(" is in use. Set to "), _c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v("In-Active")]), _vm._v(" anyway? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-7612b2d6] {\n  margin: 1.2em 0;\n}\n.desc-width[data-v-7612b2d6] {\n  width: 60%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("1fc01cc2", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue":
/*!***************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelDetail.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true */ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true");
/* harmony import */ var _UnscheduledModelDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UnscheduledModelDetail.vue?vue&type=script&lang=js */ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true */ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _UnscheduledModelDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7612b2d6",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/unscheduledmodel/UnscheduledModelDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js":
/*!***************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true":
/*!************************************************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=style&index=0&id=7612b2d6&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_style_index_0_id_7612b2d6_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelDetail.vue?vue&type=template&id=7612b2d6&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelDetail_vue_vue_type_template_id_7612b2d6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue":
/*!*****************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca */ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca");
/* harmony import */ var _UnscheduledModelSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UnscheduledModelSideMenu.vue?vue&type=script&lang=js */ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UnscheduledModelSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/unscheduledmodel/UnscheduledModelSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca":
/*!***********************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelSideMenu.vue?vue&type=template&id=a479e7ca");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelSideMenu_vue_vue_type_template_id_a479e7ca__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelValidation.js":
/*!******************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelValidation.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.make', 'entity.model', 'entity.bodies'],
    entity: {
      make: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(20)
      },
      model: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(100)
      },
      bodies: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(12)
      }
    },
    filter: {}
  }
});

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelView.vue":
/*!*************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelView.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UnscheduledModelView.vue?vue&type=template&id=49cbc26a */ "./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a");
/* harmony import */ var _UnscheduledModelView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UnscheduledModelView.vue?vue&type=script&lang=js */ "./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UnscheduledModelView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/unscheduledmodel/UnscheduledModelView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a":
/*!*******************************************************************************************!*\
  !*** ./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UnscheduledModelView.vue?vue&type=template&id=49cbc26a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/unscheduledmodel/UnscheduledModelView.vue?vue&type=template&id=49cbc26a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UnscheduledModelView_vue_vue_type_template_id_49cbc26a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/unscheduledmodel/storeMixin.js":
/*!**************************************************!*\
  !*** ./src/views/unscheduledmodel/storeMixin.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'unscheduledmodels';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])('vehicleOptions', {
    storeBodyShapes: 'bodyShapes',
    storeColours: 'colours',
    storePaintGroups: 'paintGroups'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('vehicleOptions', ['refreshColour'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=unscheduledmodel-chunk.js.map