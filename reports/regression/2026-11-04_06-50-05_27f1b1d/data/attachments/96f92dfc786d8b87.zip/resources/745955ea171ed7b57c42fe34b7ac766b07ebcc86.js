(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bankundepositedfund-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _BankUndepositedFundService__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./BankUndepositedFundService */ "./src/views/bankundepositedfund/BankUndepositedFundService.js");
/* harmony import */ var _BankUndepositedFundSummary__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./BankUndepositedFundSummary */ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./columns */ "./src/views/bankundepositedfund/columns.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_23__);
























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BankUndepositedFundDetail',
  inject: ['$vv'],
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_21__["default"],
    BankUndepositedFundSummary: _BankUndepositedFundSummary__WEBPACK_IMPORTED_MODULE_19__["default"]
  },
  mixins: [],
  props: {
    filter: {
      type: Object
    },
    entity: {
      type: Array
    },
    isSave: {
      type: Boolean
    },
    value: null
  },
  data: function data() {
    return {
      activeItems: [],
      selectedItems: [],
      temp: false,
      totalRows: 0,
      selectAllFunds: [],
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      selectedRow: null,
      isTableLoading: false,
      totalAmount: 0.0,
      isTitleCheck: false,
      bankAccount: null,
      glBankAccount: '11030',
      accountName: '',
      selectedDate: '',
      isSelected: false,
      isSelectedAccount: null
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_22__["BankUndepositedFundColumns"];
    }
  },
  watch: {
    entity: function entity(newVal, oldVal) {
      this.activeItems = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_23___default()(newVal);
      this.getData();
      this.checkTitleStatus();
    },
    activeItems: {
      handler: function handler(val, oldVal) {
        // Return the object that changed
        this.checkTitleStatus();
      },
      deep: true
    }
    // selectedDate: function(newVal, oldVal) {
    //   if (newVal) {
    //     for (let i = 0; i < this.selectedItems.length; i++) {
    //       this.selectedItems[i].selectedDate = newVal.toISOString().split('.')[0] + 'Z'
    //     }
    //   } else {
    //     for (let i = 0; i < this.selectedItems.length; i++) {
    //       this.selectedItems[i].selectedDate = ''
    //     }
    //   }
    // }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.activeItems = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_23___default()(_this.entity);
            _this.getData();
            _this.checkTitleStatus();
            _context.n = 1;
            return _this.getBankAccountListCombo();
          case 1:
            _this.selectedDate = new Date();
            _this.accountName = _this.$userInfo.companyName;
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    this.$v.detailGroup.$touch();
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filter, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filter));
      if (filter) {
        this.filter = filter;
      }
    },
    onPageChange: function onPageChange(pageIndex) {
      this.$showSpinner();
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.$hideSpinner();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    addBankDetails: function addBankDetails() {
      var _this2 = this;
      this.isSelectedAccount = this.bankAccount.filter(function (b) {
        return b.accountNo === _this2.glBankAccount;
      });
      this.value.selectedBankAccount = this.glBankAccount;
      if (!this.selectedDate) {
        this.value.selectedDate = null;
      } else {
        this.value.selectedDate = this.selectedDate.toISOString().split('.')[0] + 'Z';
      }
      this.value.accountName = this.accountName;
      this.value.accountNumber = this.isSelectedAccount[0].bankAccount;
    },
    checkTitleStatus: function checkTitleStatus() {
      var found = this.activeItems.find(function (id) {
        return id.isChecked === false;
      });
      if (found) {
        this.isTitleCheck = false;
      } else {
        this.isTitleCheck = true;
      }
    },
    //Methods
    titleCheckboxChanged: function titleCheckboxChanged(value) {
      if (value) {
        this.$showSpinner();
        for (var i = 0; i < this.activeItems.length; i++) {
          this.selectBankUndepositedFund(this.activeItems[i], i, false);
        }
        this.activeItems.forEach(function (i) {
          return i.isChecked = value;
        });
        this.$hideSpinner();
      } else {
        var filter = this.activeItems.filter(function (id) {
          return id.isChecked === true;
        });
        for (var _i = 0; _i < this.activeItems.length; _i++) {
          if (filter.length === this.activeItems.length) {
            this.selectBankUndepositedFund(this.activeItems[_i], _i, true);
          } else {
            if (!this.activeItems[_i].isChecked) {
              this.selectBankUndepositedFund(this.activeItems[_i], _i, true);
            }
          }
        }
      }
    },
    selectBankUndepositedFund: function selectBankUndepositedFund(item, index, isCheck) {
      var _this3 = this;
      //When Item is Checked
      if (isCheck === false) {
        var _index = this.value.selectedFund.map(function (id) {
          return id.unclearedId;
        }).indexOf(item.unclearedId);
        if (_index < 0) {
          var bankFund = {
            debitAmount: 0.0,
            creditAmount: 0.0,
            bsbCustomer: '',
            accountNoCutomer: '',
            bsbInsurer: '',
            accountNoInsurer: '',
            remarks: '',
            chequeNo: '',
            unclearedId: ''
          };
          this.totalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_20__["roundAwayFromZero"])(this.totalAmount + item.debit, 2);
          this.value.totalAmount = this.totalAmount;
          bankFund.debitAmount = item.debit;
          bankFund.creditAmount = item.credit;
          bankFund.remarks = item.remarks;
          bankFund.chequeNo = item.cheque;
          bankFund.bsbCustomer = item.bsbCustomer;
          bankFund.accountNoCutomer = item.accountNoCutomer;
          bankFund.bsbInsurer = item.bsbInsurer;
          bankFund.accountNoInsurer = item.accountNoInsurer;
          bankFund.unclearedId = item.unclearedId;

          //Add value to SelectedFund
          this.value.selectedFund.push(bankFund);
          this.value.unclearedIdList.push(item.unclearedId.trim());
          this.value.accountName = this.accountName;
          this.value.selectedBankAccount = this.glBankAccount;
          this.value.selectedDate = this.selectedDate.toISOString().split('.')[0] + 'Z';
          this.isSelectedAccount = this.bankAccount.filter(function (b) {
            return b.accountNo === _this3.glBankAccount;
          });
          this.value.accountNumber = this.isSelectedAccount[0].bankAccount;
        }
      }
      //When Item is Unchecked
      else {
        //Remove value from SelectedFund
        var _index2 = this.value.selectedFund.map(function (id) {
          return id.unclearedId;
        }).indexOf(item.unclearedId);
        if (_index2 >= 0) {
          this.value.selectedFund.splice(_index2, 1);
          this.totalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_20__["roundAwayFromZero"])(this.totalAmount - item.debit, 2);
          this.value.totalAmount = this.totalAmount;
        }

        //Remove List of UnclearedId
        var index2 = this.value.unclearedIdList.indexOf(item.unclearedId.trim());
        if (index2 >= 0) {
          this.value.unclearedIdList.splice(index2, 1);
        }
        //Untick ActiveItems
        var index3 = this.activeItems.map(function (id) {
          return id.unclearedId;
        }).indexOf(item.unclearedId);
        this.activeItems[index3].isChecked = false;
      }
      this.checkTitleStatus();
    },
    getData: function getData() {
      if (this.isSave) {
        this.isTableLoading = true;
        this.value.selectedFund = [];
        this.value.totalAmount = 0.0;
        this.value.unclearedIdList = [];
        this.totalAmount = 0.0;
      }
      // this.activeItems = await BankUndepositedFundService.getEntitySummaries(this.filter)
      this.totalRows = this.activeItems.length > 0 ? this.activeItems[0].totalRows : 0;
      if (this.value.selectedFund.length > 0) {
        for (var i = 0; i < this.value.selectedFund.length; i++) {
          var index = 0;
          index = this.activeItems.map(function (id) {
            return id.unclearedId;
          }).indexOf(this.value.selectedFund[i].unclearedId);
          if (index >= 0) {
            this.activeItems[index].isChecked = true;
          }
        }
      }
      this.isTableLoading = false;
      this.$hideSpinner();
    },
    //Getting Bank Account Combo List
    getBankAccountListCombo: function getBankAccountListCombo() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var index;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _BankUndepositedFundService__WEBPACK_IMPORTED_MODULE_18__["default"].getGLBankAccountsDropdownProto(_this4.$userInfo.companyId);
            case 1:
              _this4.bankAccount = _context2.v;
              index = _this4.bankAccount.findIndex(function (i) {
                return i.glCategory === 'UND';
              });
              if (index > -1) {
                _this4.bankAccount.splice(index, 1);
              }
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2__);

// import BankUndepositedFundRoutes from './route-types'


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BankUndepositedFundSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_1__["NumberFiltersMixin"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value)
    };
  },
  computed: {},
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
      },
      deep: true
    }
  },
  mounted: function mounted() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./columns */ "./src/views/bankundepositedfund/columns.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");


// import { roundAwayFromZero } from '@/components/utils/AccountingFunctions'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BankUndepositedFundSummary',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    entity: null,
    value: null
  },
  data: function data() {
    return {
      selectedRow: null
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_0__["BankUndepositedFundSummaryColumns"];
    }
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _BankUndepositedFundSideMenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./BankUndepositedFundSideMenu */ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue");
/* harmony import */ var _BankUndepositedFundService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./BankUndepositedFundService */ "./src/views/bankundepositedfund/BankUndepositedFundService.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./route-types */ "./src/views/bankundepositedfund/route-types.js");
/* harmony import */ var _BankUndepositedFundValidation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./BankUndepositedFundValidation */ "./src/views/bankundepositedfund/BankUndepositedFundValidation.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../receiptentry/route-types */ "./src/views/receiptentry/route-types.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./storeMixin */ "./src/views/bankundepositedfund/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");


































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BankUndepositedFundView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__["default"]
  }, _BankUndepositedFundSideMenu__WEBPACK_IMPORTED_MODULE_15__["default"].name, _BankUndepositedFundSideMenu__WEBPACK_IMPORTED_MODULE_15__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["UnsavedModal"]), "SaveConflictModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["SaveConflictModal"]), "ConfirmModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["ConfirmModal"]),
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_26__["default"], _BankUndepositedFundValidation__WEBPACK_IMPORTED_MODULE_18__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      filter: {
        query: '',
        sortColumn: '',
        sortOrder: '',
        pageIndex: 1,
        pageSize: 15
      },
      newEntity: {
        companyId: null,
        selectedDate: new Date(),
        selectedBankAccount: null,
        accountName: null,
        bankingTotalAmount: 0.00,
        unclearedIdList: []
      },
      selectedItems: {
        selectedDate: new Date(),
        selectedBankAccount: null,
        accountNumber: null,
        accountName: null,
        totalAmount: 0.00,
        unclearedIdList: [],
        selectedFund: []
      },
      isTableLoading: false,
      totalRows: 0,
      entity: null,
      toRoute: null,
      // stores "to" route of beforeRouteLeave
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      isSaveButton: false,
      isConfirmModalActive: false,
      isSave: false
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error || this.$v.detailGroup.$invalid;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_32___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          //this.saveSnapshot(_cloneDeep(this.entity))
        }
      }, 500),
      deep: true
    },
    'selectedItems.selectedFund': function selectedItemsSelectedFund(newVal, oldVal) {
      if (newVal) {
        this.isSaveButton = false;
        var find = this.selectedItems.selectedFund.length;
        if (find > 0) {
          this.isSaveButton = true;
        }
      }
    },
    'filter.pageIndex': function filterPageIndex(newVal, oldVal) {
      if (newVal) {
        this.$showSpinner();
        this.getData();
        this.$hideSpinner();
      }
    },
    'filter.sortColumn': function filterSortColumn(newVal, oldVal) {
      if (newVal) {
        this.getData();
      }
    },
    'filter.sortOrder': function filterSortOrder(newVal, oldVal) {
      if (newVal) {
        this.getData();
      }
    }
  },
  created: function created() {
    if (this.returnUrl) {
      this.persistQueries();
      this.replaceRoute(this.$route.params.CompanyId);
    }
    this.getData();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Print:
          this.print1();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Delete:
          this.entity.deleted = true;
          this.save(true);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Save:
          this.confirmSave();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              // this.retrieveFilter()
              _context.n = 1;
              return _BankUndepositedFundService__WEBPACK_IMPORTED_MODULE_16__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entity = _context.v;
              // this.totalRows = this.entity.length > 0 ? this.entity[0].totalRows : 0
              _this.isTableLoading = false;
              _this.$hideSpinner();
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filter, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filter));
      if (filter) {
        this.filter = filter;
      }
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getData();
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    resetList: function resetList() {
      this.filter.query = '';
      this.filter.sortColumn = '';
      this.filter.sortOrder = '';
      this.filter.pageIndex = 1;
      this.filter.pageSize = 15;
      this.persistFilter();
      this.getData();
    },
    confirmSave: function confirmSave() {
      this.isConfirmModalActive = true;
    },
    saveEntity: function saveEntity(confirmSave) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var title;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isConfirmModalActive = false;
              title = 'Receipt Entry';
              if (!_this2.validateError) {
                _context2.n = 1;
                break;
              }
              _this2.$notification.openNotificationWithType('danger', title, 'Bank Account or Account Name is Missing');
              return _context2.a(2, false);
            case 1:
              if (confirmSave === 'ok') {
                // this.print1()
                _this2.save();
              } else if (confirmSave === 'print') {
                _this2.print1();
              }
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    //Save
    save: function save(isDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var title, response, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              title = 'Receipt Entry'; // this.isConfirmModalActive = true
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context3.a(2, false);
            case 1:
              _context3.p = 1;
              _this3.$showSpinner('Saving...');
              //Assign Value to newEntity
              _this3.newEntity = {
                companyId: _this3.$userInfo.companyId,
                selectedDate: _this3.selectedItems.selectedDate,
                selectedBankAccount: _this3.selectedItems.selectedBankAccount,
                accountName: _this3.selectedItems.accountName,
                bankingTotalAmount: _this3.selectedItems.totalAmount,
                unclearedIdList: _this3.selectedItems.unclearedIdList
              }, _this3.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(_this3.newEntity));
              _context3.n = 2;
              return _BankUndepositedFundService__WEBPACK_IMPORTED_MODULE_16__["default"].postEntity(_this3.newEntity);
            case 2:
              response = _context3.v;
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].OK)) {
                _context3.n = 4;
                break;
              }
              _this3.isSave = true;
              _this3.isSaveButton = false;
              if (!_this3.isSaveContinue) {
                _context3.n = 3;
                break;
              }
              _this3.isSave = false;
              _this3.isSaveContinue = true;
              _context3.n = 3;
              return _this3.print1();
            case 3:
              _this3.print1();
              _this3.getData();
              // await BankUndepositedFundDetail.getData()
              _this3.$notification.success('Bank Un-Deposited Funds', isDelete ? 'Bank Undeposited Fund set to In-Active' : 'Save successful');
              // this.$router.push({
              //   name: ReceiptEntryRoutes.ReceiptEntryListView.name
              // })
              _this3.$hideSpinner();
              _context3.n = 5;
              break;
            case 4:
              if (response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].NO_CONTENT) {
                _this3.$notification.success('Bank Un-Deposited Funds', isDelete ? 'Bank Undeposited Fund set to In-Active' : 'Save successful');
                _this3.$router.push({
                  name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].ReceiptEntryListView.name
                });
              } else if (_this3.isSkipSave) {
                _this3.$router.push({
                  name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].ReceiptEntryListView.name
                });
              }
            case 5:
              // reloadData()
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 6:
              _context3.p = 6;
              _t = _context3.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_24__["default"].$emit('serviceError', _t.response.status);
              // if (e.response.request.status === HttpStatus.CONFLICT) {
              //   this.isSaveConflictModalActive = true
              // } else {
              if (_t.response.status !== _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].CONFLICT) {
                _this3.$notification.openMessageXhrError('Bank Undeposited Fund', _t);
              }
              return _context3.a(2, false);
            case 7:
              _context3.p = 7;
              _this3.$hideSpinner();
              return _context3.f(7);
            case 8:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 6, 7, 8]]);
      }))();
    },
    cancel: function cancel() {
      // this.saveSnapshot(_cloneDeep(this.selectedItems))
      if (this.selectedItems.selectedFund.length > 0 && !this.isSkipSave && !this.isSaveContinue) {
        this.isUnsavedModalActive = true;
      } else if (this.isSkipSave) {
        if (this.returnUrl) {
          this.clearSessionStorage();
          this.clearSnapshots(this.entity.invoiceId);
          window.location.href = "".concat("").concat(this.returnUrl);
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].ReceiptEntryListView.name
          });
        }
      } else {
        if (this.returnUrl) {
          this.clearSessionStorage();
          this.clearSnapshots(this.entity.invoiceId);
          window.location.href = "".concat("").concat(this.returnUrl);
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_28___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].ReceiptEntryListView.name
          });
        }
      }
    },
    //Save And Continue Function
    saveContinue: function saveContinue() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isUnsavedModalActive = false;
              _this4.isSkipSave = false;
              _this4.isSaveContinue = true;
              _context4.n = 1;
              return _this4.save();
            case 1:
              _this4.isSaveContinue = _context4.v;
              if (_this4.isSaveContinue) {
                _this4.cancel();
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    //Print Function
    print1: function print1() {
      this.$showSpinner();
      var partsXml = this.generatePartsXml();
      var params = Object.assign({
        ACCOUNTNAME: this.selectedItems.accountName,
        COMPANYID: this.$userInfo.companyId,
        reportDocId: this.$lzstring.compressToBase64(partsXml),
        BANKINGTOTAL: this.selectedItems.totalAmount,
        BANKACCOUNT: this.selectedItems.selectedBankAccount
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_31__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var parameterId = this.$guid.newGuid();
      _store_utils__WEBPACK_IMPORTED_MODULE_19__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_30__["Emailer"]();
      emailer.subject = 'Bank Un-Deposited Fund';
      emailer.reportName = 'BankUndepositedList';
      this.addEmailer(emailer);
      _store_utils__WEBPACK_IMPORTED_MODULE_19__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
      var routeData = this.$router.resolve({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__["default"].PrintPreview.name,
        params: {
          reportName: 'AT_BankUndeposited'
        },
        query: {
          parameterId: parameterId,
          emailerId: emailer.id,
          isNewTab: true
        }
      });
      window.open(routeData.href, '_blank');
      this.$hideSpinner();
      // window.open(printPreviewRoute.href, '_blank')
    },
    //Generate XML for Print
    generatePartsXml: function generatePartsXml() {
      var xmlDoc = document.implementation.createDocument('', '', null);
      var invoiceElement = xmlDoc.createElement('AT_Invoice');
      var bsbField;
      var chequeNo;
      for (var i = 0; i < this.selectedItems.selectedFund.length; i++) {
        var invoiceItemElement = xmlDoc.createElement('INVOICEITEM');
        var drawerElement = xmlDoc.createElement('Drawer');
        var chequeNoElement = xmlDoc.createElement('ChequeNo');
        var receiptedAmountElement = xmlDoc.createElement('ReceiptedAmount');
        var paidAmountElement = xmlDoc.createElement('PaidAmount');
        var bsbElement = xmlDoc.createElement('BSB');
        var bankAccountElement = xmlDoc.createElement('BankAccountNo');
        var debitAmount = this.selectedItems.selectedFund[i].debitAmount.toString();
        var creditAmount = this.selectedItems.selectedFund[i].creditAmount.toString();
        if (this.selectedItems.selectedFund[i].bsbCustomer || this.selectedItems.selectedFund[i].accountNoCustomer) {
          if (this.selectedItems.selectedFund[i].bsbCustomer) {
            bsbField = this.selectedItems.selectedFund[i].bsbCustomer;
          }
          if (this.selectedItems.selectedFund[i].accountNoCustomer) {
            bsbField = this.selectedItems.selectedFund[i].accountNoCustomer;
          }
          if (this.selectedItems.selectedFund[i].bsbCustomer && this.selectedItems.selectedFund[i].accountNoCustomer) {
            bsbField = this.selectedItems.selectedFund[i].accountNoCustomer + '/' + this.selectedItems.selectedFund[i].bsbCustomer;
          }
        }
        if (this.selectedItems.selectedFund[i].bsbInsurer || this.selectedItems.selectedFund[i].accountNoInsurer) {
          if (this.selectedItems.selectedFund[i].bsbInsurer) {
            bsbField = this.selectedItems.selectedFund[i].bsbInsurer;
          }
          if (this.selectedItems.selectedFund[i].accountNoInsurer) {
            bsbField = this.selectedItems.selectedFund[i].accountNoInsurer;
          }
          if (this.selectedItems.selectedFund[i].bsbInsurer && this.selectedItems.selectedFund[i].accountNoInsurer) {
            bsbField = this.selectedItems.selectedFund[i].accountNoInsurer + '/' + this.selectedItems.selectedFund[i].bsbInsurer;
          }
          //bsbField = this.selectedItems.selectedFund[i].accountNoInsurer + '/' + this.selectedItems.selectedFund[i].bsbInsurer
        } else {
          bsbField = '';
        }
        if (this.selectedItems.selectedFund[i].chequeNo) {
          chequeNo = this.selectedItems.selectedFund[i].chequeNo;
        } else {
          chequeNo = '';
        }
        drawerElement.innerHTML = this.selectedItems.selectedFund[i].remarks.escapeXml();
        chequeNoElement.innerHTML = chequeNo.escapeXml();
        receiptedAmountElement.innerHTML = debitAmount.escapeXml();
        if (Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_33__["roundAwayFromZero"])(creditAmount, 2) > 0) {
          paidAmountElement.innerHTML = creditAmount.escapeXml();
        } else {
          creditAmount = '0.00';
          paidAmountElement.innerHTML = creditAmount.escapeXml();
        }
        bsbElement.innerHTML = bsbField.escapeXml();
        bankAccountElement.innerHTML = this.selectedItems.accountNumber.escapeXml();
        invoiceItemElement.appendChild(drawerElement);
        invoiceItemElement.appendChild(chequeNoElement);
        invoiceItemElement.appendChild(receiptedAmountElement);
        invoiceItemElement.appendChild(paidAmountElement);
        invoiceItemElement.appendChild(bsbElement);
        invoiceItemElement.appendChild(bankAccountElement);
        invoiceElement.appendChild(invoiceItemElement);
      }
      xmlDoc.appendChild(invoiceElement);
      return new XMLSerializer().serializeToString(xmlDoc);
    },
    //Skip Button
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    //Redirect Route
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    //Close Modal
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      // this.isSaveConflictModalActive = false
      this.isSaveContinue = false;
      this.toRoute = null;
    },
    //Reload Data
    reloadData: function reloadData() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              // this.isSaveConflictModalActive = false
              _this5.isSaveContinue = false;
              _context5.n = 1;
              return _this5.getEntity(true);
            case 1:
              _this5.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|bankundepositedfund|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|bankundepositedfund|type"), this.type);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|bankundepositedfund|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|bankundepositedfund|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_17__["default"].BankUndepositedFundDetail.name,
        params: {
          CompanyId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(this.selectedItems));
    if (this.selectedItems.selectedFund.length > 0 && !this.isSkipSave && !this.isSaveContinue && !this.isSave) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entity.assetID);
      this.clearSessionStorage();
      this.clearRouteMeta();
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);









var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent is-9"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm.activeItems.length > 0 ? _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "is-title-checkable": true,
      "title-checkbox-location": "front",
      "is-title-checked": _vm.isTitleCheck
    },
    on: {
      pageChanged: _vm.onPageChange,
      "update:isTitleChecked": function updateIsTitleChecked($event) {
        _vm.isTitleCheck = $event;
      },
      "update:is-title-checked": function updateIsTitleChecked($event) {
        _vm.isTitleCheck = $event;
      },
      "title-checkbox-changed": _vm.titleCheckboxChanged,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.activeItems, function (item, index) {
    return _c("tr", {
      key: item.unclearedId,
      class: {
        "is-selected": _vm.selectedRow === index
      }
    }, [_c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.isChecked,
        expression: "item.isChecked"
      }],
      staticClass: "is-checkradio is-box is-primary",
      class: {
        "has-background-color": item.isChecked
      },
      attrs: {
        id: "report".concat(index),
        name: "report".concat(index),
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(item.isChecked) ? _vm._i(item.isChecked, null) > -1 : item.isChecked
      },
      on: {
        click: function click($event) {
          return _vm.selectBankUndepositedFund(item, index, item.isChecked);
        },
        change: function change($event) {
          var $$a = item.isChecked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(item, "isChecked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(item, "isChecked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(item, "isChecked", $$c);
          }
        }
      }
    }), _c("label", {
      attrs: {
        for: "report".concat(index),
        "data-label-empty": ""
      }
    })]), _c("td", [_vm._v(_vm._s(item.remarks))]), _c("td", {
      staticClass: "has-text-right"
    }, [_c("input", {
      staticClass: "input",
      attrs: {
        type: "text",
        disabled: "",
        readonly: ""
      },
      domProps: {
        value: _vm.$filters.formatDateLocale(item.transactionDate, _vm.$userInfo.locale)
      }
    })]), _c("td", [_c("div", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.debit, _vm.$userInfo.locale)))])]), _c("td", [_c("div", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.credit, _vm.$userInfo.locale)))])]), _c("td", [_c("div", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(item.cheque))])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])], 2) : _vm._e()], 1)]), _c("div", {
    staticClass: "tile is-vertical is-3"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "field is-pulled-left"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Select Banking Date")]), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    on: {
      input: function input($event) {
        return _vm.addBankDetails();
      }
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("div", {
          staticClass: "control"
        }, [_c("input", _vm._g({
          staticClass: "input",
          class: {
            "is-danger": _vm.$v.selectedItems.selectedDate.$invalid
          },
          attrs: {
            type: "text",
            placeholder: "Banking Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), !_vm.$v.selectedItems.selectedDate.required ? _c("span", {
          staticClass: "help is-danger"
        }, [_vm._v("Banking Date is required. ")]) : _vm._e()])])];
      }
    }]),
    model: {
      value: _vm.selectedDate,
      callback: function callback($$v) {
        _vm.selectedDate = $$v;
      },
      expression: "selectedDate"
    }
  }), _c("label", {
    staticClass: "label"
  }, [_vm._v("Select Bank Account")]), _c("div", {
    staticClass: "select field"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.glBankAccount,
      expression: "glBankAccount"
    }],
    staticStyle: {
      width: "230px"
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.glBankAccount = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }, function ($event) {
        return _vm.addBankDetails();
      }]
    }
  }, _vm._l(_vm.bankAccount, function (b) {
    return _c("option", {
      key: b.accountId,
      domProps: {
        value: b.accountNo
      }
    }, [_vm._v(" " + _vm._s(b.displayName) + " ")]);
  }), 0)]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Enter Account Name")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.accountName,
      expression: "accountName"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.selectedItems.accountName.$error
    },
    attrs: {
      placeholder: "Account Name"
    },
    domProps: {
      value: _vm.accountName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.accountName = $event.target.value;
      }, function ($event) {
        return _vm.addBankDetails();
      }]
    }
  })]), !_vm.$v.selectedItems.accountName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Account Name is required. ")]) : _vm._e()], 1)])]), _c("div", {
    staticClass: "tile is-parent"
  }, [_c("bank-undeposited-fund-summary", {
    staticClass: "tile is-child box",
    attrs: {
      entity: _vm.value.selectedFund,
      value: _vm.totalAmount
    }
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Bank Un-Deposited Fund ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.query,
      expression: "value.query"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Cheque No or Drawer of Cheque"
    },
    domProps: {
      value: _vm.value.query
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "query", $event.target.value);
      }
    }
  })])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5 ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", [_c("p", {
    staticClass: "title"
  }, [_vm._v("Summary")]), _vm.value === "" ? _c("p", {
    staticClass: "subtitle has-text-success"
  }, [_vm._v(" Banking Amount: $0.00")]) : _c("p", {
    staticClass: "subtitle has-text-success"
  }, [_vm._v(" Banking Amount: $" + _vm._s(_vm.$filters.formatNumber(_vm.value, _vm.$userInfo.locale)))]), _c("div", {
    staticStyle: {
      "overflow-y": "auto",
      height: "400px"
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "total-rows": _vm.entity.length,
      "show-pagination": false
    }
  }, [_vm._l(_vm.entity, function (item, index) {
    return _c("tr", {
      key: item.unclearedId,
      class: {
        "is-selected": _vm.selectedRow === index
      }
    }, [_c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.remarks))])]), _c("td", [_c("div", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(item.debitAmount, _vm.$userInfo.locale)))])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-dots-horizontal mdi-inactive-color mdi-inactive"
  })])])])], 2)], 1)]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": _vm.isSaveButton
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("bank-undeposited-fund-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name,
      filter: _vm.filter,
      entity: _vm.entity,
      "is-save": _vm.isSave
    },
    model: {
      value: _vm.selectedItems,
      callback: function callback($$v) {
        _vm.selectedItems = $$v;
      },
      expression: "selectedItems"
    }
  }) : _vm._e()], 1)]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Save & Print",
      "cancel-text": "Print",
      "close-text": "Close",
      "show-close": true
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.saveEntity("ok");
      },
      cancel: function cancel($event) {
        return _vm.saveEntity("print");
      },
      close: function close($event) {
        return _vm.saveEntity("close");
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Do you want to Save and Print?")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" This will save your selected Bank Un-deposited Funds and Print. ")])]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./src/assets/proto/bankundepositedfund/BankUndepositedFundFilter.proto":
/*!******************************************************************************!*\
  !*** ./src/assets/proto/bankundepositedfund/BankUndepositedFundFilter.proto ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*undefined*/


var $protobuf = __webpack_require__(/*! protobufjs/minimal */ "./node_modules/protobufjs/minimal.js");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.BankUndepositedFundFilter = (function() {

    /**
     * Namespace BankUndepositedFundFilter.
     * @exports BankUndepositedFundFilter
     * @namespace
     */
    var BankUndepositedFundFilter = {};

    BankUndepositedFundFilter.BankUndepositedFundFilterModel = (function() {

        /**
         * Properties of a BankUndepositedFundFilterModel.
         * @memberof BankUndepositedFundFilter
         * @interface IBankUndepositedFundFilterModel
         * @property {string|null} [query] BankUndepositedFundFilterModel query
         * @property {string|null} [sortColumn] BankUndepositedFundFilterModel sortColumn
         * @property {string|null} [sortOrder] BankUndepositedFundFilterModel sortOrder
         * @property {number|null} [pageIndex] BankUndepositedFundFilterModel pageIndex
         * @property {number|null} [pageSize] BankUndepositedFundFilterModel pageSize
         */

        /**
         * Constructs a new BankUndepositedFundFilterModel.
         * @memberof BankUndepositedFundFilter
         * @classdesc Represents a BankUndepositedFundFilterModel.
         * @implements IBankUndepositedFundFilterModel
         * @constructor
         * @param {BankUndepositedFundFilter.IBankUndepositedFundFilterModel=} [p] Properties to set
         */
        function BankUndepositedFundFilterModel(p) {
            if (p)
                for (var ks = Object.keys(p), i = 0; i < ks.length; ++i)
                    if (p[ks[i]] != null)
                        this[ks[i]] = p[ks[i]];
        }

        /**
         * BankUndepositedFundFilterModel query.
         * @member {string|null|undefined} query
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        BankUndepositedFundFilterModel.prototype.query = null;

        /**
         * BankUndepositedFundFilterModel sortColumn.
         * @member {string|null|undefined} sortColumn
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        BankUndepositedFundFilterModel.prototype.sortColumn = null;

        /**
         * BankUndepositedFundFilterModel sortOrder.
         * @member {string|null|undefined} sortOrder
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        BankUndepositedFundFilterModel.prototype.sortOrder = null;

        /**
         * BankUndepositedFundFilterModel pageIndex.
         * @member {number|null|undefined} pageIndex
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        BankUndepositedFundFilterModel.prototype.pageIndex = null;

        /**
         * BankUndepositedFundFilterModel pageSize.
         * @member {number|null|undefined} pageSize
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        BankUndepositedFundFilterModel.prototype.pageSize = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * BankUndepositedFundFilterModel _query.
         * @member {"query"|undefined} _query
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        Object.defineProperty(BankUndepositedFundFilterModel.prototype, "_query", {
            get: $util.oneOfGetter($oneOfFields = ["query"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * BankUndepositedFundFilterModel _sortColumn.
         * @member {"sortColumn"|undefined} _sortColumn
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        Object.defineProperty(BankUndepositedFundFilterModel.prototype, "_sortColumn", {
            get: $util.oneOfGetter($oneOfFields = ["sortColumn"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * BankUndepositedFundFilterModel _sortOrder.
         * @member {"sortOrder"|undefined} _sortOrder
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        Object.defineProperty(BankUndepositedFundFilterModel.prototype, "_sortOrder", {
            get: $util.oneOfGetter($oneOfFields = ["sortOrder"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * BankUndepositedFundFilterModel _pageIndex.
         * @member {"pageIndex"|undefined} _pageIndex
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        Object.defineProperty(BankUndepositedFundFilterModel.prototype, "_pageIndex", {
            get: $util.oneOfGetter($oneOfFields = ["pageIndex"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * BankUndepositedFundFilterModel _pageSize.
         * @member {"pageSize"|undefined} _pageSize
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @instance
         */
        Object.defineProperty(BankUndepositedFundFilterModel.prototype, "_pageSize", {
            get: $util.oneOfGetter($oneOfFields = ["pageSize"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Encodes the specified BankUndepositedFundFilterModel message. Does not implicitly {@link BankUndepositedFundFilter.BankUndepositedFundFilterModel.verify|verify} messages.
         * @function encode
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @static
         * @param {BankUndepositedFundFilter.IBankUndepositedFundFilterModel} m BankUndepositedFundFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [w] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        BankUndepositedFundFilterModel.encode = function encode(m, w) {
            if (!w)
                w = $Writer.create();
            if (m.query != null && Object.hasOwnProperty.call(m, "query"))
                w.uint32(10).string(m.query);
            if (m.sortColumn != null && Object.hasOwnProperty.call(m, "sortColumn"))
                w.uint32(18).string(m.sortColumn);
            if (m.sortOrder != null && Object.hasOwnProperty.call(m, "sortOrder"))
                w.uint32(26).string(m.sortOrder);
            if (m.pageIndex != null && Object.hasOwnProperty.call(m, "pageIndex"))
                w.uint32(32).int32(m.pageIndex);
            if (m.pageSize != null && Object.hasOwnProperty.call(m, "pageSize"))
                w.uint32(40).int32(m.pageSize);
            return w;
        };

        /**
         * Encodes the specified BankUndepositedFundFilterModel message, length delimited. Does not implicitly {@link BankUndepositedFundFilter.BankUndepositedFundFilterModel.verify|verify} messages.
         * @function encodeDelimited
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @static
         * @param {BankUndepositedFundFilter.IBankUndepositedFundFilterModel} message BankUndepositedFundFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        BankUndepositedFundFilterModel.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a BankUndepositedFundFilterModel message from the specified reader or buffer.
         * @function decode
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} r Reader or buffer to decode from
         * @param {number} [l] Message length if known beforehand
         * @returns {BankUndepositedFundFilter.BankUndepositedFundFilterModel} BankUndepositedFundFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        BankUndepositedFundFilterModel.decode = function decode(r, l) {
            if (!(r instanceof $Reader))
                r = $Reader.create(r);
            var c = l === undefined ? r.len : r.pos + l, m = new $root.BankUndepositedFundFilter.BankUndepositedFundFilterModel();
            while (r.pos < c) {
                var t = r.uint32();
                switch (t >>> 3) {
                case 1:
                    m.query = r.string();
                    break;
                case 2:
                    m.sortColumn = r.string();
                    break;
                case 3:
                    m.sortOrder = r.string();
                    break;
                case 4:
                    m.pageIndex = r.int32();
                    break;
                case 5:
                    m.pageSize = r.int32();
                    break;
                default:
                    r.skipType(t & 7);
                    break;
                }
            }
            return m;
        };

        /**
         * Decodes a BankUndepositedFundFilterModel message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof BankUndepositedFundFilter.BankUndepositedFundFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {BankUndepositedFundFilter.BankUndepositedFundFilterModel} BankUndepositedFundFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        BankUndepositedFundFilterModel.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        return BankUndepositedFundFilterModel;
    })();

    return BankUndepositedFundFilter;
})();

module.exports = $root;


/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundDetail.vue":
/*!*********************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundDetail.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c */ "./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c");
/* harmony import */ var _BankUndepositedFundDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BankUndepositedFundDetail.vue?vue&type=script&lang=js */ "./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BankUndepositedFundDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/bankundepositedfund/BankUndepositedFundDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js":
/*!*********************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c":
/*!***************************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundDetail.vue?vue&type=template&id=13e26c1c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundDetail_vue_vue_type_template_id_13e26c1c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundService.js":
/*!*********************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundService.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_3__);




// import ProtoBufApi from '@/services/protobuf-api'
// import AuditTrailApi from '@/services/audittrail-api'
// import { GlAccountTypes } from '@/enums'

/* harmony default export */ __webpack_exports__["default"] = ({
  getEntity: function getEntity(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get("/bankundepositedfund?id=".concat(id));
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  getEntitySummaries: function getEntitySummaries(filter) {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var serialised, url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            serialised = _this.serialisebankUndepositedFundFilter(filter);
            url = "/bankundepositedfund/list/".concat(serialised);
            _context2.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get(url);
          case 1:
            result = _context2.v;
            return _context2.a(2, result.data);
        }
      }, _callee2);
    }))();
  },
  serialisebankUndepositedFundFilter: function serialisebankUndepositedFundFilter(filter) {
    var bankUndepositedFundProto = __webpack_require__(/*! ../../assets/proto/bankundepositedfund/BankUndepositedFundFilter.proto */ "./src/assets/proto/bankundepositedfund/BankUndepositedFundFilter.proto");
    var filterMessage = bankUndepositedFundProto.BankUndepositedFundFilter.BankUndepositedFundFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_3___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  postEntity: function postEntity(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            return _context3.a(2, _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].post('/bankundepositedfund', entity));
        }
      }, _callee3);
    }))();
  },
  getGLBankAccountsDropdownProto: function getGLBankAccountsDropdownProto(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            _context4.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get("/bankundepositedfund/getGlBankAccount?id=".concat(id));
          case 1:
            result = _context4.v;
            return _context4.a(2, result.data);
        }
      }, _callee4);
    }))();
  }
});

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue":
/*!***********************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37 */ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37");
/* harmony import */ var _BankUndepositedFundSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BankUndepositedFundSideMenu.vue?vue&type=script&lang=js */ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BankUndepositedFundSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37":
/*!*****************************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37 ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSideMenu.vue?vue&type=template&id=1f15cc37");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSideMenu_vue_vue_type_template_id_1f15cc37__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue":
/*!**********************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSummary.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BankUndepositedFundSummary.vue?vue&type=template&id=018278d5 */ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5");
/* harmony import */ var _BankUndepositedFundSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BankUndepositedFundSummary.vue?vue&type=script&lang=js */ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BankUndepositedFundSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/bankundepositedfund/BankUndepositedFundSummary.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js":
/*!**********************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundSummary.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5":
/*!****************************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5 ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundSummary.vue?vue&type=template&id=018278d5 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundSummary.vue?vue&type=template&id=018278d5");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundSummary_vue_vue_type_template_id_018278d5__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundValidation.js":
/*!************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundValidation.js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['selectedItems.accountName', 'selectedItems.selectedDate'],
    selectedItems: {
      accountName: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      selectedDate: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundView.vue":
/*!*******************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundView.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BankUndepositedFundView.vue?vue&type=template&id=50daf086 */ "./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086");
/* harmony import */ var _BankUndepositedFundView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BankUndepositedFundView.vue?vue&type=script&lang=js */ "./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BankUndepositedFundView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/bankundepositedfund/BankUndepositedFundView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js":
/*!*******************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086":
/*!*************************************************************************************************!*\
  !*** ./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086 ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BankUndepositedFundView.vue?vue&type=template&id=50daf086 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/bankundepositedfund/BankUndepositedFundView.vue?vue&type=template&id=50daf086");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BankUndepositedFundView_vue_vue_type_template_id_50daf086__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/bankundepositedfund/columns.js":
/*!**************************************************!*\
  !*** ./src/views/bankundepositedfund/columns.js ***!
  \**************************************************/
/*! exports provided: BankUndepositedFundColumns, BankUndepositedFundSummaryColumns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BankUndepositedFundColumns", function() { return BankUndepositedFundColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BankUndepositedFundSummaryColumns", function() { return BankUndepositedFundSummaryColumns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var BankUndepositedFundColumns = [
// new TableColumn('', 'action', false, 'desc', 'centered'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Drawer of Cheque', 'remarks', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Receipted Date', 'transactionDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Receipted Amount', 'debit', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Paid Amount', 'credit', false, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Cheque No', 'cheque', false, 'asc', 'right')];
var BankUndepositedFundSummaryColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Drawer of Cheque', 'remarks', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Amount', 'debit', false, 'desc', 'right')];


/***/ }),

/***/ "./src/views/bankundepositedfund/route-types.js":
/*!******************************************************!*\
  !*** ./src/views/bankundepositedfund/route-types.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var BankUndepositedFundRoutes = {
  BankUndepositedFundView: new _classes__WEBPACK_IMPORTED_MODULE_0__["ComponentRoute"]('/bankundepositedfund/:CompanyId', 'BankUndepositedFundView'),
  BankUndepositedFundDetail: new _classes__WEBPACK_IMPORTED_MODULE_0__["ComponentRoute"]('/bankundepositedfund/:CompanyId', 'BankUndepositedFundDetail')
};
/* harmony default export */ __webpack_exports__["default"] = (BankUndepositedFundRoutes);

/***/ }),

/***/ "./src/views/bankundepositedfund/storeMixin.js":
/*!*****************************************************!*\
  !*** ./src/views/bankundepositedfund/storeMixin.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'receiptpayment';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=bankundepositedfund-chunk.js.map