(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[13],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/AuthCard.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_mixins_global_GlobalSpinnerMixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/mixins/global/GlobalSpinnerMixin */ "./src/components/mixins/global/GlobalSpinnerMixin.js");
/* harmony import */ var _components_Spinners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/Spinners */ "./src/components/Spinners/index.js");



/**
 * Shared chrome for the auth pages - background, logo, card, spinner, the mobile uploader link
 * and the error alert - so SignIn and SignInCsr do not each carry their own copy of the layout.
 *
 * Follows SignIn.aspx and Common/css/login.css closely, so the two logins read as the page they
 * replace: the uploader link and the error alert sit outside the card, below it. The logo stays
 * inside the card rather than above it, which is where the legacy page puts it.
 */
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AuthCard',
  mixins: [_components_mixins_global_GlobalSpinnerMixin__WEBPACK_IMPORTED_MODULE_0__["default"]],
  props: {
    title: {
      type: String,
      default: ''
    },
    errorMessage: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      // The legacy alert is dismissible, and a new error re-opens it.
      dismissed: false
    };
  },
  computed: {
    spinner: function spinner() {
      return _components_Spinners__WEBPACK_IMPORTED_MODULE_1__["default"];
    },
    mobileUrl: function mobileUrl() {
      return "".concat("", "/mobile");
    },
    logoImgPath: function logoImgPath() {
      return this.$theme && this.$theme.isDark ? __webpack_require__(/*! @/assets/images/flexiquote-logo-dark.svg */ "./src/assets/images/flexiquote-logo-dark.svg") : __webpack_require__(/*! @/assets/images/flexiquote-logo-light.svg */ "./src/assets/images/flexiquote-logo-light.svg");
    }
  },
  watch: {
    errorMessage: function errorMessage() {
      this.dismissed = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");



var COMPLEXITY_DEBOUNCE_MS = 350;

/**
 * First-login password change, shared by /login and /login-csr. Both reach it the same way: the
 * server refuses to issue a token for an account still carrying its admin-assigned password and
 * hands back a ticket instead.
 *
 * Emits `submit` with the chosen password once it is confirmed and meets the server's criteria.
 * The parent owns the ticket and the call, since the two flows continue differently afterwards.
 */
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'NewPasswordPanel',
  props: {
    // Feeds the hidden field password managers read; not submitted.
    username: {
      type: String,
      default: ''
    },
    isSubmitting: {
      type: Boolean,
      default: false
    },
    // Keeps input ids unique when both panels exist in one page's markup.
    idPrefix: {
      type: String,
      default: 'newpassword'
    }
  },
  data: function data() {
    return {
      newPassword: '',
      confirmPassword: '',
      complexityMessage: '',
      meetsCriteria: false,
      touched: false
    };
  },
  beforeDestroy: function beforeDestroy() {
    clearTimeout(this._complexityTimer);
  },
  methods: {
    onNewPasswordInput: function onNewPasswordInput() {
      // Debounced so this is not one request per keystroke.
      clearTimeout(this._complexityTimer);
      this._complexityTimer = setTimeout(this.checkComplexity, COMPLEXITY_DEBOUNCE_MS);
    },
    checkComplexity: function checkComplexity() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _yield$FqApi$post, data, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              if (_this.newPassword) {
                _context.n = 1;
                break;
              }
              _this.complexityMessage = '';
              _this.meetsCriteria = false;
              return _context.a(2);
            case 1:
              _context.p = 1;
              _context.n = 2;
              return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].post('/auth/postPasswordComplexity', {
                password: _this.newPassword
              });
            case 2:
              _yield$FqApi$post = _context.v;
              data = _yield$FqApi$post.data;
              _this.meetsCriteria = data.passwordMeetsCriteria;
              _this.complexityMessage = data.passwordMeetsCriteria ? 'Password is strong' : data.message;
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.meetsCriteria = false;
              _this.complexityMessage = 'Could not validate password';
            case 4:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    submit: function submit() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.touched = true;
              if (!(!_this2.newPassword || !_this2.confirmPassword)) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              if (!(_this2.newPassword !== _this2.confirmPassword)) {
                _context2.n = 2;
                break;
              }
              return _context2.a(2);
            case 2:
              // The debounce may still be pending on a fast submit, so settle the check before relying
              // on it rather than posting a password the server will reject.
              clearTimeout(_this2._complexityTimer);
              _context2.n = 3;
              return _this2.checkComplexity();
            case 3:
              if (_this2.meetsCriteria) {
                _context2.n = 4;
                break;
              }
              return _context2.a(2);
            case 4:
              _this2.$emit('submit', _this2.newPassword);
            case 5:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "auth-container is-flex is-align-items-center is-justify-content-center"
  }, [_vm.$showSpinnerRequestCount > 0 ? _c(_vm.spinner, {
    tag: "component"
  }) : _vm._e(), _c("div", {
    staticClass: "body-container"
  }, [_c("div", {
    staticClass: "box login-container"
  }, [_c("div", {
    staticClass: "login-logo"
  }, [_c("img", {
    attrs: {
      src: _vm.logoImgPath,
      alt: "Flexiquote Logo",
      title: "Flexiquote Logo"
    }
  })]), _vm.title ? _c("div", {
    staticClass: "login-title"
  }, [_vm._v(_vm._s(_vm.title))]) : _vm._e(), _vm._t("default")], 2), _c("div", {
    staticClass: "mobile-container has-text-centered"
  }, [_c("a", {
    attrs: {
      href: _vm.mobileUrl
    }
  }, [_c("i", {
    staticClass: "mdi mdi-camera",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v(" Mobile Image Uploader ")])]), _vm.errorMessage && !_vm.dismissed ? _c("div", {
    staticClass: "error-message-container",
    attrs: {
      role: "alert"
    }
  }, [_c("button", {
    staticClass: "error-close",
    attrs: {
      type: "button",
      "aria-label": "Close"
    },
    on: {
      click: function click($event) {
        _vm.dismissed = true;
      }
    }
  }, [_c("span", {
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v("×")])]), _c("strong", [_vm._v("Error:")]), _vm._v(" " + _vm._s(_vm.errorMessage) + " ")]) : _vm._e()])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("form", {
    on: {
      submit: function submit($event) {
        $event.preventDefault();
        return _vm.submit.apply(null, arguments);
      }
    }
  }, [_c("input", {
    staticClass: "is-hidden",
    attrs: {
      type: "text",
      autocomplete: "username"
    },
    domProps: {
      value: _vm.username
    }
  }), _c("p", {
    staticClass: "mb-4"
  }, [_vm._v("First time signing in! Please enter and confirm a new password")]), _c("div", {
    staticClass: "control mb-4"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "".concat(_vm.idPrefix, "-newpassword")
    }
  }, [_vm._v("New Password")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newPassword,
      expression: "newPassword"
    }],
    staticClass: "input",
    attrs: {
      id: "".concat(_vm.idPrefix, "-newpassword"),
      type: "password",
      placeholder: "New Password",
      autocomplete: "new-password",
      disabled: _vm.isSubmitting
    },
    domProps: {
      value: _vm.newPassword
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.newPassword = $event.target.value;
      }, _vm.onNewPasswordInput]
    }
  }), _vm.touched && !_vm.newPassword ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "".concat(_vm.idPrefix, "-confirmpassword")
    }
  }, [_vm._v("Confirm Password")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.confirmPassword,
      expression: "confirmPassword"
    }],
    staticClass: "input",
    attrs: {
      id: "".concat(_vm.idPrefix, "-confirmpassword"),
      type: "password",
      placeholder: "Confirm Password",
      autocomplete: "new-password",
      disabled: _vm.isSubmitting
    },
    domProps: {
      value: _vm.confirmPassword
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.confirmPassword = $event.target.value;
      }
    }
  }), _vm.touched && !_vm.confirmPassword ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm.confirmPassword && _vm.confirmPassword !== _vm.newPassword ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Passwords do not match")]) : _vm._e()]), _vm.complexityMessage ? _c("span", {
    staticClass: "password-validity",
    class: _vm.meetsCriteria ? "is-strong" : "is-weak"
  }, [_vm._v(_vm._s(_vm.complexityMessage))]) : _vm._e()]), _c("div", {
    staticClass: "control is-flex is-justify-content-end"
  }, [_c("button", {
    staticClass: "button is-primary",
    attrs: {
      type: "submit",
      disabled: _vm.isSubmitting
    }
  }, [_vm._v(" Save "), _c("span", {
    staticClass: "icon ml-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.isSubmitting ? "mdi-loading mdi-spin" : "mdi-arrow-right"
  })])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(/*! ../../assets/images/flexiquoteloginbackground.jpg */ "./src/assets/images/flexiquoteloginbackground.jpg");
exports = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
exports.push([module.i, ".auth-container[data-v-64d8ae55] {\n  width: 100%;\n  min-height: 100vh;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") top center no-repeat !important;\n  background-size: cover !important;\n}\n.body-container[data-v-64d8ae55] {\n  position: relative;\n  width: 350px;\n}\n.login-logo[data-v-64d8ae55] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  margin-top: 1rem;\n  margin-bottom: 2.5rem;\n}\n.login-logo img[data-v-64d8ae55] {\n  height: 40px;\n}\n.login-container[data-v-64d8ae55] {\n  width: 100%;\n  border-radius: 10px !important;\n  padding: 1rem;\n}\n.login-title[data-v-64d8ae55] {\n  font-size: 20px;\n  font-weight: 400;\n  margin-bottom: 1rem;\n}\n.mobile-container[data-v-64d8ae55] {\n  width: 100%;\n  margin-top: 1rem;\n}\n.mobile-container a[data-v-64d8ae55] {\n  color: white;\n  text-decoration: none;\n  font-size: 0.9rem;\n}\n.error-message-container[data-v-64d8ae55] {\n  position: absolute;\n  top: 100%;\n  width: 100%;\n  margin-top: 20px;\n  padding: 15px 35px 15px 15px;\n  border: 1px solid #ebccd1;\n  border-radius: 4px;\n  background-color: #f2dede;\n  color: #a94442;\n  font-size: 0.9rem;\n}\n.error-message-container strong[data-v-64d8ae55] {\n  color: inherit;\n}\n.error-close[data-v-64d8ae55] {\n  position: absolute;\n  top: 8px;\n  right: 10px;\n  padding: 0;\n  border: 0;\n  background: none;\n  color: inherit;\n  font-size: 21px;\n  line-height: 1;\n  font-weight: bold;\n  opacity: 0.2;\n  cursor: pointer;\n}\n.error-close[data-v-64d8ae55]:hover {\n  opacity: 0.5;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".label[data-v-61b1fb34] {\n  font-weight: 500;\n}\n.password-validity.is-strong[data-v-61b1fb34] {\n  color: green;\n}\n.password-validity.is-weak[data-v-61b1fb34] {\n  color: red;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("55f3c740", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("610d3d71", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/images/flexiquoteloginbackground.jpg":
/*!*********************************************************!*\
  !*** ./src/assets/images/flexiquoteloginbackground.jpg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/flexiquoteloginbackground.a7bed929.jpg";

/***/ }),

/***/ "./src/services/platform.js":
/*!**********************************!*\
  !*** ./src/services/platform.js ***!
  \**********************************/
/*! exports provided: detectPlatform, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detectPlatform", function() { return detectPlatform; });
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__);



function detectPlatform() {
  var ua = typeof navigator !== 'undefined' && navigator.userAgent || '';
  var osId = 'Unknown';
  var m;
  if (m = /Windows NT ([\d.]+)/.exec(ua)) {
    var map = {
      '10.0': '10/11',
      '6.3': '8.1',
      '6.2': '8',
      '6.1': '7',
      '6.0': 'Vista',
      '5.1': 'XP'
    };
    osId = 'Windows ' + (map[m[1]] || m[1]);
  } else if (m = /Mac OS X ([\d_]+)/.exec(ua)) {
    osId = 'macOS ' + m[1].replace(/_/g, '.');
  } else if (m = /Android ([\d.]+)/.exec(ua)) {
    osId = 'Android ' + m[1];
  } else if (m = /(iPhone|iPad); CPU [^ ]+ OS ([\d_]+)/.exec(ua)) {
    osId = m[1] + ' iOS ' + m[2].replace(/_/g, '.');
  } else if (/CrOS/.test(ua)) {
    osId = 'ChromeOS';
  } else if (/Linux/.test(ua)) {
    osId = 'Linux';
  }
  var browserId = 'Unknown';
  if (m = /Edg\/([\d.]+)/.exec(ua)) browserId = 'Edge ' + m[1];else if (m = /OPR\/([\d.]+)/.exec(ua)) browserId = 'Opera ' + m[1];else if (m = /Firefox\/([\d.]+)/.exec(ua)) browserId = 'Firefox ' + m[1];else if (m = /Chrome\/([\d.]+)/.exec(ua)) browserId = 'Chrome ' + m[1];else if (m = /Version\/([\d.]+).*Safari/.exec(ua)) browserId = 'Safari ' + m[1];
  return {
    osId: osId,
    browserId: browserId
  };
}
/* harmony default export */ __webpack_exports__["default"] = ({
  detectPlatform: detectPlatform
});

/***/ }),

/***/ "./src/views/auth/AuthCard.vue":
/*!*************************************!*\
  !*** ./src/views/auth/AuthCard.vue ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true */ "./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true");
/* harmony import */ var _AuthCard_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AuthCard.vue?vue&type=script&lang=js */ "./src/views/auth/AuthCard.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true */ "./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AuthCard_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "64d8ae55",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/AuthCard.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/AuthCard.vue?vue&type=script&lang=js":
/*!*************************************************************!*\
  !*** ./src/views/auth/AuthCard.vue?vue&type=script&lang=js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthCard.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true":
/*!**********************************************************************************************!*\
  !*** ./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=style&index=0&id=64d8ae55&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_style_index_0_id_64d8ae55_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true":
/*!*******************************************************************************!*\
  !*** ./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/AuthCard.vue?vue&type=template&id=64d8ae55&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AuthCard_vue_vue_type_template_id_64d8ae55_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/auth/ErrorMessage.js":
/*!****************************************!*\
  !*** ./src/views/auth/ErrorMessage.js ***!
  \****************************************/
/*! exports provided: getErrorMessage, getApiErrorMessage, isSignInTicketExpired */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessage", function() { return getErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApiErrorMessage", function() { return getApiErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSignInTicketExpired", function() { return isSignInTicketExpired; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);

var errorMessages = {
  'default': {
    title: 'Something wrong',
    message: 'Something wrong. Please get in touch with support.'
  },
  'password_not_meet_criteria': {
    title: 'Password not meet criteria',
    message: 'The password you provided does not meet criteria.'
  },
  'forget_password_request_not_found': {
    title: 'Forget Password Request not found',
    message: 'Forget password request not found. Please send a new request.'
  },
  'no_valid_user_found': {
    title: 'No valid user found',
    message: 'We could not locate a user matching information you provided. Please get in touch with support.'
  },
  'failed_send_email_with_mailgun': {
    title: 'Failed to send an email',
    message: 'Failed to send an email. Please get in touch with support.'
  },
  'failed_create_password_entry': {
    title: 'Failed to create password entry',
    message: 'Failed to create password entry. Please get in touch with support.'
  },
  'failed_insert_emailoutgoing': {
    title: 'Failed to insert email outgoing record',
    message: 'Failed to insert email outgoing record. Please get in touch with support.'
  },
  'password_reset_link_expired': {
    title: 'Expired password reset link',
    message: 'The password reset link has expired. Please send a new request.'
  },
  'password_reset_link_used': {
    title: 'Used password reset link',
    message: 'The password reset link has already been used. Please send a new request.'
  },
  'not_valid_user_token': {
    title: 'Invalid user token',
    message: 'Not valid user. Please contact support.'
  }
};
var getErrorMessage = function getErrorMessage(errorCode) {
  return errorMessages[errorCode] || errorMessages['default'];
};

/**
 * Text to show for a failed sign-in call.
 *
 * Distinct from getErrorMessage above, which maps known error *codes* to friendly copy. The
 * sign-in endpoints instead return literal user-facing strings ("Invalid credentials, you have
 * 3 remaining attempts", "You have been locked out. Try again in ...") deliberately matched to
 * the wording of the legacy login page, so the server's message is the message to display.
 *
 * ASP.NET Web API serialises Request.CreateErrorResponse as {"Message": "..."}, but the shape
 * varies across the endpoints and proxies involved, so each known form is checked in turn.
 *
 * A few of these endpoints do return a bare code rather than prose - the password-change path
 * surfaces 'password_not_meet_criteria' straight from UpdateUserPassword - so anything matching
 * a known code is translated rather than shown to the user verbatim.
 */
var getApiErrorMessage = function getApiErrorMessage(error, fallback) {
  var data = error && error.response ? error.response.data : null;
  var raw = null;
  if (typeof data === 'string' && data.trim()) {
    raw = data;
  } else if (data) {
    if (typeof data.Message === 'string' && data.Message.trim()) raw = data.Message;else if (typeof data.message === 'string' && data.message.trim()) raw = data.message;else if (typeof data.ExceptionMessage === 'string' && data.ExceptionMessage.trim()) raw = data.ExceptionMessage;
  }
  if (!raw) return fallback || 'Something went wrong. Please try again.';
  var trimmed = raw.trim();
  return errorMessages[trimmed] ? errorMessages[trimmed].message : trimmed;
};

/**
 * True when a sign-in step failed because its server-side ticket is gone. The only way on from
 * there is to enter the password again for a fresh ticket.
 */
var isSignInTicketExpired = function isSignInTicketExpired(error) {
  var data = error && error.response ? error.response.data : null;
  return !!data && data.code === 'signin_ticket_expired';
};

/***/ }),

/***/ "./src/views/auth/NewPasswordPanel.vue":
/*!*********************************************!*\
  !*** ./src/views/auth/NewPasswordPanel.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true */ "./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true");
/* harmony import */ var _NewPasswordPanel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NewPasswordPanel.vue?vue&type=script&lang=js */ "./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true */ "./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _NewPasswordPanel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "61b1fb34",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/NewPasswordPanel.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js":
/*!*********************************************************************!*\
  !*** ./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NewPasswordPanel.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true":
/*!******************************************************************************************************!*\
  !*** ./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=style&index=0&id=61b1fb34&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_style_index_0_id_61b1fb34_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true":
/*!***************************************************************************************!*\
  !*** ./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/NewPasswordPanel.vue?vue&type=template&id=61b1fb34&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewPasswordPanel_vue_vue_type_template_id_61b1fb34_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=13.js.map