(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[8],{

/***/ "./src/views/quote/components/repairAreaGroupingData.js":
/*!**************************************************************!*\
  !*** ./src/views/quote/components/repairAreaGroupingData.js ***!
  \**************************************************************/
/*! exports provided: repairAreas, repairSections, repairAreaGroupingData, sectionToAreaMapping, getPartsByArea, getAllRepairAreas, mapPartIdToSection, selectionItemsToCodes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "repairAreas", function() { return repairAreas; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "repairSections", function() { return repairSections; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "repairAreaGroupingData", function() { return repairAreaGroupingData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sectionToAreaMapping", function() { return sectionToAreaMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPartsByArea", function() { return getPartsByArea; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAllRepairAreas", function() { return getAllRepairAreas; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapPartIdToSection", function() { return mapPartIdToSection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectionItemsToCodes", function() { return selectionItemsToCodes; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_25__);


























var repairAreas = {
  Front: 'Front',
  Centre: 'Centre',
  Rear: 'Rear',
  TrimGlass: 'Trim/Glass'
};
var repairSections = {
  //front
  LeftFrontLamps: 'LeftFrontLamps',
  FrontBumper: 'FrontBumper',
  RightFrontLamps: 'RightFrontLamps',
  LeftFrontGuard: 'LeftFrontGuard',
  Bonnet: 'Bonnet',
  RightFrontGuard: 'RightFrontGuard',
  LeftFrontDoor: 'LeftFrontDoor',
  RightFrontDoor: 'RightFrontDoor',
  //centre
  LeftCantRail: 'LeftCantRail',
  RightCantRail: 'RightCantRail',
  Turret: 'Turret',
  //rear
  LeftRearDoor: 'LeftRearDoor',
  RightRearDoor: 'RightRearDoor',
  LeftQuarterPanel: 'LeftQuarterPanel',
  Bootlid: 'Bootlid',
  RightQuarterPanel: 'RightQuarterPanel',
  LeftRearLamps: 'LeftRearLamps',
  RearBumper: 'RearBumper',
  RightRearLamps: 'RightRearLamps',
  //trim/glass
  FrontWindscreen: 'FrontWindscreen',
  RearWindscreen: 'RearWindscreen'
};
var repairAreaGroupingData = {
  front: {
    sortOrder: 1,
    title: 'Front',
    area: repairAreas.Front,
    items: [{
      partName: 'Left Front Lamp',
      partId: 'LFL',
      sortOrder: 3
    }, {
      partName: 'Front Bumper Bar',
      partId: 'FB',
      sortOrder: 2
    }, {
      partName: 'Grille',
      partId: 'G',
      sortOrder: 1
    }, {
      partName: 'Right Front Lamp',
      partId: 'RFL',
      sortOrder: 4
    }, {
      partName: 'Left Front Guard',
      partId: 'LFG',
      sortOrder: 5
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }, {
      partName: 'Air Conditioning',
      partId: 'AC',
      sortOrder: 35
    }, {
      partName: 'Bonnet',
      partId: 'B',
      sortOrder: 7
    }, {
      partName: 'Chassis Assembly',
      partId: 'FC',
      sortOrder: 41
    }, {
      partName: 'Front Apron',
      partId: 'FP',
      sortOrder: 8
    }, {
      partName: 'Front Chassis',
      partId: 'CF',
      sortOrder: 40
    }, {
      partName: 'Radiator',
      partId: 'RA',
      sortOrder: 36
    }, {
      partName: 'Radiator Support',
      partId: 'RS',
      sortOrder: 26
    }, {
      partName: 'Engine',
      partId: 'E',
      sortOrder: 38
    }, {
      partName: 'Engine Bay Parts',
      partId: 'EBH',
      sortOrder: 37
    }, {
      partName: 'Front Suspension, Steering & Wheels',
      partId: 'FM',
      sortOrder: 42
    }, {
      partName: 'Right Front Guard',
      partId: 'RFG',
      sortOrder: 6
    }, {
      partName: 'Left Front Door',
      partId: 'LFD',
      sortOrder: 25
    }, {
      partName: 'Left Front Pillar',
      partId: 'LFH',
      sortOrder: 34
    }, {
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Right Front Door',
      partId: 'RFD',
      sortOrder: 9
    }, {
      partName: 'Right Front Pillar',
      partId: 'RFH',
      sortOrder: 28
    }, {
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }],
    partIds: ['LFL', 'FB', 'G', 'RFL', 'LFG', 'B', 'AC', 'FC', 'FP', 'CF', 'RA', 'RS', 'RFG', 'LFD', 'LFH', 'LSP', 'LBP', 'RFD', 'RFH', 'RSP', 'RBP']
  },
  centre: {
    sortOrder: 2,
    title: 'Centre',
    area: repairAreas.Centre,
    items: [{
      partName: 'Antenna',
      partId: 'AE',
      sortOrder: 20
    }, {
      partName: 'Floor Panel',
      partId: 'FPAN',
      sortOrder: 30
    }, {
      partName: 'Left Cant Rail',
      partId: 'LCR',
      sortOrder: 50
    }, {
      partName: 'Right Cant Rail',
      partId: 'RCR',
      sortOrder: 49
    }, {
      partName: 'Turret',
      partId: 'T',
      sortOrder: 19
    }, {
      partName: 'Interior Trims',
      partId: 'I',
      sortOrder: 22
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }, {
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Centre Pillar',
      partId: 'LCP',
      sortOrder: 33
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Centre Pillar',
      partId: 'RCP',
      sortOrder: 29
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }, {
      partName: 'Dash & Glove Box',
      partId: 'D',
      sortOrder: 21
    }],
    partIds: ['AE', 'FPAN', 'LCR', 'RCR', 'T', 'I', 'OL', 'LSP', 'LCP', 'LBP', 'RSP', 'RCP', 'RBP', 'D']
  },
  rear: {
    sortOrder: 3,
    title: 'Rear',
    area: repairAreas.Rear,
    items: [{
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Centre Pillar',
      partId: 'LCP',
      sortOrder: 33
    }, {
      partName: 'Left Rear Door',
      partId: 'LRD',
      sortOrder: 23
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }, {
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Centre Pillar',
      partId: 'RCP',
      sortOrder: 29
    }, {
      partName: 'Right Rear Door',
      partId: 'RRD',
      sortOrder: 11
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }, {
      partName: 'Left Quarter Panel',
      partId: 'LQP',
      sortOrder: 22
    }, {
      partName: 'Rear Suspension, Tank & Wheels',
      partId: 'RM',
      sortOrder: 43
    }, {
      partName: 'Beaver Panel',
      partId: 'BP',
      sortOrder: 32
    }, {
      partName: 'Boot Floor',
      partId: 'BF',
      sortOrder: 31
    }, {
      partName: 'Boot Lid',
      partId: 'BL',
      sortOrder: 17
    }, {
      partName: 'Tail Gate',
      partId: 'TG',
      sortOrder: 18
    }, {
      partName: 'Exhaust',
      partId: 'EXH',
      sortOrder: 39
    }, {
      partName: 'Fuel Tank',
      partId: 'FT',
      sortOrder: 51
    }, {
      partName: 'Rear Quarter Panel',
      partId: 'RQP',
      sortOrder: 12
    }, {
      partName: 'Rear Lamp',
      partId: 'RL',
      sortOrder: 14
    }, {
      partName: 'Rear Bumper Bar',
      partId: 'RB',
      sortOrder: 15
    }, {
      partName: 'Rear License Plate',
      partId: 'RNP',
      sortOrder: 16
    }],
    partIds: ['LSP', 'LCP', 'LRD', 'LBP', 'OL', 'RSP', 'RCP', 'RRD', 'RBP', 'RM', 'BP', 'BF', 'BL', 'TG', 'RQP', 'RL', 'RB', 'RNP']
  },
  trimGlass: {
    sortOrder: 4,
    title: 'Trim/Glass',
    area: repairAreas.TrimGlass,
    items: [{
      partName: 'Front Windscreen',
      partId: 'FW',
      sortOrder: 44
    }, {
      partName: 'Plenum & Firewall',
      partId: 'SP',
      sortOrder: 27
    }, {
      partName: 'Rear Windscreen',
      partId: 'RW',
      sortOrder: 45
    }],
    partIds: ['FW', 'SP', 'RW']
  }
};
var sectionToAreaMapping = {
  // Front area sections
  'LeftFrontLamps': {
    //F1
    area: 'Front',
    section: repairSections.LeftFrontLamps,
    items: [{
      partName: 'Left Front Lamp',
      partId: 'LFL',
      sortOrder: 3
    }]
  },
  'FrontBumper': {
    //F2
    area: 'Front',
    section: repairSections.FrontBumper,
    items: [{
      partName: 'Front Bumper Bar',
      partId: 'FB',
      sortOrder: 2
    }, {
      partName: 'Grille',
      partId: 'G',
      sortOrder: 1
    }]
  },
  'RightFrontLamps': {
    //F3
    area: 'Front',
    section: repairSections.RightFrontLamps,
    items: [{
      partName: 'Right Front Lamp',
      partId: 'RFL',
      sortOrder: 4
    }]
  },
  'LeftFrontGuard': {
    //F4
    area: 'Front',
    section: repairSections.LeftFrontGuard,
    items: [{
      partName: 'Left Front Guard',
      partId: 'LFG',
      sortOrder: 5
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'Bonnet': {
    //F5
    area: 'Front',
    section: repairSections.Bonnet,
    items: [{
      partName: 'Air Conditioning',
      partId: 'AC',
      sortOrder: 35
    }, {
      partName: 'Bonnet',
      partId: 'B',
      sortOrder: 7
    }, {
      partName: 'Chassis Assembly',
      partId: 'FC',
      sortOrder: 41
    }, {
      partName: 'Front Apron',
      partId: 'FP',
      sortOrder: 8
    }, {
      partName: 'Front Chassis',
      partId: 'CF',
      sortOrder: 40
    }, {
      partName: 'Radiator',
      partId: 'RA',
      sortOrder: 36
    }, {
      partName: 'Radiator Support',
      partId: 'RS',
      sortOrder: 26
    }, {
      partName: 'Engine',
      partId: 'E',
      sortOrder: 38
    }, {
      partName: 'Engine Bay Parts',
      partId: 'EBH',
      sortOrder: 37
    }, {
      partName: 'Front Suspension, Steering & Wheels',
      partId: 'FM',
      sortOrder: 42
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'RightFrontGuard': {
    //F6
    area: 'Front',
    section: repairSections.RightFrontGuard,
    items: [{
      partName: 'Right Front Guard',
      partId: 'RFG',
      sortOrder: 6
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'LeftFrontDoor': {
    //F7
    area: 'Front',
    section: repairSections.LeftFrontDoor,
    items: [{
      partName: 'Left Front Door',
      partId: 'LFD',
      sortOrder: 25
    }, {
      partName: 'Left Front Pillar',
      partId: 'LFH',
      sortOrder: 34
    }, {
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'RightFrontDoor': {
    //F8
    area: 'Front',
    section: repairSections.RightFrontDoor,
    items: [{
      partName: 'Right Front Door',
      partId: 'RFD',
      sortOrder: 9
    }, {
      partName: 'Right Front Pillar',
      partId: 'RFH',
      sortOrder: 28
    }, {
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  // Centre area sections
  'Turret': {
    //C1
    area: 'Centre',
    section: repairSections.Turret,
    items: [{
      partName: 'Antenna',
      partId: 'AE',
      sortOrder: 20
    }, {
      partName: 'Floor Panel',
      partId: 'FPAN',
      sortOrder: 30
    }, {
      partName: 'Left Cant Rail',
      partId: 'LCR',
      sortOrder: 50
    }, {
      partName: 'Right Cant Rail',
      partId: 'RCR',
      sortOrder: 49
    }, {
      partName: 'Turret',
      partId: 'T',
      sortOrder: 19
    }, {
      partName: 'Dash & Glove Box',
      partId: 'D',
      sortOrder: 21
    }, {
      partName: 'Interior Trims',
      partId: 'I',
      sortOrder: 22
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'LeftCantRail': {
    //C2
    area: 'Centre',
    section: repairSections.LeftCantRail,
    items: [{
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Centre Pillar',
      partId: 'LCP',
      sortOrder: 33
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }]
  },
  'RightCantRail': {
    //C3
    area: 'Centre',
    section: repairSections.RightCantRail,
    items: [{
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Centre Pillar',
      partId: 'RCP',
      sortOrder: 29
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }]
  },
  // Rear area sections
  'LeftRearDoor': {
    //R1
    area: 'Rear',
    section: repairSections.LeftRearDoor,
    items: [{
      partName: 'Left Sill Panel',
      partId: 'LSP',
      sortOrder: 24
    }, {
      partName: 'Left Centre Pillar',
      partId: 'LCP',
      sortOrder: 33
    }, {
      partName: 'Left Rear Door',
      partId: 'LRD',
      sortOrder: 23
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'RightRearDoor': {
    //R2
    area: 'Rear',
    section: repairSections.RightRearDoor,
    items: [{
      partName: 'Right Sill Panel',
      partId: 'RSP',
      sortOrder: 10
    }, {
      partName: 'Right Centre Pillar',
      partId: 'RCP',
      sortOrder: 29
    }, {
      partName: 'Right Rear Door',
      partId: 'RRD',
      sortOrder: 11
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'LeftQuarterPanel': {
    //R3
    area: 'Rear',
    section: repairSections.LeftQuarterPanel,
    items: [{
      partName: 'Left Quarter Panel',
      partId: 'LQP',
      sortOrder: 22
    }, {
      partName: 'Left Body Side',
      partId: 'LBP',
      sortOrder: 34
    }, {
      partName: 'Rear Suspension, Tank & Wheels',
      partId: 'RM',
      sortOrder: 43
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'Bootlid': {
    //R4
    area: 'Rear',
    section: repairSections.Bootlid,
    items: [{
      partName: 'Beaver Panel',
      partId: 'BP',
      sortOrder: 32
    }, {
      partName: 'Boot Floor',
      partId: 'BF',
      sortOrder: 31
    }, {
      partName: 'Boot Lid',
      partId: 'BL',
      sortOrder: 17
    }, {
      partName: 'Tail Gate',
      partId: 'TG',
      sortOrder: 18
    }, {
      partName: 'Exhaust',
      partId: 'EXH',
      sortOrder: 39
    }, {
      partName: 'Fuel Tank',
      partId: 'FT',
      sortOrder: 51
    }, {
      partName: 'Rear Suspension, Tank & Wheels',
      partId: 'RM',
      sortOrder: 43
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'RightQuarterPanel': {
    //R5
    area: 'Rear',
    section: repairSections.RightQuarterPanel,
    items: [{
      partName: 'Rear Quarter Panel',
      partId: 'RQP',
      sortOrder: 12
    }, {
      partName: 'Right Body Side',
      partId: 'RBP',
      sortOrder: 35
    }, {
      partName: 'Rear Suspension, Tank & Wheels',
      partId: 'RM',
      sortOrder: 43
    }, {
      partName: 'Decal',
      partId: 'OL',
      sortOrder: 48
    }]
  },
  'LeftRearLamps': {
    //R6
    area: 'Rear',
    section: repairSections.LeftRearLamps,
    items: [{
      partName: 'Rear Lamp',
      partId: 'RL',
      sortOrder: 14
    }]
  },
  'RearBumper': {
    //R7
    area: 'Rear',
    section: repairSections.RearBumper,
    items: [{
      partName: 'Rear Bumper Bar',
      partId: 'RB',
      sortOrder: 15
    }, {
      partName: 'Rear License Plate',
      partId: 'RNP',
      sortOrder: 16
    }]
  },
  'RightRearLamps': {
    //R8
    area: 'Rear',
    section: repairSections.RightRearLamps,
    items: [{
      partName: 'Rear Lamp',
      partId: 'RL',
      sortOrder: 14
    }]
  },
  // Trim/Glass area sections
  'FrontWindscreen': {
    //T1
    area: 'Trim/Glass',
    section: repairSections.FrontWindscreen,
    items: [{
      partName: 'Front Windscreen',
      partId: 'FW',
      sortOrder: 44
    }, {
      partName: 'Plenum & Firewall',
      partId: 'SP',
      sortOrder: 27
    }]
  },
  'RearWindscreen': {
    //T2
    area: 'Trim/Glass',
    section: repairSections.RearWindscreen,
    items: [{
      partName: 'Rear Windscreen',
      partId: 'RW',
      sortOrder: 45
    }]
  }
};

// Derive partIds from items so the two can't drift. They previously did: several codes
// (OL, E, EBH, FM, LQP, EXH, FT) were in items but missing from partIds, which made
// area lookups resolve them to 'Other'.
Object.values(repairAreaGroupingData).forEach(function (areaData) {
  areaData.partIds = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(new Set(areaData.items.map(function (item) {
    return item.partId;
  })));
});
var getPartsByArea = function getPartsByArea(area) {
  var areaKey = area.toLowerCase().replace('/', '').replace(' ', '');
  return repairAreaGroupingData[areaKey] || null;
};
var getAllRepairAreas = function getAllRepairAreas() {
  return Object.values(repairAreaGroupingData).sort(function (a, b) {
    return a.sortOrder - b.sortOrder;
  });
};
var mapPartIdToSection = function mapPartIdToSection(partId) {
  for (var _i = 0, _Object$entries = Object.entries(sectionToAreaMapping); _i < _Object$entries.length; _i++) {
    var _Object$entries$_i = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_Object$entries[_i], 2),
      sectionName = _Object$entries$_i[0],
      sectionData = _Object$entries$_i[1];
    if (sectionData.items && sectionData.items.some(function (item) {
      return item.partId === partId;
    })) {
      return sectionName;
    }
  }
  return null;
};

/**
 * VehicleButterflySelector selection items -> flat butterfly codes, for screens that
 * only need a `butterflyCode` filter value.
 *
 * The selector reports every part of every displayed area, checked or not, so filtering
 * on `selected` is required - otherwise touching one part filters by its whole area.
 * Codes are area-scoped in the selector (LSP, RSP, LBP, OL, LCP, RCP, RM appear in more
 * than one area, and both rear-lamp sections share RL), so the Set dedupe is required
 * too: the codes end up in a comma-joined varchar parameter where duplicates only waste
 * length.
 */
var selectionItemsToCodes = function selectionItemsToCodes(items) {
  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(new Set((items || []).filter(function (item) {
    return item.selected;
  }).map(function (item) {
    return item.partId;
  })));
};

/***/ }),

/***/ "./src/views/quote/storeMixin.js":
/*!***************************************!*\
  !*** ./src/views/quote/storeMixin.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");













var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  created: function created() {
    this.getCompanyItemTypes();
    this.getJobStages(); // Store job stages in vuex
    // this.getExternalSetting('partscheck')
    //this.getSubJobStages() // Store job stages in vuex
    this.getJobNSubJobStages();
    this.getExternalSetting('partscheck');
    // if (this.$route.name !== QuoteRoutes.QuoteListView.name && this.value) {
    //   console.log('get vvvv')
    //   this.getQuoteVehicle(this.value.vehicleId)
    // }
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    companyItemTypes: 'companyItemTypes',
    currentVehicleSnapshot: 'currentVehicleSnapshot',
    currentCustomerSnapshot: 'currentCustomerSnapshot',
    currentInsurerSnapshot: 'currentInsurerSnapshot',
    quoteVehicle: 'quoteVehicle',
    quoteCustomer: 'quoteCustomer',
    quoteInsurer: 'quoteInsurer',
    emtaVehicleStore: 'emtaVehicle',
    standardLabourItems: 'standardLabourItems',
    ntarLoadingItems: 'ntarLoadingItems',
    ntarOtherLoadingItems: 'ntarOtherLoadingItems',
    ntarLoadingValues: 'ntarLoadingValues',
    jobStages: 'jobStages',
    subJobStages: 'subJobStages',
    jobNSubJobStages: 'jobNSubJobStages',
    repairDelayReasons: 'repairDelayReasons',
    partsCheckSettingExists: 'partsCheckSettingExists',
    readOnlyView: 'readOnlyView',
    previousQuoteId: 'previousQuoteId',
    audanetLock: 'audanetLock',
    snapshotDiffVehicle: 'snapshotDiffVehicle',
    snapshotDiffCustomer: 'snapshotDiffCustomer',
    snapshotDiffInsurer: 'snapshotDiffInsurer',
    partsCheckSetting: 'partsCheckSetting'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])(moduleName, ['load', 'getStoreItem', 'getLiteStoreItem', 'addStoreItem', 'addStoreSupplementaryItem', 'saveSnapshot', 'setBaseSnapshot', 'setBaseSnapshotFields', 'clearSnapshots', 'clearHeaders', 'setReturnRoute', 'getCompanyItemTypes', 'getQuoteVehicle', 'getNewVehicle', 'removeQuoteVehicle', 'getQuoteCustomer', 'getNewCustomer', 'removeQuoteCustomer', 'getEmtaVehicle', 'setEmtaVehicle', 'resetEmtaVehicle', 'clearInvoiceState', 'copyStoreQuote', 'getQuoteInsurer', 'getNewInsurer', 'setQuoteInsurer', 'removeQuoteInsurer', 'getStandardLabourItems', 'getNtarLoadingItems', 'getNtarOtherLoadingItems', 'removeLabourItems', 'getNtarLoadingValues', 'getJobStages', 'getSubJobStages', 'getJobNSubJobStages', 'removeJobStages', 'getExternalSetting', 'setReadOnlyView', 'setPreviousQuoteId', 'setAudaNetLock', 'setQuoteVehicle', 'saveVehicleSnapshot', 'saveCustomerSnapshot', 'saveInsurerSnapshot', 'resetJobNSubJobStages'])), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('insurers', {
    setInsurerReturnRoute: 'setReturnRoute',
    editStoreInsurer: 'editStoreItem',
    addStoreInsurer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('vehicles', {
    setVehicleReturnRoute: 'setReturnRoute',
    editStoreVehicle: 'editStoreItem',
    addStoreVehicle: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  })),
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(to, from, next) {
      var isQuoteRoutes;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            // remove quote vehicle, customer & insurer vuex objects when leaving quote pages
            isQuoteRoutes = Object.values(_route_types__WEBPACK_IMPORTED_MODULE_12__["default"]).filter(function (r) {
              return r.name !== _route_types__WEBPACK_IMPORTED_MODULE_12__["default"].QuoteListView.name;
            }).find(function (r) {
              return r.name === to.name;
            });
            if (!isQuoteRoutes) {
              this.resetEmtaVehicle();
              this.removeLabourItems();
            }
            next();
          case 1:
            return _context.a(2);
        }
      }, _callee, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ }),

/***/ "./src/views/quotetemplate/columns.js":
/*!********************************************!*\
  !*** ./src/views/quotetemplate/columns.js ***!
  \********************************************/
/*! exports provided: AvailableLabourColumns, LabourColumns, MiscColumns, QuoteTemplateListColumns, SubletColumns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvailableLabourColumns", function() { return AvailableLabourColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabourColumns", function() { return LabourColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MiscColumns", function() { return MiscColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuoteTemplateListColumns", function() { return QuoteTemplateListColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubletColumns", function() { return SubletColumns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var QuoteTemplateListColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Name', 'name', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Type', 'quoteType', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Created Date', 'createdDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour Times', 'timesType', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Tag/s', 'tags', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var LabourColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ItemNo', 'itemNo', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Description', 'itemDesc', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rpt', 'reportOnly', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Type', 'itemType', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var AvailableLabourColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ItemNo', 'itemNo', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Description', 'itemDesc', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var MiscColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ItemNo', 'itemNo', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Description', 'itemDesc', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rpt', 'reportOnly', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Charge', 'value', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var SubletColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ItemNo', 'itemNo', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Description', 'itemDesc', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rpt', 'reportOnly', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Charge', 'value', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ })

}]);
//# sourceMappingURL=8.js.map