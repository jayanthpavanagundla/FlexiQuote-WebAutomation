(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-documents-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_AgentService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/AgentService */ "./src/services/AgentService.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storeMixin */ "./src/components/Agent/storeMixin.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AgentScanButton',
  components: {},
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_4__["default"]],
  props: {},
  data: function data() {
    return {};
  },
  computed: {},
  watch: {},
  created: function created() {},
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    scan: function scan() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var deviceName, resolutionName, pixelTypeName, b64Image;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!(!_this.$agentIsScannerReady || _this.$licenceExpired)) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              deviceName = _store_utils__WEBPACK_IMPORTED_MODULE_3__["default"].getLocalStorage('scanner', 'deviceName');
              resolutionName = _store_utils__WEBPACK_IMPORTED_MODULE_3__["default"].getLocalStorage('scanner', 'resolutionName');
              pixelTypeName = _store_utils__WEBPACK_IMPORTED_MODULE_3__["default"].getLocalStorage('scanner', 'pixelTypeName');
              _context.n = 2;
              return _services_AgentService__WEBPACK_IMPORTED_MODULE_2__["default"].Scanner.scan(deviceName, resolutionName, pixelTypeName);
            case 2:
              b64Image = _context.v;
              //await AgentService.Scanner.getDevices(deviceName, resolutionName, pixelTypeName)

              _this.$emit('scan-results', b64Image);
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BaseModalEx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BaseModalEx */ "./src/components/BulmaModal/BaseModalEx.vue");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ConfirmModal',
  components: {
    BaseModalEx: _BaseModalEx__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'fadeIn'
    },
    animationOut: {
      type: String,
      default: 'fadeOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    okText: {
      type: String,
      default: 'Ok'
    },
    okTooltip: {
      type: String,
      default: ''
    },
    okClass: {
      type: String,
      default: 'is-primary'
    },
    cancelText: {
      type: String,
      default: 'Cancel'
    },
    cancelTooltip: {
      type: String,
      default: ''
    },
    cancelClass: {
      type: String,
      default: ''
    },
    showCancel: {
      type: Boolean,
      default: true
    },
    closeText: {
      type: String,
      default: 'Close'
    },
    closeTooltip: {
      type: String,
      default: ''
    },
    closeClass: {
      type: String,
      default: ''
    },
    showClose: {
      type: Boolean,
      default: false
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'warning' // 'mdi-alert-decagram'
    }
  },
  data: function data() {
    return {
      isActive: this.active || false
    };
  },
  watch: {
    active: function active(value) {
      this.isActive = value;
    }
  },
  methods: {
    ok: function ok() {
      this.$emit('ok');
    },
    cancel: function cancel() {
      this.$emit('cancel');
    },
    close: function close() {
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/FileDropZone.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/FileDropZone.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_VueDropzone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/VueDropzone */ "./src/components/VueDropzone/index.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");








/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FileDropZone',
  components: {
    VueDropzone: _components_VueDropzone__WEBPACK_IMPORTED_MODULE_6__["default"]
  },
  props: {
    quoteId: {
      type: String
    },
    quoteAttachmentCategoryId: {
      type: String
    },
    previewsContainer: {
      type: String,
      default: null
    },
    defaultSize: {
      type: Number,
      default: 128
    },
    additionalClasses: {
      type: String,
      default: ''
    },
    maxFileSizeMb: {
      type: Number,
      default: 10
    }
  },
  data: function data() {
    return {
      id: null,
      dropzoneOptions: {
        url: '/',
        dictDefaultMessage: 'Drop files here or click to upload',
        autoProcessQueue: false,
        thumbnailWidth: this.defaultSize,
        thumbnailHeight: this.defaultSize,
        maxFilesize: this.maxFileSizeMb,
        resizeWidth: 800,
        acceptedFiles: 'image/jpeg,image/jpg,image/png,image/gif,image/bmp,application/pdf',
        previewsContainer: this.previewsContainer
      }
    };
  },
  computed: {},
  watch: {
    // PCK-213 - the cap arrives from the API after this component is created, and VueDropzone
    // builds Dropzone once from its options, so the live instance needs setOption too.
    maxFileSizeMb: function maxFileSizeMb(mb) {
      this.dropzoneOptions.maxFilesize = mb;
      if (this.$refs.filedropzone) {
        this.$refs.filedropzone.setOption('maxFilesize', mb);
      }
    }
  },
  created: function created() {},
  mounted: function mounted() {
    this.id = this._uid + '';
  },
  methods: {
    acceptFile: function acceptFile(file) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var allowedTypes, errorMsg, maxFileSizeInBytes, _errorMsg, packet;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/bmp', 'image/webp', 'application/pdf'];
              if (allowedTypes.includes(file.type)) {
                _context.n = 1;
                break;
              }
              errorMsg = 'Unsupported file type';
              file.accepted = false;
              file.errorMessage = errorMsg;
              _this.$refs.filedropzone.dropzone.emit('error', file, errorMsg);
              _this.$refs.filedropzone.dropzone.emit('complete', file);
              return _context.a(2);
            case 1:
              // Check file size (maxFilesize is in MB, file.size is in bytes)
              maxFileSizeInBytes = _this.dropzoneOptions.maxFilesize * 1024 * 1024;
              if (!(file.size > maxFileSizeInBytes)) {
                _context.n = 2;
                break;
              }
              _errorMsg = "File size must not exceed ".concat(_this.dropzoneOptions.maxFilesize, "MB");
              file.accepted = false;
              file.errorMessage = _errorMsg;
              _this.$refs.filedropzone.dropzone.emit('error', file, _errorMsg);
              _this.$refs.filedropzone.dropzone.emit('complete', file);
              return _context.a(2);
            case 2:
              _this.$showSpinner();
              _context.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_7__["default"].getQuoteAttachmentUploadUrl(_this.quoteId);
            case 3:
              packet = _context.v.data;
              file.uploadURL = packet.url;
              file.guid = packet.guid;
              _this.$refs.filedropzone.processFile(file);
            case 4:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    dropzoneQueueComplete: function dropzoneQueueComplete() {
      this.$hideSpinner && this.$hideSpinner();
      this.$emit('queue-complete');
    },
    processFile: function processFile(file) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.$refs.filedropzone.changeUrl(file.uploadURL);
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    sendingFile: function sendingFile(file, xhr) {
      console.log(file, xhr);
    },
    successFile: function successFile(file) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_7__["default"].setupQuoteAttachment(_this3.quoteId, _this3.quoteAttachmentCategoryId, file.guid, file.name);
            case 1:
              _this3.$emit('image-uploaded', {});
              _this3.$hideSpinner();
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    dropzoneError: function dropzoneError(file, message, xhr) {},
    clearAllFiles: function clearAllFiles() {
      if (this.$refs.filedropzone && typeof this.$refs.filedropzone.removeAllFiles === 'function') {
        this.$refs.filedropzone.removeAllFiles(true);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_QuoteAttachmentCategory_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/QuoteAttachmentCategory.vue */ "./src/views/quote/components/QuoteAttachmentCategory.vue");
/* harmony import */ var _components_QuoteAttachmentCategoryModal_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/QuoteAttachmentCategoryModal.vue */ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _services_uploadLimits__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/services/uploadLimits */ "./src/services/uploadLimits.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteDocuments',
  components: {
    QuoteAttachmentCategory: _components_QuoteAttachmentCategory_vue__WEBPACK_IMPORTED_MODULE_14__["default"],
    QuoteAttachmentCategoryModal: _components_QuoteAttachmentCategoryModal_vue__WEBPACK_IMPORTED_MODULE_15__["default"]
  },
  props: {
    value: null
  },
  data: function data() {
    return {
      categories: [],
      attachments: {},
      isLoading: 0,
      modalOpen: false,
      // PCK-213 - replaced by the API values in created(). Seeded with the fallbacks so the
      // dropzone has a sane cap during the fetch.
      uploadMaxFileMb: 10,
      audaNetMaxFileMb: 1.5
    };
  },
  computed: {
    documentCount: function documentCount() {
      return Object.values(this.attachments).reduce(function (total, row) {
        return total + Object.values(row.quoteAttachments).length;
      }, 0);
    },
    maxFileSizeMb: function maxFileSizeMb() {
      var _this$$company;
      // AudaNet/Bridge quotes cap document uploads at 1.5MB (AudaNet submitFile limit) for shops with
      // AudaNet document upload enabled; everything else keeps the 10MB default
      var audaNetDocumentUploadEnabled = ((_this$$company = this.$company) === null || _this$$company === void 0 || (_this$$company = _this$$company.setting) === null || _this$$company === void 0 ? void 0 : _this$$company.audaNetDocumentUploadEnabled) === true;
      return audaNetDocumentUploadEnabled && this.value && (this.value.isAudaNet || this.value.isAudaBridge) ? this.audaNetMaxFileMb : this.uploadMaxFileMb;
    }
  },
  created: function created() {
    this.applyUploadLimits();
    this.getQuoteAttachmentCategories();
    this.getQuoteAttachments();
    this.setDocumentsAsRead();
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntityReloaded, this.getQuoteAttachments);
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntityReloaded, this.getQuoteAttachments);
  },
  mounted: function mounted() {},
  methods: {
    // Opening the tab is the read action - there is no explicit "mark as read" control,
    // by design. The dot is cleared straight away rather than on the sub nav's next poll;
    // a failure here is not worth interrupting the user for, since the next poll corrects it.
    setDocumentsAsRead: function setDocumentsAsRead() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee() {
        var quoteId, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              quoteId = _this.value && _this.value.quoteId;
              if (quoteId) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              _context.p = 1;
              _context.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].setDocumentsAsRead(quoteId);
            case 2:
              _this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].DocumentsRead);
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              console.error(_t);
            case 4:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    applyUploadLimits: function applyUploadLimits() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return Object(_services_uploadLimits__WEBPACK_IMPORTED_MODULE_17__["getMaxUploadFileMb"])();
            case 1:
              _this2.uploadMaxFileMb = _context2.v;
              _context2.n = 2;
              return Object(_services_uploadLimits__WEBPACK_IMPORTED_MODULE_17__["getAudaNetMaxFileMb"])();
            case 2:
              _this2.audaNetMaxFileMb = _context2.v;
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    handleUpdateAttachments: function handleUpdateAttachments(e) {
      var _this$categories;
      var category = e.category,
        attachment = e.attachment,
        isSelected = e.isSelected;
      var cloned = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_16___default()(this.categories);
      var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(cloned),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var c = _step.value;
          if (c.quoteAttachmentCategoryId != category.quoteAttachmentCategoryId) continue;
          // If select all/deselect all, update all attachments in this category
          if (attachment === 'ALL') {
            var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(c.attachments),
              _step2;
            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var a = _step2.value;
                a.isSelected = isSelected;
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }
          } else {
            var _iterator3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(c.attachments),
              _step3;
            try {
              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                var _a = _step3.value;
                if (_a.quoteAttachmentId != attachment.quoteAttachmentId) continue;
                _a.isSelected = isSelected;
                _a.orderIndex = attachment.orderIndex;
              }
            } catch (err) {
              _iterator3.e(err);
            } finally {
              _iterator3.f();
            }
          }
        }
        // Replace array reference for reactivity
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      (_this$categories = this.categories).splice.apply(_this$categories, [0, this.categories.length].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(cloned)));
    },
    toggleCategoryModal: function toggleCategoryModal(value) {
      this.modalOpen = value;
    },
    getAttachments: function getAttachments(quoteAttachmentCategoryId) {
      var _this$attachments$quo, _this$attachments$quo2;
      return Object.values(Object.values((_this$attachments$quo = (_this$attachments$quo2 = this.attachments[quoteAttachmentCategoryId]) === null || _this$attachments$quo2 === void 0 ? void 0 : _this$attachments$quo2.quoteAttachments) !== null && _this$attachments$quo !== void 0 ? _this$attachments$quo : {}));
    },
    sortQuoteAttachments: function sortQuoteAttachments() {
      if (this.categories.length == 0) {
        return;
      }
      var _iterator4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.categories),
        _step4;
      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var category = _step4.value;
          var attachments = this.getAttachments(category.quoteAttachmentCategoryId).sort(function (a, b) {
            return a.orderIndex > b.orderIndex;
          });
          var _iterator5 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(attachments),
            _step5;
          try {
            for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
              var attachment = _step5.value;
              attachment.isSelected = false;
            }
          } catch (err) {
            _iterator5.e(err);
          } finally {
            _iterator5.f();
          }
          category.attachments = attachments;
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
    },
    getQuoteAttachmentCategories: function getQuoteAttachmentCategories() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee3() {
        var response;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isLoading += 1;
              _context3.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].getQuoteAttachmentCategories();
            case 1:
              response = _context3.v;
              _this3.categories = response;
              _this3.isLoading -= 1;
              _this3.sortQuoteAttachments();
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getQuoteAttachments: function getQuoteAttachments() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee4() {
        var response, documentCount;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isLoading += 1;
              _context4.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].getQuoteAttachments(_this4.value.quoteId);
            case 1:
              response = _context4.v;
              _this4.attachments = response.data;
              documentCount = Object.values(_this4.attachments).reduce(function (total, row) {
                return total + Object.values(row.quoteAttachments).length;
              }, 0);
              _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].DocumentCountChanged, documentCount);
              _this4.isLoading -= 1;
              _this4.sortQuoteAttachments();
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array-buffer.constructor.js */ "./node_modules/core-js/modules/es.array-buffer.constructor.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array-buffer.slice.js */ "./node_modules/core-js/modules/es.array-buffer.slice.js");
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array-buffer.detached.js */ "./node_modules/core-js/modules/es.array-buffer.detached.js");
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer.js */ "./node_modules/core-js/modules/es.array-buffer.transfer.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer-to-fixed-length.js */ "./node_modules/core-js/modules/es.array-buffer.transfer-to-fixed-length.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.typed-array.uint8-array.js */ "./node_modules/core-js/modules/es.typed-array.uint8-array.js");
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.typed-array.at.js */ "./node_modules/core-js/modules/es.typed-array.at.js");
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.typed-array.copy-within.js */ "./node_modules/core-js/modules/es.typed-array.copy-within.js");
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.typed-array.every.js */ "./node_modules/core-js/modules/es.typed-array.every.js");
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.typed-array.fill.js */ "./node_modules/core-js/modules/es.typed-array.fill.js");
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.typed-array.filter.js */ "./node_modules/core-js/modules/es.typed-array.filter.js");
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.typed-array.find.js */ "./node_modules/core-js/modules/es.typed-array.find.js");
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-index.js */ "./node_modules/core-js/modules/es.typed-array.find-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last.js */ "./node_modules/core-js/modules/es.typed-array.find-last.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last-index.js */ "./node_modules/core-js/modules/es.typed-array.find-last-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.typed-array.for-each.js */ "./node_modules/core-js/modules/es.typed-array.for-each.js");
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.typed-array.includes.js */ "./node_modules/core-js/modules/es.typed-array.includes.js");
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.typed-array.index-of.js */ "./node_modules/core-js/modules/es.typed-array.index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.typed-array.iterator.js */ "./node_modules/core-js/modules/es.typed-array.iterator.js");
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/es.typed-array.join.js */ "./node_modules/core-js/modules/es.typed-array.join.js");
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/es.typed-array.last-index-of.js */ "./node_modules/core-js/modules/es.typed-array.last-index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! core-js/modules/es.typed-array.map.js */ "./node_modules/core-js/modules/es.typed-array.map.js");
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce.js */ "./node_modules/core-js/modules/es.typed-array.reduce.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce-right.js */ "./node_modules/core-js/modules/es.typed-array.reduce-right.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! core-js/modules/es.typed-array.reverse.js */ "./node_modules/core-js/modules/es.typed-array.reverse.js");
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! core-js/modules/es.typed-array.set.js */ "./node_modules/core-js/modules/es.typed-array.set.js");
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! core-js/modules/es.typed-array.slice.js */ "./node_modules/core-js/modules/es.typed-array.slice.js");
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! core-js/modules/es.typed-array.some.js */ "./node_modules/core-js/modules/es.typed-array.some.js");
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! core-js/modules/es.typed-array.sort.js */ "./node_modules/core-js/modules/es.typed-array.sort.js");
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! core-js/modules/es.typed-array.subarray.js */ "./node_modules/core-js/modules/es.typed-array.subarray.js");
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-locale-string.js */ "./node_modules/core-js/modules/es.typed-array.to-locale-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-reversed.js */ "./node_modules/core-js/modules/es.typed-array.to-reversed.js");
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-sorted.js */ "./node_modules/core-js/modules/es.typed-array.to-sorted.js");
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-string.js */ "./node_modules/core-js/modules/es.typed-array.to-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! core-js/modules/es.typed-array.with.js */ "./node_modules/core-js/modules/es.typed-array.with.js");
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var core_js_modules_web_atob_js__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! core-js/modules/web.atob.js */ "./node_modules/core-js/modules/web.atob.js");
/* harmony import */ var core_js_modules_web_atob_js__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_atob_js__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var core_js_modules_web_dom_exception_constructor_js__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! core-js/modules/web.dom-exception.constructor.js */ "./node_modules/core-js/modules/web.dom-exception.constructor.js");
/* harmony import */ var core_js_modules_web_dom_exception_constructor_js__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_exception_constructor_js__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var core_js_modules_web_dom_exception_stack_js__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! core-js/modules/web.dom-exception.stack.js */ "./node_modules/core-js/modules/web.dom-exception.stack.js");
/* harmony import */ var core_js_modules_web_dom_exception_stack_js__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_exception_stack_js__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var core_js_modules_web_dom_exception_to_string_tag_js__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! core-js/modules/web.dom-exception.to-string-tag.js */ "./node_modules/core-js/modules/web.dom-exception.to-string-tag.js");
/* harmony import */ var core_js_modules_web_dom_exception_to_string_tag_js__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_exception_to_string_tag_js__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var _QuoteAttachment_vue__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ./QuoteAttachment.vue */ "./src/views/quote/components/QuoteAttachment.vue");
/* harmony import */ var _components_FileDropZone_vue__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! @/components/FileDropZone.vue */ "./src/components/FileDropZone.vue");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _services_AgentService__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! @/services/AgentService */ "./src/services/AgentService.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var _QuoteNoSearchModal_vue__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(/*! ./QuoteNoSearchModal.vue */ "./src/views/quote/components/QuoteNoSearchModal.vue");
/* harmony import */ var _components_VueEmail__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(/*! @/components/VueEmail */ "./src/components/VueEmail/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var _components_printpreview_storeMixin_js__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(/*! @/components/printpreview/storeMixin.js */ "./src/components/printpreview/storeMixin.js");
/* harmony import */ var _components_Agent_AgentScanButton__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(/*! @/components/Agent/AgentScanButton */ "./src/components/Agent/AgentScanButton.vue");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var _components_BulmaModal_ConfirmModal_vue__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(/*! @/components/BulmaModal/ConfirmModal.vue */ "./src/components/BulmaModal/ConfirmModal.vue");













































































var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteAttachmentCategory',
  components: {
    QuoteAttachment: _QuoteAttachment_vue__WEBPACK_IMPORTED_MODULE_63__["default"],
    FileDropZone: _components_FileDropZone_vue__WEBPACK_IMPORTED_MODULE_64__["default"],
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_67___default.a,
    QuoteNoSearchModal: _QuoteNoSearchModal_vue__WEBPACK_IMPORTED_MODULE_68__["default"],
    VueEmail: _components_VueEmail__WEBPACK_IMPORTED_MODULE_69__["VueEmail"],
    VueEmailModal: _components_VueEmail__WEBPACK_IMPORTED_MODULE_69__["VueEmailModal"],
    AgentScanButton: _components_Agent_AgentScanButton__WEBPACK_IMPORTED_MODULE_74__["default"],
    ConfirmModal: _components_BulmaModal_ConfirmModal_vue__WEBPACK_IMPORTED_MODULE_76__["default"]
  },
  mixins: [_components_printpreview_storeMixin_js__WEBPACK_IMPORTED_MODULE_73__["default"]],
  props: {
    quoteId: {
      type: String
    },
    category: {
      type: Object,
      default: function _default() {}
    },
    attachments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    categories: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    maxFileSizeMb: {
      type: Number,
      default: 10
    }
  },
  data: function data() {
    return {
      isSending: false,
      isCopyImageModalActive: false,
      isEmailModalActive: false,
      isImageAttachActive: false,
      emailer: null,
      queuedFileCount: 0,
      // Track uploaded attachments
      isDeleteAllModalActive: false
    };
  },
  computed: {
    isSystemCategory: function isSystemCategory() {
      var _this$category;
      return ((_this$category = this.category) === null || _this$category === void 0 ? void 0 : _this$category.isSystem) === true;
    },
    allSelectedAttachments: function allSelectedAttachments() {
      var set = [];
      var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.categories),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var category = _step.value;
          var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])((category === null || category === void 0 ? void 0 : category.attachments) || []),
            _step2;
          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var attachment = _step2.value;
              if (!attachment.isSelected) {
                continue;
              }
              set.push(attachment);
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      return set;
    },
    selectedAttachments: function selectedAttachments() {
      return this.attachments.filter(function (row) {
        return row.isSelected;
      });
    },
    hasSelected: function hasSelected() {
      return this.selectedAttachments.length > 0;
    },
    // Locked documents (filed by an integration) can be viewed, downloaded and emailed, but not
    // deleted, moved or copied to another quote - those actions only apply to the rest.
    selectedUnlockedAttachments: function selectedUnlockedAttachments() {
      return this.selectedAttachments.filter(function (row) {
        return !row.isLocked;
      });
    },
    selectedLockedCount: function selectedLockedCount() {
      return this.selectedAttachments.length - this.selectedUnlockedAttachments.length;
    },
    hasSelectedUnlocked: function hasSelectedUnlocked() {
      return this.selectedUnlockedAttachments.length > 0;
    },
    enableSend: function enableSend() {
      var _this$emailer;
      return (((_this$emailer = this.emailer) === null || _this$emailer === void 0 || (_this$emailer = _this$emailer.toEmails) === null || _this$emailer === void 0 ? void 0 : _this$emailer.length) || 0) > 0 && !this.isEnteringNewEmail;
    }
  },
  created: function created() {
    this.clearSessionStorage();
  },
  mounted: function mounted() {
    this.resetEmailer();
  },
  methods: {
    handleAttachmentChange: function handleAttachmentChange(e, attachment) {
      this.$emit('update:attachments', Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
        category: this.category
      }, e));
    },
    handleScanResult: function handleScanResult(result) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var packet, uploadURL, guid, dateTimeStamp, fileName, base64toBlob;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].getQuoteAttachmentUploadUrl(_this.quoteId);
            case 1:
              packet = _context.v.data;
              uploadURL = packet.url;
              guid = packet.guid;
              dateTimeStamp = luxon__WEBPACK_IMPORTED_MODULE_75__["DateTime"].now().toFormat('yyyyMMddHHmmss');
              fileName = 'Scanned' + dateTimeStamp + '.png';
              base64toBlob = function base64toBlob(b64Data) {
                var contentType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
                var sliceSize = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 512;
                var byteCharacters = atob(b64Data);
                var byteArrays = [];
                for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                  var slice = byteCharacters.slice(offset, offset + sliceSize);
                  var byteNumbers = new Array(slice.length);
                  for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                  }
                  var byteArray = new Uint8Array(byteNumbers);
                  byteArrays.push(byteArray);
                }
                var blob = new Blob(byteArrays, {
                  type: contentType
                });
                return blob;
              };
              _context.n = 2;
              return _services_AgentService__WEBPACK_IMPORTED_MODULE_66__["default"].Scanner.uploadFile(uploadURL, base64toBlob(result, 'image/png'));
            case 2:
              _context.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].setupQuoteAttachment(_this.quoteId, _this.category.quoteAttachmentCategoryId, guid, fileName);
            case 3:
              _this.$emit('image-uploaded');
              _this.queuedFileCount++;
            case 4:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    sent: function sent() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.discardEmail();
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    attachMedia: function attachMedia() {},
    sendEmail: function sendEmail() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$refs.emailer.send();
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    discardEmail: function discardEmail() {
      this.isEmailModalActive = false;
      this.isImageAttachActive = false;
      this.resetEmailer();
    },
    resetEmailer: function resetEmailer() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var sessionEmailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              sessionEmailer = _this4.retrieveEmailer() || _store_utils__WEBPACK_IMPORTED_MODULE_71__["default"].getLocalStorage(_this4.$route.query.emailerId, 'emailer');
              if (sessionEmailer) {
                _this4.emailer = sessionEmailer;
              } else {
                _this4.emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_72___default()(_this4.getEmailer(_this4.$route.query.emailerId) || new _classes__WEBPACK_IMPORTED_MODULE_70__["Emailer"]());
              }
              _this4.emailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this4.$userInfo.companyName));
              _store_utils__WEBPACK_IMPORTED_MODULE_71__["default"].removeLocalStorage(_this4.$route.query.emailerId, 'emailer');
              _this4.persistEmailer();
              _this4.updateAttachmentList();
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    updateAttachmentList: function updateAttachmentList() {
      // PCK-213 - hand the composer sized objects on quoteAttachments, as PrintPreview does,
      // rather than bare filenames on attachments. Filenames counted as zero (totalAttachmentSize
      // skips strings) so the meter read 0 B, and removing a chip did not change what was sent
      // because the ids came from the allSelectedAttachments prop instead of the emailer.
      // attachments stays empty: entries in both lists would double-count in the total.
      this.emailer.attachments = [];
      this.$set(this.emailer, 'quoteAttachments', this.allSelectedAttachments.map(function (a) {
        return {
          quoteAttachmentId: a.quoteAttachmentId,
          fileName: a.filename,
          fileSize: a.fileSize
        };
      }));
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(this.emailer));
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
    },
    copyQuoteAttachmentToOtherQuote: function copyQuoteAttachmentToOtherQuote(targetQuoteId) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var rows, _iterator3, _step3, row, message, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              rows = _this5.selectedUnlockedAttachments;
              _iterator3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(rows);
              _context5.p = 1;
              _iterator3.s();
            case 2:
              if ((_step3 = _iterator3.n()).done) {
                _context5.n = 4;
                break;
              }
              row = _step3.value;
              _context5.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].copyQuoteAttachmentToQuote(_this5.quoteId, row.quoteAttachmentId, targetQuoteId, _this5.category.quoteAttachmentCategoryId, false);
            case 3:
              _context5.n = 2;
              break;
            case 4:
              _context5.n = 6;
              break;
            case 5:
              _context5.p = 5;
              _t = _context5.v;
              _iterator3.e(_t);
            case 6:
              _context5.p = 6;
              _iterator3.f();
              return _context5.f(6);
            case 7:
              _this5.toggleCopyAttachmentModal(false);
              message = "".concat(rows.length, " attachments copied");
              if (_this5.selectedLockedCount > 0) {
                message += ". ".concat(_this5.selectedLockedCount, " locked document(s) attached by an integration were not copied.");
              }
              _this5.$notification.openNotificationWithType('success', 'Copy attachments', message);
            case 8:
              return _context5.a(2);
          }
        }, _callee5, null, [[1, 5, 6, 7]]);
      }))();
    },
    toggleCopyAttachmentModal: function toggleCopyAttachmentModal(value) {
      this.isCopyImageModalActive = value;
    },
    getCompiledAttachmentDataUrl: function getCompiledAttachmentDataUrl(attachment) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              return _context6.a(2, attachment.externalStorageURL);
          }
        }, _callee6);
      }))();
    },
    downloadSelectedAttachmentsAsZip: function downloadSelectedAttachmentsAsZip() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        var JSZip, FileSaver, zip, attachments, fetchFile, _iterator4, _step4, attachment, url, blob, content, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.p = _context8.n) {
            case 0:
              _context8.n = 1;
              return __webpack_require__.e(/*! import() */ 40).then(__webpack_require__.t.bind(null, /*! jszip */ "./node_modules/jszip/dist/jszip.min.js", 7));
            case 1:
              JSZip = _context8.v.default;
              _context8.n = 2;
              return __webpack_require__.e(/*! import() */ 39).then(__webpack_require__.t.bind(null, /*! file-saver */ "./node_modules/file-saver/dist/FileSaver.min.js", 7));
            case 2:
              FileSaver = _context8.v.default;
              zip = new JSZip();
              attachments = _this6.selectedAttachments;
              fetchFile = /*#__PURE__*/function () {
                var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7(url) {
                  var response;
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
                    while (1) switch (_context7.n) {
                      case 0:
                        _context7.n = 1;
                        return fetch(url);
                      case 1:
                        response = _context7.v;
                        _context7.n = 2;
                        return response.blob();
                      case 2:
                        return _context7.a(2, _context7.v);
                    }
                  }, _callee7);
                }));
                return function fetchFile(_x) {
                  return _ref.apply(this, arguments);
                };
              }();
              _iterator4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(attachments);
              _context8.p = 3;
              _iterator4.s();
            case 4:
              if ((_step4 = _iterator4.n()).done) {
                _context8.n = 7;
                break;
              }
              attachment = _step4.value;
              url = attachment.externalStorageURL;
              if (!url) {
                _context8.n = 6;
                break;
              }
              _context8.n = 5;
              return fetchFile(url);
            case 5:
              blob = _context8.v;
              zip.file(attachment.filename, blob);
            case 6:
              _context8.n = 4;
              break;
            case 7:
              _context8.n = 9;
              break;
            case 8:
              _context8.p = 8;
              _t2 = _context8.v;
              _iterator4.e(_t2);
            case 9:
              _context8.p = 9;
              _iterator4.f();
              return _context8.f(9);
            case 10:
              _context8.n = 11;
              return zip.generateAsync({
                type: 'blob'
              });
            case 11:
              content = _context8.v;
              FileSaver.saveAs(content, 'attachments.zip');
            case 12:
              return _context8.a(2);
          }
        }, _callee8, null, [[3, 8, 9, 10]]);
      }))();
    },
    downloadSelectedAttachments: function downloadSelectedAttachments() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _this7.$showSpinner();
              _context9.n = 1;
              return _this7.downloadSelectedAttachmentsAsZip();
            case 1:
              _this7.$hideSpinner();
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    // Reordering a locked document within its own category is fine; dragging it into another
    // category is not.
    canMoveAttachment: function canMoveAttachment(event) {
      var _event$draggedContext;
      return !((_event$draggedContext = event.draggedContext) !== null && _event$draggedContext !== void 0 && (_event$draggedContext = _event$draggedContext.element) !== null && _event$draggedContext !== void 0 && _event$draggedContext.isLocked && event.from !== event.to);
    },
    attachmentChange: function attachmentChange(targetCategory, event) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee0() {
        var i, _event$added$element, movedItem;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              if (event.moved !== undefined) {
                for (i = 0; i < _this8.attachments.length; i++) {
                  _this8.attachments[i].orderIndex = i;
                  _this8.$emit('update:attachments', {
                    category: _this8.category,
                    attachment: _this8.attachments[i],
                    isSelected: _this8.attachments[i].isSelected
                  });
                  _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].updateQuoteAttachmentOrderIndex(_this8.attachments[i].quoteAttachmentId, i);
                }
              }
              if (!(event.added !== undefined)) {
                _context0.n = 3;
                break;
              }
              if (!((_event$added$element = event.added.element) !== null && _event$added$element !== void 0 && _event$added$element.isLocked)) {
                _context0.n = 1;
                break;
              }
              _this8.$emit('image-uploaded');
              return _context0.a(2);
            case 1:
              movedItem = event.added.element;
              _context0.n = 2;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].copyQuoteAttachment(_this8.quoteId, movedItem.quoteAttachmentId, targetCategory.quoteAttachmentCategoryId, true);
            case 2:
              _this8.$emit('image-uploaded');
            case 3:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    showDeleteAllModal: function showDeleteAllModal() {
      this.isDeleteAllModalActive = true;
    },
    deleteSelectedAttachments: function deleteSelectedAttachments(confirm) {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee1() {
        var rows, _iterator5, _step5, row, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context1) {
          while (1) switch (_context1.p = _context1.n) {
            case 0:
              _this9.isDeleteAllModalActive = false;
              if (!confirm) {
                _context1.n = 8;
                break;
              }
              rows = _this9.selectedUnlockedAttachments;
              _iterator5 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(rows);
              _context1.p = 1;
              _iterator5.s();
            case 2:
              if ((_step5 = _iterator5.n()).done) {
                _context1.n = 4;
                break;
              }
              row = _step5.value;
              _context1.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_65__["default"].deleteQuoteAttachment(row.quoteAttachmentId);
            case 3:
              _context1.n = 2;
              break;
            case 4:
              _context1.n = 6;
              break;
            case 5:
              _context1.p = 5;
              _t3 = _context1.v;
              _iterator5.e(_t3);
            case 6:
              _context1.p = 6;
              _iterator5.f();
              return _context1.f(6);
            case 7:
              _this9.$notification.openNotificationWithType('success', 'Delete attachments', "".concat(rows.length, " attachments deleted"));
              _this9.$emit('image-uploaded');
            case 8:
              return _context1.a(2);
          }
        }, _callee1, null, [[1, 5, 6, 7]]);
      }))();
    },
    // Removed duplicate 'attachments' key to fix vue/no-dupe-keys lint error
    setSelectedStatusAll: function setSelectedStatusAll(value) {
      var _iterator6 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this.attachments),
        _step6;
      try {
        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          var row = _step6.value;
          row.isSelected = value; // update local state for immediate UI feedback
          this.$emit('update:attachments', {
            attachment: row,
            category: this.category,
            isSelected: value
          });
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
    },
    imageUpdated: function imageUpdated() {
      this.queuedFileCount++;
      this.$emit('image-uploaded');
    },
    openEmailModal: function openEmailModal() {
      this.updateAttachmentList();
      this.isEmailModalActive = true;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");







/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteAttachmentCategoryModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_5__["BaseModalEx"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_5__["ConfirmModal"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      newCategoryName: '',
      categories: [],
      isDeleteModalActive: false,
      categoryToDelete: null
    };
  },
  computed: {},
  watch: {
    active: function active(value) {
      this.loadQuoteAttachmentCategories();
      this.isActive = value;
    }
  },
  created: function created() {},
  mounted: function mounted() {
    this.loadQuoteAttachmentCategories();
  },
  methods: {
    createNewCategory: function createNewCategory() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_6__["default"].createQuoteAttachmentCategory(_this.newCategoryName);
            case 1:
              _this.$emit('categories-changed');
              _this.loadQuoteAttachmentCategories();
              _this.newCategoryName = '';
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    deleteCategory: function deleteCategory(row) {
      if (row !== null && row !== void 0 && row.isSystem) {
        return;
      }
      this.categoryToDelete = row;
      this.isDeleteModalActive = true;
    },
    confirmDeleteCategory: function confirmDeleteCategory(confirm) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var row, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              _this2.isDeleteModalActive = false;
              row = _this2.categoryToDelete;
              _this2.categoryToDelete = null;
              if (!(!confirm || !row)) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _context2.p = 1;
              _context2.n = 2;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_6__["default"].updateQuoteAttachmentCategory(row.quoteAttachmentCategoryId, row.name, true);
            case 2:
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('Delete category', _t);
            case 4:
              _this2.$emit('categories-changed');
              _this2.loadQuoteAttachmentCategories();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    saveCategories: function saveCategories() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var _iterator, _step, row, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this3.categories);
              _context3.p = 1;
              _iterator.s();
            case 2:
              if ((_step = _iterator.n()).done) {
                _context3.n = 5;
                break;
              }
              row = _step.value;
              if (!(!row.isDirty || row.isSystem)) {
                _context3.n = 3;
                break;
              }
              return _context3.a(3, 4);
            case 3:
              _context3.n = 4;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_6__["default"].updateQuoteAttachmentCategory(row.quoteAttachmentCategoryId, row.name, false);
            case 4:
              _context3.n = 2;
              break;
            case 5:
              _context3.n = 7;
              break;
            case 6:
              _context3.p = 6;
              _t2 = _context3.v;
              _iterator.e(_t2);
            case 7:
              _context3.p = 7;
              _iterator.f();
              return _context3.f(7);
            case 8:
              _this3.$emit('categories-changed');
              _this3.loadQuoteAttachmentCategories();
              _this3.$emit('cancel');
            case 9:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 6, 7, 8]]);
      }))();
    },
    setDirty: function setDirty(category) {
      category.isDirty = true;
    },
    loadQuoteAttachmentCategories: function loadQuoteAttachmentCategories() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_6__["default"].getQuoteAttachmentCategories();
            case 1:
              _this4.categories = _context4.v;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    cancel: function cancel() {
      this.$emit('cancel');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return this.$agentIsScannerReady ? _c("div", {
    staticClass: "button is-info",
    on: {
      click: function click() {
        return _vm.scan();
      }
    }
  }, [_c("i", {
    staticClass: "mdi mdi-scanner mdi-24px"
  }), _vm._v(" Scan ")]) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("div", {
    staticClass: "model-content"
  }, [_c("div", {
    staticClass: "modal-card"
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("span", {
    staticClass: "mso mso-36px"
  }, [_vm._v(_vm._s(_vm.iconName))])]) : _vm._e(), _vm._t("text-title")], 2)]), _c("section", {
    staticClass: "modal-card-body"
  }, [_vm._t("text-content")], 2), _c("footer", {
    staticClass: "modal-card-foot",
    style: "justify-content: flex-".concat(_vm.buttonLocation)
  }, [_c("button", {
    staticClass: "button",
    class: [{
      tooltip: _vm.okTooltip !== ""
    }, _vm.okClass],
    attrs: {
      "data-tooltip": _vm.okTooltip
    },
    on: {
      click: function click($event) {
        return _vm.ok();
      }
    }
  }, [_vm._v(_vm._s(_vm.okText) + " ")]), _vm.showCancel ? _c("button", {
    staticClass: "button",
    class: [{
      tooltip: _vm.cancelTooltip !== ""
    }, _vm.cancelClass],
    attrs: {
      "data-tooltip": _vm.cancelTooltip
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_vm._v(_vm._s(_vm.cancelText) + " ")]) : _vm._e(), _vm.showClose ? _c("button", {
    staticClass: "button",
    class: [{
      tooltip: _vm.closeTooltip !== ""
    }, _vm.closeClass],
    attrs: {
      "data-tooltip": _vm.closeTooltip
    },
    on: {
      click: function click($event) {
        return _vm.close();
      }
    }
  }, [_vm._v(_vm._s(_vm.closeText) + " ")]) : _vm._e()])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/FileDropZone.vue?vue&type=template&id=616db4f2":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/FileDropZone.vue?vue&type=template&id=616db4f2 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticStyle: {
      height: "100%"
    }
  }, [_c("vue-dropzone", {
    ref: "filedropzone",
    attrs: {
      id: "filedropzone" + _vm.id,
      options: _vm.dropzoneOptions,
      "additional-classes": _vm.additionalClasses
    },
    on: {
      "vdropzone-file-added": function vdropzoneFileAdded(file) {
        return _vm.acceptFile(file);
      },
      "vdropzone-processing": function vdropzoneProcessing(file) {
        return _vm.processFile(file);
      },
      "vdropzone-sending": function vdropzoneSending(file, xhr) {
        return _vm.sendingFile(file, xhr);
      },
      "vdropzone-complete": function vdropzoneComplete(file) {
        return _vm.successFile(file);
      },
      "vdropzone-error": _vm.dropzoneError
    }
  })], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349 ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-documents-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Documents")]), _vm.documentCount ? _c("span", {
    staticClass: "has-badge-rounded has-badge-info has-badge-large",
    attrs: {
      "data-badge": _vm.documentCount
    }
  }) : _vm._e(), _c("a", {
    staticClass: "button is-secondary is-pulled-right",
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.toggleCategoryModal(true);
      }
    }
  }, [_vm._m(0), _c("span", [_vm._v("Category")])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isLoading > 0,
      expression: "isLoading > 0"
    }],
    staticClass: "columns is-multiline"
  }, [_vm._m(1)]), _c("quote-attachment-category-modal", {
    attrs: {
      active: _vm.modalOpen
    },
    on: {
      cancel: function cancel($event) {
        return _vm.toggleCategoryModal(false);
      },
      "categories-changed": function categoriesChanged($event) {
        return _vm.getQuoteAttachmentCategories();
      }
    }
  }), _vm._l(_vm.categories, function (category) {
    return [_c("quote-attachment-category", {
      key: category.quoteAttachmentCategoryId,
      attrs: {
        category: category,
        "quote-id": _vm.value.quoteId,
        attachments: category.attachments,
        categories: _vm.categories,
        "max-file-size-mb": _vm.maxFileSizeMb
      },
      on: {
        "update:attachments": function updateAttachments(e) {
          return _vm.handleUpdateAttachments(e);
        },
        "image-uploaded": function imageUploaded($event) {
          return _vm.getQuoteAttachments();
        }
      }
    })];
  })], 2)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "section"
  }, [_c("span", {
    staticClass: "is-loading-image has-text-grey has-text-centered"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm$emailer;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-multiline"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "subtitle"
  }, [_vm._v(_vm._s(_vm.category.name) + " "), _vm.isSystemCategory ? _c("span", {
    staticClass: "icon tooltip",
    attrs: {
      "data-tooltip": "System category. Integrations resolve it by name, so it cannot be renamed or deleted. Documents an integration files here are view only."
    }
  }, [_c("i", {
    staticClass: "mdi mdi-lock mdi-18px"
  })]) : _vm._e(), _vm.attachments.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-info has-badge-large pl-3",
    attrs: {
      "data-badge": _vm.attachments.length
    }
  }) : _vm._e()])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("p", {
    staticClass: "buttons"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Email"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.openEmailModal();
      }
    }
  }, [_vm._m(0)]), _c("agent-scan-button", {
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      "scan-results": function scanResults(e) {
        return _vm.handleScanResult(e);
      }
    }
  }), _c("a", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Refresh"
    },
    on: {
      click: function click($event) {
        return _vm.$emit("image-uploaded");
      }
    }
  }, [_vm._m(1)]), _c("a", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Select all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(true);
      }
    }
  }, [_vm._m(2)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Deselect all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(false);
      }
    }
  }, [_vm._m(3)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelectedUnlocked,
      expression: "hasSelectedUnlocked"
    }],
    staticClass: "button tooltip",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Copy to quote"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.toggleCopyAttachmentModal(true);
      }
    }
  }, [_vm._m(4)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelectedUnlocked,
      expression: "hasSelectedUnlocked"
    }],
    staticClass: "button tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Delete selected"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showDeleteAllModal();
      }
    }
  }, [_vm._m(5)]), _c("confirm-modal", {
    attrs: {
      active: _vm.isDeleteAllModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteAllModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteSelectedAttachments(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteSelectedAttachments(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete attachments")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedUnlockedAttachments.length))]), _vm._v(" selected attachments will be deleted. Continue? ")]), _vm.selectedLockedCount > 0 ? _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" " + _vm._s(_vm.selectedLockedCount) + " locked document(s) attached by an integration will be kept. ")]) : _vm._e()]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Download selected"
    },
    on: {
      click: function click($event) {
        return _vm.downloadSelectedAttachments();
      }
    }
  }, [_vm._m(6)])], 1)])]), _c("div", [_c("draggable", {
    staticClass: "columns is-multiline",
    attrs: {
      list: _vm.attachments,
      group: "attachments",
      move: _vm.canMoveAttachment,
      disabled: _vm.$licenceExpired
    },
    on: {
      change: function change(event) {
        return _vm.attachmentChange(_vm.category, event);
      }
    }
  }, [_vm._l(_vm.attachments, function (attachment) {
    return _c("div", {
      key: attachment.quoteAttachmentId,
      staticClass: "column is-1 m-0 p-1"
    }, [_c("QuoteAttachment", {
      attrs: {
        attachment: attachment,
        "quote-id": _vm.quoteId,
        "quote-attachment-category-id": _vm.category.quoteAttachmentCategoryId,
        "quote-attachment-id": attachment.quoteAttachmentId,
        categories: _vm.categories
      },
      on: {
        "update:attachment": function updateAttachment(e) {
          return _vm.handleAttachmentChange(e, attachment);
        },
        "image-uploaded": function imageUploaded($event) {
          return _vm.imageUpdated();
        }
      }
    })], 1);
  }), !_vm.$licenceExpired ? _c("div", {
    staticClass: "column is-3 m-0 p-1"
  }, [_c("file-drop-zone", {
    staticStyle: {
      height: "100%"
    },
    attrs: {
      "quote-id": _vm.quoteId,
      "default-size": 128,
      "quote-attachment-category-id": _vm.category.quoteAttachmentCategoryId,
      "max-file-size-mb": _vm.maxFileSizeMb,
      "additional-classes": "quote-attachment-dropzone"
    },
    on: {
      "image-uploaded": function imageUploaded($event) {
        return _vm.imageUpdated();
      }
    }
  })], 1) : _vm._e()], 2)], 1)]), _c("vue-email-modal", {
    attrs: {
      active: _vm.isEmailModalActive,
      "icon-name": "mdi-email-open",
      "icon-type": "primary",
      "enable-send": _vm.enableSend && !_vm.isImageAttachActive,
      "is-sending": _vm.isSending,
      "enable-attach": false,
      "toggle-attach-button": false
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEmailModalActive = $event;
      },
      send: _vm.sendEmail,
      discard: _vm.discardEmail,
      attach: _vm.attachMedia,
      "show-attach": false
    }
  }, [_c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.isEmailModalActive ? _c("vue-email", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isImageAttachActive,
      expression: "!isImageAttachActive"
    }],
    ref: "emailer",
    attrs: {
      "quote-attachments": _vm.allSelectedAttachments,
      "asset-id": (_vm$emailer = _vm.emailer) === null || _vm$emailer === void 0 ? void 0 : _vm$emailer.assetId
    },
    on: {
      "new-email": true,
      sent: _vm.sent,
      "sending-changed": function sendingChanged($event) {
        _vm.isSending = $event;
      }
    },
    model: {
      value: _vm.emailer,
      callback: function callback($$v) {
        _vm.emailer = $$v;
      },
      expression: "emailer"
    }
  }) : _vm._e(), _vm.emailer && _vm.isImageAttachActive ? _c("image-select", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isImageAttachActive,
      expression: "isImageAttachActive"
    }],
    attrs: {
      "quote-id": _vm.emailer.assetId,
      "quote-ids": _vm.quoteIds
    },
    model: {
      value: _vm.selectedImages,
      callback: function callback($$v) {
        _vm.selectedImages = $$v;
      },
      expression: "selectedImages"
    }
  }) : _vm._e()], 1)]), _vm.isCopyImageModalActive ? _c("quote-no-search-modal", {
    attrs: {
      active: _vm.isCopyImageModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCopyImageModalActive = $event;
      },
      copy: function copy($event) {
        return _vm.copyQuoteAttachmentToOtherQuote($event);
      },
      close: function close($event) {
        return _vm.toggleCopyAttachmentModal(false);
      }
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-email-fast mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-content-copy mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete-sweep mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-download mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_c("span", [_vm._v("Add or Edit Category")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", [_vm._v("Create New Category")])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newCategoryName,
      expression: "newCategoryName"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Please enter a new Name"
    },
    domProps: {
      value: _vm.newCategoryName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.newCategoryName = $event.target.value;
      }
    }
  })])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "button is-secondary",
    on: {
      click: function click($event) {
        _vm.newCategoryName = "";
      }
    }
  }, [_vm._v("Cancel")])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "button is-primary is-pulled-right",
    on: {
      click: function click($event) {
        return _vm.createNewCategory();
      }
    }
  }, [_vm._v("Create")])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", [_vm._v("Edit Existing Category")])])]), _vm._l(_vm.categories, function (category) {
    return _c("div", {
      key: category.quoteAttachmentCategoryId,
      staticClass: "columns"
    }, [_c("div", {
      staticClass: "column"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: category.name,
        expression: "category.name"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        placeholder: "Existing Name",
        disabled: category.isSystem
      },
      domProps: {
        value: category.name
      },
      on: {
        keyup: function keyup($event) {
          return _vm.setDirty(category);
        },
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(category, "name", $event.target.value);
        }
      }
    }), _c("div", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-secondary has-text-danger",
      class: {
        "is-hidden": category.isSystem
      },
      on: {
        click: function click($event) {
          return _vm.deleteCategory(category);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-trash-can mdi-18px"
    })])]), category.isSystem ? _c("div", {
      staticClass: "control is-flex is-align-items-center pl-3 tooltip",
      attrs: {
        "data-tooltip": "System category. Integrations resolve it by name, so it cannot be renamed or deleted."
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("i", {
      staticClass: "mdi mdi-lock mdi-24px"
    })])]) : _vm._e()])])]);
  })], 2), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; flex-direction: row-reverse;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_c("span", [_vm._v("Cancel")])]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Save"
    },
    on: {
      click: function click($event) {
        return _vm.saveCategories();
      }
    }
  }, [_c("span", [_vm._v("Save")])])])])])]), _vm.categoryToDelete ? _c("confirm-modal", {
    attrs: {
      active: _vm.isDeleteModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.confirmDeleteCategory(true);
      },
      cancel: function cancel($event) {
        return _vm.confirmDeleteCategory(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete category")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.categoryToDelete.name))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.freeze.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.freeze.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var FREEZING = __webpack_require__(/*! ../internals/freezing */ "./node_modules/core-js/internals/freezing.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var onFreeze = __webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js").onFreeze;

// eslint-disable-next-line es/no-object-freeze -- safe
var $freeze = Object.freeze;
var FAILS_ON_PRIMITIVES = fails(function () { $freeze(1); });

// `Object.freeze` method
// https://tc39.es/ecma262/#sec-object.freeze
$({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES, sham: !FREEZING }, {
  freeze: function freeze(it) {
    return $freeze && isObject(it) ? $freeze(onFreeze(it)) : it;
  }
});


/***/ }),

/***/ "./node_modules/core-js/modules/web.atob.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/web.atob.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
var validateArgumentsLength = __webpack_require__(/*! ../internals/validate-arguments-length */ "./node_modules/core-js/internals/validate-arguments-length.js");
var c2i = __webpack_require__(/*! ../internals/base64-map */ "./node_modules/core-js/internals/base64-map.js").c2i;

var disallowed = /[^\d+/a-z]/i;
var whitespaces = /[\t\n\f\r ]+/g;
var finalEq = /[=]{1,2}$/;

var $atob = getBuiltIn('atob');
var fromCharCode = String.fromCharCode;
var charAt = uncurryThis(''.charAt);
var replace = uncurryThis(''.replace);
var exec = uncurryThis(disallowed.exec);

var BASIC = !!$atob && !fails(function () {
  return $atob('aGk=') !== 'hi';
});

var NO_SPACES_IGNORE = BASIC && fails(function () {
  return $atob(' ') !== '';
});

var NO_ENCODING_CHECK = BASIC && !fails(function () {
  $atob('a');
});

var NO_ARG_RECEIVING_CHECK = BASIC && !fails(function () {
  $atob();
});

var WRONG_ARITY = BASIC && $atob.length !== 1;

var FORCED = !BASIC || NO_SPACES_IGNORE || NO_ENCODING_CHECK || NO_ARG_RECEIVING_CHECK || WRONG_ARITY;

// `atob` method
// https://html.spec.whatwg.org/multipage/webappapis.html#dom-atob
$({ global: true, bind: true, enumerable: true, forced: FORCED }, {
  atob: function atob(data) {
    validateArgumentsLength(arguments.length, 1);
    // `webpack` dev server bug on IE global methods - use call(fn, global, ...)
    if (BASIC && !NO_SPACES_IGNORE && !NO_ENCODING_CHECK) return call($atob, globalThis, data);
    var string = replace(toString(data), whitespaces, '');
    var output = '';
    var position = 0;
    var bc = 0;
    var length, chr, bs;
    if (string.length % 4 === 0) {
      string = replace(string, finalEq, '');
    }
    length = string.length;
    if (length % 4 === 1 || exec(disallowed, string)) {
      throw new (getBuiltIn('DOMException'))('The string is not correctly encoded', 'InvalidCharacterError');
    }
    while (position < length) {
      chr = charAt(string, position++);
      bs = bc % 4 ? bs * 64 + c2i[chr] : c2i[chr];
      if (bc++ % 4) output += fromCharCode(255 & bs >> (-2 * bc & 6));
    } return output;
  }
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.quote-attachment-dropzone {\n  height: 100%;\n  padding: 0px !important;\n  min-height: 100% !important;\n}\n.quote-attachment-dropzone .dz-message {\n  margin: 0 !important;\n  margin-top: 10px !important;\n}\n.quote-attachment-dropzone .dz-preview.dz-file-preview {\n  width: 128px !important;\n  height: 128px !important;\n  display: -webkit-inline-box !important;\n  display: -ms-inline-flexbox !important;\n  display: inline-flex !important;\n  -webkit-box-align: center !important;\n      -ms-flex-align: center !important;\n          align-items: center !important;\n  -webkit-box-pack: center !important;\n      -ms-flex-pack: center !important;\n          justify-content: center !important;\n  border-radius: 16px !important;\n  border: 1px solid #e0e0e0 !important;\n  -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;\n          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;\n  margin: 8px !important;\n  background-color: #ffffff !important;\n  position: relative !important;\n  overflow: visible !important;\n}\n.quote-attachment-dropzone .dz-preview.dz-file-preview .dz-image {\n  border-radius: 14px;\n  overflow: hidden;\n  width: 100% !important;\n  height: 100% !important;\n  position: relative;\n  display: block;\n  z-index: 10;\n}\n.quote-attachment-dropzone .dz-preview.dz-file-preview .dz-image img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.quote-attachment-dropzone .dz-preview.dz-error {\n  border-color: #d9534d !important;\n}\n.quote-attachment-dropzone .dz-preview.dz-success {\n  border-color: #5cb85c !important;\n  display: none !important;\n}\n.quote-attachment-dropzone .dz-preview .dz-remove {\n  position: absolute;\n  top: -8px;\n  right: -8px;\n  z-index: 30;\n  width: 22px;\n  height: 22px;\n  background-color: #ffffff;\n  border: 1px solid #666666;\n  border-radius: 50%;\n  color: #4a4a4a;\n  cursor: pointer;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-size: 14px;\n  font-weight: 500;\n  line-height: 1;\n  -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);\n          box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);\n  -webkit-transition: all 0.2s ease;\n  transition: all 0.2s ease;\n}\n.quote-attachment-dropzone .dz-preview .dz-remove:hover {\n  background-color: #f8f8f8;\n  border-color: #555555;\n  color: #333333;\n  -webkit-box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-d85cbe88] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-documents-licence-expired [disabled]:not(.tooltip) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-documents-licence-expired [disabled]:not(.tooltip):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  right: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("359ab51a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3b01b1f7", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("09f30297", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/Agent/AgentScanButton.vue":
/*!**************************************************!*\
  !*** ./src/components/Agent/AgentScanButton.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true */ "./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true");
/* harmony import */ var _AgentScanButton_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AgentScanButton.vue?vue&type=script&lang=js */ "./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AgentScanButton_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "709d58ca",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Agent/AgentScanButton.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js":
/*!**************************************************************************!*\
  !*** ./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AgentScanButton_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AgentScanButton.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Agent/AgentScanButton.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AgentScanButton_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true":
/*!********************************************************************************************!*\
  !*** ./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Agent/AgentScanButton.vue?vue&type=template&id=709d58ca&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AgentScanButton_vue_vue_type_template_id_709d58ca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/BulmaModal/ConfirmModal.vue":
/*!****************************************************!*\
  !*** ./src/components/BulmaModal/ConfirmModal.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true */ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true");
/* harmony import */ var _ConfirmModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ConfirmModal.vue?vue&type=script&lang=js */ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true */ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ConfirmModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "d85cbe88",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/BulmaModal/ConfirmModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ConfirmModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true":
/*!*************************************************************************************************************!*\
  !*** ./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=style&index=0&id=d85cbe88&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_style_index_0_id_d85cbe88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true":
/*!**********************************************************************************************!*\
  !*** ./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaModal/ConfirmModal.vue?vue&type=template&id=d85cbe88&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ConfirmModal_vue_vue_type_template_id_d85cbe88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/FileDropZone.vue":
/*!*****************************************!*\
  !*** ./src/components/FileDropZone.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FileDropZone.vue?vue&type=template&id=616db4f2 */ "./src/components/FileDropZone.vue?vue&type=template&id=616db4f2");
/* harmony import */ var _FileDropZone_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FileDropZone.vue?vue&type=script&lang=js */ "./src/components/FileDropZone.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FileDropZone_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/FileDropZone.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/FileDropZone.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/components/FileDropZone.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FileDropZone_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./FileDropZone.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/FileDropZone.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FileDropZone_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/FileDropZone.vue?vue&type=template&id=616db4f2":
/*!***********************************************************************!*\
  !*** ./src/components/FileDropZone.vue?vue&type=template&id=616db4f2 ***!
  \***********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./FileDropZone.vue?vue&type=template&id=616db4f2 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/FileDropZone.vue?vue&type=template&id=616db4f2");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FileDropZone_vue_vue_type_template_id_616db4f2__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueDropzone/index.js":
/*!*********************************************!*\
  !*** ./src/components/VueDropzone/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// import VueDropzone from './VueDropzone'
var VueDropzone = function VueDropzone(r) {
  return __webpack_require__.e(/*! require.ensure | dropzone-components-chunk */ "dropzone-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueDropzone.vue */ "./src/components/VueDropzone/VueDropzone.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
/* harmony default export */ __webpack_exports__["default"] = (VueDropzone);

/***/ }),

/***/ "./src/components/printpreview/storeMixin.js":
/*!***************************************************!*\
  !*** ./src/components/printpreview/storeMixin.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'printpreview';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    getEmailer: 'getEmailer',
    reportParameters: 'reportParameters'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addParameters: 'addParameters',
    removeParameters: 'removeParameters'
  }))
});

/***/ }),

/***/ "./src/services/byteUnits.js":
/*!***********************************!*\
  !*** ./src/services/byteUnits.js ***!
  \***********************************/
/*! exports provided: BYTES_PER_MB, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BYTES_PER_MB", function() { return BYTES_PER_MB; });
/**
 * PCK-213 - bytes in a megabyte. Size limits are stored and shown in MB but compared in bytes,
 * so this conversion appeared across the limit services and the uploaders.
 *
 * apps/pwa has its own copy: the two apps are separate builds with no module in common.
 */
var BYTES_PER_MB = 1024 * 1024;
/* harmony default export */ __webpack_exports__["default"] = ({
  BYTES_PER_MB: BYTES_PER_MB
});

/***/ }),

/***/ "./src/services/uploadLimits.js":
/*!**************************************!*\
  !*** ./src/services/uploadLimits.js ***!
  \**************************************/
/*! exports provided: FALLBACK_MAX_FILE_BYTES, FALLBACK_AUDANET_MAX_FILE_BYTES, getUploadLimits, getMaxUploadFileMb, getAudaNetMaxFileMb, resetUploadLimitsCache, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_MAX_FILE_BYTES", function() { return FALLBACK_MAX_FILE_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_AUDANET_MAX_FILE_BYTES", function() { return FALLBACK_AUDANET_MAX_FILE_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUploadLimits", function() { return getUploadLimits; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMaxUploadFileMb", function() { return getMaxUploadFileMb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAudaNetMaxFileMb", function() { return getAudaNetMaxFileMb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetUploadLimitsCache", function() { return resetUploadLimitsCache; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.number.is-finite.js */ "./node_modules/core-js/modules/es.number.is-finite.js");
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.freeze.js */ "./node_modules/core-js/modules/es.object.freeze.js");
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/services/byteUnits */ "./src/services/byteUnits.js");








/**
 * PCK-213 - per-file upload caps, read from the API instead of hardcoded.
 *
 * The same 10MB was written into every uploader in both apps, with nothing keeping the copies in
 * step. A shared JS constant cannot fix it because apps/web and apps/pwa are separate builds, so
 * the setting is the only single source both can read - apps/pwa has its own copy of this module.
 *
 * Memoised: the caps do not change within a page load.
 */

var FALLBACK_MAX_FILE_BYTES = 10 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"];
var FALLBACK_AUDANET_MAX_FILE_BYTES = 1.5 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"];
var FALLBACK = Object.freeze({
  maxFileBytes: FALLBACK_MAX_FILE_BYTES,
  audaNetMaxFileBytes: FALLBACK_AUDANET_MAX_FILE_BYTES
});
var cached = null;
function getUploadLimits() {
  if (!cached) {
    cached = _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get('/settings/uploadlimits').then(function (response) {
      var data = response && response.data || {};
      var maxFileBytes = Number(data.maxFileBytes);
      var audaNetMaxFileBytes = Number(data.audaNetMaxFileBytes);
      return {
        maxFileBytes: Number.isFinite(maxFileBytes) && maxFileBytes > 0 ? maxFileBytes : FALLBACK.maxFileBytes,
        audaNetMaxFileBytes: Number.isFinite(audaNetMaxFileBytes) && audaNetMaxFileBytes > 0 ? audaNetMaxFileBytes : FALLBACK.audaNetMaxFileBytes
      };
    }).catch(function () {
      return FALLBACK;
    });
  }
  return cached;
}

/** Dropzone's maxFilesize option is in MB. */
function getMaxUploadFileMb() {
  return _getMaxUploadFileMb.apply(this, arguments);
}
function _getMaxUploadFileMb() {
  _getMaxUploadFileMb = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
    var limits;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
      while (1) switch (_context.n) {
        case 0:
          _context.n = 1;
          return getUploadLimits();
        case 1:
          limits = _context.v;
          return _context.a(2, limits.maxFileBytes / _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"]);
      }
    }, _callee);
  }));
  return _getMaxUploadFileMb.apply(this, arguments);
}
function getAudaNetMaxFileMb() {
  return _getAudaNetMaxFileMb.apply(this, arguments);
}

/** Test seam - drops the memoised result so each spec starts clean. */
function _getAudaNetMaxFileMb() {
  _getAudaNetMaxFileMb = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
    var limits;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
      while (1) switch (_context2.n) {
        case 0:
          _context2.n = 1;
          return getUploadLimits();
        case 1:
          limits = _context2.v;
          return _context2.a(2, limits.audaNetMaxFileBytes / _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"]);
      }
    }, _callee2);
  }));
  return _getAudaNetMaxFileMb.apply(this, arguments);
}
function resetUploadLimitsCache() {
  cached = null;
}
/* harmony default export */ __webpack_exports__["default"] = ({
  getUploadLimits: getUploadLimits,
  getMaxUploadFileMb: getMaxUploadFileMb,
  getAudaNetMaxFileMb: getAudaNetMaxFileMb,
  resetUploadLimitsCache: resetUploadLimitsCache
});

/***/ }),

/***/ "./src/views/quote/QuoteDocuments.vue":
/*!********************************************!*\
  !*** ./src/views/quote/QuoteDocuments.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteDocuments.vue?vue&type=template&id=6e232349 */ "./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349");
/* harmony import */ var _QuoteDocuments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteDocuments.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss */ "./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteDocuments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteDocuments.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js":
/*!********************************************************************!*\
  !*** ./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDocuments.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss":
/*!*****************************************************************************************!*\
  !*** ./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=style&index=0&id=6e232349&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_style_index_0_id_6e232349_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349":
/*!**************************************************************************!*\
  !*** ./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349 ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDocuments.vue?vue&type=template&id=6e232349 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDocuments.vue?vue&type=template&id=6e232349");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDocuments_vue_vue_type_template_id_6e232349__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategory.vue":
/*!****************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategory.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1 */ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1");
/* harmony import */ var _QuoteAttachmentCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteAttachmentCategory.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css */ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteAttachmentCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteAttachmentCategory.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategory.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css":
/*!************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=style&index=0&id=6c4e75d1&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_style_index_0_id_6c4e75d1_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1":
/*!**********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1 ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategory.vue?vue&type=template&id=6c4e75d1");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategory_vue_vue_type_template_id_6c4e75d1__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue":
/*!*********************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategoryModal.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8 */ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8");
/* harmony import */ var _QuoteAttachmentCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteAttachmentCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteAttachmentCategoryModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js":
/*!*********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8":
/*!***************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8 ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentCategoryModal.vue?vue&type=template&id=8db7f1e8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentCategoryModal_vue_vue_type_template_id_8db7f1e8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-documents-chunk.js.map