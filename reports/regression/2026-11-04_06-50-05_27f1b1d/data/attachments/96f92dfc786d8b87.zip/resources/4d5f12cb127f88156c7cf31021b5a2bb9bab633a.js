(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quickinvoice-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./QuickInvoiceService */ "./src/views/quickinvoice/QuickInvoiceService.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quickinvoice/storeMixin.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_currency__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/currency */ "./src/components/currency/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var lodash_set__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash/set */ "./node_modules/lodash/set.js");
/* harmony import */ var lodash_set__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_set__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var lodash_tap__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash/tap */ "./node_modules/lodash/tap.js");
/* harmony import */ var lodash_tap__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_tap__WEBPACK_IMPORTED_MODULE_30__);































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickinvoiceDetail',
  inject: ['$vv'],
  components: {
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_17___default.a,
    RemarkModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__["RemarkModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_23__["default"]],
  props: {
    value: null,
    isNew: Boolean,
    gstPaid: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(this.value),
      // invoiceDate: null,
      selectedAsset: null,
      selectedContact: null,
      customers: [],
      contacts: [],
      isCustomerLoading: false,
      isContactLoading: false,
      customerInput: '',
      contactInput: '',
      isRemarkModalActive: false,
      assetFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty(),
        assetName: '',
        showCustomer: true,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      moneyMask: {
        precision: 2,
        prefix: '$ '
      },
      assetButtonLoading: false,
      contactButtonLoading: false,
      selectedInvoiceDate: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    local: {
      get: function get() {
        return this.value;
      },
      set: function set() {
        this.$emit('input', this.local);
      }
    },
    hasAssetSelected: function hasAssetSelected() {
      return this.selectedAsset && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20___default()(this.selectedAsset);
    },
    assetButtonIconClass: function assetButtonIconClass() {
      return {
        'mdi-pencil': this.hasAssetSelected,
        'mdi-plus': !this.hasAssetSelected
      };
    },
    assetButtonClass: function assetButtonClass() {
      return {
        'is-primary': this.hasAssetSelected,
        'is-success': !this.hasAssetSelected,
        'is-loading': this.assetButtonLoading
      };
    },
    hasContactSelected: function hasContactSelected() {
      return this.selectedContact && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20___default()(this.selectedContact);
    },
    contactButtonIconClass: function contactButtonIconClass() {
      return {
        'mdi-pencil': this.hasContactSelected,
        'mdi-plus': !this.hasContactSelected
      };
    },
    contactButtonClass: function contactButtonClass() {
      return {
        'is-primary': this.hasContactSelected,
        'is-success': !this.hasContactSelected,
        'is-loading': this.contactButtonLoading
      };
    },
    activeRemarks: function activeRemarks() {
      return this.innerValue.remarks.filter(function (r) {
        return !r.isDeleted;
      });
    },
    activePrintedRemarks: function activePrintedRemarks() {
      return this.innerValue.printedRemarks.filter(function (r) {
        return !r.isDeleted;
      });
    },
    remarkTypes: function remarkTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["RemarkTypes"];
    },
    activeItems: function activeItems() {
      return this.innerValue.items.filter(function (i) {
        return !i.isDeleted;
      });
    },
    showAsset: function showAsset() {
      return {
        customer: this.assetFilter.showCustomer,
        insurer: this.assetFilter.showInsurer
      };
    },
    $v: function $v() {
      return this.$vv || this.$v;
    },
    currencySymbol: function currencySymbol() {
      return Object(_components_currency__WEBPACK_IMPORTED_MODULE_25__["getCurrencySymbol"])(this.$userInfo.locale);
    },
    totalPaid: function totalPaid() {
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(this.innerValue.payments.reduce(function (total, payment) {
        return total + payment.amountPaid;
      }, 0), 2);
    },
    balance: function balance() {
      return this.innerValue.totalIncGst - this.totalPaid;
    },
    balanceClass: function balanceClass() {
      if (this.balance > 0) {
        return 'has-text-success';
      } else if (this.balance < 0) {
        return 'has-text-danger';
      }
    },
    activeContacts: function activeContacts() {
      return this.contacts.filter(function (c) {
        return c.active;
      });
    },
    activeCustomers: function activeCustomers() {
      return this.customers.filter(function (c) {
        return c.active;
      });
    },
    firstDayOfMonth: function firstDayOfMonth() {
      if (this.$company.setting.allowInvoicePreviousMonth) {
        return null;
      }
      var invoiceDate = new Date();
      if (!this.innerValue.isNew) {
        invoiceDate = new Date("".concat(this.innerValue.invoiceDate));
        return this.$filters.firstDayOfMonth(invoiceDate.getFullYear(), invoiceDate.getMonth());
      } else {
        return this.$filters.firstDayOfMonth();
      }
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    showAsset: function showAsset(newVal, oldVal) {
      if (!newVal.customer && !newVal.insurer) {
        this.assetFilter.showCustomer = !oldVal.customer;
        this.assetFilter.showInsurer = !oldVal.insurer;
      }
      this.getAssetDropdown();
    },
    selectedInvoiceDate: function selectedInvoiceDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.invoiceDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.invoiceDate = null;
      }
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_21__["EventHubTypes"].EntitySaved);
  },
  created: function created() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_21__["EventHubTypes"].EntityReload, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(_this.value);
      _this.onReload();
    });
    this.invoiceDate = new Date("".concat(this.innerValue.invoiceDate));
    this.selectedInvoiceDate = new Date("".concat(this.innerValue.invoiceDate));
    this.assetFilter.assetId = this.innerValue.assetId;
    this.getAssetDropdown();
  },
  mounted: function mounted() {
    var _this2 = this;
    this.$v.detailGroup.$touch();
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_21__["EventHubTypes"].EntitySaved, function () {
      _this2.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(_this2.value);
    });
  },
  methods: {
    toogleReadOnly: function toogleReadOnly() {
      if (this.canChangeReadOnly) {
        this.setReadOnlyView(!this.readOnlyView);
      }
    },
    canChangeReadOnly: function canChangeReadOnly() {
      return this.$userInfo.isSupportUser || this.$userInfo.isCustomerAdministrator;
    },
    update: function update(key, value) {
      this.$emit('input', lodash_tap__WEBPACK_IMPORTED_MODULE_30___default()(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(this.local), function (v) {
        return lodash_set__WEBPACK_IMPORTED_MODULE_29___default()(v, key, value);
      }));
    },
    getAssetDropdown: function getAssetDropdown() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _yield$Promise$all, _yield$Promise$all2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this3.isCustomerLoading = true;
              _context.n = 1;
              return Promise.all([_QuickInvoiceService__WEBPACK_IMPORTED_MODULE_16__["default"].getAssetDropdownProto(_this3.assetFilter), _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_16__["default"].getContactDropdown(_this3.innerValue.assetId)]);
            case 1:
              _yield$Promise$all = _context.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_yield$Promise$all, 2);
              _this3.customers = _yield$Promise$all2[0];
              _this3.contacts = _yield$Promise$all2[1];
              if (_this3.assetFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty()) {
                _this3.selectedAsset = _this3.customers.find(function (c) {
                  return c.assetId === _this3.innerValue.assetId;
                });
              }
              _this3.selectedContact = _this3.contacts.find(function (c) {
                return c.contactId === _this3.innerValue.contactId;
              });
              _this3.isCustomerLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getAssetDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.isCustomerLoading = true;
              this.assetFilter.assetName = query;
              _context2.n = 1;
              return _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_16__["default"].getAssetDropdownProto(this.assetFilter);
            case 1:
              this.customers = _context2.v;
              this.isCustomerLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectAsset: function selectAsset(selected) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this4.innerValue.assetId = selected.assetId;
              _this4.innerValue.assetType = selected.assetType;
              _this4.innerValue.invoiceGlCode = selected.assetGlCode;
              _this4.assetFilter.assetId = selected.assetId;
              _this4.innerValue.contactId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
              _context3.n = 1;
              return _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_16__["default"].getContactDropdown(selected.assetId);
            case 1:
              _this4.contacts = _context3.v;
              _this4.selectedContact = null;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    removeAsset: function removeAsset(removed) {
      this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
      this.innerValue.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
      this.innerValue.contactId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
      this.innerValue.assetType = null;
      this.selectedContact = null;
      this.contacts = [];
      this.getAssetDropdown();
    },
    selectContact: function selectContact(selected) {
      this.innerValue.contactId = selected.contactId;
    },
    removeContact: function removeContact(removed) {
      this.innerValue.contactId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
    },
    onContactSearchChange: function onContactSearchChange(query) {
      this.isContactLoading = true;
      if (query && this.selectedContact) {
        this.selectedContact = null;
      }
      this.isContactLoading = false;
    },
    captureContactInput: function captureContactInput(event) {
      this.contactInput = event.target.value;
    },
    deleteRemark: function deleteRemark(remark, index, remarkType) {
      if (remark.isNew) {
        if (remarkType === this.remarkTypes.Remark) {
          this.innerValue.remarks.splice(index, 1);
        } else if (remarkType === this.remarkTypes.PrintedRemark) {
          this.innerValue.printedRemarks.splice(index, 1);
        }
      } else {
        remark.isDeleted = true;
      }
    },
    addRemarks: function addRemarks(remark, printedRemark) {
      if (remark) {
        var newRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__["RemarkModel"](this.innerValue.invoiceId, _enums__WEBPACK_IMPORTED_MODULE_21__["RemarkTypes"].Remark, remark);
        this.innerValue.remarks.push(newRemark);
      }
      if (printedRemark) {
        var newPrintedRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__["RemarkModel"](this.innerValue.invoiceId, _enums__WEBPACK_IMPORTED_MODULE_21__["RemarkTypes"].PrintedRemark, printedRemark);
        this.innerValue.printedRemarks.push(newPrintedRemark);
      }
      this.toggleRemarkModal();
    },
    toggleRemarkModal: function toggleRemarkModal() {
      this.isRemarkModalActive = !this.isRemarkModalActive;
    },
    onEditAddAsset: function onEditAddAsset() {
      if (this.gstPaid) {
        return false;
      }
      this.assetButtonLoading = true;
      if (this.hasAssetSelected) {
        if (this.selectedAsset.assetType === _enums__WEBPACK_IMPORTED_MODULE_21__["AssetTypes"].Customer.toString()) {
          this.setCustomerReturnRoute(this.$route);
          // Edit customer
          this.editStoreCustomer(this.selectedAsset.assetId);
        } else if (this.selectedAsset.assetType === _enums__WEBPACK_IMPORTED_MODULE_21__["AssetTypes"].Insurer.toString()) {
          this.setInsurerReturnRoute(this.$route);
          this.editStoreInsurer(this.selectedAsset.assetId);
        }
      } else {
        this.setCustomerReturnRoute(this.$route);
        this.addStoreCustomer(this.assetFilter.assetName);
      }
    },
    onEditAddContact: function onEditAddContact(event) {
      if (!this.hasAssetSelected || this.gstPaid) {
        return false;
      }
      this.contactButtonLoading = true;
      this.setContactReturnRoute(this.$route);
      if (this.hasContactSelected) {
        this.editStoreContact(this.selectedContact.contactId);
      } else {
        var payload = new _classes__WEBPACK_IMPORTED_MODULE_24__["ContactPayload"](this.contactInput, this.innerValue.assetId, this.innerValue.assetType, this.selectedAsset.assetName);
        this.addStoreContact(payload);
      }
    },
    onReload: function onReload() {
      var _this5 = this;
      this.$nextTick(function () {
        _this5.assetFilter.assetId = _this5.innerValue.assetId;
        _this5.getAssetDropdown();
      });
    },
    invoiceDateInputEvent: function invoiceDateInputEvent(event) {
      this.selectedInvoiceDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/quickinvoice/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickinvoiceSideMenu',
  inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_1___default.a;
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _QuickInvoiceSideMenu__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./QuickInvoiceSideMenu */ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue");
/* harmony import */ var _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./QuickInvoiceService */ "./src/views/quickinvoice/QuickInvoiceService.js");
/* harmony import */ var _QuickInvoiceValidation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./QuickInvoiceValidation */ "./src/views/quickinvoice/QuickInvoiceValidation.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./route-types */ "./src/views/quickinvoice/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _views_customer_route_types__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/views/customer/route-types */ "./src/views/customer/route-types.js");
/* harmony import */ var _views_customer_route_types__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_views_customer_route_types__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _views_insurer_route_types__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/views/insurer/route-types */ "./src/views/insurer/route-types.js");
/* harmony import */ var _views_contact_route_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/views/contact/route-types */ "./src/views/contact/route-types.js");
/* harmony import */ var _views_contact_route_types__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_views_contact_route_types__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quickinvoice/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");


































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickInvoiceView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_23__["default"]
  }, _QuickInvoiceSideMenu__WEBPACK_IMPORTED_MODULE_16__["default"].name, _QuickInvoiceSideMenu__WEBPACK_IMPORTED_MODULE_16__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_24__["UnsavedModal"]), "SaveConflictModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_24__["SaveConflictModal"]), "ConfirmModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_24__["ConfirmModal"]),
  mixins: [_QuickInvoiceValidation__WEBPACK_IMPORTED_MODULE_18__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_27__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null // stores "to" route of beforeRouteLeave
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error || this.$v.entity.items.$error;
    },
    activeItems: function activeItems() {
      return this.entity.items.filter(function (i) {
        return !i.isDeleted;
      });
    },
    gstPaid: function gstPaid() {
      return this.entity.gstPaidDate != null;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_29___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(this.entity));
        }
      }, 500),
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.returnUrl) {
              _this.persistQueries();
              _this.replaceRoute(_this.$route.params.invoiceId);
            }
            _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {
    if (lodash_isEmpty__WEBPACK_IMPORTED_MODULE_30___default()(this.returnRoute)) {
      this.setReadOnlyView(false);
    }
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_26__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_26__["AppHeaderButtonTypes"].Print:
          this.print1();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_26__["AppHeaderButtonTypes"].Delete:
          this.isConfirmModalActive = true;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_26__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_26__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.invoiceId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.invoiceId);
            case 2:
              _this2.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(_this2.currentSnapshot);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('', _t);
            case 4:
              _this2.$hideSpinner();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var title, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              title = 'Quick Invoice';
              if (isDelete) {
                _context3.n = 2;
                break;
              }
              // Touch here, not only in the child tabs: after a refresh on /items the Detail
              // tab never mounts, so its payer check would otherwise stay untouched and pass.
              _this3.$v.detailGroup.$touch();
              _this3.$v.entity.items.$touch();
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context3.a(2, false);
            case 1:
              if (!(_this3.activeItems.length === 0 || _this3.entity.totalExGst === 0)) {
                _context3.n = 2;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Invoice total cannot be 0');
              return _context3.a(2, false);
            case 2:
              _context3.p = 2;
              _this3.$showSpinner('Saving...');
              _this3.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(_this3.entity));
              if (!_this3.entity.isNew) {
                _context3.n = 4;
                break;
              }
              _context3.n = 3;
              return _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_17__["default"].postEntity(_this3.entity);
            case 3:
              response = _context3.v;
              _context3.n = 7;
              break;
            case 4:
              if (!_this3.snapshotDiff) {
                _context3.n = 6;
                break;
              }
              _context3.n = 5;
              return _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_17__["default"].putQuickInvoice(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(_this3.entity), _this3.snapshotDiff);
            case 5:
              response = _context3.v;
              _context3.n = 7;
              break;
            case 6:
              _this3.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 7:
              _this3.$hideSpinner();
              if (!_this3.isSaveContinue) {
                _context3.n = 8;
                break;
              }
              _this3.$notification.openNotificationWithType('success', title, isDelete ? 'Quick Invoice deleted' : 'Save successful');
              _context3.n = 12;
              break;
            case 8:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].NO_CONTENT)) {
                _context3.n = 10;
                break;
              }
              _context3.n = 9;
              return _this3.getEntity(true);
            case 9:
              _this3.$notification.openNotificationWithType('success', title, isDelete ? 'Quick Invoice deleted' : 'Save successful');
              _context3.n = 12;
              break;
            case 10:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CREATED)) {
                _context3.n = 12;
                break;
              }
              _context3.n = 11;
              return _this3.getEntity(true);
            case 11:
              _this3.$notification.openNotificationWithType('success', title, 'New Quick Invoice added');
            case 12:
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 13:
              _context3.p = 13;
              _t2 = _context3.v;
              _this3.$hideSpinner();
              if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CONFLICT) {
                _this3.isSaveConflictModalActive = true;
              } else {
                _this3.$notification.openMessageXhrError('Quick Invoice', _t2);
              }
              return _context3.a(2, false);
          }
        }, _callee3, null, [[2, 13]]);
      }))();
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      this.isConfirmModalActive = false;
      if (confirmDelete) {
        this.entity.deleted = true;
        // save snapshots immediately not waiting for debounce
        this.save(true);
      }
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(this.entity));
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        console.log(this.snapshotDiff);
        this.isUnsavedModalActive = true;
      } else {
        if (this.returnUrl) {
          this.clearSessionStorage();
          this.clearSnapshots(this.entity.invoiceId);
          window.location.href = "".concat("").concat(this.returnUrl);
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_30___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_19___default.a.QuickInvoiceListView.name
          });
        }
      }
    },
    print: function print() {
      var params = {
        reportname: 'AT_QuickInvoice',
        INVOICEID: this.entity.invoiceId,
        REPORTTITLE: this.$user.info.locale !== 'en-MY' ? 'TAX INVOICE' : 'INVOICE',
        COMPANYNAME: encodeURIComponent(this.$userInfo.companyName),
        COMPANYID: this.$userInfo.companyId,
        timezoneoffset: this.$filters.getSiteTimezoneOffset()
      };
      var url = "".concat("", "/modules/reports/printpreview.aspx?") + Object.keys(params).map(function (e) {
        return "".concat(e, "=").concat(params[e]);
      }).join('&');
      window.open(url, '_blank');
    },
    saveContinue: function saveContinue() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isUnsavedModalActive = false;
              _this4.isSaveContinue = true;
              _context4.n = 1;
              return _this4.save();
            case 1:
              _this4.isSaveContinue = _context4.v;
              if (_this4.isSaveContinue) {
                _this4.cancel();
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    print1: function print1() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var params, keyValuePairs, assetEmail, emailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              params = {
                // reportname: 'AT_QuickInvoice',
                INVOICEID: _this5.entity.invoiceId,
                REPORTTITLE: _this5.$user.info.locale !== 'en-MY' ? 'TAX INVOICE' : 'INVOICE',
                COMPANYNAME: encodeURIComponent(_this5.$userInfo.companyName),
                COMPANYID: _this5.$userInfo.companyId,
                timezoneoffset: _this5.$filters.getSiteTimezoneOffset()
              }; // Create KeyValuePairs and add to vuex for later retrieval by PrintPreviewEx component
              keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__["KeyValuePairModel"].convertToKeyValuePairs(params);
              _this5.addReportParameters(keyValuePairs);
              _context5.n = 1;
              return _QuickInvoiceService__WEBPACK_IMPORTED_MODULE_17__["default"].getAssetEmail(_this5.entity.assetId, _this5.entity.assetType);
            case 1:
              assetEmail = _context5.v;
              // console.log(assetEmail)
              emailer = new _classes__WEBPACK_IMPORTED_MODULE_32__["Emailer"]();
              if (assetEmail) {
                emailer.toEmails.push(assetEmail);
              }
              emailer.assetId = _this5.entity.invoiceId;
              emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_26__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_26__["AssetTypes"].Insurer];
              emailer.remark = "Invoice ".concat(_this5.entity.prefix).concat(_this5.entity.invoiceNo).concat(_this5.entity.suffix);
              emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_26__["RemarkTypes"].Remark;
              emailer.subject = "Invoice ".concat(_this5.entity.prefix).concat(_this5.entity.invoiceNo).concat(_this5.entity.suffix);
              emailer.reportName = "".concat(_this5.entity.prefix).concat(_this5.entity.invoiceNo).concat(_this5.entity.suffix);
              _this5.addEmailer(emailer);
              _this5.$router.push({
                name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_31__["default"].PrintPreview.name,
                params: {
                  reportName: 'AT_QuickInvoice'
                },
                query: {
                  parameterId: _this5.$guid.newGuid(),
                  emailerId: emailer.id
                }
              });
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
    },
    reloadData: function reloadData() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isSaveConflictModalActive = false;
              _this6.isSaveContinue = false;
              _context6.n = 1;
              return _this6.getEntity(true);
            case 1:
              _this6.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].EntityReload);
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickinvoice|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickinvoice|type"), this.type);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quickinvoice|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quickinvoice|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_19___default.a.QuickInvoiceDetail.name,
        params: {
          invoiceId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7(to, from, next) {
      var isEditCustomerContact;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_28___default()(this.entity));
            isEditCustomerContact = to.name === _views_customer_route_types__WEBPACK_IMPORTED_MODULE_20___default.a.CustomerDetail.name || to.name === _views_contact_route_types__WEBPACK_IMPORTED_MODULE_22___default.a.ContactDetail.name || to.name === _views_insurer_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].InsurerDetail.name;
            if (isEditCustomerContact) {
              next();
            } else if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
              console.log(this.snapshotDiff);
              this.$router.replace(from.path);
              this.toRoute = to;
              this.isUnsavedModalActive = true;
            } else {
              // Clean vuex store for now
              this.clearSnapshots(this.entity.invoiceId);
              this.clearSessionStorage();
              this.clearRouteMeta();
              if (to.name !== _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_31__["default"].PrintPreview.name) {
                this.setReturnRoute({});
              }
              next();
            }
          case 1:
            return _context7.a(2);
        }
      }, _callee7, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);



var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info "), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.innerValue.isNew,
      expression: "!innerValue.isNew"
    }],
    staticClass: "icon has-text-info tooltip is-tooltip-info",
    class: [_vm.canChangeReadOnly ? "readonly-pointer" : ""],
    attrs: {
      "data-tooltip": _vm.readOnlyView ? "Invoice is locked" : "Invoice is unlocked"
    },
    on: {
      click: function click($event) {
        return _vm.toogleReadOnly();
      }
    }
  }, [_c("i", {
    staticClass: "icon mdi",
    class: [_vm.readOnlyView ? "mdi-lock-outline" : "mdi-lock-open-outline"]
  })])]), _vm.innerValue.gstPaidDate ? _c("p", {
    staticClass: "subtitle has-text-warning"
  }, [_vm._v("Only Reference & Remarks can be updated")]) : _vm._e()]), _c("div", {
    staticClass: "column is-narrow"
  }, [_vm.innerValue.gstPaidDate ? _c("span", {
    staticClass: "tag is-warning is-pulled-right tooltip is-tooltip-warning",
    attrs: {
      "data-tooltip": "GST has been paid. Only Reference & Remarks can be updated"
    }
  }, [_vm._v("GST paid on " + _vm._s(_vm.$filters.formatDateLocale(_vm.innerValue.gstPaidDate, _vm.$userInfo.locale)))]) : _vm._e()])]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      placeholder: "Invoice No.",
      readonly: ""
    },
    domProps: {
      value: "".concat(_vm.innerValue.prefix).concat(_vm.innerValue.invoiceNo).concat(_vm.innerValue.suffix)
    }
  })])]), _vm.gstPaid || _vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.selectedInvoiceDate, _vm.$userInfo.locale)
    }
  })]) : _vm.$userInfo && !_vm.gstPaid && _vm.selectedInvoiceDate ? _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "min-date": _vm.firstDayOfMonth,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.invoiceDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Invoice Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedInvoiceDate,
      callback: function callback($$v) {
        _vm.selectedInvoiceDate = $$v;
      },
      expression: "selectedInvoiceDate"
    }
  })], 1) : _vm._e()]), _c("div", {
    staticClass: "is-divider"
  }), !_vm.gstPaid && !_vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("label", {
    staticStyle: {
      "font-size": "0.75rem"
    },
    attrs: {
      for: "chk-pretty-customer"
    }
  }, [_vm._v("Customer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth mr-0 ml-1",
    staticStyle: {
      "font-size": "0.875rem"
    }
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showCustomer,
      expression: "assetFilter.showCustomer"
    }],
    attrs: {
      id: "chk-pretty-customer",
      name: "chk-pretty-customer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showCustomer) ? _vm._i(_vm.assetFilter.showCustomer, null) > -1 : _vm.assetFilter.showCustomer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showCustomer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showCustomer", $$c);
        }
      }
    }
  }), _vm._m(0)]), _c("label", {
    staticClass: "pl-2",
    staticStyle: {
      "font-size": "0.75rem"
    },
    attrs: {
      for: "chk-pretty-insurer"
    }
  }, [_vm._v("Insurer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth mr-0 ml-1",
    staticStyle: {
      "font-size": "0.875rem"
    }
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showInsurer,
      expression: "assetFilter.showInsurer"
    }],
    attrs: {
      id: "chk-pretty-insurer",
      name: "chk-pretty-insurer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showInsurer) ? _vm._i(_vm.assetFilter.showInsurer, null) > -1 : _vm.assetFilter.showInsurer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showInsurer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showInsurer", $$c);
        }
      }
    }
  }), _vm._m(1)])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), (_vm.gstPaid || _vm.readOnlyView) && _vm.selectedAsset ? _c("div", {
    staticClass: "field"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.selectedAsset.assetName
    }
  })]) : !_vm.gstPaid && !_vm.readOnlyView ? _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_vm.activeCustomers ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.assetId.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Select a payer",
      options: _vm.activeCustomers,
      loading: _vm.isCustomerLoading,
      "internal-search": false,
      "options-limit": _vm.assetFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectAsset,
      remove: _vm.removeAsset,
      "search-change": _vm.getAssetDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetType == 1,
            "is-info": props.option.assetType == 4
          }
        }, [_vm._v(" " + _vm._s(props.option.assetType == 1 ? "Customer" : "Insurer") + " ")]), _c("span", [_vm._v(_vm._s("".concat(props.option.assetName)))])];
      }
    }], null, false, 2502510241),
    model: {
      value: _vm.selectedAsset,
      callback: function callback($$v) {
        _vm.selectedAsset = $$v;
      },
      expression: "selectedAsset"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Payer not found.")])]) : _vm._e(), _vm.selectedAsset && !_vm.selectedAsset.active ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Payer has been set to inactive.")]) : _vm._e(), _vm.$v.entity && !_vm.$v.entity.assetId.validGuid ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Payer is required.")]) : _vm._e()], 1), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button",
    class: _vm.assetButtonClass,
    attrs: {
      disabled: _vm.gstPaid || _vm.readOnlyView
    },
    on: {
      click: function click($event) {
        return _vm.onEditAddAsset();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: _vm.assetButtonIconClass
  })])])])]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Contact")]), _vm.gstPaid || _vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.selectedContact ? _vm.selectedContact.fullname : ""
    }
  })]) : _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      "track-by": "contactId",
      label: "fullname",
      placeholder: "Select a contact",
      options: _vm.activeContacts,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectContact,
      remove: _vm.removeContact,
      "search-change": _vm.onContactSearchChange
    },
    nativeOn: {
      input: function input($event) {
        return _vm.captureContactInput.apply(null, arguments);
      }
    },
    model: {
      value: _vm.selectedContact,
      callback: function callback($$v) {
        _vm.selectedContact = $$v;
      },
      expression: "selectedContact"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Contact not found.")])]), _vm.selectedContact && !_vm.selectedContact.active ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Contact has been set to inactive.")]) : _vm._e()], 1), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button",
    class: _vm.contactButtonClass,
    attrs: {
      disabled: !_vm.hasAssetSelected || _vm.gstPaid || _vm.readOnlyView
    },
    on: {
      click: function click($event) {
        return _vm.onEditAddContact();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: _vm.contactButtonIconClass
  })])])])])]), _c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.exported,
      expression: "innerValue.exported"
    }],
    attrs: {
      id: "chk-invoice-exported",
      name: "chk-invoice-exported",
      type: "checkbox",
      disabled: _vm.readOnlyView || !_vm.$userInfo.isSupportUser
    },
    domProps: {
      checked: Array.isArray(_vm.innerValue.exported) ? _vm._i(_vm.innerValue.exported, null) > -1 : _vm.innerValue.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.innerValue.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.innerValue, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.innerValue, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.innerValue, "exported", $$c);
        }
      }
    }
  }), _vm._m(2)]), _c("div", {
    staticClass: "is-divider"
  }), _c("label", {
    staticClass: "label"
  }, [_vm._v("Items")]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(3), _c("tfoot", {
    staticClass: "has-multiple-totals no-border"
  }, [_c("tr", {
    staticClass: "has-border-bottom-4",
    class: "quick-invoice-background-text-".concat(_vm.$theme.name)
  }, [_vm._m(4), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.innerValue.totalExGst, _vm.$userInfo.locale)))])]), _c("tr", {
    staticClass: "has-border-bottom-4",
    class: "quick-invoice-background-primary-".concat(_vm.$theme.name)
  }, [_c("th", {
    staticClass: "has-text-left"
  }, [_vm._v("GST "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(" + _vm._s(_vm.innerValue.gstRate) + "%)")])]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.innerValue.gst, _vm.$userInfo.locale)))])]), _c("tr", {
    class: "quick-invoice-background-success-".concat(_vm.$theme.name)
  }, [_vm._m(5), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.innerValue.totalIncGst, _vm.$userInfo.locale)))])])]), _vm.activeItems.length > 0 ? _c("tbody", _vm._l(_vm.activeItems, function (item) {
    return _c("tr", {
      key: item.invoiceItemId
    }, [_c("td", [_vm._v(_vm._s(item.invoiceItemDesc))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.totalIncGst, _vm.$userInfo.locale)))])]);
  }), 0) : _c("tbody", [_vm._m(6)])]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Payments")]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(7), _vm.innerValue.payments.length > 0 ? _c("tfoot", {
    staticClass: "has-multiple-totals"
  }, [_c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: "2"
    }
  }, [_vm._v("Total Paid")]), _c("th", {
    staticClass: "has-text-right has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalPaid, _vm.$userInfo.locale)))])]), _c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: "2"
    }
  }, [_vm._v("Balance")]), _c("th", {
    staticClass: "has-text-right"
  }, [_c("span", {
    class: _vm.balanceClass
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.balance, _vm.$userInfo.locale)))])])])]) : _vm._e(), _vm.innerValue.payments.length > 0 ? _c("tbody", _vm._l(_vm.innerValue.payments, function (payment) {
    return _c("tr", {
      key: payment.invoicePaymentId
    }, [_c("td", [_vm._v(" " + _vm._s(_vm.$filters.formatDateLocale(payment.payDate, _vm.$userInfo.locale)) + " ")]), _c("td", [_vm._v(_vm._s(payment.chequeNo))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(payment.amountPaid, _vm.$userInfo.locale)))])]);
  }), 0) : _c("tbody", [_vm._m(8)])])])]), _c("div", {
    staticClass: "cell is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Reference & Remarks")]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Reference")]), _c("div", {
    staticClass: "control"
  }, [!_vm.readOnlyView ? _c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.reference,
      expression: "innerValue.reference"
    }],
    staticClass: "textarea",
    attrs: {
      placeholder: "",
      disabled: _vm.readOnlyView
    },
    domProps: {
      value: _vm.innerValue.reference
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "reference", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.innerValue.reference))])])]), !_vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("a", {
    staticClass: "button is-small is-success tooltip",
    attrs: {
      "data-tooltip": "Add Remarks"
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(9), _c("span", [_vm._v("Remarks")])])])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Remarks")]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_c("thead"), _vm.activeRemarks.length > 0 ? _c("tbody", _vm._l(_vm.activeRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _vm.readOnlyView ? _c("td", [_c("div", {
      staticClass: "control"
    }, [_c("span", [_vm._v(_vm._s(remark.remarks))])])]) : _c("td", [_c("div", {
      staticClass: "control"
    }, [_c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: remark.remarks,
        expression: "remark.remarks"
      }],
      staticClass: "textarea",
      attrs: {
        placeholder: ""
      },
      domProps: {
        value: remark.remarks
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(remark, "remarks", $event.target.value);
        }
      }
    })])]), !_vm.readOnlyView ? _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.deleteRemark(remark, index, _vm.remarkTypes.Remark);
        }
      }
    }, [_vm._m(10, true)])]) : _vm._e()]);
  }), 0) : _c("tbody", [_vm._m(11)])])]), !_vm.readOnlyView ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("a", {
    staticClass: "button is-small is-success tooltip",
    attrs: {
      "data-tooltip": "Add Remarks"
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(12), _c("span", [_vm._v("Remarks")])])])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Printed Remarks")]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_c("thead"), _vm.activePrintedRemarks.length > 0 ? _c("tbody", _vm._l(_vm.activePrintedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _vm.readOnlyView ? _c("td", [_c("div", {
      staticClass: "control"
    }, [_c("span", [_vm._v(_vm._s(remark.remarks))])])]) : _c("td", [_c("div", {
      staticClass: "control"
    }, [_c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: remark.remarks,
        expression: "remark.remarks"
      }],
      staticClass: "textarea",
      attrs: {
        placeholder: ""
      },
      domProps: {
        value: remark.remarks
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(remark, "remarks", $event.target.value);
        }
      }
    })])]), !_vm.readOnlyView ? _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.deleteRemark(remark, index, _vm.remarkTypes.PrintedRemark);
        }
      }
    }, [_vm._m(13, true)])]) : _vm._e()]);
  }), 0) : _c("tbody", [_vm._m(14)])])])])])]), _vm.value && _vm.isRemarkModalActive ? _c("remark-modal", {
    attrs: {
      "show-remark": true,
      "show-printed-remark": true,
      "show-recurring-remark": true,
      active: _vm.isRemarkModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRemarkModalActive = $event;
      },
      add: _vm.addRemarks,
      cancel: function cancel($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Add Quick Invoice Remarks")])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-success"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", [_vm._v("Exported")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Description")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(" Total ")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("th", {
    staticClass: "has-text-left"
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("th", {
    staticClass: "has-text-left"
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    staticClass: "has-text-centered",
    attrs: {
      colspan: "3"
    }
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-dots-horizontal mdi-inactive-color mdi-inactive"
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("th", [_vm._v("Date")]), _c("th", [_vm._v("Cheque No.")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Paid")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    staticClass: "has-text-centered",
    attrs: {
      colspan: "3"
    }
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-dots-horizontal mdi-inactive-color mdi-inactive"
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-medium"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    staticClass: "has-text-centered",
    attrs: {
      colspan: "2"
    }
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-comment-text-outline mdi-inactive-color mdi-inactive"
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-medium"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    staticClass: "has-text-centered",
    attrs: {
      colspan: "2"
    }
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-comment-text-outline mdi-inactive-color mdi-inactive"
  })])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Inv No: " + _vm._s(_vm.entityName) + " ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.QuickInvoiceDetail.name,
        params: {
          invoiceId: _vm.$route.params.invoiceId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.detailGroup.$error ? "" : null
    }
  }, [_vm._v(" Detail Info ")])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.QuickInvoiceItems.name,
        params: {
          invoiceId: _vm.$route.params.invoiceId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.entity.items.$error
    },
    attrs: {
      "data-badge": _vm.$v.entity.items.$error ? "" : null
    }
  }, [_vm._v(" Invoice Items ")])])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.entity && !_vm.entity.isNew,
      "show-delete": _vm.entity && !_vm.entity.deleted && !_vm.entity.isNew && _vm.entity.payments.length == 0 && !_vm.gstPaid && !_vm.readOnlyView,
      "show-save": _vm.entity && !_vm.entity.deleted && !_vm.readOnlyView
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("quickinvoice-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": "".concat(_vm.entity.prefix).concat(_vm.entity.invoiceNo).concat(_vm.entity.suffix)
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column m-3"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name,
      "gst-paid": _vm.gstPaid,
      "read-only-view": _vm.readOnlyView
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Quick Invoice")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Invoice "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.prefix).concat(_vm.entity.invoiceNo).concat(_vm.entity.suffix)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-3b006894] {\n  margin: 1.2em 0;\n}\n.subtext[data-v-3b006894] {\n  font-size: 10px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/_baseSet.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/_baseSet.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assignValue = __webpack_require__(/*! ./_assignValue */ "./node_modules/lodash/_assignValue.js"),
    castPath = __webpack_require__(/*! ./_castPath */ "./node_modules/lodash/_castPath.js"),
    isIndex = __webpack_require__(/*! ./_isIndex */ "./node_modules/lodash/_isIndex.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    toKey = __webpack_require__(/*! ./_toKey */ "./node_modules/lodash/_toKey.js");

/**
 * The base implementation of `_.set`.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {Array|string} path The path of the property to set.
 * @param {*} value The value to set.
 * @param {Function} [customizer] The function to customize path creation.
 * @returns {Object} Returns `object`.
 */
function baseSet(object, path, value, customizer) {
  if (!isObject(object)) {
    return object;
  }
  path = castPath(path, object);

  var index = -1,
      length = path.length,
      lastIndex = length - 1,
      nested = object;

  while (nested != null && ++index < length) {
    var key = toKey(path[index]),
        newValue = value;

    if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
      return object;
    }

    if (index != lastIndex) {
      var objValue = nested[key];
      newValue = customizer ? customizer(objValue, key, nested) : undefined;
      if (newValue === undefined) {
        newValue = isObject(objValue)
          ? objValue
          : (isIndex(path[index + 1]) ? [] : {});
      }
    }
    assignValue(nested, key, newValue);
    nested = nested[key];
  }
  return object;
}

module.exports = baseSet;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/lodash/set.js":
/*!************************************!*\
  !*** ./node_modules/lodash/set.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseSet = __webpack_require__(/*! ./_baseSet */ "./node_modules/lodash/_baseSet.js");

/**
 * Sets the value at `path` of `object`. If a portion of `path` doesn't exist,
 * it's created. Arrays are created for missing index properties while objects
 * are created for all other missing properties. Use `_.setWith` to customize
 * `path` creation.
 *
 * **Note:** This method mutates `object`.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to modify.
 * @param {Array|string} path The path of the property to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns `object`.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.set(object, 'a[0].b.c', 4);
 * console.log(object.a[0].b.c);
 * // => 4
 *
 * _.set(object, ['x', '0', 'y', 'z'], 5);
 * console.log(object.x[0].y.z);
 * // => 5
 */
function set(object, path, value) {
  return object == null ? object : baseSet(object, path, value);
}

module.exports = set;


/***/ }),

/***/ "./node_modules/lodash/tap.js":
/*!************************************!*\
  !*** ./node_modules/lodash/tap.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method invokes `interceptor` and returns `value`. The interceptor
 * is invoked with one argument; (value). The purpose of this method is to
 * "tap into" a method chain sequence in order to modify intermediate results.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Seq
 * @param {*} value The value to provide to `interceptor`.
 * @param {Function} interceptor The function to invoke.
 * @returns {*} Returns `value`.
 * @example
 *
 * _([1, 2, 3])
 *  .tap(function(array) {
 *    // Mutate input array.
 *    array.pop();
 *  })
 *  .reverse()
 *  .value();
 * // => [2, 1]
 */
function tap(value, interceptor) {
  interceptor(value);
  return value;
}

module.exports = tap;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("63ee0c04", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceDetail.vue":
/*!*******************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceDetail.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true */ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true");
/* harmony import */ var _QuickInvoiceDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickInvoiceDetail.vue?vue&type=script&lang=js */ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true */ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuickInvoiceDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3b006894",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickinvoice/QuickInvoiceDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true":
/*!****************************************************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=style&index=0&id=3b006894&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_style_index_0_id_3b006894_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true":
/*!*************************************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceDetail.vue?vue&type=template&id=3b006894&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceDetail_vue_vue_type_template_id_3b006894_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue":
/*!*********************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceSideMenu.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a */ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a");
/* harmony import */ var _QuickInvoiceSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickInvoiceSideMenu.vue?vue&type=script&lang=js */ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuickInvoiceSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickinvoice/QuickInvoiceSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a":
/*!***************************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceSideMenu.vue?vue&type=template&id=9965260a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceSideMenu_vue_vue_type_template_id_9965260a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceValidation.js":
/*!**********************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceValidation.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.assetId', 'entity.invoiceDate'],
    entity: {
      assetId: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      },
      invoiceDate: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      items: {
        $each: {
          invoiceItemDesc: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
          }
        }
      }
    },
    filter: {
      dateFrom: {
        validDate: true // aussieDateValidator
      },
      dateTo: {
        validDate: true // aussieDateValidator
      }
    }
  }
});

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceView.vue":
/*!*****************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceView.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickInvoiceView.vue?vue&type=template&id=6669934a */ "./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a");
/* harmony import */ var _QuickInvoiceView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickInvoiceView.vue?vue&type=script&lang=js */ "./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuickInvoiceView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickinvoice/QuickInvoiceView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a":
/*!***********************************************************************************!*\
  !*** ./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickInvoiceView.vue?vue&type=template&id=6669934a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickinvoice/QuickInvoiceView.vue?vue&type=template&id=6669934a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickInvoiceView_vue_vue_type_template_id_6669934a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickinvoice/storeMixin.js":
/*!**********************************************!*\
  !*** ./src/views/quickinvoice/storeMixin.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'quickinvoices';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    readOnlyView: 'readOnlyView'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute', 'setReadOnlyView'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['setAsset', 'setContactId'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('contacts', {
    setContactReturnRoute: 'setReturnRoute',
    addStoreContact: 'addStoreItem',
    editStoreContact: 'editStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('customers', {
    setCustomerReturnRoute: 'setReturnRoute',
    editStoreCustomer: 'editStoreItem',
    addStoreCustomer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('insurers', {
    setInsurerReturnRoute: 'setReturnRoute',
    editStoreInsurer: 'editStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=quickinvoice-chunk.js.map