(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-orm-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.flat-map.js */ "./node_modules/core-js/modules/es.array.flat-map.js");
/* harmony import */ var core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_flat_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.array.unscopables.flat-map.js */ "./node_modules/core-js/modules/es.array.unscopables.flat-map.js");
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.flat-map.js */ "./node_modules/core-js/modules/es.iterator.flat-map.js");
/* harmony import */ var core_js_modules_es_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_XmlViewer__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @/components/XmlViewer */ "./src/components/XmlViewer/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./mixins/QuoteStoreMixin */ "./src/views/quote/mixins/QuoteStoreMixin.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_OrmPnetUtilitiesModal__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./components/OrmPnetUtilitiesModal */ "./src/views/quote/components/OrmPnetUtilitiesModal.vue");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ../ormmessage/OrmMessageService */ "./src/views/ormmessage/OrmMessageService.js");
/* harmony import */ var _ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ../ormmessage/columns */ "./src/views/ormmessage/columns.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _ormbatching_OrmBatchingService__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ../ormbatching/OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./mixins/QuoteInvoiceStoreMixin */ "./src/views/quote/mixins/QuoteInvoiceStoreMixin.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");


























































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteOrm',
  inject: ['$vv'],
  directives: {
    mask: vue_the_mask__WEBPACK_IMPORTED_MODULE_49__["mask"]
  },
  components: {
    XmlViewerModal: _components_XmlViewer__WEBPACK_IMPORTED_MODULE_38__["XmlViewerModal"],
    OrmDeclineQuoteRequestModal: _components__WEBPACK_IMPORTED_MODULE_40__["OrmDeclineQuoteRequestModal"],
    OrmSendQuoteModal: _components__WEBPACK_IMPORTED_MODULE_40__["OrmSendQuoteModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_42__["ConfirmModal"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_44__["default"],
    OrmSubmitTaxInvoiceModal: _components__WEBPACK_IMPORTED_MODULE_40__["OrmSubmitTaxInvoiceModal"],
    OrmPnetUtilitiesModal: _components_OrmPnetUtilitiesModal__WEBPACK_IMPORTED_MODULE_48__["default"],
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_49__["TheMask"]
  },
  mixins: [_mixins__WEBPACK_IMPORTED_MODULE_39__["QuoteNotificationMixin"], _storeMixin__WEBPACK_IMPORTED_MODULE_52__["default"], _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_41__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_45__["DateTimeFiltersMixin"], _mixins__WEBPACK_IMPORTED_MODULE_39__["QuoteAssessmentMixin"], _mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_55__["default"]],
  props: {
    value: null,
    ormUnreadMessageCount: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      innerValue: null,
      messageType: 'ORM',
      isXmlViewerModalActive: false,
      isOrmDeclineQuoteRequestModalActive: false,
      isOrmSendQuoteModalActive: false,
      sendQuoteType: _enums__WEBPACK_IMPORTED_MODULE_37__["OrmSendQuoteTypes"].Quote,
      isConfirmModalActive: false,
      isWarningModalActive: false,
      isSendQuoteAnyway: false,
      isOrmSubmitTaxInvoiceModalActive: false,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_43__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_43__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 8
      },
      isTableLoading: false,
      isReactivateInvoice: false,
      quoteStatusTypes: null,
      isOrmUtilitiesModalActive: false,
      ormQuoteBatch: null,
      quotesTotals: [],
      innerInvoice: null,
      ormLatestPaymentAuthorisedMessage: null
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    qdeStatusTypes: function qdeStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_37__["QdeStatusTypes"];
    },
    isActionEnabled: function isActionEnabled() {
      return this.value.orm && this.value.orm.messageNo;
    },
    isSubmitTaxInvoiceEnabled: function isSubmitTaxInvoiceEnabled() {
      return this.value.invoices.some(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_37__["InvoiceTypes"].Quote && !i.deleted;
      });
    },
    ormSendQuoteTypes: function ormSendQuoteTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_37__["OrmSendQuoteTypes"];
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_43__["RemarkColumns"];
    },
    remarkTotalRows: function remarkTotalRows() {
      return this.value.otherRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_37__["RemarkTypes"].ORMSystemRemark && !r.isDeleted;
      }).length;
    },
    activeRemarks: function activeRemarks() {
      return this.value.otherRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_37__["RemarkTypes"].ORMSystemRemark && !r.isDeleted;
      });
    },
    pagedRemarks: function pagedRemarks() {
      return this.activeRemarks.slice((this.filter.pageIndex - 1) * this.filter.pageSize, this.filter.pageIndex * this.filter.pageSize);
    },
    MessageStatusTypes: function MessageStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_37__["MessageStatusTypes"];
    },
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|ormmessage|filter");
      } else {
        return '';
      }
    },
    Columns: function Columns() {
      return _ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__["Columns"];
    },
    isOrmInvoiceSubmitted: function isOrmInvoiceSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmQuoteStatusTypes"].QuoteInvoiceSubmitted;
    },
    isOrmReactiveInvoiceSubmitted: function isOrmReactiveInvoiceSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmQuoteStatusTypes"].ReactiveInvoiceSubmitted;
    },
    isOrmAdjustmentNoteSubmitted: function isOrmAdjustmentNoteSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmQuoteStatusTypes"].AdjustmentNoteSubmitted;
    },
    cannotRaiseInvoice: function cannotRaiseInvoice() {
      return this.isOrmInvoiceSubmitted || this.isOrmReactiveInvoiceSubmitted || this.isOrmAdjustmentNoteSubmitted;
    },
    hasInvoices: function hasInvoices() {
      var _this$value;
      return (_this$value = this.value) === null || _this$value === void 0 || (_this$value = _this$value.invoices) === null || _this$value === void 0 ? void 0 : _this$value.some(function (inv) {
        var _inv$includedQuotes;
        return !inv.deleted && ((_inv$includedQuotes = inv.includedQuotes) === null || _inv$includedQuotes === void 0 ? void 0 : _inv$includedQuotes.length) > 0;
      });
    },
    invoiceRows: function invoiceRows() {
      if (!this.quotesTotals || this.quotesTotals.length === 0) {
        return [];
      }
      return this.quotesTotals.map(function (quote) {
        var label = 'Unknown';
        if (quote.subQuoteNo === 0) {
          label = 'Main';
        } else if (quote.subQuoteNo > 0) {
          label = "Supp-".concat(quote.subQuoteNo);
        }
        var totalExGst = quote.totalExGst || 0;
        // const excess = quote.excess || 0
        // const ownerContribution = quote.ownerContribution || 0
        var total = totalExGst;
        return {
          quoteId: quote.quoteId,
          subQuoteNo: quote.subQuoteNo,
          label: label,
          totalExGst: totalExGst,
          total: total
        };
      }).sort(function (a, b) {
        return a.subQuoteNo - b.subQuoteNo;
      });
    },
    totalQuotesAmount: function totalQuotesAmount() {
      if (!this.quotesTotals || this.quotesTotals.length === 0) {
        return 0;
      }
      return this.quotesTotals.reduce(function (sum, quote) {
        return sum + (quote.totalExGst || 0);
      }, 0);
    },
    totalAuthorisedAmount: function totalAuthorisedAmount() {
      if (!this.quotesTotals || this.quotesTotals.length === 0) {
        return 0;
      }
      return this.quotesTotals.reduce(function (sum, quote) {
        return sum + (quote.authorisedAmount || 0);
      }, 0);
    },
    totalInvoicedAmount: function totalInvoicedAmount() {
      var invoiceTotalExGst = (this.innerInvoice.partTotal || 0) + (this.innerInvoice.labourTotal || 0) + (this.innerInvoice.miscTotal || 0) + (this.innerInvoice.subletTotal || 0) + (!this.isAssessmentEnabled ? this.innerInvoice.mechTotal || 0 : 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(invoiceTotalExGst);
    },
    amountDifference: function amountDifference() {
      return this.totalAuthorisedAmount - this.totalInvoicedAmount;
    },
    hasDiffInvoicedAndAuthorised: function hasDiffInvoicedAndAuthorised() {
      var _this$innerValue;
      if (!this.innerValue.authorisedAmount) return false; //skip if authorised amount is not set
      //if (this.innerValue?.isAssessmentEnabled) return false
      if (((_this$innerValue = this.innerValue) === null || _this$innerValue === void 0 || (_this$innerValue = _this$innerValue.orm) === null || _this$innerValue === void 0 ? void 0 : _this$innerValue.quoteStatusId) === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmQuoteStatusTypes"].PaymentAuthorised) return false;
      if (!this.isSubmitTaxInvoiceEnabled) return false;
      if (!this.totalAuthorisedAmount || !this.totalInvoicedAmount) return false;
      var roundingTolerance = 0.05; // Allow 5 cents difference (rounding tolerance)

      if (this.isAssessmentEnabled) {
        return Math.abs(this.totalInvoicedAmount - this.totalAuthorisedAmount) > roundingTolerance;
      } else {
        var diff1 = Math.abs(this.totalInvoicedAmount - this.totalAuthorisedAmount) > roundingTolerance;
        var diff2 = Math.abs(this.totalInvoicedAmount - this.totalQuotesAmount) > roundingTolerance;
        return diff1 || diff2;
      }
    },
    isAssessmentEnabled: function isAssessmentEnabled() {
      var _this$innerValue2;
      return (_this$innerValue2 = this.innerValue) === null || _this$innerValue2 === void 0 ? void 0 : _this$innerValue2.isAssessmentEnabled;
    },
    IsOrmPaymentUnableLoad: function IsOrmPaymentUnableLoad() {
      if (this.innerValue && this.innerValue.orm && this.ormLatestPaymentAuthorisedMessage) {
        var currentMessageNo = parseInt(this.innerValue.orm.messageNo, 10) || 0;
        var expectedMessageNo = currentMessageNo + 1;
        if (this.ormLatestPaymentAuthorisedMessage && expectedMessageNo !== this.ormLatestPaymentAuthorisedMessage.ormMessageNo && this.ormLatestPaymentAuthorisedMessage.statusId === 30) {
          return true;
        }
      }
      return false;
    },
    ormExpectedMessageNo: function ormExpectedMessageNo() {
      if (this.innerValue && this.innerValue.orm) {
        return (parseInt(this.innerValue.orm.messageNo, 10) || 0) + 1;
      }
      return null;
    }
  },
  watch: {
    // 'innerValue.orm.outOfScope': function(newVal, oldVal) {
    //   this.$emit('input', newVal)
    // }
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46___default()(_this.value);
            _this.getOrmQuoteStatusTypes();
            _this.getOrmQuoteBatch();
            _this.getIncludedQuotesTotals();
            _this.getInvoice();
            if (!_this.innerValue.orm) {
              _context.n = 1;
              break;
            }
            _context.n = 1;
            return _this.getOrmUnreadPaymentAuthorisedMessage();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    var _this2 = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_37__["EventHubTypes"].EntitySaved, function () {
      _this2.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46___default()(_this2.value);
      _this2.reloadInvoice();
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_37__["EventHubTypes"].EntitySaved);
  },
  methods: {
    reloadInvoice: function reloadInvoice() {
      this.getIncludedQuotesTotals();
      this.getInvoice();
    },
    updateInvoice: function updateInvoice() {
      var _this3 = this;
      var entity = this.currentSnapshot;
      if (entity) {
        this.innerInvoice = this.innerValue.invoices.find(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_37__["InvoiceTypes"].Quote && !i.deleted;
        });
        if (!this.innerInvoice) return;
        console.log('this.invoiceIncludedQuotes: ', this.invoiceIncludedQuotes)

        // Calculate all invoice values
        ;
        this.innerInvoice.gstRate = entity.gstRate, this.innerInvoice.labourTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.labourTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.labourTotal;
        }, 0)), this.innerInvoice.rrTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.rrTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.rrTotal;
        }, 0)), this.innerInvoice.repairTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.repairTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.repairTotal;
        }, 0)), this.innerInvoice.rwaTotals = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.rwaTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.rwaTotal;
        }, 0)), this.innerInvoice.paintTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.paintTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.paintTotal;
        }, 0)), this.innerInvoice.fgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.fgTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.fgTotal;
        }, 0)), this.innerInvoice.crushTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.crushTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.crushTotal;
        }, 0)), this.innerInvoice.cdTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.cdTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.cdTotal;
        }, 0)), this.innerInvoice.mechTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.mechTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.mechTotal;
        }, 0)), this.innerInvoice.opgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.opgTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.opgTotal;
        }, 0)), this.innerInvoice.partTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.partTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.partTotal;
        }, 0)), this.innerInvoice.miscTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.miscTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.miscTotal;
        }, 0)), this.innerInvoice.subletTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.sublTotal + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.sublTotal;
        }, 0)), this.innerInvoice.excessAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.excess + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.excess;
        }, 0)), this.innerInvoice.ownerContribution = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.ownersContribution + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.ownerContribution;
        }, 0)), this.innerInvoice.quoteDiscount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(entity.discount + this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return total + quote.discount;
        }, 0));
        this.recalculateTotals();
        this.$emit('save');
        this.$nextTick(function () {
          _this3.showSuccessToast('Invoice updated to match authorised totals.<br/>Submission unlocked.');
        });
      }
    },
    recalculateTotals: function recalculateTotals() {
      var includedQuotesTotalExGst = this.invoiceIncludedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(total + (quote.totalExGst || 0));
      }, 0);
      console.log('this.innerValue.totalExGst: ', this.innerValue.totalExGst);
      console.log('includedQuotesTotalExGst: ', includedQuotesTotalExGst);
      var quotesTotalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(this.innerValue.totalExGst + includedQuotesTotalExGst);
      console.log('quotesTotalExGst: ', quotesTotalExGst);
      if (!this.innerValue.excessWithGst) {
        // let ownerContributionGst = roundAwayFromZero((this.innerInvoice.ownerContribution * this.innerInvoice.gstRate) / 100)
        // this.innerInvoice.totalExGst = roundAwayFromZero(
        //   quotesTotalExGst - this.innerInvoice.quoteDiscount - this.innerInvoice.excessAmount - this.innerInvoice.ownerContribution - ownerContributionGst
        // )
        this.innerInvoice.totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(quotesTotalExGst);
        this.innerInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])((quotesTotalExGst - this.innerInvoice.quoteDiscount) * this.innerValue.gstRate / 100);
        this.innerInvoice.totalIncGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(this.innerInvoice.totalExGst + this.innerInvoice.gst);
      } else {
        // this.innerInvoice.totalExGst = roundAwayFromZero(
        //   quotesTotalExGst - this.innerInvoice.excessAmount - this.innerInvoice.quoteDiscount - this.innerInvoice.ownerContribution
        // )
        this.innerInvoice.totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(quotesTotalExGst);
        this.innerInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_56__["roundAwayFromZero"])(this.innerInvoice.totalExGst * this.innerInvoice.gstRate / 100);
        this.innerInvoice.totalIncGst = this.innerInvoice.totalExGst + this.innerInvoice.gst;
      }
      console.log('innerInvoice: ', this.innerInvoice.totalIncGst);
    },
    getInvoice: function getInvoice() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var _this4$innerValue;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this4.innerInvoice = ((_this4$innerValue = _this4.innerValue) === null || _this4$innerValue === void 0 || (_this4$innerValue = _this4$innerValue.invoices) === null || _this4$innerValue === void 0 ? void 0 : _this4$innerValue.length) > 0 ? _this4.innerValue.invoices.find(function (i) {
                return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_37__["InvoiceTypes"].Quote && !i.deleted;
              }) : null;
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getIncludedQuotesTotals: function getIncludedQuotesTotals() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var _this5$quotesTotals;
        var rawQuoteIds, quoteIds, vm, quotesTotals;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              rawQuoteIds = _this5.innerValue.invoices.filter(function (inv) {
                return inv.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_37__["InvoiceTypes"].Quote && !inv.deleted;
              }).filter(function (inv) {
                var _inv$includedQuotes2;
                return inv.includedQuotes && ((_inv$includedQuotes2 = inv.includedQuotes) === null || _inv$includedQuotes2 === void 0 ? void 0 : _inv$includedQuotes2.length) > 0;
              }).flatMap(function (inv) {
                return inv.includedQuotes;
              });
              quoteIds = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(new Set(rawQuoteIds.filter(Boolean)));
              vm = _this5;
              _context3.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_54__["default"].getIncludedQuotesTotals(quoteIds);
            case 1:
              quotesTotals = _context3.v;
              (_this5$quotesTotals = _this5.quotesTotals).splice.apply(_this5$quotesTotals, [0, _this5.quotesTotals.length].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(quotesTotals)));
              console.log('quotesTotals: ', _this5.quotesTotals);
              _this5.clearInvoiceIncludedQuotes();
              _this5.quotesTotals.forEach(function (q) {
                if (q && q.subQuoteNo !== vm.innerValue.subQuoteNo) {
                  vm.addInvoiceIncludedQuotes(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_46___default()(q));
                }
              });
              console.log('invoiceIncludedQuotes: ', _this5.invoiceIncludedQuotes);
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    handleViewOrmUnreadMessages: function handleViewOrmUnreadMessages() {
      var filter = {
        quoteNo: '',
        rego: '',
        claimNo: this.value.claimNo,
        messageTypeId: 0,
        messageStatusId: _enums__WEBPACK_IMPORTED_MODULE_37__["MessageStatusTypes"].UnRead,
        sortColumn: _ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__["Columns"][_ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__["Columns"].length - 2].name,
        sortOrder: _ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__["Columns"][_ormmessage_columns__WEBPACK_IMPORTED_MODULE_51__["Columns"].length - 2].defaultOrder,
        pageIndex: 1,
        pageSize: 18,
        customerNameOrContactNo: ''
      };
      sessionStorage.setItem(this.filterKey, JSON.stringify(filter));
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|ormmessage|returnUrl"), this.$route.path);
      this.$router.push({
        path: '/ormmessages'
      });
    },
    viewMessages: function viewMessages(type) {
      this.messageType = type;
      this.isXmlViewerModalActive = true;
    },
    sendQuote: function sendQuote(type) {
      var _arguments = arguments,
        _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        var sendAnyway, hasPenndingMessage, hasJobDateError;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              sendAnyway = _arguments.length > 1 && _arguments[1] !== undefined ? _arguments[1] : false;
              if (!_this6.$licenceExpired) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              if (!(_this6.value.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_37__["QuotingMethodTypes"].Dollar)) {
                _context5.n = 2;
                break;
              }
              _this6.showToast('ORM does not accept Dollar quotes.', 'warning');
              return _context5.a(2);
            case 2:
              _this6.$showSpinner();
              _context5.n = 3;
              return _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_50__["default"].hasAnyPendingOrmMessage(_this6.innerValue.quoteId);
            case 3:
              hasPenndingMessage = _context5.v;
              _context5.n = 4;
              return _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_50__["default"].validateQuoteItems(_this6.innerValue.quoteId);
            case 4:
              _this6.$hideSpinner();
              if (!hasPenndingMessage) {
                _context5.n = 5;
                break;
              }
              _this6.$notification.openNotificationWithType('danger', 'ORM', 'There are pending messages. Please load those messages before sending quote.');
              return _context5.a(2);
            case 5:
              if (_this6.$parent && _this6.$parent.touchOrmHeaderValidators) {
                _this6.$parent.touchOrmHeaderValidators();
                _this6.$parent.touchOrmSummaryValidators();
              } else {
                _this6.touchOrmHeaderValidators();
                _this6.touchOrmSummaryValidators();
              }
              if (_this6.$parent && _this6.$parent.validateJobStartEndForOrm) {
                _this6.$parent.validateJobStartEndForOrm();
              } else {
                _this6.validateJobStartEndForOrm();
              }
              hasJobDateError = !_this6.$v.entity.jobStart.bothRequired || !_this6.$v.entity.jobEnd.bothRequired || _this6.$v.entity.jobStart.$error || _this6.$v.entity.jobEnd.$error;
              if (!(_this6.$v.ormHeaderGroup.$error || _this6.$v.ormSummaryGroup.$error || hasJobDateError)) {
                _context5.n = 6;
                break;
              }
              _this6.$notification.openNotificationWithType('danger', 'ORM', 'Send cancelled. Required fields are missing or invalid');
              return _context5.a(2);
            case 6:
              if (_this6.$parent && _this6.$parent.resetOrmValidation) {
                _this6.$parent.resetOrmValidation();
              } else {
                _this6.resetOrmValidation();
              }
              _context5.n = 7;
              return _this6.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
                  while (1) switch (_context4.n) {
                    case 0:
                      if (_this6.value.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmQuoteStatusTypes"].QuoteSubmitted && type === _enums__WEBPACK_IMPORTED_MODULE_37__["OrmSendQuoteTypes"].Quote && !sendAnyway) {
                        _this6.isConfirmModalActive = true;
                      } else {
                        _this6.isConfirmModalActive = false;
                        _this6.sendQuoteType = type;
                        _this6.isOrmSendQuoteModalActive = true;
                      }
                    case 1:
                      return _context4.a(2);
                  }
                }, _callee4);
              })));
            case 7:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    declineQuoteRequest: function declineQuoteRequest() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              if (!_this7.$licenceExpired) {
                _context7.n = 1;
                break;
              }
              return _context7.a(2);
            case 1:
              _context7.n = 2;
              return _this7.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
                  while (1) switch (_context6.n) {
                    case 0:
                      _this7.isOrmDeclineQuoteRequestModalActive = true;
                    case 1:
                      return _context6.a(2);
                  }
                }, _callee6);
              })));
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    sendInvoice: function sendInvoice(isReactivateInvoice) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var items, itemsChanged;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!_this8.$licenceExpired) {
                _context8.n = 1;
                break;
              }
              return _context8.a(2);
            case 1:
              _this8.isReactivateInvoice = isReactivateInvoice;
              items = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.labours), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.others), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.parts), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.opgs), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.miscs), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.value.sublets));
              itemsChanged = _this8.itemsChanged(items, _this8.value.quotingMethod);
              if (!_this8.innerValue.quoteAssessments.some(function (a) {
                return a.isInvoiced !== true;
              })) {
                _context8.n = 2;
                break;
              }
              _this8.isWarningModalActive = true;
              _context8.n = 4;
              break;
            case 2:
              if (!(itemsChanged.length > 0 && _this8.innerValue.isAssessmentEnabled)) {
                _context8.n = 3;
                break;
              }
              _this8.isWarningModalActive = true;
              _context8.n = 4;
              break;
            case 3:
              _context8.n = 4;
              return _this8.showSubmitTaxInvoiceModal();
            case 4:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    getOrmUnreadPaymentAuthorisedMessage: function getOrmUnreadPaymentAuthorisedMessage() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee9() {
        var messages, latestMessage, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context9) {
          while (1) switch (_context9.p = _context9.n) {
            case 0:
              _context9.p = 0;
              _context9.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_47__["OrmService"].getMessages(_this9.innerValue.claimNo, _this9.innerValue.vehicleRego, _enums__WEBPACK_IMPORTED_MODULE_37__["MessageTypes"].QML_PaymentAuthorised);
            case 1:
              messages = _context9.v;
              if (!(!messages || messages.length === 0)) {
                _context9.n = 2;
                break;
              }
              return _context9.a(2);
            case 2:
              latestMessage = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(messages).sort(function (a, b) {
                return b.ormMessageNo - a.ormMessageNo;
              })[0];
              _this9.ormLatestPaymentAuthorisedMessage = latestMessage;
              _context9.n = 4;
              break;
            case 3:
              _context9.p = 3;
              _t = _context9.v;
              console.error('Error fetching ORM Payment Authorised messages:', _t);
            case 4:
              return _context9.a(2);
          }
        }, _callee9, null, [[0, 3]]);
      }))();
    },
    showSubmitTaxInvoiceModal: function showSubmitTaxInvoiceModal() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee1() {
        var hasPenndingMessage, hasJobDateError;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (!(_this0.ormUnreadMessageCount > 0)) {
                _context1.n = 1;
                break;
              }
              _this0.$notification.openNotificationWithType('danger', 'ORM', 'There are unread ORM messages. Please load those messages before sending quote.');
              return _context1.a(2);
            case 1:
              _this0.isWarningModalActive = false;
              _context1.n = 2;
              return _ormmessage_OrmMessageService__WEBPACK_IMPORTED_MODULE_50__["default"].hasAnyPendingOrmMessage(_this0.innerValue.quoteId);
            case 2:
              hasPenndingMessage = _context1.v;
              if (!hasPenndingMessage) {
                _context1.n = 3;
                break;
              }
              _this0.$notification.openNotificationWithType('danger', 'ORM', 'There are pending messages. Please load those messages before sending quote.');
              return _context1.a(2);
            case 3:
              if (_this0.$parent && _this0.$parent.touchOrmHeaderValidators) {
                _this0.$parent.touchOrmHeaderValidators();
                _this0.$parent.touchOrmSummaryValidators();
              } else {
                _this0.touchOrmHeaderValidators();
                _this0.touchOrmSummaryValidators();
              }
              if (_this0.$parent && _this0.$parent.validateJobStartEndForOrm) {
                _this0.$parent.validateJobStartEndForOrm();
              } else {
                _this0.validateJobStartEndForOrm();
              }
              hasJobDateError = !_this0.$v.entity.jobStart.bothRequired || !_this0.$v.entity.jobEnd.bothRequired || _this0.$v.entity.jobStart.$error || _this0.$v.entity.jobEnd.$error;
              if (!(_this0.$v.ormHeaderGroup.$error || _this0.$v.ormSummaryGroup.$error || hasJobDateError)) {
                _context1.n = 4;
                break;
              }
              _this0.$notification.openNotificationWithType('danger', 'ORM', 'Send cancelled. Required fields are missing or invalid');
              return _context1.a(2);
            case 4:
              if (_this0.$parent && _this0.$parent.resetOrmValidation) {
                _this0.$parent.resetOrmValidation();
              } else {
                _this0.resetOrmValidation();
              }
              _context1.n = 5;
              return _this0.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee0() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context0) {
                  while (1) switch (_context0.n) {
                    case 0:
                      _this0.isOrmSubmitTaxInvoiceModalActive = true;
                    case 1:
                      return _context0.a(2);
                  }
                }, _callee0);
              })));
            case 5:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    reload: function reload() {
      this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_37__["EventHubTypes"].EntityReload);
      this.showSuccessToast('Tax invoice is being submitted');
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
    },
    sort: function sort(name, order) {},
    getOrmQuoteStatusTypes: function getOrmQuoteStatusTypes() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee10() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              _context10.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_47__["OrmService"].getOrmQuoteStatusTypes();
            case 1:
              _this1.quoteStatusTypes = _context10.v;
            case 2:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    showUtilities: function showUtilities() {
      this.isOrmUtilitiesModalActive = true;
    },
    viewOrmBatchDetail: function viewOrmBatchDetail() {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee11() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              _this10.$router.push({
                path: "/ormbatching/batch/".concat(_this10.ormQuoteBatch.batchId)
              });
            case 1:
              return _context11.a(2);
          }
        }, _callee11);
      }))();
    },
    getOrmQuoteBatch: function getOrmQuoteBatch() {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee12() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              _context12.n = 1;
              return _ormbatching_OrmBatchingService__WEBPACK_IMPORTED_MODULE_53__["default"].getOrmQuoteBatch(_this11.innerValue.orm.quoteId);
            case 1:
              _this11.ormQuoteBatch = _context12.v;
            case 2:
              return _context12.a(2);
          }
        }, _callee12);
      }))();
    },
    refreshInvoice: function refreshInvoice() {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee13() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context13) {
          while (1) switch (_context13.n) {
            case 0:
              _this12.updateInvoice();
            case 1:
              return _context13.a(2);
          }
        }, _callee13);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);










var render = function render() {
  var _vm$quoteStatusTypes;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-orm-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_vm._m(0), _c("div", {
    staticClass: "column is-narrow"
  }, [_vm.value.orm ? _c("div", {
    staticClass: "dropdown is-right is-hoverable"
  }, [_vm._m(1), _c("div", {
    staticClass: "dropdown-menu",
    attrs: {
      id: "dropdown-menu-pnet",
      role: "menu"
    }
  }, [_c("div", {
    staticClass: "dropdown-content"
  }, [_vm.isActionEnabled && _vm.ormUnreadMessageCount == 0 && _vm.value.orm.canSubmit ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.sendQuote(_vm.ormSendQuoteTypes.Quote);
      }
    }
  }, [_vm._m(2), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Quote")])]) : _vm._e(), _vm.isSubmitTaxInvoiceEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && (_vm.cannotRaiseInvoice || _vm.hasDiffInvoicedAndAuthorised),
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        $event.preventDefault();
        !_vm.$licenceExpired && !_vm.cannotRaiseInvoice && !_vm.hasDiffInvoicedAndAuthorised && _vm.sendInvoice(false);
      }
    }
  }, [_vm._m(3), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Tax Invoice")])]) : _vm._e(), _vm.isActionEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.declineQuoteRequest();
      }
    }
  }, [_vm._m(4), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Decline Quote Request")])]) : _vm._e(), _vm.isActionEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.sendQuote(_vm.ormSendQuoteTypes.TotalLoss);
      }
    }
  }, [_vm._m(5), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Inform Total Loss")])]) : _vm._e(), _vm.isActionEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.sendQuote(_vm.ormSendQuoteTypes.RequestInspection);
      }
    }
  }, [_vm._m(6), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Request Inspection")])]) : _vm._e(), _vm.isSubmitTaxInvoiceEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.cannotRaiseInvoice,
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        $event.preventDefault();
        !_vm.$licenceExpired && !_vm.cannotRaiseInvoice && _vm.sendInvoice(true);
      }
    }
  }, [_vm._m(7), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Re-activate Tax Invoice")])]) : _vm._e(), _c("hr", {
    staticClass: "dropdown-divider"
  }), _vm.$user.info.isSupportUser ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.showUtilities();
      }
    }
  }, [_vm._m(8), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Utilities")])]) : _vm._e(), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.viewMessages("ORM");
      }
    }
  }, [_vm._m(9), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("View Messages")])])])])]) : _vm._e()])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("table", {
    staticClass: "table is-bordered is-striped"
  }, [_c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle"
  }, [_vm._v("Unread Messages")]), _c("td", [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-space-between"
  }, [_c("span", [_vm._v(" " + _vm._s(_vm.ormUnreadMessageCount) + " Unread ")]), _c("div", {
    staticClass: "button is-primary",
    on: {
      click: _vm.handleViewOrmUnreadMessages
    }
  }, [_vm._v(" View ")])])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle"
  }, [_vm._v("Message No.")]), _vm.$user.info.isSupportUser ? _c("td", [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "Message No.",
      disabled: _vm.$licenceExpired,
      mask: ["##"]
    },
    model: {
      value: _vm.innerValue.orm.messageNo,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue.orm, "messageNo", $$v);
      },
      expression: "innerValue.orm.messageNo"
    }
  })], 1) : _c("td", [_vm._v(_vm._s(_vm.value.orm.messageNo))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle"
  }, [_vm._v("ReInstatement No.")]), _vm.$user.info.isSupportUser ? _c("td", [_c("the-mask", {
    staticClass: "input",
    attrs: {
      type: "number",
      placeholder: "ReInstatement No.",
      disabled: _vm.$licenceExpired,
      mask: ["##"]
    },
    model: {
      value: _vm.innerValue.orm.reinstatementNo,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue.orm, "reinstatementNo", $$v);
      },
      expression: "innerValue.orm.reinstatementNo"
    }
  })], 1) : _c("td", [_vm._v(_vm._s(_vm.value.orm.reinstatementNo))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle"
  }, [_vm._v("Quote Status")]), _vm.$user.info.isSupportUser ? _c("td", [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.orm.quoteStatusId,
      expression: "innerValue.orm.quoteStatusId"
    }],
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue.orm, "quoteStatusId", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.quoteStatusTypes, function (type) {
    return _c("option", {
      key: type.value,
      domProps: {
        value: type.value
      }
    }, [_vm._v(_vm._s(type.name))]);
  }), 0)])]) : _c("td", [_vm._v(_vm._s((_vm$quoteStatusTypes = _vm.quoteStatusTypes) === null || _vm$quoteStatusTypes === void 0 || (_vm$quoteStatusTypes = _vm$quoteStatusTypes.find(function (s) {
    return s.value === _vm.value.orm.quoteStatusId;
  })) === null || _vm$quoteStatusTypes === void 0 ? void 0 : _vm$quoteStatusTypes.name))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Vehicle ID")]), _vm.$user.info.isSupportUser ? _c("td", [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.orm.vehicleId,
      expression: "innerValue.orm.vehicleId"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Vehicle ID",
      disabled: _vm.$licenceExpired,
      maxlength: "20"
    },
    domProps: {
      value: _vm.innerValue.orm.vehicleId
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue.orm, "vehicleId", $event.target.value);
      }
    }
  })]) : _c("td", [_vm._v(_vm._s(_vm.value.orm.vehicleId))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Underwriter")]), _vm.$user.info.isSupportUser ? _c("td", [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.orm.underwriter,
      expression: "innerValue.orm.underwriter"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Underwriter",
      disabled: _vm.$licenceExpired,
      maxlength: "45"
    },
    domProps: {
      value: _vm.innerValue.orm.underwriter
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue.orm, "underwriter", $event.target.value);
      }
    }
  })]) : _c("td", [_vm._v(_vm._s(_vm.value.orm.underwriter))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Make & Model")]), _c("td", [_vm._v(_vm._s(_vm.value.orm.make) + " " + _vm._s(_vm.value.orm.model) + " " + _vm._s(_vm.value.orm.series))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Quote Type")]), _c("td", [_vm._v(_vm._s(_vm.value.orm.quoteType))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Damaged Areas")]), _c("td", [_vm._v(_vm._s(_vm.value.orm.damagedAreas))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("QDE Status")]), _c("td", [_vm._v(_vm._s(_vm.$filters.formatQdeStatus(_vm.value.orm.qdeStatus)))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle"
  }, [_vm._v("Batch Number")]), _vm.ormQuoteBatch ? _c("td", [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-space-between"
  }, [_c("span", [_vm._v(_vm._s(_vm.ormQuoteBatch.batchNo))]), _c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.viewOrmBatchDetail
    }
  }, [_vm._v(" View ")])])]) : _c("td", [_vm._v("N/A")])])])]), _c("div", {
    staticClass: "column is-5"
  }, [_vm.ormUnreadMessageCount > 0 || !_vm.value.orm.canSubmit || _vm.IsOrmPaymentUnableLoad ? _c("div", {
    staticClass: "unread-messages-section mb-4"
  }, [_c("div", {
    staticClass: "is-flex flex-start"
  }, [_c("span", {
    staticClass: "material-symbols-outlined has-text-warning mr-2"
  }, [_vm._v(" warning ")]), _c("div", [_vm.IsOrmPaymentUnableLoad ? _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" Note: The latest Payment Authorisation message for this quote was "), _c("b", [_vm._v("NOT")]), _vm._v(" loaded successfully because the message number is out of sequence. The expected message number is "), _c("b", [_vm._v(_vm._s(_vm.ormExpectedMessageNo))]), _vm._v(", but the received message is "), _c("b", [_vm._v(_vm._s(_vm.ormLatestPaymentAuthorisedMessage.ormMessageNo))]), _vm._v(". Please load the message manually. ")]) : _vm._e(), !_vm.value.orm.canSubmit ? _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" Note: The Submit Quote button is currently disabled because a Payment Authorisation Message has been received for this job. ")]) : _vm._e(), _vm.ormUnreadMessageCount > 0 ? _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" Note: The submit Quote button is currently disabled because there are unread messages for this quote. Please view and load messages to unlock the submit function. ")]) : _vm._e(), !_vm.value.orm.canSubmit ? _c("div", [_vm._m(10), _vm._m(11), _vm._m(12)]) : _vm._e()])])]) : _vm._e(), _vm.hasDiffInvoicedAndAuthorised ? _c("article", {
    staticClass: "message",
    class: "is-warning " + (_vm.$theme.isDark ? "is-dark" : "is-light")
  }, [_vm._m(13), _c("section", {
    staticClass: "message-body",
    class: _vm.$theme.isDark ? "is-dark" : "is-light"
  }, [_vm._m(14), _c("div", {
    staticClass: "table-container mb-4"
  }, [_c("table", {
    staticClass: "table is-fullwidth"
  }, [_vm._m(15), _c("tbody", [_vm._l(_vm.invoiceRows, function (row) {
    return _c("tr", {
      key: row.quoteId
    }, [_c("td", [_vm._v(_vm._s(row.label))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(row.total, _vm.$userInfo.locale, false, 2)))])]);
  }), _c("tr", {
    staticClass: "has-text-weight-bold tr-top-border-2px"
  }, [_c("td", [_vm._v("Totals")]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalQuotesAmount, _vm.$userInfo.locale, false, 2)))])]), _c("tr", {
    staticClass: "has-text-weight-semibold tr-top-border-2px authorised-row"
  }, [_c("td", {}, [_vm._v("Authorised Amount in ORM")]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalAuthorisedAmount, _vm.$userInfo.locale, false, 2)))])]), _c("tr", {
    staticClass: "has-text-weight-semibold"
  }, [_c("td", [_vm._v("Amount (Ext GST) In Invoice")]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalInvoicedAmount, _vm.$userInfo.locale, false, 2)))])]), _c("tr", {
    staticClass: "has-text-weight-bold difference-row"
  }, [_c("td", [_vm._v("Difference")]), _c("td", {
    staticClass: "has-text-right has-text-danger has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.amountDifference, _vm.$userInfo.locale, false, 2)))])])], 2)])])])]) : _vm.cannotRaiseInvoice ? _c("div", [_c("div", {
    staticClass: "bulma-message-modal"
  }, [_c("article", {
    staticClass: "message bulma-message-modal-panel",
    class: "is-warning " + (_vm.$theme.isDark ? "is-dark" : "is-light")
  }, [_vm._m(16), _c("section", {
    staticClass: "message-body",
    class: _vm.$theme.isDark ? "is-dark" : "is-light"
  }, [_vm._m(17)])])])]) : _vm._e()])])]), _c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Remarks")]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.remarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "is-remark"
    }, [_c("div", [_vm._v(_vm._s(remark.remarks))])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), _vm.isXmlViewerModalActive ? _c("xml-viewer-modal", {
    attrs: {
      active: _vm.isXmlViewerModalActive,
      "quote-id": _vm.value.quoteId,
      "message-type": _vm.messageType,
      "page-size": 10
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isXmlViewerModalActive = $event;
      },
      close: function close($event) {
        _vm.isXmlViewerModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("View " + _vm._s(_vm.messageType) + " Messages")])]) : _vm._e(), _vm.isOrmDeclineQuoteRequestModalActive ? _c("orm-decline-quote-request-modal", {
    attrs: {
      active: _vm.isOrmDeclineQuoteRequestModalActive,
      value: _vm.value
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isOrmDeclineQuoteRequestModalActive = $event;
      },
      close: function close($event) {
        _vm.isOrmDeclineQuoteRequestModalActive = false;
      }
    }
  }) : _vm._e(), _vm.isOrmSendQuoteModalActive ? _c("orm-send-quote-modal", {
    attrs: {
      active: _vm.isOrmSendQuoteModalActive,
      value: _vm.value,
      "send-quote-type": _vm.sendQuoteType
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isOrmSendQuoteModalActive = $event;
      },
      close: function close($event) {
        _vm.isOrmSendQuoteModalActive = false;
      }
    }
  }) : _vm._e(), _vm.isOrmSubmitTaxInvoiceModalActive ? _c("orm-submit-tax-invoice-modal", {
    attrs: {
      active: _vm.isOrmSubmitTaxInvoiceModalActive,
      "is-reactivate-invoice": _vm.isReactivateInvoice,
      value: _vm.value
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isOrmSubmitTaxInvoiceModalActive = $event;
      },
      sent: function sent($event) {
        return _vm.reload();
      }
    }
  }) : _vm._e(), _vm.isConfirmModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Proceed",
      "cancel-text": "Cancel"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.sendQuote(_vm.ormSendQuoteTypes.Quote, true);
      },
      cancel: function cancel($event) {
        _vm.isConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Submit Quote")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(" AUTHORISATION FOR LAST QUOTE NOT YET RECEIVED FROM INSURER. WE STRONGLY RECCOMMEND THAT YOU WAIT FOR THE AUTHORISATION MESSAGE AND LOAD IT INTO THIS QUOTE BEFORE YOU SEND MORE VARIATIONS ")])])]) : _vm._e(), _vm.isWarningModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isWarningModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isWarningModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.showSubmitTaxInvoiceModal(true);
      },
      cancel: function cancel($event) {
        _vm.isWarningModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Send Invoice")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(" Some items haven't been authorised. Do you want to proceed? Please note, only the authorised amounts will be sent to the insurer. ")])])]) : _vm._e(), _vm.isOrmUtilitiesModalActive ? _c("orm-pnet-utilities-modal", {
    attrs: {
      active: _vm.isOrmUtilitiesModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isOrmUtilitiesModalActive = $event;
      }
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("ORM")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "dropdown-trigger"
  }, [_c("button", {
    staticClass: "button",
    attrs: {
      "aria-haspopup": "true",
      "aria-controls": "dropdown-menu-pnet"
    }
  }, [_c("span", [_vm._v("ORM")]), _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-chevron-down",
    attrs: {
      "aria-hidden": "true"
    }
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-upload mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-currency-usd mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-cancel mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-car-off mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-eye-check-outline mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-restart mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-tools mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-file-code mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" Please review the information below and send an email to the appropriate department via the "), _c("strong", [_vm._v("Communications")]), _vm._v(" tab. ")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mb-3"
  }, [_c("strong", [_vm._v("Quote Variation")]), _c("br"), _vm._v(" If submitting a quote variation, email nationalassessing@iag.com.au "), _c("a", {
    staticClass: "icon has-text-primary",
    attrs: {
      href: "mailto:nationalassessing@iag.com.au"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-link-box-variant mdi-24px"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mb-3"
  }, [_c("strong", [_vm._v("Invoice Variation")]), _c("br"), _vm._v(" If submitting an invoice variation, email supplierinvoices@iag.com.au "), _c("a", {
    staticClass: "icon has-text-primary",
    attrs: {
      href: "mailto:supplierinvoices@iag.com.au"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-link-box-variant mdi-24px"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("header", {
    staticClass: "message-header"
  }, [_c("span", {
    staticClass: "is-flex is-align-items-center"
  }, [_c("span", {
    staticClass: "msr msr-24px mr-2 has-text-amber"
  }, [_vm._v("warning")]), _c("span", [_vm._v("Authorised Amount Mismatch")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" The authorised amount for this invoice doesn't match the invoiced amount."), _c("br"), _vm._v(" To continue, "), _c("span", [_vm._v("please update the invoice so that the totals align before proceeding.")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Quote")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Amount")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("header", {
    staticClass: "message-header"
  }, [_c("span", {
    staticClass: "is-flex is-align-items-center"
  }, [_c("span", {
    staticClass: "msr msr-24px mr-2 has-text-amber"
  }, [_vm._v("warning")]), _c("span", [_vm._v("Invoice Pending Payment Authority")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "mb-3"
  }, [_vm._v(" An invoice has already been submitted for this quote and is awaiting payment authority."), _c("br"), _vm._v(" Raising a new invoice is currently disabled. ")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.tr-top-border-2px[data-v-3ba7453b] {\n  border-top: 2px var(--bulma-table-cell-border-style) var(--bulma-table-cell-border-color) !important;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "a.dropdown-item-has-icon[data-v-3ba7453b] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\nspan.dropdown-item-text[data-v-3ba7453b] {\n  padding-left: 5px;\n}\n.unread-messages-section[data-v-3ba7453b] {\n  border: 1px solid var(--border-color);\n  padding: 20px;\n}\n.bulma-message-modal[data-v-3ba7453b] {\n  border: 1px solid var(--border-color);\n}\n.bulma-message-modal-footer[data-v-3ba7453b] {\n  padding: 0.75rem 1rem 1rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  gap: 0.5rem;\n}\n.message.is-light .message-header[data-v-3ba7453b] {\n  background-color: var(--message-header-light-bg);\n  color: var(--message-header-light-color);\n}\n.message.is-dark .message-header[data-v-3ba7453b] {\n  background-color: var(--message-header-dark-bg);\n  color: var(--message-header-dark-color);\n}\n.message.is-light .message-body[data-v-3ba7453b] {\n  background-color: var(--message-body-light-bg);\n  color: var(--message-body-light-color);\n  border: 2px solid var(--message-header-light-bg);\n}\n.message.is-dark .message-body[data-v-3ba7453b] {\n  background-color: var(--message-body-dark-bg);\n  color: var(--message-body-dark-color);\n  border: 2px solid var(--message-header-dark-bg);\n}\n.dropdown-item.is-disabled[data-v-3ba7453b] {\n  pointer-events: none;\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n.difference-row[data-v-3ba7453b] {\n  background-color: var(--bulma-background) !important;\n}\n.message.is-light .authorised-row[data-v-3ba7453b] {\n  background-color: var(--bulma-success-95);\n}\n.message.is-dark .authorised-row[data-v-3ba7453b] {\n  background-color: var(--bulma-success-15);\n}\na.is-disabled[data-v-3ba7453b] {\n  opacity: 0.5;\n  cursor: not-allowed;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-orm-licence-expired .dropdown-item.is-licence-disabled,\n.quote-orm-licence-expired td:has(> input:disabled),\n.quote-orm-licence-expired td:has(> .select > select:disabled) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-orm-licence-expired .dropdown-item.is-licence-disabled:hover::before,\n.quote-orm-licence-expired td:has(> input:disabled):hover::before,\n.quote-orm-licence-expired td:has(> .select > select:disabled):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-orm-licence-expired .dropdown-item.is-licence-disabled > .icon,\n.quote-orm-licence-expired .dropdown-item.is-licence-disabled > .dropdown-item-text {\n  opacity: 0.5;\n}\n.quote-orm-licence-expired .dropdown-item.is-licence-disabled:hover::before {\n  top: 50%;\n  right: 100%;\n  -webkit-transform: translate(-0.5rem, -50%);\n          transform: translate(-0.5rem, -50%);\n}\n.quote-orm-licence-expired td:has(> input:disabled):hover::before,\n.quote-orm-licence-expired td:has(> .select > select:disabled):hover::before {\n  top: 100%;\n  left: 0;\n}\n.quote-orm-licence-expired td > input:disabled,\n.quote-orm-licence-expired td > .select > select:disabled {\n  cursor: not-allowed;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2a0bed8c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("68438bc7", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("48a18b5b", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/ormmessage/columns.js":
/*!*****************************************!*\
  !*** ./src/views/ormmessage/columns.js ***!
  \*****************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Type', 'messageType', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('QDE Status', 'qdeStatus', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Message No.', 'ormMessageNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'regoNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim No.', 'claimNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim Type', 'claimType', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Customer', 'customerName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Mobile No.', 'mobilePhone', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('UID', 'uid', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No.', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Vehicle', 'vehicleDescription', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Received Date', 'createdDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue":
/*!**************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true */ "./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true");
/* harmony import */ var _QuoteOrm_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteOrm.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true */ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true");
/* harmony import */ var _QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss */ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss");
/* harmony import */ var _QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css */ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");








/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_5__["default"])(
  _QuoteOrm_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3ba7453b",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteOrm.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js":
/*!**************************************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true":
/*!***********************************************************************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=0&id=3ba7453b&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_0_id_3ba7453b_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss":
/*!***********************************************************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=1&id=3ba7453b&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_1_id_3ba7453b_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css":
/*!**********************************************************************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=style&index=2&id=3ba7453b&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_style_index_2_id_3ba7453b_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true":
/*!********************************************************************************!*\
  !*** ./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOrm.vue?vue&type=template&id=3ba7453b&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOrm_vue_vue_type_template_id_3ba7453b_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-orm-chunk.js.map