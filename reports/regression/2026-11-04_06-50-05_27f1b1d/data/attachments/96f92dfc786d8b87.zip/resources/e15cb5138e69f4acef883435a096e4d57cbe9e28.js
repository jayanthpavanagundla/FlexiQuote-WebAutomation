(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-detail-chunk~quote-summary-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteDetailSummary',
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_15__["default"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      supplementaryQuotes: [],
      isFetchingSupplementaryQuote: false
    };
  },
  computed: {
    hasPinnedRemarks: function hasPinnedRemarks() {
      return this.pinnedActiveRemarks && this.pinnedActiveRemarks.length > 0;
    },
    pinnedActiveRemarks: function pinnedActiveRemarks() {
      var pinnedActiveRemarks = this.value.remarks.filter(function (r) {
        return r.pinRemarkOrder !== null && r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_14__["RemarkTypes"].Remark && !r.isDeleted;
      });
      return pinnedActiveRemarks.sort(function (a, b) {
        return a.pinRemarkOrder - b.pinRemarkOrder;
      });
    },
    displayRemarks: function displayRemarks() {
      var unpinnedActiveRemarks = this.value.remarks.filter(function (r) {
        return r.pinRemarkOrder == null && r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_14__["RemarkTypes"].Remark && !r.isDeleted;
      });
      unpinnedActiveRemarks.sort(function (a, b) {
        return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
      });
      return this.hasPinnedRemarks ? this.pinnedActiveRemarks.slice(0, 5) : unpinnedActiveRemarks.slice(0, 5);
    },
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_14__["ItemCategoryTypes"];
    },
    showSupplementaryQuoteTotals: function showSupplementaryQuoteTotals() {
      return this.value.subQuoteNos.length > 1 && this.value.subQuoteNo === 0 && !this.isFetchingSupplementaryQuote && this.supplementaryQuotes.length > 0;
    },
    test: function test() {
      return this.supplementaryQuotes.map(function (q) {
        return q.rwaTotal;
      });
    },
    grandTotalExGst: function grandTotalExGst() {
      return this.showSupplementaryQuoteTotals ? this.calculateGrandTotal(this.value.totalExGst, this.supplementaryQuotes.map(function (q) {
        return q.totalExGst;
      })) : this.value.totalExGst;
    },
    invTotalExGst: function invTotalExGst() {
      var _this$value$excess, _this$value$discount;
      var excess = (_this$value$excess = this.value.excess) !== null && _this$value$excess !== void 0 ? _this$value$excess : 0;
      var discount = (_this$value$discount = this.value.discount) !== null && _this$value$discount !== void 0 ? _this$value$discount : 0;
      return !this.value.excessWithGst ? this.grandTotalExGst - discount : this.grandTotalExGst - (excess + discount);
    },
    totalPayableIncGst: function totalPayableIncGst() {
      var total = this.invTotalExGst * (this.value.gstRate / 100 + 1);
      var ownerContributionWithGST = this.value.ownersContribution * (this.value.gstRate / 100 + 1);
      var res = this.value.excessWithGst ? total - ownerContributionWithGST : total - this.value.excess - ownerContributionWithGST;
      return res;
    },
    showInvAmtIncGst: function showInvAmtIncGst() {
      return this.value.ownersContribution || this.value.excess || this.value.discount;
    },
    mainQuoteTotalGst: function mainQuoteTotalGst() {
      var grandSuppTotalExGst = this.supplementaryQuotes.reduce(function (sum, supp) {
        return sum + (parseFloat(supp.totalExGst) || 0);
      }, 0);
      return (this.invTotalExGst - grandSuppTotalExGst) * (this.value.gstRate / 100);
    },
    mainQuoteTotalIncGst: function mainQuoteTotalIncGst() {
      var grandSuppTotalIncGst = this.supplementaryQuotes.reduce(function (sum, supp) {
        return sum + (parseFloat(supp.totalIncGst) || 0);
      }, 0);
      return this.invTotalExGst * (this.value.gstRate / 100 + 1) - grandSuppTotalIncGst;
    },
    mainQuoteTotalPayable: function mainQuoteTotalPayable() {
      var grandSuppTotalIncGst = this.supplementaryQuotes.reduce(function (sum, supp) {
        return sum + (parseFloat(supp.totalIncGst) || 0);
      }, 0);
      return this.totalPayableIncGst - grandSuppTotalIncGst;
    }
  },
  created: function created() {
    this.getSupplementaryQuoteTotals();
  },
  mounted: function mounted() {},
  methods: {
    getDisplayName: function getDisplayName(itemCategoryType) {
      if (this.companyItemTypes) {
        var itemType = this.companyItemTypes.find(function (i) {
          return i.itemCategoryType === itemCategoryType;
        });
        if (itemType) {
          return itemType.displayName;
        }
      }
      return itemCategoryType;
    },
    isEnabled: function isEnabled(itemCategoryType) {
      if (this.companyItemTypes) {
        var itemType = this.companyItemTypes.find(function (i) {
          return i.itemCategoryType === itemCategoryType;
        });
        if (itemType) {
          return itemType.enabled;
        }
      }
      return false;
    },
    getSupplementaryQuoteTotals: function getSupplementaryQuoteTotals() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!(_this.value.subQuoteNo === 0)) {
                _context.n = 2;
                break;
              }
              _this.isFetchingSupplementaryQuote = true;
              _context.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_16__["default"].getSupplementaryQuoteTotals(_this.value.quoteId);
            case 1:
              _this.supplementaryQuotes = _context.v;
              _this.supplementaryQuotes.sort(function (a, b) {
                return a.subQuoteNo - b.subQuoteNo;
              });
            case 2:
              _this.isFetchingSupplementaryQuote = false;
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    calculateGrandTotal: function calculateGrandTotal(mainCategorytotal, supplementaryCategoryTotalsArray) {
      var suppCategoryTotal = supplementaryCategoryTotalsArray.reduce(function (total, suppTotal) {
        return total + suppTotal;
      }, 0);
      return mainCategorytotal + suppCategoryTotal;
    },
    calculateSummaryTotal: function calculateSummaryTotal() {
      var suppTotalExGst = this.supplementaryQuotes.map(function (q) {
        return q.totalExGst;
      }).reduce(function (total, suppTotal) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_17__["roundAwayFromZero"])(total + suppTotal);
      }, 0);
      var gstTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_17__["roundAwayFromZero"])((this.value.totalExGst + suppTotalExGst) * (this.value.gstRate / 100));
      var totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_17__["roundAwayFromZero"])(this.value.totalExGst + suppTotalExGst);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_17__["roundAwayFromZero"])(totalExGst + gstTotal);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.companyItemTypes ? _c("div", [_c("table", {
    staticClass: "table is-bordered is-narrow is-fullwidth",
    class: {
      "is-loading": _vm.isFetchingSupplementaryQuote
    }
  }, [_c("thead", [_c("tr", {
    staticClass: "no-border",
    class: "summary-background-text-".concat(_vm.$theme.name)
  }, [_c("th", [_vm._v("Category")]), _vm.value.subQuoteNos.length > 1 && _vm.value.subQuoteNo === 0 ? [_vm._l(_vm.value.subQuoteNos, function (sub) {
    return _c("th", {
      key: sub.value,
      staticClass: "has-text-right is-subtotal"
    }, [_vm._v(" " + _vm._s(sub.key === 0 ? "Main" : "Add-".concat(sub.key)) + " ")]);
  }), _c("th", {
    staticClass: "has-text-right is-subtotal"
  }, [_vm._v(" Summary ")])] : _vm.value.subQuoteNos.length === 1 || _vm.value.subQuoteNo > 0 ? [_c("th", {
    staticClass: "has-text-right is-subtotal"
  }, [_vm._v(" Total ")])] : _vm._e()], 2)]), _vm.value.subQuoteNos.length === 1 || _vm.showSupplementaryQuoteTotals || _vm.value.subQuoteNo > 0 ? _c("tfoot", {
    staticClass: "no-border"
  }, [_c("tr", {
    staticClass: "has-border-bottom-4",
    class: ["summary-background-text-".concat(_vm.$theme.name)]
  }, [_vm._m(0), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.value.totalExGst, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(supp.totalExGst, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.calculateGrandTotal(_vm.value.totalExGst, _vm.supplementaryQuotes.map(function (q) {
    return q.totalExGst;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2), _vm.value.discount ? _c("tr", [_c("td", [_vm._v("Discount")]), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.discount, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v("- ")]);
  }), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.discount, _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.value.excess && _vm.value.excessWithGst ? _c("tr", [_c("td", [_vm._v("Excess")]), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.excess, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v("- ")]);
  }), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.excess, _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _c("tr", {
    staticClass: "has-border-bottom-4",
    class: ["summary-background-primary-".concat(_vm.$theme.name)]
  }, [_c("td", [_vm._v("GST "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(" + _vm._s(_vm.value.gstRate) + "%)")])]), _vm.showSupplementaryQuoteTotals ? [_c("td", {
    staticClass: "has-text-right"
  }, [_vm.mainQuoteTotalGst > 0 ? _c("span", [_vm._v("+")]) : _vm._e(), _vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.mainQuoteTotalGst, _vm.$userInfo.locale)))]), _vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" +" + _vm._s(_vm.$filters.formatCurrency(supp.totalExGst * supp.gstRate / 100, _vm.$userInfo.locale)) + " ")]);
  })] : _vm._e(), _c("td", {
    staticClass: "has-text-right"
  }, [_vm.invTotalExGst > 0 ? _c("span", [_vm._v("+")]) : _vm._e(), _vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.invTotalExGst * (_vm.value.gstRate / 100), _vm.$userInfo.locale)))])], 2), _vm.showInvAmtIncGst ? _c("tr", {
    class: "summary-background-text-".concat(_vm.$theme.name)
  }, [_vm._m(1), _vm.showSupplementaryQuoteTotals ? [_c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.mainQuoteTotalIncGst, _vm.$userInfo.locale)))]), _vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(supp.totalIncGst, _vm.$userInfo.locale)) + " ")]);
  })] : _vm._e(), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.invTotalExGst * (_vm.value.gstRate / 100 + 1), _vm.$userInfo.locale)))])], 2) : _vm._e(), _vm.value.ownersContribution ? _c("tr", [_vm._m(2), _vm.showSupplementaryQuoteTotals ? [_c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.ownersContribution * (_vm.value.gstRate / 100 + 1), _vm.$userInfo.locale)))]), _vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v("- ")]);
  })] : _vm._e(), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.ownersContribution * (_vm.value.gstRate / 100 + 1), _vm.$userInfo.locale)))])], 2) : _vm._e(), _vm.value.excess && !_vm.value.excessWithGst ? _c("tr", [_c("td", [_vm._v("Excess")]), _vm.showSupplementaryQuoteTotals ? [_c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.excess, _vm.$userInfo.locale)))]), _vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v("- ")]);
  })] : _vm._e(), _c("td", {
    staticClass: "has-text-right has-text-danger"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.value.excess, _vm.$userInfo.locale)))])], 2) : _vm._e(), _c("tr", {
    class: "summary-background-success-".concat(_vm.$theme.name)
  }, [_vm._m(3), _vm.showSupplementaryQuoteTotals ? [_c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.mainQuoteTotalPayable, _vm.$userInfo.locale)))]), _vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("th", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(supp.totalIncGst, _vm.$userInfo.locale)) + " ")]);
  })] : _vm._e(), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalPayableIncGst, _vm.$userInfo.locale)))])], 2)]) : _vm._e(), _vm.value.subQuoteNos.length === 1 || _vm.showSupplementaryQuoteTotals || _vm.value.subQuoteNo > 0 ? _c("tbody", {
    staticClass: "has-bottom-border-only no-border-last-row"
  }, [_vm.isEnabled(_vm.itemCategoryTypes.RR) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.RR)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.rrTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.rrTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.rrTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.rrTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.RWA) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.RWA)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.rwaTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.rwaTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.rwaTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.rwaTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.REP) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.REP)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.repairTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.repairTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.repairTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.repairTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.PAINT) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.PAINT)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.paintTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.paintTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.paintTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.paintTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.FIBER) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.FIBER)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.fgTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.fgTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.fgTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.fgTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.CRUSH) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.CRUSH)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.crushTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.crushTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.crushTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.crushTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.CD) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.CD)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.cdTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.cdTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.cdTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.cdTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.MECH) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.MECH)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.mechTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.mechTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.mechTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.mechTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.PART) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.PART)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.partTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.partTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.partTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.partTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.OPG) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.OPG)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.opgTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.opgTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.opgTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.opgTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.MISC) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.MISC)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.miscTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.miscTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.miscTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.miscTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e(), _vm.isEnabled(_vm.itemCategoryTypes.SUBL) ? _c("tr", [_c("td", [_vm._v(_vm._s(_vm.getDisplayName(_vm.itemCategoryTypes.SUBL)))]), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.value.sublTotal, _vm.$userInfo.locale)))]), _vm.showSupplementaryQuoteTotals ? [_vm._l(_vm.supplementaryQuotes, function (supp) {
    return _c("td", {
      key: supp.quoteId,
      staticClass: "has-text-right"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatNumber(supp.sublTotal, _vm.$userInfo.locale)) + " ")]);
  }), _c("td", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.calculateGrandTotal(_vm.value.sublTotal, _vm.supplementaryQuotes.map(function (q) {
    return q.sublTotal;
  })), _vm.$userInfo.locale)))])] : _vm._e()], 2) : _vm._e()]) : _vm._e()]), _vm.displayRemarks.length > 0 ? _c("div", [_vm.hasPinnedRemarks ? _c("label", {
    staticClass: "label"
  }, [_vm._v("Pinned Remarks")]) : _vm._e(), !_vm.hasPinnedRemarks ? _c("label", {
    staticClass: "label"
  }, [_vm._v("Recent Remarks")]) : _vm._e(), _vm.value.subQuoteNos.length === 1 || _vm.showSupplementaryQuoteTotals || _vm.value.subQuoteNo > 0 ? _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_c("thead"), _c("tbody", _vm._l(_vm.displayRemarks, function (remark) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "is-remark"
    }, [_c("div", [_vm._v(_vm._s(remark.remarks))])])]);
  }), 0)]) : _vm._e()]) : _vm._e()]) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("td", [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("td", [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("td", [_vm._v("Owner Cont. "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("th", [_vm._v("Total Payable "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "th.is-subtotal[data-v-df3ae0b4] {\n  width: 7em;\n}\n.subtext[data-v-df3ae0b4] {\n  font-size: 10px;\n}\n.no-border td[data-v-df3ae0b4],\n.no-border th[data-v-df3ae0b4] {\n  border: none;\n}\n.has-bottom-border-only td[data-v-df3ae0b4] {\n  border-top: none;\n  border-left: none;\n  border-right: none;\n}\n.no-border-last-row tr:last-child td[data-v-df3ae0b4] {\n  border: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("419e4f25", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteDetailSummary.vue":
/*!************************************************!*\
  !*** ./src/views/quote/QuoteDetailSummary.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true */ "./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true");
/* harmony import */ var _QuoteDetailSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteDetailSummary.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true */ "./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteDetailSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "df3ae0b4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteDetailSummary.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetailSummary.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=style&index=0&id=df3ae0b4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_style_index_0_id_df3ae0b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true":
/*!******************************************************************************************!*\
  !*** ./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteDetailSummary.vue?vue&type=template&id=df3ae0b4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteDetailSummary_vue_vue_type_template_id_df3ae0b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-detail-chunk~quote-summary-chunk.js.map