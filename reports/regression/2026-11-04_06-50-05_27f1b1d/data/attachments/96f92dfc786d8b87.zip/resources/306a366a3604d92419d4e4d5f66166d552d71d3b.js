(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-communications-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./columns */ "./src/components/Sms/columns.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _SmsService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./SmsService */ "./src/components/Sms/SmsService.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SmsMessageTemplates',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["UnsavedModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["ConfirmModal"]
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_12__["FocusInserted"]
  },
  props: {
    value: null,
    enableSave: false,
    active: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      isNew: false,
      isEdit: false,
      isDeleted: false,
      isBack: false,
      isClose: false,
      isEnableSave: false,
      isMessageEntered: true,
      isUnsavedModalActive: false,
      isConfirmModalActive: false,
      isEmpty: false,
      totalRows: 0,
      entitySummaries: {},
      entity: {
        id: '',
        message: ''
      },
      selected: {
        id: '',
        message: ''
      },
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 5
      },
      oriMsg: '',
      selectedRow: null,
      isTableLoading: false,
      smsMessage: ''
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"];
    }
  },
  created: function created() {
    this.smsMessage = '';
    this.getData();
    this.isEnableSave = this.enableSave;
  },
  methods: {
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _context.n = 1;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    enterMessage: function enterMessage() {
      this.isMessageEntered = this.smsMessage !== '';
      if (this.isMessageEntered) {
        this.isEnableSave = true;
      }
    },
    reset: function reset() {
      this.isNew = false;
      this.isDeleted = false;
      this.isEdit = false;
      this.isUnsavedModalActive = false;
      this.isConfirmModalActive = false;
      this.entity.id = '';
      this.entity.message = '';
      this.oriMsg = this.smsMessage = '';
      this.isEnableSave = false;
      this.$emit('save-button', false);
    },
    add: function add() {
      this.reset();
      this.selectedRow = '';
      this.isMessageEntered = false;
      this.isEnableSave = true;
      this.isNew = true;
    },
    back: function back() {
      if (this.oriMsg !== this.smsMessage) {
        this.isBack = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('back');
      }
    },
    close: function close() {
      if (this.oriMsg !== this.smsMessage) {
        this.isClose = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('close', true);
      }
    },
    editMessage: function editMessage(entity, index) {
      // add new -> edit message
      if (this.oriMsg !== this.smsMessage) {
        this.isEdit = true;
        this.isUnsavedModalActive = true;
        // edit message
      } else {
        this.isNew = false;
        this.isEdit = true;
        this.isEnableSave = true;
        this.entity.id = entity.id;
        this.entity.message = entity.message;
        this.oriMsg = entity.message;
        this.smsMessage = entity.message;
        this.smsMessage.FocusInserted;
        this.isMessageEntered = this.smsMessage !== '';
        this.isEnableSave = true;
        this.$emit('save-button', true);
      }
    },
    deleteMessage: function deleteMessage(id, index, msg) {
      this.isDeleted = true;
      if (!this.isEdit) {
        this.entity.id = id;
      }
      if (!this.isEdit && this.oriMsg !== this.smsMessage && this.entity.id !== this.selected.id) {
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
        this.isUnsavedModalActive = true;
      } else if (this.smsMessage != msg && this.smsMessage != '' && this.isNew) {
        this.isUnsavedModalActive = true;
        // } else if (this.isEdit && this.selected.id !== id) {
        // edit msg then delete on same msg or other msg
      } else if (this.isEdit && this.isDeleted && this.oriMsg !== this.smsMessage && this.entity.id !== id) {
        this.isUnsavedModalActive = true;
      } else {
        this.entity.id = id;
        this.entity.message = msg;
        this.isNew = false; // set to false when add new message is empty and then click on delete
        this.isEdit = false; // set to false when no change on edit message and then click on delete
        this.isConfirmModalActive = true;
      }
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!confirmDelete) {
                _context2.n = 5;
                break;
              }
              _context2.p = 1;
              _context2.n = 2;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].deleteEntity(_this2.selected.id);
            case 2:
              _this2.getData();
              _this2.isEnableSave = false;
              _this2.isMessageEntered = true;
              // for edit then edit same message and
              // for add new then highlight and delete other message
              if (!_this2.isNew && !_this2.isEdit && _this2.isDeleted || !_this2.isNew && !_this2.isEdit && _this2.entity.id == _this2.selected.id || !_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.reset();
              }
              _this2.selectedRow = '';
              _this2.$emit('save-button', false);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t.response.status);
              _this2.$notification.openMessageXhrError('SMS Message', _t);
              return _context2.a(2, false);
            case 4:
              _context2.n = 6;
              break;
            case 5:
              if (!_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.isConfirmModalActive = false;
                _this2.selectedRow = _this2.entitySummaries.indexOf(_this2.entitySummaries.find(function (i) {
                  return i.message === _this2.oriMsg;
                }));
              } else {
                _this2.reset();
                _this2.$emit('save-button', false);
              }
            case 6:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    cancel: function cancel() {
      this.reset();
      this.selectedRow = '';
    },
    saveSms: function saveSms() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!_this3.isNew) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _this3.save(true);
            case 1:
              _context3.n = 3;
              break;
            case 2:
              if (!_this3.isEdit) {
                _context3.n = 3;
                break;
              }
              _context3.n = 3;
              return _this3.save(false);
            case 3:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    save: function save(isNew) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var newMsg, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              newMsg = _this4.smsMessage;
              _this4.isEmpty = false;
              if (!(newMsg == '')) {
                _context4.n = 1;
                break;
              }
              _this4.isEmpty = true;
              _this4.$notification.openNotificationWithType('danger', 'SMS Message', 'Validation errors. Please fix before saving');
              return _context4.a(2, false);
            case 1:
              if (!(_this4.oriMsg == newMsg && _this4.entity.id == _this4.selected.id)) {
                _context4.n = 2;
                break;
              }
              _this4.$notification.openNotificationWithType('warning', 'SMS Message', 'No changes detected. Not saved');
              return _context4.a(2, false);
            case 2:
              _context4.p = 2;
              _this4.$showSpinner('Saving...');
              // add new message
              if (!isNew) {
                _context4.n = 5;
                break;
              }
              _this4.entity.id = 0;
              _this4.entity.message = newMsg;
              _context4.n = 3;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].postEntity(_this4.entity);
            case 3:
              _context4.n = 4;
              return _this4.getData();
            case 4:
              // wait to get latest order after add
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.message === newMsg;
              })); // get latest index for case NOT from save continue
              // edit message
              _context4.n = 8;
              break;
            case 5:
              _this4.entity.message = newMsg;
              _context4.n = 6;
              return _SmsService__WEBPACK_IMPORTED_MODULE_14__["default"].putEntity(_this4.entity);
            case 6:
              _context4.n = 7;
              return _this4.getData();
            case 7:
              // wait to get latest order after edit
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.id === _this4.selected.id;
              })); // get latest index for case NOT from save continue
            case 8:
              _this4.reset();
              _this4.$notification.success('SMS Message', 'Save successful');
              _this4.$emit('save-button', false);
              return _context4.a(2, true);
            case 9:
              _context4.p = 9;
              _t2 = _context4.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t2.response.status);
              _this4.$notification.openMessageXhrError('SMS Message', _t2);
              return _context4.a(2, false);
            case 10:
              _context4.p = 10;
              _this4.$hideSpinner();
              return _context4.f(10);
            case 11:
              return _context4.a(2);
          }
        }, _callee4, null, [[2, 9, 10, 11]]);
      }))();
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (!(_this5.isNew && _this5.isDeleted)) {
                _context5.n = 3;
                break;
              }
              _context5.n = 1;
              return _this5.deleteEntity(true);
            case 1:
              _context5.n = 2;
              return _this5.save(true);
            case 2:
              _this5.reset();
              _context5.n = 11;
              break;
            case 3:
              if (!(_this5.isEdit && _this5.isDeleted)) {
                _context5.n = 6;
                break;
              }
              _context5.n = 4;
              return _this5.deleteEntity(true);
            case 4:
              _context5.n = 5;
              return _this5.save(false);
            case 5:
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = false;
              _context5.n = 11;
              break;
            case 6:
              if (!(_this5.isNew && _this5.isEdit)) {
                _context5.n = 8;
                break;
              }
              _context5.n = 7;
              return _this5.save(true);
            case 7:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              _this5.smsMessage = _this5.selected.message;
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for case add new then edit, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 8:
              if (!(!_this5.isNew && _this5.isEdit)) {
                _context5.n = 10;
                break;
              }
              _context5.n = 9;
              return _this5.save(false);
            case 9:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              if (_this5.isEmpty) {
                _this5.smsMessage = '';
              } else {
                _this5.smsMessage = _this5.selected.message;
              }
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for edit then edit others, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 10:
              if (!(_this5.isNew && !_this5.isEdit && !_this5.Deleted)) {
                _context5.n = 11;
                break;
              }
              _context5.n = 11;
              return _this5.save(true);
            case 11:
              // isEmpty is to check if msg empty then it not allow back to SmsSend
              if (_this5.isBack && !_this5.isEmpty) {
                _this5.$emit('back');
              }
              if (_this5.isClose && !_this5.isEmpty) {
                _this5.$emit('close', true);
              }
            case 12:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    skipSave: function skipSave() {
      if (this.isBack) {
        this.$emit('back');
      } else if (this.isClose) {
        this.$emit('close', true);
      } else if (this.isDeleted) {
        this.deleteEntity(true);
        this.reset();
      } else if (this.isEdit) {
        this.isUnsavedModalActive = false;
        this.smsMessage = this.selected.message;
        this.smsMessage.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.smsMessage;
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
      } else if (this.isNew) {
        this.isUnsavedModalActive = false;
        this.smsMessage = this.selected.message;
        this.smsMessage.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.smsMessage;
      }
    },
    closeModal: function closeModal() {
      var _this6 = this;
      this.isDeleted = false;
      this.isBack = false;
      this.isClose = false;
      this.isUnsavedModalActive = false;
      if (this.isEnableSave) {
        this.smsMessage.FocusInserted;
        this.selectedRow = this.entitySummaries.indexOf(this.entitySummaries.find(function (i) {
          return i.id === _this6.entity.id;
        }));
      }
    },
    highlightSelected: function highlightSelected(entity, index, event) {
      this.selectedRow = index;
      this.selected = entity;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.getData();
    },
    insertTag: function insertTag(myValue) {
      var myField = document.getElementById('smsMessage');
      if (document.selection) {
        myField.focus();
        var sel = document.selection.createRange();
        sel.text = myValue;
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
      } else {
        myField.value += myValue;
      }
      this.smsMessage = myField.value;
      this.enterMessage();
      myField.focus();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _SmsMessageTemplates__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SmsMessageTemplates */ "./src/components/Sms/SmsMessageTemplates.vue");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SmsTemplateModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__["BaseModalEx"],
    SmsMessageTemplates: _SmsMessageTemplates__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    },
    iconName: {
      type: String,
      default: 'mdi-message-text'
    }
  },
  data: function data() {
    return {
      isActive: false,
      enableSave: false
    };
  },
  computed: {},
  created: function created() {},
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    edit: function edit() {},
    send: function send() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.$emit('update:active', false);
              _this.$emit('cancel');
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    add: function add() {
      this.$refs.smsMessageTemplates.add();
      this.enableSave = true;
    },
    close: function close() {
      this.$emit('update:active', false);
      this.$emit('close');
      this.isActive = false;
    },
    cancel: function cancel() {
      this.$refs.smsMessageTemplates.cancel();
    },
    setEnableSave: function setEnableSave(value) {
      this.enableSave = value;
    },
    save: function save() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _this2.$refs.smsMessageTemplates.saveSms();
            case 1:
              _this2.$emit('update:active', false);
              _this2.$emit('close');
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./columns */ "./src/components/VueEmail/columns.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _EmailService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./EmailService */ "./src/components/VueEmail/EmailService.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VueEmailMessageTemplates',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_9__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["UnsavedModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["ConfirmModal"]
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_12__["FocusInserted"]
  },
  props: {
    value: null,
    enableSave: false,
    active: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      isNew: false,
      isEdit: false,
      isDeleted: false,
      isBack: false,
      isClose: false,
      isEnableSave: false,
      isMessageEntered: true,
      isUnsavedModalActive: false,
      isConfirmModalActive: false,
      isEmpty: false,
      totalRows: 0,
      entitySummaries: {},
      entity: {
        id: '',
        message: ''
      },
      selected: {
        id: '',
        message: ''
      },
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 5
      },
      oriMsg: '',
      selectedRow: null,
      isTableLoading: false,
      message: ''
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_11__["Columns"];
    }
  },
  created: function created() {
    this.message = '';
    this.getData();
    this.isEnableSave = this.enableSave;
  },
  methods: {
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var prevIndex;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _context.n = 1;
              return _EmailService__WEBPACK_IMPORTED_MODULE_14__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              if (!_this.entitySummaries.length && _this.filter.pageIndex > 1) {
                prevIndex = _this.filter.pageIndex - 1;
                _this.onPageChange(prevIndex);
              }
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    enterMessage: function enterMessage() {
      this.isMessageEntered = this.message !== '';
      if (this.isMessageEntered) {
        this.isEnableSave = true;
      }
    },
    reset: function reset() {
      this.isNew = false;
      this.isDeleted = false;
      this.isEdit = false;
      this.isUnsavedModalActive = false;
      this.isConfirmModalActive = false;
      this.entity.id = '';
      this.entity.message = '';
      this.oriMsg = this.message = '';
      this.isEnableSave = false;
      this.$emit('save-button', false);
    },
    add: function add() {
      this.reset();
      this.selectedRow = '';
      this.isMessageEntered = false;
      this.isEnableSave = true;
      this.isNew = true;
    },
    back: function back() {
      if (this.oriMsg !== this.message) {
        this.isBack = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('back');
      }
    },
    close: function close() {
      if (this.oriMsg !== this.message) {
        this.isClose = true;
        this.isUnsavedModalActive = true;
      } else {
        this.$emit('close', true);
      }
    },
    editMessage: function editMessage(entity, index) {
      // add new -> edit message
      if (this.oriMsg !== this.message) {
        this.isEdit = true;
        this.isUnsavedModalActive = true;
        // edit message
      } else {
        this.isNew = false;
        this.isEdit = true;
        this.isEnableSave = true;
        this.entity.id = entity.id;
        this.entity.message = entity.message;
        this.oriMsg = entity.message;
        this.message = entity.message;
        this.message.FocusInserted;
        this.isMessageEntered = this.message !== '';
        this.isEnableSave = true;
        this.$emit('save-button', true);
      }
    },
    deleteMessage: function deleteMessage(id, index, msg) {
      this.isDeleted = true;
      if (!this.isEdit) {
        this.entity.id = id;
      }
      if (!this.isEdit && this.oriMsg !== this.message && this.entity.id !== this.selected.id) {
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
        this.isUnsavedModalActive = true;
      } else if (this.message != msg && this.message != '' && this.isNew) {
        this.isUnsavedModalActive = true;
        // } else if (this.isEdit && this.selected.id !== id) {
        // edit msg then delete on same msg or other msg
      } else if (this.isEdit && this.isDeleted && this.oriMsg !== this.message && this.entity.id !== id) {
        this.isUnsavedModalActive = true;
      } else {
        this.entity.id = id;
        this.entity.message = msg;
        this.isNew = false; // set to false when add new message is empty and then click on delete
        this.isEdit = false; // set to false when no change on edit message and then click on delete
        this.isConfirmModalActive = true;
      }
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!confirmDelete) {
                _context2.n = 5;
                break;
              }
              _context2.p = 1;
              _context2.n = 2;
              return _EmailService__WEBPACK_IMPORTED_MODULE_14__["default"].deleteEntity(_this2.selected.id);
            case 2:
              _this2.getData();
              _this2.isEnableSave = false;
              _this2.isMessageEntered = true;
              // for edit then edit same message and
              // for add new then highlight and delete other message
              if (!_this2.isNew && !_this2.isEdit && _this2.isDeleted || !_this2.isNew && !_this2.isEdit && _this2.entity.id == _this2.selected.id || !_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.reset();
              }
              _this2.selectedRow = '';
              _this2.$emit('save-button', false);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t.response.status);
              _this2.$notification.openMessageXhrError('Email Message', _t);
              return _context2.a(2, false);
            case 4:
              _context2.n = 6;
              break;
            case 5:
              if (!_this2.isNew && _this2.isEdit && _this2.entity.id == _this2.selected.id) {
                _this2.isConfirmModalActive = false;
                _this2.selectedRow = _this2.entitySummaries.indexOf(_this2.entitySummaries.find(function (i) {
                  return i.message === _this2.oriMsg;
                }));
              } else {
                _this2.reset();
                _this2.$emit('save-button', false);
              }
            case 6:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    cancel: function cancel() {
      this.reset();
      this.selectedRow = '';
    },
    saveEmail: function saveEmail() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!_this3.isNew) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _this3.save(true);
            case 1:
              _context3.n = 3;
              break;
            case 2:
              if (!_this3.isEdit) {
                _context3.n = 3;
                break;
              }
              _context3.n = 3;
              return _this3.save(false);
            case 3:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    save: function save(isNew) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var newMsg, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              newMsg = _this4.message;
              _this4.isEmpty = false;
              if (!(newMsg == '')) {
                _context4.n = 1;
                break;
              }
              _this4.isEmpty = true;
              _this4.$notification.openNotificationWithType('danger', 'Email Message', 'Validation errors. Please fix before saving');
              return _context4.a(2, false);
            case 1:
              if (!(_this4.oriMsg == newMsg && _this4.entity.id == _this4.selected.id)) {
                _context4.n = 2;
                break;
              }
              _this4.$notification.openNotificationWithType('warning', 'Email Message', 'No changes detected. Not saved');
              return _context4.a(2, false);
            case 2:
              _context4.p = 2;
              _this4.$showSpinner('Saving...');
              // add new message
              if (!isNew) {
                _context4.n = 5;
                break;
              }
              _this4.entity.id = 0;
              _this4.entity.message = newMsg;
              _context4.n = 3;
              return _EmailService__WEBPACK_IMPORTED_MODULE_14__["default"].postEntity(_this4.entity);
            case 3:
              _context4.n = 4;
              return _this4.getData();
            case 4:
              // wait to get latest order after add
              //console.log('save')
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.message === newMsg;
              })); // get latest index for case NOT from save continue
              // edit message
              _context4.n = 8;
              break;
            case 5:
              _this4.entity.message = newMsg;
              _context4.n = 6;
              return _EmailService__WEBPACK_IMPORTED_MODULE_14__["default"].putEntity(_this4.entity);
            case 6:
              _context4.n = 7;
              return _this4.getData();
            case 7:
              // wait to get latest order after edit
              _this4.selectedRow = _this4.entitySummaries.indexOf(_this4.entitySummaries.find(function (i) {
                return i.id === _this4.selected.id;
              })); // get latest index for case NOT from save continue
            case 8:
              //console.log('save done')
              _this4.reset();
              _this4.$notification.success('Email Message', 'Save successful');
              _this4.$emit('save-button', false);
              return _context4.a(2, true);
            case 9:
              _context4.p = 9;
              _t2 = _context4.v;
              if (_t2 && _t2.response && _t2.response.status) {
                _components_EventBus__WEBPACK_IMPORTED_MODULE_13__["default"].$emit('serviceError', _t2.response.status);
                _this4.$notification.openMessageXhrError('Email Message', _t2);
              }
              return _context4.a(2, false);
            case 10:
              _context4.p = 10;
              _this4.$hideSpinner();
              return _context4.f(10);
            case 11:
              return _context4.a(2);
          }
        }, _callee4, null, [[2, 9, 10, 11]]);
      }))();
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (!(_this5.isNew && _this5.isDeleted)) {
                _context5.n = 3;
                break;
              }
              _context5.n = 1;
              return _this5.deleteEntity(true);
            case 1:
              _context5.n = 2;
              return _this5.save(true);
            case 2:
              _this5.reset();
              _context5.n = 11;
              break;
            case 3:
              if (!(_this5.isEdit && _this5.isDeleted)) {
                _context5.n = 6;
                break;
              }
              _context5.n = 4;
              return _this5.deleteEntity(true);
            case 4:
              _context5.n = 5;
              return _this5.save(false);
            case 5:
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = false;
              _context5.n = 11;
              break;
            case 6:
              if (!(_this5.isNew && _this5.isEdit)) {
                _context5.n = 8;
                break;
              }
              _context5.n = 7;
              return _this5.save(true);
            case 7:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              _this5.message = _this5.selected.message;
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for case add new then edit, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 8:
              if (!(!_this5.isNew && _this5.isEdit)) {
                _context5.n = 10;
                break;
              }
              _context5.n = 9;
              return _this5.save(false);
            case 9:
              _this5.isEdit = true; // isEdit has been set to false after save. Re-set to true for edit on selected msg
              _this5.oriMsg = _this5.selected.message;
              _this5.entity.id = _this5.selected.id;
              _this5.entity.message = _this5.selected.message;
              if (_this5.isEmpty) {
                _this5.message = '';
              } else {
                _this5.message = _this5.selected.message;
              }
              _this5.selectedRow = _this5.entitySummaries.indexOf(_this5.entitySummaries.find(function (i) {
                return i.id === _this5.selected.id;
              })); // for edit then edit others, get latest index after insert
              _this5.isUnsavedModalActive = false;
              _this5.isEnableSave = true;
              _this5.$emit('save-button', true);
              _context5.n = 11;
              break;
            case 10:
              if (!(_this5.isNew && !_this5.isEdit && !_this5.Deleted)) {
                _context5.n = 11;
                break;
              }
              _context5.n = 11;
              return _this5.save(true);
            case 11:
              // isEmpty is to check if msg empty then it not allow back to MessageSend
              if (_this5.isBack && !_this5.isEmpty) {
                _this5.$emit('back');
              }
              if (_this5.isClose && !_this5.isEmpty) {
                _this5.$emit('close', true);
              }
            case 12:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    skipSave: function skipSave() {
      if (this.isBack) {
        this.$emit('back');
      } else if (this.isClose) {
        this.$emit('close', true);
      } else if (this.isDeleted) {
        this.deleteEntity(true);
        this.reset();
      } else if (this.isEdit) {
        this.isUnsavedModalActive = false;
        this.message = this.selected.message;
        this.message.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.message;
        this.entity.id = this.selected.id;
        this.entity.message = this.selected.message;
      } else if (this.isNew) {
        this.isUnsavedModalActive = false;
        this.message = this.selected.message;
        this.message.FocusInserted;
        this.isNew = false;
        this.isEdit = true;
        this.oriMsg = this.message;
      }
    },
    closeModal: function closeModal() {
      var _this6 = this;
      this.isDeleted = false;
      this.isBack = false;
      this.isClose = false;
      this.isUnsavedModalActive = false;
      if (this.isEnableSave) {
        this.message.FocusInserted;
        this.selectedRow = this.entitySummaries.indexOf(this.entitySummaries.find(function (i) {
          return i.id === _this6.entity.id;
        }));
      }
    },
    highlightSelected: function highlightSelected(entity, index, event) {
      this.selectedRow = index;
      this.selected = entity;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.getData();
    },
    insertTag: function insertTag(myValue) {
      var myField = document.getElementById('message');
      if (document.selection) {
        myField.focus();
        var sel = document.selection.createRange();
        sel.text = myValue;
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
      } else {
        myField.value += myValue;
      }
      this.message = myField.value;
      this.enterMessage();
      myField.focus();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _VueEmailMessageTemplates__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./VueEmailMessageTemplates */ "./src/components/VueEmail/VueEmailMessageTemplates.vue");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VueEmailTemplateModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__["BaseModalEx"],
    VueEmailMessageTemplates: _VueEmailMessageTemplates__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    },
    iconName: {
      type: String,
      default: 'mdi-message-text'
    }
  },
  data: function data() {
    return {
      isActive: false,
      enableSave: false
    };
  },
  computed: {},
  created: function created() {},
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    edit: function edit() {},
    send: function send() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.$emit('update:active', false);
              _this.$emit('cancel');
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    add: function add() {
      this.$refs.emailMessageTemplates.add();
      this.enableSave = true;
    },
    close: function close() {
      this.$emit('update:active', false);
      this.$emit('close');
      this.isActive = false;
    },
    cancel: function cancel() {
      this.$refs.emailMessageTemplates.cancel();
    },
    setEnableSave: function setEnableSave(value) {
      this.enableSave = value;
    },
    save: function save() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _this2.$refs.emailMessageTemplates.saveEmail();
            case 1:
              //console.log('save complete')
              _this2.$emit('update:active', false);
              _this2.$emit('close');
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Sms_SmsTemplateModal__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/Sms/SmsTemplateModal */ "./src/components/Sms/SmsTemplateModal.vue");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _utils_StringFunctions__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/utils/StringFunctions */ "./src/utils/StringFunctions.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./mixins/QuoteCommunicationsMixin */ "./src/views/quote/mixins/QuoteCommunicationsMixin.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _components_QuoteEmail_vue__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./components/QuoteEmail.vue */ "./src/views/quote/components/QuoteEmail.vue");
/* harmony import */ var _components_QuoteEmailViewerModal_vue__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./components/QuoteEmailViewerModal.vue */ "./src/views/quote/components/QuoteEmailViewerModal.vue");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_QuoteHeader_PhoneNoAutocomplete_vue__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./components/QuoteHeader/PhoneNoAutocomplete.vue */ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue");
































// import { VueEmail } from '@/components/VueEmail'
// import mimeTypes from 'mime-types'
// import { Emailer } from '@/classes'
// import StoreUtil from '@/store/utils'



var _createNamespacedHelp = Object(vuex__WEBPACK_IMPORTED_MODULE_33__["createNamespacedHelpers"])('quoteContentCounts'),
  mapGetters = _createNamespacedHelp.mapGetters,
  mapActions = _createNamespacedHelp.mapActions;
// import { QuoteImage } from '../components/QuoteImage'





// Temporary const for copyright message
// const divider = '=============================================================='
// const copyright =
//   'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteCommunications',
  // components: { Multiselect, SmsTemplateModal, VueEmail, QuoteEmail },
  components: {
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_24___default.a,
    SmsTemplateModal: _components_Sms_SmsTemplateModal__WEBPACK_IMPORTED_MODULE_28__["default"],
    QuoteEmailViewerModal: _components_QuoteEmailViewerModal_vue__WEBPACK_IMPORTED_MODULE_35__["default"],
    QuoteEmail: _components_QuoteEmail_vue__WEBPACK_IMPORTED_MODULE_34__["default"],
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_36__["BaseModalEx"],
    PhoneNoAutocomplete: _components_QuoteHeader_PhoneNoAutocomplete_vue__WEBPACK_IMPORTED_MODULE_37__["default"]
  },
  //QuoteEmailViewerModal,
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_25__["FocusInserted"]
  },
  mixins: [_mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_32__["default"]],
  props: {
    value: {
      type: Object,
      default: null
    },
    customer: {
      type: Object,
      default: null
    },
    vehicle: {
      type: Object,
      default: null
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    return {
      entity: null,
      phoneNoMask: Array(31).join('P'),
      phoneNoTokens: {
        P: {
          pattern: /[0-9 ()\-+]/
        }
      },
      msgDetails: {
        quoteId: null,
        customer: null,
        rego: null,
        jobStart: null,
        jobEnd: null,
        excess: null,
        mobile: null,
        message: '',
        shopName: '',
        imgLink: '',
        // Email specific fields
        emailTo: '',
        emailSubject: '',
        emailCc: '',
        emailBcc: ''
      },
      smsDetails: new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__["SmsSendMessageModel"](),
      isTemplateLoading: false,
      isMessagesLoading: false,
      templates: [],
      messages: [],
      selectedTemplate: '',
      templateFilter: {
        message: '',
        pageIndex: 1,
        pageSize: 999
      },
      isSmsTemplateModalActive: false,
      interval: null,
      markAsReadTimer: null,
      activeTab: _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].SMS,
      maxLength: 0,
      isShowWhatsApp: false,
      approvedTemplate: '',
      replyToMessageId: '',
      replyToSender: '',
      replyToContent: '',
      replyToEmail: {},
      selectedAttachmentEmailId: '',
      isIncoming: null,
      editMaximize: false,
      isViewEmail: false,
      viewMessage: {},
      isMessageModalActive: false,
      messageModalMessage: '',
      isEmailerActive: true,
      // isEmailModalActive: false,
      // isImageAttachActive: false,
      // emailer: {
      //   reportName: null
      // },
      // reportBytes: null,
      // reportContentType: '',
      // selectedImages: [],
      // quoteIds: []
      selectedPhone: null,
      groupedOptions: [],
      loading: false
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, mapGetters(['smsUnreadCount', 'whatsAppUnreadCount', 'emailUnreadCount', 'smsTotalCount', 'whatsAppTotalCount', 'emailTotalCount'])), {}, {
    isDisabledSend: function isDisabledSend() {
      var disabled = !this.msgDetails.message || !this.msgDetails.mobile || this.isEmptyString(this.msgDetails.mobile) || !this.validateNumber(this.msgDetails.mobile);
      return disabled;
    },
    communicationTypes: function communicationTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"];
    },
    isSMS: function isSMS() {
      return this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].SMS;
    },
    isWhatsApp: function isWhatsApp() {
      return this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].WhatsApp;
    },
    isEmail: function isEmail() {
      return this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].Email;
    }

    //reportExtension() {
    //  return mimeTypes.extension(this.reportContentType)
    //}
  }),
  watch: {
    isEmail: function isEmail(value) {
      //this.isEmailModalActive = value
      if (!value) {
        this.replyToMessageId = '';
      }
    },
    'msgDetails.message': function msgDetailsMessage(newValue, oldValue) {
      // Scroll to bottom when user starts typing (only if content is being added)
      if (newValue && newValue.length > (oldValue || '').length) {
        this.scrollToBottom();
      }
    },
    // Watch id (not the object) so autosave reassigning customer doesn't clobber autocomplete edits.
    'customer.id': {
      handler: function handler() {
        if (!this.customer || !this.customer.phones) return;
        var mobile = this.customer.phones.find(function (p) {
          return p.type === _enums__WEBPACK_IMPORTED_MODULE_27__["PhoneTypes"].Mobile.toString();
        });
        this.msgDetails.mobile = mobile ? mobile.no : '';
      },
      immediate: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.getEntity();
            _this.setParams();
            _context.n = 1;
            return _this.getSettings();
          case 1:
            _this.getSmsMessageDropdown();
            _this.autoRefresh();
            _this.getMessages();
            _this.getMaxLength();
            //this.clearSessionStorage()
            _this.assignMessageDetails(_this.msgDetails);
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    var _this2 = this;
    // Scroll message log to bottom on mount
    this.$nextTick(function () {
      _this2.scrollToBottom(true); // Force scroll on initial mount
    });
  },
  updated: function updated() {
    var unreadCount = this.messages.reduce(function (acc, cur) {
      return !cur.isRead ? ++acc : acc;
    }, 0);
    if (unreadCount) {
      this.scrollToBottom(true); // Force scroll when there are unread messages
    }
  },
  beforeDestroy: function beforeDestroy() {
    clearInterval(this.interval);
    // Otherwise a pending timer fires after the user has navigated away, marking messages
    // read that were never on screen and emitting into a torn-down component.
    this.clearMarkAsReadTimer();
  },
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, mapActions({
    refreshContentCounts: 'refresh',
    markContentRead: 'markRead'
  })), {}, {
    validateNumber: function validateNumber(phoneNo) {
      var regex = /^[0-9]*$/;
      phoneNo = phoneNo.replace(/\s+/g, '');
      return regex.test(phoneNo);
    },
    onPhoneNoSelected: function onPhoneNoSelected(option) {
      if (!option || option.isGroupHeader) {
        return;
      } else {
        this.msgDetails.mobile = String(option.phoneNo || '').replace(/\s+/g, '');
      }
      // Handle selection
    },
    getEntity: function getEntity() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (_this3.currentSnapshot) {
                _context2.n = 1;
                break;
              }
              _context2.n = 1;
              return _this3.getStoreItem(_this3.$route.params.quoteId);
            case 1:
              _this3.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default()(_this3.currentSnapshot);
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getMessages: function getMessages() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              _this4.isMessagesLoading = true;
              _context3.p = 1;
              if (!_this4.isSMS) {
                _context3.n = 3;
                break;
              }
              _context3.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_26__["SmsService"].getMessages(_this4.value.quoteId);
            case 2:
              _this4.messages = _context3.v;
              _context3.n = 7;
              break;
            case 3:
              if (!_this4.isWhatsApp) {
                _context3.n = 5;
                break;
              }
              _context3.n = 4;
              return _services__WEBPACK_IMPORTED_MODULE_26__["WhatsAppService"].getMessages(_this4.value.quoteId);
            case 4:
              _this4.messages = _context3.v;
              _context3.n = 7;
              break;
            case 5:
              if (!_this4.isEmail) {
                _context3.n = 7;
                break;
              }
              _context3.n = 6;
              return _services__WEBPACK_IMPORTED_MODULE_26__["EmailService"].getMessages(_this4.value.quoteId);
            case 6:
              _this4.messages = _context3.v;
            case 7:
              _this4.setMessagesAsRead();
            case 8:
              _context3.p = 8;
              _this4.isMessagesLoading = false;
              // Scroll to bottom after messages are loaded
              _this4.$nextTick(function () {
                _this4.scrollToBottom(true); // Force scroll for data loading
              });
              return _context3.f(8);
            case 9:
              return _context3.a(2);
          }
        }, _callee3, null, [[1,, 8, 9]]);
      }))();
    },
    assignMessageDetails: function assignMessageDetails(message) {
      var jobStart = this.value.jobStart ? new Date(this.value.jobStart).toLocaleDateString(this.$userInfo.locale) : 'DD/MM/YYYY';
      var jobEnd = this.value.jobEnd ? new Date(this.value.jobEnd).toLocaleDateString(this.$userInfo.locale) : 'DD/MM/YYYY';
      message.quoteId = this.value.quoteId;
      message.customer = this.customer.firstname ? this.customer.firstname : this.customer.fullname;
      message.rego = this.vehicle.rego;
      message.jobStart = jobStart;
      message.jobEnd = jobEnd;
      message.excess = this.value.excessWithGst ? this.value.excess + Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_29__["roundAwayFromZero"])(this.value.excess * this.value.gstRate / 100) : this.value.excess;
      message.shopName = this.$userInfo.companyName;
    },
    send: function send() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var type, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              _this5.$showSpinner('Sending...');
              _this5.assignMessageDetails(_this5.msgDetails);
              type = _this5.activeTab;
              _context4.p = 1;
              if (!_this5.isSMS) {
                _context4.n = 3;
                break;
              }
              _context4.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_26__["SmsService"].sendSms(_this5.msgDetails);
            case 2:
              _context4.n = 4;
              break;
            case 3:
              if (!_this5.isWhatsApp) {
                _context4.n = 4;
                break;
              }
              _context4.n = 4;
              return _services__WEBPACK_IMPORTED_MODULE_26__["WhatsAppService"].sendWhatsApp(_this5.msgDetails);
            case 4:
              _this5.$notification.openNotificationWithType('success', "Send ".concat(type), 'Message Sent');
              //if (this.isSMS) this.smsDetails.message = ''
              _this5.msgDetails.message = '';
              _this5.selectedTemplate = '';
              _context4.n = 6;
              break;
            case 5:
              _context4.p = 5;
              _t = _context4.v;
              _this5.$notification.openMessageXhrError("Send ".concat(type), _t);
            case 6:
              _context4.p = 6;
              _context4.n = 7;
              return _this5.getMessages();
            case 7:
              _context4.n = 8;
              return _this5.refreshContentCounts();
            case 8:
              _this5.$hideSpinner();
              return _context4.f(6);
            case 9:
              return _context4.a(2);
          }
        }, _callee4, null, [[1, 5, 6, 9]]);
      }))();
    },
    getSmsMessageDropdown: function getSmsMessageDropdown() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this6.isTemplateLoading = true;
              _context5.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_26__["SmsService"].getSmsMessageDropdownProto(_this6.templateFilter);
            case 1:
              _this6.templates = _context5.v;
              if (_this6.templateFilter.message !== '') {
                _this6.selectedTemplate = _this6.templates.find(function (c) {
                  return c.message === _this6.templateFilter.message;
                });
              }
              _this6.isTemplateLoading = false;
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    selectTemplate: function selectTemplate(selected) {
      this.templateFilter.message = selected.message;
      this.msgDetails.message = selected.message; //this.smsDetails.message = selected.message
    },
    closeSmsTemplateModal: function closeSmsTemplateModal() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this7.isSmsTemplateModalActive = false;
              _this7.resetTemplateFilter();
              _context6.n = 1;
              return _this7.getSmsMessageDropdown();
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    autoRefresh: function autoRefresh() {
      var _this8 = this;
      // Only the message list. The sub-tab counts come from the quoteContentCounts
      // store, which the task bar polls once for the whole quote.
      this.interval = setInterval(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _context7.n = 1;
              return _this8.getMessages();
            case 1:
              return _context7.a(2);
          }
        }, _callee7);
      })), 30000);
    },
    stopAutoRefresh: function stopAutoRefresh() {
      clearInterval(this.interval);
    },
    setMessagesAsRead: function setMessagesAsRead() {
      var _this9 = this;
      // Only ever one pending timer. getMessages() runs on every tab switch, so without
      // this a few quick switches would leave several overlapping timers running.
      this.clearMarkAsReadTimer();
      var unread = this.messages.filter(function (m) {
        return !m.isRead;
      });
      if (!unread || unread.length === 0) return;

      // Captured now rather than read inside the callback: the user can switch tab during
      // the ten seconds, and `this.activeTab` would then name the channel they moved to,
      // marking that one read instead of the one they were actually looking at.
      var channel = this.activeTab;
      this.markAsReadTimer = setTimeout(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        var _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.p = _context8.n) {
            case 0:
              _this9.markAsReadTimer = null;
              _context8.p = 1;
              if (!(channel === _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].SMS)) {
                _context8.n = 3;
                break;
              }
              _context8.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_26__["SmsService"].setMessagesAsRead(_this9.value.quoteId);
            case 2:
              _this9.markContentRead('sms');
              _context8.n = 7;
              break;
            case 3:
              if (!(channel === _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].WhatsApp)) {
                _context8.n = 5;
                break;
              }
              _context8.n = 4;
              return _services__WEBPACK_IMPORTED_MODULE_26__["WhatsAppService"].setMessagesAsRead(_this9.value.quoteId);
            case 4:
              _this9.markContentRead('whatsApp');
              _context8.n = 7;
              break;
            case 5:
              if (!(channel === _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].Email)) {
                _context8.n = 7;
                break;
              }
              _context8.n = 6;
              return _services__WEBPACK_IMPORTED_MODULE_26__["EmailService"].setMessagesAsRead(_this9.value.quoteId);
            case 6:
              _this9.markContentRead('email');
            case 7:
              _context8.n = 9;
              break;
            case 8:
              _context8.p = 8;
              _t2 = _context8.v;
              // The 30s refresh re-reads the true counts, so a failure here self-corrects.
              console.error(_t2);
              return _context8.a(2);
            case 9:
              // Only the messages still on screen for that channel - if the user has since
              // switched tab, this.messages belongs to a different channel.
              if (_this9.activeTab === channel) {
                _this9.messages.forEach(function (m) {
                  return m.isRead = true;
                });
              }

              // The store already knows, from markContentRead above. This is for anything
              // else listening - the counts are held per channel, so the event names which
              // one was cleared rather than reporting the tab as read.
              _this9.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_27__["EventHubTypes"].CommsRead, channel);
            case 10:
              return _context8.a(2);
          }
        }, _callee8, null, [[1, 8]]);
      })), 10000);
    },
    clearMarkAsReadTimer: function clearMarkAsReadTimer() {
      if (this.markAsReadTimer) {
        clearTimeout(this.markAsReadTimer);
        this.markAsReadTimer = null;
      }
    },
    setActiveTab: function setActiveTab(tab) {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _this0.activeTab = tab;
              _context9.n = 1;
              return _this0.getMessages();
            case 1:
              _this0.getMaxLength();
              _this0.resetMsgLength();

              // Clear email-specific fields when switching away from email
              if (tab !== _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].Email) {
                _this0.msgDetails.emailTo = '';
                _this0.msgDetails.emailCc = '';
                _this0.msgDetails.emailBcc = '';
                _this0.msgDetails.emailSubject = '';
                _this0.msgDetails.message = ''; // Clear message content when switching away from email
              }

              // Scroll to bottom after tab switch and messages load
              _this0.$nextTick(function () {
                _this0.scrollToBottom(true); // Force scroll for tab switching
              });
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    getToolTip: function getToolTip() {
      if (this.$licenceExpired) {
        return 'Disabled, as your licence has expired';
      }
      return "Send ".concat(this.activeTab);
    },
    getMaxLength: function getMaxLength() {
      this.maxLength = this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].SMS ? 2000 : this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].WhatsApp ? 2000 : this.activeTab == _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].Email ? 2000 : 0;
    },
    resetMsgLength: function resetMsgLength() {
      this.msgDetails.message = this.msgDetails.message.slice(0, this.maxLength);
    },
    setParams: function setParams() {
      var type = this.$route.params.type;
      if (type) {
        if (type == _enums__WEBPACK_IMPORTED_MODULE_27__["NotificationType"].QuoteSmsIncoming) this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].SMS;else if (type == _enums__WEBPACK_IMPORTED_MODULE_27__["NotificationType"].QuoteWhatsAppIncoming) this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].WhatsApp;else if (type == _enums__WEBPACK_IMPORTED_MODULE_27__["NotificationType"].QuoteEmailIncoming) this.activeTab = _enums__WEBPACK_IMPORTED_MODULE_27__["CommunicationTypes"].Email;
      }
    },
    getSettings: function getSettings() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee0() {
        var setting;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              _context0.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_26__["WhatsAppService"].getCompanyExternalSetting();
            case 1:
              setting = _context0.v;
              if (setting) {
                _this1.isShowWhatsApp = setting.active == '1';
                _this1.approvedTemplate = setting.approvedTemplate;
              }
            case 2:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    truncate: function truncate(str, max) {
      return this.isEmail ? Object(_utils_StringFunctions__WEBPACK_IMPORTED_MODULE_30__["truncate"])(str, max) : str;
    },
    replyTo: function replyTo(message) {
      // .messageId, message.isIncoming ? message.sender : message.recipients, message.message
      var isCancelReply = this.replyToMessageId === message.messageId;
      this.replyToMessageId = isCancelReply ? '' : message.messageId;
      // this.replyToSender = isCancelReply ? '' : message.isIncoming ? message.sender : message.recipients
      this.replyToEmail = isCancelReply ? {} : message;
      // this.replyToContent = isCancelReply ? '' : message
    },
    sent: function sent() {},
    isSelectedReplyToMessage: function isSelectedReplyToMessage(messageId) {
      if (!this.replyToMessageId) return false;
      return this.replyToMessageId === messageId;
    },
    messageBodyStyle: function messageBodyStyle(message) {
      if (this.isSelectedReplyToMessage(message.messageId)) return 'is-warning';else if (message.isOutgoing) return 'is-info';else if (message.isIncoming) return 'is-success';else return '';
    },
    openAttachmentModel: function openAttachmentModel(messageId, isIncoming) {
      this.selectedAttachmentEmailId = messageId;
      this.isIncoming = isIncoming;
    },
    closeAttachmentModel: function closeAttachmentModel() {
      this.selectedAttachmentEmailId = '';
      this.isIncoming = null;
    },
    toggleEditMaximize: function toggleEditMaximize() {
      this.editMaximize = !this.editMaximize;
    },
    updateAttachment: function updateAttachment() {
      this.$emit('image-uploaded');
    },
    viewEmail: function viewEmail(message) {
      this.viewMessage = message;
      this.isViewEmail = !this.isViewEmail;
      //console.log(this.isViewEmail)
    },
    closeViewEmail: function closeViewEmail() {
      this.viewMessage = {};
      this.isViewEmail = !this.isViewEmail;
      this.resetTemplateFilter();
      this.getSmsMessageDropdown();
      //console.log(this.isViewEmail)
    },
    // Single source of truth for an outgoing email's status. Every status getter
    // below derives from this one so they cannot disagree with each other.
    //
    // A single EmailOutgoing row can legitimately carry BOTH deliveredAt and
    // failedAt: Mailgun raises an event per recipient against the one row, and a
    // temporary failure can later be retried into a success. The later of the two
    // events is therefore the current truth. Equal timestamps resolve to 'failed'
    // (Mailgun timestamps are second-resolution, so surface the problem).
    emailStatus: function emailStatus(message) {
      var delivered = message.deliveredAt ? new Date(message.deliveredAt).getTime() : null;
      var failed = message.failedAt ? new Date(message.failedAt).getTime() : null;
      if (delivered && failed) return failed >= delivered ? 'failed' : 'delivered';
      if (failed) return 'failed';
      if (delivered) return 'delivered';
      return 'sent';
    },
    // A failure the user may want to read, even where a later retry delivered it.
    // Guards the reason modal: the webhook sets FailedOn before it resolves the
    // failure text, so failedMessage can be null while failedAt is set.
    hasFailureDetail: function hasFailureDetail(message) {
      return !!message.failedAt && !!message.failedMessage;
    },
    getEmailStatusIndicator: function getEmailStatusIndicator(message) {
      switch (this.emailStatus(message)) {
        case 'failed':
          return 'mdi-alert-circle has-text-danger';
        case 'delivered':
          return 'mdi-check-all';
        default:
          return 'mdi-check';
      }
    },
    getEmailStatus: function getEmailStatus(message) {
      var _this10 = this;
      var at = function at(value) {
        return _this10.$filters.formatDateTimeLocale(value, _this10.$userInfo.locale);
      };
      var reason = message.failedMessage ? ' — ' + message.failedMessage : '';
      var status = this.emailStatus(message);
      if (status === 'failed') {
        return message.deliveredAt ? 'Delivered at ' + at(message.deliveredAt) + ', then failed at ' + at(message.failedAt) + reason : 'Failed at ' + at(message.failedAt) + reason;
      }
      if (status === 'delivered') {
        return message.failedAt ? 'Failed at ' + at(message.failedAt) + reason + ', then delivered at ' + at(message.deliveredAt) : 'Delivered at ' + at(message.deliveredAt);
      }
      return 'Sent at ' + at(message.sentAt);
    },
    getEmailStatusIconName: function getEmailStatusIconName(message) {
      if (message.isIncoming) return 'mark_email_read';
      if (this.emailStatus(message) === 'failed') return 'warning';
      return 'send';
    },
    getEmailStatusLabel: function getEmailStatusLabel(message) {
      if (message.isIncoming) return 'Received';
      if (this.emailStatus(message) === 'failed') return 'Error in sending';
      return 'Sent';
    },
    getEmailStatusIconStyle: function getEmailStatusIconStyle(message) {
      var base = {
        fontVariationSettings: '\'FILL\' 1, \'wght\' 600, \'GRAD\' 0, \'opsz\' 20',
        fontStyle: 'normal'
      };
      if (message.isIncoming) return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, base), {}, {
        color: '#4B9EF1'
      });
      if (this.emailStatus(message) === 'failed') return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, base), {}, {
        color: '#E97C96'
      });
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, base), {}, {
        color: '#7CE999'
      });
    },
    openMessageModal: function openMessageModal(message) {
      if (!this.hasFailureDetail(message)) return;
      this.messageModalMessage = message.failedMessage.replace(/\\n/g, '<br/>');
      this.isMessageModalActive = true;
    },
    closeMessageModal: function closeMessageModal() {
      this.messageModalMessage = '';
      this.isMessageModalActive = false;
    },
    resetEmail: function resetEmail() {
      var _this11 = this;
      this.replyToMessageId = '';
      // this.replyToSender = ''
      this.replyToContent = '';
      this.replyToEmail = {};
      this.refreshEmailer = true;

      // Clear email preview fields
      this.msgDetails.emailTo = '';
      this.msgDetails.emailCc = '';
      this.msgDetails.emailBcc = '';
      this.msgDetails.emailSubject = '';
      this.msgDetails.message = '';
      if (this.isEmailerActive === true) {
        this.isEmailerActive = false;
        this.$nextTick(function () {
          _this11.isEmailerActive = true;
        });
      }
    },
    emailSent: function emailSent() {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee1() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              _this12.resetEmail();
              _context1.n = 1;
              return _this12.getMessages();
            case 1:
              _context1.n = 2;
              return _this12.refreshContentCounts();
            case 2:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    getCurrentTime: function getCurrentTime() {
      var now = new Date();
      return now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
    },
    getPreviewBubbleClass: function getPreviewBubbleClass() {
      if (this.isWhatsApp) return 'whatsapp-bubble';
      if (this.isEmail) return 'email-bubble';
      return 'sms-bubble';
    },
    getMessageBubbleClass: function getMessageBubbleClass(message) {
      var classes = [];
      if (this.isSelectedReplyToMessage(message.messageId)) {
        classes.push('has-background-warning', 'has-text-white');
      } else if (message.isIncoming) {
        classes.push('has-background-success', 'has-text-white'); // Green for incoming
      } else {
        classes.push('has-background-primary', 'has-text-white'); // Blue for outgoing
      }
      if (this.isEmail) {
        classes.push('email-bubble');
      } else {
        if (message.isIncoming) {
          classes.push('has-radius-left');
        } else {
          classes.push('has-radius-right');
        }
      }
      return classes.join(' ');
    },
    formatPhoneNumber: function formatPhoneNumber(phoneNumber) {
      if (!phoneNumber) return '';
      // Return phone number without hyphens - just clean digits or original format
      var cleaned = phoneNumber.replace(/\D/g, '');
      return cleaned || phoneNumber;
    },
    getProcessedMessage: function getProcessedMessage() {
      if (!this.msgDetails.message) return '';

      // Build Message Text - replace placeholders with actual data
      var message = this.msgDetails.message;

      // Replace placeholders with actual values
      message = message.replace(/\[NAME\]/g, this.msgDetails.customer || '');
      message = message.replace(/\[REGO\]/g, this.msgDetails.rego || '');
      message = message.replace(/\[EXCESS\]/g, this.msgDetails.excess ? '$' + Number(this.msgDetails.excess).toFixed(2) : '');
      message = message.replace(/\[EST START DATE\]/g, this.msgDetails.jobStart || '');
      message = message.replace(/\[EST END DATE\]/g, this.msgDetails.jobEnd || '');
      message = message.replace(/\[SHOPNAME\]/g, this.msgDetails.shopName || '');

      // Clean up HTML tags
      message = message.replace(/<p>/g, '');
      message = message.replace(/<\/p>/g, '');
      return message;
    },
    getPreviewLogBubbleClass: function getPreviewLogBubbleClass() {
      var classes = ['has-radius-right'];
      // For SMS/WhatsApp previews, use grey background with dark text
      classes.push('has-background-grey-lighter', 'has-text-dark');
      return classes.join(' ');
    },
    scrollToBottom: function scrollToBottom() {
      var _this13 = this;
      var force = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      this.$nextTick(function () {
        if (_this13.$refs.messageContainer) {
          var container = _this13.$refs.messageContainer;
          if (force) {
            // Force scroll to bottom (for initial load and tab switches)
            container.scrollTop = container.scrollHeight;
          } else {
            // Only scroll if not already at the bottom (for typing events)
            var isAtBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 10;
            if (!isAtBottom) {
              container.scrollTop = container.scrollHeight;
            }
          }
        }
      });
    },
    updateEmailPreview: function updateEmailPreview(emailData) {
      // Update msgDetails with email information for preview
      if (emailData) {
        this.msgDetails.emailTo = emailData.toEmails ? emailData.toEmails.join(', ') : '';
        this.msgDetails.emailCc = emailData.ccEmails ? emailData.ccEmails.join(', ') : '';
        this.msgDetails.emailBcc = emailData.bccEmails ? emailData.bccEmails.join(', ') : '';
        this.msgDetails.emailSubject = emailData.subject || '';
        this.msgDetails.message = emailData.message || '';
      }
    },
    resetTemplateFilter: function resetTemplateFilter() {
      this.templateFilter = {
        message: '',
        pageIndex: 1,
        pageSize: 999
      };
    },
    truncateTemplateLabel: function truncateTemplateLabel(str) {
      var max = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 60;
      return Object(_utils_StringFunctions__WEBPACK_IMPORTED_MODULE_30__["truncate"])(str, max);
    },
    isEmptyString: function isEmptyString(str) {
      return typeof str === 'string' && str.trim() === '';
    }
  }),
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  },
  truncate: function truncate(message, noOfChar) {
    return Object(_utils_StringFunctions__WEBPACK_IMPORTED_MODULE_30__["truncate"])(sender, noOfChar);
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _components_ImageSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/ImageSelect */ "./src/components/ImageSelect/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../mixins/QuoteCommunicationsMixin */ "./src/views/quote/mixins/QuoteCommunicationsMixin.js");
/* harmony import */ var _QuoteEmailAttachments__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./QuoteEmailAttachments */ "./src/views/quote/components/QuoteEmailAttachments.vue");
/* harmony import */ var _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/views/quote/components/AttachmentSelect.vue */ "./src/views/quote/components/AttachmentSelect.vue");






// import { Emailer } from '@/classes'
// import StoreUtil from '@/store/utils'
// import PrintPreviewRoutes from '@/components/printpreview/route-types'
// import { RemarkTypes, AssetTypes } from '@/enums'
// import { KeyValuePairModel } from '@/classes/viewmodels'



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteCommunicationEmailModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__["BaseModalEx"],
    ImageSelect: _components_ImageSelect__WEBPACK_IMPORTED_MODULE_4__["default"],
    QuoteEmailAttachments: _QuoteEmailAttachments__WEBPACK_IMPORTED_MODULE_7__["default"],
    AttachmentSelect: _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_8__["default"]
  },
  mixins: [_mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_6__["default"]],
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    },
    iconName: {
      type: String,
      default: 'mdi-attachment'
    },
    okDisabled: {
      type: Boolean,
      default: false
    },
    attachDisabled: {
      type: Boolean,
      default: true
    },
    cancelDisabled: {
      type: Boolean,
      default: false
    },
    emailer: {
      type: Object,
      defaul: {}
    },
    // toggleAttachButton: {
    //   type: Boolean,
    //   default: false
    // }
    selectedAttachmentEmailId: {
      type: String,
      default: ''
    },
    isIncoming: {
      type: Boolean,
      default: false
    },
    isDocAttachActive: {
      type: Boolean,
      default: false
    },
    selectedDocuments: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      isActive: false,
      innerValue: null,
      imagesSelectedForAttachment: [],
      documentsSelectedForAttachment: [],
      attachmentOptions: {
        selectedQuotes: []
      },
      toggleAttachButton: false,
      innerEmailer: {},
      isActiveImageSelect: true,
      isActiveAttachment: false
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_3__["mapGetters"])(['licenceExpired'])), {}, {
    childModel: {
      get: function get() {
        return this.value;
      },
      set: function set(newValue) {
        this.$emit('input', newValue);
      }
    },
    canAttach: function canAttach() {
      return this.imagesSelectedForAttachment.length > 0;
    },
    cancelInWording: function cancelInWording() {
      return this.isActiveAttachment ? 'Close' : 'Cancel';
    }
  }),
  watch: {
    selectedDocuments: {
      handler: function handler(newVal) {
        this.documentsSelectedForAttachment = Array.isArray(newVal) ? newVal : [];
      },
      immediate: true
    },
    active: function active(value) {
      this.isActive = value;
    },
    value: {
      handler: function handler(newVal, oldVal) {
        //console.log(newVal)
        this.imagesSelectedForAttachment = newVal;
      }
    },
    selectedAttachmentEmailId: {
      handler: function handler(newVal, oldVal) {
        this.innerSelectedAttachmentEmailId = newVal;
        this.isActiveAttachment = !!newVal;
        this.isActiveImageSelect = !this.isActiveAttachment && !this.isDocAttachActive;
      }
    },
    isDocAttachActive: {
      handler: function handler(newVal) {
        if (newVal) {
          this.isActiveImageSelect = false;
        } else {
          this.isActiveImageSelect = !this.isActiveAttachment;
        }
      },
      immediate: true
    }
  },
  created: function created() {
    this.imagesSelectedForAttachment = this.value;
    this.innerEmailer = this.emailer;
    //console.log(this.innerEmailer)
  },
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    onDocumentsSelected: function onDocumentsSelected(docs) {
      this.documentsSelectedForAttachment = docs;
      this.$emit('update:selectedDocuments', docs);
    },
    // ...mapActions('printpreview', { addEmailer: 'addEmailer', removeEmailer: 'removeEmailer' }),
    // ...mapActions('printpreview', { addReportParameters: 'addParameters', removeReportParameters: 'removeParameters' }),
    ok: function ok() {
      if (this.isDocAttachActive) {
        this.$emit('update:selectedDocuments', this.documentsSelectedForAttachment);
      } else {
        this.childModel = this.imagesSelectedForAttachment;
        this.setEmailerAttachments({
          emailerId: this.innerEmailer.id,
          attachments: this.imagesSelectedForAttachment
        });
      }
      this.reset();
      this.$emit('ok');
      this.$emit('update:active', false);
    },
    // attach() {
    //   this.toggleAttachButton = !this.toggleAttachButton
    //   // const param = {
    //   //   quoteId: this.innerEmailer.assetId,
    //   //   images: this.imagesSelectedForAttachment
    //   // }
    //   // this.imagesSelectedForAttachment.forEach(i => { i.text = i.fileName })
    //   this.setEmailerAttachments({ emailerId: this.innerEmailer.id, attachments: this.imagesSelectedForAttachment })
    //   this.childModel = this.imagesSelectedForAttachment
    // },
    cancel: function cancel() {
      //this.imagesSelectedForAttachment.splice(0, this.imagesSelectedForAttachment.length)
      //this.isActive = false
      //this.$emit('update:active', false)
      this.reset();
      this.$emit('cancel');
      this.$emit('update:active', false);
    },
    reset: function reset() {
      this.toggleAttachButton = false;
    },
    getImageIdForAttachment: function getImageIdForAttachment(index) {
      if (index <= this.imagesSelectedForAttachment.length) {
        return this.imagesSelectedForAttachment[index - 1].quoteImageId;
      } else {
        return _components_Guid__WEBPACK_IMPORTED_MODULE_5__["default"].empty();
      }
    },
    getSelectedImage: function getSelectedImage(selectedImages) {
      this.imagesSelectedForAttachment = selectedImages;
    },
    updateAttachment: function updateAttachment() {
      this.$emit('updateAttachment');
    },
    closeAttachmentsModel: function closeAttachmentsModel() {
      this.isActiveAttachment = false;
      this.isActiveImageSelect = true;
      this.isActive = false;
      this.innerSelectedAttachmentEmailId = '';
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.match.js */ "./node_modules/core-js/modules/es.string.match.js");
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../mixins/QuoteCommunicationsMixin */ "./src/views/quote/mixins/QuoteCommunicationsMixin.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_VueEmail_VueEmailTemplateModal__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/VueEmail/VueEmailTemplateModal */ "./src/components/VueEmail/VueEmailTemplateModal.vue");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _QuoteEmailModal_vue__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./QuoteEmailModal.vue */ "./src/views/quote/components/QuoteEmailModal.vue");
/* harmony import */ var _QuoteCommunicationEmailModal_vue__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./QuoteCommunicationEmailModal.vue */ "./src/views/quote/components/QuoteCommunicationEmailModal.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");





































// Temporary const for copyright message
var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEmail',
  components: {
    QuoteEmailModal: _QuoteEmailModal_vue__WEBPACK_IMPORTED_MODULE_33__["default"],
    QuoteCommunicationEmailModal: _QuoteCommunicationEmailModal_vue__WEBPACK_IMPORTED_MODULE_34__["default"],
    VueEmailTemplateModal: _components_VueEmail_VueEmailTemplateModal__WEBPACK_IMPORTED_MODULE_30__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_32___default.a
  },
  mixins: [_mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_28__["default"]],
  props: {
    quote: {
      type: Object,
      required: true
    },
    enableAttach: {
      type: Boolean,
      default: true
    },
    enableSend: {
      type: Boolean,
      default: false
    },
    toggleAttachButton: {
      type: Boolean,
      default: false
    },
    replyToEmail: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    selectedAttachmentEmailId: {
      type: String,
      default: ''
    },
    isIncoming: {
      type: Boolean,
      default: false
    },
    msgDetails: {
      type: Object,
      default: function _default() {
        return {
          quoteId: null,
          customer: null,
          rego: null,
          jobStart: null,
          jobEnd: null,
          excess: null,
          mobile: null,
          message: '',
          shopName: ''
        };
      }
    }
  },
  data: function data() {
    return {
      //isEmailModalActive: false,
      //isImageAttachActive: false,
      docAttachActive: false,
      selectedDocuments: [],
      emailer: {
        id: null,
        reportName: null,
        assetId: ''
      },
      //reportBytes: null,
      // reportContentType: '',
      selectedImages: [],
      quoteIds: [],
      isEnteringNewEmail: false,
      selectedImageIds: [],
      // replyToMessageId: '',
      replyToSenderEmails: [],
      replyToEmailCcs: [],
      replyToEmailBccs: [],
      isAttachmentModalActive: false,
      innerReplyToEmail: {},
      innerReplyToEmailSubject: '',
      innerReplyToEmailMessage: '',
      innerSelectedAttachmentEmailId: '',
      editMaximize: true,
      isEmailTemplateModalActive: false,
      isTemplateLoading: false,
      templates: [],
      messages: [],
      selectedTemplate: '',
      templateFilter: {
        message: '',
        pageIndex: 1,
        pageSize: 999
      },
      innerMsgDetails: {},
      defaultCc: '',
      showAttachDropdown: false
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_35__["mapGetters"])({
    company: 'company/company'
  })), {}, {
    companyEnabledAutoCC: function companyEnabledAutoCC() {
      return this.company.setting ? this.company.setting.enabledAutoCC : false;
    },
    getSender: function getSender() {
      var message = this.innerReplyToEmail;
      var isEmpty = this.isEmptyObject(message);
      return isEmpty ? '' : message.isIncoming ? message.sender : message.recipients;
    },
    // reportExtension() {
    //   return mimeTypes.extension(this.reportContentType)
    // }
    isAllowAutoCC: function isAllowAutoCC() {
      return this.companyEnabledAutoCC && this.defaultCc && !this.replyToEmailCcs.includes(this.defaultCc);
    }
  }),
  watch: {
    replyToEmail: function replyToEmail(message) {
      this.resetEmailer();
      this.clearSelectedTemplate();
      this.innerReplyToEmail = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(message || {});
      this.buildReplyEmail();
      //this.resetEmailer()
      //this.clearSelectedTemplate()
    },
    // replyToMessage(value) {
    //   this.replyToMessageId = value
    // },
    // replyToSender(value) {
    //   this.replyToSenderEmails = value ? [value] : []
    // },
    emailer: {
      handler: function handler(newVal, oldVal) {
        // Emit email data change for preview update
        this.$emit('emailDataChanged', newVal);
      },
      deep: true
    },
    'emailer.attachments': {
      handler: function handler(newVal, oldVal) {
        var _this = this;
        if (this.selectedImages && this.selectedImages.length) {
          var differences = this.selectedImages.filter(function (image) {
            var index = newVal.findIndex(function (i) {
              return i === image.fileName;
            });
            return index === -1;
          });
          if (!_isEmpty(differences)) {
            differences.forEach(function (diff) {
              var imageIndex = _this.selectedImages.findIndex(function (i) {
                return i.fileName === diff.fileName;
              });
              if (imageIndex !== -1) _this.selectedImages.splice(imageIndex, 1);
              var idIndex = _this.selectedImageIds.findIndex(function (id) {
                return id === diff.quoteImageId;
              });
              if (idIndex !== -1) _this.selectedImageIds.splice(idIndex, 1);
            });
          }
        }
        // if (this.selectedImages.length > 0) {
        //   const difference = this.selectedImages.filter(function(image) {
        //     const index = newVal.findIndex(i => i === image.fileName)
        //     return index === -1
        //   })
        //   if (!_isEmpty(difference)) {
        //     const imageIndex = this.selectedImages.findIndex(i => i.fileName === difference[0].fileName)
        //     this.selectedImages.splice(imageIndex, 1)
        //     const idIndex = this.selectedImageIds.findIndex(id => id === difference[0].quoteImageId)
        //     this.selectedImageIds.splice(idIndex, 1, Guid.empty())
        //   }
        // }
      },
      deep: true
    },
    selectedAttachmentEmailId: {
      handler: function handler(newVal, oldVal) {
        this.innerSelectedAttachmentEmailId = newVal;
        this.isAttachmentModalActive = !!newVal;
      }
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this2.clearSessionStorage();
            _this2.checkCompanySetting();
            _this2.setEmailer();
            _context.n = 1;
            return _this2.fetchDefaultCc();
          case 1:
            _this2.getEmailMessageDropdown();
            _this2.assignInnerValue();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    this.resetEmailer();
    this.buildReplyEmail();
    if (this.isAllowAutoCC) {
      this.replyToEmailCcs.push(this.defaultCc);
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.cleanEmailer();
  },
  methods: {
    checkCompanySetting: function checkCompanySetting() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (_this3.company.setting) {
                _context2.n = 1;
                break;
              }
              _context2.n = 1;
              return _this3.$store.dispatch('company/getCompanySetting');
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    fetchDefaultCc: function fetchDefaultCc() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this4.defaultCc = _this4.isAllowAutoCC ? _this4.$userInfo.email || '' : '';
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    toggleAttachDropdown: function toggleAttachDropdown() {
      this.showAttachDropdown = !this.showAttachDropdown;
    },
    assignInnerValue: function assignInnerValue() {
      this.innerMsgDetails = this.msgDetails;
    },
    isEmptyObject: function isEmptyObject(obj) {
      // Check if obj is an object and not null
      if (Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(obj) === 'object' && obj !== null) {
        // Get the internal [[Class]] property
        var objClass = Object.prototype.toString.call(obj);

        // Check if the object is an object literal or an instance of Object
        if (objClass === '[object Object]' || objClass === '[object ObjectConstructor]') {
          // Check if the object has no own enumerable properties
          return Object.keys(obj).length === 0;
        }
      }

      // Return false for non-object types or non-empty objects
      return false;
    },
    buildReplyEmail: function buildReplyEmail() {
      var isEmpty = this.isEmptyObject(this.innerReplyToEmail);
      if (!isEmpty && this.innerReplyToEmail.messageId) {
        var sender = this.getSender;
        this.replyToSenderEmails = sender ? [sender] : [];
        var cc = this.innerReplyToEmail.cc;
        this.replyToEmailCcs = cc ? cc.split(',') : [];

        // Always add defaultCc from server to CC if not present
        if (this.isAllowAutoCC) {
          this.replyToEmailCcs.push(this.defaultCc);
        }
        var bcc = this.innerReplyToEmail.bcc;
        this.replyToEmailBccs = bcc ? bcc.split(',') : [];
        var replyCurrentDate = new Date();
        if (this.innerReplyToEmail.subject) {
          this.innerReplyToEmailSubject = 'Re: ' + this.innerReplyToEmail.subject;
          this.emailer.subject = this.innerReplyToEmailSubject;
        }
        this.innerReplyToEmailMessage = this.emailer.message + '\n\n\n\n';
        this.innerReplyToEmailMessage += "On ".concat(replyCurrentDate, ", ").concat(this.getSender, " wrote:\n\n");
        this.innerReplyToEmailMessage += this.innerReplyToEmail.message;
        // if (this.getSender)
        //   this.innerReplyToEmailMessage = `${this.emailer.message} \n\n\n\nOn ${currentDate}, ${this.getSender} wrote:\n\n` + this.innerReplyToEmail.message
      } else {
        // this.resetEmailer()
        this.innerReplyToEmailSubject = this.emailer.subject;
        this.innerReplyToEmailMessage = this.emailer.message;
        this.replyToSenderEmails = [];
        this.replyToEmailCcs = this.defaultCc ? [this.defaultCc] : [];
        this.replyToEmailBccs = [];
      }
      //return message
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isEnteringNewEmail = newEmail;
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
    },
    setEmailer: function setEmailer() {
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_25__["Emailer"]();
      emailer.assetId = this.quote.quoteId;
      emailer.assetType = _enums__WEBPACK_IMPORTED_MODULE_29__["EmailAssetTypes"].Quote;
      emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_29__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_29__["AssetTypes"].Insurer];
      emailer.remark = "Quote ".concat(this.quote.prefix).concat(this.quote.quoteNo).concat(this.quote.suffix);
      if (this.companyEnabledAutoCC && this.$userInfo.email) {
        emailer.ccEmails = [this.$userInfo.email];
      }
      emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_29__["RemarkTypes"].OtherSystemRemark;
      emailer.subject = "Quote No: ".concat(this.quote.quoteNo || 'NA', " - Claim No: ").concat(this.quote.claimNo || 'NA', " - Rego: ").concat(this.quote.vehicleRego || 'NA', " ");
      emailer.reportName = "".concat(this.quote.prefix).concat(this.quote.quoteNo).concat(this.quote.suffix);
      this.addEmailer(emailer);
      this.emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(this.getEmailer(emailer.id));
    },
    resetEmailer: function resetEmailer() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var _emailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              //console.log('reset Emailer')
              _emailer = null;
              if (!_emailer) _emailer = _this5.retrieveEmailer();
              if (!_emailer) _emailer = _store_utils__WEBPACK_IMPORTED_MODULE_26__["default"].getLocalStorage(_this5.emailer.id, 'emailer');
              if (!_emailer) _emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(_this5.getEmailer(_this5.emailer.id) || new _classes__WEBPACK_IMPORTED_MODULE_25__["Emailer"]());
              _emailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this5.$userInfo.companyName));
              _this5.emailer = _emailer;
              _this5.persistEmailer();
              //this.updateAttachmentList()
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(this.emailer));
    },
    cleanEmailer: function cleanEmailer() {
      //console.log('cleanEmailer')
      _store_utils__WEBPACK_IMPORTED_MODULE_26__["default"].removeStorage(this.emailer.id, 'emailer');
      _store_utils__WEBPACK_IMPORTED_MODULE_26__["default"].removeLocalStorage(this.emailer.id, 'emailer');
      this.removeEmailer(this.emailer.id);
    },
    sent: function sent() {
      this.discardEmail();
      this.$emit('sent');
    },
    resetEmail: function resetEmail() {
      this.discardEmail();
      this.$emit('resetEmail');
    },
    send: function send() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _this6.$refs.emailer.send();
            case 1:
              _this6.clearSelectedTemplate();
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    discardEmail: function discardEmail() {
      //this.isImageAttachActive = false
      this.selectedImageIds.splice(0, this.selectedImageIds.length);
      this.selectedImages.splice(0, this.selectedImages.length);
      this.selectedDocuments.splice(0, this.selectedDocuments.length);
      // this.replyToMessageId = ''
      this.replyToSenderEmails = [];
      this.replyToEmailCcs = [];
      this.replyToEmailBccs = [];
      this.resetEmailer();
    },
    toggleEditMaximize: function toggleEditMaximize() {
      this.editMaximize = !this.editMaximize;
      this.$emit('toggleEditMaximize');
    },
    getEmailMessageDropdown: function getEmailMessageDropdown() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var postData, templates, _templates;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this7.isTemplateLoading = true;
              postData = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, _this7.templateFilter), {
                message: ''
              });
              _context6.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_31__["EmailService"].getEmailTemplateDropdown(postData);
            case 1:
              templates = _context6.v;
              _this7.templates = templates;
              if (!(_this7.templateFilter.message !== '')) {
                _context6.n = 3;
                break;
              }
              _this7.selectedTemplate = _this7.templates.find(function (c) {
                return c.message === _this7.templateFilter.message;
              });
              if (_this7.selectedTemplate) {
                _context6.n = 3;
                break;
              }
              _this7.clearSelectedTemplate();
              _context6.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_31__["EmailService"].getEmailTemplateDropdown(_this7.templateFilter);
            case 2:
              _templates = _context6.v;
              _this7.templates = _templates;
            case 3:
              _this7.isTemplateLoading = false;
            case 4:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    closeTemplateModal: function closeTemplateModal() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this8.isEmailTemplateModalActive = false;
              //console.log('close template modal')
              setTimeout(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
                  while (1) switch (_context7.n) {
                    case 0:
                      _context7.n = 1;
                      return _this8.getEmailMessageDropdown();
                    case 1:
                      return _context7.a(2, _context7.v);
                  }
                }, _callee7);
              })), 1000);
            case 1:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    selectTemplate: function selectTemplate(selected) {
      //this.innerMsgDetails.customer = this.extractName(this.getSender)
      this.resetEmailer();
      this.clearSelectedTemplate();
      this.buildReplyEmail();
      this.templateFilter.message = selected.message;
      this.selectedTemplate = selected;
      //console.log(this.emailer.message)
      var templateMessage = this.replaceTags(selected.message);
      this.innerReplyToEmailMessage = templateMessage + '\n\n' + this.innerReplyToEmailMessage;
    },
    clearSelectedTemplate: function clearSelectedTemplate() {
      this.templateFilter.message = '';
      //this.innerReplyToEmail.message = ''
      //this.innerMsgDetails.customer = this.msgDetails.customer
      this.selectedTemplate = '';
    },
    replaceTags: function replaceTags(message) {
      message = message.replace(/\[QUOTEID\]/g, this.innerMsgDetails.quoteId);
      message = message.replace(/\[NAME\]/g, this.innerMsgDetails.customer);
      message = message.replace(/\[REGO\]/g, this.innerMsgDetails.rego);
      message = message.replace(/\[EST START DATE\]/g, this.innerMsgDetails.jobStart);
      message = message.replace(/\[EST END DATE\]/g, this.innerMsgDetails.jobEnd);
      message = message.replace(/\[EXCESS\]/g, this.innerMsgDetails.excess);
      message = message.replace(/\[SHOPNAME\]/g, this.innerMsgDetails.shopName);
      return message;
    },
    extractName: function extractName(sender) {
      if (sender) {
        var matchName = sender.match(/^[^<]*/);
        if (matchName) return matchName[0].trim();
        var matchEmail = sender.match(/<([^>]+)>/);
        if (matchEmail) return matchEmail[1];
      }
      return '';
    },
    resetReplyToEmail: function resetReplyToEmail() {
      this.innerReplyToEmail = {};
      this.innerReplyToEmailSubject = '';
      this.innerReplyToEmailMessage = '';
      // this.replyToMessageId = ''
      this.replyToSenderEmails = [];
      this.replyToEmailCcs = [];
      this.replyToEmailBccs = [];
    },
    closeAttachModal: function closeAttachModal() {
      this.isAttachmentModalActive = false;
      this.innerSelectedAttachmentEmailId = '';
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_LazyImage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/LazyImage */ "./src/components/LazyImage.vue");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEmailAttachmentViewerModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_13__["BaseModalEx"],
    LazyImage: _components_LazyImage__WEBPACK_IMPORTED_MODULE_14__["default"]
    // PsPdfViewer
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    },
    quoteId: {
      type: String
    },
    // quoteAttachmentId: {
    //   type: String
    // },
    attachment: {
      type: Object
    },
    isIncoming: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      selectedDervied: null,
      internalAttachment: this.attachment,
      redaction: false,
      maxHeight: '600px'
    };
  },
  computed: {
    isPDF: function isPDF() {
      return this.internalAttachment.filename.toLowerCase().endsWith('pdf');
    }
  },
  watch: {
    active: function active(value) {
      this.isActive = value;
    },
    attachment: function attachment(value) {
      this.internalAttachment = value;
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    downloadUrl: function downloadUrl(url, fileName) {
      var link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(link.href);
    },
    downloadModifiedDocument: function downloadModifiedDocument() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var response, fileName;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_15__["EmailService"].downloadModifiedQuoteEmailAttachment(_this.quoteId, _this.internalAttachment.quoteEmailAttachmentId, _this.internalAttachment.isIncoming);
            case 1:
              response = _context.v;
              fileName = _this.attachment.filename;
              _this.downloadUrl('data:application/pdf;base64,' + response.data, fileName);
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    cancel: function cancel() {
      this.$emit('cancel');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Buffer) {/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _QuoteEmailAttachmentViewerModal_vue__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./QuoteEmailAttachmentViewerModal.vue */ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");























//import { DateTime } from 'luxon'


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEmailAttachments',
  components: {
    QuoteEmailAttachmentViewerModal: _QuoteEmailAttachmentViewerModal_vue__WEBPACK_IMPORTED_MODULE_21__["default"]
  },
  props: {
    quoteId: {
      type: String
    },
    emailId: {
      type: String
    },
    // quoteAttachmentId: {
    //   type: String
    // },
    // quoteAttachmentCategoryId: {
    //   type: String
    // },
    attachments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    // attachment: {
    //   type: Object
    // },
    // categories: {
    //   type: Array,
    //   default: () => []
    // }
    isIncoming: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isModalActive: false,
      isViewerModalOpen: false,
      attachmentUrl: '',
      innerAttachments: [],
      selectedQuoteEmailAttachmentId: '',
      viewAttachment: null,
      attachmentCategories: [],
      attachmentCategory: '',
      isCopyingAttachmentToQuote: false
    };
  },
  computed: {
    hasSelected: function hasSelected() {
      return this.innerAttachments.filter(function (i) {
        return i.isSelected;
      }).length > 0;
    },
    selectedAttachments: function selectedAttachments() {
      return this.innerAttachments.filter(function (i) {
        return i.isSelected;
      });
    }
  },
  watch: {
    emailId: {
      handler: function handler(newVal, oldVal) {
        console.log(newVal);
        this.getAttachment();
      }
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _this.getAttachment();
          case 1:
            _context.n = 2;
            return _this.loadQuoteAttachmentCategories();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {
    loadQuoteAttachmentCategories: function loadQuoteAttachmentCategories() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var _this2$attachmentCate, _this2$attachmentCate2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_22__["default"].getQuoteAttachmentCategories();
            case 1:
              _this2.attachmentCategories = _context2.v;
              if (!_this2.attachmentCategory) {
                _this2.attachmentCategory = (_this2$attachmentCate = (_this2$attachmentCate2 = _this2.attachmentCategories[0]) === null || _this2$attachmentCate2 === void 0 ? void 0 : _this2$attachmentCate2.quoteAttachmentCategoryId) !== null && _this2$attachmentCate !== void 0 ? _this2$attachmentCate : '';
              }
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getAttachment: function getAttachment() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var attachments;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["EmailService"].getQuoteEmailAttachments(_this3.quoteId, _this3.emailId, _this3.isIncoming);
            case 1:
              attachments = _context3.v;
              _this3.innerAttachments = attachments;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    setSelectedStatusAll: function setSelectedStatusAll(value) {
      this.innerAttachments.forEach(function (item) {
        item.isSelected = value;
      });
    },
    openModal: function openModal(attachment) {
      var filename = attachment.filename;
      //const decodeData = this.decodeData(attachment.ImageContentBase64)
      if (filename.toLowerCase().endsWith('.pdf')) {
        this.attachmentUrl = "data:application/pdf;base64,".concat(attachment.imageContentBase64);
      } else {
        this.attachmentUrl = "data:image/jpeg;base64,".concat(attachment.imageContentBase64);
      }
      this.isModalActive = true;
    },
    decodeData: function decodeData(base64Data) {
      return Buffer.from(base64Data, 'base64');
    },
    closeModal: function closeModal() {
      this.isModalActive = false;
      this.$emit('close');
    },
    handleIsSelectedChange: function handleIsSelectedChange(value) {
      var isSelected = value;
      //this.attachment.isSelected = isSelected
      //console.log('sending update:attachment', isSelected)
      this.$emit('update:attachment', {
        attachment: this.attachment,
        isSelected: isSelected
      });
    },
    imageUpdated: function imageUpdated() {
      this.$emit('image-uploaded');
    },
    downloadUrl: function downloadUrl(url, fileName) {
      var link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(link.href);
    },
    downloadModifiedDocument: function downloadModifiedDocument(attachment) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var response, fileName;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["EmailService"].downloadModifiedQuoteEmailAttachment(_this4.quoteId, attachment.quoteEmailAttachmentId, attachment.isIncoming);
            case 1:
              response = _context4.v;
              fileName = attachment.filename; // if (fileName.indexOf('.pdf') === -1) {
              //   fileName += '.pdf'
              // }
              console.log(response);
              if (attachment.isPdf) {
                _this4.downloadUrl('data:application/pdf;base64,' + response.data, fileName);
              } else if (_this4.hasExtension(fileName, '.xml')) {
                _this4.downloadUrl('data:application/xml;base64,' + response.data, fileName);
              } else {
                _this4.downloadUrl('data:application/text/plain;base64,' + response.data, fileName);
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    hasExtension: function hasExtension(fileName, extension) {
      return fileName.toLowerCase().endsWith(extension.toLowerCase());
    },
    viewImage: function viewImage(attachment, isImage) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              console.log(attachment);
              if (attachment) {
                if (!isImage) {
                  _this5.downloadModifiedDocument(attachment);
                } else {
                  _this5.isViewerModalOpen = true;
                  _this5.selectedQuoteEmailAttachmentId = attachment.quoteEmailAttachmentId;
                  _this5.viewAttachment = attachment;
                }
              } else {
                _this5.isViewerModalOpen = false;
                _this5.selectedQuoteEmailAttachmentId = '';
                _this5.viewAttachment = null;
              }
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    copyAttachmentToQuote: function copyAttachmentToQuote() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var _iterator, _step, row, response, data, documentCount, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.p = _context6.n) {
            case 0:
              _this6.$showSpinner('Copying attachment');
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this6.selectedAttachments);
              _context6.p = 1;
              _iterator.s();
            case 2:
              if ((_step = _iterator.n()).done) {
                _context6.n = 4;
                break;
              }
              row = _step.value;
              _context6.n = 3;
              return _services__WEBPACK_IMPORTED_MODULE_23__["EmailService"].copyAttachmentToQuote(row.quoteEmailAttachmentId, _this6.quoteId, _this6.attachmentCategory);
            case 3:
              _context6.n = 2;
              break;
            case 4:
              _context6.n = 6;
              break;
            case 5:
              _context6.p = 5;
              _t = _context6.v;
              _iterator.e(_t);
            case 6:
              _context6.p = 6;
              _iterator.f();
              return _context6.f(6);
            case 7:
              _this6.$hideSpinner('Copying images');
              _context6.n = 8;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_22__["default"].getQuoteAttachments(_this6.quoteId);
            case 8:
              response = _context6.v;
              data = response.data;
              documentCount = Object.values(data).reduce(function (total, row) {
                return total + Object.values(row.quoteAttachments).length;
              }, 0);
              _this6.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].DocumentCountChanged, documentCount);
              _this6.$notification.openNotificationWithType('success', 'Copy to attachment', 'Save successful');
              //console.log('trigger')
              //this.toggleCopyAttachmentModal(false)
            case 9:
              return _context6.a(2);
          }
        }, _callee6, null, [[1, 5, 6, 7]]);
      }))();
    }
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/buffer/index.js */ "./node_modules/buffer/index.js").Buffer))

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_VueEmail__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/VueEmail */ "./src/components/VueEmail/index.js");
/* harmony import */ var _components_ImageSelect__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/ImageSelect */ "./src/components/ImageSelect/index.js");
/* harmony import */ var _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/views/quote/components/AttachmentSelect.vue */ "./src/views/quote/components/AttachmentSelect.vue");
/* harmony import */ var _components_BulmaModal_BaseModalEx_vue__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/BulmaModal/BaseModalEx.vue */ "./src/components/BulmaModal/BaseModalEx.vue");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../mixins/QuoteCommunicationsMixin */ "./src/views/quote/mixins/QuoteCommunicationsMixin.js");

























var divider = '==============================================================';
var copyright = 'All accompanying materials are the exclusive property of [COMPANY].  All [COMPANY] rights are reserved.  These Materials must not be reproduced, adapted, modified, published, or communicated to any person in any form, without express prior written consent of [COMPANY].  Any unauthorised use of these Materials will be vigorously pursued and may result in legal action, including a claim for damages or an account for loss of profits.';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEmailModal',
  components: {
    VueEmail: _components_VueEmail__WEBPACK_IMPORTED_MODULE_17__["VueEmail"],
    ImageSelect: _components_ImageSelect__WEBPACK_IMPORTED_MODULE_18__["default"],
    AttachmentSelect: _views_quote_components_AttachmentSelect_vue__WEBPACK_IMPORTED_MODULE_19__["default"],
    BaseModalEx: _components_BulmaModal_BaseModalEx_vue__WEBPACK_IMPORTED_MODULE_20__["default"]
  },
  mixins: [_mixins_QuoteCommunicationsMixin__WEBPACK_IMPORTED_MODULE_24__["default"]],
  props: {
    active: {
      type: Boolean,
      default: false
    },
    emailer: {
      type: Object,
      required: true
    },
    quoteIds: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    enableAttach: {
      type: Boolean,
      default: true
    },
    replyToMessageId: {
      type: String,
      default: ''
    },
    replyToSenderEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    replyToEmailCcs: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    replyToEmailBccs: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    emailSubject: {
      type: String,
      default: ''
    },
    emailMessage: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      isSending: false,
      isImageAttachActive: false,
      isDocAttachActive: false,
      isEnteringNewEmail: false,
      selectedImages: [],
      selectedImageIds: [],
      selectedDocuments: [],
      showAttachDropdown: false,
      allowedImageExtensions: ['.jpg', '.jpeg', '.png'],
      allowedDocumentExtensions: ['.pdf'],
      emailValidation: {
        canSend: true,
        isAttachmentSizeExceeded: false,
        totalSize: 0,
        errors: []
      }
    };
  },
  computed: {
    enableSend: function enableSend() {
      return !this.isEnteringNewEmail && this.emailValidation.canSend;
    },
    assetId: function assetId() {
      return this.emailer.assetId;
    },
    computeQuoteIds: function computeQuoteIds() {
      var ids = this.emailer.quoteIds;
      return Array.isArray(ids) ? ids : [];
    }
  },
  created: function created() {
    this.clearSessionStorage();
  },
  mounted: function mounted() {
    this.resetEmailer();
  },
  beforeDestroy: function beforeDestroy() {
    this.cleanEmailer();
  },
  methods: {
    sendEmail: function sendEmail() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _this.$refs.emailer.send();
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    resetEmail: function resetEmail() {
      this.discardEmail();
      this.$emit('resetEmail');
    },
    discardEmail: function discardEmail() {
      this.isImageAttachActive = false;
      this.isDocAttachActive = false;
      this.selectedImageIds.splice(0, this.selectedImageIds.length);
      this.selectedImages.splice(0, this.selectedImages.length);
      this.selectedDocuments.splice(0, this.selectedDocuments.length);
      this.resetEmailer();
      this.$emit('update:active', false);
      this.$emit('discard');
    },
    toggleAttachDropdown: function toggleAttachDropdown() {
      this.showAttachDropdown = !this.showAttachDropdown;
    },
    onFileLabelClick: function onFileLabelClick() {
      this.$refs.fileInput.accept = this.allowedImageExtensions.join(',') + ',' + this.allowedDocumentExtensions.join(',');
      this.$refs.fileInput.click();
    },
    onFileChange: function onFileChange(event) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var files;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              files = Array.from(event.target.files);
              _context2.n = 1;
              return _this2.onAttachFiles(files);
            case 1:
              event.target.value = ''; // Clear input after files are processed
              _this2.showAttachDropdown = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    showAttachImage: function showAttachImage() {
      this.isImageAttachActive = true;
      this.isDocAttachActive = false;
      // Initialize selectedImages with current quoteImageAttachments if any
      this.selectedImages = this.emailer.quoteImageAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteImageAttachments) : [];
    },
    closeImageModal: function closeImageModal() {
      this.isImageAttachActive = false;
      this.showAttachDropdown = false;
      // Reset selections if canceled - restore from emailer
      this.selectedImages = this.emailer.quoteImageAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteImageAttachments) : [];
    },
    onImagesSelected: function onImagesSelected(selectedImages) {
      this.selectedImages = selectedImages;
      console.log('Selected Images:', this.selectedImages);
      //this.$emit('update:selectedImages', this.selectedImages)
      //this.updateAttachmentList()
    },
    confirmImageSelection: function confirmImageSelection() {
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(this.emailer);
      if (!updatedEmailer.quoteImageAttachments) {
        this.$set(updatedEmailer, 'quoteImageAttachments', []);
      }
      updatedEmailer.quoteImageAttachments = this.selectedImages;
      this.$emit('update:emailer', updatedEmailer);
      this.isImageAttachActive = false;
      this.showAttachDropdown = false;
      //this.updateAttachmentList()
    },
    attachDocs: function attachDocs() {
      this.isDocAttachActive = true;
      this.isImageAttachActive = false;
      // Initialize selectedDocuments with current quoteAttachments if any
      this.selectedDocuments = this.emailer.quoteAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteAttachments) : [];
    },
    closeDocModal: function closeDocModal() {
      this.isDocAttachActive = false;
      this.showAttachDropdown = false;
      // Reset selections if canceled - restore from emailer
      this.selectedDocuments = this.emailer.quoteAttachments ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.emailer.quoteAttachments) : [];
    },
    confirmDocSelection: function confirmDocSelection() {
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(this.emailer);
      if (!updatedEmailer.quoteAttachments) {
        this.$set(updatedEmailer, 'quoteAttachments', []);
      }
      updatedEmailer.quoteAttachments = this.selectedDocuments;
      this.$emit('update:emailer', updatedEmailer);
      this.isDocAttachActive = false;
      this.showAttachDropdown = false;
    },
    onAttachFiles: function onAttachFiles(files) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var fileArray, updatedEmailer, maxSizeMB, maxSizeBytes, allowedExtensions, oversizedFiles, invalidTypeFiles, validFiles, _i, _fileArray, file, fileName, fileExtension, fileSizeMB, fileList, allowedTypes, _fileList, _i2, _validFiles, _file, arrayBuffer, _fileSizeMB, fileObj;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              fileArray = Array.from(files);
              updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_this3.emailer);
              if (!updatedEmailer.customAttachments) {
                _this3.$set(updatedEmailer, 'customAttachments', []);
              }
              maxSizeMB = 5;
              maxSizeBytes = maxSizeMB * 1024 * 1024; // Define allowed file types
              allowedExtensions = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this3.allowedImageExtensions), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this3.allowedDocumentExtensions));
              oversizedFiles = [];
              invalidTypeFiles = [];
              validFiles = []; // Check file sizes and types
              _i = 0, _fileArray = fileArray;
            case 1:
              if (!(_i < _fileArray.length)) {
                _context3.n = 4;
                break;
              }
              file = _fileArray[_i];
              fileName = file.name.toLowerCase();
              fileExtension = fileName.substring(fileName.lastIndexOf('.')); // Check file type
              if (allowedExtensions.includes(fileExtension)) {
                _context3.n = 2;
                break;
              }
              invalidTypeFiles.push(file.name);
              return _context3.a(3, 3);
            case 2:
              // Check file size
              if (file.size > maxSizeBytes) {
                fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
                oversizedFiles.push("".concat(file.name, " (").concat(fileSizeMB, "MB)"));
              } else {
                validFiles.push(file);
              }
            case 3:
              _i++;
              _context3.n = 1;
              break;
            case 4:
              // Show error for invalid file types
              if (invalidTypeFiles.length > 0) {
                fileList = invalidTypeFiles.join(', ');
                allowedTypes = 'Images (jpg, jpeg, png) and Documents (pdf)';
                _this3.$notification.error('Invalid File Type', "The following files have unsupported file types and cannot be attached: ".concat(fileList, ". Only ").concat(allowedTypes, " are allowed."));
              }

              // Show error for oversized files
              if (oversizedFiles.length > 0) {
                _fileList = oversizedFiles.join(', ');
                _this3.$notification.error('File Size Error', "The following files exceed the ".concat(maxSizeMB, "MB size limit and cannot be attached: ").concat(_fileList));
              }

              // Process only valid files
              _i2 = 0, _validFiles = validFiles;
            case 5:
              if (!(_i2 < _validFiles.length)) {
                _context3.n = 8;
                break;
              }
              _file = _validFiles[_i2];
              _context3.n = 6;
              return _file.arrayBuffer();
            case 6:
              arrayBuffer = _context3.v;
              _fileSizeMB = (arrayBuffer.byteLength / (1024 * 1024)).toFixed(2);
              fileObj = {
                fileName: _file.name,
                fileBytes: arrayBuffer,
                fileType: _file.type,
                fileSizeMB: parseFloat(_fileSizeMB)
              }; // Add to customAttachments
              updatedEmailer.customAttachments.push(fileObj);
            case 7:
              _i2++;
              _context3.n = 5;
              break;
            case 8:
              _this3.$emit('update:emailer', updatedEmailer);
            case 9:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    onDocumentsSelected: function onDocumentsSelected(docs) {
      this.selectedDocuments = Array.isArray(docs) ? docs : [];
      this.$emit('update:selectedDocuments', this.selectedDocuments);
      //this.updateAttachmentList()
    },
    handleAttachmentsUpdate: function handleAttachmentsUpdate(updatedAttachments) {
      // Update selectedDocuments to match the current attachments
      this.selectedDocuments = updatedAttachments || [];
      // Emit the update event
      this.$emit('update:selectedDocuments', this.selectedDocuments);
      // Update the attachment list to ensure consistency
      //this.updateAttachmentList()
    },
    handleValidationChanged: function handleValidationChanged(validation) {
      this.emailValidation = validation;
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isEnteringNewEmail = newEmail;
      this.$emit('new-email', newEmail);
    },
    sent: function sent() {
      this.discardEmail();
      this.$emit('sent');
    },
    clearSessionStorage: function clearSessionStorage() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.pkey));
    },
    resetEmailer: function resetEmailer() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var _emailer, updatedEmailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _emailer = _this4.retrieveEmailer();
              if (!_emailer) _emailer = _store_utils__WEBPACK_IMPORTED_MODULE_23__["default"].getLocalStorage(_this4.emailer.id, 'emailer');
              if (!_emailer) _emailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_this4.getEmailer(_this4.emailer.id) || new _classes__WEBPACK_IMPORTED_MODULE_21__["Emailer"]());
              updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_emailer);
              updatedEmailer.message = "\n\n".concat(divider, "\n").concat(copyright.replace(/\[COMPANY\]/g, _this4.$userInfo.companyName));
              _this4.$emit('update:emailer', updatedEmailer);
              _this4.persistEmailer(updatedEmailer);
              //this.updateAttachmentList()
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    retrieveEmailer: function retrieveEmailer() {
      return JSON.parse(sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey)));
    },
    persistEmailer: function persistEmailer() {
      var emailer = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
      var emailerToStore = emailer || this.emailer;
      sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ekey), JSON.stringify(emailerToStore));
    },
    cleanEmailer: function cleanEmailer() {
      _store_utils__WEBPACK_IMPORTED_MODULE_23__["default"].removeStorage(this.emailer.id, 'emailer');
      _store_utils__WEBPACK_IMPORTED_MODULE_23__["default"].removeLocalStorage(this.emailer.id, 'emailer');
      this.removeEmailer(this.emailer.id);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEmailViewerModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_4__["BaseModalEx"]
    // PsPdfViewer
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-email-open'
    },
    email: {
      type: Object,
      default: function _default() {
        return {};
      }
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      selectedDervied: null,
      internalAttachment: this.attachment,
      redaction: false,
      maxHeight: '600px'
    };
  },
  computed: {},
  watch: {
    email: function email(value) {
      this.email = value;
      console.log(this.email);
      console.log(this.isActive);
    },
    active: function active(value) {
      this.isActive = value;
      console.log(value);
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    getHtmlMessage: function getHtmlMessage() {
      var _this$email$message;
      var html = ((_this$email$message = this.email.message) !== null && _this$email$message !== void 0 ? _this$email$message : '').replace(/\n/g, '<br/>');
      return html;
    },
    ucaseFirst: function ucaseFirst(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    },
    close: function close() {
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_26__);



























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PhoneNoAutocomplete',
  components: {
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_24__["BulmaAutocomplete"]
  },
  mixins: [],
  props: {
    value: {
      type: String,
      default: ''
    },
    quoteId: {
      type: String,
      default: ''
    },
    classProp: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      items: [],
      innerValue: ''
    };
  },
  computed: {},
  watch: {
    innerValue: function innerValue(newVal, oldVal) {
      this.$emit('input', newVal);
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = newVal || '';
      },
      immediate: true
    }
  },
  created: function created() {
    // console.log('created', this.value)
    this.innerValue = this.value || '';
    this.getCustomerInsurerPhoneNo();
  },
  mounted: function mounted() {
    console.log('mounted', this.value);
  },
  beforeDestroy: function beforeDestroy() {},
  methods: {
    groupWithHeaders: function groupWithHeaders(items) {
      var grouped = {};

      // Group items by groupName
      items.forEach(function (item) {
        var group = item.isInQuote;
        if (!grouped[group]) {
          grouped[group] = [];
        }
        grouped[group].push(item);
      });

      // Create final array with headers
      var final = [];
      var groupOrder = [1, 0]; // Optional: control display order

      groupOrder.forEach(function (group) {
        if (grouped[group]) {
          final.push({
            isGroupHeader: true,
            groupName: group == 1 ? 'In Quote' : 'Out of Quote'
          });
          final.push.apply(final, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(grouped[group]));
        }
      });
      return final;
    },
    // Collapse the same name/number arriving twice with different formatting, and drop
    // rows with no usable number.
    dedupe: function dedupe(items) {
      var _this = this;
      var seen = new Set();
      return items.filter(function (item) {
        var digits = _this.keepOnlyDigits(item.phoneNo);
        if (!digits) {
          return false;
        }
        var key = "".concat(String(item.fullName || '').toLowerCase().trim(), "|").concat(digits);
        if (seen.has(key)) {
          return false;
        }
        seen.add(key);
        return true;
      });
    },
    getCustomerInsurerPhoneNo: lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(query) {
        var contacts;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!query) {
                _context.n = 2;
                break;
              }
              _context.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_25__["SmsService"].getCustomersInsurersdetails(this.quoteId, query);
            case 1:
              contacts = _context.v;
              this.items = this.groupWithHeaders(this.dedupe(contacts));
              this.$nextTick(function () {
                var items = document.querySelectorAll('.phone-no-autocomplete .dropdown-item');
                items.forEach(function (link) {
                  // link.classList.remove('is-disabled')
                  link.classList.remove('is-hovered');
                  link.removeAttribute('style'); // prevent clicks
                  var hasCustomHeader = link.querySelector('.custom-header') !== null;
                  if (hasCustomHeader) {
                    link.removeAttribute('href'); // removes link
                    // link.classList.add('is-disabled')           // add styling class
                    link.classList.add('is-hovered');
                    link.style.pointerEvents = 'none'; // prevent clicks
                    //link.style.color = 'gray'                   // visual cue
                  }
                });
              });
              _context.n = 3;
              break;
            case 2:
              this.items = [];
            case 3:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 100),
    keepOnlyDigits: function keepOnlyDigits(str) {
      return String(str || '').replace(/\D/g, ''); // keeps only digits
    },
    select: function select(selectedItem) {
      if (!selectedItem || selectedItem.isGroupHeader) return;
      if (selectedItem) {
        selectedItem.phoneNo = this.keepOnlyDigits(selectedItem.phoneNo);
        this.$emit('select', selectedItem);
      }
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    attrs: {
      active: _vm.isActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (sms, index) {
    return _c("tr", {
      key: sms.id,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(sms, index, $event);
        }
      }
    }, [_c("td", {
      on: {
        dblclick: function dblclick($event) {
          return _vm.editMessage(sms, index);
        }
      }
    }, [_vm._v(_vm._s(sms.message))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        "data-tooltip": "Click to delete"
      },
      on: {
        click: function click($event) {
          return _vm.deleteMessage(sms.id, index, sms.message);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2), _vm.isEnableSave ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message :")]), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }, {
      name: "model",
      rawName: "v-model",
      value: _vm.smsMessage,
      expression: "smsMessage"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": !_vm.isMessageEntered
    },
    attrs: {
      id: "smsMessage",
      placeholder: "Enter New Message Here...",
      maxlength: "2000"
    },
    domProps: {
      value: _vm.smsMessage
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.smsMessage = $event.target.value;
      }, _vm.enterMessage]
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("span", {
    staticClass: "help"
  }, [_vm._v(_vm._s(_vm.smsMessage.length) + "/2000")]), !_vm.isMessageEntered && _vm.isEnableSave ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Message is required.")]) : _vm._e()])]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Insert : ")]), _c("div", [_c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[NAME]");
      }
    }
  }, [_c("span", [_vm._v("Name")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Rego"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[REGO]");
      }
    }
  }, [_c("span", [_vm._v("Rego")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Excess"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EXCESS]");
      }
    }
  }, [_c("span", [_vm._v("Excess")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated Start Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST START DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated Start Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated End Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST END DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated End Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Shop Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[SHOPNAME]");
      }
    }
  }, [_c("span", [_vm._v("Shop Name")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Attach Image Hyperlink"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[IMAGEUPLOAD]");
      }
    }
  }, [_c("span", [_vm._v("Image Upload Link")])])])]) : _vm._e(), _vm.entity ? _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]) : _vm._e(), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Message Template")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Message Template "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.message)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 45,
      "min-height": 85,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("SMS Template")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("sms-message-templates", {
    ref: "smsMessageTemplates",
    attrs: {
      "enable-save": _vm.enableSave
    },
    on: {
      "save-button": _vm.setEnableSave
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [!_vm.enableSave ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save template"
    },
    on: {
      click: _vm.add
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-20px"
  })]), _c("span", [_vm._v("New")])]) : _vm._e(), _vm.enableSave ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save template"
    },
    on: {
      click: _vm.save
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save mdi-20px"
  })]), _c("span", [_vm._v("Save")])]) : _vm._e(), _vm.enableSave ? _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel changes"
    },
    on: {
      click: _vm.cancel
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save-off mdi-20px"
  })]), _c("span", [_vm._v("Cancel")])]) : _vm._e(), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: _vm.close
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-20px"
  })]), _c("span", [_vm._v("Close")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    attrs: {
      active: _vm.isActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (msg, index) {
    return _c("tr", {
      key: msg.id,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(msg, index, $event);
        }
      }
    }, [_c("td", {
      on: {
        dblclick: function dblclick($event) {
          return _vm.editMessage(msg, index);
        }
      }
    }, [_vm._v(_vm._s(msg.message))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        "data-tooltip": "Click to delete"
      },
      on: {
        click: function click($event) {
          return _vm.deleteMessage(msg.id, index, msg.message);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2), _vm.isEnableSave ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message :")]), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }, {
      name: "model",
      rawName: "v-model",
      value: _vm.message,
      expression: "message"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": !_vm.isMessageEntered
    },
    attrs: {
      id: "message",
      placeholder: "Enter New Message Here...",
      maxlength: "2000"
    },
    domProps: {
      value: _vm.message
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.message = $event.target.value;
      }, _vm.enterMessage]
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("span", {
    staticClass: "help"
  }, [_vm._v(_vm._s(_vm.message.length) + "/8000")]), !_vm.isMessageEntered && _vm.isEnableSave ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Message is required.")]) : _vm._e()])]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Insert : ")]), _c("div", [_c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[NAME]");
      }
    }
  }, [_c("span", [_vm._v("Name")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Rego"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[REGO]");
      }
    }
  }, [_c("span", [_vm._v("Rego")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Excess"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EXCESS]");
      }
    }
  }, [_c("span", [_vm._v("Excess")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated Start Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST START DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated Start Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Estimated End Date"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[EST END DATE]");
      }
    }
  }, [_c("span", [_vm._v("Estimated End Date")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Add Shop Name"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[SHOPNAME]");
      }
    }
  }, [_c("span", [_vm._v("Shop Name")])]), _vm._v("  "), _c("button", {
    staticClass: "button is-small is-rounded is-outlined is-info tooltip",
    attrs: {
      "data-tooltip": "Attach Image Hyperlink"
    },
    on: {
      click: function click($event) {
        return _vm.insertTag("[IMAGEUPLOAD]");
      }
    }
  }, [_c("span", [_vm._v("Image Upload Link")])])])]) : _vm._e(), _vm.entity ? _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]) : _vm._e(), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Email Template")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Email Template "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.message)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 45,
      "min-height": 85,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Email Template")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("vue-email-message-templates", {
    ref: "emailMessageTemplates",
    attrs: {
      "enable-save": _vm.enableSave
    },
    on: {
      "save-button": _vm.setEnableSave
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [!_vm.enableSave ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save template"
    },
    on: {
      click: _vm.add
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-20px"
  })]), _c("span", [_vm._v("New")])]) : _vm._e(), _vm.enableSave ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save template"
    },
    on: {
      click: _vm.save
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save mdi-20px"
  })]), _c("span", [_vm._v("Save")])]) : _vm._e(), _vm.enableSave ? _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel changes"
    },
    on: {
      click: _vm.cancel
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save-off mdi-20px"
  })]), _c("span", [_vm._v("Cancel")])]) : _vm._e(), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: _vm.close
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-20px"
  })]), _c("span", [_vm._v("Close")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "fixed-grid has-12-cols",
    class: {
      "quote-comms-licence-expired": _vm.$licenceExpired
    }
  }, [_vm.value && _vm.customer && _vm.vehicle ? _c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell is-flex pr-0",
    class: {
      "is-col-span-12": _vm.editMaximize,
      "is-col-span-6": _vm.isEmail && !_vm.editMaximize,
      "is-col-span-7": !_vm.isEmail && !_vm.editMaximize
    }
  }, [_c("div", {
    staticClass: "is-flex-grow-1 is-flex"
  }, [_c("article", {
    staticClass: "box detail-page-tile is-flex-grow-1 is-flex is-flex-direction-column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Message")]), _c("div", {
    staticClass: "tabs"
  }, [_c("ul", {
    staticStyle: {
      "margin-top": "12px"
    }
  }, [_c("li", {
    class: {
      "is-active": _vm.activeTab == "SMS",
      "tab-disabled": _vm.activeTab !== "SMS" && _vm.editMaximize
    },
    on: {
      click: function click($event) {
        return _vm.setActiveTab("SMS");
      }
    }
  }, [_c("a", [_c("span", [_vm._m(0), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.smsTotalCount,
      expression: "smsTotalCount"
    }],
    staticClass: "has-badge-info has-badge-rounded has-badge-medium",
    class: {
      "has-new-content": _vm.smsUnreadCount > 0
    },
    attrs: {
      "data-badge": _vm.smsTotalCount
    }
  })])])]), _vm.isShowWhatsApp ? _c("li", {
    class: {
      "is-active": _vm.activeTab == "WhatsApp",
      "tab-disabled": _vm.activeTab !== "WhatsApp" && _vm.editMaximize
    },
    on: {
      click: function click($event) {
        return _vm.setActiveTab("WhatsApp");
      }
    }
  }, [_c("a", [_c("span", [_vm._m(1), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.whatsAppTotalCount,
      expression: "whatsAppTotalCount"
    }],
    staticClass: "has-badge-info has-badge-rounded has-badge-medium",
    class: {
      "has-new-content": _vm.whatsAppUnreadCount > 0
    },
    attrs: {
      "data-badge": _vm.whatsAppTotalCount
    }
  })])])]) : _vm._e(), _c("li", {
    class: {
      "is-active": _vm.activeTab == "Email",
      "tab-disabled": _vm.activeTab !== "Email" && _vm.editMaximize
    },
    on: {
      click: function click($event) {
        return _vm.setActiveTab("Email");
      }
    }
  }, [_c("a", [_c("span", [_vm._m(2), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.emailTotalCount,
      expression: "emailTotalCount"
    }],
    staticClass: "has-badge-info has-badge-rounded has-badge-medium",
    class: {
      "has-new-content": _vm.emailUnreadCount > 0
    },
    attrs: {
      "data-badge": _vm.emailTotalCount
    }
  })])])])])]), _c("div", {
    staticClass: "is-flex-grow-1 is-flex is-flex-direction-column"
  }, [_vm.isEmail ? _c("div", {
    staticClass: "is-flex-grow-1"
  }, [_vm.isEmail && _vm.isEmailerActive ? _c("quote-email", {
    attrs: {
      quote: _vm.entity,
      "enable-send": true,
      "enable-attach": true,
      "reply-to-message-id": _vm.replyToMessageId,
      "reply-to-email": _vm.replyToEmail,
      "selected-attachment-email-id": _vm.selectedAttachmentEmailId,
      "is-incoming": _vm.isIncoming,
      "msg-details": _vm.msgDetails
    },
    on: {
      sent: _vm.emailSent,
      resetEmail: _vm.resetEmail,
      close: _vm.closeAttachmentModel,
      toggleEditMaximize: _vm.toggleEditMaximize,
      emailDataChanged: _vm.updateEmailPreview
    }
  }) : _vm._e()], 1) : _c("div", {
    staticClass: "is-flex-grow-1 is-flex is-flex-direction-column is-overflow-hidden"
  }, [_c("div", {
    staticClass: "is-flex-grow-1 is-flex is-flex-direction-column is-overflow-y-auto"
  }, [_c("article", {
    staticClass: "box detail-page-tile"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("To")]), _c("div", {
    staticClass: "control"
  }, [_c("phone-no-autocomplete", {
    attrs: {
      "quote-id": _vm.value.quoteId,
      disabled: _vm.$licenceExpired
    },
    on: {
      select: _vm.onPhoneNoSelected
    },
    model: {
      value: _vm.msgDetails.mobile,
      callback: function callback($$v) {
        _vm.$set(_vm.msgDetails, "mobile", $$v);
      },
      expression: "msgDetails.mobile"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-align-items-end"
  }, [_c("div", {
    staticClass: "is-flex-grow-1 mr-3"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Template")]), _c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      "track-by": "message",
      label: "message",
      placeholder: "Select Template",
      options: _vm.templates,
      loading: _vm.isTemplateLoading,
      searchable: true,
      "allow-empty": true,
      "options-limit": _vm.templateFilter.pageSize,
      disabled: _vm.$licenceExpired
    },
    on: {
      select: _vm.selectTemplate
    },
    scopedSlots: _vm._u([{
      key: "singleLabel",
      fn: function fn(_ref) {
        var option = _ref.option;
        return [_c("span", [_vm._v(_vm._s(_vm.truncateTemplateLabel(option && option.message)))])];
      }
    }, {
      key: "option",
      fn: function fn(_ref2) {
        var option = _ref2.option;
        return [_c("span", [_vm._v(_vm._s(_vm.truncateTemplateLabel(option && option.message)))])];
      }
    }], null, false, 1970849366),
    model: {
      value: _vm.selectedTemplate,
      callback: function callback($$v) {
        _vm.selectedTemplate = $$v;
      },
      expression: "selectedTemplate"
    }
  })], 1)]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Edit message template",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        _vm.isSmsTemplateModalActive = true;
      }
    }
  }, [_vm._m(3), _c("span", [_vm._v("Edit")])])])]), _vm.approvedTemplate ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("span", {
    staticClass: "is-size-7 help has-text-grey-light"
  }, [_vm._v("Approved Template")]), _c("div", {
    staticClass: "box"
  }, [_vm._v(" " + _vm._s(_vm.approvedTemplate) + " ")])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message")]), _c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.msgDetails.message,
      expression: "msgDetails.message"
    }],
    staticClass: "textarea",
    attrs: {
      disabled: _vm.$licenceExpired,
      rows: "8",
      maxlength: _vm.maxLength,
      placeholder: "Text message"
    },
    domProps: {
      value: _vm.msgDetails.message
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.msgDetails, "message", $event.target.value);
      }
    }
  })]), _c("span", {
    staticClass: "help",
    class: {
      "has-text-danger": _vm.msgDetails.message.length > _vm.maxLength * 0.9,
      "has-text-warning": _vm.msgDetails.message.length > _vm.maxLength * 0.7
    }
  }, [_vm._v(" " + _vm._s(_vm.msgDetails.message.length) + "/" + _vm._s(_vm.maxLength) + " ")])]), _c("div", {
    staticClass: "is-flex is-justify-content-flex-end"
  }, [_c("button", {
    staticClass: "button is-success tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.getToolTip(),
      disabled: _vm.isDisabledSend || _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        return _vm.send();
      },
      sent: _vm.emailSent
    }
  }, [_vm._m(4), _c("span", [_vm._v("Send")])])])])])])])])])]), !_vm.editMaximize ? _c("div", {
    staticClass: "cell",
    class: {
      "is-col-span-6": _vm.isEmail && !_vm.editMaximize,
      "is-col-span-5": !_vm.isEmail && !_vm.editMaximize
    }
  }, [_c("article", {
    staticClass: "box detail-page-tile is-flex-grow-1 is-flex is-flex-direction-column",
    staticStyle: {
      height: "calc(100vh - 8rem)"
    }
  }, [_c("p", {
    staticClass: "title"
  }, [_vm.isEmail ? _c("span", [_vm._v(" Email Log ")]) : _vm.isWhatsApp ? _c("span", [_vm._v(" WhatsApp Log ")]) : _c("span", [_vm._v(" SMS Log ")])]), _c("div", {
    staticClass: "message-preview is-background-white pl-2 is-flex-grow-1 is-flex is-flex-direction-column is-overflow-hidden"
  }, [_vm.isMessagesLoading ? _c("div", {
    staticClass: "has-text-centered p-4"
  }, [_vm._m(5), _c("p", {
    staticClass: "mt-2"
  }, [_vm._v("Loading messages...")])]) : _c("div", {
    ref: "messageContainer",
    staticClass: "is-overflow-y-auto py-2 is-flex-grow-1",
    staticStyle: {
      "scroll-behavior": "smooth"
    }
  }, [_c("div", {
    staticClass: "pr-3"
  }, [_vm._l(_vm.messages, function (message) {
    return _c("div", {
      key: message.id,
      staticClass: "is-flex mb-4 is-full-width",
      class: {
        "is-justify-content-flex-start": message.isIncoming,
        "is-justify-content-flex-end": message.isOutgoing
      }
    }, [_c("div", {
      staticClass: "message-wrapper",
      style: _vm.isEmail ? message.isIncoming ? "width: 90%; margin-right: 10%;" : "width: 90%; margin-left: 10%;" : "min-width: 50%; max-width: 85%; width: auto;"
    }, [_c("div", {
      staticClass: "is-flex is-justify-content-space-between is-align-items-center mb-1 px-1"
    }, [_c("div", {
      staticClass: "is-size-7 has-text-weight-semibold has-text-grey"
    }, [_vm.isEmail ? _c("span", [message.isIncoming ? _c("span", [_vm._v(" " + _vm._s(message.sender || "Unknown") + " ")]) : _c("span", [_vm._v(" " + _vm._s(message.recipients) + " ")])]) : _c("span", [message.isIncoming ? _c("span", [_vm._v(" " + _vm._s(message.sender ? _vm.formatPhoneNumber(message.sender) : "Unknown") + " ")]) : _c("span", [_vm._v(" " + _vm._s(message.recipients ? _vm.formatPhoneNumber(message.recipients) : "Unknown") + " ")])])]), _c("div", {
      staticClass: "is-size-7 has-text-grey is-flex is-align-items-center",
      staticStyle: {
        gap: "2px"
      }
    }, [_vm.isEmail ? [_c("span", {
      staticClass: "material-symbols-rounded ls-size-7 has-text-weight-semibold",
      style: _vm.getEmailStatusIconStyle(message)
    }, [_vm._v(_vm._s(_vm.getEmailStatusIconName(message)))]), _c("span", {
      staticClass: "is-italic mr-1"
    }, [_vm._v(_vm._s(_vm.getEmailStatusLabel(message)))])] : _vm._e(), _c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(message.createdDate, _vm.$userInfo.locale)))])], 2)]), _c("div", {
      staticClass: "message-bubble has-background-white p-4 mb-2 is-shadowless has-border has-radius-normal is-relative",
      class: [_vm.getMessageBubbleClass(message), {
        "unread-animation": !message.isRead
      }]
    }, [_c("div", {
      staticClass: "is-flex is-align-items-center is-absolute",
      staticStyle: {
        top: "8px",
        right: "8px",
        gap: "2px",
        opacity: "0.7"
      }
    }, [_vm.isEmail && message.isOutgoing ? _c("span", {
      staticClass: "icon tooltip is-tooltip-right is-tooltip-multiline mr-1",
      class: {
        "is-clickable": _vm.hasFailureDetail(message),
        "is-tooltip-danger": _vm.emailStatus(message) === "failed"
      },
      attrs: {
        "data-tooltip": _vm.getEmailStatus(message)
      },
      on: {
        click: function click($event) {
          return _vm.openMessageModal(message);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-16px",
      class: _vm.getEmailStatusIndicator(message)
    })]) : _vm._e(), _vm.isEmail ? _c("span", {
      staticClass: "icon tooltip is-tooltip-right is-clickable mr-1",
      attrs: {
        "data-tooltip": "View Email"
      },
      on: {
        click: function click($event) {
          return _vm.viewEmail(message);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-16px mdi-email-open"
    })]) : _vm._e(), _vm.isEmail ? _c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: message.attachments,
        expression: "message.attachments"
      }],
      staticClass: "icon tooltip is-tooltip-right is-clickable mr-1",
      attrs: {
        "data-tooltip": "Attachment"
      },
      on: {
        click: function click($event) {
          return _vm.openAttachmentModel(message.id, message.isIncoming);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-16px mdi-attachment"
    })]) : _vm._e(), _vm.isEmail ? _c("span", {
      staticClass: "icon tooltip is-tooltip-right is-clickable",
      attrs: {
        "data-tooltip": "Reply"
      },
      on: {
        click: function click($event) {
          return _vm.replyTo(message);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-16px",
      class: [{
        "mdi-reply-outline": !_vm.isSelectedReplyToMessage(message.messageId)
      }, {
        "mdi-reply": _vm.isSelectedReplyToMessage(message.messageId)
      }]
    })]) : _vm._e()]), _c("div", {
      staticClass: "content is-size-6 has-text-weight-normal"
    }, [_vm.isEmail && message.subject ? _c("div", {
      staticClass: "has-text-weight-semibold mb-1 is-size-7"
    }, [_vm._v(" " + _vm._s(message.subject) + " ")]) : _vm._e(), _c("div", {
      staticClass: "has-text-pre-wrap message-text-content"
    }, [_vm._v(_vm._s(_vm.truncate(message.message, 100)))])])])])]);
  }), !_vm.isMessagesLoading && (_vm.isEmail ? _vm.msgDetails.message.trim() || _vm.msgDetails.emailSubject.trim() || _vm.msgDetails.emailTo.trim() : _vm.msgDetails.message.trim() || _vm.msgDetails.mobile) ? _c("div", {
    staticClass: "is-flex mb-4 is-full-width",
    class: {
      "is-justify-content-flex-end": true
    },
    staticStyle: {
      opacity: "0.6"
    }
  }, [_c("div", {
    staticClass: "message-wrapper",
    style: _vm.isEmail ? "width: 90%; margin-left: 10%;" : "min-width: 50%; max-width: 85%; width: auto;"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between is-align-items-center mb-1 px-1"
  }, [_c("div", {
    staticClass: "is-size-7 has-text-weight-semibold has-text-grey"
  }, [_vm.isEmail ? _c("span", [_vm._v(" You → " + _vm._s(_vm.msgDetails.emailTo || "No recipient") + " ")]) : _c("span", [_vm._v(" " + _vm._s(_vm.formatPhoneNumber(_vm.msgDetails.mobile)) + " ")])]), _c("div", {
    staticClass: "is-size-7 has-text-grey is-flex is-align-items-center",
    staticStyle: {
      gap: "2px"
    }
  }, [_vm.isEmail ? _c("span", {
    staticClass: "material-symbols-rounded ls-size-7 has-text-weight-semibold",
    staticStyle: {
      color: "#98A6B3",
      "font-variation-settings": "'FILL' 1, 'wght' 600, 'GRAD' 0, 'opsz' 20",
      "font-style": "normal"
    }
  }, [_vm._v("drafts")]) : _vm._e(), _c("span", {
    staticClass: "is-italic"
  }, [_vm._v("Draft")])])]), _c("div", {
    staticClass: "message-bubble p-4 mb-2 is-shadowless has-border has-radius-normal is-relative preview-bubble",
    class: [{
      "email-bubble": _vm.isEmail
    }, _vm.getPreviewLogBubbleClass()]
  }, [_c("div", {
    staticClass: "content is-size-6 has-text-weight-normal"
  }, [_vm.isEmail ? _c("div", [!_vm.msgDetails.emailSubject.trim() && !_vm.msgDetails.emailTo.trim() && !_vm.msgDetails.message.trim() ? _c("div", {
    staticClass: "has-text-centered p-2"
  }, [_vm._m(6), _c("span", {
    staticClass: "is-size-7 is-italic"
  }, [_vm._v("Start composing email to show preview...")])]) : _c("div", [_c("div", {
    staticClass: "email-header-preview mb-3"
  }, [_vm.msgDetails.emailTo.trim() ? _c("div", {
    staticClass: "mb-1"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold is-size-7"
  }, [_vm._v("To:")]), _c("span", {
    staticClass: "is-size-7 ml-1"
  }, [_vm._v(_vm._s(_vm.msgDetails.emailTo))])]) : _vm._e(), _vm.msgDetails.emailCc.trim() ? _c("div", {
    staticClass: "mb-1"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold is-size-7"
  }, [_vm._v("Cc:")]), _c("span", {
    staticClass: "is-size-7 ml-1"
  }, [_vm._v(_vm._s(_vm.msgDetails.emailCc))])]) : _vm._e(), _vm.msgDetails.emailBcc.trim() ? _c("div", {
    staticClass: "mb-1"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold is-size-7"
  }, [_vm._v("Bcc:")]), _c("span", {
    staticClass: "is-size-7 ml-1"
  }, [_vm._v(_vm._s(_vm.msgDetails.emailBcc))])]) : _vm._e(), _vm.msgDetails.emailSubject.trim() ? _c("div", {
    staticClass: "mb-2"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold is-size-7"
  }, [_vm._v("Subject:")]), _c("span", {
    staticClass: "is-size-7 ml-1 has-text-weight-semibold"
  }, [_vm._v(_vm._s(_vm.msgDetails.emailSubject))])]) : _vm._e()]), _vm.msgDetails.emailTo.trim() || _vm.msgDetails.emailSubject.trim() ? _c("hr", {
    staticClass: "my-2 has-background-grey-light",
    staticStyle: {
      height: "1px",
      "max-width": "100%",
      overflow: "hidden",
      "margin-left": "0",
      "margin-right": "0"
    }
  }) : _vm._e(), _vm.msgDetails.message.trim() ? _c("div", {
    staticClass: "is-italic has-text-pre-wrap message-text-content",
    staticStyle: {
      opacity: "0.8"
    }
  }, [_vm._v(" " + _vm._s(_vm.getProcessedMessage()) + " ")]) : _vm.msgDetails.emailTo.trim() || _vm.msgDetails.emailSubject.trim() ? _c("div", {
    staticClass: "has-text-centered p-2"
  }, [_c("span", {
    staticClass: "is-size-7 is-italic"
  }, [_vm._v("Email body is empty...")])]) : _vm._e()])]) : _c("div", [!_vm.msgDetails.message.trim() ? _c("div", {
    staticClass: "has-text-centered p-2"
  }, [_vm._m(7), _c("span", {
    staticClass: "is-size-7 is-italic"
  }, [_vm._v("Start typing to show preview...")])]) : _c("div", {
    staticClass: "is-italic has-text-pre-wrap message-text-content",
    staticStyle: {
      opacity: "0.8"
    }
  }, [_vm._v(" " + _vm._s(_vm.getProcessedMessage()) + " ")])])])])])]) : _vm._e()], 2)])]), _c("quote-email-viewer-modal", {
    attrs: {
      active: _vm.isViewEmail,
      "show-icon": true,
      email: _vm.viewMessage
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isViewEmail = $event;
      },
      cancel: _vm.closeViewEmail,
      close: _vm.closeViewEmail
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Email")])])], 1)]) : _vm._e(), _vm.isSmsTemplateModalActive ? _c("sms-template-modal", {
    attrs: {
      active: _vm.isSmsTemplateModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSmsTemplateModalActive = $event;
      },
      close: _vm.closeSmsTemplateModal
    }
  }) : _vm._e(), _c("base-modal-ex", {
    attrs: {
      active: _vm.isMessageModalActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isMessageModalActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": true
    }
  }, [_c("span", [_vm._v("Email Delivery Failed Message")])])]), _c("section", {
    staticClass: "modal-card-body p-0 m-0",
    staticStyle: {
      position: "relative"
    }
  }, [_c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_c("div", {
    domProps: {
      innerHTML: _vm._s(_vm.messageModalMessage)
    }
  })])])])])])]), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }), _c("div", {
    staticStyle: {
      "align-self": "flex-end"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.closeMessageModal();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Close")])])])])])])], 1) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "has-badge-child-offset3"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-message-text mdi-20px",
    attrs: {
      "aria-hidden": "true"
    }
  })]), _c("span", {}, [_vm._v("SMS")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "has-badge-child-offset3"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-whatsapp mdi-20px icon-green"
  })]), _c("span", {}, [_vm._v("WhatsApp")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "has-badge-child-offset3"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-email mdi-20px",
    attrs: {
      "aria-hidden": "true"
    }
  })]), _c("span", {}, [_vm._v("Email")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-20px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-message-text mdi-20px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-large"
  }, [_c("i", {
    staticClass: "mdi mdi-loading mdi-spin mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-flex is-justify-content-center is-align-items-center mb-2",
    staticStyle: {
      gap: "4px"
    }
  }, [_c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out",
      "animation-delay": "-0.32s"
    }
  }), _c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out",
      "animation-delay": "-0.16s"
    }
  }), _c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out"
    }
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-flex is-justify-content-center is-align-items-center mb-2",
    staticStyle: {
      gap: "4px"
    }
  }, [_c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out",
      "animation-delay": "-0.32s"
    }
  }), _c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out",
      "animation-delay": "-0.16s"
    }
  }), _c("span", {
    staticClass: "has-background-grey is-inline-block",
    staticStyle: {
      width: "6px",
      height: "6px",
      "border-radius": "50%",
      animation: "typing-bounce 1.4s infinite ease-in-out"
    }
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);




var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.isActive ? _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "min-height": 90,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _vm._t("text-title")], 2)]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", [_vm.innerEmailer && _vm.isActiveImageSelect && !_vm.isDocAttachActive ? _c("image-select", {
    attrs: {
      "quote-id": _vm.innerEmailer.assetId,
      "quote-ids": _vm.attachmentOptions.selectedQuotes.map(function (q) {
        return q.value;
      }),
      subtitle: "Select images to attach"
    },
    on: {
      input: _vm.getSelectedImage
    },
    model: {
      value: _vm.imagesSelectedForAttachment,
      callback: function callback($$v) {
        _vm.imagesSelectedForAttachment = $$v;
      },
      expression: "imagesSelectedForAttachment"
    }
  }) : _vm._e(), _vm.innerEmailer && _vm.isDocAttachActive && !_vm.isActiveImageSelect ? _c("attachment-select", {
    attrs: {
      "quote-id": _vm.innerEmailer.assetId,
      subtitle: "Select documents to attach"
    },
    on: {
      input: _vm.onDocumentsSelected
    },
    model: {
      value: _vm.documentsSelectedForAttachment,
      callback: function callback($$v) {
        _vm.documentsSelectedForAttachment = $$v;
      },
      expression: "documentsSelectedForAttachment"
    }
  }) : _vm._e(), _vm.isActiveAttachment ? _c("quote-email-attachments", {
    attrs: {
      "quote-id": _vm.innerEmailer.assetId,
      "email-id": _vm.innerSelectedAttachmentEmailId,
      "is-incoming": _vm.isIncoming
    },
    on: {
      close: _vm.closeAttachmentsModel
    }
  }) : _vm._e()], 1)]), _c("footer", {
    staticClass: "modal-card-foot",
    style: "justify-content: flex-".concat(_vm.buttonLocation)
  }, [_vm.isActiveImageSelect && !_vm.isDocAttachActive ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Done",
      disabled: !_vm.canAttach
    },
    on: {
      click: function click($event) {
        return _vm.ok();
      }
    }
  }, [_c("span", [_vm._v("Ok")])]) : _vm._e(), _vm.isDocAttachActive && !_vm.isActiveImageSelect ? _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Done",
      disabled: !_vm.documentsSelectedForAttachment.length
    },
    on: {
      click: function click($event) {
        return _vm.ok();
      }
    }
  }, [_c("span", [_vm._v("Ok")])]) : _vm._e(), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": _vm.cancelInWording,
      disabled: _vm.cancelDisabled
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_vm._v(_vm._s(_vm.cancelInWording))])])]) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", {
    staticClass: "tile is-child box detail-page-tile"
  }, [_c("div", [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      "track-by": "message",
      label: "message",
      placeholder: "Select Template",
      options: _vm.templates,
      loading: _vm.isTemplateLoading,
      searchable: true,
      "allow-empty": true,
      "options-limit": _vm.templateFilter.pageSize,
      disabled: _vm.$licenceExpired
    },
    on: {
      select: _vm.selectTemplate
    },
    model: {
      value: _vm.selectedTemplate,
      callback: function callback($$v) {
        _vm.selectedTemplate = $$v;
      },
      expression: "selectedTemplate"
    }
  })], 1)])])])]), _c("hr"), _c("quote-email-modal", {
    attrs: {
      emailer: _vm.emailer,
      "quote-ids": _vm.quoteIds,
      "enable-attach": _vm.enableAttach,
      "reply-to-message-id": _vm.innerReplyToEmail.replyToMessageId,
      "reply-to-sender-emails": _vm.replyToSenderEmails,
      "reply-to-email-ccs": _vm.replyToEmailCcs,
      "reply-to-email-bccs": _vm.replyToEmailBccs,
      "email-subject": _vm.innerReplyToEmailSubject,
      "email-message": _vm.innerReplyToEmailMessage
    },
    on: {
      "update:emailer": function updateEmailer($event) {
        _vm.emailer = $event;
      },
      resetEmail: _vm.resetEmail,
      "new-email": _vm.newEmailInput,
      sent: _vm.sent,
      discard: _vm.discardEmail
    }
  }, [_c("template", {
    slot: "template-actions"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Edit message template",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        _vm.isEmailTemplateModalActive = true;
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-20px"
  })]), _c("span", [_vm._v("Edit Template")])])])], 2), _c("quote-communication-email-modal", {
    attrs: {
      active: _vm.isAttachmentModalActive,
      "show-icon": true,
      "attach-disabled": false,
      "cancel-disabled": false,
      emailer: _vm.emailer,
      "selected-attachment-email-id": _vm.selectedAttachmentEmailId,
      "is-incoming": _vm.isIncoming
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isAttachmentModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.closeAttachModal();
      },
      cancel: function cancel($event) {
        return _vm.closeAttachModal();
      },
      close: function close($event) {
        return _vm.closeAttachModal();
      }
    },
    model: {
      value: _vm.selectedImages,
      callback: function callback($$v) {
        _vm.selectedImages = $$v;
      },
      expression: "selectedImages"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Attachment")])]), _vm.isEmailTemplateModalActive ? _c("vue-email-template-modal", {
    attrs: {
      active: _vm.isEmailTemplateModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEmailTemplateModalActive = $event;
      },
      close: _vm.closeTemplateModal
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Template")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "min-height": 70,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Attachment Viewer")])])]), _c("section", {
    staticClass: "modal-card-body p-0 m-0"
  }, [_c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0"
  }, [_c("figure", {
    staticClass: "image"
  }, [_c("LazyImage", {
    staticClass: "image",
    staticStyle: {
      "object-fit": "contain"
    },
    attrs: {
      src: _vm.attachment.externalStorageURL
    }
  })], 1)])])])]), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Download"
    },
    on: {
      click: function click() {
        _vm.downloadModifiedDocument();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-format-color-marker-cancel mdi-18px"
  })]), _c("span", [_vm._v("Download")])])]), _c("div", {
    staticStyle: {
      "align-self": "flex-end"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Close")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "columns is-multiline mt-3 mr-2"
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "column"
  }, [_vm._v(" Please select category: "), _c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.attachmentCategory,
      expression: "attachmentCategory"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.attachmentCategory = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, _vm._l(_vm.attachmentCategories, function (m) {
    return _c("option", {
      key: m.quoteAttachmentCategoryId,
      domProps: {
        value: m.quoteAttachmentCategoryId
      }
    }, [_vm._v(_vm._s(m.name))]);
  }), 0)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip ml-2",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Copy to quote"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.copyAttachmentToQuote(true);
      }
    }
  }, [_vm._m(0)])]), _c("div", {
    staticClass: "column is-narrow",
    class: [{
      "is-full": !_vm.hasSelected
    }]
  }, [_c("p", {
    staticClass: "buttons is-justify-content-right"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isIncoming,
      expression: "isIncoming"
    }],
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Select all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(true);
      }
    }
  }, [_vm._m(1)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Deselect all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(false);
      }
    }
  }, [_vm._m(2)])])])]), _c("div", [_c("div", {
    staticClass: "columns is-multiline"
  }, _vm._l(_vm.innerAttachments, function (attachment) {
    return _c("div", {
      key: attachment.quoteEmailAttachmentId,
      staticClass: "column is-1 m-0 p-1"
    }, [_c("div", {
      staticClass: "is-clickable is-unselectable py-0 px-0",
      class: "has-background-".concat(_vm.$theme.name)
    }, [_c("div", {
      staticClass: "columns is-gapless is-relative"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.isIncoming,
        expression: "isIncoming"
      }],
      staticClass: "button is-primary is-small px-1 m-0",
      class: !attachment.isSelected ? ["is-light", "is-light-btn-".concat(_vm.$theme.name)] : "",
      staticStyle: {
        position: "absolute",
        top: "0",
        left: "0",
        "z-index": "1"
      },
      on: {
        click: function click() {
          attachment.isSelected = !attachment.isSelected;
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-check",
      class: {
        "": attachment.isSelected,
        "has-text-grey-light": !attachment.isSelected
      }
    })]), _c("div", {
      staticClass: "column is-full is-clipped"
    }, [_c("figure", {
      staticClass: "image is-3by4 is-fullwidth is-vcentered",
      on: {
        click: function click($event) {
          return _vm.viewImage(attachment, attachment.isImage);
        }
      }
    }, [attachment.isImage ? _c("img", {
      staticStyle: {
        "object-fit": "cover"
      },
      attrs: {
        src: attachment.externalStorageURL
      }
    }) : _vm._e(), attachment.isPdf ? _c("img", {
      attrs: {
        alt: "Vue logo",
        src: __webpack_require__(/*! ../../../assets/images/attachment-pdf.png */ "./src/assets/images/attachment-pdf.png")
      }
    }) : _vm._e(), !attachment.isImage && !attachment.isPdf ? _c("img", {
      attrs: {
        alt: "Vue logo",
        src: __webpack_require__(/*! ../../../assets/images/attachment-doc.png */ "./src/assets/images/attachment-doc.png")
      }
    }) : _vm._e()]), _c("div", {
      staticClass: "columns is-multiline column is-clipped p-0 m-0"
    }, [_c("div", {
      staticClass: "column is-full p-0 m-0",
      staticStyle: {
        overflow: "hidden",
        "text-overflow": "ellipsis",
        "font-weight": "bold",
        "white-space": "nowrap"
      },
      attrs: {
        tooltip: attachment.filename,
        title: attachment.filename
      }
    }, [_vm._v(_vm._s(attachment.filename) + ")")])])])])]), _vm.isViewerModalOpen ? _c("quote-email-attachment-viewer-modal", {
      attrs: {
        active: _vm.isViewerModalOpen,
        attachment: _vm.viewAttachment,
        "quote-id": _vm.quoteId,
        "is-incoming": _vm.isIncoming
      },
      on: {
        cancel: function cancel($event) {
          return _vm.viewImage(null);
        }
      }
    }) : _vm._e()], 1);
  }), 0)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-content-copy mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "email-container"
  }, [_c("div", {
    staticClass: "email-content"
  }, [!_vm.isImageAttachActive && !_vm.isDocAttachActive ? _c("vue-email", {
    ref: "emailer",
    attrs: {
      value: _vm.emailer,
      "asset-id": _vm.assetId,
      "quote-image-attachments": _vm.selectedImages,
      "quote-attachments": _vm.selectedDocuments,
      "reply-to-message-id": _vm.replyToMessageId,
      "to-emails": _vm.replyToSenderEmails,
      "cc-emails": _vm.replyToEmailCcs,
      "bcc-emails": _vm.replyToEmailBccs,
      subject: _vm.emailSubject,
      message: _vm.emailMessage,
      "is-show-cc-bcc": !!_vm.replyToEmailCcs.length || !!_vm.replyToEmailBccs.length,
      disabled: _vm.$licenceExpired
    },
    on: {
      "new-email": _vm.newEmailInput,
      "attachments-updated": _vm.handleAttachmentsUpdate,
      "validation-changed": _vm.handleValidationChanged,
      "sending-changed": function sendingChanged($event) {
        _vm.isSending = $event;
      },
      input: function input($event) {
        return _vm.$emit("update:emailer", $event);
      },
      sent: _vm.sent
    }
  }) : _vm._e(), _c("base-modal-ex", {
    attrs: {
      active: _vm.isImageAttachActive,
      "has-modal-card": true,
      "animation-in": "fadeIn",
      "animation-out": "fadeOut",
      "min-width": 60
    },
    on: {
      close: _vm.closeImageModal
    }
  }, [_c("div", {
    staticClass: "modal-card"
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Select Images")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("image-select", {
    attrs: {
      "quote-id": _vm.assetId,
      "quote-ids": _vm.computeQuoteIds,
      subtitle: "Select images to attach"
    },
    on: {
      input: _vm.onImagesSelected
    },
    model: {
      value: _vm.selectedImages,
      callback: function callback($$v) {
        _vm.selectedImages = $$v;
      },
      expression: "selectedImages"
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot is-justify-content-flex-end"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.closeImageModal
    }
  }, [_vm._v(" Cancel ")]), _c("button", {
    staticClass: "button is-success",
    on: {
      click: _vm.confirmImageSelection
    }
  }, [_vm._v(" Done ")])])])]), _c("base-modal-ex", {
    attrs: {
      active: _vm.isDocAttachActive,
      "has-modal-card": true,
      "min-width": 60,
      "animation-in": "fadeIn",
      "animation-out": "fadeOut"
    },
    on: {
      close: _vm.closeDocModal
    }
  }, [_c("div", {
    staticClass: "modal-card"
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Select Documents")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("attachment-select", {
    attrs: {
      "quote-id": _vm.assetId,
      subtitle: "Select documents to attach"
    },
    on: {
      input: _vm.onDocumentsSelected
    },
    model: {
      value: _vm.selectedDocuments,
      callback: function callback($$v) {
        _vm.selectedDocuments = $$v;
      },
      expression: "selectedDocuments"
    }
  })], 1), _c("footer", {
    staticClass: "modal-card-foot is-justify-content-flex-end"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.closeDocModal
    }
  }, [_vm._v(" Cancel ")]), _c("button", {
    staticClass: "button is-success",
    on: {
      click: _vm.confirmDocSelection
    }
  }, [_vm._v(" Done ")])])])])], 1), _c("div", {
    staticClass: "email-actions"
  }, [_vm._t("template-actions"), _c("div", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button is-warning tooltip is-tooltip-topright",
    attrs: {
      disabled: !_vm.enableSend || _vm.isSending || _vm.isImageAttachActive || _vm.isDocAttachActive,
      "data-tooltip": "Reset Email"
    },
    on: {
      click: _vm.resetEmail
    }
  }, [_vm._m(0), _c("span", [_vm._v("Reset")])]), _vm.enableAttach ? _c("div", {
    staticClass: "dropdown",
    class: {
      "is-active": _vm.showAttachDropdown
    },
    staticStyle: {
      display: "inline-block"
    }
  }, [_c("button", {
    staticClass: "button is-primary",
    class: {
      tooltip: _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired",
      disabled: _vm.$licenceExpired || _vm.isSending
    },
    on: {
      click: _vm.toggleAttachDropdown
    }
  }, [_vm._m(1)]), _c("div", {
    staticClass: "dropdown-menu",
    staticStyle: {
      left: "-120px",
      right: "auto",
      top: "auto",
      bottom: "100%",
      transform: "translateY(-8px)"
    },
    attrs: {
      role: "menu"
    }
  }, [_c("div", {
    staticStyle: {
      position: "absolute",
      left: "130px",
      bottom: "-8px",
      width: "0",
      height: "0",
      "border-left": "8px solid transparent",
      "border-right": "8px solid transparent",
      "border-top": "8px solid #fff",
      "z-index": "2"
    }
  }), _c("div", {
    staticClass: "dropdown-content"
  }, [_c("a", {
    staticClass: "dropdown-item",
    on: {
      click: _vm.showAttachImage
    }
  }, [_vm._m(2), _vm._v(" Images ")]), _c("a", {
    staticClass: "dropdown-item",
    on: {
      click: _vm.attachDocs
    }
  }, [_vm._m(3), _vm._v(" Documents ")])])])]) : _vm._e(), _c("button", {
    staticClass: "button is-success",
    class: {
      tooltip: _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired",
      disabled: !_vm.enableSend || _vm.isImageAttachActive || _vm.isDocAttachActive || _vm.$licenceExpired || _vm.isSending
    },
    on: {
      click: _vm.sendEmail
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi",
    class: _vm.isSending ? "mdi-loading mdi-spin" : "mdi-send"
  })]), _c("span", [_vm._v("Send")])])])], 2)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-paperclip"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-image-multiple"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-document-outline"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Email")])])]), _c("section", {
    staticClass: "modal-card-body p-0 m-0",
    staticStyle: {
      position: "relative"
    }
  }, [_c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-9 p-3 m-0"
  }, [_vm._v(" From: "), _c("b", [_vm._v(_vm._s(_vm.email.sender))])]), _c("div", {
    staticClass: "column is-3 p-3 m-0 has-text-right"
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatDateTimeLocale(_vm.email.createdDate, _vm.$userInfo.locale)) + " ")])])])])]), _c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_vm._v(" To : "), _c("b", [_vm._v(_vm._s(_vm.email.recipients))])])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.email.cc && _vm.email.cc.length,
      expression: "email.cc && email.cc.length"
    }],
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_vm._v(" Cc : "), _c("b", [_vm._v(_vm._s(_vm.email.cc))])])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.email.bcc && _vm.email.bcc.length,
      expression: "email.bcc && email.bcc.length"
    }],
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_vm._v(" Bcc : "), _c("b", [_vm._v(_vm._s(_vm.email.bcc))])])])])])]), _c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_c("b", [_vm._v(_vm._s(_vm.email.subject))])])])])])]), _c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0"
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-3 m-0"
  }, [_c("div", {
    domProps: {
      innerHTML: _vm._s(_vm.getHtmlMessage())
    }
  })])])])])])]), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }), _c("div", {
    staticStyle: {
      "align-self": "flex-end"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.close();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Close")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("bulma-autocomplete", _vm._b({
    class: ["phone-no-autocomplete", _vm.classProp],
    attrs: {
      id: "phone-no-autocomplete",
      data: _vm.items,
      field: "phoneNo",
      value: _vm.innerValue,
      "keep-first": true,
      placeholder: "Search name/mobile",
      expanded: true
    },
    on: {
      input: _vm.getCustomerInsurerPhoneNo,
      select: _vm.select
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [props.option.isGroupHeader ? _c("div", {
          staticClass: "is-flex is-justify-content-space-between is-align-items-center custom-header p-1",
          class: "has-background-".concat(_vm.$theme.name, " has-text-invert")
        }, [_c("div", {
          staticClass: "is-size-8 has-text-weight-bold"
        }, [_vm._v(" " + _vm._s(props.option.groupName) + " ")])]) : _vm._e(), !props.option.isGroupHeader ? _c("div", {
          staticClass: "is-flex is-justify-content-space-between is-align-items-center"
        }, [_c("div", [_c("strong", [_vm._v(_vm._s(props.option.phoneNo))]), props.option.fullName ? _c("span", [_vm._v(" - " + _vm._s(props.option.fullName))]) : _vm._e()]), _c("div", {
          staticClass: "is-pulled-right"
        }, [props.option.groupName ? _c("span", {
          staticClass: "tag",
          class: {
            "is-success": props.option.groupName === "Customer",
            "is-info": props.option.groupName === "Insurer"
          }
        }, [_vm._v(" " + _vm._s(props.option.groupName) + " ")]) : _vm._e()])]) : _vm._e()];
      }
    }]),
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }, "bulma-autocomplete", _vm.$attrs, false));
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.email-container[data-v-cc2d61fe] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  gap: 1rem;\n  border-radius: 6px;\n  padding: 0rem;\n}\n.email-actions[data-v-cc2d61fe] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-bottom: 1rem;\n}\n.email-content[data-v-cc2d61fe] {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n.buttons[data-v-cc2d61fe] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  gap: 0.5rem;\n}\n.modal-card[data-v-cc2d61fe] {\n  width: 100% !important;\n  margin: 0;\n}\n.modal-card-head[data-v-cc2d61fe] {\n  width: 100% !important;\n}\n.modal-card-body[data-v-cc2d61fe] {\n  overflow-y: auto;\n  padding: 1.5rem;\n  width: 100% !important;\n}\n.dropdown-menu[data-v-cc2d61fe] {\n  min-width: 200px;\n}\n.dropdown-item[data-v-cc2d61fe] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.5rem 1rem;\n  cursor: pointer;\n}\n.dropdown-item .icon[data-v-cc2d61fe] {\n  margin-right: 0.5rem;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-2d1c5fc0] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-798ae4b4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-comms-licence-expired .control:has(> input:disabled),\n.quote-comms-licence-expired .control:has(> textarea:disabled),\n.quote-comms-licence-expired .control:has(> .multiselect--disabled),\n.quote-comms-licence-expired .control:has(> .vue-input-tag-wrapper.read-only) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-comms-licence-expired .control:has(> input:disabled):hover::before,\n.quote-comms-licence-expired .control:has(> textarea:disabled):hover::before,\n.quote-comms-licence-expired .control:has(> .multiselect--disabled):hover::before,\n.quote-comms-licence-expired .control:has(> .vue-input-tag-wrapper.read-only):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  left: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "/* Essential animations and custom styles */\n@-webkit-keyframes typing-bounce-8cdbfdc8 {\n0%, 80%, 100% {\n    -webkit-transform: scale(0.8);\n            transform: scale(0.8);\n    opacity: 0.5;\n}\n40% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n    opacity: 1;\n}\n}\n@keyframes typing-bounce-8cdbfdc8 {\n0%, 80%, 100% {\n    -webkit-transform: scale(0.8);\n            transform: scale(0.8);\n    opacity: 0.5;\n}\n40% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n    opacity: 1;\n}\n}\n@-webkit-keyframes highlight-unread-8cdbfdc8 {\n0% {\n    -webkit-filter: brightness(0.4) contrast(0.4);\n            filter: brightness(0.4) contrast(0.4);\n}\n50% {\n    -webkit-filter: brightness(0.6) contrast(0.6);\n            filter: brightness(0.6) contrast(0.6);\n}\n100% {\n    -webkit-filter: brightness(1) contrast(1);\n            filter: brightness(1) contrast(1);\n}\n}\n@keyframes highlight-unread-8cdbfdc8 {\n0% {\n    -webkit-filter: brightness(0.4) contrast(0.4);\n            filter: brightness(0.4) contrast(0.4);\n}\n50% {\n    -webkit-filter: brightness(0.6) contrast(0.6);\n            filter: brightness(0.6) contrast(0.6);\n}\n100% {\n    -webkit-filter: brightness(1) contrast(1);\n            filter: brightness(1) contrast(1);\n}\n}\n.unread-animation[data-v-8cdbfdc8] {\n  -webkit-animation: highlight-unread-8cdbfdc8 10s 1;\n          animation: highlight-unread-8cdbfdc8 10s 1;\n  font-weight: bold;\n}\n\n/* Custom radius classes */\n.has-radius-left[data-v-8cdbfdc8] {\n  border-radius: 4px 18px 18px 18px !important;\n}\n.has-radius-right[data-v-8cdbfdc8] {\n  border-radius: 18px 18px 4px 18px !important;\n}\n.has-radius-normal[data-v-8cdbfdc8] {\n  border-radius: 18px !important;\n}\n.has-text-pre-wrap[data-v-8cdbfdc8] {\n  white-space: pre-wrap !important;\n}\n\n/* Icon color override */\ni.icon-green[data-v-8cdbfdc8] {\n  color: var(--bulma-success);\n}\n\n/* Message Preview Styles (still used in left preview section) */\n.message-preview[data-v-8cdbfdc8] {\n  border-radius: 12px;\n  border: 1px solid var(--border-color);\n}\n.email-header-preview[data-v-8cdbfdc8] {\n  border-bottom: 1px solid var(--bulma-border-strong) !important;\n  padding-bottom: 8px;\n  margin-bottom: 8px;\n}\n.email-header-preview .mb-1[data-v-8cdbfdc8]:last-child {\n  margin-bottom: 0 !important;\n}\n.message-bubble[data-v-8cdbfdc8]:not(.email-bubble) {\n  max-width: 300px;\n  margin-bottom: 8px;\n}\n.message-bubble.whatsapp-bubble[data-v-8cdbfdc8] {\n  background: var(--bulma-success-light);\n  color: var(--bulma-text);\n}\n.message-bubble.email-bubble[data-v-8cdbfdc8] {\n  width: 100%;\n  border-radius: 8px;\n}\n\n/* Email preview content container */\n.email-bubble .content[data-v-8cdbfdc8] {\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  word-break: break-word;\n  max-width: 100%;\n  overflow: hidden;\n}\n.email-bubble hr[data-v-8cdbfdc8] {\n  max-width: 100% !important;\n  margin-left: 0 !important;\n  margin-right: 0 !important;\n  overflow: hidden;\n}\n\n/* Message text content - handles long URLs and text wrapping */\n.message-text-content[data-v-8cdbfdc8] {\n  overflow-wrap: break-word !important;\n  word-wrap: break-word !important;\n  word-break: break-word !important;\n  -ms-hyphens: auto;\n      hyphens: auto;\n  max-width: 100%;\n  overflow: hidden;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-7efb72f2] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".buttons-group[data-v-27816e88] {\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n}\n.buttons-group > .button[data-v-27816e88]:not(:last-child) {\n  margin-right: 0.5em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".alpha-code-tag[data-v-ee263976] {\n  font-size: 0.55rem;\n}\n.alpha-code-tag.alpha-code-tag[data-v-ee263976]:not(:last-child) {\n  margin-right: 0.15rem;\n}\n.alpha-code-tag.alpha-code-tag[data-v-ee263976]:not(body) {\n  padding-left: 0.2rem;\n  padding-right: 0.2rem;\n}\n.custom-header[data-v-ee263976] {\n  border-bottom: solid 1px #d4d3d3 !important;\n  color: var(--bulma-background-color) !important;\n  font-size: 0.8rem !important;\n  font-weight: bold !important;\n}\n.phone-no-autocomplete[data-v-ee263976] .dropdown-content a.dropdown-item.is-hovered:not(:has(.custom-header)) {\n  background-color: hsl(221, 14%, 71%) !important;\n  color: var(--bulma-text-invert) !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5aae116a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("30fa4416", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3fbb19ba", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("566db321", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("652e13b7", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("73024834", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("b8098f7c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("1be39d1c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/BulmaAutocomplete/index.js":
/*!***************************************************!*\
  !*** ./src/components/BulmaAutocomplete/index.js ***!
  \***************************************************/
/*! exports provided: BulmaAutocomplete */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaAutocomplete", function() { return BulmaAutocomplete; });
var BulmaAutocomplete = function BulmaAutocomplete(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaAutocomplete.vue */ "./src/components/BulmaAutocomplete/BulmaAutocomplete.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/components/Sms/SmsMessageTemplates.vue":
/*!****************************************************!*\
  !*** ./src/components/Sms/SmsMessageTemplates.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsMessageTemplates.vue?vue&type=template&id=6c65f415 */ "./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415");
/* harmony import */ var _SmsMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsMessageTemplates.vue?vue&type=script&lang=js */ "./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SmsMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Sms/SmsMessageTemplates.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsMessageTemplates.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessageTemplates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415":
/*!**********************************************************************************!*\
  !*** ./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415 ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsMessageTemplates.vue?vue&type=template&id=6c65f415 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsMessageTemplates.vue?vue&type=template&id=6c65f415");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsMessageTemplates_vue_vue_type_template_id_6c65f415__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/SmsService.js":
/*!******************************************!*\
  !*** ./src/components/Sms/SmsService.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array-buffer.constructor.js */ "./node_modules/core-js/modules/es.array-buffer.constructor.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array-buffer.slice.js */ "./node_modules/core-js/modules/es.array-buffer.slice.js");
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array-buffer.detached.js */ "./node_modules/core-js/modules/es.array-buffer.detached.js");
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer.js */ "./node_modules/core-js/modules/es.array-buffer.transfer.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer-to-fixed-length.js */ "./node_modules/core-js/modules/es.array-buffer.transfer-to-fixed-length.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.typed-array.uint8-array.js */ "./node_modules/core-js/modules/es.typed-array.uint8-array.js");
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.typed-array.at.js */ "./node_modules/core-js/modules/es.typed-array.at.js");
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.typed-array.copy-within.js */ "./node_modules/core-js/modules/es.typed-array.copy-within.js");
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.typed-array.every.js */ "./node_modules/core-js/modules/es.typed-array.every.js");
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.typed-array.fill.js */ "./node_modules/core-js/modules/es.typed-array.fill.js");
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.typed-array.filter.js */ "./node_modules/core-js/modules/es.typed-array.filter.js");
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.typed-array.find.js */ "./node_modules/core-js/modules/es.typed-array.find.js");
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-index.js */ "./node_modules/core-js/modules/es.typed-array.find-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last.js */ "./node_modules/core-js/modules/es.typed-array.find-last.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last-index.js */ "./node_modules/core-js/modules/es.typed-array.find-last-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.typed-array.for-each.js */ "./node_modules/core-js/modules/es.typed-array.for-each.js");
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.typed-array.includes.js */ "./node_modules/core-js/modules/es.typed-array.includes.js");
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.typed-array.index-of.js */ "./node_modules/core-js/modules/es.typed-array.index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.typed-array.iterator.js */ "./node_modules/core-js/modules/es.typed-array.iterator.js");
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.typed-array.join.js */ "./node_modules/core-js/modules/es.typed-array.join.js");
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.typed-array.last-index-of.js */ "./node_modules/core-js/modules/es.typed-array.last-index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.typed-array.map.js */ "./node_modules/core-js/modules/es.typed-array.map.js");
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce.js */ "./node_modules/core-js/modules/es.typed-array.reduce.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce-right.js */ "./node_modules/core-js/modules/es.typed-array.reduce-right.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.typed-array.reverse.js */ "./node_modules/core-js/modules/es.typed-array.reverse.js");
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.typed-array.set.js */ "./node_modules/core-js/modules/es.typed-array.set.js");
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.typed-array.slice.js */ "./node_modules/core-js/modules/es.typed-array.slice.js");
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.typed-array.some.js */ "./node_modules/core-js/modules/es.typed-array.some.js");
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.typed-array.sort.js */ "./node_modules/core-js/modules/es.typed-array.sort.js");
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.typed-array.subarray.js */ "./node_modules/core-js/modules/es.typed-array.subarray.js");
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-locale-string.js */ "./node_modules/core-js/modules/es.typed-array.to-locale-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-reversed.js */ "./node_modules/core-js/modules/es.typed-array.to-reversed.js");
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-sorted.js */ "./node_modules/core-js/modules/es.typed-array.to-sorted.js");
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-string.js */ "./node_modules/core-js/modules/es.typed-array.to-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.typed-array.with.js */ "./node_modules/core-js/modules/es.typed-array.with.js");
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _services_protobuf_api__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/services/protobuf-api */ "./src/services/protobuf-api.js");













































/* harmony default export */ __webpack_exports__["default"] = ({
  getEntitySummaries: function getEntitySummaries(filter) {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var serialised, url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            serialised = _this.serialiseMessageFilter(filter);
            url = "/sms/list/".concat(serialised);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  serialiseMessageFilter: function serialiseMessageFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageFilter.proto */ "./src/assets/proto/sms/SmsMessageFilter.proto");
    var filterMessage = entityProto.SmsMessageFilter.SmsMessageFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_43___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  getSmsMessageDropdownProto: function getSmsMessageDropdownProto(filter) {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var serialised, result, proto, message, entity;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            serialised = encodeURIComponent(_this2.serialiseSmsMessageDropdownFilter(filter));
            _context2.n = 1;
            return Object(_services_protobuf_api__WEBPACK_IMPORTED_MODULE_44__["default"])("/sms/protobuf/sendsms/listcombo?filter=".concat(serialised));
          case 1:
            result = _context2.v;
            proto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageDropdown.proto */ "./src/assets/proto/sms/SmsMessageDropdown.proto");
            message = proto.SmsMessageDropdown.SmsMessageDropdownModel;
            entity = message.decode(new Uint8Array(result.data));
            return _context2.a(2, entity.assets);
        }
      }, _callee2);
    }))();
  },
  serialiseSmsMessageDropdownFilter: function serialiseSmsMessageDropdownFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/sms/SmsMessageDropdownFilter.proto */ "./src/assets/proto/sms/SmsMessageDropdownFilter.proto");
    var filterMessage = entityProto.SmsMessageDropdownFilter.SmsMessageDropdownFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_43___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  sendSms: function sendSms(info) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].post('/sms/send', info);
          case 1:
            result = _context3.v;
            return _context3.a(2, result.data);
        }
      }, _callee3);
    }))();
  },
  postEntity: function postEntity(entity) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].post('/sms/new', entity);
  },
  putEntity: function putEntity(entity) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].put("/sms/".concat(entity.id), entity);
  },
  deleteEntity: function deleteEntity(id) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].delete('/sms/' + id);
  }
});

/***/ }),

/***/ "./src/components/Sms/SmsTemplateModal.vue":
/*!*************************************************!*\
  !*** ./src/components/Sms/SmsTemplateModal.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true */ "./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true");
/* harmony import */ var _SmsTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SmsTemplateModal.vue?vue&type=script&lang=js */ "./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true */ "./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SmsTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2d1c5fc0",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Sms/SmsTemplateModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsTemplateModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=style&index=0&id=2d1c5fc0&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_style_index_0_id_2d1c5fc0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true":
/*!*******************************************************************************************!*\
  !*** ./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Sms/SmsTemplateModal.vue?vue&type=template&id=2d1c5fc0&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SmsTemplateModal_vue_vue_type_template_id_2d1c5fc0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/Sms/columns.js":
/*!***************************************!*\
  !*** ./src/components/Sms/columns.js ***!
  \***************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Message Template', 'message', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ }),

/***/ "./src/components/VueEmail/EmailService.js":
/*!*************************************************!*\
  !*** ./src/components/VueEmail/EmailService.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/services/emailSendRetry */ "./src/services/emailSendRetry.js");





var baseUrl = '/emails';
/* harmony default export */ __webpack_exports__["default"] = ({
  send: function send(formData, onRetry) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return Object(_services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__["sendWithRetry"])(function () {
              return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post('/emails/send', formData);
            }, {
              onRetry: onRetry
            });
          case 1:
            return _context.a(2, _context.v);
        }
      }, _callee);
    }))();
  },
  sendExport: function sendExport(quoteId, exportOptions, reportOptions, formData, onRetry) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/emails/sendtext/".concat(quoteId, "?exportOptions=").concat(exportOptions, "&reportOptions=").concat(reportOptions);
            _context2.n = 1;
            return Object(_services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__["sendWithRetry"])(function () {
              return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post(url, formData);
            }, {
              onRetry: onRetry
            });
          case 1:
            return _context2.a(2, _context2.v);
        }
      }, _callee2);
    }))();
  },
  getAssetsEmailAddresses: function getAssetsEmailAddresses(filter) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            url = 'emails/assetsemails';
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post(url, filter);
          case 1:
            result = _context3.v;
            return _context3.a(2, result.data);
        }
      }, _callee3);
    }))();
  },
  // recent previously-sent recipients for the whole shop (last 3 months).
  getRecentRecipients: function getRecentRecipients() {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            url = 'emails/recentrecipients';
            _context4.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].get(url);
          case 1:
            result = _context4.v;
            return _context4.a(2, result.data);
        }
      }, _callee4);
    }))();
  },
  getEntitySummaries: function getEntitySummaries(filter) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
        while (1) switch (_context5.n) {
          case 0:
            _context5.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(baseUrl, "/template/list"), filter);
          case 1:
            result = _context5.v;
            return _context5.a(2, result.data);
        }
      }, _callee5);
    }))();
  },
  postEntity: function postEntity(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
        while (1) switch (_context6.n) {
          case 0:
            _context6.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(baseUrl, "/new"), entity);
          case 1:
            result = _context6.v;
            return _context6.a(2, result.data);
        }
      }, _callee6);
    }))();
  },
  putEntity: function putEntity(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            _context7.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].put("".concat(baseUrl, "/").concat(entity.id), entity);
          case 1:
            result = _context7.v;
            return _context7.a(2, result.data);
        }
      }, _callee7);
    }))();
  },
  deleteEntity: function deleteEntity(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
        while (1) switch (_context8.n) {
          case 0:
            _context8.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].delete("".concat(baseUrl, "/").concat(id));
          case 1:
            result = _context8.v;
            return _context8.a(2, result.data);
        }
      }, _callee8);
    }))();
  }
});

/***/ }),

/***/ "./src/components/VueEmail/VueEmailMessageTemplates.vue":
/*!**************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailMessageTemplates.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe */ "./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe");
/* harmony import */ var _VueEmailMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VueEmailMessageTemplates.vue?vue&type=script&lang=js */ "./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VueEmailMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VueEmail/VueEmailMessageTemplates.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js":
/*!**************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailMessageTemplates.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailMessageTemplates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe":
/*!********************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailMessageTemplates.vue?vue&type=template&id=44b04abe");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailMessageTemplates_vue_vue_type_template_id_44b04abe__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueEmail/VueEmailTemplateModal.vue":
/*!***********************************************************!*\
  !*** ./src/components/VueEmail/VueEmailTemplateModal.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true */ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true");
/* harmony import */ var _VueEmailTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VueEmailTemplateModal.vue?vue&type=script&lang=js */ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true */ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VueEmailTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "798ae4b4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VueEmail/VueEmailTemplateModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailTemplateModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=style&index=0&id=798ae4b4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_style_index_0_id_798ae4b4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailTemplateModal.vue?vue&type=template&id=798ae4b4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailTemplateModal_vue_vue_type_template_id_798ae4b4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueEmail/columns.js":
/*!********************************************!*\
  !*** ./src/components/VueEmail/columns.js ***!
  \********************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Message Template', 'message', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ }),

/***/ "./src/views/quote/QuoteCommunications.vue":
/*!*************************************************!*\
  !*** ./src/views/quote/QuoteCommunications.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true */ "./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true");
/* harmony import */ var _QuoteCommunications_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteCommunications.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss */ "./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss");
/* harmony import */ var _QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true */ "./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteCommunications_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "8cdbfdc8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteCommunications.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss":
/*!**********************************************************************************************!*\
  !*** ./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=0&id=8cdbfdc8&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_0_id_8cdbfdc8_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=style&index=1&id=8cdbfdc8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_style_index_1_id_8cdbfdc8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true":
/*!*******************************************************************************************!*\
  !*** ./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteCommunications.vue?vue&type=template&id=8cdbfdc8&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunications_vue_vue_type_template_id_8cdbfdc8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteCommunicationEmailModal.vue":
/*!*********************************************************************!*\
  !*** ./src/views/quote/components/QuoteCommunicationEmailModal.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true */ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true");
/* harmony import */ var _QuoteCommunicationEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteCommunicationEmailModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true */ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteCommunicationEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7efb72f2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteCommunicationEmailModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js":
/*!*********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunicationEmailModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true":
/*!******************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=style&index=0&id=7efb72f2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_style_index_0_id_7efb72f2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true ***!
  \***************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteCommunicationEmailModal.vue?vue&type=template&id=7efb72f2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCommunicationEmailModal_vue_vue_type_template_id_7efb72f2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteEmail.vue":
/*!***************************************************!*\
  !*** ./src/views/quote/components/QuoteEmail.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true */ "./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true");
/* harmony import */ var _QuoteEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEmail.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true */ "./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "27816e88",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteEmail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=style&index=0&id=27816e88&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_style_index_0_id_27816e88_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true":
/*!*********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmail.vue?vue&type=template&id=27816e88&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmail_vue_vue_type_template_id_27816e88_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue":
/*!************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c */ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c");
/* harmony import */ var _QuoteEmailAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteEmailAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteEmailAttachmentViewerModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js":
/*!************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c":
/*!******************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachmentViewerModal.vue?vue&type=template&id=52ca0d6c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachmentViewerModal_vue_vue_type_template_id_52ca0d6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachments.vue":
/*!**************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachments.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEmailAttachments.vue?vue&type=template&id=3428c984 */ "./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984");
/* harmony import */ var _QuoteEmailAttachments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEmailAttachments.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteEmailAttachments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteEmailAttachments.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js":
/*!**************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailAttachments.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachments_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984":
/*!********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984 ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailAttachments.vue?vue&type=template&id=3428c984 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailAttachments.vue?vue&type=template&id=3428c984");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailAttachments_vue_vue_type_template_id_3428c984__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteEmailModal.vue":
/*!********************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailModal.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true */ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true");
/* harmony import */ var _QuoteEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEmailModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css */ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "cc2d61fe",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteEmailModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js":
/*!********************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css":
/*!****************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=style&index=0&id=cc2d61fe&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_style_index_0_id_cc2d61fe_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true":
/*!**************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true ***!
  \**************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailModal.vue?vue&type=template&id=cc2d61fe&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailModal_vue_vue_type_template_id_cc2d61fe_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteEmailViewerModal.vue":
/*!**************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailViewerModal.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2 */ "./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2");
/* harmony import */ var _QuoteEmailViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEmailViewerModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteEmailViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteEmailViewerModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js":
/*!**************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailViewerModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2":
/*!********************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2 ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteEmailViewerModal.vue?vue&type=template&id=d15f57e2");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEmailViewerModal_vue_vue_type_template_id_d15f57e2__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue":
/*!************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true */ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true");
/* harmony import */ var _PhoneNoAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PhoneNoAutocomplete.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true */ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PhoneNoAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "ee263976",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js":
/*!************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PhoneNoAutocomplete.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true":
/*!*********************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=style&index=0&id=ee263976&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_style_index_0_id_ee263976_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true":
/*!******************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true ***!
  \******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/PhoneNoAutocomplete.vue?vue&type=template&id=ee263976&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PhoneNoAutocomplete_vue_vue_type_template_id_ee263976_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/mixins/QuoteCommunicationsMixin.js":
/*!************************************************************!*\
  !*** ./src/views/quote/mixins/QuoteCommunicationsMixin.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'quotecommunications';
var moduleNameQuote = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    getEmailer: 'getEmailer',
    getParameters: 'getParameters'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleNameQuote, {
    currentSnapshot: 'currentSnapshot'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, {
    addParameter: 'addParameter',
    addParameters: 'addParameters',
    setEmailerAttachments: 'setEmailerAttachments',
    removeParameter: 'removeParameter',
    removeParameters: 'removeParameters'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleNameQuote, {
    getStoreItem: 'getStoreItem'
  }))
});

/***/ })

}]);
//# sourceMappingURL=quote-communications-chunk.js.map