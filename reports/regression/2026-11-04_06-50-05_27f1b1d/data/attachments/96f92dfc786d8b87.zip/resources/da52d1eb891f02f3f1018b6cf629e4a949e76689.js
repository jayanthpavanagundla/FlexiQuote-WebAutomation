(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-vehiclecustomer-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteVehicleCustomer',
  inject: ['$vv'],
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]
  },
  props: {
    value: null,
    vehicle: null,
    customer: null,
    readOnlyView: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: null,
      // vehicle: null,
      // customer: null,
      isVehicleLoading: false,
      isCustomerLoading: false
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    defaultAddress: function defaultAddress() {
      return this.customer.addresses.find(function (a) {
        return a.isDefault;
      });
    },
    homePhone: function homePhone() {
      return this.customer.phones.find(function (a) {
        return a.type === _enums__WEBPACK_IMPORTED_MODULE_12__["PhoneTypes"].Home.toString();
      });
    },
    workPhone: function workPhone() {
      return this.customer.phones.find(function (a) {
        return a.type === _enums__WEBPACK_IMPORTED_MODULE_12__["PhoneTypes"].Work.toString();
      });
    },
    mobilePhone: function mobilePhone() {
      return this.customer.phones.find(function (a) {
        return a.type === _enums__WEBPACK_IMPORTED_MODULE_12__["PhoneTypes"].Mobile.toString();
      });
    },
    fax: function fax() {
      return this.customer.phones.find(function (a) {
        return a.type === _enums__WEBPACK_IMPORTED_MODULE_12__["PhoneTypes"].Fax.toString();
      });
    },
    defaultEmail: function defaultEmail() {
      return this.customer.emails.find(function (e) {
        return e.isDefault;
      });
    },
    paintGroupTypes: function paintGroupTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["PaintGroupTypes"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    this.innerValue = this.value;
    if (this.innerValue.isNew) {
      this.innerValue.odometer = this.vehicle.odometer;
    }
    // this.getCustomerEntity()
    // this.getVehicleEntity()
    // this.getEntities()
  },
  mounted: function mounted() {
    this.$vv.vehicleCustomerGroup.$touch();
  },
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_14__["mapActions"])('quotes', ['getQuoteCustomer'])), {}, {
    getVehicleEntity: function getVehicleEntity() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isVehicleLoading = true;
              _context.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_11__["default"].getVehicleEntity(_this.innerValue.vehicleId);
            case 1:
              _this.vehicle = _context.v;
              _this.isVehicleLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getCustomerEntity: function getCustomerEntity() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isCustomerLoading = true;
              _context2.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_11__["default"].getCustomerEntity(_this2.innerValue.customerId);
            case 1:
              _this2.customer = _context2.v;
              _this2.isCustomerLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getEntities: function getEntities() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var _yield$Promise$all, _yield$Promise$all2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isVehicleLoading = true;
              _this3.isCustomerLoading = true;
              _context3.n = 1;
              return Promise.all([_QuoteService__WEBPACK_IMPORTED_MODULE_11__["default"].getVehicleEntity(_this3.innerValue.vehicleId), _QuoteService__WEBPACK_IMPORTED_MODULE_11__["default"].getCustomerEntity(_this3.innerValue.customerId)]);
            case 1:
              _yield$Promise$all = _context3.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_yield$Promise$all, 2);
              _this3.vehicle = _yield$Promise$all2[0];
              _this3.customer = _yield$Promise$all2[1];
              _this3.isVehicleLoading = false;
              _this3.isCustomerLoading = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    fixCustomerMismatch: function fixCustomerMismatch() {
      this.isCustomerLoading = true;
      this.innerValue.customerId = this.vehicle.customer.key;
      this.getQuoteCustomer({
        id: this.innerValue.customerId,
        refresh: true
      });
      this.isCustomerLoading = false;
    }
  })
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell"
  }, [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Vehicle")]), _vm.vehicle && !_vm.vehicle.isActive ? _c("p", {
    staticClass: "subtitle has-text-danger"
  }, [_vm._v("This vehicle has been deleted")]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    class: {
      "is-loading-no-header": _vm.isVehicleLoading
    }
  }, [!_vm.isVehicleLoading && _vm.vehicle ? _c("tbody", [_c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Make")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.model.make))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Model")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.model.model))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Series")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.model.make))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Built")]), _c("td", [_vm._v(_vm._s(_vm.$filters.pad(_vm.vehicle.buildMonth, 2)) + _vm._s(_vm.vehicle.buildMonth ? "/" : "") + _vm._s(_vm.vehicle.buildYear))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Engine Size")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.engizeSize))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("VIN")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.vin))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Body Style")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.bodyId2))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Colour")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.colour))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Engine No.")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.engineNo))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Cylinders")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.cylinders))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Transmission")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.transmissionType))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Paint Group")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.paintGroup === _vm.paintGroupTypes.M3 && _vm.vehicle.paintGroupPlus ? "M3+" : _vm.vehicle.paintGroup))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("NRMA Schedule")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.scheduleId))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("NTAR Schedule")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.ntarScheduleId))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("MTA Schedule")]), _c("td", [_vm._v(_vm._s(_vm.vehicle.mtaScheduleId))])])]) : _vm.isVehicleLoading ? _c("tbody", [_vm._m(0)]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Odometer")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.innerValue.odometer
    }
  })]) : _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      precision: 0
    },
    model: {
      value: _vm.innerValue.odometer,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "odometer", _vm._n($$v));
      },
      expression: "innerValue.odometer"
    }
  })], 1)])])]), _c("div", {
    staticClass: "cell"
  }, [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Customer")]), _vm.customer && !_vm.customer.active ? _c("p", {
    staticClass: "subtitle has-text-danger"
  }, [_vm._v("This customer has been deleted")]) : _vm._e(), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    class: {
      "is-loading-no-header": _vm.isCustomerLoading
    }
  }, [!_vm.isCustomerLoading && _vm.customer ? _c("tbody", [_c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_c("span", [_vm._v("Name")]), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: this.$v.vehicleCustomerGroup.$error,
      expression: "this.$v.vehicleCustomerGroup.$error"
    }],
    staticClass: "icon has-text-danger tooltip is-tooltip-danger is-tooltip-multiline",
    attrs: {
      "data-tooltip": "Quote's customer does not match vehicle's customer. Click button next to name to fix."
    }
  }, [_c("i", {
    staticClass: "mdi mdi-alert-circle mdi-18px"
  })])]), _c("td", [_vm._v(" " + _vm._s(_vm.customer.fullname) + " "), _vm.customer && !_vm.customer.active ? _c("span", {
    staticClass: "tag is-danger is-light"
  }, [_vm._v("Deleted")]) : _vm._e(), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: this.$v.vehicleCustomerGroup.$error,
      expression: "this.$v.vehicleCustomerGroup.$error"
    }],
    staticClass: "button is-small is-outlined is-danger is-pulled-right tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Auto fix customer mismatch issue"
    },
    on: {
      click: function click($event) {
        return _vm.fixCustomerMismatch();
      }
    }
  }, [_vm._m(1)])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Address")]), _c("td", [_vm._v(_vm._s(_vm.defaultAddress ? _vm.defaultAddress.displayAddress : ""))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Home")]), _c("td", [_vm._v(_vm._s(_vm.homePhone ? _vm.homePhone.no : ""))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Work")]), _c("td", [_vm._v(_vm._s(_vm.workPhone ? _vm.workPhone.no : ""))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Mobile")]), _c("td", [_vm._v(_vm._s(_vm.mobilePhone ? _vm.mobilePhone.no : ""))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Fax")]), _c("td", [_vm._v(_vm._s(_vm.fax ? _vm.fax.no : ""))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Email")]), _c("td", [_vm._v(_vm._s(_vm.defaultEmail ? _vm.defaultEmail.address : ""))])])]) : _vm.isCustomerLoading ? _c("tbody", [_vm._m(2)]) : _vm._e()])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    attrs: {
      colspan: "2"
    }
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    staticStyle: {
      opacity: "0"
    },
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-spin mdi-loading mdi-30px"
  })])])])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-auto-fix mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", [_c("td", {
    attrs: {
      colspan: "2"
    }
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    staticStyle: {
      opacity: "0"
    },
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-spin mdi-loading mdi-30px"
  })])])])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./src/views/quote/QuoteVehicleCustomer.vue":
/*!**************************************************!*\
  !*** ./src/views/quote/QuoteVehicleCustomer.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a */ "./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a");
/* harmony import */ var _QuoteVehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteVehicleCustomer.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteVehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteVehicleCustomer.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js":
/*!**************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleCustomer.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a":
/*!********************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleCustomer.vue?vue&type=template&id=1a12a00a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleCustomer_vue_vue_type_template_id_1a12a00a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-vehiclecustomer-chunk.js.map