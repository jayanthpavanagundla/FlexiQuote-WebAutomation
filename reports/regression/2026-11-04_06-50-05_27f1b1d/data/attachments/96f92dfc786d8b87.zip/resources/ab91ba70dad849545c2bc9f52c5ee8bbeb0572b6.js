(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-remarks-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_UserProfileIcon_UserProfileIcon__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/UserProfileIcon/UserProfileIcon */ "./src/components/UserProfileIcon/UserProfileIcon.vue");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_startcase__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash.startcase */ "./node_modules/lodash.startcase/index.js");
/* harmony import */ var lodash_startcase__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_startcase__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _services_RemarkService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/services/RemarkService */ "./src/services/RemarkService.js");
/* harmony import */ var _components_BulmaCheckbox_BulmaCheckbox_vue__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/components/BulmaCheckbox/BulmaCheckbox.vue */ "./src/components/BulmaCheckbox/BulmaCheckbox.vue");
/* harmony import */ var _helpers_QuoteRemarksAutoSaveHelper__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./helpers/QuoteRemarksAutoSaveHelper */ "./src/views/quote/helpers/QuoteRemarksAutoSaveHelper.js");
/* harmony import */ var _components_QuoteRemarks_QuoteIncidentNotes__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./components/QuoteRemarks/QuoteIncidentNotes */ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue");




































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteRemarks',
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_27__["FocusInserted"]
  },
  components: {
    RemarkModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__["RemarkModal"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_26__["default"],
    UserProfileIcon: _components_UserProfileIcon_UserProfileIcon__WEBPACK_IMPORTED_MODULE_28__["default"],
    BulmaCheckbox: _components_BulmaCheckbox_BulmaCheckbox_vue__WEBPACK_IMPORTED_MODULE_33__["default"],
    QuoteIncidentNotes: _components_QuoteRemarks_QuoteIncidentNotes__WEBPACK_IMPORTED_MODULE_35__["default"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_22__["DateTimeFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_22__["NumberFiltersMixin"]],
  props: {
    value: null,
    autoSaveEnabled: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: null,
      isRemarkModalActive: false,
      isIncidentNotesSaving: false,
      selectedRow: null,
      isTableLoading: false,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 15
      },
      printedFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 6
      },
      jobFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 6
      },
      otherFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 6
      },
      dueInFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 4
      },
      dueOutFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 4
      },
      editRemarkRowNumber: -1,
      editPrintedRemarkRowNumber: -1,
      editJobNoteRemarkRowNumber: -1,
      editDueInNoteRowNumber: -1,
      editDueOutNoteRowNumber: -1,
      editRemarkInnerValue: '',
      editPrintedRemarkInnerValue: '',
      editJobNoteRemarkInnerValue: '',
      editDueInNoteInnerValue: '',
      editDueOutNoteInnerValue: '',
      otherRemarkTypes: {
        //subset or RemarkTypes.js
        ORMSystemRemark: 19,
        PNETSystemRemark: 20,
        OtherSystemRemark: 21,
        ORMMessageRemark: 22,
        PNETMessageRemark: 23,
        REPXSystemRemark: 30,
        PartsCheckRemark: 35
      },
      otherRemarksIdFilter: 0,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      showJobNoteRemarks: false
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_25__["RemarkColumns"];
    },
    remarkTypes: function remarkTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"];
    },
    remarkTotalRows: function remarkTotalRows() {
      return this.innerValue.remarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark && !r.isDeleted;
      }).length;
    },
    printedRemarkTotalRows: function printedRemarkTotalRows() {
      return this.innerValue.printedRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].PrintedRemark && !r.isDeleted;
      }).length;
    },
    jobRemarkTotalRows: function jobRemarkTotalRows() {
      return this.innerValue.jobNoteRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].JobNote && !r.isDeleted;
      }).length;
    },
    otherRemarkTotalRows: function otherRemarkTotalRows() {
      var _this = this;
      if (!this.otherRemarksIdFilter) {
        return this.innerValue.otherRemarks.filter(function (r) {
          return !r.isDeleted;
        }).length;
      } else {
        return this.innerValue.otherRemarks.filter(function (r) {
          return !r.isDeleted && r.remarkTypeId === _this.otherRemarksIdFilter;
        }).length;
      }
    },
    dueInNotesTotalRows: function dueInNotesTotalRows() {
      return this.innerValue.dueInNotes.filter(function (r) {
        return !r.isDeleted;
      }).length;
    },
    dueOutNotesTotalRows: function dueOutNotesTotalRows() {
      return this.innerValue.dueOutNotes.filter(function (r) {
        return !r.isDeleted;
      }).length;
    },
    pagedRemarks: function pagedRemarks() {
      return this.activeRemarks.slice((this.filter.pageIndex - 1) * this.filter.pageSize, this.filter.pageIndex * this.filter.pageSize);
    },
    pagedPrintedRemarks: function pagedPrintedRemarks() {
      return this.activePrintedRemarks.slice((this.printedFilter.pageIndex - 1) * this.printedFilter.pageSize, this.printedFilter.pageIndex * this.printedFilter.pageSize);
    },
    pagedJobNoteRemarks: function pagedJobNoteRemarks() {
      return this.activeJobNoteRemarks.slice((this.jobFilter.pageIndex - 1) * this.jobFilter.pageSize, this.jobFilter.pageIndex * this.jobFilter.pageSize);
    },
    pagedOtherRemarks: function pagedOtherRemarks() {
      return this.activeOtherRemarks.slice((this.otherFilter.pageIndex - 1) * this.otherFilter.pageSize, this.otherFilter.pageIndex * this.otherFilter.pageSize);
    },
    pagedDueInNotes: function pagedDueInNotes() {
      return this.activeDueInNotes.slice((this.dueInFilter.pageIndex - 1) * this.dueInFilter.pageSize, this.dueInFilter.pageIndex * this.dueInFilter.pageSize);
    },
    pagedDueOutNotes: function pagedDueOutNotes() {
      return this.activeDueOutNotes.slice((this.dueOutFilter.pageIndex - 1) * this.dueOutFilter.pageSize, this.dueOutFilter.pageIndex * this.dueOutFilter.pageSize);
    },
    activeRemarks: function activeRemarks() {
      var pinnedActiveRemarks = this.innerValue.remarks.filter(function (r) {
        return r.pinRemarkOrder != null && r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark && !r.isDeleted;
      });
      var unpinnedActiveRemarks = this.innerValue.remarks.filter(function (r) {
        return r.pinRemarkOrder == null && r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark && !r.isDeleted;
      });
      pinnedActiveRemarks.sort(function (a, b) {
        return a.pinRemarkOrder - b.pinRemarkOrder;
      });
      unpinnedActiveRemarks.sort(function (a, b) {
        return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
      });
      return [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_4__["default"])(pinnedActiveRemarks), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_4__["default"])(unpinnedActiveRemarks));
    },
    activePrintedRemarks: function activePrintedRemarks() {
      return this.innerValue.printedRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].PrintedRemark && !r.isDeleted;
      });
    },
    activeJobNoteRemarks: function activeJobNoteRemarks() {
      return this.innerValue.jobNoteRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].JobNote && !r.isDeleted;
      }).sort(function (a, b) {
        return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
      });
    },
    activeOtherRemarks: function activeOtherRemarks() {
      var _this2 = this;
      if (!this.otherRemarksIdFilter) {
        return this.innerValue.otherRemarks.filter(function (r) {
          return !r.isDeleted;
        });
      } else {
        return this.innerValue.otherRemarks.filter(function (r) {
          return !r.isDeleted && r.remarkTypeId === _this2.otherRemarksIdFilter;
        });
      }
    },
    activeDueInNotes: function activeDueInNotes() {
      return this.innerValue.dueInNotes.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].DueInNote && !r.isDeleted;
      });
    },
    activeDueOutNotes: function activeDueOutNotes() {
      return this.innerValue.dueOutNotes.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].DueOutNote && !r.isDeleted;
      });
    },
    formattedRemarkTypes: function formattedRemarkTypes() {
      var _this3 = this;
      return Object.entries(this.otherRemarkTypes).map(function (_ref) {
        var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref, 2),
          prop = _ref2[0],
          value = _ref2[1];
        return {
          label: prop === 'PartsCheckRemark' ? 'PartsCheck Remark' : _this3.startCase(prop),
          value: value
        };
      });
    }
  },
  watch: {
    value: function value(newVal) {
      this.innerValue = newVal;
    }
  },
  created: function created() {
    var _this4 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this4.innerValue = _this4.value;
            if (_this4.autoSaveEnabled) {
              _this4._remarksAutoSaveHelper = Object(_helpers_QuoteRemarksAutoSaveHelper__WEBPACK_IMPORTED_MODULE_34__["createQuoteRemarksAutoSaveHelper"])(function (isSaving) {
                _this4.$emit('remarks-save-state-change', isSaving);
                if (!isSaving) _this4.$emit('remarks-saved');
              });
            }
            _context.n = 1;
            return _this4.getPlanningPlusActiveStatus();
          case 1:
            _this4.setRemarksAsRead();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    var _this5 = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntityReloaded, function () {
      _this5.innerValue = _this5.value;
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntityReloaded);
  },
  methods: {
    // Opening the tab is the read action - there is no explicit "mark as read" control,
    // by design. The dot is cleared straight away rather than on the sub nav's next poll;
    // a failure here is not worth interrupting the user for, since the next poll corrects it.
    setRemarksAsRead: function setRemarksAsRead() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var quoteId, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              quoteId = _this6.innerValue && _this6.innerValue.quoteId;
              if (quoteId) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _context2.p = 1;
              _context2.n = 2;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_32__["default"].setRemarksAsRead(quoteId);
            case 2:
              _this6.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].RemarksRead);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              console.error(_t);
            case 4:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    getPlanningPlusActiveStatus: function getPlanningPlusActiveStatus() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var externalSetting, _externalSetting$filt, _externalSetting$filt2, planningPlusExternalSetting;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_31__["CompanySettingService"].getCompanyExternalSettings();
            case 1:
              externalSetting = _context3.v;
              _externalSetting$filt = externalSetting.filter(function (i) {
                return i.settingName == _enums__WEBPACK_IMPORTED_MODULE_24__["ExternalSettingTypes"].SETTING_PLANNINGPLUS;
              }), _externalSetting$filt2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_externalSetting$filt, 1), planningPlusExternalSetting = _externalSetting$filt2[0];
              _this7.showJobNoteRemarks = parseInt(planningPlusExternalSetting.property5); // Active property
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    setPinRemarkOrder: function setPinRemarkOrder(remark) {
      var _this$_remarksAutoSav;
      if (this.$licenceExpired) return;
      var selectedRemark = this.innerValue.remarks.find(function (r) {
        return r.remarkId == remark.remarkId;
      });
      var pinnedRemarks = this.innerValue.remarks.filter(function (r) {
        return r.pinRemarkOrder !== null && r.remarkId !== remark.remarkId;
      });
      if (selectedRemark.pinRemarkOrder == null) {
        selectedRemark.pinRemarkOrder = 0;
        var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(pinnedRemarks),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var _remark = _step.value;
            _remark.pinRemarkOrder += 1;
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      } else {
        var selectedPinRemarkOrder = selectedRemark.pinRemarkOrder;
        selectedRemark.pinRemarkOrder = null;
        var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(pinnedRemarks),
          _step2;
        try {
          for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
            var _remark2 = _step2.value;
            if (_remark2.pinRemarkOrder > selectedPinRemarkOrder) {
              _remark2.pinRemarkOrder -= 1;
            }
          }
        } catch (err) {
          _iterator2.e(err);
        } finally {
          _iterator2.f();
        }
      }
      (_this$_remarksAutoSav = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav === void 0 || _this$_remarksAutoSav.pin([selectedRemark].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_4__["default"])(pinnedRemarks)));
    },
    addRemarks: function addRemarks(remark, printedRemark, jobNoteRemark) {
      if (remark) {
        var _this$_remarksAutoSav2;
        var newRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__["RemarkModel"](this.innerValue.quoteId, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark, remark, this.$userInfo.firstName, this.$userInfo.lastName, this.$userInfo.displayName, this.value.isSyncRepX);
        this.innerValue.remarks.splice(this.innerValue.remarks.length, 1, newRemark);
        this.innerValue.remarks.sort(function (a, b) {
          return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
        });
        (_this$_remarksAutoSav2 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav2 === void 0 || _this$_remarksAutoSav2.add(newRemark);
      }
      if (printedRemark) {
        var _this$_remarksAutoSav3;
        var newPrintedRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__["RemarkModel"](this.innerValue.quoteId, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].PrintedRemark, printedRemark, this.$userInfo.firstName, this.$userInfo.lastName, this.$userInfo.displayName);
        this.innerValue.printedRemarks.splice(this.innerValue.printedRemarks.length, 1, newPrintedRemark);
        this.innerValue.printedRemarks.sort(function (a, b) {
          return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
        });
        (_this$_remarksAutoSav3 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav3 === void 0 || _this$_remarksAutoSav3.add(newPrintedRemark);
      }
      if (jobNoteRemark) {
        var _this$_remarksAutoSav4;
        var newJobNoteRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__["RemarkModel"](this.innerValue.quoteId, _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].JobNote, jobNoteRemark, this.$userInfo.firstName, this.$userInfo.lastName, this.$userInfo.displayName);
        this.innerValue.jobNoteRemarks.splice(this.innerValue.jobNoteRemarks.length, 1, newJobNoteRemark);
        this.innerValue.jobNoteRemarks.sort(function (a, b) {
          return new Date(b.remarkDateTime) - new Date(a.remarkDateTime);
        });
        (_this$_remarksAutoSav4 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav4 === void 0 || _this$_remarksAutoSav4.add(newJobNoteRemark);
      }
      this.toggleRemarkModal();
    },
    toggleRemarkModal: function toggleRemarkModal() {
      if (this.$licenceExpired) return;
      this.isRemarkModalActive = !this.isRemarkModalActive;
    },
    deleteRemark: function deleteRemark(index, remarkId, remarkType) {
      var _this$_remarksAutoSav5;
      if (this.$licenceExpired) return;
      var deletedRemark;
      console.log('remarkType: ', remarkType);
      if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].Remark) {
        deletedRemark = this.activeRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew || this.autoSaveEnabled) {
          var _index = this.innerValue.remarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.remarks.splice(_index, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].PrintedRemark) {
        deletedRemark = this.activePrintedRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew || this.autoSaveEnabled) {
          var _index2 = this.innerValue.printedRemarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.printedRemarks.splice(_index2, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].JobNote) {
        deletedRemark = this.activeJobNoteRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew || this.autoSaveEnabled) {
          var _index3 = this.innerValue.jobNoteRemarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.jobNoteRemarks.splice(_index3, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].DueInNote) {
        deletedRemark = this.activeDueInNotes.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew || this.autoSaveEnabled) {
          var _index4 = this.innerValue.dueInNotes.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.dueInNotes.splice(_index4, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].DueOutNote) {
        deletedRemark = this.activeDueOutNotes.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew || this.autoSaveEnabled) {
          var _index5 = this.innerValue.dueOutNotes.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.dueOutNotes.splice(_index5, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else {
        deletedRemark = this.innerValue.otherRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (this.autoSaveEnabled) {
          var _index6 = this.innerValue.otherRemarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.otherRemarks.splice(_index6, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      }
      (_this$_remarksAutoSav5 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav5 === void 0 || _this$_remarksAutoSav5.delete(deletedRemark);
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
    },
    onPrintedRemarksPageChange: function onPrintedRemarksPageChange(pageIndex) {
      this.printedFilter.pageIndex = pageIndex;
    },
    onJobNoteRemarksPageChange: function onJobNoteRemarksPageChange(pageIndex) {
      this.jobFilter.pageIndex = pageIndex;
    },
    onOtherRemarksPageChange: function onOtherRemarksPageChange(pageIndex) {
      this.otherFilter.pageIndex = pageIndex;
    },
    onDueInNotePageChange: function onDueInNotePageChange(pageIndex) {
      this.dueInFilter.pageIndex = pageIndex;
    },
    onDueOutNotePageChange: function onDueOutNotePageChange(pageIndex) {
      this.dueOutFilter.pageIndex = pageIndex;
    },
    sort: function sort(name, order) {},
    onIncidentNotesTextChange: function onIncidentNotesTextChange(text) {
      if (!this.innerValue.incidentNotes) {
        this.innerValue.incidentNotes = this._createIncidentNotesRemark();
      }
      this.innerValue.incidentNotes.remarks = text;
    },
    onIncidentNotesDateChange: function onIncidentNotesDateChange(date) {
      if (!this.innerValue.incidentNotes) {
        this.innerValue.incidentNotes = this._createIncidentNotesRemark();
      }
      this.innerValue.incidentNotes.remarkDateTime = date ? date.toISOString().split('.')[0] + 'Z' : null;
    },
    _createIncidentNotesRemark: function _createIncidentNotesRemark() {
      return {
        remarkId: null,
        remarkTypeId: _enums__WEBPACK_IMPORTED_MODULE_24__["RemarkTypes"].INCNOT,
        assetId: this.innerValue.quoteId,
        remarks: '',
        remarkDateTime: new Date().toISOString().split('.')[0] + 'Z',
        isNew: true
      };
    },
    onIncidentNotesSave: function onIncidentNotesSave() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              if (!(!_this8.autoSaveEnabled || !_this8.innerValue.incidentNotes)) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              _this8.isIncidentNotesSaving = true;
              _context4.p = 2;
              _context4.n = 3;
              return _this8._remarksAutoSaveHelper.saveIncidentNotes(_this8.innerValue.incidentNotes);
            case 3:
              _context4.n = 5;
              break;
            case 4:
              _context4.p = 4;
              _t2 = _context4.v;
            case 5:
              _context4.p = 5;
              _this8.isIncidentNotesSaving = false;
              return _context4.f(5);
            case 6:
              return _context4.a(2);
          }
        }, _callee4, null, [[2, 4, 5, 6]]);
      }))();
    },
    editRemark: function editRemark(row, remark) {
      if (this.$licenceExpired) return;
      if (this.editRemarkRowNumber === row) {
        var _this$_remarksAutoSav6;
        // Confirm edit - apply the change
        remark.remarks = this.editRemarkInnerValue;
        this.editRemarkRowNumber = -1;
        this.editRemarkInnerValue = '';
        (_this$_remarksAutoSav6 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav6 === void 0 || _this$_remarksAutoSav6.update(remark);
      } else {
        // Start edit - store current value
        this.editRemarkInnerValue = remark.remarks;
        this.editRemarkRowNumber = row;
      }
      this.editPrintedRemarkRowNumber = -1;
    },
    editPrintedRemark: function editPrintedRemark(row, remark) {
      if (this.$licenceExpired) return;
      if (this.editPrintedRemarkRowNumber === row) {
        var _this$_remarksAutoSav7;
        // Confirm edit - apply the change
        remark.remarks = this.editPrintedRemarkInnerValue;
        this.editPrintedRemarkRowNumber = -1;
        this.editPrintedRemarkInnerValue = '';
        (_this$_remarksAutoSav7 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav7 === void 0 || _this$_remarksAutoSav7.update(remark);
      } else {
        // Start edit - store current value
        this.editPrintedRemarkInnerValue = remark.remarks;
        this.editPrintedRemarkRowNumber = row;
      }
      this.editRemarkRowNumber = -1;
    },
    editJobNoteRemark: function editJobNoteRemark(row, remark) {
      if (this.$licenceExpired) return;
      if (this.editJobNoteRemarkRowNumber === row) {
        var _this$_remarksAutoSav8;
        // Confirm edit - apply the change
        remark.remarks = this.editJobNoteRemarkInnerValue;
        this.editJobNoteRemarkRowNumber = -1;
        this.editJobNoteRemarkInnerValue = '';
        (_this$_remarksAutoSav8 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav8 === void 0 || _this$_remarksAutoSav8.update(remark);
      } else {
        // Start edit - store current value
        this.editJobNoteRemarkInnerValue = remark.remarks;
        this.editJobNoteRemarkRowNumber = row;
      }
    },
    editDueInNote: function editDueInNote(row, remark) {
      if (this.$licenceExpired) return;
      if (this.editDueInNoteRowNumber === row) {
        var _this$_remarksAutoSav9;
        // Confirm edit - apply the change
        remark.remarks = this.editDueInNoteInnerValue;
        this.editDueInNoteRowNumber = -1;
        this.editDueInNoteInnerValue = '';
        (_this$_remarksAutoSav9 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav9 === void 0 || _this$_remarksAutoSav9.update(remark);
      } else {
        // Start edit - store current value
        this.editDueInNoteInnerValue = remark.remarks;
        this.editDueInNoteRowNumber = row;
      }
      this.editDueOutNoteRowNumber = -1;
    },
    editDueOutNote: function editDueOutNote(row, remark) {
      if (this.$licenceExpired) return;
      if (this.editDueOutNoteRowNumber === row) {
        var _this$_remarksAutoSav0;
        // Confirm edit - apply the change
        remark.remarks = this.editDueOutNoteInnerValue;
        this.editDueOutNoteRowNumber = -1;
        this.editDueOutNoteInnerValue = '';
        (_this$_remarksAutoSav0 = this._remarksAutoSaveHelper) === null || _this$_remarksAutoSav0 === void 0 || _this$_remarksAutoSav0.update(remark);
      } else {
        // Start edit - store current value
        this.editDueOutNoteInnerValue = remark.remarks;
        this.editDueOutNoteRowNumber = row;
      }
      this.editDueInNoteRowNumber = -1;
    },
    cancelEditRemark: function cancelEditRemark() {
      this.editRemarkRowNumber = -1;
      this.editRemarkInnerValue = '';
    },
    cancelEditPrintedRemark: function cancelEditPrintedRemark() {
      this.editPrintedRemarkRowNumber = -1;
      this.editPrintedRemarkInnerValue = '';
    },
    cancelEditJobNoteRemark: function cancelEditJobNoteRemark() {
      this.editJobNoteRemarkRowNumber = -1;
      this.editJobNoteRemarkInnerValue = '';
    },
    cancelEditDueInNote: function cancelEditDueInNote() {
      this.editDueInNoteRowNumber = -1;
      this.editDueInNoteInnerValue = '';
    },
    cancelEditDueOutNote: function cancelEditDueOutNote() {
      this.editDueOutNoteRowNumber = -1;
      this.editDueOutNoteInnerValue = '';
    },
    camelCaseToStartCase: function camelCaseToStartCase(str) {
      return str.replace(/((?<!^)[A-Z](?![A-Z]))(?=\S)/g, ' $1').replace(/^./, function (s) {
        return s.toUpperCase();
      });
    },
    startCase: function startCase(str) {
      return lodash_startcase__WEBPACK_IMPORTED_MODULE_30___default()(str);
    },
    showRemarkTypes: function showRemarkTypes(type) {
      if (type === 'PartsCheckRemark') {
        return 'PartsCheck Remark';
      } else {
        return this.startCase(type);
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteIncidentNotes',
  props: {
    value: {
      type: Object,
      default: null
    },
    isSaving: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      incidentNotesText: '',
      selectedIncidentNotesDate: null,
      notesSnapshot: null,
      dateSnapshot: null,
      isSyncing: false,
      formats: {
        input: ['L', 'YYYY-MM-DD', 'YYYY/MM/DD']
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  watch: {
    value: function value(newVal) {
      this.syncFromValue(newVal);
    },
    incidentNotesText: function incidentNotesText(val) {
      if (this.isSyncing) return; // skip prop-driven syncs; only user input emits
      this.$emit('text-change', val);
    },
    selectedIncidentNotesDate: function selectedIncidentNotesDate(val) {
      if (this.isSyncing) return; // skip prop-driven syncs; only user input emits
      this.$emit('date-change', val);
      var iso = val ? val.toISOString() : null;
      if (iso !== this.dateSnapshot) {
        this.$emit('date-save');
      }
    }
  },
  created: function created() {
    this.syncFromValue(this.value);
  },
  methods: {
    syncFromValue: function syncFromValue(val) {
      var _this = this;
      // Mirror the prop into local state without emitting; cleared next tick.
      this.isSyncing = true;
      this.incidentNotesText = (val === null || val === void 0 ? void 0 : val.remarks) || '';
      var newDate = val !== null && val !== void 0 && val.remarkDateTime ? new Date(val.remarkDateTime) : null;
      // Snapshot before the reactive property so date-save stays accurate.
      this.dateSnapshot = newDate ? newDate.toISOString() : null;
      this.selectedIncidentNotesDate = newDate;
      this.$nextTick(function () {
        _this.isSyncing = false;
      });
    },
    captureNotesSnapshot: function captureNotesSnapshot() {
      this.notesSnapshot = this.incidentNotesText;
    },
    handleNotesBlur: function handleNotesBlur() {
      if (this.incidentNotesText !== this.notesSnapshot) {
        this.$emit('notes-blur');
      }
    },
    confirmDateSaved: function confirmDateSaved() {
      this.dateSnapshot = this.selectedIncidentNotesDate ? this.selectedIncidentNotesDate.toISOString() : null;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.replace-all.js */ "./node_modules/core-js/modules/es.string.replace-all.js");
/* harmony import */ var core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_9__);










var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "grid is-col-min-15",
    class: {
      "quote-remarks-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", {
    staticClass: "cell is-flex is-flex-direction-column grid mb-0"
  }, [_c("div", {
    staticClass: "is-flex-grow-1 is-flex cell"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(0), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("a", {
    staticClass: "button is-small is-success tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Add Remarks",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Remarks")])])])])])])]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.remarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("div", {
      staticClass: "is-pulled-left ml-1"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editRemarkRowNumber === -1 || _vm.editRemarkRowNumber !== index,
        expression: "editRemarkRowNumber === -1 || editRemarkRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editRemarkRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.editRemarkInnerValue,
        expression: "editRemarkInnerValue"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: _vm.editRemarkInnerValue
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.editRemarkInnerValue = $event.target.value;
        }
      }
    }) : _vm._e()]), _c("div", {
      staticClass: "is-clearfix"
    }), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [remark.firstName || remark.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": remark.firstName,
        "last-name": remark.lastName,
        "display-name": remark.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "is-italic pr-1"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))]), remark.isSyncRepX ? _c("span", {
      staticClass: "is-rounded is-success tag is-italic"
    }, [_c("i", {
      staticClass: "mdi mdi-check mdi-14px"
    }), _vm._v(" RepX ")]) : _vm._e()], 1)]), _c("td", {
      staticClass: "is-content-width"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.setPinRemarkOrder(remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-22px",
      class: [remark.pinRemarkOrder !== null ? "mdi-pin" : "mdi-pin-outline"]
    })])]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("a", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        mousedown: function mousedown($event) {
          return _vm.editRemark(index, remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editRemarkRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]) : _vm._e(), _vm.editRemarkRowNumber === index ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.cancelEditRemark();
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-close mdi-24px"
    })])]) : _vm._e(), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])]) : _vm._e()])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.innerValue.dueInNotes.length !== 0,
      expression: "innerValue.dueInNotes.length !== 0"
    }],
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_vm._m(2), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.dueInFilter.pageIndex,
      "page-size": _vm.dueInFilter.pageSize,
      "total-rows": _vm.dueInNotesTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.dueInFilter.sortColumn,
      "sort-order": _vm.dueInFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onDueInNotePageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedDueInNotes, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("div", {
      staticClass: "is-pulled-left ml-1"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editDueInNoteRowNumber === -1 || _vm.editDueInNoteRowNumber !== index,
        expression: "editDueInNoteRowNumber === -1 || editDueInNoteRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editDueInNoteRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.editDueInNoteInnerValue,
        expression: "editDueInNoteInnerValue"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: _vm.editDueInNoteInnerValue
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.editDueInNoteInnerValue = $event.target.value;
        }
      }
    }) : _vm._e()]), _c("div", {
      staticClass: "is-clearfix"
    }), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [remark.firstName || remark.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": remark.firstName,
        "last-name": remark.lastName,
        "display-name": remark.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])], 1)]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("td", {
      staticClass: "is-content-width"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.editDueInNote(index, remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editDueInNoteRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]), _vm.editDueInNoteRowNumber === index ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.cancelEditDueInNote();
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-close mdi-24px"
    })])]) : _vm._e(), _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])]) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.innerValue.dueOutNotes.length !== 0,
      expression: "innerValue.dueOutNotes.length !== 0"
    }],
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_vm._m(3), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.dueOutFilter.pageIndex,
      "page-size": _vm.dueOutFilter.pageSize,
      "total-rows": _vm.dueOutNotesTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.dueOutFilter.sortColumn,
      "sort-order": _vm.dueOutFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onDueOutNotePageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedDueOutNotes, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("div", {
      staticClass: "is-pulled-left ml-1"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editDueOutNoteRowNumber === -1 || _vm.editDueOutNoteRowNumber !== index,
        expression: "editDueOutNoteRowNumber === -1 || editDueOutNoteRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editDueOutNoteRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.editDueOutNoteInnerValue,
        expression: "editDueOutNoteInnerValue"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: _vm.editDueOutNoteInnerValue
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.editDueOutNoteInnerValue = $event.target.value;
        }
      }
    }) : _vm._e()]), _c("div", {
      staticClass: "is-clearfix"
    }), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [remark.firstName || remark.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": remark.firstName,
        "last-name": remark.lastName,
        "display-name": remark.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])], 1)]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("td", {
      staticClass: "is-content-width"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.editDueOutNote(index, remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editDueOutNoteRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]), _vm.editDueOutNoteRowNumber === index ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.cancelEditDueOutNote();
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-close mdi-24px"
    })])]) : _vm._e(), _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])]) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])]), _c("div", {
    staticClass: "cell is-flex is-flex-direction-column grid"
  }, [_c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(4), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("button", {
    staticClass: "button is-small is-success tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Add Remarks",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(5), _c("span", [_vm._v("Remarks")])])])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.printedFilter.pageIndex,
      "page-size": _vm.printedFilter.pageSize,
      "total-rows": _vm.printedRemarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.printedFilter.sortColumn,
      "sort-order": _vm.printedFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPrintedRemarksPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedPrintedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-remark"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editPrintedRemarkRowNumber === -1 || _vm.editPrintedRemarkRowNumber !== index,
        expression: "editPrintedRemarkRowNumber === -1 || editPrintedRemarkRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editPrintedRemarkRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.editPrintedRemarkInnerValue,
        expression: "editPrintedRemarkInnerValue"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: _vm.editPrintedRemarkInnerValue
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.editPrintedRemarkInnerValue = $event.target.value;
        }
      }
    }) : _vm._e(), _vm._v(" "), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [remark.firstName || remark.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": remark.firstName,
        "last-name": remark.lastName,
        "display-name": remark.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])], 1)]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.editPrintedRemark(index, remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editPrintedRemarkRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]), _vm.editPrintedRemarkRowNumber === index ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.cancelEditPrintedRemark();
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-close mdi-24px"
    })])]) : _vm._e(), _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])]) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), _vm.showJobNoteRemarks ? _c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(6), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("button", {
    staticClass: "button is-small is-success tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Add Remarks",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(7), _c("span", [_vm._v("Remarks")])])])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.jobFilter.pageIndex,
      "page-size": _vm.jobFilter.pageSize,
      "total-rows": _vm.jobRemarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.jobFilter.sortColumn,
      "sort-order": _vm.jobFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onJobNoteRemarksPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedJobNoteRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-remark"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editJobNoteRemarkRowNumber === -1 || _vm.editJobNoteRemarkRowNumber !== index,
        expression: "editJobNoteRemarkRowNumber === -1 || editJobNoteRemarkRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editJobNoteRemarkRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.editJobNoteRemarkInnerValue,
        expression: "editJobNoteRemarkInnerValue"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: _vm.editJobNoteRemarkInnerValue
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.editJobNoteRemarkInnerValue = $event.target.value;
        }
      }
    }) : _vm._e(), _vm._v(" "), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [remark.firstName || remark.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": remark.firstName,
        "last-name": remark.lastName,
        "display-name": remark.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])], 1)]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.editJobNoteRemark(index, remark);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editJobNoteRemarkRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]), _vm.editJobNoteRemarkRowNumber === index ? _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.cancelEditJobNoteRemark();
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-close mdi-24px"
    })])]) : _vm._e(), _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])]) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]) : _vm._e(), _c("div", {
    staticClass: "cell"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(8), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.otherRemarksIdFilter,
      expression: "otherRemarksIdFilter"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.otherRemarksIdFilter = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    domProps: {
      value: 0
    }
  }, [_vm._v("All")]), _vm._l(_vm.formattedRemarkTypes, function (remark) {
    return _c("option", {
      key: remark.value,
      domProps: {
        value: remark.value
      }
    }, [_vm._v(_vm._s(remark.label))]);
  })], 2)])])])])])]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.otherFilter.pageIndex,
      "page-size": _vm.otherFilter.pageSize,
      "total-rows": _vm.otherRemarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.otherFilter.sortColumn,
      "sort-order": _vm.otherFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onOtherRemarksPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedOtherRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-remark"
    }, [_c("div", {
      domProps: {
        innerHTML: _vm._s(remark.remarks.replaceAll("\n", "<br>"))
      }
    }), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [_c("span", {
      staticClass: "is-italic"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])])]), _vm.$user.info.isSupportUser || _vm.$user.info.isCustomerAdministrator ? _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])]) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)]), _c("quote-incident-notes", {
    attrs: {
      value: _vm.innerValue.incidentNotes,
      "is-saving": _vm.isIncidentNotesSaving,
      disabled: _vm.$licenceExpired
    },
    on: {
      "text-change": _vm.onIncidentNotesTextChange,
      "date-change": _vm.onIncidentNotesDateChange,
      "notes-blur": _vm.onIncidentNotesSave,
      "date-save": _vm.onIncidentNotesSave
    }
  })], 1), _vm.value && _vm.isRemarkModalActive ? _c("remark-modal", {
    attrs: {
      "show-remark": true,
      "show-printed-remark": true,
      "show-job-note-remark": true,
      "show-recurring-remark": true,
      active: _vm.isRemarkModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRemarkModalActive = $event;
      },
      add: _vm.addRemarks,
      cancel: function cancel($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Add Quote Remarks")]), !!_vm.value.repx ? _c("div", {
    staticClass: "is-flex ml-6",
    attrs: {
      slot: "remark-last-postfix"
    },
    slot: "remark-last-postfix"
  }, [_c("bulma-checkbox", {
    model: {
      value: _vm.value.isSyncRepX,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "isSyncRepX", $$v);
      },
      expression: "value.isSyncRepX"
    }
  }), _c("div", [_c("small", [_vm._v("Sync to RepX")])])], 1) : _vm._e()]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Remarks")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Due In Notes")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Due Out Notes")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Printed Remarks")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Job Remarks")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Other Remarks")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382 ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "cell",
    staticStyle: {
      position: "relative"
    },
    attrs: {
      inert: _vm.isSaving
    }
  }, [_vm.isSaving ? _c("div", {
    staticClass: "quote-incident-notes-overlay"
  }) : _vm._e(), _c("article", {
    staticClass: "box"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Incident Date")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Incident Date",
            disabled: _vm.disabled,
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedIncidentNotesDate,
      callback: function callback($$v) {
        _vm.selectedIncidentNotesDate = $$v;
      },
      expression: "selectedIncidentNotesDate"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Notes")]), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.incidentNotesText,
      expression: "incidentNotesText"
    }],
    staticClass: "textarea",
    attrs: {
      disabled: _vm.disabled,
      placeholder: ""
    },
    domProps: {
      value: _vm.incidentNotesText
    },
    on: {
      focus: _vm.captureNotesSnapshot,
      blur: _vm.handleNotesBlur,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.incidentNotesText = $event.target.value;
      }
    }
  })])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/core-js/modules/es.string.replace-all.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es.string.replace-all.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var isRegExp = __webpack_require__(/*! ../internals/is-regexp */ "./node_modules/core-js/internals/is-regexp.js");
var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/core-js/internals/get-method.js");
var getRegExpFlags = __webpack_require__(/*! ../internals/regexp-get-flags */ "./node_modules/core-js/internals/regexp-get-flags.js");
var getSubstitution = __webpack_require__(/*! ../internals/get-substitution */ "./node_modules/core-js/internals/get-substitution.js");
var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");

var REPLACE = wellKnownSymbol('replace');
var $TypeError = TypeError;
var indexOf = uncurryThis(''.indexOf);
var replace = uncurryThis(''.replace);
var stringSlice = uncurryThis(''.slice);
var max = Math.max;

// `String.prototype.replaceAll` method
// https://tc39.es/ecma262/#sec-string.prototype.replaceall
$({ target: 'String', proto: true }, {
  replaceAll: function replaceAll(searchValue, replaceValue) {
    var O = requireObjectCoercible(this);
    var IS_REG_EXP, flags, replacer, string, searchString, functionalReplace, searchLength, advanceBy, position, replacement;
    var endOfLastMatch = 0;
    var result = '';
    if (isObject(searchValue)) {
      IS_REG_EXP = isRegExp(searchValue);
      if (IS_REG_EXP) {
        flags = toString(requireObjectCoercible(getRegExpFlags(searchValue)));
        if (!~indexOf(flags, 'g')) throw new $TypeError('`.replaceAll` does not allow non-global regexes');
      }
      replacer = getMethod(searchValue, REPLACE);
      if (replacer) return call(replacer, searchValue, O, replaceValue);
      if (IS_PURE && IS_REG_EXP) return replace(toString(O), searchValue, replaceValue);
    }
    string = toString(O);
    searchString = toString(searchValue);
    functionalReplace = isCallable(replaceValue);
    if (!functionalReplace) replaceValue = toString(replaceValue);
    searchLength = searchString.length;
    advanceBy = max(1, searchLength);
    position = indexOf(string, searchString);
    while (position !== -1) {
      replacement = functionalReplace
        ? toString(replaceValue(searchString, position, string))
        : getSubstitution(searchString, string, position, [], undefined, replaceValue);
      result += stringSlice(string, endOfLastMatch, position) + replacement;
      endOfLastMatch = position + searchLength;
      position = position + advanceBy > string.length ? -1 : indexOf(string, searchString, position + advanceBy);
    }
    if (endOfLastMatch < string.length) {
      result += stringSlice(string, endOfLastMatch);
    }
    return result;
  }
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".small-font[data-v-04be1244] {\n  font-size: 10px;\n}\n.cell > article.box[data-v-04be1244] {\n  min-height: 300px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-remarks-licence-expired .button[disabled]:not(.tooltip) {\n  position: relative;\n  opacity: 1;\n  cursor: not-allowed;\n}\n.quote-remarks-licence-expired .button[disabled]:not(.tooltip) > .icon {\n  opacity: 0.5;\n}\n.quote-remarks-licence-expired .button[disabled]:not(.tooltip):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  right: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-incident-notes-overlay {\n  position: absolute;\n  inset: 0;\n  z-index: 20;\n  pointer-events: all;\n  overflow: hidden;\n  border-radius: var(--bulma-radius-small, 4px);\n  background: color-mix(in srgb, var(--bulma-scheme-main) 40%, transparent);\n}\n.quote-incident-notes-overlay::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 2px;\n  background: var(--bulma-primary);\n  opacity: 0.7;\n}\n.quote-incident-notes-overlay::after {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: -webkit-gradient(linear, left top, right top, from(transparent), color-stop(50%, color-mix(in srgb, var(--bulma-primary) 14%, transparent)), to(transparent));\n  background: linear-gradient(90deg, transparent 0%, color-mix(in srgb, var(--bulma-primary) 14%, transparent) 50%, transparent 100%);\n  -webkit-transform: translateX(-100%);\n          transform: translateX(-100%);\n  -webkit-animation: incident-notes-saving-shimmer 1.6s ease-in-out infinite;\n          animation: incident-notes-saving-shimmer 1.6s ease-in-out infinite;\n}\n@-webkit-keyframes incident-notes-saving-shimmer {\n0% {\n    -webkit-transform: translateX(-100%);\n            transform: translateX(-100%);\n}\n100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n}\n}\n@keyframes incident-notes-saving-shimmer {\n0% {\n    -webkit-transform: translateX(-100%);\n            transform: translateX(-100%);\n}\n100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7f39a7a6", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4384638c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("b46060ec", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteRemarks.vue":
/*!******************************************!*\
  !*** ./src/views/quote/QuoteRemarks.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true */ "./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true");
/* harmony import */ var _QuoteRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteRemarks.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true */ "./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true");
/* harmony import */ var _QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss */ "./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "04be1244",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteRemarks.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=0&id=04be1244&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_0_id_04be1244_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss":
/*!***************************************************************************************!*\
  !*** ./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=style&index=1&id=04be1244&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_style_index_1_id_04be1244_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true":
/*!************************************************************************************!*\
  !*** ./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteRemarks.vue?vue&type=template&id=04be1244&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteRemarks_vue_vue_type_template_id_04be1244_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue":
/*!************************************************************************!*\
  !*** ./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteIncidentNotes.vue?vue&type=template&id=19cbd382 */ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382");
/* harmony import */ var _QuoteIncidentNotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteIncidentNotes.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss */ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteIncidentNotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js":
/*!************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteIncidentNotes.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss":
/*!*********************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=style&index=0&id=19cbd382&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_style_index_0_id_19cbd382_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382":
/*!******************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382 ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteIncidentNotes.vue?vue&type=template&id=19cbd382 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteRemarks/QuoteIncidentNotes.vue?vue&type=template&id=19cbd382");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteIncidentNotes_vue_vue_type_template_id_19cbd382__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/helpers/QuoteRemarksAutoSaveHelper.js":
/*!***************************************************************!*\
  !*** ./src/views/quote/helpers/QuoteRemarksAutoSaveHelper.js ***!
  \***************************************************************/
/*! exports provided: createQuoteRemarksAutoSaveHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createQuoteRemarksAutoSaveHelper", function() { return createQuoteRemarksAutoSaveHelper; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/services/RemarkService */ "./src/services/RemarkService.js");





function createQuoteRemarksAutoSaveHelper(onSavingChange) {
  var _queue = Promise.resolve();
  var _pendingCount = 0;
  function enqueue(operation) {
    _pendingCount++;
    if (_pendingCount === 1) onSavingChange === null || onSavingChange === void 0 || onSavingChange(true);
    var slot = _queue.then(operation).catch(function () {}).finally(function () {
      _pendingCount--;
      if (_pendingCount === 0) onSavingChange === null || onSavingChange === void 0 || onSavingChange(false);
    });
    _queue = slot;
    return slot;
  }
  return {
    add: function add(remark) {
      enqueue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].postEntity(remark);
            case 1:
              remark.isNew = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      })));
    },
    update: function update(remark) {
      enqueue(function () {
        return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].putEntity(remark);
      });
    },
    pin: function pin(affectedRemarks) {
      enqueue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var _iterator, _step, remark, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(affectedRemarks);
              _context2.p = 1;
              _iterator.s();
            case 2:
              if ((_step = _iterator.n()).done) {
                _context2.n = 4;
                break;
              }
              remark = _step.value;
              _context2.n = 3;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].putEntity(remark);
            case 3:
              _context2.n = 2;
              break;
            case 4:
              _context2.n = 6;
              break;
            case 5:
              _context2.p = 5;
              _t = _context2.v;
              _iterator.e(_t);
            case 6:
              _context2.p = 6;
              _iterator.f();
              return _context2.f(6);
            case 7:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 5, 6, 7]]);
      })));
    },
    delete: function _delete(remark) {
      // Always enqueue — for new remarks whose add hasn't fired yet, the queue runs
      // add first (same client GUID is honoured server-side), then delete.
      enqueue(function () {
        return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].deleteEntity(remark.remarkId);
      });
    },
    saveIncidentNotes: function saveIncidentNotes(remark) {
      return enqueue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!(remark.isNew || !remark.remarkId)) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].postEntity(remark);
            case 1:
              remark.isNew = false;
              _context3.n = 3;
              break;
            case 2:
              _context3.n = 3;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_4__["default"].putEntity(remark);
            case 3:
              return _context3.a(2);
          }
        }, _callee3);
      })));
    }
  };
}

/***/ })

}]);
//# sourceMappingURL=quote-remarks-chunk.js.map