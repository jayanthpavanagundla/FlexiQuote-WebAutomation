(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-summary-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _QuoteDetailSummary__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./QuoteDetailSummary */ "./src/views/quote/QuoteDetailSummary.vue");
/* harmony import */ var _QuoteDetailAssessmentSummary__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./QuoteDetailAssessmentSummary */ "./src/views/quote/QuoteDetailAssessmentSummary.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/enums/JobStageTypes */ "./src/enums/JobStageTypes.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");





























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteSummary',
  inject: ['$vv'],
  components: {
    QuoteDetailSummary: _QuoteDetailSummary__WEBPACK_IMPORTED_MODULE_23__["default"],
    QuoteDetailAssessmentSummary: _QuoteDetailAssessmentSummary__WEBPACK_IMPORTED_MODULE_24__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_22__["default"]],
  props: {
    value: null,
    insurer: null
  },
  data: function data() {
    return {
      innerValue: null,
      selectedQuoteDate: null,
      selectedJobStage: null,
      sortKey: null,
      quoters: [],
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      modelConfig: {
        start: {
          timeAdjust: '08:00:00'
        },
        end: {
          timeAdjust: '08:00:00'
        }
      },
      isPauseWatch: false,
      bookedInSortKey: null,
      dragValue: null,
      jobStartDate: null,
      jobEndDate: null,
      inspectionStartDate: null,
      inspectionEndDate: null,
      arrivedForRepairDate: null,
      isRepairLateReasonActive: false,
      oriJobStartDate: null,
      oriJobEndDate: null,
      quoteRepx: null,
      innerJobNSubJobStageCompositeKey: null,
      vehicleDepartedDate: null,
      repairBookedDate: null,
      isArrived: false,
      isDeparted: false
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    selectDragAttribute: function selectDragAttribute() {
      return {
        popover: {
          visibility: 'hover',
          isInteractive: false // Defaults to true when using slot
        }
      };
    },
    filteredQuoters: function filteredQuoters() {
      var _this = this;
      return this.quoters.filter(function (option) {
        return option.toString().toLowerCase().indexOf(_this.innerValue.quoter.toLowerCase()) >= 0;
      });
    },
    canChangeReadOnly: function canChangeReadOnly() {
      return this.$userInfo.isSupportUser || this.$userInfo.isCustomerAdministrator;
    },
    invoice: function invoice() {
      return this.innerValue.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_25__["InvoiceTypes"].Quote;
      });
    },
    excessInvoice: function excessInvoice() {
      return this.innerValue.invoices.find(function (i) {
        return !i.isNew && !i.deleted && i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_25__["InvoiceTypes"].Excess;
      });
    },
    ormJobEndJobEndValidationText: function ormJobEndJobEndValidationText() {
      if (!this.$v.entity.jobStart.required || !this.$v.entity.jobEnd.required) {
        return 'Required by ORM';
      } else if (!this.$v.entity.jobStart.validJobStart || !this.$v.entity.jobEnd.validJobEnd) {
        return 'Invalid date range';
      }
    },
    assessmentHistoryToggleDisable: function assessmentHistoryToggleDisable() {
      if (this.value.quoteAssessments && this.value.quoteAssessments.length > 0) {
        return true;
      }
      if (this.value.invoices && this.value.invoices.length > 0) {
        return true;
      }
      if (this.value.orm && this.value.orm.messageNo != '0') {
        return true;
      }
      if (this.value.subQuoteNos.length > 1) {
        return true;
      }
      return false;
    },
    isInspectionBookingDateExist: function isInspectionBookingDateExist() {
      return this.innerValue.quoteCycleTime.inspectionBookingDate != null && this.innerValue.quoteCycleTime.inspectionBookingDate != undefined && this.innerValue.repx != null;
      // return this.innerValue.inspectionBookingStart != null && this.innerValue.inspectionBookingStart != undefined && this.innerValue.repx!=null
    },
    // isSubJobStagesAvailable() {
    //   return this.subJobStagesBySelectedJobStage != null && this.subJobStagesBySelectedJobStage.length > 0
    // },
    // subJobStagesBySelectedJobStage() {
    //   return this.subJobStages.filter((i) => i.jobStage == this.innerValue.jobStage)
    // },
    isRepairBooked: function isRepairBooked() {
      return this.innerValue.isRepairBooked;
    },
    isRepx: function isRepx() {
      return this.innerValue.repx != null;
    },
    isRepairStartDateSynced: function isRepairStartDateSynced() {
      return this.quoteRepx ? this.quoteRepx.isRepairStartDateSynced : false;
    },
    // jobNSubJobStageCompositeKey() {
    //   let jobStage = this.innerValue.jobStage == null ? '' : ''
    //   let subJobStage = this.innerValue.subJobStage == null ? '' : ''
    //   return this.innerValue.jobStage || '' + '|' + subJobStage
    // }
    jobNSubJobStagesOptions: function jobNSubJobStagesOptions() {
      var _this2 = this;
      var isDisableParentWithSub = !!this.isRepx;
      var groupedStages = {};

      // Group job stages and sub job stages
      this.jobNSubJobStages.forEach(function (option) {
        var jobStageId = option.jobStageId;
        var jobStageName = option.jobStageName;
        if (!groupedStages[jobStageId]) {
          // Get sort key from jobStages array
          var jobStageInfo = _this2.jobStages ? _this2.jobStages.find(function (js) {
            return js.stage === jobStageId;
          }) : null;
          var jobStageSortKey = jobStageInfo ? jobStageInfo.sortKey : 999;
          groupedStages[jobStageId] = {
            jobStageId: jobStageId,
            jobStageName: jobStageName,
            jobStageSortKey: jobStageSortKey,
            mainStage: {
              compositeKey: "".concat(jobStageId, "|"),
              compositeName: jobStageName,
              disabled: false
            },
            subStages: []
          };
        }

        // If this option has a sub job stage, add it to the subStages array
        if (option.subJobStageId && option.subJobStageId !== '') {
          groupedStages[jobStageId].subStages.push(option);
          // If there are sub stages, disable the parent stage if needed
          if (isDisableParentWithSub) {
            groupedStages[jobStageId].mainStage.disabled = true;
          }
        }
      });

      // Convert to array and sort by jobStageSortKey
      var sortedGroups = Object.values(groupedStages).sort(function (a, b) {
        return (a.jobStageSortKey || 999) - (b.jobStageSortKey || 999);
      });

      // Sort sub stages within each group by sortKey
      sortedGroups.forEach(function (group) {
        group.subStages.sort(function (a, b) {
          return (a.sortKey || 999) - (b.sortKey || 999);
        });
      });
      return sortedGroups;
    },
    //TEMP check for GEMCan company - REMOVE AFTER ASSESSMENT HISTORY PHASE 2
    tempGemCan: function tempGemCan() {
      return this.$userInfo.isCustomerAdministrator && this.$company.info.companyId === 'a5ffbdc0-41d2-4e7f-8ecf-e51beac57e6b';
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        if (!this.isPauseWatch) {
          this.$emit('input', newVal);
        }
      },
      deep: true
    },
    selectedQuoteDate: function selectedQuoteDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.quoteDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.quoteDate = null;
      }
    },
    jobStartDate: function jobStartDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.jobStart = newVal.toISOString().split('.')[0] + 'Z';
        if (this.innerValue.jobEnd && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn;
          this.innerValue.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn;
        }
      } else {
        this.innerValue.jobStart = null;
      }
    },
    jobEndDate: function jobEndDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.jobEnd = newVal.toISOString().split('.')[0] + 'Z';
        //to prompt late reason
        this.isRepairLateReasonActive = this.compare1DateTo2(newVal, this.oriJobEndDate);
        if (this.innerValue.jobStart && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn;
          this.innerValue.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn;
        }
      } else {
        this.innerValue.jobEnd = null;
      }
    },
    arrivedForRepairDate: function arrivedForRepairDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.quoteCycleTime.arrivedForRepairDate = newVal.toISOString().split('.')[0] + 'Z';
        this.isArrived = true;
        if (this.innerValue.quoteCycleTime.arrivedForRepairDate && isNaN(oldVal)) {
          this.innerValue.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].VehicleArrived;
        }
      } else {
        this.innerValue.quoteCycleTime.arrivedForRepairDate = null;
      }
    },
    vehicleDepartedDate: function vehicleDepartedDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.quoteCycleTime.vehicleDepartedDate = newVal.toISOString().split('.')[0] + 'Z';
        this.isDeparted = true;
        if (this.innerValue.quoteCycleTime.vehicleDepartedDate && isNaN(oldVal)) {
          this.innerValue.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].VehicleReady;
        }
      } else {
        this.innerValue.quoteCycleTime.vehicleDepartedDate = null;
      }
    },
    repairBookedDate: function repairBookedDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.quoteCycleTime.repairBookedDate = newVal.toISOString().split('.')[0] + 'Z';
        console.log(this.innerValue.quoteCycleTime.repairBookedDate);
      } else {
        this.innerValue.quoteCycleTime.repairBookedDate = null;
      }
    }
  },
  created: function created() {
    var _this3 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this3.getQuoters();
            _this3.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_20___default()(_this3.value);
            _this3.selectedQuoteDate = new Date("".concat(_this3.innerValue.quoteDate));
            _this3.selectedJobStage = _this3.innerValue.jobStage;
            _this3.sortKey = _this3.getJobStageSortKey(_this3.innerValue.jobStage);
            _this3.bookedInSortKey = _this3.getJobStageSortKey(_enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn);
            if (_this3.innerValue.jobStart) {
              _this3.jobStart = new Date("".concat(_this3.innerValue.jobStart));
              _this3.selectedJobStart = new Date("".concat(_this3.innerValue.jobStart));
              _this3.jobStartDate = new Date("".concat(_this3.innerValue.jobStart));
              _this3.oriJobStartDate = _this3.jobStartDate;
            }
            if (_this3.innerValue.jobEnd) {
              _this3.jobEnd = new Date("".concat(_this3.innerValue.jobEnd));
              _this3.selectedJobEnd = new Date("".concat(_this3.innerValue.jobEnd));
              _this3.jobEndDate = new Date("".concat(_this3.innerValue.jobEnd));
              _this3.oriJobEndDate = _this3.jobEndDate;
            }
            // if (this.innerValue.inspectionBookingStart) this.inspectionStartDate = new Date(`${this.innerValue.inspectionBookingStart}`)
            // if (this.innerValue.inspectionBookingEnd) this.inspectionEndDate = new Date(`${this.innerValue.inspectionBookingEnd}`)
            if (_this3.innerValue.quoteCycleTime.inspectionBookingDate) _this3.inspectionStartDate = new Date("".concat(_this3.innerValue.quoteCycleTime.inspectionBookingDate));
            if (_this3.innerValue.quoteCycleTime.arrivedForRepairDate) _this3.arrivedForRepairDate = new Date("".concat(_this3.innerValue.quoteCycleTime.arrivedForRepairDate));
            if (_this3.innerValue.quoteCycleTime.vehicleDepartedDate) _this3.vehicleDepartedDate = new Date("".concat(_this3.innerValue.quoteCycleTime.vehicleDepartedDate));
            if (_this3.innerValue.quoteCycleTime.repairBookedDate) _this3.repairBookedDate = new Date("".concat(_this3.innerValue.quoteCycleTime.repairBookedDate));
            _this3.setInscopeDefault();
            _context.n = 1;
            return _this3.loadQuoteRepxIfExist();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    var _this4 = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved, /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            _this4.isPauseWatch = true;
            _this4.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_20___default()(_this4.value);
            _context2.n = 1;
            return _this4.loadQuoteRepxIfExist();
          case 1:
            _this4.isPauseWatch = false;
          case 2:
            return _context2.a(2);
        }
      }, _callee2);
    })));
    var jobStage = this.innerValue.jobStage;
    if (jobStage) {
      var subJobStage = this.innerValue.subJobStage || '';
      this.innerJobNSubJobStageCompositeKey = jobStage + '|' + subJobStage;
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved);
  },
  methods: {
    compare1DateTo2: function compare1DateTo2(dateStr1, dateStr2) {
      if (dateStr1 && dateStr2) {
        var date1 = new Date(dateStr1);
        var date2 = new Date(dateStr2);
        if (date1 > date2) {
          return true;
        }
      }
      return false;
    },
    quoteDateInputEvent: function quoteDateInputEvent(event) {
      this.selectedQuoteDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    inScopeOnChange: function inScopeOnChange(event) {
      this.innerValue.inScope = !!event.target.checked;
    },
    driveableOnChange: function driveableOnChange(event) {
      this.innerValue.driveable = !!event.target.checked;
    },
    assessmentHistoryChange: function assessmentHistoryChange(event) {
      this.innerValue.isAssessmentEnabled = !!event.target.checked;
    },
    clearArrivedForRepairDate: function clearArrivedForRepairDate() {
      if (this.arrivedForRepairDate !== null) {
        this.arrivedForRepairDate = null;
        this.isArrived = false;
      }
    },
    clearVehicleDepartedDate: function clearVehicleDepartedDate() {
      if (this.vehicleDepartedDate !== null) {
        this.vehicleDepartedDate = null;
        this.isDeparted = false;
      }
    },
    clearRepairBookedDate: function clearRepairBookedDate() {
      if (this.repairBookedDate !== null) {
        this.repairBookedDate = null;
      }
    },
    resetJobStartEnd: function resetJobStartEnd() {
      if (!this.isRepx || !this.isRepairStartDateSynced) {
        if (this.jobStartDate !== null) {
          this.jobStartDate = null;
        }
      }
      if (this.jobEndDate !== null) {
        this.jobEndDate = null;
      }
      if (this.selectedJobStage == _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].BookedIn && this.insurer.autoBookedInForDueInOut) {
        this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].FollowUpRequired;
        this.innerValue.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_27__["default"].FollowUpRequired;
      }

      // Reset validation objects
      this.$v.entity.jobStart.$reset();
      this.$v.entity.jobEnd.$reset();
    },
    jobStartEndDragEvent: function jobStartEndDragEvent(event) {
      this.dragValue = event;
    },
    jobStartEndInputEvent: function jobStartEndInputEvent(event) {},
    getQuoters: function getQuoters() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_21__["QuoteService"].getQuoters();
            case 1:
              _this5.quoters = _context3.v;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    formatJobStage: function formatJobStage(value) {
      if (value.toLowerCase() === 'none') {
        return '-- Job Stage --';
      } else {
        return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
          return str.toUpperCase();
        });
      }
    },
    formatSubJobStage: function formatSubJobStage(value) {
      if (value.toLowerCase() === '' || value == null) {
        return '-- Sub Job Stage --';
      } else {
        return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
          return str.toUpperCase();
        });
      }
    },
    displayJobStage: function displayJobStage(jobNSubJobStages) {
      var compositeName = jobNSubJobStages.compositeName,
        subJobStageId = jobNSubJobStages.subJobStageId,
        subJobStageName = jobNSubJobStages.subJobStageName;
      var hasSubJobStage = subJobStageId;
      var name = hasSubJobStage ? subJobStageName : compositeName;
      if (name.toLowerCase() === '' || name == null) {
        return '-- Sub Job Stage --';
      } else {
        name = this.formatJobStage(name);
      }
      return hasSubJobStage ? "\xA0\xA0\xA0 ".concat(name) : name;
    },
    toogleReadOnly: function toogleReadOnly() {
      if (this.canChangeReadOnly) {
        this.innerValue.readOnly = !this.innerValue.readOnly;
        this.innerValue.readOnlyStatuses.splice(this.innerValue.subQuoteNo, 1, this.innerValue.readOnly);
      }
    },
    toggleActive: function toggleActive(active) {
      this.innerValue.deleted = !this.innerValue.deleted;
    },
    getNoOfDays: function getNoOfDays(startDate, endDate) {
      var d1 = luxon__WEBPACK_IMPORTED_MODULE_26__["DateTime"].fromISO(startDate.toISOString());
      var d2 = luxon__WEBPACK_IMPORTED_MODULE_26__["DateTime"].fromISO(endDate.toISOString());
      return d2.diff(d1, 'days').toObject().days + 1;
    },
    getJobStageSortKey: function getJobStageSortKey(stageId) {
      var index = this.jobStages.findIndex(function (i) {
        return i.stage === stageId;
      });
      var sortKey = this.jobStages[index].sortKey;
      return sortKey;
    },
    setInscopeDefault: function setInscopeDefault() {
      if (this.innerValue.isNew && this.insurer.inScope) {
        this.innerValue.inScope = this.insurer.inScope;
      }
    },
    jobStartDateInputEvent: function jobStartDateInputEvent(event) {},
    jobEndDateInputEvent: function jobEndDateInputEvent(event) {},
    handleJobStageChanged: function handleJobStageChanged() {
      this.innerValue.subJobStage = null;
    },
    handleJobNSubJobStageChanged: function handleJobNSubJobStageChanged(event) {
      var selected = event.target.value;
      if (selected && selected.includes('|')) {
        var result = selected.split('|');
        this.innerValue.jobStage = result[0] || null;
        this.innerValue.subJobStage = result[1] || null;
      } else {
        this.innerValue.jobStage = null;
        this.innerValue.subJobStage = null;
      }
    },
    handleRepairLateReasonClose: function handleRepairLateReasonClose() {
      this.isRepairLateReasonActive = false;
    },
    loadQuoteRepxIfExist: function loadQuoteRepxIfExist() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var quoteRepx;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_28__["default"].getQuoteRepx(_this6.innerValue.quoteId);
            case 1:
              quoteRepx = _context4.v;
              if (quoteRepx) {
                _this6.quoteRepx = quoteRepx;
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    isArrivedOnChange: function isArrivedOnChange(event) {
      this.isArrived = !!event.target.checked;
      if (!this.isArrived) {
        this.clearArrivedForRepairDate();
      } else {
        this.arrivedForRepairDate = new Date();
      }
    },
    isDepartedOnChange: function isDepartedOnChange(event) {
      this.isDeparted = !!event.target.checked;
      if (!this.isDeparted) {
        this.clearVehicleDepartedDate();
      } else {
        this.vehicleDepartedDate = new Date();
      }
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.jobStages && _vm.jobStages.length > 0 ? _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-6"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Totals")]), !_vm.value.isAssessmentEnabled ? _c("quote-detail-summary", {
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }) : _c("quote-detail-assessment-summary", {
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  })], 1)])]) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".readonly-pointer[data-v-45c47b77] {\n  cursor: pointer;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("34e43892", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteSummary.vue":
/*!******************************************!*\
  !*** ./src/views/quote/QuoteSummary.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true */ "./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true");
/* harmony import */ var _QuoteSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteSummary.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true */ "./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "45c47b77",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteSummary.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSummary.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=style&index=0&id=45c47b77&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_style_index_0_id_45c47b77_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true":
/*!************************************************************************************!*\
  !*** ./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteSummary.vue?vue&type=template&id=45c47b77&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteSummary_vue_vue_type_template_id_45c47b77_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/storeMixin.js":
/*!***************************************!*\
  !*** ./src/views/quote/storeMixin.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");













var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  created: function created() {
    this.getCompanyItemTypes();
    this.getJobStages(); // Store job stages in vuex
    // this.getExternalSetting('partscheck')
    //this.getSubJobStages() // Store job stages in vuex
    this.getJobNSubJobStages();
    this.getExternalSetting('partscheck');
    // if (this.$route.name !== QuoteRoutes.QuoteListView.name && this.value) {
    //   console.log('get vvvv')
    //   this.getQuoteVehicle(this.value.vehicleId)
    // }
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    companyItemTypes: 'companyItemTypes',
    currentVehicleSnapshot: 'currentVehicleSnapshot',
    currentCustomerSnapshot: 'currentCustomerSnapshot',
    currentInsurerSnapshot: 'currentInsurerSnapshot',
    quoteVehicle: 'quoteVehicle',
    quoteCustomer: 'quoteCustomer',
    quoteInsurer: 'quoteInsurer',
    emtaVehicleStore: 'emtaVehicle',
    standardLabourItems: 'standardLabourItems',
    ntarLoadingItems: 'ntarLoadingItems',
    ntarOtherLoadingItems: 'ntarOtherLoadingItems',
    ntarLoadingValues: 'ntarLoadingValues',
    jobStages: 'jobStages',
    subJobStages: 'subJobStages',
    jobNSubJobStages: 'jobNSubJobStages',
    repairDelayReasons: 'repairDelayReasons',
    partsCheckSettingExists: 'partsCheckSettingExists',
    readOnlyView: 'readOnlyView',
    previousQuoteId: 'previousQuoteId',
    audanetLock: 'audanetLock',
    snapshotDiffVehicle: 'snapshotDiffVehicle',
    snapshotDiffCustomer: 'snapshotDiffCustomer',
    snapshotDiffInsurer: 'snapshotDiffInsurer',
    partsCheckSetting: 'partsCheckSetting'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])(moduleName, ['load', 'getStoreItem', 'getLiteStoreItem', 'addStoreItem', 'addStoreSupplementaryItem', 'saveSnapshot', 'setBaseSnapshot', 'setBaseSnapshotFields', 'clearSnapshots', 'clearHeaders', 'setReturnRoute', 'getCompanyItemTypes', 'getQuoteVehicle', 'getNewVehicle', 'removeQuoteVehicle', 'getQuoteCustomer', 'getNewCustomer', 'removeQuoteCustomer', 'getEmtaVehicle', 'setEmtaVehicle', 'resetEmtaVehicle', 'clearInvoiceState', 'copyStoreQuote', 'getQuoteInsurer', 'getNewInsurer', 'setQuoteInsurer', 'removeQuoteInsurer', 'getStandardLabourItems', 'getNtarLoadingItems', 'getNtarOtherLoadingItems', 'removeLabourItems', 'getNtarLoadingValues', 'getJobStages', 'getSubJobStages', 'getJobNSubJobStages', 'removeJobStages', 'getExternalSetting', 'setReadOnlyView', 'setPreviousQuoteId', 'setAudaNetLock', 'setQuoteVehicle', 'saveVehicleSnapshot', 'saveCustomerSnapshot', 'saveInsurerSnapshot', 'resetJobNSubJobStages'])), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('insurers', {
    setInsurerReturnRoute: 'setReturnRoute',
    editStoreInsurer: 'editStoreItem',
    addStoreInsurer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('vehicles', {
    setVehicleReturnRoute: 'setReturnRoute',
    editStoreVehicle: 'editStoreItem',
    addStoreVehicle: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  })),
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(to, from, next) {
      var isQuoteRoutes;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            // remove quote vehicle, customer & insurer vuex objects when leaving quote pages
            isQuoteRoutes = Object.values(_route_types__WEBPACK_IMPORTED_MODULE_12__["default"]).filter(function (r) {
              return r.name !== _route_types__WEBPACK_IMPORTED_MODULE_12__["default"].QuoteListView.name;
            }).find(function (r) {
              return r.name === to.name;
            });
            if (!isQuoteRoutes) {
              this.resetEmtaVehicle();
              this.removeLabourItems();
            }
            next();
          case 1:
            return _context.a(2);
        }
      }, _callee, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ })

}]);
//# sourceMappingURL=quote-summary-chunk.js.map