(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-imagesbreakout-chunk~shared"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ImageService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ImageService */ "./src/components/BulmaCarousel/ImageService.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");












/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BulmaCarousel',
  props: {
    imageIds: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    startIndex: {
      type: Number,
      default: 0
    },
    imageWidth: {
      type: Number,
      default: 800
    },
    imageHeight: {
      type: Number,
      default: 600
    }
  },
  data: function data() {
    return {
      imageBase64: '',
      imageIndex: this.startIndex,
      imageCount: this.imageIds.length,
      isLoading: false,
      images: [],
      showZoom: false,
      showMagnifier: false,
      zoom: {
        // scale is expressed as a fraction of the image's NATIVE resolution:
        // 1.0 = native 1:1 (sharpest, all captured detail). See lensBackgroundSize().
        scale: 1.0,
        zoom: true
      }
    };
  },
  computed: {
    isLoadingFirstImage: function isLoadingFirstImage() {
      return !this.images[this.startIndex] || this.images[this.startIndex] === undefined;
    }
  },
  watch: {
    imageBase64: function imageBase64(newVal, oldVal) {
      this.notifyOrientation();
    },
    // change cursor zoom in / zoom out when zoom changes
    zoom: {
      handler: function handler(newVal, oldVal) {
        var magnifiedImage = document.querySelector('#img-2-bg');
        var zoomerBox = document.querySelector('#img-zoomer-box');
        var original = document.querySelector('#img-1');
        if (!magnifiedImage || !zoomerBox || !original) return;
        zoomerBox.style.cursor = newVal.zoom ? 'zoom-in' : 'zoom-out';
        var bg = this.lensBackgroundSize(original);
        magnifiedImage.style.backgroundSize = bg.width + 'px ' + bg.height + 'px';
      },
      deep: true
    }
  },
  created: function created() {
    this.images = new Array(this.imageIds.length);
    this.initSelectedIds(this.imageIds.length);
    this.getImage();
    // this.getThumbnails()
  },
  mounted: function mounted() {
    window.addEventListener('wheel', this.onWheel);
  },
  methods: {
    getThumbnail: function getThumbnail(id, index) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var thumbnail;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _ImageService__WEBPACK_IMPORTED_MODULE_10__["default"].getImageThumbnail(id, 800);
            case 1:
              thumbnail = _context.v;
              _this.images.splice(index, 1, thumbnail);
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getThumbnails: function getThumbnails() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var vm, promises;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isLoading = true;
              vm = _this2;
              _this2.images = new Array(_this2.imageIds.length);
              _this2.initSelectedIds(_this2.imageIds.length);
              promises = _this2.imageIds.map(function (id, index) {
                vm.getThumbnail(id, index);
              });
              _context2.n = 1;
              return Promise.all(promises);
            case 1:
              // console.log(this.images[this.startIndex])
              _this2.isLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    initSelectedIds: function initSelectedIds(length) {
      this.imagesSelected = new Array(length);
      var size = length;
      while (size--) {
        this.imagesSelected.splice(size, 1, false);
      }
    },
    getImage: function getImage(action) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isLoading = true;
              // if (action === 'prev') {
              //   this.images[0] = !this.images[1] ? this.images[1] : (this.imageIndex > 0 ? await ImageService.getImageThumbnail(this.imageIds[this.imageIndex - 1], 800) : '')
              //   this.images[1] = !this.images[2] ? this.images[2] : await ImageService.getImageThumbnail(this.imageIds[this.imageIndex], 800)
              //   this.images[2] = await ImageService.getImageThumbnail(this.imageIds[this.imageIndex + 1], 800)
              // } else if (action === 'next') {
              //   this.images[0] = await ImageService.getImageThumbnail(this.imageIds[this.imageIndex - 1], 800)
              //   this.images[1] = !this.images[0] ? this.images[0] : await ImageService.getImageThumbnail(this.imageIds[this.imageIndex], 800)
              //   this.images[2] = this.imageIndex < this.imageCount - 1 ? await ImageService.getImageThumbnail(this.imageIds[this.imageIndex + 1], 800) : ''
              // } else {
              //   this.images[0] = this.imageIndex > 0 ? await ImageService.getImageThumbnail(this.imageIds[this.imageIndex - 1], 800) : ''
              //   this.images[1] = await ImageService.getImageThumbnail(this.imageIds[this.imageIndex], 800)
              //   this.images[2] = this.imageIndex < this.imageCount - 1 ? await ImageService.getImageThumbnail(this.imageIds[this.imageIndex + 1], 800) : ''
              // }
              if (!(_this3.images[_this3.imageIndex] !== undefined)) {
                _context3.n = 1;
                break;
              }
              _this3.imageBase64 = _this3.images[_this3.imageIndex];
              _context3.n = 3;
              break;
            case 1:
              _context3.n = 2;
              return _ImageService__WEBPACK_IMPORTED_MODULE_10__["default"].getImage(_this3.imageIds[_this3.imageIndex]);
            case 2:
              _this3.imageBase64 = _context3.v;
              _this3.images.splice(_this3.imageIndex, 1, _this3.imageBase64);
            case 3:
              _this3.isLoading = false;
            case 4:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    previousImage: function previousImage() {
      if (this.imageIndex > 0) {
        this.imageIndex--;
        this.getImage('prev');
      }
    },
    nextImage: function nextImage() {
      if (this.imageIndex < this.imageCount - 1) {
        this.imageIndex++;
        this.getImage('next');
      }
    },
    notifyOrientation: function notifyOrientation() {
      var i = new Image();
      var vm = this;
      i.onload = function () {
        // console.log({ w: i.width, h: i.height })
        var o = i.width > i.height ? _enums__WEBPACK_IMPORTED_MODULE_11__["ImageOrientationTypes"].Landscape : _enums__WEBPACK_IMPORTED_MODULE_11__["ImageOrientationTypes"].Portrait;
        vm.$emit('orientation', o);
      };
      i.src = this.images[this.imageIndex];
    },
    handleMouseOver: function handleMouseOver(event) {
      if (this.showMagnifier) {
        var x = event.offsetX || layerX;
        var y = event.offsetY || layerY;
        this.handleImageAndMousePosition(event, x, y);
      }
    },
    // Size the lens' background image relative to the source's NATIVE resolution
    // instead of the shrunk-to-fit on-screen size. this.zoom.scale = 1.0 renders
    // the source at true 1:1 (maximum real detail); values above 1.0 interpolate.
    // Never go below the on-screen size, so the lens always magnifies at least a
    // little even for small source images (where there's no extra detail to show).
    lensBackgroundSize: function lensBackgroundSize(original) {
      var naturalWidth = original.naturalWidth || original.offsetWidth;
      var naturalHeight = original.naturalHeight || original.offsetHeight;
      var width = Math.max(naturalWidth * this.zoom.scale, original.offsetWidth);
      return {
        width: width,
        height: width * (naturalHeight / naturalWidth)
      };
    },
    handleImageAndMousePosition: function handleImageAndMousePosition(event, offsetX, offsetY) {
      this.showZoom = true;
      // original image
      var original = document.querySelector('#img-1');
      // magnified image magnifier/container
      var magnified = document.querySelector('#img-2');
      // image inside of magnifier
      var magnifiedImage = document.querySelector('#img-2-bg');
      var style = magnified === null || magnified === void 0 ? void 0 : magnified.style;
      var imgStyle = magnifiedImage === null || magnifiedImage === void 0 ? void 0 : magnifiedImage.style;
      if (!style || !imgStyle) return;

      // setting background image on the fly
      imgStyle.backgroundImage = 'url(' + original.src + ')';

      // offsets when mouse moves over image and layers when clicked on image

      var x = offsetX;
      var y = offsetY;
      var imgWidth = original.offsetWidth;
      var imgHeight = original.offsetHeight;
      var xperc = x / imgWidth * 100;
      var yperc = y / imgHeight * 100;

      //lets user scroll past right edge of image
      if (x > 0.01 * imgWidth) xperc += 0.15 * xperc;
      //lets user scroll past bottom edge of image
      if (y >= 0.01 * imgHeight) yperc += 0.15 * yperc;
      var bg = this.lensBackgroundSize(original);
      imgStyle.backgroundSize = bg.width + 'px ' + bg.height + 'px';
      imgStyle.backgroundPositionX = xperc + '%';
      imgStyle.backgroundPositionY = yperc + '%';
      // position of the magnifying glass
      var posY = 0;
      var posX = 0;
      //// when the magnified image tries to go beyond the viewport (x axis)
      if (event.pageY + 300 > event.view.innerHeight) {
        posY = event.view.innerHeight - 600;
      } else if (event.pageY - 300 < 0) posY = 0;else posY = event.pageY - 300;

      //// when the magnified image tries to go beyond the viewport (y axis)
      if (event.pageX + 300 > event.view.innerWidth) {
        posX = event.view.innerWidth - 600;
      } else if (event.pageX - 300 < 0) posX = 0;else posX = event.pageX - 300;
      style.left = posX + 'px';
      style.top = posY + 'px';
    },
    handleImageClick: function handleImageClick(event) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (_this4.showMagnifier) {
                _context4.n = 2;
                break;
              }
              _this4.showMagnifier = true;
              _this4.showZoom = true;
              // await 1 second before showing magnifier, will not work without this as the image is not mounted otherwise
              _context4.n = 1;
              return new Promise(function (resolve) {
                return setTimeout(resolve, 10);
              });
            case 1:
              _this4.handleImageAndMousePosition(event, event.layerX, event.layerY);
              _context4.n = 3;
              break;
            case 2:
              _this4.showMagnifier = false;
              _this4.showZoom = false;
            case 3:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    onWheel: function onWheel(event) {
      // delta Y is scroll up and down; showZoom is true when mouse is over image.
      // scale is a fraction of native resolution: MIN shows more area (still sharp),
      // 1.0 is native 1:1, MAX allows a little interpolation for reading fine detail.
      if (!this.showZoom) return;
      var MIN_ZOOM = 0.75;
      var MAX_ZOOM = 1.5;
      var STEP = 0.25;
      if (event.deltaY > 0) {
        this.zoom.scale = Math.max(MIN_ZOOM, this.zoom.scale - STEP);
      } else if (event.deltaY < 0) {
        this.zoom.scale = Math.min(MAX_ZOOM, this.zoom.scale + STEP);
      }
      this.zoom.zoom = this.zoom.scale < MAX_ZOOM;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _BulmaCarousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BulmaCarousel */ "./src/components/BulmaCarousel/BulmaCarousel.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BulmaCarouselModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_1__["BaseModalEx"],
    BulmaCarousel: _BulmaCarousel__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    closable: {
      type: Boolean,
      default: true
    },
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    imageIds: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    startIndex: {
      type: Number,
      default: 0
    },
    imageWidth: {
      type: Number,
      default: 800
    },
    imageHeight: {
      type: Number,
      default: 600
    },
    image: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      minWidth: 30
    };
  },
  computed: {},
  watch: {
    active: function active(value) {
      this.isActive = value;
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    close: function close() {
      this.$emit('close');
    },
    previousImage: function previousImage() {
      this.$emit('previousImage');
    },
    nextImage: function nextImage() {
      this.$emit('nextImage');
    },
    setOrientation: function setOrientation(value) {
      this.minWidth = value === _enums__WEBPACK_IMPORTED_MODULE_3__["ImageOrientationTypes"].Portrait ? 30 : 60;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "carousel carousel-animated carousel-animate-slide",
    class: {
      "is-loading-image-popup": _vm.isLoading
    }
  }, [_vm.isLoading && !_vm.imageBase64 ? _c("section", {
    staticClass: "section"
  }, [_vm._m(0)]) : _vm._e(), _c("div", {
    staticClass: "carousel-container"
  }, [_vm._m(1), _c("div", {
    staticClass: "carousel-item has-background",
    staticStyle: {
      overflow: "visible"
    }
  }, [_c("div", {
    attrs: {
      id: "img-zoomer-box"
    }
  }, [_c("img", {
    staticClass: "is-background",
    attrs: {
      id: "img-1",
      src: _vm.imageBase64,
      alt: "",
      width: "800",
      height: "600"
    },
    on: {
      mousemove: _vm.handleMouseOver,
      mouseleave: function mouseleave($event) {
        _vm.showZoom = false;
      },
      click: _vm.handleImageClick
    }
  }), _vm.showZoom ? _c("div", {
    attrs: {
      id: "img-2"
    }
  }, [_c("div", {
    attrs: {
      id: "img-2-bg"
    }
  })]) : _vm._e()]), _vm.imageBase64 ? _c("div", {
    staticClass: "title"
  }, [_vm._v(_vm._s(_vm.imageIndex + 1) + " of " + _vm._s(_vm.imageCount))]) : _vm._e()])]), _c("div", {
    staticClass: "carousel-navigation is-overlay"
  }, [_c("div", {
    staticClass: "carousel-nav-left"
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-chevron-left",
    class: {
      "mdi-inactive-color mdi-inactive": _vm.imageIndex === 0
    },
    attrs: {
      "aria-hidden": "true"
    },
    on: {
      click: function click($event) {
        return _vm.previousImage();
      }
    }
  })]), _c("div", {
    staticClass: "carousel-nav-right"
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-chevron-right",
    class: {
      "mdi-inactive-color mdi-inactive": _vm.imageIndex === _vm.imageCount - 1
    },
    attrs: {
      "aria-hidden": "true"
    },
    on: {
      click: function click($event) {
        return _vm.nextImage();
      }
    }
  })])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    staticStyle: {
      opacity: "0"
    },
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-spin mdi-loading mdi-36px"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "carousel-item has-background is-active"
  }, [_c("img", {
    staticClass: "is-background",
    attrs: {
      src: "",
      alt: "",
      width: "800",
      height: "600"
    }
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      id: "pdf-modal",
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": true,
      "min-width": _vm.minWidth
    },
    on: {
      "update:active": [function ($event) {
        _vm.isActive = $event;
      }, function ($event) {
        return _vm.close();
      }]
    }
  }, [_c("div", {
    staticClass: "box"
  }, [_c("article", {
    staticClass: "media"
  }, [_c("div", {
    staticClass: "media-content"
  }, [_c("div", {
    staticClass: "content"
  }, [_vm.title ? _c("h4", {
    staticClass: "title is-5"
  }, [_vm._v(_vm._s(_vm.title))]) : _vm._e(), _c("bulma-carousel", {
    attrs: {
      image: _vm.image,
      "image-width": _vm.imageWidth,
      "image-height": _vm.imageHeight,
      "image-ids": _vm.imageIds,
      "start-index": _vm.startIndex
    },
    on: {
      orientation: _vm.setOrientation
    }
  })], 1)])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n#img-zoomer-box {\n  height: auto;\n  position: relative;\n  margin: 10px auto;\n}\n#img-1 {\n  width: 100%;\n  height: auto;\n}\n#img-zoomer-box:hover,\n#img-zoomer-box:active {\n  display: block;\n  cursor: -webkit-zoom-in;\n  cursor: zoom-in;\n}\n#img-zoomer-box:hover #img-2,\n#img-zoomer-box:active #img-2 {\n  opacity: 1;\n}\n#img-2 {\n  width: 600px;\n  height: 600px;\n  -webkit-box-shadow: 0 5px 10px -2px rgba(0, 0, 0, 0.3);\n          box-shadow: 0 5px 10px -2px rgba(0, 0, 0, 0.3);\n  pointer-events: none;\n  position: fixed;\n  border: 4px solid whitesmoke;\n  z-index: 999;\n  border-radius: 100%;\n  opacity: 0;\n  display: block;\n  overflow: hidden !important;\n  -webkit-transition: opacity 0.2s;\n  transition: opacity 0.2s;\n}\n#img-2-bg {\n  width: 100%;\n  height: 100%;\n  overflow: hidden !important;\n  background-repeat: no-repeat;\n  background-position: 0 0;\n  border-radius: 100%;\n  /* transition: background-position 0.2s; */\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("a01e9ad4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarousel.vue":
/*!********************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarousel.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BulmaCarousel.vue?vue&type=template&id=70621e6b */ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b");
/* harmony import */ var _BulmaCarousel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BulmaCarousel.vue?vue&type=script&lang=js */ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css */ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _BulmaCarousel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/BulmaCarousel/BulmaCarousel.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js":
/*!********************************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarousel.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css":
/*!****************************************************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=style&index=0&id=70621e6b&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_style_index_0_id_70621e6b_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b":
/*!**************************************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarousel.vue?vue&type=template&id=70621e6b */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarousel.vue?vue&type=template&id=70621e6b");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarousel_vue_vue_type_template_id_70621e6b__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarouselModal.vue":
/*!*************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarouselModal.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BulmaCarouselModal.vue?vue&type=template&id=0438a29c */ "./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c");
/* harmony import */ var _BulmaCarouselModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BulmaCarouselModal.vue?vue&type=script&lang=js */ "./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BulmaCarouselModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/BulmaCarousel/BulmaCarouselModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarouselModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarouselModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarouselModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c":
/*!*******************************************************************************************!*\
  !*** ./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BulmaCarouselModal.vue?vue&type=template&id=0438a29c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/BulmaCarousel/BulmaCarouselModal.vue?vue&type=template&id=0438a29c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BulmaCarouselModal_vue_vue_type_template_id_0438a29c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/BulmaCarousel/ImageService.js":
/*!******************************************************!*\
  !*** ./src/components/BulmaCarousel/ImageService.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Buffer) {/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");






/* harmony default export */ __webpack_exports__["default"] = ({
  getImageThumbnail: function getImageThumbnail(id, size) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result, image;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/quotes/images/thumbnail/".concat(id, "?size=").concat(size);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get(url, {
              responseType: 'arraybuffer'
            });
          case 1:
            result = _context.v;
            image = Buffer.from(result.data, 'binary').toString('base64');
            return _context.a(2, "data:".concat(result.headers['content-type'].toLowerCase(), ";base64,").concat(image));
        }
      }, _callee);
    }))();
  },
  // Full-resolution (un-resized) original image. Used by the carousel viewer so
  // clicking a thumbnail shows the stored image, not the 800px downscaled copy.
  getImage: function getImage(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url, result, image;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/quotes/images/data/".concat(id);
            _context2.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get(url, {
              responseType: 'arraybuffer'
            });
          case 1:
            result = _context2.v;
            image = Buffer.from(result.data, 'binary').toString('base64');
            return _context2.a(2, "data:".concat(result.headers['content-type'].toLowerCase(), ";base64,").concat(image));
        }
      }, _callee2);
    }))();
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/buffer/index.js */ "./node_modules/buffer/index.js").Buffer))

/***/ })

}]);
//# sourceMappingURL=quote-imagesbreakout-chunk~shared.js.map