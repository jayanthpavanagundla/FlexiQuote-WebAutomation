(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["jobinvoicedlist-chunk"],{

/***/ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _regeneratorValues; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/core-js/modules/es.error.cause.js");
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");








function _regeneratorValues(e) {
  if (null != e) {
    var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"],
      r = 0;
    if (t) return t.call(e);
    if ("function" == typeof e.next) return e;
    if (!isNaN(e.length)) return {
      next: function next() {
        return e && r >= e.length && (e = void 0), {
          value: e && e[r++],
          done: !e
        };
      }
    };
  }
  throw new TypeError(Object(_typeof_js__WEBPACK_IMPORTED_MODULE_7__["default"])(e) + " is not iterable");
}


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _views_jobsCompletedNotInvoiced_JcniService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/views/jobsCompletedNotInvoiced/JcniService */ "./src/views/jobsCompletedNotInvoiced/JcniService.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'JobInvoicedMenuBar',
  props: {
    value: null,
    totalJobs: {
      type: Number,
      value: 0
    },
    totalAmount: {
      type: Number,
      value: 0
    },
    fiscalYearName: {
      type: String,
      value: null
    },
    currentMonth: {
      type: Number,
      value: 0
    },
    currentYear: {
      type: Number,
      value: 0
    },
    isLoading: {
      type: Boolean,
      value: false
    }
  },
  data: function data() {
    return {
      selectedType: 0,
      jcniRecords: []
    };
  },
  computed: {
    avgDailyInvAmount: function avgDailyInvAmount() {
      var avgAmount = 0;
      if (this.monthlyWorkingDays !== 0) {
        avgAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(this.totalAmount / this.monthlyWorkingDays, 2);
      }
      return avgAmount;
    },
    totalNotInvoiced: function totalNotInvoiced() {
      var total = this.jcniRecords.reduce(function (acc, item) {
        return acc + item.totalNotInvoiced;
      }, 0);
      return this.$filters.formatCurrency(total, this.$userInfo.locale);
    },
    dailyTarget: function dailyTarget() {
      var target = 0;
      if (this.monthlyWorkingDays !== 0) {
        target = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(this.monthlyTarget / this.monthlyWorkingDays, 2);
      }
      return target;
    },
    dailyTargetYTD: function dailyTargetYTD() {
      var target = 0;
      if (this.yearlyWorkingDays !== 0) {
        target = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(this.yearlyTarget / this.yearlyWorkingDays, 2);
      }
      return target;
    },
    monthlyTarget: function monthlyTarget() {
      var _this = this;
      var target = 0;
      var setting = this.value.find(function (i) {
        return i.month === _this.currentMonth && i.year === _this.currentYear;
      });
      if (setting !== undefined) {
        target = setting.monthlyTarget;
      }
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(target, 0);
    },
    monthlyWorkingDays: function monthlyWorkingDays() {
      var _this2 = this;
      var days = 0;
      var setting = this.value.find(function (i) {
        return i.month === _this2.currentMonth && i.year === _this2.currentYear;
      });
      if (setting !== undefined) {
        days = setting.workingDays;
      }
      return days;
    },
    yearlyTarget: function yearlyTarget() {
      var _this3 = this;
      var sumMonthlyTarget = this.value.reduce(function (sum, setting) {
        if (setting.fiscalYearName === _this3.fiscalYearName) {
          sum += setting.monthlyTarget || 0;
        }
        return sum;
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(sumMonthlyTarget, 0);
    },
    yearlyWorkingDays: function yearlyWorkingDays() {
      var _this4 = this;
      var sumMonthlyWorkingDays = this.value.reduce(function (sum, setting) {
        if (setting.fiscalYearName === _this4.fiscalYearName) {
          sum += setting.workingDays || 0;
        }
        return sum;
      }, 0);
      return sumMonthlyWorkingDays;
    }
  },
  watch: {},
  created: function created() {
    var _this5 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var response;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _views_jobsCompletedNotInvoiced_JcniService__WEBPACK_IMPORTED_MODULE_9__["default"].getJobsCompletedNotInvoiced();
          case 1:
            response = _context.v;
            _this5.jcniRecords = response;
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    changeType: function changeType(type) {
      this.selectedType = type;
      this.$emit('selected-type', type);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _JobInvoicedMenuBar__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./JobInvoicedMenuBar */ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue");
/* harmony import */ var _JobInvoicedService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./JobInvoicedService */ "./src/views/jobinvoiced/JobInvoicedService.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./columns */ "./src/views/jobinvoiced/columns.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./storeMixin */ "./src/views/jobinvoiced/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @/components/utils/CalendarFunctions */ "./src/components/utils/CalendarFunctions.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");













































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'JobInvoicedView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_30__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_33__["default"],
    JobInvoicedMenuBar: _JobInvoicedMenuBar__WEBPACK_IMPORTED_MODULE_31__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_36__["default"]],
  data: function data() {
    return {
      jobInvoicedObj: {
        0: 'Job Invoiced',
        1: 'Job Invoiced Year to Date'
      },
      isLoading: false,
      entitySummaries: [],
      totalRows: 0,
      selectedQuoteId: null,
      selectedJobNo: null,
      sortColumn: _columns__WEBPACK_IMPORTED_MODULE_34__["DetailColumns"][0].name,
      sortOrder: _columns__WEBPACK_IMPORTED_MODULE_34__["DetailColumns"][0].defaultOrder,
      filter: {
        dateFrom: null,
        dateTo: null,
        fiscalStart: 1,
        fiscalDuration: 12,
        selectedType: 0,
        selectedRow: null,
        sortColumn: 'QuoteNoRef',
        sortOrder: 'asc'
      },
      toggle: true,
      selectedRow: null,
      currentMonth: 0,
      currentYear: 0,
      fiscalYearName: null,
      currentFiscalYearSettings: [],
      currentFiscalStartDate: new Date()
    };
  },
  computed: {
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    includeGst: function includeGst() {
      var _this$$company;
      return (_this$$company = this.$company) === null || _this$$company === void 0 || (_this$$company = _this$$company.info) === null || _this$$company === void 0 ? void 0 : _this$$company.isGst;
    },
    columns: function columns() {
      var cols = _columns__WEBPACK_IMPORTED_MODULE_34__["DetailColumns"];
      if (this.filter.selectedType === 0) {
        if (this.includeGst) {
          cols[8].title = 'Total (Inc GST)';
        }
      } else {
        cols = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(_columns__WEBPACK_IMPORTED_MODULE_34__["MonthlyColumns"]);
        if (this.includeGst) {
          cols[5].title = 'Total (Inc GST)';
        }
      }
      return cols;
    },
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_38__["ItemCategoryTypes"];
    },
    sortedData: function sortedData() {
      var _this = this;
      var data = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(this.entitySummaries);
      return data.sort(function (a, b) {
        var modifier = _this.sortOrder === 'desc' ? -1 : 1;
        if (a[_this.sortColumn] < b[_this.sortColumn]) return -1 * modifier;
        if (a[_this.sortColumn] > b[_this.sortColumn]) return 1 * modifier;
        return 0;
      });
    },
    totalJobs: function totalJobs() {
      var quoteNos = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(new Set(this.entitySummaries.map(function (job) {
        return job.quoteNo;
      })));
      return quoteNos.length;
    },
    totalAmount: function totalAmount() {
      var total = this.entitySummaries.reduce(function (acc, item) {
        return acc + item.totalIncGst;
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_35__["roundAwayFromZero"])(total, 2);
    },
    showPrint: function showPrint() {
      var showPrint = false;
      if (this.$route && this.$route.meta) {
        if (this.$route.meta.access) {
          showPrint = this.$route.meta.access.isPrint;
        }
      }
      return showPrint;
    }
  },
  watch: {},
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var today, _getThisMonthDates, _getThisMonthDates2, dateFrom;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            today = new Date();
            _this2.currentMonth = today.getMonth() + 1;
            _this2.currentYear = today.getFullYear();
            _getThisMonthDates = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__["getThisMonthDates"])(), _getThisMonthDates2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_getThisMonthDates, 1), dateFrom = _getThisMonthDates2[0];
            _this2.filter.dateFrom = dateFrom.toISOString();
            _this2.filter.dateTo = new Date(new Date().setHours(0, 0, 0, 0)).toISOString(); // dateTo.toISOString()

            _this2.getEntitySummaries();
            _context.n = 1;
            return _this2.getCompanyFiscalYearSetting();
          case 1:
            _this2.filter.fiscalDuration = _this2.$company.setting.fiscalDuration;
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {
    filterList: function filterList() {
      this.persistFilter();
      this.getEntitySummaries();
    },
    changeType: function changeType(type) {
      this.filter.selectedType = type;
      this.selectedRow = null;
      this.filter.selectedRow = null;
      if (type === 0) {
        var _getThisMonthDates3 = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__["getThisMonthDates"])(),
          _getThisMonthDates4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_getThisMonthDates3, 1),
          firstDayOfMonth = _getThisMonthDates4[0];
        this.filter.dateFrom = firstDayOfMonth.toISOString();
        this.filter.sortColumn = 'QuoteNoRef';
      } else {
        this.filter.dateFrom = this.currentFiscalStartDate.toISOString();
        this.filter.sortColumn = 'FiscalMonthOrder';
      }
      this.getEntitySummaries();
    },
    getEntitySummaries: function getEntitySummaries() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              // console.log('job invoiced filter = ' + JSON.stringify(this.filter))
              _this3.isLoading = true;
              if (!(_this3.filter.selectedType === 0)) {
                _context2.n = 2;
                break;
              }
              _context2.n = 1;
              return _JobInvoicedService__WEBPACK_IMPORTED_MODULE_32__["default"].getEntitySummaries(_this3.filter);
            case 1:
              _this3.entitySummaries = _context2.v;
              _context2.n = 4;
              break;
            case 2:
              _context2.n = 3;
              return _JobInvoicedService__WEBPACK_IMPORTED_MODULE_32__["default"].getEntitySummariesYTD(_this3.filter, _this3.currentFiscalYearSettings);
            case 3:
              _this3.entitySummaries = _context2.v;
            case 4:
              _this3.totalRows = _this3.entitySummaries.length > 0 ? _this3.entitySummaries[0].totalRows : 0;
              _this3.isLoading = false;
            case 5:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getCompanyFiscalYearSetting: function getCompanyFiscalYearSetting() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var currentMonth, currentYear, allFiscalYears, currentFiscalYear, startDate, startYear, startMonth, firstFyYear, firstFyMonth, firstFyDate, yearDiff, monthDiff, totalMonths, fiscalDiff, _getFiscalYearDates, _getFiscalYearDates2, fiscalYearStartDate;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              currentMonth = new Date().getMonth() + 1; // JavaScript months are zero-indexed
              currentYear = new Date().getFullYear(); // return this.$filters.formatCurrency(this.getSum(jobs), this.$userInfo.locale).split('.')
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_40__["CompanySettingService"].getAllFiscalYear();
            case 1:
              allFiscalYears = _context3.v;
              if (!(allFiscalYears.length !== 0)) {
                _context3.n = 5;
                break;
              }
              currentFiscalYear = allFiscalYears.filter(function (i) {
                return i.year === currentYear && i.month === currentMonth;
              });
              if (!(currentFiscalYear.length !== 0)) {
                _context3.n = 2;
                break;
              }
              startDate = allFiscalYears.find(function (r) {
                return r.fiscalYearName === currentFiscalYear[0].fiscalYearName;
              });
              startYear = startDate.year;
              startMonth = startDate.month - 1;
              _this4.fiscalYearName = startDate.fiscalYearName;
              _this4.currentFiscalStartDate = new Date(new Date(startYear, startMonth).setHours(0, 0, 0, 0));
              _this4.currentFiscalYearSettings = allFiscalYears.filter(function (i) {
                return i.fiscalYearName === _this4.fiscalYearName;
              });
              _context3.n = 4;
              break;
            case 2:
              firstFyYear = allFiscalYears[0].year;
              firstFyMonth = allFiscalYears[0].month - 1;
              firstFyDate = new Date(firstFyYear, firstFyMonth);
              yearDiff = currentYear - firstFyDate.getFullYear();
              monthDiff = currentMonth - firstFyDate.getMonth();
              totalMonths = yearDiff * 12 + monthDiff;
              fiscalDiff = Math.floor(totalMonths / _this4.$company.setting.fiscalDuration);
              _this4.currentFiscalStartDate = new Date(firstFyDate.setMonth(firstFyDate.getMonth() + fiscalDiff * _this4.$company.setting.fiscalDuration));
              _context3.n = 3;
              return Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__["getFiscalYearName"])(_this4.currentFiscalStartDate, _this4.$company.setting.fiscalDuration);
            case 3:
              _this4.fiscalYearName = _context3.v;
            case 4:
              _context3.n = 7;
              break;
            case 5:
              _getFiscalYearDates = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__["getFiscalYearDates"])(_this4.$company.setting.fiscalStart, _this4.$company.setting.fiscalDuration, true), _getFiscalYearDates2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_getFiscalYearDates, 1), fiscalYearStartDate = _getFiscalYearDates2[0];
              _context3.n = 6;
              return Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_39__["getFiscalYearName"])(fiscalYearStartDate, _this4.$company.setting.fiscalDuration);
            case 6:
              _this4.fiscalYearName = _context3.v;
              _this4.currentFiscalStartDate = fiscalYearStartDate;
            case 7:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getAvgDailyInvoiced: function getAvgDailyInvoiced(total, days) {
      var amount = 0;
      if (days && days !== 0) {
        amount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_35__["roundAwayFromZero"])(total / days, 2);
      }
      return amount;
    },
    getMonthlyTarget: function getMonthlyTarget(value) {
      var target = 0;
      if (value) {
        target = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_35__["roundAwayFromZero"])(value, 0);
      }
      return target;
    },
    quoteClick: function quoteClick(quoteId) {
      this.setQuoteReturnRoute(this.$route);
      this.editStoreQuote(quoteId);
    },
    sort: function sort(column, order) {
      this.sortColumn = column;
      this.sortOrder = order;
      this.filter.sortColumn = this.sortColumn;
      this.filter.sortOrder = this.sortOrder;
      this.persistFilter();
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
      this.filter.selectedRow = index;
      this.persistFilter();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
        this.selectedRow = this.filter.selectedRow;
        this.sortColumn = this.filter.sortColumn;
        this.sortOrder = this.filter.sortOrder;
      }
    },
    handlePrint: function handlePrint() {
      var title = this.filter.selectedType === 0 ? 'Job Invoiced This Month' : 'Job Invoiced Year to Date';
      var params = {
        CompanyId: this.$userInfo.companyId,
        DateFrom: this.filter.dateFrom,
        DateTo: this.filter.dateTo,
        SortColumn: this.filter.sortColumn,
        SortOrder: this.filter.sortOrder,
        FiscalDuration: this.filter.selectedType === 0 ? 0 : this.filter.fiscalDuration
      };
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_41__["Emailer"]();
      emailer.subject = title;
      emailer.reportName = title;
      this.addEmailer(emailer);
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_42__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_43__["default"].PrintPreview.name,
        params: {
          reportName: 'rptJobInvoiced'
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-child box has-sticky-tile",
    staticStyle: {
      "margin-bottom": "1rem !important"
    }
  }, [_c("div", {
    staticClass: "is-flex is-align-items-center",
    staticStyle: {
      height: "60px"
    }
  }, [_c("div", {
    staticClass: "toggle-buttons-vertical ml-2 is-flex is-flex-direction-column mt-2 mb-1"
  }, [_c("span", {
    staticClass: "button m-0",
    class: {
      "is-primary is-selected": _vm.selectedType === 0
    },
    staticStyle: {
      "border-radius": "5px 5px 0px 0px"
    },
    on: {
      click: function click($event) {
        return _vm.changeType(0);
      }
    }
  }, [_c("span", [_vm._v("Job Invoiced This Month")])]), _c("span", {
    staticClass: "button m-0",
    class: {
      "is-primary is-selected": _vm.selectedType === 1
    },
    staticStyle: {
      "border-radius": "0px 0px 5px 5px"
    },
    on: {
      click: function click($event) {
        return _vm.changeType(1);
      }
    }
  }, [_c("span", [_vm._v("Job Invoiced Year to Date")])])]), _vm.selectedType === 0 ? _c("div", {
    staticClass: "is-flex is-flex-direction-row is-justify-content-space-evenly",
    staticStyle: {
      height: "60px",
      width: "100%"
    }
  }, [_c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Total Jobs")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.totalJobs))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Working Days")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.monthlyWorkingDays))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Daily Target")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.dailyTarget, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Amount Waiting in JCNI")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.totalNotInvoiced))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Monthly Target")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.monthlyTarget, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Invoiced Amount (MTD)")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.totalAmount, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])])]) : _c("div", {
    staticClass: "is-flex is-flex-direction-row is-justify-content-space-evenly",
    staticStyle: {
      height: "60px",
      width: "100%"
    }
  }, [_c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Daily Target")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.dailyTargetYTD, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Yearly Target")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.yearlyTarget, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "mt-1 header-text-divider"
  }, [_vm._v("Invoiced YTD (FY " + _vm._s(_vm.fiscalYearName) + ")")]), !_vm.isLoading ? _c("span", {
    staticClass: "is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(this.$filters.formatCurrency(_vm.totalAmount, this.$userInfo.locale)))]) : _c("div", {
    staticClass: "spins"
  }, [_c("span", {
    staticClass: "mdi mdi-loading"
  })])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-delete": false,
      "show-new": false,
      "show-save": false,
      "show-cancel": false,
      title: _vm.jobInvoicedObj[_vm.filter.selectedType],
      "show-print": _vm.showPrint
    },
    on: {
      appDetailHeaderButtonClicked: _vm.handlePrint
    }
  }), _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-vertical is-parent"
  }, [_c("job-invoiced-menu-bar", {
    attrs: {
      "is-loading": _vm.isLoading,
      "total-jobs": _vm.totalJobs,
      "total-amount": _vm.totalAmount,
      "include-gst": _vm.includeGst,
      "current-month": _vm.currentMonth,
      "current-year": _vm.currentYear,
      "fiscal-year-name": _vm.fiscalYearName
    },
    on: {
      "selected-type": _vm.changeType,
      "filter-list": _vm.filterList
    },
    model: {
      value: _vm.currentFiscalYearSettings,
      callback: function callback($$v) {
        _vm.currentFiscalYearSettings = $$v;
      },
      expression: "currentFiscalYearSettings"
    }
  }), _vm.filter.selectedType === 0 ? _c("div", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "is-striped is-narrow is-fullwidth is-hoverable",
    attrs: {
      columns: _vm.columns,
      data: _vm.sortedData,
      "total-rows": _vm.entitySummaries.length,
      "page-size": _vm.entitySummaries.length,
      "is-loading": _vm.isLoading,
      "sort-column": _vm.sortColumn,
      "sort-order": _vm.sortOrder,
      "show-pagination": false,
      "has-sticky-header": true,
      "sticky-header-top": "10.25rem"
    },
    on: {
      sort: _vm.sort
    }
  }, [_vm._l(_vm.sortedData, function (item, index) {
    return _c("tr", {
      key: index,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      staticClass: "col-5"
    }, [_c("a", {
      on: {
        click: function click($event) {
          return _vm.quoteClick(item.quoteId);
        }
      }
    }, [_vm._v(_vm._s(item.quoteNoRef))])]), _c("td", {
      staticClass: "col-8"
    }, [_vm._v(_vm._s(item.jobStageDesc))]), _c("td", {
      staticClass: "col-10"
    }, [_vm._v(_vm._s(item.owner))]), _c("td", {
      staticClass: "col-5"
    }, [_vm._v(_vm._s(item.rego))]), _c("td", {
      staticClass: "col-12"
    }, [_vm._v(_vm._s(item.makeModel))]), _c("td", {
      staticClass: "col-10"
    }, [_vm._v(_vm._s(item.debtorName))]), _c("td", {
      staticClass: "col-5"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(item.invoiceDate, _vm.$userInfo.locale)) + " ")]), _c("td", {
      staticClass: "col-5"
    }, [_vm._v(_vm._s(item.invoiceNoRef))]), _c("td", {
      staticClass: "has-text-right col-5"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.totalIncGst, _vm.$userInfo.locale)))])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1) : _vm._e(), _vm.filter.selectedType === 1 ? _c("div", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "is-striped is-narrow is-fullwidth is-hoverable",
    attrs: {
      columns: _vm.columns,
      data: _vm.sortedData,
      "total-rows": _vm.entitySummaries.length,
      "is-loading": _vm.isLoading,
      "sort-column": _vm.sortColumn,
      "sort-order": _vm.sortOrder,
      "show-pagination": false,
      "has-sticky-header": true,
      "sticky-header-top": "10.25rem"
    },
    on: {
      sort: _vm.sort
    }
  }, [_vm._l(_vm.sortedData, function (item, index) {
    return _c("tr", {
      key: "item" + index,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      staticClass: "col-5 has-text-weight-bold"
    }, [_vm._v(_vm._s(item.monthName) + " " + _vm._s(item.year))]), _c("td", {
      staticClass: "col-5 has-text-centered"
    }, [_vm._v(_vm._s(item.workingDays))]), _c("td", {
      staticClass: "col-5 has-text-centered"
    }, [_c("div", [_vm._v(_vm._s(item.totalInvoices))])]), _c("td", {
      staticClass: "has-text-right col-5"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.getAvgDailyInvoiced(item.totalIncGst, item.workingDays), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right col-5"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.getMonthlyTarget(item.monthlyTarget), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right col-5"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(item.totalIncGst, _vm.$userInfo.locale)))])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1) : _vm._e()], 1)])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".spins[data-v-b4343516] {\n  -webkit-animation: spin-b4343516 1s infinite linear;\n          animation: spin-b4343516 1s infinite linear;\n}\n@-webkit-keyframes spin-b4343516 {\nfrom {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n}\nto {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n}\n}\n@keyframes spin-b4343516 {\nfrom {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n}\nto {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n}\n}\n.tile.is-child.has-sticky-tile[data-v-b4343516] {\n  position: sticky;\n  top: 3.25rem;\n  z-index: 31;\n}\n.header-text-divider[data-v-b4343516] {\n  border-bottom: 1px solid lightgray;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".col-5[data-v-3b734cb4] {\n  width: 5%;\n}\n.col-8[data-v-3b734cb4] {\n  width: 8%;\n}\n.col-10[data-v-3b734cb4] {\n  width: 10%;\n}\n.col-12[data-v-3b734cb4] {\n  width: 12%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("c2ea71e4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("11042d1e", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/proto/jobinvoiced/JobInvoicedFilter.proto":
/*!**************************************************************!*\
  !*** ./src/assets/proto/jobinvoiced/JobInvoicedFilter.proto ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*undefined*/


var $protobuf = __webpack_require__(/*! protobufjs/minimal */ "./node_modules/protobufjs/minimal.js");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.JobInvoicedFilter = (function() {

    /**
     * Namespace JobInvoicedFilter.
     * @exports JobInvoicedFilter
     * @namespace
     */
    var JobInvoicedFilter = {};

    JobInvoicedFilter.JobInvoicedFilterModel = (function() {

        /**
         * Properties of a JobInvoicedFilterModel.
         * @memberof JobInvoicedFilter
         * @interface IJobInvoicedFilterModel
         * @property {string|null} [dateFrom] JobInvoicedFilterModel dateFrom
         * @property {string|null} [dateTo] JobInvoicedFilterModel dateTo
         * @property {number|null} [selectedType] JobInvoicedFilterModel selectedType
         * @property {number|null} [fiscalDuration] JobInvoicedFilterModel fiscalDuration
         * @property {string|null} [sortColumn] JobInvoicedFilterModel sortColumn
         * @property {string|null} [sortOrder] JobInvoicedFilterModel sortOrder
         */

        /**
         * Constructs a new JobInvoicedFilterModel.
         * @memberof JobInvoicedFilter
         * @classdesc Represents a JobInvoicedFilterModel.
         * @implements IJobInvoicedFilterModel
         * @constructor
         * @param {JobInvoicedFilter.IJobInvoicedFilterModel=} [p] Properties to set
         */
        function JobInvoicedFilterModel(p) {
            if (p)
                for (var ks = Object.keys(p), i = 0; i < ks.length; ++i)
                    if (p[ks[i]] != null)
                        this[ks[i]] = p[ks[i]];
        }

        /**
         * JobInvoicedFilterModel dateFrom.
         * @member {string|null|undefined} dateFrom
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.dateFrom = null;

        /**
         * JobInvoicedFilterModel dateTo.
         * @member {string|null|undefined} dateTo
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.dateTo = null;

        /**
         * JobInvoicedFilterModel selectedType.
         * @member {number|null|undefined} selectedType
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.selectedType = null;

        /**
         * JobInvoicedFilterModel fiscalDuration.
         * @member {number|null|undefined} fiscalDuration
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.fiscalDuration = null;

        /**
         * JobInvoicedFilterModel sortColumn.
         * @member {string|null|undefined} sortColumn
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.sortColumn = null;

        /**
         * JobInvoicedFilterModel sortOrder.
         * @member {string|null|undefined} sortOrder
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        JobInvoicedFilterModel.prototype.sortOrder = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * JobInvoicedFilterModel _dateFrom.
         * @member {"dateFrom"|undefined} _dateFrom
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_dateFrom", {
            get: $util.oneOfGetter($oneOfFields = ["dateFrom"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * JobInvoicedFilterModel _dateTo.
         * @member {"dateTo"|undefined} _dateTo
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_dateTo", {
            get: $util.oneOfGetter($oneOfFields = ["dateTo"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * JobInvoicedFilterModel _selectedType.
         * @member {"selectedType"|undefined} _selectedType
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_selectedType", {
            get: $util.oneOfGetter($oneOfFields = ["selectedType"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * JobInvoicedFilterModel _fiscalDuration.
         * @member {"fiscalDuration"|undefined} _fiscalDuration
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_fiscalDuration", {
            get: $util.oneOfGetter($oneOfFields = ["fiscalDuration"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * JobInvoicedFilterModel _sortColumn.
         * @member {"sortColumn"|undefined} _sortColumn
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_sortColumn", {
            get: $util.oneOfGetter($oneOfFields = ["sortColumn"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * JobInvoicedFilterModel _sortOrder.
         * @member {"sortOrder"|undefined} _sortOrder
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @instance
         */
        Object.defineProperty(JobInvoicedFilterModel.prototype, "_sortOrder", {
            get: $util.oneOfGetter($oneOfFields = ["sortOrder"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Encodes the specified JobInvoicedFilterModel message. Does not implicitly {@link JobInvoicedFilter.JobInvoicedFilterModel.verify|verify} messages.
         * @function encode
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @static
         * @param {JobInvoicedFilter.IJobInvoicedFilterModel} m JobInvoicedFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [w] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JobInvoicedFilterModel.encode = function encode(m, w) {
            if (!w)
                w = $Writer.create();
            if (m.dateFrom != null && Object.hasOwnProperty.call(m, "dateFrom"))
                w.uint32(10).string(m.dateFrom);
            if (m.dateTo != null && Object.hasOwnProperty.call(m, "dateTo"))
                w.uint32(18).string(m.dateTo);
            if (m.selectedType != null && Object.hasOwnProperty.call(m, "selectedType"))
                w.uint32(24).int32(m.selectedType);
            if (m.fiscalDuration != null && Object.hasOwnProperty.call(m, "fiscalDuration"))
                w.uint32(32).int32(m.fiscalDuration);
            if (m.sortColumn != null && Object.hasOwnProperty.call(m, "sortColumn"))
                w.uint32(42).string(m.sortColumn);
            if (m.sortOrder != null && Object.hasOwnProperty.call(m, "sortOrder"))
                w.uint32(50).string(m.sortOrder);
            return w;
        };

        /**
         * Encodes the specified JobInvoicedFilterModel message, length delimited. Does not implicitly {@link JobInvoicedFilter.JobInvoicedFilterModel.verify|verify} messages.
         * @function encodeDelimited
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @static
         * @param {JobInvoicedFilter.IJobInvoicedFilterModel} message JobInvoicedFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        JobInvoicedFilterModel.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a JobInvoicedFilterModel message from the specified reader or buffer.
         * @function decode
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} r Reader or buffer to decode from
         * @param {number} [l] Message length if known beforehand
         * @returns {JobInvoicedFilter.JobInvoicedFilterModel} JobInvoicedFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JobInvoicedFilterModel.decode = function decode(r, l) {
            if (!(r instanceof $Reader))
                r = $Reader.create(r);
            var c = l === undefined ? r.len : r.pos + l, m = new $root.JobInvoicedFilter.JobInvoicedFilterModel();
            while (r.pos < c) {
                var t = r.uint32();
                switch (t >>> 3) {
                case 1:
                    m.dateFrom = r.string();
                    break;
                case 2:
                    m.dateTo = r.string();
                    break;
                case 3:
                    m.selectedType = r.int32();
                    break;
                case 4:
                    m.fiscalDuration = r.int32();
                    break;
                case 5:
                    m.sortColumn = r.string();
                    break;
                case 6:
                    m.sortOrder = r.string();
                    break;
                default:
                    r.skipType(t & 7);
                    break;
                }
            }
            return m;
        };

        /**
         * Decodes a JobInvoicedFilterModel message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof JobInvoicedFilter.JobInvoicedFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {JobInvoicedFilter.JobInvoicedFilterModel} JobInvoicedFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        JobInvoicedFilterModel.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        return JobInvoicedFilterModel;
    })();

    return JobInvoicedFilter;
})();

module.exports = $root;


/***/ }),

/***/ "./src/components/utils/CalendarFunctions.js":
/*!***************************************************!*\
  !*** ./src/components/utils/CalendarFunctions.js ***!
  \***************************************************/
/*! exports provided: getFiscalYearName, addMonthsToDate, getThisMonthDates, getMonthName, getMonthAbbr, getFiscalYearDates, getFiscalYearDates_UpToToday */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearName", function() { return getFiscalYearName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addMonthsToDate", function() { return addMonthsToDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getThisMonthDates", function() { return getThisMonthDates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMonthName", function() { return getMonthName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMonthAbbr", function() { return getMonthAbbr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearDates", function() { return getFiscalYearDates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearDates_UpToToday", function() { return getFiscalYearDates_UpToToday; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_4__);





function getFiscalYearName(fiscalStartDate, fiscalDuration) {
  // Extract month and year from currentDate
  var currentMonth = fiscalStartDate.getMonth(); // JavaScript months are zero-indexed
  var currentYear = fiscalStartDate.getFullYear();
  fiscalStartDate = new Date(currentYear, currentMonth);
  var dateTo = addMonthsToDate(fiscalStartDate, fiscalDuration - 1);
  var fiscalStartYear, fiscalEndYear;
  fiscalStartYear = fiscalStartDate.getFullYear();
  fiscalEndYear = dateTo.getFullYear();

  // Format fiscal year as needed
  var fiscalYear;
  if (fiscalStartYear === fiscalEndYear) {
    fiscalYear = fiscalStartYear.toString(); // Output single year
  } else {
    fiscalYear = "".concat(fiscalStartYear, "-").concat(fiscalEndYear.toString().slice(2));
  }
  return fiscalYear;
}
function addMonthsToDate(date, monthsToAdd) {
  // Clone the original date to avoid modifying it directly
  var newDate = new Date(date);

  // Add the specified number of months
  newDate.setMonth(newDate.getMonth() + monthsToAdd);
  return newDate;
}
function getThisMonthDates() {
  var today = new Date();
  var firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  firstDayOfMonth = new Date(firstDayOfMonth.setHours(0, 0, 0, 0));
  lastDayOfMonth = new Date(lastDayOfMonth.setHours(0, 0, 0, 0));
  return [firstDayOfMonth, lastDayOfMonth];
}
function getMonthName(monthNumber) {
  return luxon__WEBPACK_IMPORTED_MODULE_4__["DateTime"].local().set({
    month: monthNumber
  }).monthLong;
}
function getMonthAbbr(monthNumber) {
  return luxon__WEBPACK_IMPORTED_MODULE_4__["DateTime"].local().set({
    month: monthNumber
  }).monthShort;
}

// get Fiscal Year Dates, passing isLastDayOfFY to indicate get up to today's date or last day of FY
function getFiscalYearDates(fiscalStart, fiscalDuration) {
  var isLastDayOfFY = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  var fiscalStartMonth = fiscalStart - 1;
  var fiscalYearStartDate = new Date(new Date().getFullYear(), fiscalStartMonth, 1);
  var today = new Date(); // Initialize current date
  var dateTo = today;
  var todayYear = today.getFullYear();
  var yearStartYear = fiscalYearStartDate.getFullYear();
  if (today < fiscalYearStartDate || todayYear !== yearStartYear) fiscalYearStartDate.setFullYear(fiscalYearStartDate.getFullYear() - 1);

  // add duration to start date to get date to
  if (isLastDayOfFY) {
    dateTo = new Date(fiscalYearStartDate);
    dateTo = new Date(dateTo.setMonth(dateTo.getMonth() + fiscalDuration));

    // Set the date to the last day
    dateTo.setDate(0);
  }
  fiscalYearStartDate = new Date(fiscalYearStartDate.setHours(0, 0, 0, 0));
  dateTo = new Date(dateTo.setHours(0, 0, 0, 0));
  return [fiscalYearStartDate, dateTo];
}

// get fiscal year dates up to today's date
function getFiscalYearDates_UpToToday(fiscalStart) {
  var fiscalStartMonth = fiscalStart - 1;
  var fiscalYearStartDate = new Date(new Date().getFullYear(), fiscalStartMonth, 1);
  var today = new Date(); // Initialize current date

  // Check if today is before the fiscal year start date
  if (today < fiscalYearStartDate) {
    fiscalYearStartDate.setFullYear(today.getFullYear() - 1); // If so, adjust fiscal year start date to previous year
  }

  // Set time part of dates to 00:00:00
  fiscalYearStartDate = new Date(fiscalYearStartDate.setHours(0, 0, 0, 0));
  today = new Date(today.setHours(0, 0, 0, 0));
  return [fiscalYearStartDate, today];
}

// function getLastDayOfFiscalYear(fiscalStartMonth, fiscalDuration) {
//   const currentDate = new Date() // Assuming this is the current date

//   // Determine the fiscal year start date
//   let fiscalYearStartDate
//   if (fiscalStartMonth === 1) {
//     fiscalYearStartDate = new Date(currentDate.getFullYear(), 0, 1)
//   } else {
//     fiscalYearStartDate = new Date(currentDate.getFullYear(), fiscalStartMonth - 1, 1)
//   }

//   // Add the fiscal duration to find the fiscal year end date
//   let fiscalYearEndDate = new Date(fiscalYearStartDate.getFullYear(), fiscalYearStartDate.getMonth() + fiscalDuration, 0)
//   return fiscalYearEndDate
// }

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue":
/*!******************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedMenuBar.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true */ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true");
/* harmony import */ var _JobInvoicedMenuBar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JobInvoicedMenuBar.vue?vue&type=script&lang=js */ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true */ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _JobInvoicedMenuBar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "b4343516",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/jobinvoiced/JobInvoicedMenuBar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js":
/*!******************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedMenuBar.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=style&index=0&id=b4343516&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_style_index_0_id_b4343516_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true":
/*!************************************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedMenuBar.vue?vue&type=template&id=b4343516&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedMenuBar_vue_vue_type_template_id_b4343516_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedService.js":
/*!*****************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedService.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/utils/CalendarFunctions */ "./src/components/utils/CalendarFunctions.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");














/* harmony default export */ __webpack_exports__["default"] = ({
  getEntitySummaries: function getEntitySummaries(filter) {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      var serialised, url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            serialised = _this.serialiseJobInvoicedFilter(filter);
            url = "jobinvoiced/list/".concat(serialised);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_10__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  getEntitySummariesYTD: function getEntitySummariesYTD(filter, monthlySettingSummaries) {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
      var serialised, url, result, data, _loop, i;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            serialised = _this2.serialiseJobInvoicedFilter(filter);
            url = "jobinvoiced/list/ytd/".concat(serialised);
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_10__["default"].get(url);
          case 1:
            result = _context3.v;
            // Process YTD data and merge with monthly settings
            data = [];
            _loop = /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _loop(i) {
              var object, monthYear, setting, jobInvoicedYTDModel;
              return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
                while (1) switch (_context2.n) {
                  case 0:
                    object = result.data.find(function (j) {
                      return j.fiscalMonthOrder === i;
                    });
                    monthYear = _this2.getMonthYear(filter.dateFrom, i);
                    setting = monthlySettingSummaries.find(function (k) {
                      return k.month === monthYear.month && k.year === monthYear.year;
                    }) || {};
                    jobInvoicedYTDModel = object ? new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__["JobInvoicedYTDModel"](object) : new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__["JobInvoicedYTDModel"]({
                      monthName: Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_12__["getMonthName"])(monthYear.month),
                      fiscalMonthOrder: i,
                      month: monthYear.month,
                      year: monthYear.year
                    });
                    jobInvoicedYTDModel.monthlyTarget = setting.monthlyTarget || 0;
                    jobInvoicedYTDModel.workingDays = setting.workingDays || 0;
                    data.push(jobInvoicedYTDModel);
                  case 1:
                    return _context2.a(2);
                }
              }, _loop);
            });
            i = 1;
          case 2:
            if (!(i <= filter.fiscalDuration)) {
              _context3.n = 4;
              break;
            }
            return _context3.d(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_loop(i)), 3);
          case 3:
            i++;
            _context3.n = 2;
            break;
          case 4:
            return _context3.a(2, data);
        }
      }, _callee2);
    }))();
  },
  getMonthYear: function getMonthYear(dateString, monthsToAdd) {
    var date = new Date(dateString);
    var month = date.getMonth() + monthsToAdd;
    var year = date.getFullYear() + Math.floor((month - 1) / 12);
    return {
      month: month % 12 || 12,
      year: year
    };
  },
  serialiseJobInvoicedFilter: function serialiseJobInvoicedFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/jobinvoiced/JobInvoicedFilter.proto */ "./src/assets/proto/jobinvoiced/JobInvoicedFilter.proto");
    var filterMessage = entityProto.JobInvoicedFilter.JobInvoicedFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_11___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  }
});

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedView.vue":
/*!***************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedView.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true */ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true");
/* harmony import */ var _JobInvoicedView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JobInvoicedView.vue?vue&type=script&lang=js */ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true */ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _JobInvoicedView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "3b734cb4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/jobinvoiced/JobInvoicedView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=style&index=0&id=3b734cb4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_style_index_0_id_3b734cb4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true":
/*!*********************************************************************************************!*\
  !*** ./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/jobinvoiced/JobInvoicedView.vue?vue&type=template&id=3b734cb4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_JobInvoicedView_vue_vue_type_template_id_3b734cb4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/jobinvoiced/columns.js":
/*!******************************************!*\
  !*** ./src/views/jobinvoiced/columns.js ***!
  \******************************************/
/*! exports provided: DetailColumns, MonthlyColumns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailColumns", function() { return DetailColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MonthlyColumns", function() { return MonthlyColumns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var DetailColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No.', 'quoteNoRef', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Job Stage', 'jobStage', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Owner', 'owner', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'rego', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Vehicle', 'MakeModel', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Debtor Name', 'debtorName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Invoice Date', 'invoiceDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Invoice No.', 'invoiceNoRef', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total', 'totalIncGst', true, 'asc', 'right')];
var MonthlyColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Month', 'fiscalMonthOrder', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Working Days', 'workingDays', true, 'desc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total Invoices', 'totalInvoices', true, 'desc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Avg. Daily Invoiced', 'avgDailyInvoie', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Monthly Target', 'otherTotal', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total', 'totalIncGst', true, 'asc', 'right')];


/***/ }),

/***/ "./src/views/jobinvoiced/storeMixin.js":
/*!*********************************************!*\
  !*** ./src/views/jobinvoiced/storeMixin.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'JobInvoiced';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
    // readOnlyView: 'readOnlyView'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quotes', {
    setQuoteReturnRoute: 'setReturnRoute',
    editStoreQuote: 'editStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=jobinvoicedlist-chunk.js.map