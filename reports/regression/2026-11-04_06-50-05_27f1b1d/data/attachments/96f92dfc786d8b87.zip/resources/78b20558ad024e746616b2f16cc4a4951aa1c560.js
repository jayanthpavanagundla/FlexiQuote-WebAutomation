(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[24],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'NotificationBox',
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      notificationClass: 'noti-primary',
      textclass: 'has-text-primary',
      icon: 'mdi-check-circle-outline'
    };
  },
  created: function created() {
    this.getClass(this.type);
  },
  methods: {
    getClass: function getClass(type) {
      switch (type) {
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Success:
          this.notificationClass = 'noti-primary';
          this.icon = 'mdi-check-circle-outline';
          this.textclass = 'has-text-primary';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Warning:
          this.notificationClass = 'noti-warning';
          this.icon = 'mdi-bell-ring-outline';
          this.textclass = 'has-text-warning';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Error:
          this.notificationClass = 'noti-danger';
          this.icon = 'mdi-alert-circle-outline';
          this.textclass = 'has-text-danger';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Default:
          this.notificationClass = 'noti-default';
          this.icon = 'mdi-information-outline';
          this.textclass = 'has-text-current';
          break;
        default:
          break;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ErrorMessage */ "./src/views/auth/ErrorMessage.js");
/* harmony import */ var _loginNavigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./loginNavigation */ "./src/views/auth/loginNavigation.js");
/* harmony import */ var _components_mixins_global_GlobalSpinnerMixin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/mixins/global/GlobalSpinnerMixin */ "./src/components/mixins/global/GlobalSpinnerMixin.js");
/* harmony import */ var _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/Notification/NotificationBox.vue */ "./src/components/Notification/NotificationBox.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_Spinners__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/Spinners */ "./src/components/Spinners/index.js");










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ForgotPasword',
  components: {
    NotificationBox: _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_6__["default"]
  },
  mixins: [_components_mixins_global_GlobalSpinnerMixin__WEBPACK_IMPORTED_MODULE_5__["default"]],
  data: function data() {
    return {
      companyLoginId: '',
      isRequestComplete: false,
      hasError: false,
      message: '',
      notificationType: '',
      username: ''
    };
  },
  computed: {
    spinner: function spinner() {
      return _components_Spinners__WEBPACK_IMPORTED_MODULE_9__["default"];
    },
    logoImgPath: function logoImgPath() {
      return this.$theme.isDark ? __webpack_require__(/*! @/assets/images/flexiquote-logo-dark.svg */ "./src/assets/images/flexiquote-logo-dark.svg") : __webpack_require__(/*! @/assets/images/flexiquote-logo-light.svg */ "./src/assets/images/flexiquote-logo-light.svg");
    }
  },
  methods: {
    cancel: function cancel() {
      return Object(_loginNavigation__WEBPACK_IMPORTED_MODULE_4__["goToLogin"])();
    },
    sendEmail: function sendEmail() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.$v.$touch();
              if (!_this.$v.$error) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              _context.p = 1;
              _this.$showSpinner();
              _context.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_2__["AuthService"].forgotPassword(_this.companyLoginId, _this.username, false);
            case 2:
              _this.message = 'An email has been sent to your nominated account. Please follow the instructions to reset your password.';
              _this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_7__["NotificationBoxType"].Warning;
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.hasError = true;
              _this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_7__["NotificationBoxType"].Error;
              _this.message = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_3__["getErrorMessage"])(_t.response.data).message;
            case 4:
              _context.p = 4;
              _this.isRequestComplete = true;
              _this.$hideSpinner();
              return _context.f(4);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    }
  },
  validations: {
    username: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["required"]
    },
    companyLoginId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["required"]
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", [_c("div", {
    staticClass: "control is-flex is-align-items-center",
    class: [_vm.notificationClass, _vm.textclass, _vm.$theme.isDark ? "is-dark" : "is-light"]
  }, [_c("div", {
    staticClass: "mr-4"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: _vm.icon
  })])]), _vm._t("text-content")], 2)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "forgot-password-container is-flex is-align-items-center is-justify-content-center"
  }, [_vm.$showSpinnerRequestCount > 0 ? _c(_vm.spinner, {
    tag: "component"
  }) : _vm._e(), _c("div", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "control mb-5 is-flex is-justify-content-center"
  }, [_c("img", {
    staticStyle: {
      "max-height": "2.25rem"
    },
    attrs: {
      src: _vm.logoImgPath,
      alt: "Flexiquote Logo",
      title: "Flexiquote Logo"
    }
  })]), _vm._m(0), !_vm.isRequestComplete ? _c("div", [_c("div", {
    staticClass: "control mb-6"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Username")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.username,
      expression: "username"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Username"
    },
    domProps: {
      value: _vm.username
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.username = $event.target.value;
      }
    }
  }), _vm.$v.username.$dirty && !_vm.$v.username.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Company ID")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyLoginId,
      expression: "companyLoginId"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Company ID"
    },
    domProps: {
      value: _vm.companyLoginId
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.companyLoginId = $event.target.value;
      }
    }
  }), _vm.$v.companyLoginId.$dirty && !_vm.$v.companyLoginId.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _vm._m(1)]), _c("div", {
    staticClass: "control mb-2 is-flex is-justify-content-space-between"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.cancel
    }
  }, [_vm._m(2), _vm._v(" Cancel")]), _c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.sendEmail
    }
  }, [_vm._m(3), _vm._v(" Send Email")])])]) : _vm._e(), _vm.isRequestComplete ? _c("div", [_c("notification-box", {
    staticClass: "mb-6",
    attrs: {
      type: _vm.notificationType
    }
  }, [_c("p", {
    staticClass: "is-size-7",
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(_vm._s(_vm.message))])]), _c("div", {
    staticClass: "control is-flex is-justify-content-end"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.cancel
    }
  }, [_vm._m(4), _vm._v(" Back to login ")])])], 1) : _vm._e()])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "control mb-5"
  }, [_c("h4", {
    staticClass: "has-text-weight-medium is-size-5"
  }, [_vm._v("Reset your password")]), _c("p", {
    staticClass: "has-text-grey is-size-7"
  }, [_vm._v("Please enter your username and company ID, and we will email you instructions on how to reset your password. ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "is-required-label"
  }), _c("label", {
    staticClass: "is-size-7"
  }, [_vm._v("Required Fields")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-send"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-arrow-left"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.noti-warning {\n  border: 1px solid #f9bf00;\n  border-radius: 4px;\n  /* background-color: #fffcf2; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-danger {\n  border: 2px solid #d73654;\n  border-radius: 4px;\n  /* background-color: #fff6f8; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-primary {\n  border: 2px solid #3291ef;\n  border-radius: 4px;\n  /* background-color: #f0f8ff; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default {\n  border: 1px solid #dbdbdb;\n  border-radius: 4px;\n  background-color: #f5f5f5;\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default.is-dark {\n  border-color: #4a4a4a;\n  background-color: #363636;\n}\n\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(/*! ../../assets/images/flexiquoteloginbackground.jpg */ "./src/assets/images/flexiquoteloginbackground.jpg");
exports = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
exports.push([module.i, ".forgot-password-container[data-v-6a3f9cca] {\n  width: 100%;\n  height: 100vh;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") top center no-repeat !important;\n  background-size: cover !important;\n}\n.box[data-v-6a3f9cca] {\n  width: 350px;\n}\n.label[data-v-6a3f9cca] {\n  font-weight: 500;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7386d66a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("44f31450", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/images/flexiquoteloginbackground.jpg":
/*!*********************************************************!*\
  !*** ./src/assets/images/flexiquoteloginbackground.jpg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/flexiquoteloginbackground.a7bed929.jpg";

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue":
/*!*********************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=template&id=dc876468 */ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony import */ var _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=script&lang=js */ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Notification/NotificationBox.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!*****************************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!***************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=template&id=dc876468 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/auth/ErrorMessage.js":
/*!****************************************!*\
  !*** ./src/views/auth/ErrorMessage.js ***!
  \****************************************/
/*! exports provided: getErrorMessage, getApiErrorMessage, isSignInTicketExpired */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessage", function() { return getErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApiErrorMessage", function() { return getApiErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSignInTicketExpired", function() { return isSignInTicketExpired; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);

var errorMessages = {
  'default': {
    title: 'Something wrong',
    message: 'Something wrong. Please get in touch with support.'
  },
  'password_not_meet_criteria': {
    title: 'Password not meet criteria',
    message: 'The password you provided does not meet criteria.'
  },
  'forget_password_request_not_found': {
    title: 'Forget Password Request not found',
    message: 'Forget password request not found. Please send a new request.'
  },
  'no_valid_user_found': {
    title: 'No valid user found',
    message: 'We could not locate a user matching information you provided. Please get in touch with support.'
  },
  'failed_send_email_with_mailgun': {
    title: 'Failed to send an email',
    message: 'Failed to send an email. Please get in touch with support.'
  },
  'failed_create_password_entry': {
    title: 'Failed to create password entry',
    message: 'Failed to create password entry. Please get in touch with support.'
  },
  'failed_insert_emailoutgoing': {
    title: 'Failed to insert email outgoing record',
    message: 'Failed to insert email outgoing record. Please get in touch with support.'
  },
  'password_reset_link_expired': {
    title: 'Expired password reset link',
    message: 'The password reset link has expired. Please send a new request.'
  },
  'password_reset_link_used': {
    title: 'Used password reset link',
    message: 'The password reset link has already been used. Please send a new request.'
  },
  'not_valid_user_token': {
    title: 'Invalid user token',
    message: 'Not valid user. Please contact support.'
  }
};
var getErrorMessage = function getErrorMessage(errorCode) {
  return errorMessages[errorCode] || errorMessages['default'];
};

/**
 * Text to show for a failed sign-in call.
 *
 * Distinct from getErrorMessage above, which maps known error *codes* to friendly copy. The
 * sign-in endpoints instead return literal user-facing strings ("Invalid credentials, you have
 * 3 remaining attempts", "You have been locked out. Try again in ...") deliberately matched to
 * the wording of the legacy login page, so the server's message is the message to display.
 *
 * ASP.NET Web API serialises Request.CreateErrorResponse as {"Message": "..."}, but the shape
 * varies across the endpoints and proxies involved, so each known form is checked in turn.
 *
 * A few of these endpoints do return a bare code rather than prose - the password-change path
 * surfaces 'password_not_meet_criteria' straight from UpdateUserPassword - so anything matching
 * a known code is translated rather than shown to the user verbatim.
 */
var getApiErrorMessage = function getApiErrorMessage(error, fallback) {
  var data = error && error.response ? error.response.data : null;
  var raw = null;
  if (typeof data === 'string' && data.trim()) {
    raw = data;
  } else if (data) {
    if (typeof data.Message === 'string' && data.Message.trim()) raw = data.Message;else if (typeof data.message === 'string' && data.message.trim()) raw = data.message;else if (typeof data.ExceptionMessage === 'string' && data.ExceptionMessage.trim()) raw = data.ExceptionMessage;
  }
  if (!raw) return fallback || 'Something went wrong. Please try again.';
  var trimmed = raw.trim();
  return errorMessages[trimmed] ? errorMessages[trimmed].message : trimmed;
};

/**
 * True when a sign-in step failed because its server-side ticket is gone. The only way on from
 * there is to enter the password again for a fresh ticket.
 */
var isSignInTicketExpired = function isSignInTicketExpired(error) {
  var data = error && error.response ? error.response.data : null;
  return !!data && data.code === 'signin_ticket_expired';
};

/***/ }),

/***/ "./src/views/auth/ForgotPassword.vue":
/*!*******************************************!*\
  !*** ./src/views/auth/ForgotPassword.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true */ "./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true");
/* harmony import */ var _ForgotPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ForgotPassword.vue?vue&type=script&lang=js */ "./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true */ "./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ForgotPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6a3f9cca",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/ForgotPassword.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=style&index=0&id=6a3f9cca&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_style_index_0_id_6a3f9cca_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true":
/*!*************************************************************************************!*\
  !*** ./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ForgotPassword.vue?vue&type=template&id=6a3f9cca&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ForgotPassword_vue_vue_type_template_id_6a3f9cca_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=24.js.map