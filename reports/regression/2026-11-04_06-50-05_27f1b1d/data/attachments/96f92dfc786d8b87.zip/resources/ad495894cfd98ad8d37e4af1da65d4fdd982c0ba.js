(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["printpreview-chunk~quote-communications-chunk~quote-documents-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/LazyImage.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/LazyImage.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'LazyImage',
  props: {
    src: {
      type: String,
      default: null
    }
  },
  data: function data() {
    return {
      loading: false
    };
  },
  computed: {
    isLoaded: function isLoaded() {
      return !this.loading && this.src != '' && this.src != null;
    }
  },
  watch: {
    src: function src(val, oldVal) {
      this.setLoading(true);
    }
  },
  methods: {
    setLoading: function setLoading(state) {
      console.log('x', state);
      this.loading = state;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _QuoteAttachmentViewerModal_vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./QuoteAttachmentViewerModal.vue */ "./src/views/quote/components/QuoteAttachmentViewerModal.vue");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_13__);














/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteAttachment',
  components: {
    QuoteAttachmentViewerModal: _QuoteAttachmentViewerModal_vue__WEBPACK_IMPORTED_MODULE_12__["default"]
  },
  props: {
    quoteId: {
      type: String
    },
    quoteAttachmentId: {
      type: String
    },
    quoteAttachmentCategoryId: {
      type: String
    },
    attachment: {
      type: Object
    },
    categories: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {
      modalOpen: false
    };
  },
  computed: {
    isPdf: function isPdf() {
      return this.attachment && this.attachment.filename && this.attachment.filename.toLowerCase().endsWith('.pdf');
    },
    isLocked: function isLocked() {
      var _this$attachment;
      return ((_this$attachment = this.attachment) === null || _this$attachment === void 0 ? void 0 : _this$attachment.isLocked) === true;
    },
    isSelectedComputed: function isSelectedComputed() {
      return this.attachment && this.attachment.isSelected === true;
    },
    fileDateTime: function fileDateTime() {
      var dateTime = this.attachment.createdDate;
      if (this.attachment.modifiedDate !== undefined) {
        dateTime = this.attachment.modifiedDate;
      }
      return luxon__WEBPACK_IMPORTED_MODULE_13__["DateTime"].fromISO(dateTime).toLocaleString();
    },
    pagesCountText: function pagesCountText() {
      var postfix = 'Page';
      if (this.pagesCount > 1) {
        postfix += 's';
      }
      return this.pagesCount + ' ' + postfix;
    },
    pagesCount: function pagesCount() {
      // No more quoteAttachmentDerivatives, fallback to 1
      return 1;
    },
    fileSize: function fileSize() {
      var size = this.attachment.fileSize;
      var i = size == 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
      return Math.round(size / Math.pow(1024, i)) + ' ' + ['B', 'KB', 'MB', 'GB', 'TB'][i];
    },
    thumbnailUrl: function thumbnailUrl() {
      if (!this.attachment || !this.attachment.filename) return '';
      var filename = this.attachment.filename.toLowerCase();
      var externalStorageURL = this.attachment.externalStorageURL || '';
      var imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg'];
      if (filename.endsWith('.pdf')) {
        return __webpack_require__(/*! @/assets/images/attachment-pdf.png */ "./src/assets/images/attachment-pdf.png");
      } else if (imageExts.some(function (ext) {
        return filename.endsWith(ext);
      })) {
        return externalStorageURL || __webpack_require__(/*! @/assets/images/image.png */ "./src/assets/images/image.png");
      } else {
        return __webpack_require__(/*! @/assets/images/attachment-doc.png */ "./src/assets/images/attachment-doc.png");
      }
    }
  },
  watch: {},
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    handleIsSelectedChange: function handleIsSelectedChange(value) {
      this.$emit('update:attachment', {
        attachment: this.attachment,
        isSelected: value
      });
    },
    imageUpdated: function imageUpdated() {
      this.$emit('image-uploaded');
    },
    handleAttachmentClick: function handleAttachmentClick() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var response, blob, url, a, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              if (!_this.isPdf) {
                _context.n = 6;
                break;
              }
              _context.p = 1;
              _context.n = 2;
              return fetch(_this.attachment.externalStorageURL);
            case 2:
              response = _context.v;
              _context.n = 3;
              return response.blob();
            case 3:
              blob = _context.v;
              url = window.URL.createObjectURL(blob);
              a = document.createElement('a');
              a.href = url;
              a.download = _this.attachment.filename;
              document.body.appendChild(a);
              a.click();
              setTimeout(function () {
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
              }, 100);
              _context.n = 5;
              break;
            case 4:
              _context.p = 4;
              _t = _context.v;
              console.error('PDF download failed:', _t);
            case 5:
              _context.n = 7;
              break;
            case 6:
              _this.modalOpen = true;
            case 7:
              return _context.a(2);
          }
        }, _callee, null, [[1, 4]]);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_LazyImage__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/LazyImage */ "./src/components/LazyImage.vue");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_VuePainterro__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/VuePainterro */ "./src/components/VuePainterro/index.js");

















// import _orderBy from 'lodash/orderBy'

// import PsPdfViewer from '@/components/PsPdfViewer.vue'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteAttachmentViewerModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__["BaseModalEx"],
    LazyImage: _components_LazyImage__WEBPACK_IMPORTED_MODULE_15__["default"]
    // PsPdfViewer
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    },
    quoteId: {
      type: String
    },
    quoteAttachmentId: {
      type: String
    },
    attachment: {
      type: Object
    },
    quoteAttachmentCategoryId: {
      type: String
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      selectedDervied: null,
      internalAttachment: this.attachment,
      redaction: false,
      maxHeight: '600px'
    };
  },
  computed: {
    isPDF: function isPDF() {
      return this.internalAttachment.filename && this.internalAttachment.filename.toLowerCase().endsWith('.pdf');
    },
    // Thumbnails and main image are now based on attachment.filename and attachment.externalStorageURL
    pageThumbnails: function pageThumbnails() {
      // Only one thumbnail, from the attachment itself
      return [{
        quoteAttachmentId: this.attachment.quoteAttachmentId || 'main',
        externalStorageURL: this.attachment.externalStorageURL || ''
      }];
    },
    mainImageLink: function mainImageLink() {
      return this.attachment.externalStorageURL || '';
    }
  },
  watch: {
    active: function active(value) {
      this.isActive = value;
    },
    attachment: function attachment(value) {
      this.internalAttachment = value;
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    downloadUrl: function downloadUrl(url, fileName) {
      var link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(link.href);
    },
    downloadModifiedDocument: function downloadModifiedDocument() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var fileName, response, blob, reader, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              fileName = _this.attachment.filename;
              _context.p = 1;
              _context.n = 2;
              return fetch(_this.mainImageLink);
            case 2:
              response = _context.v;
              _context.n = 3;
              return response.blob();
            case 3:
              blob = _context.v;
              reader = new FileReader();
              reader.onloadend = function () {
                var base64data = reader.result;
                _this.downloadUrl(base64data, fileName);
              };
              reader.readAsDataURL(blob);
              _context.n = 5;
              break;
            case 4:
              _context.p = 4;
              _t = _context.v;
              console.error('Download failed:', _t);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 4]]);
      }))();
    },
    toggleRedaction: function toggleRedaction(value) {
      if (value !== undefined) {
        this.redaction = value;
        return;
      }
      this.redaction = !this.redaction;
    },
    ucaseFirst: function ucaseFirst(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    },
    editImage: function editImage() {
      var _this$attachment,
        _this2 = this;
      // Documents filed by an integration are view only; editing would overwrite the original.
      if ((_this$attachment = this.attachment) !== null && _this$attachment !== void 0 && _this$attachment.isLocked || this.$licenceExpired) {
        return;
      }
      var vm = this;
      Object(_components_VuePainterro__WEBPACK_IMPORTED_MODULE_17__["OpenImageLink"])(this.mainImageLink, function (image) {
        var type = 'modifiedPageImages';
        var pageIndex = 0; // Only one image now
        setTimeout(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
            while (1) switch (_context2.n) {
              case 0:
                _context2.n = 1;
                return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_16__["default"].uploadQuoteAttachmentDerived(_this2.quoteId, _this2.quoteAttachmentId, type, pageIndex, image);
              case 1:
                vm.$emit('updated-image');
              case 2:
                return _context2.a(2);
            }
          }, _callee2);
        })), 0);
      }, function () {}, true);
    },
    viewImage: function viewImage(derived) {
      this.selectedDervied = derived;
    },
    cancel: function cancel() {
      this.toggleRedaction(false);
      this.$emit('cancel');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/LazyImage.vue?vue&type=template&id=0c9faac7":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/LazyImage.vue?vue&type=template&id=0c9faac7 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-relative",
    staticStyle: {
      height: "100%",
      width: "100%",
      "object-fit": "contain"
    }
  }, [!_vm.isLoaded ? _c("div", {
    staticClass: "loading-image",
    staticStyle: {
      height: "100%",
      width: "100%",
      "object-fit": "contain"
    }
  }) : _vm._e(), _c("img", {
    staticStyle: {
      height: "100%",
      width: "100%",
      "object-fit": "contain"
    },
    attrs: {
      src: _vm.src
    },
    on: {
      load: function load($event) {
        return _vm.setLoading(false);
      }
    }
  })]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3 ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-clickable is-unselectable py-0 px-0",
    class: "quote-attachment-background-".concat(_vm.$theme.name)
  }, [_c("div", {
    staticClass: "columns is-gapless is-multiline is-relative"
  }, [_c("div", {
    staticClass: "button is-primary is-small px-1 m-0",
    class: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      "is-light": !_vm.isSelectedComputed
    }, "is-light-btn-".concat(_vm.$theme.name), !_vm.isSelectedComputed),
    staticStyle: {
      position: "absolute",
      top: "0",
      left: "0",
      "z-index": "1"
    },
    on: {
      click: function click($event) {
        return _vm.handleIsSelectedChange(!_vm.isSelectedComputed);
      }
    }
  }, [_c("i", {
    staticClass: "mdi mdi-check",
    class: {
      "has-text-grey-light": !_vm.isSelectedComputed
    }
  })]), _c("div", {
    staticClass: "column is-full is-clipped"
  }, [_c("figure", {
    staticClass: "image is-3by4 is-fullwidth is-vcentered",
    on: {
      click: _vm.handleAttachmentClick
    }
  }, [_c("img", {
    staticStyle: {
      "object-fit": "cover"
    },
    attrs: {
      src: _vm.thumbnailUrl
    }
  })]), _c("quote-attachment-viewer-modal", {
    attrs: {
      active: _vm.modalOpen,
      attachment: _vm.attachment,
      "quote-id": _vm.quoteId,
      "quote-attachment-id": _vm.quoteAttachmentId,
      "quote-attachment-category-id": _vm.quoteAttachmentCategoryId
    },
    on: {
      cancel: function cancel($event) {
        _vm.modalOpen = false;
      },
      "updated-image": function updatedImage($event) {
        return _vm.imageUpdated();
      }
    }
  })], 1), _c("div", {
    staticClass: "column is-full is-size-7 is-clipped columns is-multiline"
  }, [_c("div", {
    staticClass: "column is-narrow p-0 m-0"
  }, [_vm.isLocked ? _c("span", {
    staticClass: "icon tooltip",
    attrs: {
      "data-tooltip": "Attached by an integration. View only - it cannot be deleted, moved, edited or copied to another quote."
    }
  }, [_c("i", {
    staticClass: "mdi mdi-lock mdi-18px"
  })]) : _c("i", {
    staticClass: "mdi mdi-drag-vertical mdi-24px"
  })]), _c("div", {
    staticClass: "columns is-multiline column is-clipped p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-full p-0 m-0",
    staticStyle: {
      overflow: "hidden",
      "text-overflow": "ellipsis",
      "font-weight": "bold",
      "white-space": "nowrap"
    },
    attrs: {
      tooltip: _vm.attachment.filename,
      title: _vm.attachment.filename + "(" + _vm.pagesCount + ")"
    }
  }, [_vm._v(_vm._s(_vm.attachment.filename) + "(" + _vm._s(_vm.pagesCount) + ")")]), _c("div", {
    staticClass: "column is-full p-0 m-0"
  }, [_vm._v(_vm._s(_vm.fileDateTime))])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Document")])])]), _c("section", {
    staticClass: "modal-card-body p-0 m-0",
    staticStyle: {
      position: "relative"
    }
  }, [_c("div", {
    staticClass: "columns p-0 m-0"
  }, [_c("div", {
    staticClass: "column is-2 p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0",
    style: {
      height: _vm.maxHeight,
      overflowY: "auto",
      overflowX: "hidden"
    }
  }, [_c("div", {
    staticClass: "columns is-multiline p-0 m-0"
  }, _vm._l(_vm.pageThumbnails, function (derived) {
    return _c("div", {
      key: derived.quoteAttachmentId,
      staticClass: "column is-full p-0 m-0"
    }, [_c("a", {
      on: {
        click: function click($event) {
          return _vm.viewImage(derived);
        }
      }
    }, [_c("figure", {
      staticClass: "image is-128x128"
    }, [_c("LazyImage", {
      staticClass: "image is-128x128",
      staticStyle: {
        "object-fit": "contain"
      },
      attrs: {
        src: derived.externalStorageURL
      }
    })], 1)])]);
  }), 0)])]), _c("div", {
    staticClass: "column p-0 m-0"
  }, [_c("div", {
    staticClass: "box p-0 m-0"
  }, [_c("figure", {
    staticClass: "image",
    on: {
      click: function click($event) {
        return _vm.editImage(_vm.mainImageDerived);
      }
    }
  }, [_c("LazyImage", {
    staticClass: "image",
    attrs: {
      src: _vm.mainImageLink
    }
  })], 1)])])])]), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [_vm.isPDF && false ? _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click() {
        _vm.toggleRedaction(true);
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-format-color-marker-cancel mdi-18px"
  })]), _c("span", [_vm._v("Redact")])]) : _vm._e(), _c("button", {
    staticClass: "button",
    on: {
      click: function click() {
        _vm.downloadModifiedDocument();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-format-color-marker-cancel mdi-18px"
  })]), _c("span", [_vm._v("Download")])])]), _c("div", {
    staticStyle: {
      "align-self": "flex-end"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]), _c("span", [_vm._v("Close")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./src/assets/images/attachment-doc.png":
/*!**********************************************!*\
  !*** ./src/assets/images/attachment-doc.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/attachment-doc.4702bc2f.png";

/***/ }),

/***/ "./src/assets/images/attachment-pdf.png":
/*!**********************************************!*\
  !*** ./src/assets/images/attachment-pdf.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/attachment-pdf.bce4ba74.png";

/***/ }),

/***/ "./src/assets/images/image.png":
/*!*************************************!*\
  !*** ./src/assets/images/image.png ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/image.a2e49234.png";

/***/ }),

/***/ "./src/components/LazyImage.vue":
/*!**************************************!*\
  !*** ./src/components/LazyImage.vue ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LazyImage.vue?vue&type=template&id=0c9faac7 */ "./src/components/LazyImage.vue?vue&type=template&id=0c9faac7");
/* harmony import */ var _LazyImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LazyImage.vue?vue&type=script&lang=js */ "./src/components/LazyImage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _LazyImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__["render"],
  _LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/LazyImage.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/LazyImage.vue?vue&type=script&lang=js":
/*!**************************************************************!*\
  !*** ./src/components/LazyImage.vue?vue&type=script&lang=js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LazyImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./LazyImage.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/LazyImage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LazyImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/LazyImage.vue?vue&type=template&id=0c9faac7":
/*!********************************************************************!*\
  !*** ./src/components/LazyImage.vue?vue&type=template&id=0c9faac7 ***!
  \********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./LazyImage.vue?vue&type=template&id=0c9faac7 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/LazyImage.vue?vue&type=template&id=0c9faac7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LazyImage_vue_vue_type_template_id_0c9faac7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueEmail/index.js":
/*!******************************************!*\
  !*** ./src/components/VueEmail/index.js ***!
  \******************************************/
/*! exports provided: VueEmail, VueEmailModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VueEmail", function() { return VueEmail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VueEmailModal", function() { return VueEmailModal; });
// import VueEmail from './VueEmail'
// import VueEmailModal from './VueEmailModal'
var VueEmail = function VueEmail(r) {
  return __webpack_require__.e(/*! require.ensure | email-components-chunk */ "email-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueEmail.vue */ "./src/components/VueEmail/VueEmail.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var VueEmailModal = function VueEmailModal(r) {
  return __webpack_require__.e(/*! require.ensure | email-components-chunk */ "email-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueEmailModal.vue */ "./src/components/VueEmail/VueEmailModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/components/VuePainterro/PainterroService.js":
/*!*********************************************************!*\
  !*** ./src/components/VuePainterro/PainterroService.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Buffer) {/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");






/* harmony default export */ __webpack_exports__["default"] = ({
  getImage: function getImage(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result, image;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/quotes/images/data/".concat(id);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get(url, {
              responseType: 'arraybuffer'
            });
          case 1:
            result = _context.v;
            // console.log(result)
            // const image = btoa(String.fromCharCode(...new Uint8Array(result.data)))
            image = Buffer.from(result.data, 'binary').toString('base64');
            return _context.a(2, "data:".concat(result.headers['content-type'].toLowerCase(), ";base64,").concat(image));
        }
      }, _callee);
    }))();
  },
  saveImage: function saveImage(id, formData) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/quotes/images/save/".concat(id);
            _context2.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].post(url, formData);
          case 1:
            result = _context2.v;
            return _context2.a(2, result);
        }
      }, _callee2);
    }))();
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/buffer/index.js */ "./node_modules/buffer/index.js").Buffer))

/***/ }),

/***/ "./src/components/VuePainterro/index.js":
/*!**********************************************!*\
  !*** ./src/components/VuePainterro/index.js ***!
  \**********************************************/
/*! exports provided: OpenImage, OpenImageLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenImage", function() { return OpenImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenImageLink", function() { return OpenImageLink; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _PainterroService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PainterroService */ "./src/components/VuePainterro/PainterroService.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");





// import VuePainterro from './VuePainterro'


// import Painterro from 'painterro'
// let Painterro = null
// import(/* webpackChunkName: "painterro-chunk" */ 'painterro').then(({ default: painterro }) => { return Painterro = painterro })

var defaultMimeType = 'image/jpeg';
var OpenImage = /*#__PURE__*/function () {
  var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(id, saveCallback, closeCallBack) {
    var closeOnSave,
      image,
      _yield$import,
      Painterro,
      _args2 = arguments;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
      while (1) switch (_context2.n) {
        case 0:
          closeOnSave = _args2.length > 3 && _args2[3] !== undefined ? _args2[3] : false;
          if (!_components_Guid__WEBPACK_IMPORTED_MODULE_6__["default"].validGuid(id)) {
            _context2.n = 3;
            break;
          }
          _context2.n = 1;
          return _PainterroService__WEBPACK_IMPORTED_MODULE_5__["default"].getImage(id);
        case 1:
          image = _context2.v;
          _context2.n = 2;
          return __webpack_require__.e(/*! import() | painterro-chunk */ "painterro-chunk").then(__webpack_require__.t.bind(null, /*! painterro */ "./node_modules/painterro/build/painterro.commonjs2.js", 7));
        case 2:
          _yield$import = _context2.v;
          Painterro = _yield$import.default;
          Painterro({
            hiddenTools: ['open'],
            defaultTool: 'arrow',
            // availableArrowLengths: [10,15,20,25,30,35,40],
            defaultArrowLength: 15,
            // colorScheme: {
            //   main: '#008cba',
            //   control: '#ffffff',
            //   controlContent: '#008cba',
            //   hoverControl: 'darkgray', //'#f2f2f2',
            //   hoverControlContent: '#008cba',
            //   activeControl: 'darkgray',
            //   activeControlContent: '#ffffff',
            //   inputText: 'black'
            // },
            colorScheme: {
              // main: '#008cba',
              control: '#008cba',
              controlContent: '#ffffff',
              hoverControl: '#006687',
              hoverControlContent: '#ffffff',
              activeControl: '#006687',
              activeControlContent: '#ffffff',
              inputText: 'black',
              toolControlNameColor: '#5bc0de'
            },
            saveHandler: function () {
              var _saveHandler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(image, done) {
                var formData;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
                  while (1) switch (_context.n) {
                    case 0:
                      formData = new FormData();
                      formData.append('image', image.asBlob(defaultMimeType), image.suggestedFileName());
                      _context.n = 1;
                      return _PainterroService__WEBPACK_IMPORTED_MODULE_5__["default"].saveImage(id, formData);
                    case 1:
                      if (saveCallback) saveCallback(id);
                      done(closeOnSave);
                      // doClose()
                    case 2:
                      return _context.a(2);
                  }
                }, _callee);
              }));
              function saveHandler(_x4, _x5) {
                return _saveHandler.apply(this, arguments);
              }
              return saveHandler;
            }(),
            // onBeforeClose() {
            //   closeCallBack()
            //   doClose()
            // }
            onClose: function onClose() {
              closeCallBack();
            }
          }).show(image);
          // })
        case 3:
          return _context2.a(2);
      }
    }, _callee2);
  }));
  return function OpenImage(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();
var OpenImageLink = /*#__PURE__*/function () {
  var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(link, saveCallback, closeCallBack) {
    var closeOnSave,
      _yield$import2,
      Painterro,
      _args4 = arguments;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
      while (1) switch (_context4.n) {
        case 0:
          closeOnSave = _args4.length > 3 && _args4[3] !== undefined ? _args4[3] : false;
          _context4.n = 1;
          return __webpack_require__.e(/*! import() | painterro-chunk */ "painterro-chunk").then(__webpack_require__.t.bind(null, /*! painterro */ "./node_modules/painterro/build/painterro.commonjs2.js", 7));
        case 1:
          _yield$import2 = _context4.v;
          Painterro = _yield$import2.default;
          Painterro({
            hiddenTools: ['open'],
            defaultTool: 'arrow',
            defaultArrowLength: 15,
            colorScheme: {
              control: '#008cba',
              controlContent: '#ffffff',
              hoverControl: '#006687',
              hoverControlContent: '#ffffff',
              activeControl: '#006687',
              activeControlContent: '#ffffff',
              inputText: 'black',
              toolControlNameColor: '#5bc0de'
            },
            saveHandler: function () {
              var _saveHandler2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3(image, done) {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
                  while (1) switch (_context3.n) {
                    case 0:
                      _context3.n = 1;
                      return saveCallback(image.asBlob(defaultMimeType));
                    case 1:
                      done(closeOnSave);
                    case 2:
                      return _context3.a(2);
                  }
                }, _callee3);
              }));
              function saveHandler(_x9, _x0) {
                return _saveHandler2.apply(this, arguments);
              }
              return saveHandler;
            }(),
            onClose: function onClose() {
              closeCallBack();
            }
          }).show(link);
        case 2:
          return _context4.a(2);
      }
    }, _callee4);
  }));
  return function OpenImageLink(_x6, _x7, _x8) {
    return _ref2.apply(this, arguments);
  };
}();

// export default VuePainterro


/***/ }),

/***/ "./src/views/quote/components/QuoteAttachment.vue":
/*!********************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachment.vue ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteAttachment.vue?vue&type=template&id=0b775eb3 */ "./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3");
/* harmony import */ var _QuoteAttachment_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteAttachment.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteAttachment_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteAttachment.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js":
/*!********************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachment_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachment.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachment.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachment_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3":
/*!**************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3 ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachment.vue?vue&type=template&id=0b775eb3 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachment.vue?vue&type=template&id=0b775eb3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachment_vue_vue_type_template_id_0b775eb3__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentViewerModal.vue":
/*!*******************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentViewerModal.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8 */ "./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8");
/* harmony import */ var _QuoteAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteAttachmentViewerModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteAttachmentViewerModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js":
/*!*******************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentViewerModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentViewerModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8":
/*!*************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8 ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteAttachmentViewerModal.vue?vue&type=template&id=440fadb8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAttachmentViewerModal_vue_vue_type_template_id_440fadb8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=printpreview-chunk~quote-communications-chunk~quote-documents-chunk.js.map