(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["insurer-ntar-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerConsumables',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]
  },
  props: {
    entity: null,
    isEditValues: Boolean,
    isError: null
  },
  data: function data() {
    return {
      selectedIndex: 1,
      errorMessage: 'Value cannot be 0 or negative'
    };
  },
  computed: {
    $v: function $v() {
      return this.$parent.$v;
    },
    versionList: function versionList() {
      if (!this.entity.insurerConsumables) {
        return [];
      }
      var versionList = [];
      this.entity.insurerConsumables.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      return versionList.sort();
    },
    selectedList: {
      get: function get() {
        if (!this.entity.insurerConsumables) {
          return [];
        }
        var versionFilter = function versionFilter(obj) {
          if (this === obj.versionNo) return obj;
        };
        return this.entity.insurerConsumables.filter(versionFilter, this.selectedIndex);
      },
      set: function set(newValue) {}
    }
  },
  watch: {
    selectedList: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.checkError();
        }
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.selectedIndex = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList));
  },
  methods: {
    // onNativeInput(index, event) {
    //   const location = ((this.selectedIndex - 1) * 5) + index
    //   this.$parent.$v.entity.insurerConsumables.$each[location].value.$touch()
    //   this.entity.insurerConsumables[location].isDirty = true
    // },
    getVersionList: function getVersionList() {
      var versionList = [];
      this.entity.insurerConsumables.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      this.versionList = versionList.sort();
    },
    getSelectedVersionData: function getSelectedVersionData() {
      var versionFilter = function versionFilter(obj) {
        if (this === obj.versionNo) return obj;
      };
      this.selectedList = this.entity.insurerConsumables.filter(versionFilter, this.selectedIndex);
    },
    // addNewList() {
    //   const newVersion = Math.max(...this.versionList) + 1
    //   this.versionList.push(newVersion)
    //   var newList = JSON.parse(JSON.stringify(this.selectedList))
    //   newList.forEach(item => {
    //     item.value = 0
    //     item.versionNo = newVersion
    //     item.consumablesId = Guid.newGuid()
    //     item.isNew = true
    //     this.entity.insurerConsumables.push(item)
    //   })
    //   this.selectedList = newList
    //   this.selectedIndex = newVersion
    // },
    addNewList: function addNewList() {
      var _this = this;
      // Get Max and New Version
      var maxVersion = this.getMaximumVersion();
      var newVersion = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList)) + 1;

      // Get Previous Version Entity
      var prevEntity = this.entity.insurerConsumables.filter(function (i) {
        return i.versionNo === newVersion - 1;
      });

      // Check if newVersion < maxVersion (i.e add versions to match the maxVersion)
      if (newVersion < maxVersion) {
        // Get Previous Version Entity
        // let prevEntity = this.entity.insurerConsumables.filter((i) => i.versionNo === newVersion - 1)

        if (prevEntity) {
          // Add Previous Version Entity to versions below Max Version
          for (var i = newVersion; i <= maxVersion; i++) {
            this.versionList.push(i);
            var newList = JSON.parse(JSON.stringify(prevEntity));
            newList.forEach(function (item) {
              item.versionNo = i;
              item.consumablesId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
              item.isNew = true;
              _this.entity.insurerConsumables.push(item);
            });
            this.selectedList = newList;
            this.selectedIndex = maxVersion;
          }

          //Finally add New Version (i.e max version)
          // this.versionList.push(maxVersion)
          // var newList = JSON.parse(JSON.stringify(this.selectedList))
          // newList.forEach(item => {
          // item.value = 0
          // item.versionNo = maxVersion
          // item.paintTypeId = Guid.newGuid()
          // item.isNew = true
          // this.entity.insurerConsumables.push(item)
          // })
          // this.selectedList = newList
          // this.selectedIndex = maxVersion
          this.$emit('add-versions', maxVersion);
        }
      } else {
        // if newVersion is same as max version or greater than max version
        // simply add new version
        this.versionList.push(newVersion);
        var newList = JSON.parse(JSON.stringify(prevEntity));
        newList.forEach(function (item) {
          item.versionNo = newVersion;
          item.consumablesId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
          item.isNew = true;
          _this.entity.insurerConsumables.push(item);
        });
        this.selectedList = newList;
        this.selectedIndex = newVersion;

        // Add previous versions to other consumables
        // if they are behind the max version
        // this will put all the consumables to same version
        this.$emit('add-versions', newVersion);
      }
    },
    // Get Maximum values from all the Values
    getMaximumVersion: function getMaximumVersion() {
      var value = [Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }))];
      return Math.max.apply(Math, value);
    },
    // Edit Consumable Values
    editValues: function editValues(value) {
      // Can edit all the values
      this.$emit('on-edit', value);
    },
    checkError: function checkError() {
      // const maxVersion = this.getMaximumVersion()

      // const check = this.entity.insurerConsumables.find((i) => i.versionNo === maxVersion && i.value <= 0.00)

      // if (check) {
      //   this.$emit('set-error',  { isError: true , CMI: true, PMI: false, LVI: false, SPI: false })
      // }
      // else {
      //   this.$emit('set-error',  { isError: false , CMI: true, PMI: false, LVI: false, SPI: false })
      // }
      this.$emit('set-error');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");













// import InsurerCommon from './InsurerCommon'


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerLoadingValues',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]
  },
  props: {
    entity: null,
    isEditValues: Boolean,
    isError: null
  },
  data: function data() {
    return {
      selectedIndex: 1,
      errorMessage: 'Value cannot be 0 or negative'
    };
  },
  computed: {
    $v: function $v() {
      return this.$parent.$v;
    },
    versionList: function versionList() {
      if (!this.entity.insurerLoadingValues) {
        return [];
      }
      var versionList = [];
      this.entity.insurerLoadingValues.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      return versionList.sort();
    },
    selectedList: {
      get: function get() {
        if (!this.entity.insurerLoadingValues) {
          return [];
        }
        var versionFilter = function versionFilter(obj) {
          if (this === obj.versionNo) return obj;
        };
        return this.entity.insurerLoadingValues.filter(versionFilter, this.selectedIndex);
      },
      set: function set(newValue) {}
    }
  },
  watch: {
    selectedList: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.checkError();
        }
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.selectedIndex = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList));
  },
  methods: {
    onNativeInput: function onNativeInput(index, event) {
      this.$v.entity.insurerLoadingValues.$each[index].value.$touch();
    },
    getVersionList: function getVersionList() {
      var versionList = [];
      this.entity.insurerLoadingValues.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      this.versionList = versionList.sort();
    },
    getSelectedVersionData: function getSelectedVersionData() {
      var versionFilter = function versionFilter(obj) {
        if (this === obj.versionNo) return obj;
      };
      this.selectedList = this.entity.insurerLoadingValues.filter(versionFilter, this.selectedIndex);
    },
    // addNewList() {
    //   const newVersion = Math.max(...this.versionList) + 1
    //   this.versionList.push(newVersion)
    //   var newList = JSON.parse(JSON.stringify(this.selectedList))
    //   newList.forEach(item => {
    //     item.value = 0
    //     item.versionNo = newVersion
    //     item.ntarLoadingValueId = Guid.newGuid()
    //     item.isNew = true
    //     this.entity.insurerLoadingValues.push(item)
    //   })
    //   this.selectedList = newList
    //   this.selectedIndex = newVersion
    // }
    addNewList: function addNewList() {
      var _this = this;
      // Get Max and New Version
      var maxVersion = this.getMaximumVersion();
      var newVersion = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList)) + 1;

      // Get Previous Version Entity
      var prevEntity = this.entity.insurerLoadingValues.filter(function (i) {
        return i.versionNo === newVersion - 1;
      });

      // Check if newVersion < maxVersion (i.e add versions to match the maxVersion)
      if (newVersion < maxVersion) {
        // Get Previous Version Entity
        //let prevEntity = this.entity.insurerLoadingValues.filter((i) => i.versionNo === newVersion - 1)

        if (prevEntity) {
          // Add Previous Version Entity to versions below Max Version
          for (var i = newVersion; i <= maxVersion; i++) {
            this.versionList.push(i);
            var newList = JSON.parse(JSON.stringify(prevEntity));
            newList.forEach(function (item) {
              item.versionNo = i;
              item.ntarLoadingValueId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
              item.isNew = true;
              _this.entity.insurerLoadingValues.push(item);
            });
            this.selectedList = newList;
            this.selectedIndex = maxVersion;
          }

          //Finally add New Version (i.e max version)
          // this.versionList.push(maxVersion)
          // var newList = JSON.parse(JSON.stringify(prevEntity))
          // newList.forEach(item => {
          // item.value = 0
          // item.versionNo = maxVersion
          // item.paintTypeId = Guid.newGuid()
          // item.isNew = true
          // this.entity.insurerLoadingValues.push(item)
          // })
          // this.selectedList = newList
          // this.selectedIndex = maxVersion

          this.$emit('add-versions', maxVersion);
        }
      } else {
        // if newVersion is same as max version or greater than max version
        // simply add new version
        this.versionList.push(newVersion);
        var newList = JSON.parse(JSON.stringify(prevEntity));
        newList.forEach(function (item) {
          item.versionNo = newVersion;
          item.ntarLoadingValueId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
          item.isNew = true;
          _this.entity.insurerLoadingValues.push(item);
        });
        this.selectedList = newList;
        this.selectedIndex = newVersion;

        // Add previous versions to other consumables
        // if they are behind the max version
        // this will put all the consumables to same version
        this.$emit('add-versions', newVersion);
      }
    },
    // Get Maximum values from all the Values
    getMaximumVersion: function getMaximumVersion() {
      var value = [Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }))];
      return Math.max.apply(Math, value);
    },
    // Edit Consumable Values
    editValues: function editValues(value) {
      // Can edit all the values
      this.$emit('on-edit', value);
    },
    checkError: function checkError() {
      // const maxVersion = this.getMaximumVersion()

      // console.log('Max Version ', maxVersion)
      // const check = this.entity.insurerPaintMaterials.find((i) => i.versionNo === maxVersion && i.value <= 0.00)

      // console.log('Check ', check)

      // if (check) {
      //   this.$emit('set-error',  { isError: true , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      // else {
      //   this.$emit('set-error',  { isError: false , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      this.$emit('set-error');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerPaintMaterials',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]
  },
  props: {
    entity: null,
    isEditValues: Boolean,
    isError: null
  },
  data: function data() {
    return {
      selectedIndex: 1,
      errorMessage: 'Value cannot be 0 or negative'
    };
  },
  computed: {
    $v: function $v() {
      return this.$parent.$v;
    },
    versionList: function versionList() {
      if (!this.entity.insurerPaintMaterials) {
        return [];
      }
      var versionList = [];
      this.entity.insurerPaintMaterials.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      return versionList.sort();
    },
    selectedList: {
      get: function get() {
        if (!this.entity.insurerPaintMaterials) {
          return [];
        }
        var versionFilter = function versionFilter(obj) {
          if (this === obj.versionNo) return obj;
        };
        return this.entity.insurerPaintMaterials.filter(versionFilter, this.selectedIndex);
      },
      set: function set(newValue) {}
    }
  },
  watch: {
    selectedList: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.checkError();
        }
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.selectedIndex = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList));
  },
  methods: {
    onNativeInput: function onNativeInput(index, event) {
      this.$v.entity.insurerPaintMaterials.$each[index].value.$touch();
    },
    getVersionList: function getVersionList() {
      var versionList = [];
      this.entity.insurerPaintMaterials.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      this.versionList = versionList.sort();
    },
    getSelectedVersionData: function getSelectedVersionData() {
      var versionFilter = function versionFilter(obj) {
        if (this === obj.versionNo) return obj;
      };
      this.selectedList = this.entity.insurerPaintMaterials.filter(versionFilter, this.selectedIndex);
    },
    addNewList: function addNewList() {
      var _this = this;
      // Get Max and New Version
      var maxVersion = this.getMaximumVersion();
      var newVersion = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList)) + 1;

      // Get Previous Version Entity
      var prevEntity = this.entity.insurerPaintMaterials.filter(function (i) {
        return i.versionNo === newVersion - 1;
      });

      // Check if newVersion < maxVersion (i.e add versions to match the maxVersion)
      if (newVersion < maxVersion) {
        // Get Previous Version Entity
        // let prevEntity = this.entity.insurerPaintMaterials.filter((i) => i.versionNo === newVersion - 1)

        if (prevEntity) {
          // Add Previous Version Entity to versions below Max Version
          for (var i = newVersion; i <= maxVersion; i++) {
            this.versionList.push(i);
            var newList = JSON.parse(JSON.stringify(prevEntity));
            newList.forEach(function (item) {
              item.versionNo = i;
              item.paintTypeId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
              item.isNew = true;
              _this.entity.insurerPaintMaterials.push(item);
            });
            this.selectedList = newList;
            this.selectedIndex = maxVersion;
          }

          //Finally add New Version (i.e max version)
          // this.versionList.push(maxVersion)
          // var newList = JSON.parse(JSON.stringify(this.selectedList))
          // newList.forEach((item) => {
          //   item.value = 0
          //   item.versionNo = maxVersion
          //   item.paintTypeId = Guid.newGuid()
          //   item.isNew = true
          //   this.entity.insurerPaintMaterials.push(item)
          // })
          // this.selectedList = newList
          // this.selectedIndex = maxVersion
          this.$emit('add-versions', maxVersion);
        }
      } else {
        // if newVersion is same as max version or greater than max version
        // simply add new version
        this.versionList.push(newVersion);
        var newList = JSON.parse(JSON.stringify(prevEntity));
        newList.forEach(function (item) {
          item.versionNo = newVersion;
          item.paintTypeId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
          item.isNew = true;
          _this.entity.insurerPaintMaterials.push(item);
        });
        this.selectedList = newList;
        this.selectedIndex = newVersion;

        // Add previous versions to other consumables
        // if they are behind the max version
        // this will put all the consumables to same version
        this.$emit('add-versions', newVersion);
      }
    },
    // Get Maximum values from all the Values
    getMaximumVersion: function getMaximumVersion() {
      var value = [Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }))];
      return Math.max.apply(Math, value);
    },
    // Edit Consumable Values
    editValues: function editValues(value) {
      // Can edit all the values
      this.$emit('on-edit', value);
    },
    checkError: function checkError() {
      // const maxVersion = this.getMaximumVersion()

      // console.log('Max Version ', maxVersion)
      // const check = this.entity.insurerPaintMaterials.find((i) => i.versionNo === maxVersion && i.value <= 0.00)

      // console.log('Check ', check)

      // if (check) {
      //   this.$emit('set-error',  { isError: true , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      // else {
      //   this.$emit('set-error',  { isError: false , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      this.$emit('set-error');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerSpecialRates',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]
  },
  props: {
    entity: null,
    isEditValues: Boolean,
    isError: null
  },
  data: function data() {
    return {
      selectedIndex: 1,
      errorMessage: 'Value cannot be 0 or negative'
    };
  },
  computed: {
    $v: function $v() {
      return this.$parent.$v;
    },
    versionList: function versionList() {
      if (!this.entity.insurerSpecialRates) {
        return [];
      }
      var versionList = [];
      this.entity.insurerSpecialRates.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      return versionList.sort();
    },
    selectedList: {
      get: function get() {
        if (!this.entity.insurerSpecialRates) {
          return [];
        }
        var versionFilter = function versionFilter(obj) {
          if (this === obj.versionNo) return obj;
        };
        return this.entity.insurerSpecialRates.filter(versionFilter, this.selectedIndex);
      },
      set: function set(newValue) {}
    }
  },
  watch: {
    selectedList: {
      handler: function handler(newVal, oldVal) {
        if (newVal) {
          this.checkError();
        }
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.selectedIndex = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList));
  },
  methods: {
    onNativeInput: function onNativeInput(index, event) {
      this.$v.entity.insurerSpecialRates.$each[index].value.$touch();
    },
    getVersionList: function getVersionList() {
      var versionList = [];
      this.entity.insurerSpecialRates.forEach(function (el) {
        var version = el.versionNo;
        if (versionList.length === 0) {
          versionList.push(version);
        } else if (versionList.indexOf(version) === -1) {
          versionList.push(version);
        }
      }, this);
      this.versionList = versionList.sort();
    },
    getSelectedVersionData: function getSelectedVersionData() {
      var versionFilter = function versionFilter(obj) {
        if (this === obj.versionNo) return obj;
      };
      this.selectedList = this.entity.insurerSpecialRates.filter(versionFilter, this.selectedIndex);
    },
    // addNewList() {
    //   const newVersion = Math.max(...this.versionList) + 1
    //   this.versionList.push(newVersion)
    //   var newList = JSON.parse(JSON.stringify(this.selectedList))
    //   newList.forEach(item => {
    //     item.value = 0
    //     item.versionNo = newVersion
    //     item.specialRatesId = Guid.newGuid()
    //     item.isNew = true
    //     this.entity.insurerSpecialRates.push(item)
    //   })
    //   this.selectedList = newList
    //   this.selectedIndex = newVersion
    // }
    addNewList: function addNewList() {
      var _this = this;
      // Get Max and New Version
      var maxVersion = this.getMaximumVersion();
      var newVersion = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.versionList)) + 1;

      // Get Previous Version Entity
      var prevEntity = this.entity.insurerSpecialRates.filter(function (i) {
        return i.versionNo === newVersion - 1;
      });

      // Check if newVersion < maxVersion (i.e add versions to match the maxVersion)
      if (newVersion < maxVersion) {
        // Get Previous Version Entity
        // let prevEntity = this.entity.insurerSpecialRates.filter((i) => i.versionNo === newVersion - 1)

        if (prevEntity) {
          // Add Previous Version Entity to versions below Max Version
          for (var i = newVersion; i <= maxVersion; i++) {
            this.versionList.push(i);
            var newList = JSON.parse(JSON.stringify(prevEntity));
            newList.forEach(function (item) {
              item.versionNo = i;
              item.specialRatesId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
              item.isNew = true;
              _this.entity.insurerSpecialRates.push(item);
            });
            this.selectedList = newList;
            this.selectedIndex = maxVersion;
          }

          //Finally add New Version (i.e max version)
          // this.versionList.push(maxVersion)
          // var newList = JSON.parse(JSON.stringify(this.selectedList))
          // newList.forEach(item => {
          // item.value = 0
          // item.versionNo = maxVersion
          // item.paintTypeId = Guid.newGuid()
          // item.isNew = true
          // this.entity.insurerSpecialRates.push(item)
          // })
          // this.selectedList = newList
          // this.selectedIndex = maxVersion
          this.$emit('add-versions', maxVersion);
        }
      } else {
        // if newVersion is same as max version or greater than max version
        // simply add new version
        this.versionList.push(newVersion);
        var newList = JSON.parse(JSON.stringify(prevEntity));
        newList.forEach(function (item) {
          item.versionNo = newVersion;
          item.specialRatesId = _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid();
          item.isNew = true;
          _this.entity.insurerSpecialRates.push(item);
        });
        this.selectedList = newList;
        this.selectedIndex = newVersion;

        // Add previous versions to other consumables
        // if they are behind the max version
        // this will put all the consumables to same version
        this.$emit('add-versions', newVersion);
      }
    },
    // Get Maximum values from all the Values
    getMaximumVersion: function getMaximumVersion() {
      var value = [Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }))];
      return Math.max.apply(Math, value);
    },
    // Edit Consumable Values
    editValues: function editValues(value) {
      // Can edit all the values
      this.$emit('on-edit', value);
    },
    checkError: function checkError() {
      // const maxVersion = this.getMaximumVersion()

      // console.log('Max Version ', maxVersion)
      // const check = this.entity.insurerPaintMaterials.find((i) => i.versionNo === maxVersion && i.value <= 0.00)

      // console.log('Check ', check)

      // if (check) {
      //   this.$emit('set-error',  { isError: true , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      // else {
      //   this.$emit('set-error',  { isError: false , CMI: false, PMI: true, LVI: false, SPI: false })
      // }
      console.log('test');
      this.$emit('set-error');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Consumbles")]), _c("p", {
    staticClass: "subtitle"
  }, [_vm._v("To change values, add a new version")]), _c("div", {
    staticClass: "field is-horizontal is-pulled-right"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons has-addons-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedIndex,
      expression: "selectedIndex"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedIndex = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, _vm._l(_vm.versionList, function (version) {
    return _c("option", {
      key: version,
      domProps: {
        value: version
      }
    }, [_vm._v(_vm._s(version))]);
  }), 0)])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      disabled: _vm.isEditValues,
      "data-tooltip": "Add new values"
    },
    on: {
      click: function click($event) {
        return _vm.addNewList();
      }
    }
  }, [_vm._m(1)])]), _c("div", {
    staticClass: "control ml-2"
  }, [!_vm.isEditValues ? _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Click to Edit Values"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(2)]) : _c("button", {
    staticClass: "button is-danger tooltip",
    attrs: {
      disabled: _vm.isError.isError,
      "data-tooltip": "Cancel Edit"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(3)])])])])]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(4), _c("tbody", _vm._l(_vm.selectedList, function (consumable) {
    return _c("tr", {
      key: consumable.consumablesId
    }, [_c("td", [_vm._v(_vm._s(consumable.description))]), _c("td", [_vm._v(_vm._s(consumable.category))]), _vm.isEditValues ? _c("td", [_c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      class: {
        "is-danger": _vm.isEditValues && consumable.value <= 0
      },
      attrs: {
        min: 0,
        precision: 2
      },
      model: {
        value: consumable.value,
        callback: function callback($$v) {
          _vm.$set(consumable, "value", $$v);
        },
        expression: "consumable.value"
      }
    }), _vm.isEditValues && consumable.value <= 0 ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v(_vm._s(_vm.errorMessage))]) : _vm._e()], 1)])])]) : _vm._e(), !_vm.isEditValues ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(consumable.value.toFixed(2)))]) : _vm._e()]);
  }), 0)])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Version")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-lead-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Description")]), _c("th", [_vm._v("Category")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Value")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Loading Values")]), _c("p", {
    staticClass: "subtitle"
  }, [_vm._v("To change values, add a new version")]), _c("div", {
    staticClass: "field is-horizontal is-pulled-right"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons has-addons-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedIndex,
      expression: "selectedIndex"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedIndex = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, _vm._l(_vm.versionList, function (version) {
    return _c("option", {
      key: version,
      domProps: {
        value: version
      }
    }, [_vm._v(_vm._s(version))]);
  }), 0)])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      disabled: _vm.isEditValues,
      "data-tooltip": "Add new values"
    },
    on: {
      click: function click($event) {
        return _vm.addNewList();
      }
    }
  }, [_vm._m(1)])]), _c("div", {
    staticClass: "control ml-2"
  }, [!_vm.isEditValues ? _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Click to Edit Values"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(2)]) : _c("button", {
    staticClass: "button is-danger tooltip",
    attrs: {
      disabled: _vm.isError.isError,
      "data-tooltip": "Cancel Edit"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(3)])])])])]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(4), _c("tbody", _vm._l(_vm.selectedList, function (loadingValue) {
    return _c("tr", {
      key: loadingValue.ntarLoadingValueId
    }, [_c("td", [_vm._v(_vm._s(loadingValue.description))]), _c("td", [_vm._v(_vm._s(loadingValue.category))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(loadingValue.lowerThreshold))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(loadingValue.upperThreshold))]), _vm.isEditValues ? _c("td", [_c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      class: {
        "is-danger": _vm.isEditValues && loadingValue.value <= 0
      },
      attrs: {
        min: 0,
        precision: 2
      },
      model: {
        value: loadingValue.value,
        callback: function callback($$v) {
          _vm.$set(loadingValue, "value", $$v);
        },
        expression: "loadingValue.value"
      }
    }), _vm.isEditValues && loadingValue.value <= 0 ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v(_vm._s(_vm.errorMessage))]) : _vm._e()], 1)])])]) : _vm._e(), !_vm.isEditValues ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(loadingValue.value.toFixed(2)))]) : _vm._e()]);
  }), 0)])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Version")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-lead-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Description")]), _c("th", [_vm._v("Category")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Lower")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Upper")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Value")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Paint Materials")]), _c("p", {
    staticClass: "subtitle"
  }, [_vm._v("To change values, add a new version")]), _c("div", {
    staticClass: "field is-horizontal is-pulled-right"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons has-addons-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedIndex,
      expression: "selectedIndex"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedIndex = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, _vm._l(_vm.versionList, function (version) {
    return _c("option", {
      key: version,
      domProps: {
        value: version
      }
    }, [_vm._v(_vm._s(version))]);
  }), 0)])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      disabled: _vm.isEditValues,
      "data-tooltip": "Add new values"
    },
    on: {
      click: function click($event) {
        return _vm.addNewList();
      }
    }
  }, [_vm._m(1)])]), _c("div", {
    staticClass: "control ml-2"
  }, [!_vm.isEditValues ? _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Click to Edit Values"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(2)]) : _c("button", {
    staticClass: "button is-danger tooltip",
    attrs: {
      disabled: _vm.isError.isError,
      "data-tooltip": "Cancel Edit"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(3)])])])])]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(4), _c("tbody", _vm._l(_vm.selectedList, function (paintMaterial) {
    return _c("tr", {
      key: paintMaterial.paintTypeId
    }, [_c("td", [_vm._v(_vm._s(paintMaterial.itemNo))]), _c("td", [_vm._v(_vm._s(paintMaterial.type))]), _vm.isEditValues ? _c("td", [_c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      class: {
        "is-danger": _vm.isEditValues && paintMaterial.value <= 0
      },
      attrs: {
        min: 0,
        precision: 2
      },
      model: {
        value: paintMaterial.value,
        callback: function callback($$v) {
          _vm.$set(paintMaterial, "value", $$v);
        },
        expression: "paintMaterial.value"
      }
    }), _vm.isEditValues && paintMaterial.value <= 0 ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v(_vm._s(_vm.errorMessage))]) : _vm._e()], 1)])])]) : _vm._e(), !_vm.isEditValues ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(paintMaterial.value.toFixed(2)))]) : _vm._e()]);
  }), 0)])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Version")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-lead-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Item No")]), _c("th", [_vm._v("Type")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Value")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Special Rates")]), _c("p", {
    staticClass: "subtitle"
  }, [_vm._v("To change values, add a new version")]), _c("div", {
    staticClass: "field is-horizontal is-pulled-right"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons field is-horizontal"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedIndex,
      expression: "selectedIndex"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedIndex = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }, function ($event) {
        return _vm.getSelectedVersionData();
      }]
    }
  }, _vm._l(_vm.versionList, function (version) {
    return _c("option", {
      key: version,
      domProps: {
        value: version
      }
    }, [_vm._v(_vm._s(version))]);
  }), 0)])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      disabled: _vm.isEditValues,
      "data-tooltip": "Add new values"
    },
    on: {
      click: function click($event) {
        return _vm.addNewList();
      }
    }
  }, [_vm._m(1)])]), _c("div", {
    staticClass: "control ml-2"
  }, [!_vm.isEditValues ? _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Click to Edit Values"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(2)]) : _c("button", {
    staticClass: "button is-danger tooltip",
    attrs: {
      disabled: _vm.isError.isError,
      "data-tooltip": "Cancel Edit"
    },
    on: {
      click: function click($event) {
        return _vm.editValues(_vm.isEditValues);
      }
    }
  }, [_vm._m(3)])])])])]), _c("table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth"
  }, [_vm._m(4), _c("tbody", _vm._l(_vm.selectedList, function (specialRate) {
    return _c("tr", {
      key: specialRate.specialRatesId
    }, [_c("td", [_vm._v(_vm._s(specialRate.itemNo))]), _c("td", [_vm._v(_vm._s(specialRate.description))]), _vm.isEditValues ? _c("td", [_c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      class: {
        "is-danger": _vm.isEditValues && specialRate.value <= 0
      },
      attrs: {
        min: 0,
        precision: 2
      },
      model: {
        value: specialRate.value,
        callback: function callback($$v) {
          _vm.$set(specialRate, "value", $$v);
        },
        expression: "specialRate.value"
      }
    }), _vm.isEditValues && specialRate.value <= 0 ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v(_vm._s(_vm.errorMessage))]) : _vm._e()], 1)])])]) : _vm._e(), !_vm.isEditValues ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(specialRate.value.toFixed(2)))]) : _vm._e()]);
  }), 0)])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Version")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-lead-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Item No")]), _c("th", [_vm._v("Description")]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v("Value")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./src/views/insurer/InsurerConsumables.vue":
/*!**************************************************!*\
  !*** ./src/views/insurer/InsurerConsumables.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerConsumables.vue?vue&type=template&id=446e0709 */ "./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709");
/* harmony import */ var _InsurerConsumables_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerConsumables.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InsurerConsumables_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerConsumables.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js":
/*!**************************************************************************!*\
  !*** ./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerConsumables_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerConsumables.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerConsumables.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerConsumables_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709":
/*!********************************************************************************!*\
  !*** ./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709 ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerConsumables.vue?vue&type=template&id=446e0709 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerConsumables.vue?vue&type=template&id=446e0709");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerConsumables_vue_vue_type_template_id_446e0709__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/InsurerLoadingValues.vue":
/*!****************************************************!*\
  !*** ./src/views/insurer/InsurerLoadingValues.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerLoadingValues.vue?vue&type=template&id=0dea72d7 */ "./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7");
/* harmony import */ var _InsurerLoadingValues_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerLoadingValues.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InsurerLoadingValues_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerLoadingValues.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerLoadingValues_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerLoadingValues.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerLoadingValues.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerLoadingValues_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7":
/*!**********************************************************************************!*\
  !*** ./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7 ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerLoadingValues.vue?vue&type=template&id=0dea72d7 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerLoadingValues.vue?vue&type=template&id=0dea72d7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerLoadingValues_vue_vue_type_template_id_0dea72d7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/InsurerPaintMaterials.vue":
/*!*****************************************************!*\
  !*** ./src/views/insurer/InsurerPaintMaterials.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerPaintMaterials.vue?vue&type=template&id=9bc75936 */ "./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936");
/* harmony import */ var _InsurerPaintMaterials_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerPaintMaterials.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InsurerPaintMaterials_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerPaintMaterials.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerPaintMaterials_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerPaintMaterials.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerPaintMaterials_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936":
/*!***********************************************************************************!*\
  !*** ./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936 ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerPaintMaterials.vue?vue&type=template&id=9bc75936 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerPaintMaterials.vue?vue&type=template&id=9bc75936");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerPaintMaterials_vue_vue_type_template_id_9bc75936__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/InsurerSpecialRates.vue":
/*!***************************************************!*\
  !*** ./src/views/insurer/InsurerSpecialRates.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerSpecialRates.vue?vue&type=template&id=55bcc211 */ "./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211");
/* harmony import */ var _InsurerSpecialRates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerSpecialRates.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InsurerSpecialRates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerSpecialRates.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSpecialRates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSpecialRates.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSpecialRates.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSpecialRates_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211":
/*!*********************************************************************************!*\
  !*** ./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSpecialRates.vue?vue&type=template&id=55bcc211 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSpecialRates.vue?vue&type=template&id=55bcc211");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSpecialRates_vue_vue_type_template_id_55bcc211__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=insurer-ntar-chunk.js.map