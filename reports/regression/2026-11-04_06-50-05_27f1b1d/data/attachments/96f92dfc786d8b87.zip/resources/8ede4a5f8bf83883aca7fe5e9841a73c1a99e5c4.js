(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["documentselect-components-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.entries.js */ "./node_modules/core-js/modules/es.object.entries.js");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.ends-with.js */ "./node_modules/core-js/modules/es.string.ends-with.js");
/* harmony import */ var core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_ends_with_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _services_EstImageService__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/services/EstImageService */ "./src/services/EstImageService.js");



























var MaximumDocuments = 99;
// EstImage document upload accepts PDFs and images only (FQ-2920). Keep in sync
// with AllowedDocumentExtensions on the API (EstImageOnlineService).
var AllowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tif', 'tiff'];
// AudaNet/Bridge submitFile accepts jpg or pdf only (FQ-2949 / BMS spec "11.0 submitFile").
var AudaNetAllowedExtensions = ['pdf', 'jpg', 'jpeg'];
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'DocumentSelect',
  props: {
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    quoteId: {
      type: String,
      default: ''
    },
    maxSelected: {
      type: Number,
      default: MaximumDocuments
    },
    subtitle: {
      type: String,
      default: 'Select documents to attach'
    },
    isLoading: {
      type: Boolean,
      default: false
    },
    preSelect: {
      type: String,
      default: null
    },
    // When true, source sent-state from the attachment referenceId (AudaNet) and
    // restrict uploadable types to jpg/pdf. Mirrors ImageSelect's isAudanet flag.
    isAudanet: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      documentsWithInfo: [],
      categories: [],
      isLoadingDocuments: false
    };
  },
  computed: {
    allowedExtensions: function allowedExtensions() {
      return this.isAudanet ? AudaNetAllowedExtensions : AllowedExtensions;
    },
    // Group the flat document list by their category for display.
    categoriesWithDocuments: function categoriesWithDocuments() {
      var _this = this;
      var groups = {};
      this.documentsWithInfo.forEach(function (doc) {
        var key = doc.quoteAttachmentCategoryId || 'uncategorised';
        if (!groups[key]) {
          var category = _this.categories.find(function (c) {
            return c.quoteAttachmentCategoryId === key;
          });
          groups[key] = {
            categoryId: key,
            name: category ? category.name : 'Documents',
            documents: []
          };
        }
        groups[key].documents.push(doc);
      });
      // Within each category, not-yet-sent documents come first (stable sort keeps
      // the server order within each sent/unsent partition).
      var result = Object.values(groups);
      result.forEach(function (group) {
        group.documents.sort(function (a, b) {
          return a.isSent === b.isSent ? 0 : a.isSent ? 1 : -1;
        });
      });
      return result;
    },
    // Watched so the selected list is emitted whenever a checkbox changes.
    selected: function selected() {
      return this.documentsWithInfo.map(function (d) {
        return d.isSelected;
      });
    }
  },
  watch: {
    selected: function selected() {
      var selectedDocuments = this.documentsWithInfo.filter(function (d) {
        return d.isSelected;
      }).map(function (d) {
        return {
          quoteAttachmentId: d.quoteAttachmentId,
          fileName: d.filename,
          fileSize: d.fileSize
        };
      });
      this.$emit('input', selectedDocuments);
    }
  },
  created: function created() {
    this.loadDocuments();
  },
  methods: {
    // Reuses the existing Documents tab endpoints so the selector shows the quote's
    // real documents, restricted to the PDF/image types EstImage accepts.
    loadDocuments: function loadDocuments() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var categories, response, data, sent, sentIds, documents, _t, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this2.isLoadingDocuments = true;
              _context.p = 1;
              _context.n = 2;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_25__["default"].getQuoteAttachmentCategories();
            case 2:
              categories = _context.v;
              _this2.categories = Array.isArray(categories) ? categories : [];
              _context.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_25__["default"].getQuoteAttachments(_this2.quoteId);
            case 3:
              response = _context.v;
              data = response && response.data ? response.data : {}; // Sent-state is best-effort: if it can't be fetched, fall back to showing
              // every document as unsent rather than blanking the selector.
              // AudaNet tracks "sent" via the attachment referenceId (set once submitted);
              // EstImage tracks it via a dedicated endpoint.
              sent = [];
              if (_this2.isAudanet) {
                _context.n = 7;
                break;
              }
              _context.p = 4;
              _context.n = 5;
              return _services_EstImageService__WEBPACK_IMPORTED_MODULE_26__["default"].getSentDocuments(_this2.quoteId);
            case 5:
              sentIds = _context.v;
              sent = Array.isArray(sentIds) ? sentIds : [];
              _context.n = 7;
              break;
            case 6:
              _context.p = 6;
              _t = _context.v;
              sent = [];
            case 7:
              documents = []; // The attachment list is grouped by category server-side: the outer key/row
              // carries the categoryId (the inner attachment summary does not), so read the
              // category from there to group documents the way images are grouped.
              Object.entries(data).forEach(function (_ref) {
                var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, 2),
                  categoryKey = _ref2[0],
                  row = _ref2[1];
                var categoryId = row && row.quoteAttachmentCategoryId || categoryKey || 'uncategorised';
                var attachments = row && row.quoteAttachments ? row.quoteAttachments : {};
                Object.values(attachments).forEach(function (attachment) {
                  if (attachment && attachment.deleted) return;
                  var filename = attachment.filename || attachment.fileName || '';
                  // PDF & images only.
                  if (!_this2.isUploadableType(filename)) return;
                  documents.push({
                    quoteAttachmentId: attachment.quoteAttachmentId,
                    quoteAttachmentCategoryId: categoryId,
                    filename: filename,
                    fileSize: attachment.fileSize || attachment.originalFileSize || 0,
                    externalStorageUrl: attachment.externalStorageURL || attachment.externalStorageUrl || '',
                    isSent: _this2.isAudanet ? !!attachment.referenceId : sent.includes(attachment.quoteAttachmentId),
                    isSelected: false
                  });
                });
              });
              _this2.documentsWithInfo = documents;

              // Mirror the image selector: pre-select documents not yet sent to EstImage.
              // Sent documents still appear (unselected) and remain selectable.
              if (_this2.preSelect === 'NotSent') {
                _this2.documentsWithInfo.forEach(function (d) {
                  d.isSelected = !d.isSent;
                });
              }
              _context.n = 9;
              break;
            case 8:
              _context.p = 8;
              _t2 = _context.v;
              _this2.documentsWithInfo = [];
            case 9:
              _context.p = 9;
              _this2.isLoadingDocuments = false;
              return _context.f(9);
            case 10:
              return _context.a(2);
          }
        }, _callee, null, [[4, 6], [1, 8, 9, 10]]);
      }))();
    },
    isUploadableType: function isUploadableType(filename) {
      var extension = (filename || '').split('.').pop().toLowerCase();
      return this.allowedExtensions.includes(extension);
    },
    categorySelectedCount: function categorySelectedCount(category) {
      return category.documents.reduce(function (total, doc) {
        return doc.isSelected ? total + 1 : total;
      }, 0);
    },
    categoryHasSelected: function categoryHasSelected(category) {
      return category.documents.some(function (doc) {
        return doc.isSelected;
      });
    },
    setSelectedStatusAll: function setSelectedStatusAll(category, selected) {
      category.documents.forEach(function (doc) {
        doc.isSelected = selected;
      });
    },
    // Mirrors the Documents tab (QuoteAttachment.vue): real image preview for image
    // types, a PDF thumbnail asset for PDFs, a generic doc asset otherwise.
    thumbnailUrl: function thumbnailUrl(doc) {
      var filename = (doc.filename || '').toLowerCase();
      var url = doc.externalStorageUrl || '';
      var imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tif', '.tiff', '.svg'];
      if (filename.endsWith('.pdf')) {
        return __webpack_require__(/*! @/assets/images/attachment-pdf.png */ "./src/assets/images/attachment-pdf.png");
      }
      if (imageExts.some(function (ext) {
        return filename.endsWith(ext);
      })) {
        return url || __webpack_require__(/*! @/assets/images/image.png */ "./src/assets/images/image.png");
      }
      return __webpack_require__(/*! @/assets/images/attachment-doc.png */ "./src/assets/images/attachment-doc.png");
    },
    // A signed image URL can expire/404 - fall back to a placeholder image.
    onThumbError: function onThumbError(e) {
      e.target.src = __webpack_require__(/*! @/assets/images/image.png */ "./src/assets/images/image.png");
    },
    formatFileSize: function formatFileSize(sizeInBytes) {
      if (!sizeInBytes || sizeInBytes === 0) {
        return '0 KB';
      }
      var sizeInKB = Math.round(sizeInBytes / 1024);
      return "".concat(sizeInKB, " KB");
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);



var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child"
  }, [_vm.isLoadingDocuments ? _c("div", [_c("div", {
    staticClass: "is-size-5 mb-2 has-text-grey"
  }, [_vm._v("Loading documents...")]), _c("div", {
    staticClass: "columns is-multiline dragable-box"
  }, _vm._l(8, function (n) {
    return _c("div", {
      key: "doc-skeleton-".concat(n),
      staticClass: "column is-narrow p-2"
    }, [_vm._m(0, true)]);
  }), 0)]) : _vm.documentsWithInfo.length === 0 ? _c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_vm._m(1), _c("div", [_vm._v("No Documents")])]) : _vm._l(_vm.categoriesWithDocuments, function (category) {
    return [_c("div", {
      key: category.categoryId,
      staticClass: "tile"
    }, [_c("div", {
      staticClass: "tile is-parent"
    }, [_c("article", {
      staticClass: "tile is-child"
    }, [_c("div", {
      staticClass: "columns"
    }, [_c("div", {
      staticClass: "column"
    }, [_c("div", {
      staticClass: "category-name is-size-4 has-text-weight-semibold"
    }, [_vm._v(_vm._s(category.name))]), _c("div", {
      staticClass: "is-size-5"
    }, [_vm._v(" " + _vm._s(_vm.subtitle) + " "), _c("span", {
      class: {
        "has-text-danger": _vm.categorySelectedCount(category) > _vm.maxSelected
      }
    }, [_vm._v(" (" + _vm._s(_vm.categorySelectedCount(category)) + "/" + _vm._s(category.documents.length) + ") ")])])]), _c("div", {
      staticClass: "column is-narrow"
    }, [_c("div", {
      staticClass: "buttons"
    }, [category.documents.length > 0 ? _c("a", {
      staticClass: "button tooltip",
      attrs: {
        "data-tooltip": "Select all"
      },
      on: {
        click: function click($event) {
          return _vm.setSelectedStatusAll(category, true);
        }
      }
    }, [_vm._m(2, true)]) : _vm._e(), _c("a", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.categoryHasSelected(category),
        expression: "categoryHasSelected(category)"
      }],
      staticClass: "button tooltip",
      attrs: {
        "data-tooltip": "Deselect all"
      },
      on: {
        click: function click($event) {
          return _vm.setSelectedStatusAll(category, false);
        }
      }
    }, [_vm._m(3, true)])])])]), _c("div", {
      staticClass: "columns is-multiline dragable-box"
    }, _vm._l(category.documents, function (doc, index) {
      return _c("div", {
        key: doc.quoteAttachmentId || index,
        staticClass: "column is-narrow p-2"
      }, [_c("div", {
        staticClass: "card document-card",
        class: {
          "document-card--sent": doc.isSent
        },
        staticStyle: {
          "box-shadow": "0 0 0 1px #d9d9d9"
        }
      }, [_c("header", {
        staticClass: "card-header"
      }, [_c("div", {
        staticClass: "card-header-title p-2"
      }, [_c("div", {
        staticClass: "control"
      }, [_c("div", {
        staticClass: "pretty p-icon p-curve p-smooth",
        staticStyle: {
          "font-size": "0.875rem"
        }
      }, [_c("input", {
        directives: [{
          name: "model",
          rawName: "v-model",
          value: doc.isSelected,
          expression: "doc.isSelected"
        }],
        attrs: {
          id: "chk-pretty-document".concat(category.categoryId, "-").concat(index),
          name: "chk-pretty-select-document".concat(category.categoryId, "-").concat(index),
          type: "checkbox"
        },
        domProps: {
          checked: Array.isArray(doc.isSelected) ? _vm._i(doc.isSelected, null) > -1 : doc.isSelected
        },
        on: {
          change: function change($event) {
            var $$a = doc.isSelected,
              $$el = $event.target,
              $$c = $$el.checked ? true : false;
            if (Array.isArray($$a)) {
              var $$v = null,
                $$i = _vm._i($$a, $$v);
              if ($$el.checked) {
                $$i < 0 && _vm.$set(doc, "isSelected", $$a.concat([$$v]));
              } else {
                $$i > -1 && _vm.$set(doc, "isSelected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
              }
            } else {
              _vm.$set(doc, "isSelected", $$c);
            }
          }
        }
      }), _vm._m(4, true)])])])]), _c("div", {
        staticClass: "card-content document-card-content has-text-centered p-2"
      }, [_c("figure", {
        staticClass: "image document-preview"
      }, [_c("img", {
        staticClass: "document-thumb",
        attrs: {
          src: _vm.thumbnailUrl(doc),
          alt: ""
        },
        on: {
          error: _vm.onThumbError
        }
      })]), _c("p", {
        staticClass: "document-filename is-size-7",
        attrs: {
          title: doc.filename
        }
      }, [_vm._v(_vm._s(doc.filename))]), _c("div", {
        staticClass: "document-tags"
      }, [doc.fileSize ? _c("span", {
        staticClass: "tag is-small"
      }, [_vm._v(_vm._s(_vm.formatFileSize(doc.fileSize)))]) : _vm._e(), _c("span", {
        staticClass: "tag document-status-tag",
        class: doc.isSent ? "is-success" : "is-warning"
      }, [_c("span", {
        staticClass: "icon is-small"
      }, [_c("i", {
        staticClass: "mdi",
        class: doc.isSent ? "mdi-check-circle" : "mdi-alert-circle-outline"
      })]), _c("span", [_vm._v(_vm._s(doc.isSent ? "Sent" : "Not sent"))])])])])])]);
    }), 0)])])])];
  })], 2)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "card document-card skeleton-card"
  }, [_c("div", {
    staticClass: "skeleton-block skeleton-check"
  }), _c("div", {
    staticClass: "card-content document-card-content has-text-centered p-3"
  }, [_c("div", {
    staticClass: "skeleton-block skeleton-icon"
  }), _c("div", {
    staticClass: "skeleton-block skeleton-filename"
  }), _c("div", {
    staticClass: "skeleton-block skeleton-tag"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-success"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".card-header-title[data-v-d70774a2] {\n  padding: 0.25rem 0.25rem 0.25rem 0.5rem !important;\n}\n.document-card[data-v-d70774a2] {\n  width: 120px;\n  /* Fixed height so every card lines up regardless of filename / tags. */\n  height: 218px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-transition: opacity 0.15s ease;\n  transition: opacity 0.15s ease;\n}\n\n/* Already-sent documents are dimmed so the not-yet-sent ones stand out; hovering\n   restores full opacity so they stay easy to review/re-select. */\n.document-card--sent[data-v-d70774a2] {\n  opacity: 0.5;\n}\n.document-card--sent[data-v-d70774a2]:hover {\n  opacity: 1;\n}\n.document-card-content[data-v-d70774a2] {\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  gap: 0.35rem;\n  overflow: hidden;\n}\n.document-preview[data-v-d70774a2] {\n  width: 72px;\n  height: 72px;\n  margin: 0 auto;\n}\n.document-thumb[data-v-d70774a2] {\n  width: 72px;\n  height: 72px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 4px;\n  background-color: rgba(128, 128, 128, 0.12);\n}\n\n/* Size + Sent/Not sent tags stacked vertically, centred. */\n.document-tags[data-v-d70774a2] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  gap: 0.25rem;\n}\n.document-status-tag[data-v-d70774a2] {\n  white-space: nowrap;\n  width: 100%;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n}\n.document-filename[data-v-d70774a2] {\n  max-width: 104px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-weight: 600;\n}\n.is-multiline.dragable-box[data-v-d70774a2] {\n  min-height: 3em;\n  border: dashed 2px var(--border-color);\n  border-radius: 2px;\n  margin-left: 2px;\n  margin-right: 3px;\n  background-color: var(--draggable-box-background-color);\n}\n\n/* Skeleton placeholders shown while documents load. */\n.skeleton-card[data-v-d70774a2] {\n  width: 120px;\n  padding-top: 0.5rem;\n}\n.skeleton-block[data-v-d70774a2] {\n  border-radius: 4px;\n  /* Mid-gray alphas so the shimmer reads on both light and dark themes. */\n  background: -webkit-gradient(linear, left top, right top, color-stop(25%, rgba(128, 128, 128, 0.15)), color-stop(37%, rgba(128, 128, 128, 0.3)), color-stop(63%, rgba(128, 128, 128, 0.15)));\n  background: linear-gradient(90deg, rgba(128, 128, 128, 0.15) 25%, rgba(128, 128, 128, 0.3) 37%, rgba(128, 128, 128, 0.15) 63%);\n  background-size: 400% 100%;\n  -webkit-animation: skeleton-shimmer-d70774a2 1.4s ease infinite;\n          animation: skeleton-shimmer-d70774a2 1.4s ease infinite;\n}\n.skeleton-check[data-v-d70774a2] {\n  width: 18px;\n  height: 18px;\n  margin: 0.25rem 0 0 0.5rem;\n}\n.skeleton-icon[data-v-d70774a2] {\n  width: 48px;\n  height: 48px;\n  border-radius: 6px;\n}\n.skeleton-filename[data-v-d70774a2] {\n  width: 88px;\n  height: 12px;\n}\n.skeleton-tag[data-v-d70774a2] {\n  width: 44px;\n  height: 12px;\n}\n@-webkit-keyframes skeleton-shimmer-d70774a2 {\n0% {\n    background-position: 100% 50%;\n}\n100% {\n    background-position: 0 50%;\n}\n}\n@keyframes skeleton-shimmer-d70774a2 {\n0% {\n    background-position: 100% 50%;\n}\n100% {\n    background-position: 0 50%;\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3643daf1", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/images/attachment-doc.png":
/*!**********************************************!*\
  !*** ./src/assets/images/attachment-doc.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/attachment-doc.4702bc2f.png";

/***/ }),

/***/ "./src/assets/images/attachment-pdf.png":
/*!**********************************************!*\
  !*** ./src/assets/images/attachment-pdf.png ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/attachment-pdf.bce4ba74.png";

/***/ }),

/***/ "./src/assets/images/image.png":
/*!*************************************!*\
  !*** ./src/assets/images/image.png ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/image.a2e49234.png";

/***/ }),

/***/ "./src/components/DocumentSelect/DocumentSelect.vue":
/*!**********************************************************!*\
  !*** ./src/components/DocumentSelect/DocumentSelect.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true */ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true");
/* harmony import */ var _DocumentSelect_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DocumentSelect.vue?vue&type=script&lang=js */ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true */ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _DocumentSelect_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "d70774a2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/DocumentSelect/DocumentSelect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentSelect.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=style&index=0&id=d70774a2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_style_index_0_id_d70774a2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/DocumentSelect/DocumentSelect.vue?vue&type=template&id=d70774a2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DocumentSelect_vue_vue_type_template_id_d70774a2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=documentselect-components-chunk.js.map