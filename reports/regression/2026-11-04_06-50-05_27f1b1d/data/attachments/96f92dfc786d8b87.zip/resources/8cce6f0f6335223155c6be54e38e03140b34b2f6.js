(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[32],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _services_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/services/common */ "./src/services/common.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");
/* harmony import */ var _components_VueDropzone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/VueDropzone */ "./src/components/VueDropzone/index.js");










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyEmailSetting',
  components: {
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_5__["ConfirmModal"],
    VueDropzone: _components_VueDropzone__WEBPACK_IMPORTED_MODULE_9__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_8__["default"]],
  data: function data() {
    return {
      dropzoneOptions: {
        url: "".concat("/UniqApi/v1", "/companysettings/uploadCompanyEmailSignatureImage"),
        thumbnailWidth: 128,
        thumbnailHeight: 128,
        addRemoveLinks: true,
        maxFilesize: 0.1,
        maxFiles: 1,
        acceptedFiles: 'image/*',
        headers: {
          Authorization: ''
        },
        dictDefaultMessage: '<span class="mso mso-36px">cloud_upload</span><br>click or drop your image here',
        dictMaxFilesExceeded: 'You can only upload one file.',
        dictResponseError: 'Failed to upload the image.'
      },
      companySetting: {},
      isConfirmModalActive: false
    };
  },
  computed: {
    emailSignatureImage: function emailSignatureImage() {
      if (!this.companySetting || !this.companySetting.emailSignatureImage) {
        return '';
      }
      return 'data:image/jpg;base64,' + this.companySetting.emailSignatureImage;
    }
  },
  watch: {
    companySetting: {
      handler: function handler(val) {
        this.$v.$touch();
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(val)
        });
        this.autoUpdate(val);
      },
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var _t, _t2;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.$showSpinner();
            _this.initializeAutoUpdate();
            _t = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
            _context.n = 1;
            return _this.getStoreItem({
              serviceFunction: 'getEntity'
            });
          case 1:
            _t2 = _context.v;
            _this.companySetting = _t(_t2);
            _this.dropzoneOptions.headers.Authorization = "Bearer ".concat(_services_common__WEBPACK_IMPORTED_MODULE_7__["default"].getAuthToken());
            _this.$hideSpinner();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    deleteImage: function deleteImage(deleteConfirmed) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var tmpCompanySetting;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isConfirmModalActive = false;
              if (deleteConfirmed) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _this2.$showSpinner();
              tmpCompanySetting = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(_this2.companySetting);
              tmpCompanySetting.emailSignatureImage = null;
              _this2.saveSnapshot({
                entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(tmpCompanySetting)
              });
              _context2.n = 2;
              return _this2.updateEmailSetting(tmpCompanySetting);
            case 2:
              _this2.$hideSpinner();
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdate === 'function' && typeof this.autoUpdate.cancel === 'function') {
        this.autoUpdate.cancel();
      }
      this.autoUpdate = function () {};
    },
    dropzoneMounted: function dropzoneMounted() {
      this.$refs.emailSignatureDropzone.getAcceptedFiles();
    },
    dropzoneSuccess: function dropzoneSuccess(file, response) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var _t3, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$notification.success('Company Signature Image', response);
              _t3 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
              _context3.n = 1;
              return _this3.getStoreItem({
                serviceFunction: 'getEntity'
              });
            case 1:
              _t4 = _context3.v;
              _this3.companySetting = _t3(_t4);
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    dropzoneError: function dropzoneError(file, message, xhr) {
      if (message) {
        this.$notification.error('Company Signature Image', message);
      }
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this4 = this;
      this.autoUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default()(/*#__PURE__*/function () {
        var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(value) {
          var _t5;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
            while (1) switch (_context4.n) {
              case 0:
                _t5 = _this4.snapshotDiff;
                if (!_t5) {
                  _context4.n = 1;
                  break;
                }
                _context4.n = 1;
                return _this4.updateEmailSetting(value);
              case 1:
                return _context4.a(2);
            }
          }, _callee4);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    removeImage: function removeImage() {
      this.isConfirmModalActive = true;
    },
    updateEmailSetting: function updateEmailSetting(companySetting) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var _t6, _t7;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (_this5.snapshotDiff) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              _this5.$v.$touch();
              if (!_this5.$v.$error) {
                _context5.n = 2;
                break;
              }
              return _context5.a(2);
            case 2:
              companySetting.deepDiff = JSON.stringify(_this5.snapshotDiff);
              _t6 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
              _context5.n = 3;
              return _this5.editStoreItem({
                serviceFunction: 'updateCompanySetting',
                entity: companySetting
              });
            case 3:
              _t7 = _context5.v;
              _this5.companySetting = _t6(_t7);
              if (_this5.toastNotificationEnabled) {
                _this5.openToastNotification();
              }
            case 4:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    }
  },
  validations: {
    companySetting: {
      eSetDisplayName: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6__["required"]
      },
      eSetEmail: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_6__["email"]
      },
      enabledAutoCC: {}
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this6 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
        while (1) switch (_context6.n) {
          case 0:
            _this6.disableAutoUpdate();
            _this6.toastNotificationEnabled = true;
            _context6.n = 1;
            return _this6.updateEmailSetting(_this6.companySetting);
          case 1:
            _this6.clearSnapshots();
            _this6.toastNotificationEnabled = false;
            next();
          case 2:
            return _context6.a(2);
        }
      }, _callee6);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_vm._m(0), !_vm.hasError && _vm.showSavingStatus && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()]), _c("div", {
    staticClass: "columns is-multiline"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Display Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.eSetDisplayName,
      expression: "companySetting.eSetDisplayName"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Company Name"
    },
    domProps: {
      value: _vm.companySetting.eSetDisplayName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "eSetDisplayName", $event.target.value);
      }
    }
  }), _vm.$v.companySetting.eSetDisplayName.$dirty && !_vm.$v.companySetting.eSetDisplayName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Name Required ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Display Email")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.eSetEmail,
      expression: "companySetting.eSetEmail"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Company Email"
    },
    domProps: {
      value: _vm.companySetting.eSetEmail
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "eSetEmail", $event.target.value);
      }
    }
  }), _vm.$v.companySetting.eSetEmail.$dirty && !_vm.$v.companySetting.eSetEmail.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Email Required ")]) : _vm._e(), !_vm.$v.companySetting.eSetEmail.email ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Please enter a valid email ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Enabled Auto CC")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.enabledAutoCC,
      expression: "companySetting.enabledAutoCC"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.companySetting.enabledAutoCC) ? _vm._i(_vm.companySetting.enabledAutoCC, null) > -1 : _vm.companySetting.enabledAutoCC
    },
    on: {
      change: function change($event) {
        var $$a = _vm.companySetting.enabledAutoCC,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.companySetting, "enabledAutoCC", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.companySetting, "enabledAutoCC", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.companySetting, "enabledAutoCC", $$c);
        }
      }
    }
  }), _vm._m(1)])])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label mb-3"
  }, [_vm._v("Company Signature Image")]), _vm.emailSignatureImage ? _c("div", {
    staticClass: "is-flex is-align-items-center"
  }, [_c("img", {
    staticClass: "emailSignature mr-5",
    attrs: {
      src: _vm.emailSignatureImage,
      alt: "Company Email Signature Image"
    }
  }), _c("button", {
    staticClass: "button has-text-danger",
    attrs: {
      title: "Delete"
    },
    on: {
      click: _vm.removeImage
    }
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("remove")])])]) : _c("div", [_c("vue-dropzone", {
    ref: "emailSignatureDropzone",
    attrs: {
      id: "emailSignatureDropzone",
      options: _vm.dropzoneOptions
    },
    on: {
      "vdropzone-mounted": _vm.dropzoneMounted,
      "vdropzone-success": _vm.dropzoneSuccess,
      "vdropzone-error": _vm.dropzoneError
    }
  }), _c("p", {
    staticClass: "text is-size-7 is-italic"
  }, [_vm._v("Note: Maximum image file size is 100KB. One file only.")])], 1)]), _vm.emailSignatureImage ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteImage(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteImage(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Company Signature Image")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Company Signature Image will be deleted. Continue? ")])]) : _vm._e()], 1)]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Two-Way Emails")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso mso-24px"
  }, [_vm._v("check")]), _c("label")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".emailSignature[data-v-01359762] {\n  min-height: 90px;\n  min-width: 600px;\n  max-height: 150px;\n  max-width: 650px;\n}\n#emailSignatureDropzone[data-v-01359762] {\n  border: 2px dashed #3291ef;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".dropzone .dz-preview .dz-error-message {\n  top: 150px !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("ddecd2a8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("218375c0", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VueDropzone/index.js":
/*!*********************************************!*\
  !*** ./src/components/VueDropzone/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// import VueDropzone from './VueDropzone'
var VueDropzone = function VueDropzone(r) {
  return __webpack_require__.e(/*! require.ensure | dropzone-components-chunk */ "dropzone-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueDropzone.vue */ "./src/components/VueDropzone/VueDropzone.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
/* harmony default export */ __webpack_exports__["default"] = (VueDropzone);

/***/ }),

/***/ "./src/views/companysetting/CompanyEmailSetting.vue":
/*!**********************************************************!*\
  !*** ./src/views/companysetting/CompanyEmailSetting.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true */ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true");
/* harmony import */ var _CompanyEmailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyEmailSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true */ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true");
/* harmony import */ var _CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss */ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _CompanyEmailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "01359762",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyEmailSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=0&id=01359762&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_0_id_01359762_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss":
/*!*******************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=style&index=1&id=01359762&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_style_index_1_id_01359762_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyEmailSetting.vue?vue&type=template&id=01359762&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyEmailSetting_vue_vue_type_template_id_01359762_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=32.js.map