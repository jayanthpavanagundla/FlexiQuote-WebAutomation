(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-images-chunk~quote-imagesbreakout-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_VuePainterro__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/VuePainterro */ "./src/components/VuePainterro/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_BulmaCarousel__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/BulmaCarousel */ "./src/components/BulmaCarousel/index.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27__);


























// import mimeTypes from 'mime-types'

// import CommonApiService from '@/services/common'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteImageCategory',
  components: {
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__["ConfirmModal"],
    BulmaCarouselModal: _components_BulmaCarousel__WEBPACK_IMPORTED_MODULE_24__["BulmaCarouselModal"],
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_25___default.a
  },
  props: {
    quoteId: {
      type: String
    },
    category: {
      type: String
    },
    categories: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    images: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    categoryId: {
      type: String
    },
    value: null,
    hasSelect: {
      type: Boolean,
      default: false
    },
    refresh: {
      type: Boolean,
      default: false
    },
    categoryOrderIndex: {
      type: Number
    },
    isPrivate: {
      type: Boolean
    },
    isCategorySelectAllEnable: {
      type: Boolean,
      default: true
    },
    isDeleteEnable: {
      type: Boolean,
      default: true
    },
    isImageSelectable: {
      type: Boolean,
      default: true
    }
  },
  data: function data() {
    return {
      size: 200,
      innerImages: null,
      imagesWithInfo: [],
      selectAll: false,
      imageIds: null,
      isConfirmModalActive: false,
      selectedImageId: '',
      isPrimaryConfirmModalActive: false,
      selectedPrimaryImageId: '',
      queuedFileCount: 0,
      isDropzoneActive: false,
      isClearAllActive: false,
      isUploading: false,
      isCarouselModalActive: false,
      carouselStartIndex: 0,
      isLoadingImages: false,
      lastScrollX: 0,
      lastScrollY: 0,
      areThumbnailsLoaded: false,
      id: null,
      dragImageId: null,
      dragCategoryId: null
    };
  },
  computed: {
    hasSelected: function hasSelected() {
      return this.imagesWithInfo.some(function (i) {
        return i.isSelected;
      });
    },
    selectedCount: function selectedCount() {
      return this.imagesWithInfo.reduce(function (total, item) {
        return item.isSelected ? total + 1 : total;
      }, 0);
    }
  },
  watch: {
    hasSelect: function hasSelect(value) {
      this.selectAll = value;
      this.setSelectedStatusAll(value);
    },
    refresh: function refresh(value) {
      this.getThumbnails();
    },
    imagesWithInfo: function imagesWithInfo(value) {
      var imageIds = this.imagesWithInfo.map(function (i) {
        return i.quoteImageId;
      });
      this.imageIds = imageIds;
    }
  },
  created: function created() {
    this.selectAll = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_27___default()(this.hasSelect);
    // this.dropzoneOptions.headers.Authorization = `Bearer ${CommonApiService.getAuthToken()}`
    this.getThumbnails();
  },
  mounted: function mounted() {
    this.id = this._uid + '';
  },
  methods: {
    getThumbnails: function getThumbnails() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        var images, noCategoryImages, combinedImages;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isLoadingImages = true;
              _this.imagesWithInfo.splice(0, _this.imagesWithInfo.length);
              // const vm = this
              //this.imageIds = await QuoteService.getImageIdsWithCategory(this.quoteId, this.categoryId)
              if (_this.images) {
                images = _this.images.filter(function (i) {
                  return i.imageCategoryId == _this.categoryId;
                }).sort(function (a, b) {
                  return a.orderIndex - b.orderIndex;
                });
                noCategoryImages = _this.categoryOrderIndex === 0 ? _this.images.filter(function (i) {
                  return !i.imageCategoryId;
                }) : [];
                combinedImages = images.concat(noCategoryImages).sort(function (a, b) {
                  return a.orderIndex - b.orderIndex;
                }); // combinedImages.forEach((img, index) => {
                //   img.orderIndex = index
                // })
                _this.imagesWithInfo = combinedImages;
              }
              // const promises = this.imageIds.map(function (id, index) {
              //   return vm.getThumbnailWithInfo(id, index)
              // })

              // this.imagesWithInfo = await Promise.all(promises)
              _this.isLoadingImages = false;
              _this.areThumbnailsLoaded = true;
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getThumbnailWithInfo: function getThumbnailWithInfo(id, index) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var thumbnail;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_21__["default"].getImageThumbnailWithInfo(id, _this2.size);
            case 1:
              thumbnail = _context2.v;
              return _context2.a(2, thumbnail);
          }
        }, _callee2);
      }))();
    },
    makeImagePrimary: function makeImagePrimary(targetImage) {
      var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.imagesWithInfo),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var image = _step.value;
          image.isPrimary = image.quoteImageId === targetImage.quoteImageId;
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.images),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var image = _step2.value;
          image.isPrimary = image.quoteImageId === targetImage.quoteImageId;
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
      targetImage.isPrimary = true;
      _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_21__["default"].setQuoteImageIsPrimary(targetImage.quoteImageId);
    },
    setSelectedStatusAll: function setSelectedStatusAll(selected) {
      var _this3 = this;
      this.imagesWithInfo.forEach(function (i) {
        return i.isSelected = selected;
      });
      this.imagesWithInfo.forEach(function (element) {
        var index = _this3.images.findIndex(function (i) {
          return i.quoteImageId === element.quoteImageId;
        });
        if (index !== -1) {
          _this3.images[index].isSelected = selected;
        }
      });
    },
    selectImage: function selectImage(imageid, selected) {
      var index = this.images.findIndex(function (i) {
        return i.quoteImageId === imageid;
      });
      if (index !== -1) {
        this.images[index].isSelected = selected;
      }
    },
    onImageOrderChange: function onImageOrderChange(targetCategory, event) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var movedItem;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (event.moved !== undefined) {
                console.log(event.moved);
                //await this.setQuoteImagesOrderIndex()
                _this4.$emit('arrange-images-order');
              }
              if (!(event.added !== undefined)) {
                _context3.n = 2;
                break;
              }
              movedItem = event.added.element;
              console.log(event.added);
              _context3.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_21__["default"].setImageCategory(_this4.value.quoteId, movedItem.quoteImageId, targetCategory);
            case 1:
              //await this.setQuoteImagesOrderIndex()
              _this4.$emit('arrange-images-order');
              //this.$emit('update-image')
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    // async setQuoteImagesOrderIndex() {
    //   const imageIds = this.imagesWithInfo.map((i) => i.quoteImageId)
    //   await QuoteService.setQuoteImagesOrderIndex(this.value.quoteId, imageIds)
    //   //this.imageIds = imageIds
    // },
    saved: function saved(id) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var thumbnail, updatedThumbnail;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              // Callback function to update thumbnail after saving images in Painterro
              thumbnail = _this5.imagesWithInfo.find(function (i) {
                return i.quoteImageId === id;
              });
              _context4.n = 1;
              return _this5.getThumbnailWithInfo(id, _this5.size);
            case 1:
              updatedThumbnail = _context4.v;
              thumbnail.imageContent = updatedThumbnail.imageContent;
              // Force image source update
              // document.getElementById(thumbnail.quoteImageId).src = thumbnail.imageContent
              _this5.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].ImageCountChanged, "UpdateQuote"), 0);
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    closed: function closed() {
      window.scroll(this.lastScrollX, this.lastScrollY);
    },
    editImage: function editImage(id) {
      if (this.$licenceExpired) return;
      this.$showSpinner();
      this.lastScrollX = window.scrollX;
      this.lastScrollY = window.scrollY;
      window.scrollTo(0, 0);
      Object(_components_VuePainterro__WEBPACK_IMPORTED_MODULE_22__["OpenImage"])(id, this.saved, this.closed, false);
      this.$hideSpinner();
    },
    viewImage: function viewImage(index) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this6.$showSpinner();
              _this6.carouselStartIndex = index;
              _this6.isCarouselModalActive = true;
              _this6.$hideSpinner();
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    closeCarousel: function closeCarousel() {
      this.isCarouselModalActive = false;
    },
    showDeleteModal: function showDeleteModal(id) {
      this.selectedImageId = id;
      this.isConfirmModalActive = true;
    },
    deleteImage: function deleteImage(confirm) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var index, indexToRemove;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this7.isConfirmModalActive = false;
              if (!confirm) {
                _context6.n = 2;
                break;
              }
              _context6.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_21__["default"].deleteImage(_this7.selectedImageId);
            case 1:
              index = _this7.imageIds.indexOf(_this7.selectedImageId);
              console.log(index);
              _this7.imageIds.splice(index, 1);
              indexToRemove = _this7.imagesWithInfo.findIndex(function (i) {
                return i.quoteImageId === _this7.selectedImageId;
              });
              _this7.imagesWithInfo.splice(indexToRemove, 1);
              _this7.$notification.openNotificationWithType('success', 'Delete images', 'Image deleted');
              _this7.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].ImageCountChanged, "UpdateQuote"), 0);
              //await this.setQuoteImagesOrderIndex()
              _this7.$emit('update-image');
            case 2:
              _this7.selectedImageId = '';
            case 3:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    setPrimary: function setPrimary(imageId) {
      this.selectedPrimaryImageId = imageId;
      this.isPrimaryConfirmModalActive = true;
    },
    confirmSetPrimary: function confirmSetPrimary(confirm) {
      this.isPrimaryConfirmModalActive = false;
      if (confirm) {
        console.log('Setting primary image:', this.selectedPrimaryImageId);
        this.$emit('setPrimary', this.selectedPrimaryImageId);
      }
      this.selectedPrimaryImageId = '';
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child"
  }, [_c("div", {
    staticClass: "columns title"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "subtitle"
  }, [_c("div", {
    staticClass: "p-1"
  }, [_c("div", {
    staticClass: "is-flex columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", [_c("span", {
    staticClass: "category-name"
  }, [_vm._v(_vm._s(_vm.category))]), _vm.isPrivate ? _c("span", {
    staticClass: "icon pl-3"
  }, [_c("i", {
    staticClass: "mdi mdi-eye-off mdi-24px"
  })]) : _vm._e(), _vm.imagesWithInfo.length > 0 ? _c("span", {
    staticClass: "has-badge-rounded has-badge-info has-badge-large pl-3",
    attrs: {
      "data-badge": _vm.imagesWithInfo.length
    }
  }) : _vm._e()])]), _c("div", {
    staticClass: "is-flex column is-narrow is-justify-content-flex-end"
  }, [_c("p", {
    staticClass: "buttons"
  }, [_vm.imagesWithInfo.length > 0 && _vm.isCategorySelectAllEnable ? _c("a", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Select all",
      disabled: _vm.isLoadingImages
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(true);
      }
    }
  }, [_vm._m(0)]) : _vm._e(), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected && _vm.isCategorySelectAllEnable,
      expression: "hasSelected && isCategorySelectAllEnable"
    }],
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Deselect all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(false);
      }
    }
  }, [_vm._m(1)])])])])])])])]), _c("div", [_c("draggable", {
    staticClass: "is-flex columns is-multiline dragable-box",
    attrs: {
      list: _vm.imagesWithInfo,
      group: "imagesWithInfo",
      handle: ".item-drag-handle",
      disabled: _vm.$licenceExpired
    },
    on: {
      change: function change(event) {
        return _vm.onImageOrderChange(_vm.categoryId, event);
      }
    }
  }, _vm._l(_vm.imagesWithInfo, function (image, index) {
    return _c("div", {
      key: image.quoteImageId,
      staticClass: "is-flex column is-narrow p-2 item-drag"
    }, [image.imageContent ? _c("div", {
      class: "card",
      on: {
        dblclick: function dblclick($event) {
          !_vm.$licenceExpired && _vm.makeImagePrimary(image);
        }
      }
    }, [_c("header", {
      staticClass: "card-header"
    }, [_c("div", {
      staticClass: "card-header-title p-2"
    }, [_c("div", {
      staticClass: "is-flex columns is-gapless is-justify-content-space-between",
      staticStyle: {
        width: "100%"
      }
    }, [_c("div", {
      staticClass: "is-flex column"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "control"
    }, [_vm.isImageSelectable ? _c("div", {
      staticClass: "pretty p-icon p-curve p-smooth"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: image.isSelected,
        expression: "image.isSelected"
      }],
      attrs: {
        id: "chk-pretty-image1".concat(index),
        name: "chk-pretty-image".concat(index),
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(image.isSelected) ? _vm._i(image.isSelected, null) > -1 : image.isSelected
      },
      on: {
        change: [function ($event) {
          var $$a = image.isSelected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(image, "isSelected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(image, "isSelected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(image, "isSelected", $$c);
          }
        }, function ($event) {
          return _vm.selectImage(image.quoteImageId, image.isSelected);
        }]
      }
    }), _c("div", {
      staticClass: "state p-success"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]) : _vm._e()])])]), _c("div", {
      staticClass: "is-flex column is-narrow"
    }, [_c("a", {
      staticClass: "has-text-primary is-outlined",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.editImage(image.quoteImageId);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px",
      attrs: {
        "aria-hidden": "true"
      }
    })])]), _vm.isDeleteEnable ? _c("a", {
      staticClass: "has-text-danger is-outlined",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          !_vm.$licenceExpired && _vm.showDeleteModal(image.quoteImageId);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px",
      attrs: {
        "aria-hidden": "true"
      }
    })])]) : _vm._e(), !_vm.$licenceExpired ? _c("span", {
      staticClass: "item-drag-handle"
    }, [_c("span", {
      staticClass: "msr msr-24px"
    }, [_vm._v("drag_indicator")])]) : _vm._e()])])])]), _c("div", {
      staticClass: "card-image image-container"
    }, [_c("a", {
      on: {
        click: function click($event) {
          return _vm.viewImage(index);
        }
      }
    }, [_c("figure", {
      staticClass: "image is-128x128"
    }, [_c("div", {
      staticStyle: {
        position: "relative"
      }
    }, [image.isPrimary ? _c("i", {
      staticClass: "mdi mdi-star mdi-24px has-text-gold primary-star",
      staticStyle: {
        position: "absolute",
        "z-index": "1"
      }
    }) : !_vm.$licenceExpired ? _c("i", {
      staticClass: "mdi mdi-star mdi-24px has-text-grey-lighter hover-star",
      staticStyle: {
        position: "absolute",
        "z-index": "1"
      },
      on: {
        click: function click($event) {
          $event.stopPropagation();
          return _vm.setPrimary(image.quoteImageId);
        }
      }
    }) : _vm._e(), image.imageContent ? _c("img", {
      key: image.quoteImageId,
      staticClass: "image is-128x128",
      staticStyle: {
        "object-fit": "cover"
      },
      attrs: {
        src: image.imageContent,
        id: image.quoteImageId
      }
    }) : _vm._e()])])])])]) : _vm._e()]);
  }), 0)], 1)])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteImage(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteImage(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete image")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Image will be deleted. Continue? ")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isPrimaryConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPrimaryConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.confirmSetPrimary(true);
      },
      cancel: function cancel($event) {
        return _vm.confirmSetPrimary(false);
      }
    }
  }, [_c("p", {
    staticClass: "has-text-weight-semibold",
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Set Primary Image")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("p", [_vm._v(" Are you sure you want to set this image as the primary image? ")]), _c("p", {
    staticClass: "mt-3 is-size-6 has-text-grey"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold"
  }, [_vm._v("Note:")]), _vm._v(" This will replace the current primary image. ")])])]), _vm.isCarouselModalActive ? _c("bulma-carousel-modal", {
    attrs: {
      "image-width": 800,
      "image-height": 600,
      active: _vm.isCarouselModalActive,
      "image-ids": _vm.imageIds,
      "start-index": _vm.carouselStartIndex
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCarouselModalActive = $event;
      },
      close: _vm.closeCarousel
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".category-name[data-v-534afe19] {\n  line-height: 1.8;\n}\n.is-multiline.dragable-box[data-v-534afe19] {\n  min-height: 3em;\n  border: dashed 2px var(--border-color);\n  border-radius: 2px;\n  margin-left: 2px;\n  margin-right: 3px;\n  background-color: var(--draggable-box-background-color);\n}\n.is-multiline.dragable-box .column[data-v-534afe19] {\n  max-width: -webkit-fit-content;\n  max-width: -moz-fit-content;\n  max-width: fit-content;\n}\n.image-container[data-v-534afe19] {\n  position: relative;\n}\n.image-container .hover-star[data-v-534afe19] {\n  opacity: 0;\n  -webkit-transition: opacity 0.15s ease;\n  transition: opacity 0.15s ease;\n  cursor: pointer;\n  top: 4px;\n  left: 4px;\n  pointer-events: none;\n}\n.image-container:hover .hover-star[data-v-534afe19] {\n  opacity: 1;\n  pointer-events: auto;\n}\n.hover-star[data-v-534afe19]:hover {\n  -webkit-transform: scale(1.1);\n          transform: scale(1.1);\n  color: #ffd700 !important;\n  -webkit-transition: all 0.15s ease;\n  transition: all 0.15s ease;\n}\n.primary-star[data-v-534afe19] {\n  pointer-events: none;\n  top: 4px;\n  left: 4px;\n}\n.item-drag-handle[data-v-534afe19]:hover {\n  cursor: pointer;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-images-licence-expired [disabled]:not(.tooltip) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-images-licence-expired [disabled]:not(.tooltip) > .icon {\n  opacity: 0.5;\n}\n.quote-images-licence-expired [disabled]:not(.tooltip):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  left: 50%;\n  -webkit-transform: translate(-50%, 0.5rem);\n          transform: translate(-50%, 0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-images-licence-expired .buttons > [disabled]:not(.tooltip):hover::before {\n  left: auto;\n  right: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("075b4467", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("975f7f5a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/BulmaCarousel/index.js":
/*!***********************************************!*\
  !*** ./src/components/BulmaCarousel/index.js ***!
  \***********************************************/
/*! exports provided: BulmaCarousel, BulmaCarouselModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaCarousel", function() { return BulmaCarousel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaCarouselModal", function() { return BulmaCarouselModal; });
var BulmaCarousel = function BulmaCarousel(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaCarousel.vue */ "./src/components/BulmaCarousel/BulmaCarousel.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var BulmaCarouselModal = function BulmaCarouselModal(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaCarouselModal.vue */ "./src/components/BulmaCarousel/BulmaCarouselModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/components/VuePainterro/PainterroService.js":
/*!*********************************************************!*\
  !*** ./src/components/VuePainterro/PainterroService.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Buffer) {/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");






/* harmony default export */ __webpack_exports__["default"] = ({
  getImage: function getImage(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result, image;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/quotes/images/data/".concat(id);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get(url, {
              responseType: 'arraybuffer'
            });
          case 1:
            result = _context.v;
            // console.log(result)
            // const image = btoa(String.fromCharCode(...new Uint8Array(result.data)))
            image = Buffer.from(result.data, 'binary').toString('base64');
            return _context.a(2, "data:".concat(result.headers['content-type'].toLowerCase(), ";base64,").concat(image));
        }
      }, _callee);
    }))();
  },
  saveImage: function saveImage(id, formData) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/quotes/images/save/".concat(id);
            _context2.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].post(url, formData);
          case 1:
            result = _context2.v;
            return _context2.a(2, result);
        }
      }, _callee2);
    }))();
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/buffer/index.js */ "./node_modules/buffer/index.js").Buffer))

/***/ }),

/***/ "./src/components/VuePainterro/index.js":
/*!**********************************************!*\
  !*** ./src/components/VuePainterro/index.js ***!
  \**********************************************/
/*! exports provided: OpenImage, OpenImageLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenImage", function() { return OpenImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenImageLink", function() { return OpenImageLink; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _PainterroService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PainterroService */ "./src/components/VuePainterro/PainterroService.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");





// import VuePainterro from './VuePainterro'


// import Painterro from 'painterro'
// let Painterro = null
// import(/* webpackChunkName: "painterro-chunk" */ 'painterro').then(({ default: painterro }) => { return Painterro = painterro })

var defaultMimeType = 'image/jpeg';
var OpenImage = /*#__PURE__*/function () {
  var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(id, saveCallback, closeCallBack) {
    var closeOnSave,
      image,
      _yield$import,
      Painterro,
      _args2 = arguments;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
      while (1) switch (_context2.n) {
        case 0:
          closeOnSave = _args2.length > 3 && _args2[3] !== undefined ? _args2[3] : false;
          if (!_components_Guid__WEBPACK_IMPORTED_MODULE_6__["default"].validGuid(id)) {
            _context2.n = 3;
            break;
          }
          _context2.n = 1;
          return _PainterroService__WEBPACK_IMPORTED_MODULE_5__["default"].getImage(id);
        case 1:
          image = _context2.v;
          _context2.n = 2;
          return __webpack_require__.e(/*! import() | painterro-chunk */ "painterro-chunk").then(__webpack_require__.t.bind(null, /*! painterro */ "./node_modules/painterro/build/painterro.commonjs2.js", 7));
        case 2:
          _yield$import = _context2.v;
          Painterro = _yield$import.default;
          Painterro({
            hiddenTools: ['open'],
            defaultTool: 'arrow',
            // availableArrowLengths: [10,15,20,25,30,35,40],
            defaultArrowLength: 15,
            // colorScheme: {
            //   main: '#008cba',
            //   control: '#ffffff',
            //   controlContent: '#008cba',
            //   hoverControl: 'darkgray', //'#f2f2f2',
            //   hoverControlContent: '#008cba',
            //   activeControl: 'darkgray',
            //   activeControlContent: '#ffffff',
            //   inputText: 'black'
            // },
            colorScheme: {
              // main: '#008cba',
              control: '#008cba',
              controlContent: '#ffffff',
              hoverControl: '#006687',
              hoverControlContent: '#ffffff',
              activeControl: '#006687',
              activeControlContent: '#ffffff',
              inputText: 'black',
              toolControlNameColor: '#5bc0de'
            },
            saveHandler: function () {
              var _saveHandler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(image, done) {
                var formData;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
                  while (1) switch (_context.n) {
                    case 0:
                      formData = new FormData();
                      formData.append('image', image.asBlob(defaultMimeType), image.suggestedFileName());
                      _context.n = 1;
                      return _PainterroService__WEBPACK_IMPORTED_MODULE_5__["default"].saveImage(id, formData);
                    case 1:
                      if (saveCallback) saveCallback(id);
                      done(closeOnSave);
                      // doClose()
                    case 2:
                      return _context.a(2);
                  }
                }, _callee);
              }));
              function saveHandler(_x4, _x5) {
                return _saveHandler.apply(this, arguments);
              }
              return saveHandler;
            }(),
            // onBeforeClose() {
            //   closeCallBack()
            //   doClose()
            // }
            onClose: function onClose() {
              closeCallBack();
            }
          }).show(image);
          // })
        case 3:
          return _context2.a(2);
      }
    }, _callee2);
  }));
  return function OpenImage(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();
var OpenImageLink = /*#__PURE__*/function () {
  var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(link, saveCallback, closeCallBack) {
    var closeOnSave,
      _yield$import2,
      Painterro,
      _args4 = arguments;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
      while (1) switch (_context4.n) {
        case 0:
          closeOnSave = _args4.length > 3 && _args4[3] !== undefined ? _args4[3] : false;
          _context4.n = 1;
          return __webpack_require__.e(/*! import() | painterro-chunk */ "painterro-chunk").then(__webpack_require__.t.bind(null, /*! painterro */ "./node_modules/painterro/build/painterro.commonjs2.js", 7));
        case 1:
          _yield$import2 = _context4.v;
          Painterro = _yield$import2.default;
          Painterro({
            hiddenTools: ['open'],
            defaultTool: 'arrow',
            defaultArrowLength: 15,
            colorScheme: {
              control: '#008cba',
              controlContent: '#ffffff',
              hoverControl: '#006687',
              hoverControlContent: '#ffffff',
              activeControl: '#006687',
              activeControlContent: '#ffffff',
              inputText: 'black',
              toolControlNameColor: '#5bc0de'
            },
            saveHandler: function () {
              var _saveHandler2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3(image, done) {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
                  while (1) switch (_context3.n) {
                    case 0:
                      _context3.n = 1;
                      return saveCallback(image.asBlob(defaultMimeType));
                    case 1:
                      done(closeOnSave);
                    case 2:
                      return _context3.a(2);
                  }
                }, _callee3);
              }));
              function saveHandler(_x9, _x0) {
                return _saveHandler2.apply(this, arguments);
              }
              return saveHandler;
            }(),
            onClose: function onClose() {
              closeCallBack();
            }
          }).show(link);
        case 2:
          return _context4.a(2);
      }
    }, _callee4);
  }));
  return function OpenImageLink(_x6, _x7, _x8) {
    return _ref2.apply(this, arguments);
  };
}();

// export default VuePainterro


/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategory.vue":
/*!***********************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategory.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true */ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true");
/* harmony import */ var _QuoteImageCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteImageCategory.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true */ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true");
/* harmony import */ var _QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss */ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteImageCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "534afe19",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteImageCategory.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=0&id=534afe19&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_0_id_534afe19_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss":
/*!********************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=style&index=1&id=534afe19&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_style_index_1_id_534afe19_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategory.vue?vue&type=template&id=534afe19&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategory_vue_vue_type_template_id_534afe19_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-images-chunk~quote-imagesbreakout-chunk.js.map