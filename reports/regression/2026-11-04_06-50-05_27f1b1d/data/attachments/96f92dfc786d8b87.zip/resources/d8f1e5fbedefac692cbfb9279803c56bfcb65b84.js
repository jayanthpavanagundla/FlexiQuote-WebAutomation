(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/PermissionRow.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/PermissionRow.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7__);








/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PermissionRow',
  props: {
    permission: Object,
    allPermissions: Array,
    level: {
      type: Number,
      default: 0
    }
  },
  computed: {
    children: function children() {
      var _this = this;
      return this.allPermissions.filter(function (p) {
        return p.parentId === _this.permission.permissionRecordID;
      });
    },
    hasChildren: function hasChildren() {
      return this.children.length > 0;
    },
    isParent: function isParent() {
      return this.level === 0;
    }
  },
  methods: {
    isAllChecked: function isAllChecked(type) {
      return this.children.length > 0 && this.children.every(function (child) {
        return child[type];
      });
    },
    onToggle: function onToggle(type, checked) {
      // Update the parent's own permission property
      this.permission[type] = checked;
      if (this.hasChildren) {
        this.children.forEach(function (child) {
          child[type] = checked;
          if (type === 'isBlock' && checked) {
            child.isRead = false;
            child.isAdd = false;
            child.isEdit = false;
            child.isDelete = false;
            child.isPrint = false;
          }
        });
        this.$emit('toggle-all', this.permission.permissionRecordID, type, checked);
      } else {
        // This part is for child rows and is already correct
        // this.permission[type] = checked
        if (type === 'isBlock' && checked) {
          this.permission.isRead = false;
          this.permission.isAdd = false;
          this.permission.isEdit = false;
          this.permission.isDelete = false;
          this.permission.isPrint = false;
        }
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserAccessControl.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _PermissionRow_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PermissionRow.vue */ "./src/views/user/PermissionRow.vue");










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserAccessControl',
  inject: ['$vv'],
  components: {
    PermissionRow: _PermissionRow_vue__WEBPACK_IMPORTED_MODULE_9__["default"]
  },
  props: {
    value: null // v-model
  },
  computed: {
    parentPermissions: function parentPermissions() {
      var _this$value;
      return (((_this$value = this.value) === null || _this$value === void 0 ? void 0 : _this$value.userAccessControl) || []).filter(function (p) {
        return p.parentId === '00000000-0000-0000-0000-000000000000';
      });
    },
    $v: function $v() {
      return this.$vv ? this.$vv : this.$v;
    }
  },
  mounted: function mounted() {
    this.$v.userAccessControl.$touch();
  },
  methods: {
    handleToggle: function handleToggle(_ref) {
      var permission = _ref.permission,
        type = _ref.type,
        checked = _ref.checked;
      permission[type] = checked;
      if (this.getChildren(permission.permissionRecordID).length > 0) {
        this.updateDescendants(permission.permissionRecordID, type, checked);
      }
      if (type === 'isBlock' && checked) {
        permission.isRead = false;
        permission.isAdd = false;
        permission.isEdit = false;
        permission.isDelete = false;
        permission.isPrint = false;
        if (this.getChildren(permission.permissionRecordID).length > 0) {
          this.updateDescendants(permission.permissionRecordID, 'isBlock', true);
        }
      }
      switch (type) {
        case 'isEdit':
          permission.isRead = true;
          permission.isAdd = true;
          permission.isBlock = false;
          break;
        case 'isAdd':
        case 'isDelete':
        case 'isPrint':
          permission.isRead = true;
          permission.isBlock = false;
          break;
        case 'isRead':
          if (!checked) {
            permission.isAdd = false;
            permission.isEdit = false;
            permission.isDelete = false;
            permission.isPrint = false;
          }
          break;
        case 'isBlock':
          if (checked) {
            permission.isRead = false;
            permission.isAdd = false;
            permission.isEdit = false;
            permission.isDelete = false;
            permission.isPrint = false;
          }
      }
      if (this.getChildren(permission.permissionRecordID).length > 0) {
        this.updateDescendants(permission.permissionRecordID, 'isRead', permission.isRead);
        this.updateDescendants(permission.permissionRecordID, 'isAdd', permission.isAdd);
        this.updateDescendants(permission.permissionRecordID, 'isEdit', permission.isEdit);
        this.updateDescendants(permission.permissionRecordID, 'isDelete', permission.isDelete);
        this.updateDescendants(permission.permissionRecordID, 'isPrint', permission.isPrint);
        this.updateDescendants(permission.permissionRecordID, 'isBlock', type === 'isBlock' && checked);
      }
    },
    updateDescendants: function updateDescendants(parentId, type, checked) {
      var _this = this;
      var children = this.getChildren(parentId);
      children.forEach(function (child) {
        child[type] = checked;
        if (type === 'isBlock' && checked) {
          child.isRead = false;
          child.isAdd = false;
          child.isEdit = false;
          child.isDelete = false;
          child.isPrint = false;
        }
        _this.updateDescendants(child.permissionRecordID, type, checked);
      });
    },
    getChildren: function getChildren(parentId) {
      var _this$value2;
      return (((_this$value2 = this.value) === null || _this$value2 === void 0 ? void 0 : _this$value2.userAccessControl) || []).filter(function (p) {
        return p.parentId === parentId;
      });
    },
    isAllChecked: function isAllChecked(parentId, permissionType) {
      var children = this.getChildren(parentId);
      return children.length > 0 && children.every(function (child) {
        return child[permissionType];
      });
    },
    toggleAll: function toggleAll(parentId, permissionType, checked) {
      var children = this.getChildren(parentId);
      children.forEach(function (child) {
        child[permissionType] = checked;
      });
    },
    renderRows: function renderRows(permission, level) {
      var _this$value3,
        _this2 = this;
      var rows = [{
        permission: permission,
        level: level
      }];
      var children = (((_this$value3 = this.value) === null || _this$value3 === void 0 ? void 0 : _this$value3.userAccessControl) || []).filter(function (p) {
        return p.parentId === permission.permissionRecordID;
      });
      children.forEach(function (child) {
        rows.push.apply(rows, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this2.renderRows(child, level + 1)));
      });
      return rows;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41 ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("tr", {
    class: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      "access-parent-row": _vm.isParent
    }, "theme-".concat(this.$theme.name), _vm.isParent)
  }, [_c("td", {
    style: !_vm.isParent ? {
      paddingLeft: "".concat(_vm.level * 24, "px")
    } : {}
  }, [_vm._v(_vm._s(_vm.permission.name))]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isBlock") : _vm.permission.isBlock
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isBlock",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(0)])]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox",
      disabled: _vm.permission.isBlock
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isRead") : _vm.permission.isRead
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isRead",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(1)])]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox",
      disabled: _vm.permission.isBlock
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isAdd") : _vm.permission.isAdd
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isAdd",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(2)])]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox",
      disabled: _vm.permission.isBlock
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isEdit") : _vm.permission.isEdit
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isEdit",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(3)])]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox",
      disabled: _vm.permission.isBlock
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isDelete") : _vm.permission.isDelete
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isDelete",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(4)])]), _c("td", {
    staticClass: "has-text-centered"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger m-0"
  }, [_c("input", {
    attrs: {
      type: "checkbox",
      disabled: _vm.permission.isBlock
    },
    domProps: {
      checked: _vm.hasChildren ? _vm.isAllChecked("isPrint") : _vm.permission.isPrint
    },
    on: {
      change: function change($event) {
        return _vm.$emit("toggle", {
          permission: _vm.permission,
          type: "isPrint",
          checked: $event.target.checked
        });
      }
    }
  }), _vm._m(5)])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticStyle: {
      "max-height": "500px",
      "overflow-y": "auto"
    }
  }, [_c("table", {
    staticClass: "table is-bordered is-fullwidth sticky-header-table"
  }, [_vm._m(0), _c("tbody", [_vm._l(_vm.parentPermissions, function (parent) {
    return [_vm._l(_vm.renderRows(parent, 0), function (row) {
      return [_c("PermissionRow", {
        key: row.permission.permissionRecordID,
        attrs: {
          permission: row.permission,
          "all-permissions": _vm.value.userAccessControl,
          level: row.level
        },
        on: {
          toggle: _vm.handleToggle
        }
      })];
    })];
  })], 2)])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", {
    staticStyle: {
      width: "220px"
    }
  }), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("Block")]), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("View")]), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("Add")]), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("Edit")]), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("Delete")]), _c("th", {
    staticStyle: {
      width: "60px"
    }
  }, [_vm._v("Print")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.access-parent-row[data-v-22f19584] {\n  background: hsl(222, 77%, 95%);\n  font-weight: bold;\n}\n.access-parent-row.theme-dark[data-v-22f19584] {\n  background: hsl(222, 77%, 15%);\n}\n.sticky-header-table th[data-v-22f19584] {\n  position: sticky;\n  top: 0;\n  z-index: 2;\n  background: var(--background-color);\n  color: var(--bulma-box-color);\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("8e68821e", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/user/PermissionRow.vue":
/*!******************************************!*\
  !*** ./src/views/user/PermissionRow.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PermissionRow.vue?vue&type=template&id=23266e41 */ "./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41");
/* harmony import */ var _PermissionRow_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PermissionRow.vue?vue&type=script&lang=js */ "./src/views/user/PermissionRow.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PermissionRow_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/PermissionRow.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/PermissionRow.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/user/PermissionRow.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionRow_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PermissionRow.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/PermissionRow.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionRow_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41":
/*!************************************************************************!*\
  !*** ./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41 ***!
  \************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PermissionRow.vue?vue&type=template&id=23266e41 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/PermissionRow.vue?vue&type=template&id=23266e41");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PermissionRow_vue_vue_type_template_id_23266e41__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/UserAccessControl.vue":
/*!**********************************************!*\
  !*** ./src/views/user/UserAccessControl.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true */ "./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true");
/* harmony import */ var _UserAccessControl_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserAccessControl.vue?vue&type=script&lang=js */ "./src/views/user/UserAccessControl.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css */ "./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _UserAccessControl_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "22f19584",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/UserAccessControl.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/UserAccessControl.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./src/views/user/UserAccessControl.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserAccessControl.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css":
/*!******************************************************************************************************!*\
  !*** ./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=style&index=0&id=22f19584&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_style_index_0_id_22f19584_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true":
/*!****************************************************************************************!*\
  !*** ./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserAccessControl.vue?vue&type=template&id=22f19584&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAccessControl_vue_vue_type_template_id_22f19584_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=15.js.map