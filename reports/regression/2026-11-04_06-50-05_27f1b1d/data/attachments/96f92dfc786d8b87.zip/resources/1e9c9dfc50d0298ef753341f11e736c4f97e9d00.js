(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[9],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RecurringRemarkService */ "./src/views/recurringremarks/RecurringRemarkService.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_10__);











/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    CardModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__["CardModal"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_9__["BulmaAutocomplete"]
  },
  props: {
    visible: Boolean
  },
  data: function data() {
    return {
      searchValue: '',
      selectedValue: '',
      options: [],
      isLoading: false,
      isNew: false
    };
  },
  computed: {
    notFoundMessage: function notFoundMessage() {
      if (this.searchValue === '') {
        return 'No results';
      } else {
        return 'Remark not found. You can save this remark with the save button.';
      }
    },
    message: function message() {
      if (this.searchValue === '') {
        return 'Start typing to search for a remark';
      } else if (this.isNew) {
        return 'Save and use this remark';
      } else {
        return 'Use this remark';
      }
    }
  },
  mounted: function mounted() {
    setTimeout(function () {
      document.getElementById('searcher').focus();
    }, 500);
  },
  methods: {
    close: function close() {
      // If this is not here
      // Dialog will not show up if [x] or outside of modal is clicked
      this.visible = false;
    },
    ok: function ok() {
      if (this.searchValue) {
        if (this.isNew) {
          _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__["default"].postRecurringRemark(this.searchValue);
        }
        this.$emit('ok', this.searchValue);
        this.visible = false;
      } else {
        this.cancel();
      }
    },
    cancel: function cancel() {
      this.visible = false;
    },
    search: lodash_debounce__WEBPACK_IMPORTED_MODULE_10___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(key) {
        var res;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              console.log("search ".concat(key, " - ").concat(this.selectedValue));
              if (!(key === this.selectedValue)) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              this.isNew = true;
              this.isLoading = true;
              _context.n = 2;
              return _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__["default"].getRecurringRemark(key);
            case 2:
              res = _context.v;
              this.options = res.data.result.map(function (d) {
                return d.remarkDescription;
              });
              this.isLoading = false;
            case 3:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    select: function select(val) {
      if (val) {
        this.isNew = false;
        this.selectedValue = val;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserProfile.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserProfile.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../services */ "./src/services/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _assets_UserAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./assets/UserAssetAddresses.vue */ "./src/views/user/assets/UserAssetAddresses.vue");
/* harmony import */ var _assets_UserAssetPhones_vue__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./assets/UserAssetPhones.vue */ "./src/views/user/assets/UserAssetPhones.vue");
/* harmony import */ var _assets_UserAssetEmails_vue__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./assets/UserAssetEmails.vue */ "./src/views/user/assets/UserAssetEmails.vue");
/* harmony import */ var _assets_UserContacts_vue__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./assets/UserContacts.vue */ "./src/views/user/assets/UserContacts.vue");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../classes/viewmodels */ "./src/classes/viewmodels/index.js");
























// import ContactService from '../contact/ContactService'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserProfile',
  inject: ['$vv'],
  components: {
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_18___default.a,
    UserAssetAddresses: _assets_UserAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_20__["default"],
    UserAssetPhones: _assets_UserAssetPhones_vue__WEBPACK_IMPORTED_MODULE_21__["default"],
    UserAssetEmails: _assets_UserAssetEmails_vue__WEBPACK_IMPORTED_MODULE_22__["default"],
    UserContacts: _assets_UserContacts_vue__WEBPACK_IMPORTED_MODULE_23__["default"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_17__["DateTimeFiltersMixin"]],
  props: {
    value: null //v-model
  },
  data: function data() {
    return {
      innerValue: null,
      selectedDOBDate: null,
      address: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      addresses: {
        data: [],
        loading: false
      },
      isCompaniesLoading: false,
      companies: [],
      selectedCompany: null
    };
  },
  computed: {
    addressTypes: function addressTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["AddressTypes"];
    },
    salutes: function salutes() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["Salutation"];
    },
    sex: function sex() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["Gender"];
    },
    activeAddresses: function activeAddresses() {
      if (this.innerValue.profile && this.innerValue.profile.assetAddresses) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.innerValue.profile.assetAddresses).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    activePhones: function activePhones() {
      if (this.innerValue.profile && this.innerValue.profile.assetPhones) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.innerValue.profile.assetPhones).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    activeEmails: function activeEmails() {
      if (this.innerValue.profile && this.innerValue.profile.assetEmails) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.innerValue.profile.assetEmails).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    countryCode: function countryCode() {
      if (this.activeAddresses && this.activeAddresses.length > 0) {
        var address = this.activeAddresses.find(function (a) {
          return a.isDefault;
        });
        if (address) {
          return address.countryCode;
        }
        return this.activeAddresses[0].countryCode;
      }
      return this.$company.info.countryCode;
    },
    activeContacts: function activeContacts() {
      return this.innerValue.profile.contacts.filter(function (c) {
        return c.contact.isActive;
      });
    },
    $entity: function $entity() {
      if (this.$v.entity) {
        // From route view
        return this.$v.entity;
      } else {
        // From component tab
        return this.$v;
      }
    },
    $v: function $v() {
      return this.$vv;
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    selectedDOBDate: function selectedDOBDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.profile.dob = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.profile.dob = null;
      }
    }
  },
  created: function created() {
    this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_14___default()(this.value);
    if (this.innerValue.profile.dob) {
      this.selectedDOBDate = new Date("".concat(this.innerValue.profile.dob));
    }
    this.address = {
      type: '0',
      address1: '',
      suburbText: '',
      stateCode: '',
      suburbPostcode: '',
      countryText: ''
    };
    this.getCompanyDropdown();
    // this.innerValue.profile.assetAddresses = this.activeAddresses
  },
  mounted: function mounted() {
    var _this = this;
    this.$on('refreshProfile', function (newEntity) {
      _this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_14___default()(newEntity);
    });
    // Touch validation for addresses, phones, emails
    if (this.$v.entity) {
      if (this.$v.entity.addresses) {
        this.$v.entity.addresses.$touch();
      }
      if (this.$v.entity.phones) {
        this.$v.entity.phones.$touch();
      }
      if (this.$v.entity.emails) {
        this.$v.entity.emails.$touch();
      }
      this.$v.profileAddressesGroup.$touch();
      this.$v.profilePhonesGroup.$touch();
      this.$v.profileEmailsGroup.$touch();
    }
  },
  methods: {
    dobDateInputEvent: function dobDateInputEvent(event) {
      this.selectedDOBDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    getCompanyDropdown: function getCompanyDropdown() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this2.isCompaniesLoading = true;
              _context.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_16__["CompanyService"].getAllCompanies();
            case 1:
              _this2.companies = _context.v;
              if (_this2.innerValue.profile.companyId !== _components_Guid__WEBPACK_IMPORTED_MODULE_19__["default"].empty()) {
                _this2.selectedCompany = _this2.companies.find(function (c) {
                  return c.companyId === _this2.innerValue.profile.companyId;
                });
              }
              _this2.isCompaniesLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    removeAddress: function removeAddress(address) {
      var idx = this.innerValue.profile.assetAddresses.findIndex(function (a) {
        return a === address;
      });
      if (idx !== -1) {
        if (!address.isNew && address.id) {
          this.innerValue.profile.assetAddresses[idx].isDeleted = true;
        } else {
          this.innerValue.profile.assetAddresses.splice(idx, 1);
        }
      }
    },
    removePhone: function removePhone(phone) {
      var idx = this.innerValue.profile.assetPhones.findIndex(function (a) {
        return a === phone;
      });
      if (idx !== -1) {
        if (!phone.isNew && phone.id) {
          this.innerValue.profile.assetPhones[idx].isDeleted = true;
        } else {
          this.innerValue.profile.assetPhones.splice(idx, 1);
        }
      }
    },
    removeEmail: function removeEmail(email) {
      var idx = this.innerValue.profile.assetEmails.findIndex(function (a) {
        return a === email;
      });
      if (idx !== -1) {
        if (!email.isNew && email.id) {
          this.innerValue.profile.assetEmails[idx].isDeleted = true;
        } else {
          this.innerValue.profile.assetEmails.splice(idx, 1);
        }
      }
    },
    setDefault: function setDefault(asset, assetType) {
      this.innerValue.profile[assetType].forEach(function (a) {
        return a.isDefault = a == asset;
      });
    },
    addTmpAddress: function addTmpAddress() {
      var newAddress = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__["AddressModel"](this.innerValue.profile.companyId);
      if (this.innerValue.profile.assetAddresses.length == 0) {
        newAddress.isDefault = true;
      }
      this.innerValue.profile.assetAddresses.push(newAddress);
    },
    addTmpPhone: function addTmpPhone() {
      var newPhone = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__["PhoneModel"]();
      if (this.innerValue.profile.assetPhones.length == 0) {
        newPhone.isDefault = true;
      }
      this.innerValue.profile.assetPhones.push(newPhone);
    },
    addTmpEmail: function addTmpEmail() {
      var newEmail = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__["EmailModel"]();
      if (this.innerValue.profile.assetEmails.length == 0) {
        newEmail.isDefault = true;
      }
      this.innerValue.profile.assetEmails.push(newEmail);
    },
    addContact: function addContact(newContact) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this3.innerValue.profile.contacts.push(newContact);
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    removeContact: function removeContact(contact) {
      var idx = this.innerValue.profile.contacts.findIndex(function (c) {
        return c.id === contact.id;
      });
      if (idx !== -1) {
        if (!contact.isNew && contact.id) {
          this.innerValue.profile.contacts[idx].isDeleted = true;
          this.innerValue.profile.contacts[idx].contact.isActive = false;
        } else {
          this.innerValue.profile.contacts.splice(idx, 1);
        }
      }
    },
    updateContacts: function updateContacts(updatedContacts) {
      this.innerValue.profile.contacts = updatedContacts;
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../enums */ "./src/enums/index.js");
/* harmony import */ var _UserAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./UserAssetAddresses.vue */ "./src/views/user/assets/UserAssetAddresses.vue");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _UserAssetPhones_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./UserAssetPhones.vue */ "./src/views/user/assets/UserAssetPhones.vue");
/* harmony import */ var _UserAssetEmails_vue__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./UserAssetEmails.vue */ "./src/views/user/assets/UserAssetEmails.vue");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var _views_recurringremarks_RecurringRemarkModal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/views/recurringremarks/RecurringRemarkModal */ "./src/views/recurringremarks/RecurringRemarkModal.vue");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__);




















var RecurringRemarkComponent = vue__WEBPACK_IMPORTED_MODULE_17__["default"].extend(_views_recurringremarks_RecurringRemarkModal__WEBPACK_IMPORTED_MODULE_18__["default"]);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ContactModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__["BaseModalEx"],
    UserAssetAddresses: _UserAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    UserAssetPhones: _UserAssetPhones_vue__WEBPACK_IMPORTED_MODULE_15__["default"],
    UserAssetEmails: _UserAssetEmails_vue__WEBPACK_IMPORTED_MODULE_16__["default"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    contact: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    return {
      cardModal: null,
      refsHasError: false
    };
  },
  computed: {
    salutes: function salutes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["Salutation"];
    },
    sortedAddresses: function sortedAddresses() {
      if (this.contact && this.contact.contact.addresses) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.contact.addresses).sort(function (a, b) {
          return b.isDefault - a.isDefault;
        });
      }
    },
    validationErrors: function validationErrors() {
      return this.$v.contact.contact.$error || this.$refs.addresses && this.$refs.addresses.$v && this.$refs.addresses.$v.$error || this.$refs.phones && this.$refs.phones.$v && this.$refs.phones.$v.$error || this.$refs.emails && this.$refs.emails.$v && this.$refs.emails.$v.$error || this.refsHasError;
    },
    activeAddresses: function activeAddresses() {
      if (this.contact && this.contact.contact.addresses) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.contact.addresses).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    activePhones: function activePhones() {
      if (this.contact && this.contact.contact.phones) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.contact.phones).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    activeEmails: function activeEmails() {
      if (this.contact && this.contact.contact.emails) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.contact.emails).filter(function (a) {
          return !a.isDeleted;
        });
      }
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    close: function close() {
      this.$emit('close');
    },
    save: function save() {
      this.$emit('save', this.contact);
    },
    setDefault: function setDefault(asset, assetType) {
      this.contact.contact[assetType].forEach(function (a) {
        return a.isDefault = a == asset;
      });
    },
    addTmpAddress: function addTmpAddress() {
      var newAddress = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["AddressModel"](this.contact.companyId);
      if (this.contact.contact.addresses.length == 0) {
        newAddress.isDefault = true;
      }
      this.contact.contact.addresses.push(newAddress);
    },
    addTmpPhone: function addTmpPhone() {
      var newPhone = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["PhoneModel"]();
      if (this.contact.contact.phones.length == 0) {
        newPhone.isDefault = true;
      }
      this.contact.contact.phones.push(newPhone);
    },
    addTmpEmail: function addTmpEmail() {
      var newEmail = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["EmailModel"]();
      if (this.contact.contact.emails.length == 0) {
        newEmail.isDefault = true;
      }
      this.contact.contact.emails.push(newEmail);
    },
    removeAddress: function removeAddress(address) {
      // this.contact.contact.addresses = this.contact.contact.addresses.filter((a) => a !== address)
      var idx = this.contact.contact.addresses.findIndex(function (a) {
        return a === address;
      });
      if (idx !== -1) {
        if (!address.isNew && address.id) {
          this.contact.contact.addresses[idx].isDeleted = true;
        } else {
          this.contact.contact.addresses.splice(idx, 1);
        }
      }
    },
    removePhone: function removePhone(phone) {
      //this.contact.contact.phones = this.contact.contact.phones.filter((p) => p !== phone)
      var idx = this.contact.contact.phones.findIndex(function (a) {
        return a === phone;
      });
      if (idx !== -1) {
        if (!phone.isNew && phone.id) {
          this.contact.contact.phones[idx].isDeleted = true;
        } else {
          this.contact.contact.phones.splice(idx, 1);
        }
      }
    },
    removeEmail: function removeEmail(email) {
      // this.contact.contact.emails = this.contact.contact.emails.filter((e) => e !== email)
      var idx = this.contact.contact.emails.findIndex(function (a) {
        return a === email;
      });
      if (idx !== -1) {
        if (!email.isNew && email.id) {
          this.contact.contact.emails[idx].isDeleted = true;
        } else {
          this.contact.contact.emails.splice(idx, 1);
        }
      }
    },
    showRecurringRemark: function showRecurringRemark() {
      var _this = this;
      this.cardModal = new RecurringRemarkComponent({
        el: document.createElement('div'),
        propsData: {
          visible: false
        }
      }).$on('ok', function (res) {
        _this.contact.contact.remarks.remarks = res + '\n' + _this.contact.contact.remarks.remarks;
        _this.contact.contact.remarks.isDirty = true;
      });
      this.cardModal.visible = true;
    },
    onRefsValidationChanged: function onRefsValidationChanged(hasError) {
      this.refsHasError = hasError;
    }
  },
  validations: function validations() {
    return {
      contact: {
        contact: {
          firstName: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
          },
          lastName: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
          }
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_Address_GoogleAutocomplete__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/Address/GoogleAutocomplete */ "./src/components/Address/GoogleAutocomplete.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");


















// import UserValidation from '../UserValidation.js'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserAssetAddresses',
  components: {
    GoogleAutocomplete: _components_Address_GoogleAutocomplete__WEBPACK_IMPORTED_MODULE_16__["default"]
  },
  props: {
    addresses: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    countryCode: {
      type: String | null,
      default: undefined
    },
    required: {
      type: Boolean,
      default: false
    },
    assetTypeName: {
      type: String | null,
      default: 'assetAddresses'
    }
  },
  data: function data() {
    return {
      googleApi: {
        mapUrl: 'https://maps.googleapis.com/maps/api/js',
        mapKey: "AIzaSyCK26bFvsJ1lo1dZ10WBFXA74yU-pc7CuI",
        mapLibraries: 'places',
        mapCallback: 'initMap',
        mapStatus: null,
        bounds: null
      }
    };
  },
  computed: {
    addressTypes: function addressTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_17__["AddressTypes"];
    },
    existedAddressTypes: function existedAddressTypes() {
      return this.addresses.map(function (address) {
        return address.type;
      });
    },
    googleMapAutoCompleteCountryCode: function googleMapAutoCompleteCountryCode() {
      if (this.countryCode) {
        return this.countryCode;
      }
      return this.$company.info.countryCode;
    }
  },
  watch: {
    addresses: {
      handler: function handler() {
        this.$emit('validationChanged', this.hasAnyValidationError());
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  created: function created() {
    this.initGoogleMapApi();
  },
  methods: {
    addTmpAddress: function addTmpAddress() {
      this.$emit('addTmpAddress');
    },
    initGoogleMapApi: function initGoogleMapApi() {
      var vm = this;
      window.initMap = function () {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function (position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new window.google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            vm.googleApi.bounds = circle.getBounds();
          });
        }
        vm.googleApi.mapStatus = 'AddressDetail';
      };
      if (!window.google) {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = "".concat(this.googleApi.mapUrl, "?key=").concat(this.googleApi.mapKey, "&libraries=").concat(this.googleApi.mapLibraries, "&callback=").concat(this.googleApi.mapCallback);
        document.body.appendChild(script);
      } else {
        window.initMap();
      }
    },
    removeAddress: function removeAddress(assetAddress) {
      this.$emit('removeAddress', assetAddress);
    },
    setDefault: function setDefault(assetAddress) {
      this.$emit('setDefault', assetAddress, this.assetTypeName);
    },
    hasAnyValidationError: function hasAnyValidationError() {
      return this.$v.$error || !this.$v.uniqueAddressType || this.$v.addresses.$error;
    }
  },
  validations: function validations() {
    var _this = this;
    // const baseValidations = UserValidation.validations.entity || {}
    // const addressValidations = this.required
    //   ? {
    //       ...addresses
    //     }
    //   : {
    //       ...baseValidations
    //     }

    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_18__["default"]), {}, {
      uniqueAddressType: function uniqueAddressType() {
        return new Set(_this.existedAddressTypes).size == _this.existedAddressTypes.length;
      }
    });
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../UserValidation.js */ "./src/views/user/UserValidation.js");
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserAssetEmails',
  props: {
    emails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    required: {
      type: Boolean,
      default: false
    },
    assetTypeName: {
      type: String | null,
      default: 'assetEmails'
    }
  },
  computed: {
    emailTypes: function emailTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["EmailTypes"];
    },
    existedEmailTypes: function existedEmailTypes() {
      return this.emails.map(function (email) {
        return email.type;
      });
    }
  },
  watch: {
    emails: {
      handler: function handler() {
        this.$emit('validationChanged', this.hasAnyValidationError());
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addTmpEmail: function addTmpEmail() {
      this.$emit('addTmpEmail');
    },
    removeEmail: function removeEmail(assetEmail) {
      this.$emit('removeEmail', assetEmail);
    },
    setDefault: function setDefault(assetEmail) {
      this.$emit('setDefault', assetEmail, this.assetTypeName);
    },
    hasAnyValidationError: function hasAnyValidationError() {
      return this.$v.$error || !this.$v.uniqueEmailType || this.$v.emails.$error;
    }
  },
  validations: function validations() {
    var _this = this;
    var baseValidations = _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__["default"].validations.entity || {};
    var emailValidations = this.required ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_17__["default"]) : Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, baseValidations);
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, emailValidations), {}, {
      uniqueEmailType: function uniqueEmailType() {
        return new Set(_this.existedEmailTypes).size == _this.existedEmailTypes.length;
      }
    });
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../UserValidation.js */ "./src/views/user/UserValidation.js");
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserAssetPhones',
  props: {
    phones: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    required: {
      type: Boolean,
      default: false
    },
    assetTypeName: {
      type: String | null,
      default: 'assetPhones'
    }
  },
  computed: {
    phoneTypes: function phoneTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["PhoneTypes"];
    },
    existedPhoneTypes: function existedPhoneTypes() {
      return this.phones.map(function (phone) {
        return phone.type;
      });
    }
  },
  watch: {
    phones: {
      handler: function handler() {
        this.$emit('validationChanged', this.hasAnyValidationError());
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addTmpPhone: function addTmpPhone() {
      this.$emit('addTmpPhone');
    },
    removePhone: function removePhone(assetPhone) {
      this.$emit('removePhone', assetPhone);
    },
    setDefault: function setDefault(assetPhone) {
      this.$emit('setDefault', assetPhone, this.assetTypeName);
    },
    hasAnyValidationError: function hasAnyValidationError() {
      return this.$v.$error || !this.$v.uniquePhoneType || this.$v.phones.$error;
    }
  },
  validations: function validations() {
    var _this = this;
    var baseValidations = _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__["default"].validations.entity || {};
    var phoneValidations = this.required ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_17__["default"]) : Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, baseValidations);
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, phoneValidations), {}, {
      uniquePhoneType: function uniquePhoneType() {
        return new Set(_this.existedPhoneTypes).size == _this.existedPhoneTypes.length;
      }
    });
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _classes_viewmodels_index_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../classes/viewmodels/index.js */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_Guid_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../components/Guid.js */ "./src/components/Guid.js");
/* harmony import */ var _contact_ContactService_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../contact/ContactService.js */ "./src/views/contact/ContactService.js");
/* harmony import */ var _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../UserValidation.js */ "./src/views/user/UserValidation.js");
/* harmony import */ var _ContactModal_vue__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ContactModal.vue */ "./src/views/user/assets/ContactModal.vue");


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserContacts',
  components: {
    ContactModal: _ContactModal_vue__WEBPACK_IMPORTED_MODULE_17__["default"]
  },
  props: {
    contacts: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    companyId: {
      type: String,
      default: null
    }
  },
  data: function data() {
    return {
      showContactModal: false,
      userContact: null,
      editingContactIndex: null
    };
  },
  computed: {},
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addContact: function addContact(contact) {
      if (this.editingContactIndex !== null) {
        this.$set(this.contacts, this.editingContactIndex, contact);
        this.editingContactIndex = null;
        this.$emit('updateContacts', Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.contacts));
      } else {
        contact.isNew = true;
        this.$emit('addContact', contact);
      }
      this.showContactModal = false;
    },
    editContact: function editContact(contact, index) {
      this.userContact = JSON.parse(JSON.stringify(contact));
      this.editingContactIndex = index;
      this.showContactModal = true;
    },
    removeContact: function removeContact(contact) {
      this.$emit('removeContact', contact);
    },
    setDefault: function setDefault(contact) {
      this.$emit('setDefault', contact, 'contacts');
      if (Array.isArray(this.contacts)) {
        this.contacts.forEach(function (c) {
          if (c === contact && c.contact) {
            if (Array.isArray(c.contact.emails)) {
              c.contact.emails.forEach(function (email, idx) {
                email.isDefault = idx === 0;
              });
            }
            if (Array.isArray(c.contact.addresses)) {
              c.contact.addresses.forEach(function (address, idx) {
                address.isDefault = idx === 0;
              });
            }
            if (Array.isArray(c.contact.phones)) {
              c.contact.phones.forEach(function (phone, idx) {
                phone.isDefault = idx === 0;
              });
            }
          } else if (c.contact) {
            if (Array.isArray(c.contact.emails)) {
              c.contact.emails.forEach(function (email) {
                email.isDefault = false;
              });
            }
            if (Array.isArray(c.contact.addresses)) {
              c.contact.addresses.forEach(function (address) {
                address.isDefault = false;
              });
            }
            if (Array.isArray(c.contact.phones)) {
              c.contact.phones.forEach(function (phone) {
                phone.isDefault = false;
              });
            }
          }
        });
      }
    },
    addNewContact: function addNewContact() {
      var _this = this;
      _contact_ContactService_js__WEBPACK_IMPORTED_MODULE_15__["default"].getNewAssetContact('User Profile', _components_Guid_js__WEBPACK_IMPORTED_MODULE_14__["default"].newGuid()).then(function (response) {
        var newMap = response.data;
        newMap.isNew = true;
        newMap.contact.isNew = true;
        newMap.contact.addresses = [new _classes_viewmodels_index_js__WEBPACK_IMPORTED_MODULE_13__["AddressModel"](_components_Guid_js__WEBPACK_IMPORTED_MODULE_14__["default"].empty())];
        newMap.contact.phones = [new _classes_viewmodels_index_js__WEBPACK_IMPORTED_MODULE_13__["PhoneModel"]()];
        newMap.contact.emails = [new _classes_viewmodels_index_js__WEBPACK_IMPORTED_MODULE_13__["EmailModel"]()];
        if (_this.$parent && _this.$parent.innerValue && _this.$parent.innerValue.profile && _this.contacts.length == 0) {
          if (_this.$parent.innerValue.profile.salutation) {
            newMap.contact.title = _this.$parent.innerValue.profile.salutation;
          }
          if (_this.$parent.innerValue.profile.firstName) {
            newMap.contact.firstName = _this.$parent.innerValue.profile.firstName;
          }
          if (_this.$parent.innerValue.profile.lastName) {
            newMap.contact.lastName = _this.$parent.innerValue.profile.lastName;
          }
          if (Array.isArray(_this.$parent.innerValue.profile.assetAddresses)) {
            var defaultAddress = _this.$parent.innerValue.profile.assetAddresses.find(function (a) {
              return a.isDefault;
            });
            if (defaultAddress) {
              newMap.contact.addresses = [JSON.parse(JSON.stringify(defaultAddress))];
              newMap.contact.addresses[0].isDefault = true;
              newMap.contact.addresses[0].isNew = true;
              newMap.contact.addresses[0].id = _components_Guid_js__WEBPACK_IMPORTED_MODULE_14__["default"].empty();
            }
          }
          if (Array.isArray(_this.$parent.innerValue.profile.assetPhones)) {
            var defaultPhone = _this.$parent.innerValue.profile.assetPhones.find(function (a) {
              return a.isDefault;
            });
            if (defaultPhone) {
              newMap.contact.phones = [JSON.parse(JSON.stringify(defaultPhone))];
              newMap.contact.phones[0].isDefault = true;
              newMap.contact.phones[0].isNew = true;
              newMap.contact.phones[0].id = _components_Guid_js__WEBPACK_IMPORTED_MODULE_14__["default"].empty();
            }
          }
          if (Array.isArray(_this.$parent.innerValue.profile.assetEmails)) {
            var defaultEmail = _this.$parent.innerValue.profile.assetEmails.find(function (a) {
              return a.isDefault;
            });
            if (defaultEmail) {
              newMap.contact.emails = [JSON.parse(JSON.stringify(defaultEmail))];
              newMap.contact.emails[0].isDefault = true;
              newMap.contact.emails[0].isNew = true;
              newMap.contact.emails[0].id = _components_Guid_js__WEBPACK_IMPORTED_MODULE_14__["default"].empty();
            }
          }
        }
        var anyDefault = _this.contacts.find(function (d) {
          return !d.isDeleted && d.isDefault;
        });
        if (!anyDefault) {
          newMap.isDefault = true;
        }
        _this.userContact = newMap;
        _this.userContact.companyId = _this.companyId;
      });
      this.showContactModal = true;
    },
    addTmpAddress: function addTmpAddress() {
      var newAddress = new _classes_viewmodels_index_js__WEBPACK_IMPORTED_MODULE_13__["AddressModel"](this.companyId);
      if (this.userContact.contact.addresses.length == 0) {
        newAddress.isDefault = true;
      }
      this.userContact.contact.addresses.push(newAddress);
    },
    removeAddress: function removeAddress(address) {
      this.userContact.contact.addresses = this.userContact.contact.addresses.filter(function (a) {
        return a !== address;
      });
    }
  },
  validations: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _UserValidation_js__WEBPACK_IMPORTED_MODULE_16__["default"].validations.entity)
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242 ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("card-modal", {
    attrs: {
      visible: _vm.visible,
      title: "Recurring Remarks"
    },
    on: {
      ok: _vm.ok,
      close: _vm.close,
      cancel: _vm.cancel
    }
  }, [_c("div", {
    staticClass: "content",
    staticStyle: {
      height: "10em",
      overflow: "hidden"
    }
  }, [_c("div", {
    staticClass: "field"
  }, [_c("p", {
    staticClass: "control is-expanded"
  }, [_c("bulma-autocomplete", {
    ref: "searcher",
    attrs: {
      id: "searcher",
      data: _vm.options,
      loading: _vm.isLoading
    },
    on: {
      input: _vm.search,
      select: _vm.select
    },
    model: {
      value: _vm.searchValue,
      callback: function callback($$v) {
        _vm.searchValue = $$v;
      },
      expression: "searchValue"
    }
  }), _c("span", {
    staticClass: "help is-info"
  }, [_vm._v(_vm._s(_vm.message))])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserProfile.vue?vue&type=template&id=49f29214":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserProfile.vue?vue&type=template&id=49f29214 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(0), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Company")]), _c("div", {
    staticClass: "control"
  }, [_c("multiselect", {
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "companyId",
      label: "name",
      placeholder: "Search By Name...",
      options: _vm.companies,
      loading: _vm.isCompaniesLoading,
      "internal-search": false,
      searchable: true,
      "show-labels": false,
      "allow-empty": true,
      disabled: true
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", [_vm._v(_vm._s(props.option.name))])];
      }
    }]),
    model: {
      value: _vm.selectedCompany,
      callback: function callback($$v) {
        _vm.selectedCompany = $$v;
      },
      expression: "selectedCompany"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Company not found.")])])], 1)]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Salutation")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.profile.salutation,
      expression: "value.profile.salutation"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value.profile, "salutation", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.salutes, function (name, code) {
    return _c("option", {
      key: code,
      domProps: {
        value: name
      }
    }, [_vm._v(" " + _vm._s(name) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("First Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.trim",
      value: _vm.value.profile.firstName,
      expression: "value.profile.firstName",
      modifiers: {
        trim: true
      }
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$vv.entity.profile.firstName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.value.profile.firstName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.profile, "firstName", $event.target.value.trim());
      },
      blur: function blur($event) {
        return _vm.$forceUpdate();
      }
    }
  }), !_vm.$vv.entity.profile.firstName.isPersonName ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("First Name cannot contain special characters ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Last Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.trim",
      value: _vm.value.profile.lastName,
      expression: "value.profile.lastName",
      modifiers: {
        trim: true
      }
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$vv.entity.profile.lastName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.value.profile.lastName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.profile, "lastName", $event.target.value.trim());
      },
      blur: function blur($event) {
        return _vm.$forceUpdate();
      }
    }
  }), !_vm.$vv.entity.profile.lastName.isPersonName ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Last Name cannot contain special characters ")]) : _vm._e()])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Display Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.trim",
      value: _vm.value.profile.displayName,
      expression: "value.profile.displayName",
      modifiers: {
        trim: true
      }
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$vv.entity.profile.displayName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.value.profile.displayName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.profile, "displayName", $event.target.value.trim());
      },
      blur: function blur($event) {
        return _vm.$forceUpdate();
      }
    }
  }), !_vm.$vv.entity.profile.displayName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Display Name is required ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Gender")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.profile.sex,
      expression: "value.profile.sex"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value.profile, "sex", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.sex, function (name, code) {
    return _c("option", {
      key: code,
      domProps: {
        value: code
      }
    }, [_vm._v(" " + _vm._s(name) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Date of Birth")]), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.dobDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Date of Birth",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("span", {
          staticClass: "mso mso-18px"
        }, [_vm._v(" event ")])])])])];
      }
    }]),
    model: {
      value: _vm.selectedDOBDate,
      callback: function callback($$v) {
        _vm.selectedDOBDate = $$v;
      },
      expression: "selectedDOBDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-addresses", {
    ref: "assetAddresses",
    attrs: {
      addresses: _vm.activeAddresses,
      "country-code": _vm.countryCode,
      required: false
    },
    on: {
      removeAddress: _vm.removeAddress,
      setDefault: _vm.setDefault,
      addTmpAddress: _vm.addTmpAddress
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-phones", {
    ref: "assetPhones",
    attrs: {
      phones: _vm.activePhones,
      required: false
    },
    on: {
      removePhone: _vm.removePhone,
      setDefault: _vm.setDefault,
      addTmpPhone: _vm.addTmpPhone
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-emails", {
    ref: "assetEmails",
    attrs: {
      emails: _vm.activeEmails,
      required: false
    },
    on: {
      removeEmail: _vm.removeEmail,
      setDefault: _vm.setDefault,
      addTmpEmail: _vm.addTmpEmail
    }
  })], 1), _c("div", {
    staticClass: "field columns mb-2"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("user-contacts", {
    ref: "userContacts",
    attrs: {
      contacts: _vm.activeContacts,
      "company-id": _vm.innerValue.profile.companyId
    },
    on: {
      addContact: _vm.addContact,
      setDefault: _vm.setDefault,
      removeContact: _vm.removeContact,
      updateContacts: _vm.updateContacts
    }
  })], 1)])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Profile")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622 ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm$sortedAddresses$c, _vm$sortedAddresses;
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.active,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 80,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.active = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Contacts")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-two-thirds"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Title")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.contact.title,
      expression: "contact.contact.title"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.contact.contact, "title", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.salutes, function (name, code) {
    return _c("option", {
      key: code,
      domProps: {
        value: name
      }
    }, [_vm._v(" " + _vm._s(name) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("First Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.contact.firstName,
      expression: "contact.contact.firstName"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.contact.contact.firstName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.contact.contact.firstName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact.contact, "firstName", $event.target.value);
      }, function ($event) {
        return _vm.$v.contact.contact.firstName.$touch();
      }]
    }
  }), !_vm.$v.contact.contact.firstName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("First Name is required")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Last Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.contact.lastName,
      expression: "contact.contact.lastName"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.contact.contact.lastName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.contact.contact.lastName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact.contact, "lastName", $event.target.value);
      }, function ($event) {
        return _vm.$v.contact.contact.lastName.$touch();
      }]
    }
  }), !_vm.$v.contact.contact.lastName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Last Name is required")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-addresses", {
    ref: "addresses",
    attrs: {
      addresses: _vm.activeAddresses,
      "country-code": (_vm$sortedAddresses$c = (_vm$sortedAddresses = _vm.sortedAddresses) === null || _vm$sortedAddresses === void 0 ? void 0 : _vm$sortedAddresses.countryCode) !== null && _vm$sortedAddresses$c !== void 0 ? _vm$sortedAddresses$c : null,
      required: true,
      "asset-type-name": "addresses"
    },
    on: {
      removeAddress: _vm.removeAddress,
      setDefault: _vm.setDefault,
      addTmpAddress: _vm.addTmpAddress,
      validationChanged: _vm.onRefsValidationChanged
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-phones", {
    ref: "phones",
    attrs: {
      phones: _vm.activePhones,
      required: true,
      "asset-type-name": "phones"
    },
    on: {
      removePhone: _vm.removePhone,
      setDefault: _vm.setDefault,
      addTmpPhone: _vm.addTmpPhone,
      validationChanged: _vm.onRefsValidationChanged
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("user-asset-emails", {
    ref: "emails",
    attrs: {
      emails: _vm.activeEmails,
      required: true,
      "asset-type-name": "emails"
    },
    on: {
      removeEmail: _vm.removeEmail,
      setDefault: _vm.setDefault,
      addTmpEmail: _vm.addTmpEmail,
      validationChanged: _vm.onRefsValidationChanged
    }
  })], 1)]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Contents")]), _c("p", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.contact.remarks.remarks,
      expression: "contact.contact.remarks.remarks"
    }],
    staticClass: "textarea",
    domProps: {
      value: _vm.contact.contact.remarks.remarks
    },
    on: {
      change: function change($event) {
        _vm.contact.contact.isDirty = true;
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact.contact.remarks, "remarks", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary",
    on: {
      click: _vm.showRecurringRemark
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-repeat"
  })]), _c("span", [_vm._v(" Recurring Remarks")])])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Alert?")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.contact.remarks.isAlert,
      expression: "contact.contact.remarks.isAlert"
    }],
    staticClass: "switch is-rounded",
    attrs: {
      id: "alert",
      name: "alert",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.contact.contact.remarks.isAlert) ? _vm._i(_vm.contact.contact.remarks.isAlert, null) > -1 : _vm.contact.contact.remarks.isAlert
    },
    on: {
      change: function change($event) {
        var $$a = _vm.contact.contact.remarks.isAlert,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.contact.contact.remarks, "isAlert", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.contact.contact.remarks, "isAlert", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.contact.contact.remarks, "isAlert", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "alert"
    }
  })])])])])]), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Save",
      disabled: _vm.validationErrors
    },
    on: {
      click: _vm.save
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px mso-fill"
  }, [_vm._v(" save ")])]), _c("span", [_vm._v("Save")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: _vm.close
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px"
  }, [_vm._v(" close ")])]), _c("span", [_vm._v("Cancel")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Addresses")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.addresses.length < 3,
      expression: "addresses.length < 3"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    on: {
      click: _vm.addTmpAddress
    }
  }, [_vm._m(0)])]), _vm._l(_vm.addresses, function (address, index) {
    return _c("div", {
      key: index,
      staticClass: "pb-4"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("p", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: address.type,
        expression: "address.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: _vm.$v.uniqueAddressType !== undefined && !_vm.$v.uniqueAddressType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: $v.uniqueAddressType !== undefined && !$v.uniqueAddressType }"
      }],
      class: {
        "is-invalid": _vm.$v.uniqueAddressType !== undefined && !_vm.$v.uniqueAddressType
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(address, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.addressTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: typeIndex
        }
      }, [_vm._v(" " + _vm._s(type) + " ")]);
    }), 0)])]), _c("p", {
      staticClass: "control is-expanded"
    }, [_vm.googleApi.mapStatus ? _c("google-autocomplete", {
      attrs: {
        bounds: _vm.googleApi.bounds,
        id: "address" + index,
        address: address,
        v: _vm.$v.addresses.$each[index],
        "show-address3": true,
        "country-code": _vm.googleMapAutoCompleteCountryCode
      }
    }) : _vm._e()], 1), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      on: {
        click: function click($event) {
          return _vm.setDefault(address);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [address.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      on: {
        click: function click($event) {
          return _vm.removeAddress(address);
        }
      }
    }, [_vm._m(1, true)])])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" delete ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Emails")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.emails.length < 2,
      expression: "emails.length < 2"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    on: {
      click: _vm.addTmpEmail
    }
  }, [_vm._m(0)])]), _vm._l(_vm.emails, function (assetEmail, index) {
    return _c("div", {
      key: index,
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetEmail.type,
        expression: "assetEmail.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: !_vm.$v.uniqueEmailType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: !$v.uniqueEmailType }"
      }],
      class: {
        "is-invalid": !_vm.$v.uniqueEmailType
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(assetEmail, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.emailTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: type.toString()
        },
        on: {
          change: function change($event) {
            return _vm.$v.emails.types.touch();
          }
        }
      }, [_vm._v(" " + _vm._s(typeIndex) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetEmail.address,
        expression: "assetEmail.address"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.emails.$each[index].address.$error
      },
      attrs: {
        type: "text"
      },
      domProps: {
        value: assetEmail.address
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(assetEmail, "address", $event.target.value);
        }, function ($event) {
          return _vm.$v.emails.$each[index].address.$touch();
        }]
      }
    }), !_vm.$v.emails.$each[index].address.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Email is required")]) : _vm._e(), !_vm.$v.emails.$each[index].address.email ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Please enter a valid email")]) : _vm._e()]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        title: [assetEmail.isDefault ? "Default Email" : ""],
        disabled: _vm.emails.length == 1 && assetEmail.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(assetEmail);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [assetEmail.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      attrs: {
        disabled: assetEmail.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.removeEmail(assetEmail);
        }
      }
    }, [_vm._m(1, true)])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" delete ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Phones")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.phones.length < 4,
      expression: "phones.length < 4"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    on: {
      click: _vm.addTmpPhone
    }
  }, [_vm._m(0)])]), _vm._l(_vm.phones, function (assetPhone, index) {
    return _c("div", {
      key: index,
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetPhone.type,
        expression: "assetPhone.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: !_vm.$v.uniquePhoneType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: !$v.uniquePhoneType }"
      }],
      class: {
        "is-invalid": !_vm.$v.uniquePhoneType
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(assetPhone, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.phoneTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: type.toString()
        },
        on: {
          change: function change($event) {
            return _vm.$v.phones.types.touch();
          }
        }
      }, [_vm._v(" " + _vm._s(typeIndex) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetPhone.no,
        expression: "assetPhone.no"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.phones.$each[index].no.$error
      },
      attrs: {
        type: "text"
      },
      domProps: {
        value: assetPhone.no
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(assetPhone, "no", $event.target.value);
        }, function ($event) {
          return _vm.$v.phones.$each[index].no.$touch();
        }]
      }
    }), !_vm.$v.phones.$each[index].no.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Phone number is required ")]) : _vm._e()]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        title: [assetPhone.isDefault ? "Default Phone" : ""]
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(assetPhone);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [assetPhone.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      on: {
        click: function click($event) {
          return _vm.removePhone(assetPhone);
        }
      }
    }, [_vm._m(1, true)])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" delete ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm$contacts;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Contact Person")]), _c("button", {
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    on: {
      click: _vm.addNewContact
    }
  }, [_vm._m(0)]), _vm.userContact ? _c("ContactModal", {
    attrs: {
      active: _vm.showContactModal,
      contact: _vm.userContact
    },
    on: {
      close: function close($event) {
        _vm.showContactModal = false;
      },
      save: _vm.addContact
    }
  }) : _vm._e()], 1), _vm.contacts && ((_vm$contacts = _vm.contacts) === null || _vm$contacts === void 0 ? void 0 : _vm$contacts.length) > 0 ? _c("div", [_vm._m(1), _vm._l(_vm.contacts, function (contact, index) {
    return _c("div", {
      key: index,
      staticClass: "field columns is-flex is-align-items-center"
    }, [_c("div", {
      staticClass: "column is-half"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: contact.contact.firstName,
        expression: "contact.contact.firstName"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.contacts.$each[index].contact.firstName.$error
      },
      attrs: {
        type: "text",
        placeholder: "First Name"
      },
      domProps: {
        value: contact.contact.firstName
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(contact.contact, "firstName", $event.target.value);
        }, function ($event) {
          return _vm.$v.contacts.$each[index].contact.firstName.$touch();
        }]
      }
    }), !_vm.$v.contacts.$each[index].contact.firstName.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("First Name is required ")]) : _vm._e()])]), _c("div", {
      staticClass: "field has-addons column is-half"
    }, [_c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: contact.contact.lastName,
        expression: "contact.contact.lastName"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.contacts.$each[index].contact.lastName.$error
      },
      attrs: {
        type: "text",
        placeholder: "Last Name"
      },
      domProps: {
        value: contact.contact.lastName
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(contact.contact, "lastName", $event.target.value);
        }, function ($event) {
          return _vm.$v.contacts.$each[index].contact.lastName.$touch();
        }]
      }
    }), !_vm.$v.contacts.$each[index].contact.lastName.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Last Name is required ")]) : _vm._e()]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      on: {
        click: function click($event) {
          return _vm.setDefault(contact, "contacts");
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [contact.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-primary",
      on: {
        click: function click($event) {
          return _vm.editContact(contact, index);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [contact.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" edit ")])])])]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      on: {
        click: function click($event) {
          return _vm.removeContact(contact);
        }
      }
    }, [_vm._m(2, true)])])])]);
  })], 2) : _c("div", {
    staticClass: "label has-text-weight-normal ml-1"
  }, [_vm._v("No Contacts")])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field columns mb-0"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("First Name")])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Last Name")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" remove ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-invalid[data-v-68a5bf40] {\n  background-color: pink !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/_baseTrim.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_baseTrim.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var trimmedEndIndex = __webpack_require__(/*! ./_trimmedEndIndex */ "./node_modules/lodash/_trimmedEndIndex.js");

/** Used to match leading whitespace. */
var reTrimStart = /^\s+/;

/**
 * The base implementation of `_.trim`.
 *
 * @private
 * @param {string} string The string to trim.
 * @returns {string} Returns the trimmed string.
 */
function baseTrim(string) {
  return string
    ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, '')
    : string;
}

module.exports = baseTrim;


/***/ }),

/***/ "./node_modules/lodash/_trimmedEndIndex.js":
/*!*************************************************!*\
  !*** ./node_modules/lodash/_trimmedEndIndex.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to match a single whitespace character. */
var reWhitespace = /\s/;

/**
 * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
 * character of `string`.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {number} Returns the index of the last non-whitespace character.
 */
function trimmedEndIndex(string) {
  var index = string.length;

  while (index-- && reWhitespace.test(string.charAt(index))) {}
  return index;
}

module.exports = trimmedEndIndex;


/***/ }),

/***/ "./node_modules/lodash/debounce.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/debounce.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    now = __webpack_require__(/*! ./now */ "./node_modules/lodash/now.js"),
    toNumber = __webpack_require__(/*! ./toNumber */ "./node_modules/lodash/toNumber.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        timeWaiting = wait - timeSinceLastCall;

    return maxing
      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
      : timeWaiting;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

module.exports = debounce;


/***/ }),

/***/ "./node_modules/lodash/now.js":
/*!************************************!*\
  !*** ./node_modules/lodash/now.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

module.exports = now;


/***/ }),

/***/ "./node_modules/lodash/toNumber.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/toNumber.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseTrim = __webpack_require__(/*! ./_baseTrim */ "./node_modules/lodash/_baseTrim.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = toNumber;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3c8d4e0f", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/validateForms/Address.js":
/*!*********************************************!*\
  !*** ./src/assets/validateForms/Address.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  addresses: {
    $each: {
      address1: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbPostcode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Contacts.js":
/*!**********************************************!*\
  !*** ./src/assets/validateForms/Contacts.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _Phones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _Emails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Emails */ "./src/assets/validateForms/Emails.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  contacts: {
    $each: {
      contact: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
        firstName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        },
        lastName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        }
      }, _Address__WEBPACK_IMPORTED_MODULE_2__["default"]), _Phones__WEBPACK_IMPORTED_MODULE_3__["default"]), _Emails__WEBPACK_IMPORTED_MODULE_4__["default"])
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Emails.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Emails.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  emails: {
    $each: {
      address: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["email"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Phones.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Phones.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  phones: {
    $each: {
      no: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue":
/*!*************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RecurringRemarkModal.vue?vue&type=template&id=19fbb242 */ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242");
/* harmony import */ var _RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RecurringRemarkModal.vue?vue&type=script&lang=js */ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["render"],
  _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/recurringremarks/RecurringRemarkModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./RecurringRemarkModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242":
/*!*******************************************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242 ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./RecurringRemarkModal.vue?vue&type=template&id=19fbb242 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/UserProfile.vue":
/*!****************************************!*\
  !*** ./src/views/user/UserProfile.vue ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserProfile.vue?vue&type=template&id=49f29214 */ "./src/views/user/UserProfile.vue?vue&type=template&id=49f29214");
/* harmony import */ var _UserProfile_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserProfile.vue?vue&type=script&lang=js */ "./src/views/user/UserProfile.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserProfile_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/UserProfile.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/UserProfile.vue?vue&type=script&lang=js":
/*!****************************************************************!*\
  !*** ./src/views/user/UserProfile.vue?vue&type=script&lang=js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserProfile_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserProfile.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserProfile.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserProfile_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/UserProfile.vue?vue&type=template&id=49f29214":
/*!**********************************************************************!*\
  !*** ./src/views/user/UserProfile.vue?vue&type=template&id=49f29214 ***!
  \**********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserProfile.vue?vue&type=template&id=49f29214 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserProfile.vue?vue&type=template&id=49f29214");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserProfile_vue_vue_type_template_id_49f29214__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/UserValidation.js":
/*!******************************************!*\
  !*** ./src/views/user/UserValidation.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/assets/validateForms/Contacts */ "./src/assets/validateForms/Contacts.js");
/* harmony import */ var _services_UserService__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/services/UserService */ "./src/services/UserService.js");
/* harmony import */ var _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/utils/PersonNameFunctions */ "./src/utils/PersonNameFunctions.js");


























var isUniqueUsername = /*#__PURE__*/function () {
  var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee(value) {
    var isNotUnique, _t;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          if (value) {
            _context.n = 1;
            break;
          }
          return _context.a(2, true);
        case 1:
          _context.p = 1;
          _context.n = 2;
          return _services_UserService__WEBPACK_IMPORTED_MODULE_24__["default"].checkUsernameValidity(value, this.entity.userId);
        case 2:
          isNotUnique = _context.v;
          return _context.a(2, !isNotUnique);
        case 3:
          _context.p = 3;
          _t = _context.v;
          return _context.a(2, false);
      }
    }, _callee, this, [[1, 3]]);
  }));
  return function isUniqueUsername(_x) {
    return _ref.apply(this, arguments);
  };
}();
var isUniqueEmail = /*#__PURE__*/function () {
  var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2(value) {
    var isUnique, _t2;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          if (value) {
            _context2.n = 1;
            break;
          }
          return _context2.a(2, true);
        case 1:
          _context2.p = 1;
          _context2.n = 2;
          return _services_UserService__WEBPACK_IMPORTED_MODULE_24__["default"].checkEmailValidity(value, this.entity.userId);
        case 2:
          isUnique = _context2.v;
          return _context2.a(2, isUnique);
        case 3:
          _context2.p = 3;
          _t2 = _context2.v;
          return _context2.a(2, false);
      }
    }, _callee2, this, [[1, 3]]);
  }));
  return function isUniqueEmail(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var requiredIfNotDeleted = Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
  return !model.isDeleted;
});
var emailIfNotDeleted = function emailIfNotDeleted(value, model) {
  if (model.isDeleted) return true;
  return Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["email"])(value);
};
var isAccessControlSelected = /*#__PURE__*/function () {
  var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3(value) {
    var _t3;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
      while (1) switch (_context3.p = _context3.n) {
        case 0:
          if (!(value.length <= 0)) {
            _context3.n = 1;
            break;
          }
          return _context3.a(2, false);
        case 1:
          _context3.p = 1;
          return _context3.a(2, value.filter(function (p) {
            return p.isBlock || p.isRead || p.isAdd || p.isEdit || p.isDelete || p.isPrint;
          }).length > 0);
        case 2:
          _context3.p = 2;
          _t3 = _context3.v;
          return _context3.a(2, false);
      }
    }, _callee3, null, [[1, 2]]);
  }));
  return function isAccessControlSelected(_x3) {
    return _ref3.apply(this, arguments);
  };
}();
var uniqueType = function uniqueType(value) {
  if (!Array.isArray(value)) return true;
  var types = value.filter(function (a) {
    return !a.isDeleted;
  }).map(function (a) {
    return a.type;
  });
  return new Set(types).size === types.length;
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.email', 'entity.username', 'entity.password', 'entity.confirmNewPassword'],
    emailsPhonesGroup: ['entity.emails', 'entity.phones'],
    addressesGroup: ['entity.addresses'],
    contactsGroup: ['entity.contacts'],
    // Save gates on group errors, so rules outside a group never block it.
    profileNameGroup: ['entity.profile.firstName', 'entity.profile.lastName', 'entity.profile.displayName'],
    profileAddressesGroup: ['entity.profile.assetAddresses'],
    profileEmailsGroup: ['entity.profile.assetEmails'],
    profilePhonesGroup: ['entity.profile.assetPhones'],
    userAccessControl: ['entity.userAccessControl'],
    entity: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      username: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"],
        isUniqueUsername: isUniqueUsername
      },
      password: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      confirmNewPassword: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      email: {
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["email"],
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"],
        isUniqueEmail: isUniqueEmail
      }
    }, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_22__["default"]), _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_21__["default"]), _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_20__["default"]), _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_23__["default"]), {}, {
      profile: {
        // Optional, but must be a name if given - isPersonName passes on blank.
        firstName: {
          isPersonName: _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__["isPersonName"]
        },
        lastName: {
          isPersonName: _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__["isPersonName"]
        },
        // The only mandatory one, so the avatar always has a fallback. Seeded
        // from the username on create, which may carry digits, so no character
        // rule here.
        displayName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
        },
        assetAddresses: {
          $each: {
            address1: {
              required: requiredIfNotDeleted
            },
            suburbText: {
              required: requiredIfNotDeleted
            },
            stateCode: {
              required: requiredIfNotDeleted
            },
            stateText: {
              required: requiredIfNotDeleted
            },
            suburbPostcode: {
              required: requiredIfNotDeleted
            },
            countryCode: {
              required: requiredIfNotDeleted
            },
            countryText: {
              required: requiredIfNotDeleted
            }
          },
          uniqueType: uniqueType
        },
        assetEmails: {
          $each: {
            address: {
              required: requiredIfNotDeleted,
              email: emailIfNotDeleted
            }
          },
          uniqueType: uniqueType
        },
        assetPhones: {
          $each: {
            no: {
              required: requiredIfNotDeleted
            }
          },
          uniqueType: uniqueType
        }
      },
      userAccessControl: {
        isAccessControlSelected: isAccessControlSelected
      }
    })
  }
});

/***/ }),

/***/ "./src/views/user/assets/ContactModal.vue":
/*!************************************************!*\
  !*** ./src/views/user/assets/ContactModal.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactModal.vue?vue&type=template&id=76d55622 */ "./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622");
/* harmony import */ var _ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactModal.vue?vue&type=script&lang=js */ "./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/assets/ContactModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/ContactModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622":
/*!******************************************************************************!*\
  !*** ./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622 ***!
  \******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactModal.vue?vue&type=template&id=76d55622 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/ContactModal.vue?vue&type=template&id=76d55622");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_76d55622__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/assets/UserAssetAddresses.vue":
/*!******************************************************!*\
  !*** ./src/views/user/assets/UserAssetAddresses.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserAssetAddresses.vue?vue&type=template&id=2a49b23f */ "./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f");
/* harmony import */ var _UserAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserAssetAddresses.vue?vue&type=script&lang=js */ "./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/assets/UserAssetAddresses.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js":
/*!******************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetAddresses.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetAddresses.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f":
/*!************************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetAddresses.vue?vue&type=template&id=2a49b23f */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetAddresses.vue?vue&type=template&id=2a49b23f");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetAddresses_vue_vue_type_template_id_2a49b23f__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/assets/UserAssetEmails.vue":
/*!***************************************************!*\
  !*** ./src/views/user/assets/UserAssetEmails.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserAssetEmails.vue?vue&type=template&id=2987588a */ "./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a");
/* harmony import */ var _UserAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserAssetEmails.vue?vue&type=script&lang=js */ "./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/assets/UserAssetEmails.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetEmails.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetEmails.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a":
/*!*********************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetEmails.vue?vue&type=template&id=2987588a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetEmails.vue?vue&type=template&id=2987588a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetEmails_vue_vue_type_template_id_2987588a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/assets/UserAssetPhones.vue":
/*!***************************************************!*\
  !*** ./src/views/user/assets/UserAssetPhones.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserAssetPhones.vue?vue&type=template&id=6e36b9f8 */ "./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8");
/* harmony import */ var _UserAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserAssetPhones.vue?vue&type=script&lang=js */ "./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/assets/UserAssetPhones.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetPhones.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetPhones.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8":
/*!*********************************************************************************!*\
  !*** ./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserAssetPhones.vue?vue&type=template&id=6e36b9f8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserAssetPhones.vue?vue&type=template&id=6e36b9f8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserAssetPhones_vue_vue_type_template_id_6e36b9f8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/assets/UserContacts.vue":
/*!************************************************!*\
  !*** ./src/views/user/assets/UserContacts.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true */ "./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true");
/* harmony import */ var _UserContacts_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserContacts.vue?vue&type=script&lang=js */ "./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true */ "./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _UserContacts_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "68a5bf40",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/assets/UserContacts.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserContacts.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=style&index=0&id=68a5bf40&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_style_index_0_id_68a5bf40_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true":
/*!******************************************************************************************!*\
  !*** ./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/assets/UserContacts.vue?vue&type=template&id=68a5bf40&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserContacts_vue_vue_type_template_id_68a5bf40_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=9.js.map