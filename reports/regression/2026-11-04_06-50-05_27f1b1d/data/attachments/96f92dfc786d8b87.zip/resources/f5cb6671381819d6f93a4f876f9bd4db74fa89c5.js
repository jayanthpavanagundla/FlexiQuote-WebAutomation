(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["assessment-invoice-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./mixins/QuoteTotalsMethodMixin */ "./src/views/quote/mixins/QuoteTotalsMethodMixin.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! lodash/isEqual */ "./node_modules/lodash/isEqual.js");
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @/components/BulmaMessage/BulmaMessage.vue */ "./src/components/BulmaMessage/BulmaMessage.vue");










































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteAssessmentInvoice',
  components: {
    InvoiceControl: _components__WEBPACK_IMPORTED_MODULE_33__["InvoiceControl"],
    InvoiceControlView: _components__WEBPACK_IMPORTED_MODULE_33__["InvoiceControlView"],
    QuoteDetailAssessmentSummaryModal: _components__WEBPACK_IMPORTED_MODULE_33__["QuoteDetailAssessmentSummaryModal"],
    BulmaMessage: _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_40__["default"]
  },
  mixins: [_mixins_QuoteTotalsMethodMixin__WEBPACK_IMPORTED_MODULE_36__["default"], _mixins__WEBPACK_IMPORTED_MODULE_37__["QuoteAssessmentMixin"]],
  props: {
    value: null,
    selectedInvoiceId: null,
    readOnlyView: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'fadeIn'
    },
    animationOut: {
      type: String,
      default: 'fadeOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35___default()(this.value),
      authorisedAssessments: [],
      selectedInvoice: null,
      columnsToBeInvoiced: ['Quote', 'Date Created', 'Quote Amount', 'Auth. Amount', 'Inv. Amount', 'Select'],
      columnsRaisedInvoices: ['Inv No.', 'Date Invoiced', 'Payer', 'Invoice Type', 'Inv. Amount'],
      isSummaryModalVisible: false,
      isGenerateInvoiceModalActive: false,
      modalInvoices: [],
      countShowGenerateInvoiceModal: 0,
      messages: []
    };
  },
  computed: {
    selectedAssessments: function selectedAssessments() {
      return this.authorisedAssessments.filter(function (a) {
        return a.selected;
      });
    },
    toBeInvoiceAssessments: function toBeInvoiceAssessments() {
      return this.authorisedAssessments.filter(function (a) {
        return !a.isInvoiced;
      });
    },
    raisedInvoice: function raisedInvoice() {
      return this.innerValue.invoices.filter(function (i) {
        return i.isDeleted !== true && i.deleted !== true;
      }).sort(function (a, b) {
        return b.invoiceNo - a.invoiceNo;
      });
    },
    isOrmInvoiceSubmitted: function isOrmInvoiceSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_34__["OrmQuoteStatusTypes"].QuoteInvoiceSubmitted;
    },
    isOrmPaymentAuthorised: function isOrmPaymentAuthorised() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_34__["OrmQuoteStatusTypes"].PaymentAuthorised;
    },
    isOrmPaymentDeclined: function isOrmPaymentDeclined() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_34__["OrmQuoteStatusTypes"].PaymentDeclined;
    },
    isOrmReactiveInvoiceSubmitted: function isOrmReactiveInvoiceSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_34__["OrmQuoteStatusTypes"].ReactiveInvoiceSubmitted;
    },
    isOrmAdjustmentNoteSubmitted: function isOrmAdjustmentNoteSubmitted() {
      return this.innerValue && this.innerValue.orm && this.innerValue.orm.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_34__["OrmQuoteStatusTypes"].AdjustmentNoteSubmitted;
    },
    hasRaisedInvoice: function hasRaisedInvoice() {
      return this.raisedInvoice.length > 0;
    },
    cannotRaiseInvoice: function cannotRaiseInvoice() {
      return this.isOrmInvoiceSubmitted || this.isOrmReactiveInvoiceSubmitted || this.isOrmAdjustmentNoteSubmitted || this.$licenceExpired;
    },
    isEstimage: function isEstimage() {
      return this.value.isEstimage;
    },
    cannotVoidInvoice: function cannotVoidInvoice() {
      if ((this.isOrmInvoiceSubmitted || this.isOrmPaymentAuthorised || this.isOrmReactiveInvoiceSubmitted || this.isOrmAdjustmentNoteSubmitted) && this.selectedInvoice) {
        var firstInvoice = this.innerValue.invoices.filter(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].Quote;
        }).slice().sort(function (a, b) {
          return a.invoiceNo - b.invoiceNo;
        })[0];
        if (!firstInvoice) {
          return false;
        }
        return this.selectedInvoice.invoiceId === firstInvoice.invoiceId;
      }
      return false;
    }
  },
  watch: {
    value: function value(newVal) {
      if (!lodash_isEqual__WEBPACK_IMPORTED_MODULE_39___default()(newVal, this.innerValue)) {
        this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35___default()(newVal);
        this.setAuthorisedAssessments();
      }
    }
  },
  created: function created() {
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_35___default()(this.value);
    this.setAuthorisedAssessments();
    this.clearInvoiceSelection();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    setAuthorisedAssessments: function setAuthorisedAssessments() {
      var _this = this;
      this.authorisedAssessments = [];
      var authorisedAssessment = this.innerValue.quoteAssessments.filter(function (a) {
        return a.authorisedAssessment && !a.deleted;
      });
      if (authorisedAssessment) {
        authorisedAssessment.forEach(function (assessment) {
          assessment.authorisedAmount = _this.getAssessmentItemsDeltaTotal(assessment.authorisedAssessment.assessmentQuoteItems, _this.value.quotingMethod, _this.isEstimage);
          assessment.quotedAmount = _this.getAssessmentItemsDeltaTotal(assessment.submittedAssessment.assessmentQuoteItems, _this.value.quotingMethod, _this.isEstimage);
          _this.$set(assessment, 'selected', false);
          _this.$set(assessment, 'invoicedAmount', _this.calculateInvoiceAmount(assessment));
          _this.authorisedAssessments.push(assessment);
        });
      }
    },
    onAssessmentSelect: function onAssessmentSelect(event, assessment) {
      if (this.$licenceExpired) {
        event.preventDefault();
        return;
      }
      var hasSupps = this.toBeInvoiceAssessments.some(function (a) {
        return a.subQuoteNo > 0;
      });
      if (this.countShowGenerateInvoiceModal == 0 && hasSupps && this.toBeInvoiceAssessments.length > 1) {
        event.preventDefault(); // Prevents checkbox default

        var isRaisedInvoices = this.raisedInvoice.some(function (r) {
          return r.invoiceType == 1;
        }).length > 0; //Quote invoice type
        this.modalInvoices = this.authorisedAssessments.map(function (item) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, item), {}, {
            selected: !isRaisedInvoices ? true : item.isInvoiced ? true : item.assessmentID === assessment.assessmentID ? true : item.selected
          });
        });
        this.isGenerateInvoiceModalActive = true;
        this.countShowGenerateInvoiceModal++;
      } else {
        assessment.selected = event.target.checked;
      }
      this.raisedInvoice.forEach(function (invoice) {
        invoice.isSelected = false;
      });
      this.selectedInvoice = null;
    },
    // onAssessmentSelect(event, assessment) {
    //   if (event.target.checked) {
    //     assessment.selected = true
    //     // this.toBeInvoiceAssessments.forEach((a) => {
    //     //   if (a.subQuoteNo <= assessment.subQuoteNo) {
    //     //     a.selected = true
    //     //   }
    //     // })
    //   } else {
    //     // this.toBeInvoiceAssessments.forEach((a) => {
    //     //   if (a.subQuoteNo >= assessment.subQuoteNo) {
    //     //     a.selected = false
    //     //   }
    //     // })
    //     assessment.selected = false
    //   }
    //   this.raisedInvoice.forEach((invoice) => {
    //     invoice.isSelected = false
    //   })
    //   this.selectedInvoice = null
    // },
    onSelectInvoice: function onSelectInvoice(invoice) {
      this.raisedInvoice.forEach(function (invoice) {
        invoice.isSelected = false;
      });
      this.toBeInvoiceAssessments.forEach(function (a) {
        a.selected = false;
      });
      invoice.isSelected = !invoice.isSelected;
      this.selectedInvoice = invoice;
    },
    defaultSelect: function defaultSelect() {
      this.authorisedAssessments.forEach(function (assessment) {
        assessment.selected = false;
      });
    },
    calculateInvoiceAmount: function calculateInvoiceAmount(assessment) {
      var invAmount = assessment.authorisedAmount;
      if (assessment.subQuoteNo === 0) {
        var ownerContributionGst = 0;
        if (!this.innerValue.excessWithGst) {
          ownerContributionGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(this.innerValue.ownersContribution * this.innerValue.gstRate / 100);
        }
        invAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(invAmount - this.innerValue.discount - this.innerValue.excess - this.innerValue.ownersContribution - ownerContributionGst);
      }
      return invAmount;
    },
    updateInvAmount: function updateInvAmount(deductions) {
      var mainAssessment = this.authorisedAssessments.find(function (a) {
        return a.subQuoteNo === 0;
      });
      if (mainAssessment) {
        mainAssessment.invoicedAmount = mainAssessment.authorisedAmount - deductions;
      }
    },
    onRaiseInvoice: function onRaiseInvoice(invoices) {
      var _this$innerValue$invo;
      this.$emit('input', this.innerValue);
      (_this$innerValue$invo = this.innerValue.invoices).push.apply(_this$innerValue$invo, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(invoices));
      this.selectedAssessments.forEach(function (assessment) {
        assessment.isInvoiced = true;
      });
      this.saveQuote();
      this.countShowGenerateInvoiceModal = 0;
    },
    onMergeInvoice: function onMergeInvoice(invoices) {
      var existingMainInvoice = this.innerValue.invoices.find(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].Quote && !i.deleted && !i.isDeleted;
      });
      if (existingMainInvoice) {
        var newInvoice = invoices.find(function (inv) {
          return inv.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].Quote;
        });
        if (newInvoice) {
          var currentIds = existingMainInvoice.includedAssessments || [];
          var newIds = newInvoice.includedAssessments || [];
          var mergedIds = Array.from(new Set([].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(currentIds), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newIds))));
          existingMainInvoice.includedAssessments = mergedIds;
          var includedAssessments = this.authorisedAssessments.filter(function (a) {
            return mergedIds.includes(a.assessmentID);
          });
          var totalAuthorised = includedAssessments.reduce(function (total, a) {
            return total + (a.authorisedAmount || 0);
          }, 0);
          var ownerContributionGst = 0;
          if (!this.innerValue.excessWithGst) {
            ownerContributionGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(this.innerValue.ownersContribution * this.innerValue.gstRate / 100);
          }
          var deductionAmount = this.innerValue.discount + this.innerValue.excess + this.innerValue.ownersContribution + ownerContributionGst;
          existingMainInvoice.totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(totalAuthorised - deductionAmount);
          if (!this.innerValue.excessWithGst) {
            existingMainInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((totalAuthorised - this.innerValue.discount) * this.innerValue.gstRate / 100);
          } else {
            existingMainInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(existingMainInvoice.totalExGst * existingMainInvoice.gstRate / 100);
          }
          existingMainInvoice.totalIncGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])(existingMainInvoice.totalExGst + existingMainInvoice.gst);
          existingMainInvoice.labourTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.labourTotal || 0) + (newInvoice.labourTotal || 0));
          existingMainInvoice.partTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.partTotal || 0) + (newInvoice.partTotal || 0));
          existingMainInvoice.miscTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.miscTotal || 0) + (newInvoice.miscTotal || 0));
          existingMainInvoice.subletTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.subletTotal || 0) + (newInvoice.subletTotal || 0));
          existingMainInvoice.rrTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.rrTotal || 0) + (newInvoice.rrTotal || 0));
          existingMainInvoice.repairTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.repairTotal || 0) + (newInvoice.repairTotal || 0));
          existingMainInvoice.paintTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.paintTotal || 0) + (newInvoice.paintTotal || 0));
          existingMainInvoice.mechTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.mechTotal || 0) + (newInvoice.mechTotal || 0));
          existingMainInvoice.opgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.opgTotal || 0) + (newInvoice.opgTotal || 0));
          existingMainInvoice.fgTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.fgTotal || 0) + (newInvoice.fgTotal || 0));
          existingMainInvoice.crushTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.crushTotal || 0) + (newInvoice.crushTotal || 0));
          existingMainInvoice.cdTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.cdTotal || 0) + (newInvoice.cdTotal || 0));
          existingMainInvoice.rwaTotal = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_38__["roundAwayFromZero"])((existingMainInvoice.rwaTotal || 0) + (newInvoice.rwaTotal || 0));
        }
        var newGstInvoice = invoices.find(function (inv) {
          return inv.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].Gst;
        });
        var existingGstInvoice = this.innerValue.invoices.find(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].Gst && !i.deleted && !i.isDeleted;
        });
        if (newGstInvoice) {
          if (existingGstInvoice) {
            existingGstInvoice.gst = existingMainInvoice.gst;
            existingGstInvoice.totalIncGst = existingMainInvoice.gst;
            existingGstInvoice.includedAssessments = existingMainInvoice.includedAssessments;
          } else {
            this.innerValue.invoices.push(newGstInvoice);
          }
        }
        this.selectedAssessments.forEach(function (assessment) {
          assessment.isInvoiced = true;
        });
        this.saveQuote();
      }
    },
    deleteInvoice: function deleteInvoice(invoices) {
      var _this2 = this;
      invoices.forEach(function (invoice) {
        invoice.deleted = true;
        invoice.isDeleted = true;
        invoice.isSelected = false;
        _this2.selectedInvoice = null;
        _this2.authorisedAssessments.forEach(function (a) {
          if (invoice.includedAssessments.some(function (i) {
            return i === a.assessmentID;
          })) {
            a.isInvoiced = false;
            a.selected = false;
          }
        });
      });
      this.saveQuote();
    },
    saveQuote: function saveQuote() {
      this.$emit('input', this.innerValue);
      this.$emit('save');
    },
    openSummaryModal: function openSummaryModal() {
      this.isSummaryModalVisible = true;
    },
    invoiceTypeName: function invoiceTypeName(invoiceType) {
      return _enums__WEBPACK_IMPORTED_MODULE_34__["InvoiceTypes"].getDisplayName(invoiceType);
    },
    clearInvoiceSelection: function clearInvoiceSelection() {
      var _this3 = this;
      this.innerValue.invoices.forEach(function (invoice) {
        invoice.isSelected = false;
      });
      if (this.selectedInvoiceId) {
        this.selectedInvoice = this.innerValue.invoices.find(function (i) {
          return i.invoiceId === _this3.selectedInvoiceId;
        });
      } else if (this.innerValue.invoices.length > 0) {
        this.innerValue.invoices[this.innerValue.invoices.length - 1].isSelected = true;
        this.selectedInvoice = this.innerValue.invoices[this.innerValue.invoices.length - 1];
      }
    },
    handleAdd: function handleAdd() {
      var _this4 = this;
      this.toBeInvoiceAssessments.forEach(function (item) {
        var matched = _this4.modalInvoices.find(function (modal) {
          return modal.assessmentID === item.assessmentID;
        });
        item.selected = matched ? matched.selected : false;
      });
      this.isGenerateInvoiceModalActive = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "fixed-grid has-2-cols-desktop has-1-cols-mobile",
    class: {
      "quote-assessment-invoice-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", {
    staticClass: "grid"
  }, [_c("div", {
    staticClass: "cell is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "mb-6"
  }, [_c("div", {
    staticClass: "columns mb-0"
  }, [_vm._m(0), _c("div", {
    staticClass: "column"
  }, [_c("button", {
    staticClass: "button is-small is-info is-pulled-right",
    on: {
      click: _vm.openSummaryModal
    }
  }, [_vm._m(1), _c("span", [_vm._v(" View Summary ")])])])]), _c("div", [_vm.toBeInvoiceAssessments.length > 0 ? _c("p", {
    staticClass: "is-size-7"
  }, [_vm._v("Select jobs to raise invoice/s")]) : _vm._e(), _c("table", {
    staticClass: "table is-fullwidth"
  }, [_c("thead", [_c("tr", [_c("th", [_vm._v(_vm._s(_vm.columnsToBeInvoiced[0]))]), _c("th", [_vm._v(_vm._s(_vm.columnsToBeInvoiced[1]))]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.columnsToBeInvoiced[2]) + " "), _c("p", {
    staticClass: "is-size-8"
  }, [_vm._v("Ex GST")])]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.columnsToBeInvoiced[3]) + " "), _c("p", {
    staticClass: "is-size-8"
  }, [_vm._v("Ex GST")])]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.columnsToBeInvoiced[4]) + " "), _c("p", {
    staticClass: "is-size-8"
  }, [_vm._v("Ex GST")])]), _c("th", [_vm._v(_vm._s(_vm.columnsToBeInvoiced[5]))])])]), _c("tbody", [_vm._l(_vm.toBeInvoiceAssessments, function (assessment) {
    return _c("tr", {
      key: assessment.subQuoteNo
    }, [_c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(assessment.subQuoteNo === 0 ? "Main" : "Supp-".concat(assessment.subQuoteNo)))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(assessment.authorisedAssessment.createdDate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(assessment.quotedAmount, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(assessment.authorisedAmount, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(assessment.invoicedAmount, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assessment.selected,
        expression: "assessment.selected"
      }],
      class: {
        "is-disabled": _vm.cannotRaiseInvoice
      },
      attrs: {
        disabled: _vm.cannotRaiseInvoice,
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(assessment.selected) ? _vm._i(assessment.selected, null) > -1 : assessment.selected
      },
      on: {
        click: function click($event) {
          return _vm.onAssessmentSelect($event, assessment);
        },
        change: function change($event) {
          var $$a = assessment.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(assessment, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(assessment, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(assessment, "selected", $$c);
          }
        }
      }
    }), _vm._m(2, true)])])]);
  }), _vm.toBeInvoiceAssessments.length === 0 ? _c("tr", [_c("td", {
    attrs: {
      colspan: _vm.columnsToBeInvoiced.length
    }
  }, [_vm._m(3)])]) : _vm._e()], 2)])])]), _c("div", [_c("p", {
    staticClass: "title mb-2"
  }, [_vm._v("Raised Invoices")]), _c("div", [_vm.innerValue.invoices.length > 0 ? _c("p", {
    staticClass: "is-size-7"
  }, [_vm._v("Select invoice to view details")]) : _vm._e(), _c("table", {
    staticClass: "table is-fullwidth"
  }, [_c("thead", [_c("tr", [_c("th", [_vm._v(_vm._s(_vm.columnsRaisedInvoices[0]))]), _c("th", [_vm._v(_vm._s(_vm.columnsRaisedInvoices[1]))]), _c("th", [_vm._v(_vm._s(_vm.columnsRaisedInvoices[2]))]), _c("th", [_vm._v(_vm._s(_vm.columnsRaisedInvoices[3]))]), _c("th", {
    staticClass: "has-text-right"
  }, [_vm._v(_vm._s(_vm.columnsRaisedInvoices[4]))]), _c("th")])]), _c("tbody", [_vm._l(_vm.raisedInvoice, function (invoice) {
    return _c("tr", {
      key: invoice.invoiceId,
      class: invoice.isSelected ? "has-text-primary" : ""
    }, [_c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(invoice.invoiceNo))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(invoice.invoiceDate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(invoice.assetName))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.invoiceTypeName(invoice.invoiceType)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(invoice.totalIncGst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("div", {
      staticClass: "icon-container"
    }, [_c("button", {
      staticClass: "button is-primary is-small is-inverted tooltip",
      attrs: {
        "data-tooltip": "View Details"
      },
      on: {
        click: function click($event) {
          return _vm.onSelectInvoice(invoice);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-small"
    }, [_c("i", {
      staticClass: "mdi mdi-eye mdi-24px",
      class: invoice.isSelected ? "" : "mdi-inactive-color"
    })])])])])]);
  }), _vm.raisedInvoice.length === 0 ? _c("tr", [_c("td", {
    attrs: {
      colspan: _vm.columnsRaisedInvoices.length
    }
  }, [_vm._m(4)])]) : _vm._e()], 2)])])])])]), _c("div", {
    staticClass: "cell is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_vm.selectedAssessments.length > 0 ? _c("invoice-control", {
    attrs: {
      "selected-invoice": _vm.selectedInvoice,
      assessments: _vm.selectedAssessments,
      "is-orm-invoice-submitted": _vm.isOrmInvoiceSubmitted,
      "is-orm-payment-authorised": _vm.isOrmPaymentAuthorised,
      "is-orm-payment-declined": _vm.isOrmPaymentDeclined,
      "has-raised-invoice": _vm.hasRaisedInvoice
    },
    on: {
      "raise-invoice": _vm.onRaiseInvoice,
      "merge-invoice": _vm.onMergeInvoice,
      "update-deductions": _vm.updateInvAmount
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }) : _vm.selectedInvoice ? _c("invoice-control-view", {
    attrs: {
      "selected-invoice": _vm.selectedInvoice,
      "cannot-void-invoice": _vm.cannotVoidInvoice
    },
    on: {
      "void-invoice": _vm.deleteInvoice
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }) : _c("div", [_c("p", {
    staticClass: "title"
  }, [_vm._v("Invoice Control")]), _c("div", {
    staticClass: "content has-text-grey has-text-centered borderd-box pb-3"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Select a job to raise / view")])])])], 1)]), _vm.isSummaryModalVisible ? _c("quote-detail-assessment-summary-modal", {
    attrs: {
      "show-icon": true,
      active: _vm.isSummaryModalVisible,
      value: _vm.innerValue
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSummaryModalVisible = $event;
      },
      close: function close($event) {
        _vm.isSummaryModalVisible = false;
      }
    }
  }) : _vm._e(), _c("BulmaMessage", {
    attrs: {
      type: "is-info",
      title: "Create New Invoice",
      closable: true
    },
    on: {
      close: function close($event) {
        _vm.isGenerateInvoiceModalActive = false;
      }
    },
    scopedSlots: _vm._u([{
      key: "title",
      fn: function fn() {
        return [_vm._v(" Create New Invoice ")];
      },
      proxy: true
    }, {
      key: "footer",
      fn: function fn() {
        return [_c("button", {
          staticClass: "button is-danger",
          on: {
            click: function click($event) {
              _vm.isGenerateInvoiceModalActive = false;
            }
          }
        }, [_vm._v(" Cancel ")]), _c("button", {
          staticClass: "button is-primary",
          on: {
            click: function click($event) {
              return _vm.handleAdd();
            }
          }
        }, [_vm._v(" Add ")])];
      },
      proxy: true
    }]),
    model: {
      value: _vm.isGenerateInvoiceModalActive,
      callback: function callback($$v) {
        _vm.isGenerateInvoiceModalActive = $$v;
      },
      expression: "isGenerateInvoiceModalActive"
    }
  }, [_vm.modalInvoices.some(function (assessment) {
    return assessment.isInvoiced;
  }) ? _c("div", [_c("p", {
    staticClass: "is-size-7 has-text-grey mb-2"
  }, [_vm._v("Already invoiced:")]), _c("div", {
    staticClass: "control is-flex justify-content-start"
  }, _vm._l(_vm.modalInvoices.filter(function (assessment) {
    return assessment.isInvoiced;
  }), function (assessment) {
    return _c("div", {
      key: assessment.subQuoteNo,
      staticClass: "p-2",
      staticStyle: {
        opacity: "0.6"
      }
    }, [_c("label", {
      staticClass: "checkbox toggle-style"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger pr-1"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assessment.selected,
        expression: "assessment.selected"
      }],
      attrs: {
        type: "checkbox",
        disabled: ""
      },
      domProps: {
        value: assessment,
        checked: Array.isArray(assessment.selected) ? _vm._i(assessment.selected, assessment) > -1 : assessment.selected
      },
      on: {
        change: function change($event) {
          var $$a = assessment.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = assessment,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(assessment, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(assessment, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(assessment, "selected", $$c);
          }
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]), _vm._v(" " + _vm._s(assessment.subQuoteNo === 0 ? "Main" : "Supp-".concat(assessment.subQuoteNo)) + " ")])]);
  }), 0)]) : _vm._e(), _c("div", {
    staticClass: "is-divider"
  }), _c("p", [_vm._v("Available for Invoicing: main / supplementaries")]), _vm.modalInvoices.some(function (assessment) {
    return !assessment.isInvoiced;
  }) ? _c("div", {
    staticClass: "mb-4"
  }, [_c("div", {
    staticClass: "control is-flex justify-content-start"
  }, _vm._l(_vm.modalInvoices.filter(function (assessment) {
    return !assessment.isInvoiced;
  }), function (assessment) {
    return _c("div", {
      key: assessment.subQuoteNo,
      staticClass: "p-2"
    }, [_c("label", {
      staticClass: "checkbox toggle-style"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger pr-1"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assessment.selected,
        expression: "assessment.selected"
      }],
      attrs: {
        type: "checkbox"
      },
      domProps: {
        value: assessment,
        checked: Array.isArray(assessment.selected) ? _vm._i(assessment.selected, assessment) > -1 : assessment.selected
      },
      on: {
        change: function change($event) {
          var $$a = assessment.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = assessment,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(assessment, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(assessment, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(assessment, "selected", $$c);
          }
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]), _vm._v(" " + _vm._s(assessment.subQuoteNo === 0 ? "Main" : "Supp-".concat(assessment.subQuoteNo)) + " ")])]);
  }), 0)]) : _vm._e()])], 1)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title mb-2"
  }, [_vm._v("To Be Invoiced")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-eye"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-size-8[data-v-6f9867c8] {\n  font-size: 0.65rem !important;\n}\n.borderd-box[data-v-6f9867c8] {\n  border: 1px solid gainsboro;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-assessment-invoice-licence-expired .pretty:has(> input:disabled) {\n  cursor: not-allowed;\n}\n.quote-assessment-invoice-licence-expired .pretty:has(> input:disabled):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  right: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEqual.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEqual.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseIsEqual = __webpack_require__(/*! ./_baseIsEqual */ "./node_modules/lodash/_baseIsEqual.js");

/**
 * Performs a deep comparison between two values to determine if they are
 * equivalent.
 *
 * **Note:** This method supports comparing arrays, array buffers, booleans,
 * date objects, error objects, maps, numbers, `Object` objects, regexes,
 * sets, strings, symbols, and typed arrays. `Object` objects are compared
 * by their own, not inherited, enumerable properties. Functions and DOM
 * nodes are compared by strict equality, i.e. `===`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.isEqual(object, other);
 * // => true
 *
 * object === other;
 * // => false
 */
function isEqual(value, other) {
  return baseIsEqual(value, other);
}

module.exports = isEqual;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7c01f119", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7d8bff2d", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteAssessmentInvoice.vue":
/*!****************************************************!*\
  !*** ./src/views/quote/QuoteAssessmentInvoice.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true */ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true");
/* harmony import */ var _QuoteAssessmentInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteAssessmentInvoice.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true */ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true");
/* harmony import */ var _QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss */ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteAssessmentInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6f9867c8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteAssessmentInvoice.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true":
/*!*************************************************************************************************************!*\
  !*** ./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=0&id=6f9867c8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_0_id_6f9867c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss":
/*!*************************************************************************************************!*\
  !*** ./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=style&index=1&id=6f9867c8&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_style_index_1_id_6f9867c8_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true":
/*!**********************************************************************************************!*\
  !*** ./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteAssessmentInvoice.vue?vue&type=template&id=6f9867c8&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteAssessmentInvoice_vue_vue_type_template_id_6f9867c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=assessment-invoice-chunk.js.map