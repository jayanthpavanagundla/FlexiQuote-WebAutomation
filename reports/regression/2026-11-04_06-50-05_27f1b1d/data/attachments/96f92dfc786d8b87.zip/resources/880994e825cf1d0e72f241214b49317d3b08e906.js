(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["contactlist-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _enums_AssetTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/enums/AssetTypes */ "./src/enums/AssetTypes.js");
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _components_BulmaRadio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/BulmaRadio */ "./src/components/BulmaRadio/index.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ContactListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__["default"],
    BulmaRadioButton: _components_BulmaRadio__WEBPACK_IMPORTED_MODULE_2__["BulmaRadioButton"]
  },
  props: {
    filter: null
  },
  data: function data() {
    return {
      selectedActive: 1,
      stateList: null
    };
  },
  computed: {
    assetTypes: function assetTypes() {
      return _enums_AssetTypes__WEBPACK_IMPORTED_MODULE_0__["default"];
    }
  },
  created: function created() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListView.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactListView.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _ContactService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var _ContactListSideMenu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ContactListSideMenu */ "./src/views/contact/ContactListSideMenu.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./columns */ "./src/views/contact/columns.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./storeMixin */ "./src/views/contact/storeMixin.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash/transform */ "./node_modules/lodash/transform.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(lodash_transform__WEBPACK_IMPORTED_MODULE_22__);
























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ContactListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_11__["default"],
    ContactListSideMenu: _ContactListSideMenu__WEBPACK_IMPORTED_MODULE_13__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_18__["default"]],
  data: function data() {
    return {
      entitySummaries: {},
      totalRows: 0,
      filter: {
        firstName: '',
        lastName: '',
        contactType: '',
        active: 1,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_16__["default"][1].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_16__["default"][1].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      },
      toggle: true,
      selectedRow: null,
      isTableLoading: false
    };
  },
  computed: {
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_16__["default"];
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _this.getData();
          case 1:
            _this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_14__["EventHubTypes"].ToggleSideMenu, function (data) {
              _this.toggle = false;
              setTimeout(function () {
                _this.toggle = true;
              }, 200);
            });
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].AddNew:
          this.addStoreItem(new _classes__WEBPACK_IMPORTED_MODULE_19__["ContactPayload"]());
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    resetList: function resetList() {
      this.filter = {
        firstName: '',
        lastName: '',
        contactType: '',
        active: 1,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_16__["default"][1].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_16__["default"][1].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      };
      this.persistFilter();
      this.getData();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    serialiseFilter: function serialiseFilter() {
      var entityProto = __webpack_require__(/*! ../../assets/proto/contact/ContactFilter.proto */ "./src/assets/proto/contact/ContactFilter.proto");
      var filterMessage = entityProto.ContactFilter.ContactFilter;
      var buffer = filterMessage.encode(this.filter).finish();
      var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_17___default.a.util.base64.encode(buffer, 0, buffer.length);
      return b64encoded;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getData();
    },
    getData: function getData() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var res;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isTableLoading = true;
              _this2.retrieveFilter();
              _context2.n = 1;
              return _ContactService__WEBPACK_IMPORTED_MODULE_12__["default"].getListing(_this2.serialiseFilter());
            case 1:
              res = _context2.v;
              _this2.entitySummaries = res.data;
              _this2.totalRows = _this2.entitySummaries.length > 0 ? _this2.entitySummaries[0].totalRows : 0;
              _this2.isTableLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    print: function print() {
      var sortBy = this.filter.sortColumn && this.filter.sortOrder ? "".concat(this.filter.sortColumn, " ").concat(this.filter.sortOrder) : '';
      var hackStatus = this.filter.active;
      if (hackStatus === 2) {
        hackStatus = '';
      }
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        FirstName: this.filter.firstName,
        LastName: this.filter.lastName,
        ContactType: this.filter.contactType === '' ? '-1' : this.filter.contactType,
        ActiveStatus: hackStatus,
        SortBy: sortBy
      });
      params = lodash_transform__WEBPACK_IMPORTED_MODULE_22___default()(params, function (result, value, key) {
        result[key] = value;
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_21__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_19__["Emailer"]();
      emailer.subject = 'Contact Profile Table';
      emailer.reportName = 'rptTablesContactProfile';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_20__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filter.firstName,
      expression: "filter.firstName"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "First Name"
    },
    domProps: {
      value: _vm.filter.firstName
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.filter, "firstName", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filter.lastName,
      expression: "filter.lastName"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Last Name"
    },
    domProps: {
      value: _vm.filter.lastName
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.filter, "lastName", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filter.contactType,
      expression: "filter.contactType"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.filter, "contactType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: ""
    }
  }, [_vm._v(" All ")]), _vm._l(_vm.assetTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: a
      }
    }, [_vm._v(_vm._s(b))]);
  })], 2)])])]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("bulma-radio-button", {
    attrs: {
      "native-value": 2
    },
    model: {
      value: _vm.filter.active,
      callback: function callback($$v) {
        _vm.$set(_vm.filter, "active", $$v);
      },
      expression: "filter.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-adjust"
  })]), _vm._v(" Both ")]), _c("bulma-radio-button", {
    attrs: {
      type: "is-success",
      "native-value": 1
    },
    model: {
      value: _vm.filter.active,
      callback: function callback($$v) {
        _vm.$set(_vm.filter, "active", $$v);
      },
      expression: "filter.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]), _vm._v(" Active ")]), _c("bulma-radio-button", {
    attrs: {
      type: "is-danger",
      "native-value": 0
    },
    model: {
      value: _vm.filter.active,
      callback: function callback($$v) {
        _vm.$set(_vm.filter, "active", $$v);
      },
      expression: "filter.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]), _vm._v(" In-Active ")])], 1)])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("contact-list-side-menu", {
    attrs: {
      filter: _vm.filter
    },
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, _vm._l(_vm.entitySummaries, function (c, idx) {
    return _c("tr", {
      key: c.id,
      class: {
        "is-selected": _vm.selectedRow === idx
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(idx, $event);
        }
      }
    }, [_c("td", [_vm._v(_vm._s(c.title))]), _c("td", [_c("router-link", {
      attrs: {
        to: {
          path: c.contactId
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(c.firstName) + ", " + _vm._s(c.lastName) + " ")])], 1), _c("td", [_vm._v(_vm._s(c.objectType))]), _c("td", [_vm._v(_vm._s(c.parentName))]), _c("td", [_vm._v(_vm._s(c.defaultPhone))]), _c("td", {
      staticClass: "is-email"
    }, [_c("div", [_vm._v(_vm._s(c.defaultEmail))])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [c.active ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [c.active ? "mdi-check" : "mdi-close"]
    })])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("router-link", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        to: {
          path: c.contactId
        },
        append: ""
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])])], 1)]);
  }), 0)], 1)])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/transform.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/transform.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayEach = __webpack_require__(/*! ./_arrayEach */ "./node_modules/lodash/_arrayEach.js"),
    baseCreate = __webpack_require__(/*! ./_baseCreate */ "./node_modules/lodash/_baseCreate.js"),
    baseForOwn = __webpack_require__(/*! ./_baseForOwn */ "./node_modules/lodash/_baseForOwn.js"),
    baseIteratee = __webpack_require__(/*! ./_baseIteratee */ "./node_modules/lodash/_baseIteratee.js"),
    getPrototype = __webpack_require__(/*! ./_getPrototype */ "./node_modules/lodash/_getPrototype.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isFunction = __webpack_require__(/*! ./isFunction */ "./node_modules/lodash/isFunction.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/**
 * An alternative to `_.reduce`; this method transforms `object` to a new
 * `accumulator` object which is the result of running each of its own
 * enumerable string keyed properties thru `iteratee`, with each invocation
 * potentially mutating the `accumulator` object. If `accumulator` is not
 * provided, a new object with the same `[[Prototype]]` will be used. The
 * iteratee is invoked with four arguments: (accumulator, value, key, object).
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @static
 * @memberOf _
 * @since 1.3.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @param {*} [accumulator] The custom accumulator value.
 * @returns {*} Returns the accumulated value.
 * @example
 *
 * _.transform([2, 3, 4], function(result, n) {
 *   result.push(n *= n);
 *   return n % 2 == 0;
 * }, []);
 * // => [4, 9]
 *
 * _.transform({ 'a': 1, 'b': 2, 'c': 1 }, function(result, value, key) {
 *   (result[value] || (result[value] = [])).push(key);
 * }, {});
 * // => { '1': ['a', 'c'], '2': ['b'] }
 */
function transform(object, iteratee, accumulator) {
  var isArr = isArray(object),
      isArrLike = isArr || isBuffer(object) || isTypedArray(object);

  iteratee = baseIteratee(iteratee, 4);
  if (accumulator == null) {
    var Ctor = object && object.constructor;
    if (isArrLike) {
      accumulator = isArr ? new Ctor : [];
    }
    else if (isObject(object)) {
      accumulator = isFunction(Ctor) ? baseCreate(getPrototype(object)) : {};
    }
    else {
      accumulator = {};
    }
  }
  (isArrLike ? arrayEach : baseForOwn)(object, function(value, index, object) {
    return iteratee(accumulator, value, index, object);
  });
  return accumulator;
}

module.exports = transform;


/***/ }),

/***/ "./src/assets/proto/contact/ContactFilter.proto":
/*!******************************************************!*\
  !*** ./src/assets/proto/contact/ContactFilter.proto ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*undefined*/


var $protobuf = __webpack_require__(/*! protobufjs/minimal */ "./node_modules/protobufjs/minimal.js");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.ContactFilter = (function() {

    /**
     * Namespace ContactFilter.
     * @exports ContactFilter
     * @namespace
     */
    var ContactFilter = {};

    ContactFilter.ContactFilter = (function() {

        /**
         * Properties of a ContactFilter.
         * @memberof ContactFilter
         * @interface IContactFilter
         * @property {string|null} [firstName] ContactFilter firstName
         * @property {string|null} [lastName] ContactFilter lastName
         * @property {number|null} [contactType] ContactFilter contactType
         * @property {number|null} [active] ContactFilter active
         * @property {string|null} [sortColumn] ContactFilter sortColumn
         * @property {string|null} [sortOrder] ContactFilter sortOrder
         * @property {number|null} [pageSize] ContactFilter pageSize
         * @property {number|null} [pageIndex] ContactFilter pageIndex
         */

        /**
         * Constructs a new ContactFilter.
         * @memberof ContactFilter
         * @classdesc Represents a ContactFilter.
         * @implements IContactFilter
         * @constructor
         * @param {ContactFilter.IContactFilter=} [p] Properties to set
         */
        function ContactFilter(p) {
            if (p)
                for (var ks = Object.keys(p), i = 0; i < ks.length; ++i)
                    if (p[ks[i]] != null)
                        this[ks[i]] = p[ks[i]];
        }

        /**
         * ContactFilter firstName.
         * @member {string|null|undefined} firstName
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.firstName = null;

        /**
         * ContactFilter lastName.
         * @member {string|null|undefined} lastName
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.lastName = null;

        /**
         * ContactFilter contactType.
         * @member {number|null|undefined} contactType
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.contactType = null;

        /**
         * ContactFilter active.
         * @member {number|null|undefined} active
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.active = null;

        /**
         * ContactFilter sortColumn.
         * @member {string|null|undefined} sortColumn
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.sortColumn = null;

        /**
         * ContactFilter sortOrder.
         * @member {string|null|undefined} sortOrder
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.sortOrder = null;

        /**
         * ContactFilter pageSize.
         * @member {number|null|undefined} pageSize
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.pageSize = null;

        /**
         * ContactFilter pageIndex.
         * @member {number|null|undefined} pageIndex
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        ContactFilter.prototype.pageIndex = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * ContactFilter _firstName.
         * @member {"firstName"|undefined} _firstName
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_firstName", {
            get: $util.oneOfGetter($oneOfFields = ["firstName"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _lastName.
         * @member {"lastName"|undefined} _lastName
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_lastName", {
            get: $util.oneOfGetter($oneOfFields = ["lastName"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _contactType.
         * @member {"contactType"|undefined} _contactType
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_contactType", {
            get: $util.oneOfGetter($oneOfFields = ["contactType"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _active.
         * @member {"active"|undefined} _active
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_active", {
            get: $util.oneOfGetter($oneOfFields = ["active"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _sortColumn.
         * @member {"sortColumn"|undefined} _sortColumn
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_sortColumn", {
            get: $util.oneOfGetter($oneOfFields = ["sortColumn"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _sortOrder.
         * @member {"sortOrder"|undefined} _sortOrder
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_sortOrder", {
            get: $util.oneOfGetter($oneOfFields = ["sortOrder"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _pageSize.
         * @member {"pageSize"|undefined} _pageSize
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_pageSize", {
            get: $util.oneOfGetter($oneOfFields = ["pageSize"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * ContactFilter _pageIndex.
         * @member {"pageIndex"|undefined} _pageIndex
         * @memberof ContactFilter.ContactFilter
         * @instance
         */
        Object.defineProperty(ContactFilter.prototype, "_pageIndex", {
            get: $util.oneOfGetter($oneOfFields = ["pageIndex"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Encodes the specified ContactFilter message. Does not implicitly {@link ContactFilter.ContactFilter.verify|verify} messages.
         * @function encode
         * @memberof ContactFilter.ContactFilter
         * @static
         * @param {ContactFilter.IContactFilter} m ContactFilter message or plain object to encode
         * @param {$protobuf.Writer} [w] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ContactFilter.encode = function encode(m, w) {
            if (!w)
                w = $Writer.create();
            if (m.firstName != null && Object.hasOwnProperty.call(m, "firstName"))
                w.uint32(10).string(m.firstName);
            if (m.lastName != null && Object.hasOwnProperty.call(m, "lastName"))
                w.uint32(18).string(m.lastName);
            if (m.contactType != null && Object.hasOwnProperty.call(m, "contactType"))
                w.uint32(24).int32(m.contactType);
            if (m.active != null && Object.hasOwnProperty.call(m, "active"))
                w.uint32(32).int32(m.active);
            if (m.sortColumn != null && Object.hasOwnProperty.call(m, "sortColumn"))
                w.uint32(42).string(m.sortColumn);
            if (m.sortOrder != null && Object.hasOwnProperty.call(m, "sortOrder"))
                w.uint32(50).string(m.sortOrder);
            if (m.pageSize != null && Object.hasOwnProperty.call(m, "pageSize"))
                w.uint32(56).int32(m.pageSize);
            if (m.pageIndex != null && Object.hasOwnProperty.call(m, "pageIndex"))
                w.uint32(64).int32(m.pageIndex);
            return w;
        };

        /**
         * Encodes the specified ContactFilter message, length delimited. Does not implicitly {@link ContactFilter.ContactFilter.verify|verify} messages.
         * @function encodeDelimited
         * @memberof ContactFilter.ContactFilter
         * @static
         * @param {ContactFilter.IContactFilter} message ContactFilter message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        ContactFilter.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a ContactFilter message from the specified reader or buffer.
         * @function decode
         * @memberof ContactFilter.ContactFilter
         * @static
         * @param {$protobuf.Reader|Uint8Array} r Reader or buffer to decode from
         * @param {number} [l] Message length if known beforehand
         * @returns {ContactFilter.ContactFilter} ContactFilter
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ContactFilter.decode = function decode(r, l) {
            if (!(r instanceof $Reader))
                r = $Reader.create(r);
            var c = l === undefined ? r.len : r.pos + l, m = new $root.ContactFilter.ContactFilter();
            while (r.pos < c) {
                var t = r.uint32();
                switch (t >>> 3) {
                case 1:
                    m.firstName = r.string();
                    break;
                case 2:
                    m.lastName = r.string();
                    break;
                case 3:
                    m.contactType = r.int32();
                    break;
                case 4:
                    m.active = r.int32();
                    break;
                case 5:
                    m.sortColumn = r.string();
                    break;
                case 6:
                    m.sortOrder = r.string();
                    break;
                case 7:
                    m.pageSize = r.int32();
                    break;
                case 8:
                    m.pageIndex = r.int32();
                    break;
                default:
                    r.skipType(t & 7);
                    break;
                }
            }
            return m;
        };

        /**
         * Decodes a ContactFilter message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof ContactFilter.ContactFilter
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {ContactFilter.ContactFilter} ContactFilter
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        ContactFilter.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        return ContactFilter;
    })();

    return ContactFilter;
})();

module.exports = $root;


/***/ }),

/***/ "./src/components/BulmaRadio/index.js":
/*!********************************************!*\
  !*** ./src/components/BulmaRadio/index.js ***!
  \********************************************/
/*! exports provided: BulmaRadio, BulmaRadioButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaRadio", function() { return BulmaRadio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaRadioButton", function() { return BulmaRadioButton; });
// import BulmaRadio from './BulmaRadio'
// import BulmaRadioGroup from './BulmaRadioGroup'
// import BulmaRadioButton from './BulmaRadioButton'

var BulmaRadio = function BulmaRadio(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaRadio.vue */ "./src/components/BulmaRadio/BulmaRadio.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var BulmaRadioButton = function BulmaRadioButton(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaRadioButton.vue */ "./src/components/BulmaRadio/BulmaRadioButton.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/views/contact/ContactListSideMenu.vue":
/*!***************************************************!*\
  !*** ./src/views/contact/ContactListSideMenu.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactListSideMenu.vue?vue&type=template&id=2861731b */ "./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b");
/* harmony import */ var _ContactListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactListSideMenu.vue?vue&type=script&lang=js */ "./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/contact/ContactListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b":
/*!*********************************************************************************!*\
  !*** ./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactListSideMenu.vue?vue&type=template&id=2861731b */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListSideMenu.vue?vue&type=template&id=2861731b");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListSideMenu_vue_vue_type_template_id_2861731b__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/ContactListView.vue":
/*!***********************************************!*\
  !*** ./src/views/contact/ContactListView.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactListView.vue?vue&type=template&id=29b5a96a */ "./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a");
/* harmony import */ var _ContactListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactListView.vue?vue&type=script&lang=js */ "./src/views/contact/ContactListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/contact/ContactListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/contact/ContactListView.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/contact/ContactListView.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a":
/*!*****************************************************************************!*\
  !*** ./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactListView.vue?vue&type=template&id=29b5a96a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactListView.vue?vue&type=template&id=29b5a96a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactListView_vue_vue_type_template_id_29b5a96a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/columns.js":
/*!**************************************!*\
  !*** ./src/views/contact/columns.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Title', 'TITLE', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('First/Last Name', 'firstName,lastName', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Contact Type', 'objectType', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Contact Name', 'parentName', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Phone', 'defaultPhone', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Email', 'defaultEmail', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Active', 'active', true, 'asc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
/* harmony default export */ __webpack_exports__["default"] = (Columns);

/***/ }),

/***/ "./src/views/contact/storeMixin.js":
/*!*****************************************!*\
  !*** ./src/views/contact/storeMixin.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'contacts';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'addNewEntity', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quickinvoices', {
    setQuickInvoiceContactId: 'setContactId'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('sundrycreditors', {
    setSundryCreditorContact: 'setContact'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('purchaseorders', {
    setPurchaseOrderContact: 'setContact'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=contactlist-chunk.js.map