(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _assets_CompanyAssetAddresses__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./assets/CompanyAssetAddresses */ "./src/views/companysetting/assets/CompanyAssetAddresses.vue");
/* harmony import */ var _assets_CompanyAssetEmails__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./assets/CompanyAssetEmails */ "./src/views/companysetting/assets/CompanyAssetEmails.vue");
/* harmony import */ var _assets_CompanyAssetPhones__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./assets/CompanyAssetPhones */ "./src/views/companysetting/assets/CompanyAssetPhones.vue");
/* harmony import */ var _contact_ContactService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../contact/ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");
/* harmony import */ var _company_CompanyService__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../company/CompanyService */ "./src/views/company/CompanyService.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _assets_CompanyContact__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./assets/CompanyContact */ "./src/views/companysetting/assets/CompanyContact.vue");
/* harmony import */ var _superadmin_company_route_types__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../superadmin/company/route-types */ "./src/views/superadmin/company/route-types.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../../services */ "./src/services/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ../../components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _superadmin_countrysetting_CountrySettingService__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ../superadmin/countrysetting/CountrySettingService */ "./src/views/superadmin/countrysetting/CountrySettingService.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _utils_StringFunctions__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @/utils/StringFunctions */ "./src/utils/StringFunctions.js");



































// import Multiselect from 'vue-multiselect'









var companynameUnique = /*#__PURE__*/function () {
  var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee(value) {
    var isUnique, _t;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          if (value) {
            _context.n = 1;
            break;
          }
          return _context.a(2, true);
        case 1:
          if (this.$userInfo.isSystemAccount) {
            _context.n = 2;
            break;
          }
          return _context.a(2, true);
        case 2:
          _context.p = 2;
          _context.n = 3;
          return _services__WEBPACK_IMPORTED_MODULE_39__["CompanySettingService"].checkCompanyNameValidity(this.companyDetails.companyId, this.companyDetails.name.toString());
        case 3:
          isUnique = _context.v;
          return _context.a(2, isUnique);
        case 4:
          _context.p = 4;
          _t = _context.v;
          console.error('Error checking company name validity:', _t);
          return _context.a(2, true);
      }
    }, _callee, this, [[2, 4]]);
  }));
  return function companynameUnique(_x) {
    return _ref.apply(this, arguments);
  };
}();
var companyRegisteredIdUnique = /*#__PURE__*/function () {
  var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee2(value) {
    var isUnique, _t2;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          if (value) {
            _context2.n = 1;
            break;
          }
          return _context2.a(2, true);
        case 1:
          if (this.$userInfo.isSystemAccount) {
            _context2.n = 2;
            break;
          }
          return _context2.a(2, true);
        case 2:
          _context2.p = 2;
          _context2.n = 3;
          return _services__WEBPACK_IMPORTED_MODULE_39__["CompanySettingService"].validateCompanyRegisteredID(this.companyDetails.companyId, this.companyDetails.companyRegisteredId);
        case 3:
          isUnique = _context2.v;
          return _context2.a(2, isUnique);
        case 4:
          _context2.p = 4;
          _t2 = _context2.v;
          console.error('Error checking company registered id validity:', _t2);
          return _context2.a(2, true);
      }
    }, _callee2, this, [[2, 4]]);
  }));
  return function companyRegisteredIdUnique(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var validatePassword = /*#__PURE__*/function () {
  var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee3(password) {
    var result, _t3;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context3) {
      while (1) switch (_context3.p = _context3.n) {
        case 0:
          if (password) {
            _context3.n = 1;
            break;
          }
          return _context3.a(2, false);
        case 1:
          _context3.p = 1;
          _context3.n = 2;
          return _services__WEBPACK_IMPORTED_MODULE_39__["UserService"].getPasswordComplexity(password);
        case 2:
          result = _context3.v;
          this.passwordMessage = result.message;
          return _context3.a(2, result.passwordMeetsCriteria);
        case 3:
          _context3.p = 3;
          _t3 = _context3.v;
          console.error('Error checking password validity:', _t3);
          return _context3.a(2, true);
      }
    }, _callee3, this, [[1, 3]]);
  }));
  return function validatePassword(_x3) {
    return _ref3.apply(this, arguments);
  };
}();
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyDetailSetting',
  components: {
    CompanyAssetAddresses: _assets_CompanyAssetAddresses__WEBPACK_IMPORTED_MODULE_29__["default"],
    CompanyAssetEmails: _assets_CompanyAssetEmails__WEBPACK_IMPORTED_MODULE_30__["default"],
    CompanyAssetPhones: _assets_CompanyAssetPhones__WEBPACK_IMPORTED_MODULE_31__["default"],
    // Multiselect,
    CompanyContact: _assets_CompanyContact__WEBPACK_IMPORTED_MODULE_36__["default"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_38__["BulmaAutocomplete"],
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_42__["TheMask"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_33__["default"]],
  data: function data() {
    return {
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      companyDetails: {
        contacts: []
      },
      user: {},
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['DD/MM/YYYY'],
        data: ['DD/MM/YYYY'],
        dayPopover: null
      },
      // newContacts: [],
      hqCompanyNoOptions: [],
      hqCompanyNoLoading: false,
      selectedHqCompanyNo: null,
      showPassword: false,
      innerCustomerSince: null,
      passwordMessage: '',
      countries: [],
      timezones: []
    };
  },
  computed: {
    locales: function locales() {
      return this.companyDetails.countryCode ? _enums__WEBPACK_IMPORTED_MODULE_28__["Locale"][this.companyDetails.countryCode] : [];
    },
    mappingMalaysiaStates: function mappingMalaysiaStates() {
      return _enums__WEBPACK_IMPORTED_MODULE_28__["MalaysiaStates"];
    },
    mappingStateAreaCodes: function mappingStateAreaCodes() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, _enums__WEBPACK_IMPORTED_MODULE_28__["StateAreaCodes"].AUStateAreaCodes), _enums__WEBPACK_IMPORTED_MODULE_28__["StateAreaCodes"].MYStateAreaCodes);
    },
    mappingCountryCallingCodes: function mappingCountryCallingCodes() {
      return _enums__WEBPACK_IMPORTED_MODULE_28__["CountryCallingCodes"];
    },
    sortedAddresses: function sortedAddresses() {
      if (this.companyDetails && this.companyDetails.assetAddresses) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.companyDetails.assetAddresses).sort(function (a, b) {
          return b.isDefault - a.isDefault;
        });
      }
    },
    sortedEmails: function sortedEmails() {
      if (this.companyDetails && this.companyDetails.assetEmails) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.companyDetails.assetEmails).sort(function (a, b) {
          return b.isDefault - a.isDefault;
        });
      }
    },
    sortedPhones: function sortedPhones() {
      if (this.companyDetails && this.companyDetails.assetPhones) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.companyDetails.assetPhones).sort(function (a, b) {
          return b.isDefault - a.isDefault;
        });
      }
    },
    // timezones() {
    //   return this.companyDetails.countryCode ? Timezone[this.companyDetails.countryCode] : []
    // },
    validateError: function validateError() {
      var isError = this.$v.$error;
      if (this.$refs.assetPhones !== undefined && this.$refs.assetEmails !== undefined && this.$refs.assetAddresses !== undefined && this.$refs.assetContacts !== undefined) {
        isError = isError || this.$refs.assetPhones.$v.$error || !this.$refs.assetPhones.$v.uniquePhoneType || this.$refs.assetEmails.$v.$error || !this.$refs.assetEmails.$v.uniqueEmailType || this.$refs.assetAddresses.$v.$error || !this.$refs.assetAddresses.$v.uniqueAddressType || this.$refs.assetContacts.$v.$error;
      }
      return isError;
    },
    isNew: function isNew() {
      var companyId = this.$route.params.companyId;
      return companyId === 'new';
    },
    isHQ: function isHQ() {
      var companyType = this.$route.params.companyType;
      return companyType === 'hq';
    },
    today: function today() {
      return new Date().toISOString().split('T')[0];
    }
  },
  watch: {
    companyDetails: {
      handler: function handler(val) {
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(val)
        });
        if (typeof this.autoUpdate === 'function') this.autoUpdate(val);
      },
      deep: true
    },
    'companyDetails.countryCode': {
      handler: function () {
        var _handler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee4(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context4) {
            while (1) switch (_context4.n) {
              case 0:
                if (oldVal && newVal && oldVal !== newVal) {
                  this.companyDetails.assetAddresses = [];
                  this.companyDetails.timezones = [];
                  this.companyDetails.timeZoneId = null;
                  this.companyDetails.timezone = null;
                  this.companyDetails.locale = null;
                }
                this.getTimezonesByCountryCode(newVal);
              case 1:
                return _context4.a(2);
            }
          }, _callee4, this);
        }));
        function handler(_x4, _x5) {
          return _handler.apply(this, arguments);
        }
        return handler;
      }()
    },
    'companyDetails.assetAddresses': {
      handler: function () {
        var _handler2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee5(val) {
          var _iterator, _step, address;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context5) {
            while (1) switch (_context5.n) {
              case 0:
                if (!(!val.length > 0)) {
                  _context5.n = 1;
                  break;
                }
                return _context5.a(2);
              case 1:
                _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(val);
                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    address = _step.value;
                    if (address.stateText in this.mappingMalaysiaStates) {
                      address.stateCode = this.mappingMalaysiaStates[address.stateText];
                    }
                    if (address.stateCode in this.mappingStateAreaCodes) {
                      address.stateAreaCode = this.mappingStateAreaCodes[address.stateCode];
                    }
                    if (address.countryCode in this.mappingCountryCallingCodes) {
                      address.countryCallingCode = this.mappingCountryCallingCodes[address.countryCode];
                    }
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
              case 2:
                return _context5.a(2);
            }
          }, _callee5, this);
        }));
        function handler(_x6) {
          return _handler2.apply(this, arguments);
        }
        return handler;
      }(),
      deep: true
    },
    'companyDetails.assetEmails': {
      handler: function () {
        var _handler3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee6(val) {
          var defaultEmail;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context6) {
            while (1) switch (_context6.n) {
              case 0:
                if (!(!val.length > 0)) {
                  _context6.n = 1;
                  break;
                }
                return _context6.a(2);
              case 1:
                defaultEmail = val.find(function (ae) {
                  return ae.isDefault;
                });
                if (defaultEmail) {
                  this.$set(this.user, 'email', defaultEmail.address);
                }
              case 2:
                return _context6.a(2);
            }
          }, _callee6, this);
        }));
        function handler(_x7) {
          return _handler3.apply(this, arguments);
        }
        return handler;
      }(),
      deep: true
    },
    innerCustomerSince: {
      handler: function handler(val) {
        if (val) {
          var dateTime = new Date(val);
          this.companyDetails.customerSince = dateTime.toISOString();
        } else {
          this.companyDetails.customerSince = null;
        }
      }
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee7() {
      var newCompany, _t4, _t5, _t6, _t7;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            _this.$showSpinner();
            if (!_this.isNew) {
              _context7.n = 4;
              break;
            }
            newCompany = _this.$store.getters['companysetting/newCompany'];
            if (!(newCompany && newCompany.companyDetails)) {
              _context7.n = 1;
              break;
            }
            _this.companyDetails = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(newCompany.companyDetails);
            _context7.n = 3;
            break;
          case 1:
            _t4 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default.a;
            _context7.n = 2;
            return _this.getStoreItem({
              serviceFunction: 'getNewCompanyDetails'
            });
          case 2:
            _t5 = _context7.v;
            _this.companyDetails = _t4(_t5);
          case 3:
            _this.user = {
              email: '',
              username: 'Administrator',
              password: '',
              isNew: true
            };
            _this.companyDetails.isNew = true;
            _context7.n = 6;
            break;
          case 4:
            _t6 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default.a;
            _context7.n = 5;
            return _this.getStoreItem({
              serviceFunction: 'getCompanyDetails',
              params: _this.$route.params.companyId
            });
          case 5:
            _t7 = _context7.v;
            _this.companyDetails = _t6(_t7);
          case 6:
            if (_this.companyDetails.customerSince) _this.innerCustomerSince = new Date(_this.companyDetails.customerSince).toISOString().split('T')[0];
            _this.loadHQCompaniesData();
            _this.getCountries();
            _this.getTimezonesByCountryCode(_this.companyDetails.countryCode);
            if (!_this.isNew) {
              _this.initializeAutoUpdate();
            }
            _this.$hideSpinner();
          case 7:
            return _context7.a(2);
        }
      }, _callee7);
    }))();
  },
  methods: {
    addContact: function addContact(newContact) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee8() {
        var contactMapId;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!(newContact == null)) {
                _context8.n = 1;
                break;
              }
              return _context8.a(2);
            case 1:
              if (_this2.companyDetails.contacts == null) _this2.companyDetails.contacts = [];
              contactMapId = _components_Guid__WEBPACK_IMPORTED_MODULE_40__["default"].newGuid();
              newContact.assets = [{
                assetType: 0,
                assetId: _this2.companyDetails.companyId,
                id: contactMapId
              }];
              newContact.contactMapId = contactMapId;
              _this2.companyDetails.contacts.push(newContact);
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    addTmpAddress: function addTmpAddress() {
      var newAddress = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__["AddressModel"](this.companyDetails.companyId);
      if (this.companyDetails.assetAddresses.length == 0) {
        newAddress.isDefault = true;
      }
      this.companyDetails.assetAddresses.push(newAddress);
    },
    addTmpEmail: function addTmpEmail() {
      var newEmail = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__["EmailModel"]();
      if (this.companyDetails.assetEmails.length == 0) {
        newEmail.isDefault = true;
      }
      this.companyDetails.assetEmails.push(newEmail);
    },
    addTmpPhone: function addTmpPhone() {
      var newPhone = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_27__["PhoneModel"]();
      if (this.companyDetails.assetPhones.length == 0) {
        newPhone.isDefault = true;
      }
      this.companyDetails.assetPhones.push(newPhone);
    },
    customerSinceInputEvent: function customerSinceInputEvent(date) {
      var dateTime = new Date(date);
      //dateTime.setHours(0, 0, 0, 0)
      this.companyDetails.customerSince = dateTime.toISOString();
    },
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdate === 'function' && typeof this.autoUpdate.cancel === 'function') {
        this.autoUpdate.cancel();
      }
      this.autoUpdate = function () {};
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this3 = this;
      this.autoUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default()(/*#__PURE__*/function () {
        var _ref4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee9(value) {
          var _t8;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context9) {
            while (1) switch (_context9.n) {
              case 0:
                _t8 = _this3.snapshotDiff;
                if (!_t8) {
                  _context9.n = 1;
                  break;
                }
                _context9.n = 1;
                return _this3.updateCompanyDetails(value);
              case 1:
                return _context9.a(2);
            }
          }, _callee9);
        }));
        return function (_x8) {
          return _ref4.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    removeAddress: function removeAddress(address) {
      this.companyDetails.assetAddresses = this.companyDetails.assetAddresses.filter(function (a) {
        return a !== address;
      });
    },
    removeContact: function removeContact(contact) {
      this.companyDetails.contacts = this.companyDetails.contacts.filter(function (c) {
        return c !== contact;
      });
    },
    removeEmail: function removeEmail(email) {
      this.companyDetails.assetEmails = this.companyDetails.assetEmails.filter(function (e) {
        return e !== email;
      });
    },
    removePhone: function removePhone(phone) {
      this.companyDetails.assetPhones = this.companyDetails.assetPhones.filter(function (p) {
        return p !== phone;
      });
    },
    setDefault: function setDefault(asset, assetType) {
      this.companyDetails[assetType].forEach(function (a) {
        return a.isDefault = a == asset;
      });
    },
    updateContacts: function updateContacts(newContacts) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee0() {
        var _iterator2, _step2, newContact, _t9;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context0) {
          while (1) switch (_context0.p = _context0.n) {
            case 0:
              _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(newContacts);
              _context0.p = 1;
              _iterator2.s();
            case 2:
              if ((_step2 = _iterator2.n()).done) {
                _context0.n = 7;
                break;
              }
              newContact = _step2.value;
              if (!(newContact == null)) {
                _context0.n = 3;
                break;
              }
              return _context0.a(3, 6);
            case 3:
              newContact.id = newContact.contactId;
              if (!_this4.$userInfo.isSystemAccount) {
                _context0.n = 5;
                break;
              }
              _context0.n = 4;
              return _contact_ContactService__WEBPACK_IMPORTED_MODULE_32__["default"].postContact(newContact, _this4.companyDetails.companyId);
            case 4:
              _context0.n = 6;
              break;
            case 5:
              _context0.n = 6;
              return _contact_ContactService__WEBPACK_IMPORTED_MODULE_32__["default"].postContact(newContact);
            case 6:
              _context0.n = 2;
              break;
            case 7:
              _context0.n = 9;
              break;
            case 8:
              _context0.p = 8;
              _t9 = _context0.v;
              _iterator2.e(_t9);
            case 9:
              _context0.p = 9;
              _iterator2.f();
              return _context0.f(9);
            case 10:
              return _context0.a(2);
          }
        }, _callee0, null, [[1, 8, 9, 10]]);
      }))();
    },
    updateCompanyDetails: function updateCompanyDetails(companyDetails) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee1() {
        var _t0, _t1;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (companyDetails.abn) companyDetails.abn = Object(_utils_StringFunctions__WEBPACK_IMPORTED_MODULE_43__["stripSpaces"])(companyDetails.abn);
              if (!_this5.isNew) {
                _context1.n = 1;
                break;
              }
              _this5.setStateProperty({
                key: 'companyDetails',
                value: companyDetails
              });
              _this5.setStateProperty({
                key: 'user',
                value: _this5.user
              });
              return _context1.a(2);
            case 1:
              if (!_this5.validateError) {
                _context1.n = 2;
                break;
              }
              return _context1.a(2, _this5.$notification.error('Company Details', 'Please fix validation errors.'));
            case 2:
              if (!_this5.validateCountrySectionError()) {
                _context1.n = 3;
                break;
              }
              return _context1.a(2);
            case 3:
              if (_this5.snapshotDiff) {
                _context1.n = 4;
                break;
              }
              return _context1.a(2);
            case 4:
              if (!(_this5.companyDetails.contacts.filter(function (c) {
                return c.isNew;
              }).length > 0)) {
                _context1.n = 5;
                break;
              }
              _context1.n = 5;
              return _this5.updateContacts(_this5.companyDetails.contacts.filter(function (c) {
                return c.isNew;
              }));
            case 5:
              companyDetails.deepDiff = JSON.stringify(_this5.snapshotDiff);
              console.log('Updating company details with diff:', companyDetails.deepDiff);
              _t0 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default.a;
              _context1.n = 6;
              return _this5.editStoreItem({
                serviceFunction: 'updateCompanyDetails',
                entity: companyDetails,
                params: _this5.$route.params.companyId
              });
            case 6:
              _t1 = _context1.v;
              _this5.companyDetails = _t0(_t1);
              if (_this5.toastNotificationEnabled) {
                _this5.openToastNotification();
              }
            case 7:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    validateCountrySectionError: function validateCountrySectionError() {
      if (this.companyDetails.assetAddresses.length == 0 || this.companyDetails.timezone == null || this.companyDetails.locale == null) {
        this.$notification.error('Company Details', 'Require timezone, locale and address');
        return true;
      }
      var _this$companyDetails$ = this.companyDetails.assetAddresses.filter(function (address) {
          return address.isDefault;
        }),
        _this$companyDetails$2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this$companyDetails$, 1),
        defaultAddress = _this$companyDetails$2[0];
      if (!defaultAddress || defaultAddress.countryCode !== this.companyDetails.countryCode) {
        this.$notification.error('Company Details', 'Default address country must match the selected country.');
        return true;
      }
      return false;
    },
    loadHQCompaniesData: function loadHQCompaniesData() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee10() {
        var selectedHqCompanyNo, selected;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              _this6.hqCompanyNoLoading = true;
              _context10.n = 1;
              return _company_CompanyService__WEBPACK_IMPORTED_MODULE_34__["default"].getHQCompanies();
            case 1:
              _this6.hqCompanyNoOptions = _context10.v;
              _this6.hqCompanyNoLoading = false;
              selectedHqCompanyNo = _this6.companyDetails.hqCompanyNo;
              if (selectedHqCompanyNo) {
                selected = _this6.hqCompanyNoOptions.find(function (a) {
                  return a.companyLoginId === selectedHqCompanyNo;
                });
                if (selected) {
                  _this6.selectedHqCompanyNo = selected.companyLoginId;
                }
              }
            case 2:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    onHqSelected: function onHqSelected(hq) {
      if (hq) {
        this.selectedHqCompanyNo = hq.companyLoginId;
        this.companyDetails.hqCompanyNo = hq.companyLoginId;
        this.companyDetails.CompanyParentID = hq.companyLoginId;
        this.companyDetails.parentCompanyName = hq.name;
      } else {
        this.companyDetails.hqCompanyNo = null;
        this.companyDetails.CompanyParentID = null;
        this.companyDetails.parentCompanyName = null;
      }
    },
    toggleActive: function toggleActive(active) {
      this.companyDetails.isActive = active;
    },
    preventNonDigit: function preventNonDigit(event) {
      if (event.key === 'Backspace' || event.key === 'Tab' || event.key === 'ArrowLeft' || event.key === 'ArrowRight' || event.key === 'Delete') return;
      if (!/[0-9]/.test(event.key)) {
        event.preventDefault();
      }
    },
    onRegisteredIdInput: function onRegisteredIdInput(event) {
      var val = event.target.value.replace(/\D/g, '').slice(0, 6);
      this.companyDetails.companyRegisteredId = val;
      // this.checkCompanyRegisteredIdUnique()
    },
    resetPassword: function resetPassword() {
      this.$router.push({
        name: _superadmin_company_route_types__WEBPACK_IMPORTED_MODULE_37__["default"].CompanyUserListView.name,
        params: {
          companyId: this.$route.params.companyId
        }
      });
    },
    onHqCompanyNoTyping: function onHqCompanyNoTyping(text) {
      this.hqCompanyNoOptions = this.hqCompanyNoOptions.filter(function (item) {
        return item.companyLoginId.toLowerCase().includes(text.toLowerCase());
      });
    },
    getCountries: function getCountries() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee11() {
        var filter, result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              filter = {
                query: '',
                active: 1,
                sortColumn: 'countryCode',
                sortOrder: 'asc',
                pageIndex: 1,
                pageSize: 18
              };
              _context11.n = 1;
              return _superadmin_countrysetting_CountrySettingService__WEBPACK_IMPORTED_MODULE_41__["default"].getEntitySummaries(filter);
            case 1:
              result = _context11.v;
              _this7.countries = result;
            case 2:
              return _context11.a(2);
          }
        }, _callee11);
      }))();
    },
    getTimezonesByCountryCode: function getTimezonesByCountryCode(countryCode) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee12() {
        var timezones;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              if (countryCode) {
                _context12.n = 1;
                break;
              }
              return _context12.a(2, []);
            case 1:
              _context12.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_39__["CompanySettingService"].getTimeZonesByCountryCode(countryCode);
            case 2:
              timezones = _context12.v;
              _this8.timezones = timezones;
            case 3:
              return _context12.a(2);
          }
        }, _callee12);
      }))();
    }
  },
  validations: {
    companyDetails: {
      name: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        }),
        companynameUnique: companynameUnique
      },
      abn: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      companyRegisteredId: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        }),
        companyRegisteredIdUnique: companyRegisteredIdUnique
      }
    },
    user: {
      email: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      username: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      password: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_35__["requiredIf"])(function (model) {
          return model.isNew == true;
        }),
        validatePassword: validatePassword
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this9 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_5__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().m(function _callee13() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])().w(function (_context13) {
        while (1) switch (_context13.n) {
          case 0:
            _this9.disableAutoUpdate();
            _this9.toastNotificationEnabled = true;
            _context13.n = 1;
            return _this9.updateCompanyDetails(_this9.companyDetails);
          case 1:
            _this9.clearSnapshots();
            _this9.toastNotificationEnabled = false;
            next();
          case 2:
            return _context13.a(2);
        }
      }, _callee13);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _components_Address_GoogleAutocomplete__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/Address/GoogleAutocomplete */ "./src/components/Address/GoogleAutocomplete.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");



















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyAssetAddresses',
  components: {
    GoogleAutocomplete: _components_Address_GoogleAutocomplete__WEBPACK_IMPORTED_MODULE_17__["default"]
  },
  props: {
    addresses: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    countryCode: {
      type: String | null,
      default: undefined
    }
  },
  data: function data() {
    return {
      googleApi: {
        mapUrl: 'https://maps.googleapis.com/maps/api/js',
        mapKey: "AIzaSyCK26bFvsJ1lo1dZ10WBFXA74yU-pc7CuI",
        mapLibraries: 'places',
        mapCallback: 'initMap',
        mapStatus: null,
        bounds: null
      }
    };
  },
  computed: {
    addressTypes: function addressTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_18__["AddressTypes"];
    },
    existedAddressTypes: function existedAddressTypes() {
      return this.addresses.map(function (address) {
        return address.type;
      });
    },
    googleMapAutoCompleteCountryCode: function googleMapAutoCompleteCountryCode() {
      if (this.countryCode) {
        return this.countryCode;
      }
      return this.$company.info.countryCode;
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  created: function created() {
    this.initGoogleMapApi();
  },
  methods: {
    addTmpAddress: function addTmpAddress() {
      this.$emit('addTmpAddress');
    },
    initGoogleMapApi: function initGoogleMapApi() {
      var vm = this;
      window.initMap = function () {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function (position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new window.google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            vm.googleApi.bounds = circle.getBounds();
          });
        }
        vm.googleApi.mapStatus = 'AddressDetail';
      };
      if (!window.google) {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = "".concat(this.googleApi.mapUrl, "?key=").concat(this.googleApi.mapKey, "&libraries=").concat(this.googleApi.mapLibraries, "&callback=").concat(this.googleApi.mapCallback);
        document.body.appendChild(script);
      } else {
        window.initMap();
      }
    },
    removeAddress: function removeAddress(assetAddress) {
      this.$emit('removeAddress', assetAddress);
    },
    setDefault: function setDefault(assetAddress) {
      this.$emit('setDefault', assetAddress, 'assetAddresses');
    }
  },
  validations: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_16__["default"]), {}, {
    uniqueAddressType: function uniqueAddressType() {
      return new Set(this.existedAddressTypes).size == this.existedAddressTypes.length;
    }
  })
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyAssetEmails',
  props: {
    emails: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  computed: {
    emailTypes: function emailTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_16__["EmailTypes"];
    },
    existedEmailTypes: function existedEmailTypes() {
      return this.emails.map(function (email) {
        return email.type;
      });
    }
  },
  watch: {
    emails: {
      handler: function handler() {
        this.$emit('validationChanged', this.hasAnyValidationError());
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addTmpEmail: function addTmpEmail() {
      this.$emit('addTmpEmail');
    },
    removeEmail: function removeEmail(assetEmail) {
      this.$emit('removeEmail', assetEmail);
    },
    setDefault: function setDefault(assetEmail) {
      this.$emit('setDefault', assetEmail, 'assetEmails');
    },
    hasAnyValidationError: function hasAnyValidationError() {
      return this.$v.$error || !this.$v.uniqueEmailType || this.$v.emails.$error;
    }
  },
  validations: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_15__["default"]), {}, {
    uniqueEmailType: function uniqueEmailType() {
      return new Set(this.existedEmailTypes).size == this.existedEmailTypes.length;
    }
  })
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyAssetPhones',
  props: {
    phones: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  computed: {
    phoneTypes: function phoneTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_16__["PhoneTypes"];
    },
    existedPhoneTypes: function existedPhoneTypes() {
      return this.phones.map(function (phone) {
        return phone.type;
      });
    }
  },
  watch: {
    phones: {
      handler: function handler() {
        this.$emit('validationChanged', this.hasAnyValidationError());
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addTmpPhone: function addTmpPhone() {
      this.$emit('addTmpPhone');
    },
    removePhone: function removePhone(assetPhone) {
      this.$emit('removePhone', assetPhone);
    },
    setDefault: function setDefault(assetPhone) {
      this.$emit('setDefault', assetPhone, 'assetPhones');
    },
    hasAnyValidationError: function hasAnyValidationError() {
      return this.$v.$error || !this.$v.uniquePhoneType || this.$v.phones.$error;
    }
  },
  validations: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_15__["default"]), {}, {
    uniquePhoneType: function uniquePhoneType() {
      return new Set(this.existedPhoneTypes).size == this.existedPhoneTypes.length;
    }
  })
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _contact_ContactService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../contact/ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var _ContactModal_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ContactModal.vue */ "./src/views/companysetting/assets/ContactModal.vue");















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyContact',
  components: {
    ContactModal: _ContactModal_vue__WEBPACK_IMPORTED_MODULE_14__["default"]
  },
  props: {
    contacts: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    companyId: {
      type: String,
      default: null
    }
  },
  data: function data() {
    return {
      companyContact: null,
      showContactModal: false,
      editingContactIndex: null
    };
  },
  computed: {},
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    addContact: function addContact(contact) {
      if (this.editingContactIndex !== null) {
        // this.$set(this.contacts[this.editingContactIndex], 'contact', contact)
        this.$set(this.contacts, this.editingContactIndex, contact);
        this.editingContactIndex = null;
        contact.id = contact.contactId;
        this.updateContacts(contact);
      } else {
        this.$emit('addContact', contact);
      }
      this.showContactModal = false;
    },
    editContact: function editContact(contact, index) {
      this.companyContact = JSON.parse(JSON.stringify(contact));
      this.editingContactIndex = index;
      this.showContactModal = true;
    },
    removeContact: function removeContact(contact) {
      this.$emit('removeContact', contact);
    },
    setDefault: function setDefault(contact) {
      var _this = this;
      this.$emit('setDefault', contact, 'contacts');
      if (Array.isArray(this.contacts)) {
        this.contacts.forEach(function (c) {
          if (c === contact) {
            if (Array.isArray(c.emails)) {
              c.emails.forEach(function (email, idx) {
                email.isDefault = idx === 0;
              });
            }
            if (Array.isArray(c.addresses)) {
              c.addresses.forEach(function (address, idx) {
                address.isDefault = idx === 0;
              });
            }
            if (Array.isArray(c.phones)) {
              c.phones.forEach(function (phone, idx) {
                phone.isDefault = idx === 0;
              });
            }
          } else if (c) {
            if (Array.isArray(c.emails)) {
              c.emails.forEach(function (email) {
                email.isDefault = false;
              });
            }
            if (Array.isArray(c.addresses)) {
              c.addresses.forEach(function (address) {
                address.isDefault = false;
              });
            }
            if (Array.isArray(c.phones)) {
              c.phones.forEach(function (phone) {
                phone.isDefault = false;
              });
            }
          }
          c.id = c.contactId;
          _this.updateContacts(c);
        });
      }
    },
    addNewContact: function addNewContact() {
      var _this2 = this;
      _contact_ContactService__WEBPACK_IMPORTED_MODULE_13__["default"].getNewAssetContact('Company', _components_Guid__WEBPACK_IMPORTED_MODULE_12__["default"].newGuid()).then(function (response) {
        var newContact = response.data;
        var newMap = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_11__["ContactModel"](newContact.id, newContact.firstName, newContact.lastName);
        newMap.isNew = true;
        if (_this2.$parent) {
          if (Array.isArray(_this2.$parent.companyDetails.assetAddresses)) {
            var defaultAddress = _this2.$parent.companyDetails.assetAddresses.find(function (a) {
              return a.isDefault;
            });
            if (defaultAddress) {
              newMap.addresses = [JSON.parse(JSON.stringify(defaultAddress))];
              newMap.addresses[0].isDefault = true;
              newMap.addresses[0].isNew = true;
              newMap.addresses[0].id = _components_Guid__WEBPACK_IMPORTED_MODULE_12__["default"].empty();
            }
          }
          if (Array.isArray(_this2.$parent.companyDetails.assetPhones)) {
            var defaultPhone = _this2.$parent.companyDetails.assetPhones.find(function (a) {
              return a.isDefault;
            });
            if (defaultPhone) {
              newMap.phones = [JSON.parse(JSON.stringify(defaultPhone))];
              newMap.phones[0].isDefault = true;
              newMap.phones[0].isNew = true;
              newMap.phones[0].id = _components_Guid__WEBPACK_IMPORTED_MODULE_12__["default"].empty();
            }
          }
          if (Array.isArray(_this2.$parent.companyDetails.assetEmails)) {
            var defaultEmail = _this2.$parent.companyDetails.assetEmails.find(function (a) {
              return a.isDefault;
            });
            if (defaultEmail) {
              newMap.emails = [JSON.parse(JSON.stringify(defaultEmail))];
              newMap.emails[0].isDefault = true;
              newMap.emails[0].isNew = true;
              newMap.emails[0].id = _components_Guid__WEBPACK_IMPORTED_MODULE_12__["default"].empty();
            }
          }
        }
        var anyDefault = _this2.contacts && _this2.contacts.find(function (d) {
          return !d.isDeleted && d.isDefault;
        });
        if (!anyDefault) {
          newMap.isDefault = true;
        }
        _this2.companyContact = newMap;
        _this2.companyContact.companyId = _this2.companyId;
      });
      this.showContactModal = true;
    },
    updateContacts: function updateContacts(contact) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _contact_ContactService__WEBPACK_IMPORTED_MODULE_13__["default"].putContact(contact);
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    }
  },
  validations: {
    contacts: {
      $each: {
        firstName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_10__["required"]
        },
        lastName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_10__["required"]
        }
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../enums */ "./src/enums/index.js");
/* harmony import */ var _CompanyAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./CompanyAssetAddresses.vue */ "./src/views/companysetting/assets/CompanyAssetAddresses.vue");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _CompanyAssetPhones_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./CompanyAssetPhones.vue */ "./src/views/companysetting/assets/CompanyAssetPhones.vue");
/* harmony import */ var _CompanyAssetEmails_vue__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./CompanyAssetEmails.vue */ "./src/views/companysetting/assets/CompanyAssetEmails.vue");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var _views_recurringremarks_RecurringRemarkModal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/views/recurringremarks/RecurringRemarkModal */ "./src/views/recurringremarks/RecurringRemarkModal.vue");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__);




















var RecurringRemarkComponent = vue__WEBPACK_IMPORTED_MODULE_17__["default"].extend(_views_recurringremarks_RecurringRemarkModal__WEBPACK_IMPORTED_MODULE_18__["default"]);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ContactModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__["BaseModalEx"],
    CompanyAssetAddresses: _CompanyAssetAddresses_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    CompanyAssetPhones: _CompanyAssetPhones_vue__WEBPACK_IMPORTED_MODULE_15__["default"],
    CompanyAssetEmails: _CompanyAssetEmails_vue__WEBPACK_IMPORTED_MODULE_16__["default"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    contact: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    return {
      cardModal: null,
      refsHasError: false
    };
  },
  computed: {
    salutes: function salutes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["Salutation"];
    },
    sortedAddresses: function sortedAddresses() {
      if (this.contact && this.contact.addresses) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.addresses).sort(function (a, b) {
          return b.isDefault - a.isDefault;
        });
      }
    },
    validationErrors: function validationErrors() {
      return this.$v.contact.$error || this.$refs.assetAddresses && this.$refs.assetAddresses.$v && this.$refs.assetAddresses.$v.$error || this.$refs.assetPhones && this.$refs.assetPhones.$v && this.$refs.assetPhones.$v.$error || this.$refs.assetEmails && this.$refs.assetEmails.$v && this.$refs.assetEmails.$v.$error || this.refsHasError;
    },
    activePhones: function activePhones() {
      if (this.contact && this.contact.phones) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.phones).filter(function (a) {
          return !a.isDeleted;
        });
      }
    },
    activeEmails: function activeEmails() {
      if (this.contact && this.contact.emails) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.contact.emails).filter(function (a) {
          return !a.isDeleted;
        });
      }
    }
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  methods: {
    close: function close() {
      this.$emit('close');
    },
    save: function save() {
      this.$emit('save', this.contact);
    },
    setDefault: function setDefault(asset, assetType) {
      var typeMap = {
        assetEmails: 'emails',
        assetPhones: 'phones',
        assetAddresses: 'addresses'
      };
      var key = typeMap[assetType] || assetType;
      if (this.contact[key] && Array.isArray(this.contact[key])) {
        this.contact[key].forEach(function (a) {
          a.isDefault = a === asset;
        });
      }
      // this.contact[assetType].forEach((a) => (a.isDefault = a == asset))
    },
    addTmpAddress: function addTmpAddress() {
      var newAddress = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["AddressModel"](this.contact.companyId);
      if (this.contact.addresses.length == 0) {
        newAddress.isDefault = true;
        newAddress.isNew = true;
      }
      this.contact.addresses.push(newAddress);
    },
    addTmpPhone: function addTmpPhone() {
      var newPhone = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["PhoneModel"]();
      if (this.contact.phones.length == 0) {
        newPhone.isDefault = true;
        newPhone.isNew = true;
      }
      this.contact.phones.push(newPhone);
    },
    addTmpEmail: function addTmpEmail() {
      var newEmail = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_14__["EmailModel"]();
      if (this.contact.emails.length == 0) {
        newEmail.isDefault = true;
        newEmail.isNew = true;
      }
      this.contact.emails.push(newEmail);
    },
    removeAddress: function removeAddress(address) {
      // this.contact.addresses = this.contact.addresses.filter((a) => a !== address)
      var idx = this.contact.addresses.findIndex(function (a) {
        return a === address;
      });
      if (idx !== -1) {
        if (!address.isNew && address.id) {
          this.contact.addresses[idx].isDeleted = true;
        } else {
          this.contact.addresses.splice(idx, 1);
        }
      }
    },
    removePhone: function removePhone(phone) {
      //this.contact.phones = this.contact.phones.filter((p) => p !== phone)
      var idx = this.contact.phones.findIndex(function (a) {
        return a === phone;
      });
      if (idx !== -1) {
        if (!phone.isNew && phone.id) {
          this.contact.phones[idx].isDeleted = true;
        } else {
          this.contact.phones.splice(idx, 1);
        }
      }
    },
    removeEmail: function removeEmail(email) {
      // this.contact.emails = this.contact.emails.filter((e) => e !== email)
      var idx = this.contact.emails.findIndex(function (a) {
        return a === email;
      });
      if (idx !== -1) {
        if (!email.isNew && email.id) {
          this.contact.emails[idx].isDeleted = true;
        } else {
          this.contact.emails.splice(idx, 1);
        }
      }
    },
    showRecurringRemark: function showRecurringRemark() {
      var _this = this;
      this.cardModal = new RecurringRemarkComponent({
        el: document.createElement('div'),
        propsData: {
          visible: false
        }
      }).$on('ok', function (res) {
        _this.contact.remarks.remarks = res + '\n' + _this.contact.remarks.remarks;
        _this.contact.remarks.isDirty = true;
      });
      this.cardModal.visible = true;
    },
    onRefsValidationChanged: function onRefsValidationChanged(hasError) {
      this.refsHasError = hasError;
    }
  },
  validations: function validations() {
    return {
      contact: {
        firstName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
        },
        lastName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RecurringRemarkService */ "./src/views/recurringremarks/RecurringRemarkService.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_10__);











/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    CardModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__["CardModal"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_9__["BulmaAutocomplete"]
  },
  props: {
    visible: Boolean
  },
  data: function data() {
    return {
      searchValue: '',
      selectedValue: '',
      options: [],
      isLoading: false,
      isNew: false
    };
  },
  computed: {
    notFoundMessage: function notFoundMessage() {
      if (this.searchValue === '') {
        return 'No results';
      } else {
        return 'Remark not found. You can save this remark with the save button.';
      }
    },
    message: function message() {
      if (this.searchValue === '') {
        return 'Start typing to search for a remark';
      } else if (this.isNew) {
        return 'Save and use this remark';
      } else {
        return 'Use this remark';
      }
    }
  },
  mounted: function mounted() {
    setTimeout(function () {
      document.getElementById('searcher').focus();
    }, 500);
  },
  methods: {
    close: function close() {
      // If this is not here
      // Dialog will not show up if [x] or outside of modal is clicked
      this.visible = false;
    },
    ok: function ok() {
      if (this.searchValue) {
        if (this.isNew) {
          _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__["default"].postRecurringRemark(this.searchValue);
        }
        this.$emit('ok', this.searchValue);
        this.visible = false;
      } else {
        this.cancel();
      }
    },
    cancel: function cancel() {
      this.visible = false;
    },
    search: lodash_debounce__WEBPACK_IMPORTED_MODULE_10___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(key) {
        var res;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              console.log("search ".concat(key, " - ").concat(this.selectedValue));
              if (!(key === this.selectedValue)) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              this.isNew = true;
              this.isLoading = true;
              _context.n = 2;
              return _RecurringRemarkService__WEBPACK_IMPORTED_MODULE_7__["default"].getRecurringRemark(key);
            case 2:
              res = _context.v;
              this.options = res.data.result.map(function (d) {
                return d.remarkDescription;
              });
              this.isLoading = false;
            case 3:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    select: function select(val) {
      if (val) {
        this.isNew = false;
        this.selectedValue = val;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator || _vm.$userInfo.isSystemAdministrator ? _c("div", [_c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_vm._m(0), !_vm.hasError && _vm.showSavingStatus && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.name,
      expression: "companyDetails.name"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      disabled: !_vm.$userInfo.isSystemAccount
    },
    domProps: {
      value: _vm.companyDetails.name
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyDetails, "name", $event.target.value);
      }
    }
  }), !_vm.$v.companyDetails.name.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Name is required ")]) : _vm._e(), !_vm.$v.companyDetails.name.companynameUnique ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Company name is already in use. ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ABN")]), _c("div", {
    staticClass: "control"
  }, [_vm.companyDetails.countryCode === "AU" ? _c("the-mask", {
    staticClass: "input",
    attrs: {
      mask: ["## ### ### ###"],
      disabled: !_vm.$userInfo.isSystemAccount
    },
    model: {
      value: _vm.companyDetails.abn,
      callback: function callback($$v) {
        _vm.$set(_vm.companyDetails, "abn", $$v);
      },
      expression: "companyDetails.abn"
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.abn,
      expression: "companyDetails.abn"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      disabled: !_vm.$userInfo.isSystemAccount
    },
    domProps: {
      value: _vm.companyDetails.abn
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyDetails, "abn", $event.target.value);
      }
    }
  }), !_vm.$v.companyDetails.abn.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ABN is required ")]) : _vm._e()], 1)])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Customer Since")]), !_vm.$userInfo.isSystemAccount ? _c("input", {
    staticClass: "input",
    attrs: {
      disabled: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerCustomerSince, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "max-date": _vm.today,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.customerSinceInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Customer Since"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("span", {
          staticClass: "mso mso-18px"
        }, [_vm._v("calendar_month")])])])])];
      }
    }], null, false, 2470198337),
    model: {
      value: _vm.innerCustomerSince,
      callback: function callback($$v) {
        _vm.innerCustomerSince = $$v;
      },
      expression: "innerCustomerSince"
    }
  })], 1), _c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Registered ID")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.companyRegisteredId,
      expression: "companyDetails.companyRegisteredId"
    }],
    staticClass: "input",
    attrs: {
      type: "number",
      maxlength: "6",
      disabled: !_vm.$userInfo.isSystemAccount
    },
    domProps: {
      value: _vm.companyDetails.companyRegisteredId
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyDetails, "companyRegisteredId", $event.target.value);
      }, _vm.onRegisteredIdInput],
      keydown: _vm.preventNonDigit
    }
  }), !_vm.$v.companyDetails.companyRegisteredId.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Registered ID is required ")]) : _vm._e(), !_vm.$v.companyDetails.companyRegisteredId.companyRegisteredIdUnique ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Registered ID is already in use. ")]) : _vm._e()])])]), !_vm.$userInfo.isSupportUser && _vm.$userInfo.isSystemAdministrator && !_vm.companyDetails.isHq && !_vm.isHQ ? _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("HQ Company")]), _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      placeholder: "HQ Company",
      data: _vm.hqCompanyNoOptions,
      field: "companyLoginId",
      loading: _vm.hqCompanyNoLoading
    },
    on: {
      typing: _vm.onHqCompanyNoTyping,
      select: function select($event) {
        return _vm.onHqSelected($event);
      }
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_vm._v(" " + _vm._s("".concat(props.option.companyLoginId)) + " ")];
      }
    }], null, false, 278785023),
    model: {
      value: _vm.selectedHqCompanyNo,
      callback: function callback($$v) {
        _vm.selectedHqCompanyNo = $$v;
      },
      expression: "selectedHqCompanyNo"
    }
  })], 1)]), _c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Parent Company Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.parentCompanyName,
      expression: "companyDetails.parentCompanyName"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      disabled: true
    },
    domProps: {
      value: _vm.companyDetails.parentCompanyName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyDetails, "parentCompanyName", $event.target.value);
      }
    }
  })])])]) : _vm._e(), _c("hr"), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pt-0 mt-3"
  }, [_c("div", {
    staticClass: "mb-5"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Country")]), _c("div", {
    staticClass: "control tooltip",
    attrs: {
      "data-tooltip": "Country of Default Address"
    }
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.countryCode,
      expression: "companyDetails.countryCode"
    }],
    attrs: {
      disabled: !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companyDetails, "countryCode", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.countries, function (country) {
    return _c("option", {
      key: country.countryCode,
      domProps: {
        value: country.countryCode
      }
    }, [_vm._v(" " + _vm._s(country.countryDesc) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "mb-5"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Time Zone")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.timezone,
      expression: "companyDetails.timezone"
    }],
    attrs: {
      disabled: !_vm.companyDetails.countryCode || !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companyDetails, "timezone", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.timezones, function (timezone) {
    return _c("option", {
      key: timezone.Id,
      domProps: {
        value: timezone.DisplayName
      }
    }, [_vm._v(" " + _vm._s(timezone.DisplayName) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "mb-5"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Locale")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyDetails.locale,
      expression: "companyDetails.locale"
    }],
    attrs: {
      disabled: !_vm.companyDetails.countryCode || !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companyDetails, "locale", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.locales, function (locale, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: locale
      }
    }, [_vm._v(" " + _vm._s(locale) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "is-divider-vertical p-0"
  }), _c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("company-asset-addresses", {
    ref: "assetAddresses",
    attrs: {
      addresses: _vm.sortedAddresses,
      "country-code": _vm.companyDetails.countryCode
    },
    on: {
      removeAddress: _vm.removeAddress,
      setDefault: _vm.setDefault,
      addTmpAddress: _vm.addTmpAddress
    }
  })], 1)])]), _c("hr"), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("company-asset-phones", {
    ref: "assetPhones",
    attrs: {
      phones: _vm.sortedPhones
    },
    on: {
      removePhone: _vm.removePhone,
      setDefault: _vm.setDefault,
      addTmpPhone: _vm.addTmpPhone
    }
  })], 1), _c("div", {
    staticClass: "column is-half"
  }, [_c("company-asset-emails", {
    ref: "assetEmails",
    attrs: {
      emails: _vm.sortedEmails
    },
    on: {
      removeEmail: _vm.removeEmail,
      setDefault: _vm.setDefault,
      addTmpEmail: _vm.addTmpEmail
    }
  })], 1)]), _c("div", {
    staticClass: "field columns mb-2"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_vm.$userInfo.isSystemAccount || _vm.$userInfo.isSystemAdministrator ? _c("company-contact", {
    ref: "assetContacts",
    attrs: {
      contacts: _vm.companyDetails.contacts,
      "company-id": _vm.companyDetails.companyId
    },
    on: {
      addContact: _vm.addContact,
      removeContact: _vm.removeContact,
      setDefault: _vm.setDefault
    }
  }) : _vm._e()], 1)]), _vm.$userInfo.isSystemAccount && !_vm.isNew ? _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Reset User Password")]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Reset Password"
    },
    on: {
      click: _vm.resetPassword
    }
  }, [_c("span", [_vm._v("Reset Password")])])])]) : _vm._e(), _vm.$userInfo.isSystemAccount ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _vm.$userInfo.isSystemAccount ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": _vm.companyDetails.isActive
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": !_vm.companyDetails.isActive
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("In-Active")])])])]) : _vm._e()])]), _vm.$userInfo.isSystemAdministrator && _vm.isNew && _vm.user ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(3), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Email")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.user.email,
      expression: "user.email"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      autocomplete: "new-email"
    },
    domProps: {
      value: _vm.user.email
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.user, "email", $event.target.value);
      }
    }
  }), !_vm.$v.user.email.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Email is required ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Username")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.user.username,
      expression: "user.username"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      autocomplete: "new-username"
    },
    domProps: {
      value: _vm.user.username
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.user, "username", $event.target.value);
      }
    }
  }), !_vm.$v.user.username.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Username is required ")]) : _vm._e()])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Password")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [(_vm.showPassword ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.user.password,
      expression: "user.password"
    }],
    staticClass: "input",
    attrs: {
      autocomplete: "new-password",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.user.password) ? _vm._i(_vm.user.password, null) > -1 : _vm.user.password
    },
    on: {
      change: function change($event) {
        var $$a = _vm.user.password,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.user, "password", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.user, "password", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.user, "password", $$c);
        }
      }
    }
  }) : (_vm.showPassword ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.user.password,
      expression: "user.password"
    }],
    staticClass: "input",
    attrs: {
      autocomplete: "new-password",
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.user.password, null)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.user, "password", null);
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.user.password,
      expression: "user.password"
    }],
    staticClass: "input",
    attrs: {
      autocomplete: "new-password",
      type: _vm.showPassword ? "text" : "password"
    },
    domProps: {
      value: _vm.user.password
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.user, "password", $event.target.value);
      }
    }
  }), !_vm.$v.user.password.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Password is required ")]) : _vm._e(), !_vm.$v.user.password.validatePassword ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v(" " + _vm._s(_vm.passwordMessage) + " ")]) : _vm._e()]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        _vm.showPassword = !_vm.showPassword;
      }
    }
  }, [_c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" " + _vm._s(_vm.showPassword ? "visibility" : "visibility_off") + " ")])])])])])])])])]) : _vm._e()]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Default Administrator")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Addresses")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.addresses.length < 3,
      expression: "addresses.length < 3"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      disabled: !_vm.countryCode || !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
    },
    on: {
      click: _vm.addTmpAddress
    }
  }, [_vm._m(0)])]), _vm._l(_vm.addresses, function (address, index) {
    return _c("div", {
      key: index,
      staticClass: "pb-4"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("p", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: address.type,
        expression: "address.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: !_vm.$v.uniqueAddressType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: !$v.uniqueAddressType }"
      }],
      class: {
        "is-invalid": !_vm.$v.uniqueAddressType
      },
      attrs: {
        disabled: !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(address, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.addressTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: typeIndex
        }
      }, [_vm._v(" " + _vm._s(type) + " ")]);
    }), 0)])]), _c("p", {
      staticClass: "control is-expanded"
    }, [_vm.googleApi.mapStatus ? _c("google-autocomplete", {
      attrs: {
        disabled: !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator,
        bounds: _vm.googleApi.bounds,
        id: "address" + index,
        address: address,
        v: _vm.$v.addresses.$each[index],
        "show-address3": true,
        "country-code": _vm.googleMapAutoCompleteCountryCode
      }
    }) : _vm._e()], 1), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        disabled: _vm.addresses.length == 1 && address.isDefault || !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(address);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [address.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      attrs: {
        disabled: _vm.addresses.length == 1 || address.isDefault || !_vm.$userInfo.isSupportUser && !_vm.$userInfo.isSystemAdministrator
      },
      on: {
        click: function click($event) {
          return _vm.removeAddress(address);
        }
      }
    }, [_vm._m(1, true)])])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" remove ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Emails")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.emails.length < 2,
      expression: "emails.length < 2"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      disabled: !_vm.$userInfo.isSystemAccount
    },
    on: {
      click: _vm.addTmpEmail
    }
  }, [_vm._m(0)])]), _vm._l(_vm.emails, function (assetEmail, index) {
    return _c("div", {
      key: index,
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetEmail.type,
        expression: "assetEmail.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: !_vm.$v.uniqueEmailType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: !$v.uniqueEmailType }"
      }],
      class: {
        "is-invalid": !_vm.$v.uniqueEmailType
      },
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(assetEmail, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.emailTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: type.toString()
        },
        on: {
          change: function change($event) {
            return _vm.$v.emails.types.touch();
          }
        }
      }, [_vm._v(" " + _vm._s(typeIndex) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetEmail.address,
        expression: "assetEmail.address"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        disabled: !_vm.$userInfo.isSystemAccount
      },
      domProps: {
        value: assetEmail.address
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(assetEmail, "address", $event.target.value);
        }, function ($event) {
          return _vm.$v.emails.$each[index].address.$touch();
        }]
      }
    }), !_vm.$v.emails.$each[index].address.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Email is required")]) : _vm._e(), !_vm.$v.emails.$each[index].address.email ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Please enter a valid email")]) : _vm._e()]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        title: [assetEmail.isDefault ? "Default Email" : ""],
        disabled: !_vm.$userInfo.isSystemAccount || _vm.emails.length == 1 && assetEmail.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(assetEmail);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [assetEmail.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount || assetEmail.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.removeEmail(assetEmail);
        }
      }
    }, [_vm._m(1, true)])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" remove ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Phones")]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.phones.length < 4,
      expression: "phones.length < 4"
    }],
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      disabled: !_vm.$userInfo.isSystemAccount
    },
    on: {
      click: _vm.addTmpPhone
    }
  }, [_vm._m(0)])]), _vm._l(_vm.phones, function (assetPhone, index) {
    return _c("div", {
      key: index,
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetPhone.type,
        expression: "assetPhone.type"
      }, {
        name: "tippy",
        rawName: "v-tippy",
        value: {
          content: "Duplicate Type",
          theme: "danger",
          enabled: !_vm.$v.uniquePhoneType
        },
        expression: "{ content: 'Duplicate Type', theme: 'danger', enabled: !$v.uniquePhoneType }"
      }],
      class: {
        "is-invalid": !_vm.$v.uniquePhoneType
      },
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount
      },
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(assetPhone, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.phoneTypes, function (type, typeIndex) {
      return _c("option", {
        key: typeIndex,
        domProps: {
          value: type.toString()
        },
        on: {
          change: function change($event) {
            return _vm.$v.phones.types.touch();
          }
        }
      }, [_vm._v(" " + _vm._s(typeIndex) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: assetPhone.no,
        expression: "assetPhone.no"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        disabled: !_vm.$userInfo.isSystemAccount
      },
      domProps: {
        value: assetPhone.no
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(assetPhone, "no", $event.target.value);
        }, function ($event) {
          return _vm.$v.phones.$each[index].no.$touch();
        }]
      }
    }), !_vm.$v.phones.$each[index].no.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Phone number is required ")]) : _vm._e()]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        title: [assetPhone.isDefault ? "Default Phone" : ""],
        disabled: !_vm.$userInfo.isSystemAccount || _vm.phones.length == 1 && assetPhone.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(assetPhone);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [assetPhone.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount || assetPhone.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.removePhone(assetPhone);
        }
      }
    }, [_vm._m(1, true)])])]);
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" add ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" remove ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm$contacts;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Contact Person")]), _c("button", {
    staticClass: "button is-small is-primary is-light",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      disabled: !_vm.$userInfo.isSystemAccount
    },
    on: {
      click: _vm.addNewContact
    }
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("add")])]), _vm.companyContact ? _c("ContactModal", {
    attrs: {
      active: _vm.showContactModal,
      contact: _vm.companyContact
    },
    on: {
      close: function close($event) {
        _vm.showContactModal = false;
      },
      save: _vm.addContact
    }
  }) : _vm._e()], 1), _vm.contacts && ((_vm$contacts = _vm.contacts) === null || _vm$contacts === void 0 ? void 0 : _vm$contacts.length) > 0 ? _c("div", [_vm._m(0), _vm._l(_vm.contacts, function (contact, index) {
    return _c("div", {
      key: index,
      staticClass: "field columns is-flex is-align-items-center"
    }, [_c("div", {
      staticClass: "column is-half"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: contact.firstName,
        expression: "contact.firstName"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.contacts.$each[index].firstName.$error
      },
      attrs: {
        type: "text",
        placeholder: "First Name",
        disabled: !_vm.$userInfo.isSystemAccount
      },
      domProps: {
        value: contact.firstName
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(contact, "firstName", $event.target.value);
        }, function ($event) {
          return _vm.$v.contacts.$each[index].$touch();
        }]
      }
    }), !_vm.$v.contacts.$each[index].firstName.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("First Name is required ")]) : _vm._e()])]), _c("div", {
      staticClass: "field has-addons column is-half"
    }, [_c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: contact.lastName,
        expression: "contact.lastName"
      }],
      staticClass: "input",
      class: {
        "is-danger": _vm.$v.contacts.$each[index].lastName.$error
      },
      attrs: {
        type: "text",
        placeholder: "Last Name",
        disabled: !_vm.$userInfo.isSystemAccount
      },
      domProps: {
        value: contact.lastName
      },
      on: {
        input: [function ($event) {
          if ($event.target.composing) return;
          _vm.$set(contact, "lastName", $event.target.value);
        }, function ($event) {
          return _vm.$v.contacts.$each[index].lastName.$touch();
        }]
      }
    }), !_vm.$v.contacts.$each[index].lastName.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Last Name is required ")]) : _vm._e()]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-gold",
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount
      },
      on: {
        click: function click($event) {
          return _vm.setDefault(contact, "contacts");
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("span", {
      staticClass: "mso mso-24px",
      class: [contact.isDefault ? "mso-fill" : ""]
    }, [_vm._v(" star ")])])])]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-primary",
      on: {
        click: function click($event) {
          return _vm.editContact(contact, index);
        }
      }
    }, [_vm._m(1, true)])]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      attrs: {
        disabled: !_vm.$userInfo.isSystemAccount
      },
      on: {
        click: function click($event) {
          return _vm.removeContact(contact);
        }
      }
    }, [_vm._m(2, true)])])])]);
  })], 2) : _c("div", {
    staticClass: "label has-text-weight-normal ml-1"
  }, [_vm._v("No Contacts")])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field columns mb-0"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("First Name")])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Last Name")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" edit ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("remove")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7 ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm$sortedAddresses$c, _vm$sortedAddresses;
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.active,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 80,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.active = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Contacts")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-two-thirds"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Title")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.title,
      expression: "contact.title"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.contact, "title", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.salutes, function (name, code) {
    return _c("option", {
      key: code,
      domProps: {
        value: name
      }
    }, [_vm._v(" " + _vm._s(name) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("First Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.firstName,
      expression: "contact.firstName"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.contact.firstName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.contact.firstName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact, "firstName", $event.target.value);
      }, function ($event) {
        return _vm.$v.contact.firstName.$touch();
      }]
    }
  }), !_vm.$v.contact.firstName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("First Name is required")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Last Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.lastName,
      expression: "contact.lastName"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.contact.lastName.$error
    },
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.contact.lastName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact, "lastName", $event.target.value);
      }, function ($event) {
        return _vm.$v.contact.lastName.$touch();
      }]
    }
  }), !_vm.$v.contact.lastName.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Last Name is required")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("company-asset-addresses", {
    ref: "assetAddresses",
    attrs: {
      addresses: _vm.contact.addresses,
      "country-code": (_vm$sortedAddresses$c = (_vm$sortedAddresses = _vm.sortedAddresses) === null || _vm$sortedAddresses === void 0 ? void 0 : _vm$sortedAddresses.countryCode) !== null && _vm$sortedAddresses$c !== void 0 ? _vm$sortedAddresses$c : null
    },
    on: {
      removeAddress: _vm.removeAddress,
      setDefault: _vm.setDefault,
      addTmpAddress: _vm.addTmpAddress
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("company-asset-phones", {
    ref: "assetPhones",
    attrs: {
      phones: _vm.activePhones
    },
    on: {
      removePhone: _vm.removePhone,
      setDefault: _vm.setDefault,
      addTmpPhone: _vm.addTmpPhone,
      validationChanged: _vm.onRefsValidationChanged
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("company-asset-emails", {
    ref: "assetEmails",
    attrs: {
      emails: _vm.activeEmails
    },
    on: {
      removeEmail: _vm.removeEmail,
      setDefault: _vm.setDefault,
      addTmpEmail: _vm.addTmpEmail,
      validationChanged: _vm.onRefsValidationChanged
    }
  })], 1)]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Contents")]), _c("p", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.remarks.remarks,
      expression: "contact.remarks.remarks"
    }],
    staticClass: "textarea",
    domProps: {
      value: _vm.contact.remarks.remarks
    },
    on: {
      change: function change($event) {
        _vm.contact.remarks.isDirty = true;
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.contact.remarks, "remarks", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary",
    on: {
      click: _vm.showRecurringRemark
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-repeat"
  })]), _c("span", [_vm._v(" Recurring Remarks")])])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Alert?")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.contact.isAlert,
      expression: "contact.isAlert"
    }],
    staticClass: "switch is-rounded",
    attrs: {
      id: "alert",
      name: "alert",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.contact.isAlert) ? _vm._i(_vm.contact.isAlert, null) > -1 : _vm.contact.isAlert
    },
    on: {
      change: function change($event) {
        var $$a = _vm.contact.isAlert,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.contact, "isAlert", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.contact, "isAlert", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.contact, "isAlert", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "alert"
    }
  })])])])])]), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button tooltip is-primary",
    attrs: {
      "data-tooltip": "Save",
      disabled: _vm.validationErrors
    },
    on: {
      click: _vm.save
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px mso-fill"
  }, [_vm._v(" save ")])]), _c("span", [_vm._v("Save")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: _vm.close
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-20px"
  }, [_vm._v(" close ")])]), _c("span", [_vm._v("Cancel")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242 ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("card-modal", {
    attrs: {
      visible: _vm.visible,
      title: "Recurring Remarks"
    },
    on: {
      ok: _vm.ok,
      close: _vm.close,
      cancel: _vm.cancel
    }
  }, [_c("div", {
    staticClass: "content",
    staticStyle: {
      height: "10em",
      overflow: "hidden"
    }
  }, [_c("div", {
    staticClass: "field"
  }, [_c("p", {
    staticClass: "control is-expanded"
  }, [_c("bulma-autocomplete", {
    ref: "searcher",
    attrs: {
      id: "searcher",
      data: _vm.options,
      loading: _vm.isLoading
    },
    on: {
      input: _vm.search,
      select: _vm.select
    },
    model: {
      value: _vm.searchValue,
      callback: function callback($$v) {
        _vm.searchValue = $$v;
      },
      expression: "searchValue"
    }
  }), _c("span", {
    staticClass: "help is-info"
  }, [_vm._v(_vm._s(_vm.message))])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\ninput[type='number']::-webkit-outer-spin-button,\ninput[type='number']::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("845e0f3a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/validateForms/Address.js":
/*!*********************************************!*\
  !*** ./src/assets/validateForms/Address.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  addresses: {
    $each: {
      address1: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbPostcode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Emails.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Emails.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  emails: {
    $each: {
      address: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["email"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Phones.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Phones.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  phones: {
    $each: {
      no: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/companysetting/CompanyDetailSetting.vue":
/*!***********************************************************!*\
  !*** ./src/views/companysetting/CompanyDetailSetting.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyDetailSetting.vue?vue&type=template&id=541990d8 */ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8");
/* harmony import */ var _CompanyDetailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyDetailSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css */ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CompanyDetailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyDetailSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyDetailSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css":
/*!*******************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=style&index=0&id=541990d8&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_style_index_0_id_541990d8_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8":
/*!*****************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8 ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyDetailSetting.vue?vue&type=template&id=541990d8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyDetailSetting.vue?vue&type=template&id=541990d8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyDetailSetting_vue_vue_type_template_id_541990d8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetAddresses.vue":
/*!*******************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetAddresses.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyAssetAddresses.vue?vue&type=template&id=69c2b716 */ "./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716");
/* harmony import */ var _CompanyAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyAssetAddresses.vue?vue&type=script&lang=js */ "./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CompanyAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/assets/CompanyAssetAddresses.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js":
/*!*******************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetAddresses.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetAddresses_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716":
/*!*************************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716 ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetAddresses.vue?vue&type=template&id=69c2b716 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetAddresses.vue?vue&type=template&id=69c2b716");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetAddresses_vue_vue_type_template_id_69c2b716__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetEmails.vue":
/*!****************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetEmails.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8 */ "./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8");
/* harmony import */ var _CompanyAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyAssetEmails.vue?vue&type=script&lang=js */ "./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CompanyAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/assets/CompanyAssetEmails.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetEmails.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetEmails_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8":
/*!**********************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8 ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetEmails.vue?vue&type=template&id=cf16fbd8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetEmails_vue_vue_type_template_id_cf16fbd8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetPhones.vue":
/*!****************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetPhones.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyAssetPhones.vue?vue&type=template&id=45b838fc */ "./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc");
/* harmony import */ var _CompanyAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyAssetPhones.vue?vue&type=script&lang=js */ "./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CompanyAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/assets/CompanyAssetPhones.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetPhones.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetPhones_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc":
/*!**********************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyAssetPhones.vue?vue&type=template&id=45b838fc */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyAssetPhones.vue?vue&type=template&id=45b838fc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyAssetPhones_vue_vue_type_template_id_45b838fc__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/companysetting/assets/CompanyContact.vue":
/*!************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyContact.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyContact.vue?vue&type=template&id=79aea8cd */ "./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd");
/* harmony import */ var _CompanyContact_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyContact.vue?vue&type=script&lang=js */ "./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CompanyContact_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/assets/CompanyContact.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js":
/*!************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyContact_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyContact.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyContact.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyContact_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd":
/*!******************************************************************************************!*\
  !*** ./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyContact.vue?vue&type=template&id=79aea8cd */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/CompanyContact.vue?vue&type=template&id=79aea8cd");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyContact_vue_vue_type_template_id_79aea8cd__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/companysetting/assets/ContactModal.vue":
/*!**********************************************************!*\
  !*** ./src/views/companysetting/assets/ContactModal.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactModal.vue?vue&type=template&id=2285f1d7 */ "./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7");
/* harmony import */ var _ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactModal.vue?vue&type=script&lang=js */ "./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/assets/ContactModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/ContactModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7 ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactModal.vue?vue&type=template&id=2285f1d7 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/assets/ContactModal.vue?vue&type=template&id=2285f1d7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactModal_vue_vue_type_template_id_2285f1d7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue":
/*!*************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RecurringRemarkModal.vue?vue&type=template&id=19fbb242 */ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242");
/* harmony import */ var _RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RecurringRemarkModal.vue?vue&type=script&lang=js */ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["render"],
  _RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/recurringremarks/RecurringRemarkModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./RecurringRemarkModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242":
/*!*******************************************************************************************!*\
  !*** ./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242 ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./RecurringRemarkModal.vue?vue&type=template&id=19fbb242 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/recurringremarks/RecurringRemarkModal.vue?vue&type=template&id=19fbb242");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecurringRemarkModal_vue_vue_type_template_id_19fbb242__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=10.js.map