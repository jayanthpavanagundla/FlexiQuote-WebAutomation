(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["superadmin-flexiquotemodule-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _components_PermissionTree_vue__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../components/PermissionTree.vue */ "./src/views/superadmin/components/PermissionTree.vue");
/* harmony import */ var _systemmodule_systemModuleService__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../systemmodule/systemModuleService */ "./src/views/superadmin/systemmodule/systemModuleService.js");


























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FlexiquoteModuleDetail',
  inject: {
    $vv: {
      default: null
    }
  },
  components: {
    PermissionTree: _components_PermissionTree_vue__WEBPACK_IMPORTED_MODULE_24__["default"]
  },
  props: {
    value: {
      type: Object,
      default: null
    }
  },
  data: function data() {
    return {
      showAccessibleItems: true,
      permissionRecords: [],
      isResetting: false,
      selectedModulePermissionRecords: []
    };
  },
  computed: {
    entity: {
      get: function get() {
        return this.value;
      },
      set: function set(val) {
        this.$emit('input', val);
      }
    }
  },
  watch: {
    permissionRecords: {
      handler: function handler() {
        if (this.isResetting) return;
        this.syncPermissionRecordsToEntity();
      },
      deep: true
    },
    '$route.params.moduleId': {
      handler: function handler(newModuleId, oldModuleId) {
        var _this = this;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
            while (1) switch (_context.n) {
              case 0:
                if (!(newModuleId && newModuleId !== oldModuleId)) {
                  _context.n = 2;
                  break;
                }
                _this.$showSpinner();
                _context.n = 1;
                return _this.loadModuleData();
              case 1:
                _this.$hideSpinner();
              case 2:
                return _context.a(2);
            }
          }, _callee);
        }))();
      }
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            _this2.$showSpinner();
            _context2.n = 1;
            return _this2.loadModuleData();
          case 1:
            _this2.$hideSpinner();
          case 2:
            return _context2.a(2);
        }
      }, _callee2);
    }))();
  },
  methods: {
    onModDescChange: function onModDescChange() {
      this.$emit('input', this.entity);
    },
    syncPermissionRecordsToEntity: function syncPermissionRecordsToEntity() {
      if (!this.entity) return;
      var activeRecords = this.permissionRecords.filter(function (record) {
        return record.active;
      }).map(function (record) {
        return {
          permissionRecordId: record.permissionRecordID,
          name: record.name
        };
      });
      this.entity.permissionRecords = activeRecords;
      this.$emit('input', this.entity);
    },
    loadModuleData: function loadModuleData() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var _allRecords, _mergedRecords, allRecords, selectedPermissionIds, mergedRecords;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (_this3.entity) {
                _context3.n = 1;
                break;
              }
              return _context3.a(2);
            case 1:
              if (!_this3.entity.isNew) {
                _context3.n = 4;
                break;
              }
              _context3.n = 2;
              return _systemmodule_systemModuleService__WEBPACK_IMPORTED_MODULE_25__["default"].getAllPermissionRecords();
            case 2:
              _allRecords = _context3.v;
              _mergedRecords = _allRecords.map(function (record) {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, record), {}, {
                  active: false
                });
              });
              _this3.isResetting = true;
              _this3.permissionRecords = _mergedRecords;
              _this3.disableNodePermissionAndChildren('Accounts');
              _context3.n = 3;
              return _this3.$nextTick();
            case 3:
              _this3.isResetting = false;
              return _context3.a(2);
            case 4:
              _context3.n = 5;
              return _systemmodule_systemModuleService__WEBPACK_IMPORTED_MODULE_25__["default"].getAllPermissionRecords();
            case 5:
              allRecords = _context3.v;
              _this3.selectedModulePermissionRecords = _this3.entity.permissionRecords || [];
              selectedPermissionIds = new Set(_this3.selectedModulePermissionRecords.map(function (p) {
                return p.permissionRecordId;
              }));
              mergedRecords = allRecords.map(function (record) {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, record), {}, {
                  active: selectedPermissionIds.has(record.permissionRecordID)
                });
              });
              _this3.isResetting = true;
              _this3.permissionRecords = mergedRecords;
              _this3.disableNodePermissionAndChildren('Accounts');
              _context3.n = 6;
              return _this3.$nextTick();
            case 6:
              _this3.isResetting = false;
            case 7:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    disableNodePermissionAndChildren: function disableNodePermissionAndChildren(nodeName) {
      var _this4 = this;
      var parentNode = this.permissionRecords.find(function (record) {
        return record.name === nodeName;
      });
      if (!parentNode) {
        return;
      }
      var _disableRecordAndChildren = function disableRecordAndChildren(parentId) {
        var children = _this4.permissionRecords.filter(function (record) {
          return record.parentID === parentId;
        });
        children.forEach(function (child) {
          _this4.$set(child, 'disabled', true);
          _disableRecordAndChildren(child.permissionRecordID);
        });
      };
      this.$set(parentNode, 'disabled', true);
      _disableRecordAndChildren(parentNode.permissionRecordID);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FlexiquoteModuleListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    filter: null,
    value: null
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1___default()(this.value)
    };
  },
  computed: {},
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _FlexiquoteModuleListSideMenu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./FlexiquoteModuleListSideMenu */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue");
/* harmony import */ var _flexiquoteModuleService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./flexiquoteModuleService */ "./src/views/superadmin/flexiquotemodule/flexiquoteModuleService.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./columns */ "./src/views/superadmin/flexiquotemodule/columns.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./storeMixin */ "./src/views/superadmin/flexiquotemodule/storeMixin.js");
















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FlexiquoteModuleListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_12__["default"],
    FlexiquoteModuleListSideMenu: _FlexiquoteModuleListSideMenu__WEBPACK_IMPORTED_MODULE_10__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_15__["default"]],
  props: {},
  data: function data() {
    return {
      entitySummaries: {},
      totalRows: 0,
      filter: {
        moduleDescription: '',
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_13__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_13__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      },
      selectedRow: null,
      isTableLoading: false
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_13__["Columns"];
    },
    filterKey: function filterKey() {
      return 'flexiquotemodule-list-filter';
    }
  },
  watch: {},
  created: function created() {
    this.getData();
  },
  mounted: function mounted() {},
  destroyed: function destroyed() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    resetList: function resetList() {
      this.filter.moduleDescription = '';
      this.filter.sortColumn = _columns__WEBPACK_IMPORTED_MODULE_13__["Columns"][0].name;
      this.filter.sortOrder = _columns__WEBPACK_IMPORTED_MODULE_13__["Columns"][0].defaultOrder;
      this.filter.pageIndex = 1;
      this.filter.pageSize = 18;
      this.persistFilter();
      this.getData();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getData();
    },
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _this.retrieveFilter();
              _context.n = 1;
              return _flexiquoteModuleService__WEBPACK_IMPORTED_MODULE_11__["default"].getFlexiquoteModules(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    addNew: function addNew() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _this2.addStoreItem();
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./route-types */ "./src/views/superadmin/flexiquotemodule/route-types.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FlexiquoteModuleSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    subModulePages: function subModulePages() {
      return [{
        to: {
          name: _route_types__WEBPACK_IMPORTED_MODULE_2__["default"].FlexiquoteModuleDetail.name
        },
        label: this.entityName || 'FlexiQuote Module',
        isShow: true
      }];
    }
  },
  watch: {},
  created: function created() {},
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _FlexiquoteModuleSideMenu_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./FlexiquoteModuleSideMenu.vue */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./route-types */ "./src/views/superadmin/flexiquotemodule/route-types.js");
/* harmony import */ var _flexiquoteModuleService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./flexiquoteModuleService */ "./src/views/superadmin/flexiquotemodule/flexiquoteModuleService.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storeMixin */ "./src/views/superadmin/flexiquotemodule/storeMixin.js");
/* harmony import */ var _FlexiquoteModuleValidation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./FlexiquoteModuleValidation */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleValidation.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");













/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'FlexiquoteModuleView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_5__["default"],
    FlexiquoteModuleSideMenu: _FlexiquoteModuleSideMenu_vue__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_10__["default"], _FlexiquoteModuleValidation__WEBPACK_IMPORTED_MODULE_11__["default"]],
  data: function data() {
    return {
      entity: null
    };
  },
  computed: {},
  created: function created() {
    this.getEntity();
  },
  methods: {
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _this.$showSpinner();
              _context.p = 1;
              if (reset) {
                _this.clearSnapshots(_this.$route.params.moduleId);
              }
              if (_this.currentSnapshot) {
                _context.n = 2;
                break;
              }
              _context.n = 2;
              return _this.getStoreItem(_this.$route.params.moduleId);
            case 2:
              _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_4___default()(_this.currentSnapshot);
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('', _t);
            case 4:
              _this.$hideSpinner();
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_6__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_6__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_6__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_6__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_6__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    cancel: function cancel() {
      var _this$entity;
      this.clearSnapshots((_this$entity = this.entity) === null || _this$entity === void 0 ? void 0 : _this$entity.flexiQuoteModuleId);
      this.$router.push({
        name: _route_types__WEBPACK_IMPORTED_MODULE_8__["default"].FlexiquoteModuleListView.name
      });
    },
    save: function save() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var title, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              title = 'FlexiQuote Module';
              _this2.$v.$touch();
              if (!_this2.$v.$error) {
                _context2.n = 1;
                break;
              }
              _this2.$notification.openNotificationWithType('danger', title, 'Please fix validation errors before saving');
              return _context2.a(2, false);
            case 1:
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(_this2.entity);
              if (!_this2.entity.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _flexiquoteModuleService__WEBPACK_IMPORTED_MODULE_9__["default"].postEntity(_this2.entity);
            case 2:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 3:
              if (!_this2.snapshotDiff) {
                _context2.n = 5;
                break;
              }
              _context2.n = 4;
              return _flexiquoteModuleService__WEBPACK_IMPORTED_MODULE_9__["default"].putEntity(_this2.entity);
            case 4:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 5:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
              return _context2.a(2, false);
            case 6:
              if (!(response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_12__["default"].NO_CONTENT)) {
                _context2.n = 8;
                break;
              }
              _context2.n = 7;
              return _this2.getEntity(true);
            case 7:
              _this2.$notification.openNotificationWithType('success', title, 'Save successful');
              _context2.n = 9;
              break;
            case 8:
              if (response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_12__["default"].CREATED) {
                _this2.entity.isNew = false;
                _this2.clearSnapshots(_this2.entity.flexiQuoteModuleId);
                _this2.saveSnapshot(_this2.entity);
                _this2.$notification.openNotificationWithType('success', title, 'New module added');
              }
            case 9:
              _this2.$router.push({
                name: _route_types__WEBPACK_IMPORTED_MODULE_8__["default"].FlexiquoteModuleListView.name
              });
              return _context2.a(2, true);
            case 10:
              _context2.p = 10;
              _t2 = _context2.v;
              _this2.$notification.openMessageXhrError('', _t2);
              return _context2.a(2, false);
            case 11:
              _context2.p = 11;
              _this2.$hideSpinner();
              return _context2.f(11);
            case 12:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 10, 11, 12]]);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this$entity2;
    this.clearSnapshots((_this$entity2 = this.entity) === null || _this$entity2 === void 0 ? void 0 : _this$entity2.flexiQuoteModuleId);
    this.setReturnRoute({});
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "is-flex is-align-items-center"
  }, [_vm.entity ? _c("div", {
    staticClass: "field mb-0"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.modDesc,
      expression: "entity.modDesc"
    }],
    staticClass: "input is-size-4 has-text-weight-semibold",
    class: {
      "is-danger": _vm.$vv && _vm.$vv.entity && _vm.$vv.entity.modDesc && _vm.$vv.entity.modDesc.$error
    },
    staticStyle: {
      "max-width": "26rem"
    },
    attrs: {
      type: "text",
      placeholder: "FlexiQuote Module"
    },
    domProps: {
      value: _vm.entity.modDesc
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "modDesc", $event.target.value);
      }, _vm.onModDescChange]
    }
  })]), _vm.$vv && _vm.$vv.entity && _vm.$vv.entity.modDesc && _vm.$vv.entity.modDesc.$error ? _c("p", {
    staticClass: "help is-danger"
  }, [_vm._v("Module description is required")]) : _vm._e()]) : _c("span", {
    staticClass: "title"
  }, [_vm._v("FlexiQuote Module")]), _vm.entity && _vm.entity.isBase ? _c("span", {
    staticClass: "tag is-success ml-2"
  }, [_vm._v("Base Module")]) : _vm._e()])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("PermissionTree", {
    attrs: {
      "permission-records": _vm.permissionRecords,
      "disable-toggle-children": true
    }
  })], 1)])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922 ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.moduleDescription,
      expression: "innerValue.moduleDescription"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Module Description"
    },
    domProps: {
      value: _vm.innerValue.moduleDescription
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "moduleDescription", $event.target.value);
      }
    }
  })])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("search")])]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("refresh")])]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo.isSystemAdministrator ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": true,
      "show-delete": false,
      "show-save": false,
      "show-print": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("flexiquote-module-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "m-3"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (entity, index) {
    return _c("tr", {
      key: entity.flexiQuoteModuleId,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("router-link", {
      attrs: {
        to: {
          path: "/superadmin/flexiquotemodule/".concat(entity.flexiQuoteModuleId)
        }
      }
    }, [_vm._v(" " + _vm._s(entity.modDesc) + " ")])], 1), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [entity.isBase ? "has-text-success" : "has-text-danger"]
    }, [_c("span", {
      staticClass: "mso mso-24px"
    }, [_vm._v(" " + _vm._s(entity.isBase ? "check" : "close") + " ")])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("span", {
    staticClass: "mso mso-fill mso-40px"
  }, [_vm._v("sentiment_dissatisfied")])]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738 ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, _vm._l(_vm.subModulePages, function (subModulePage) {
    return _c("ul", {
      key: subModulePage.to.name,
      staticClass: "menu-list"
    }, [_c("li", [_c("router-link", {
      attrs: {
        to: subModulePage.to,
        "active-class": "is-active",
        exact: ""
      }
    }, [_c("span", [_vm._v(" " + _vm._s(subModulePage.label) + " ")])])], 1)]);
  }), 0)]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo.isSystemAdministrator ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": true,
      "show-lock": false,
      "show-cancel": true,
      "show-edit": true
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("flexiquote-module-side-menu", {
    attrs: {
      "entity-name": _vm.entity.modDesc
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue":
/*!**************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true");
/* harmony import */ var _FlexiquoteModuleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FlexiquoteModuleDetail.vue?vue&type=script&lang=js */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FlexiquoteModuleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2e4e1d42",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js":
/*!**************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true ***!
  \********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleDetail.vue?vue&type=template&id=2e4e1d42&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleDetail_vue_vue_type_template_id_2e4e1d42_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue":
/*!********************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922 */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922");
/* harmony import */ var _FlexiquoteModuleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FlexiquoteModuleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js":
/*!********************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922":
/*!**************************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922 ***!
  \**************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListSideMenu.vue?vue&type=template&id=59f62922");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListSideMenu_vue_vue_type_template_id_59f62922__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue":
/*!****************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e");
/* harmony import */ var _FlexiquoteModuleListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FlexiquoteModuleListView.vue?vue&type=script&lang=js */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FlexiquoteModuleListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js":
/*!****************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e":
/*!**********************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleListView.vue?vue&type=template&id=84a70a1e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleListView_vue_vue_type_template_id_84a70a1e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue":
/*!****************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738 */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738");
/* harmony import */ var _FlexiquoteModuleSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FlexiquoteModuleSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js":
/*!****************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738":
/*!**********************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738 ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleSideMenu.vue?vue&type=template&id=f0186738");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleSideMenu_vue_vue_type_template_id_f0186738__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleValidation.js":
/*!*****************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleValidation.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.modDesc'],
    entity: {
      modDesc: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue":
/*!************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true");
/* harmony import */ var _FlexiquoteModuleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FlexiquoteModuleView.vue?vue&type=script&lang=js */ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FlexiquoteModuleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "261be19a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js":
/*!************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true":
/*!******************************************************************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true ***!
  \******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/flexiquotemodule/FlexiquoteModuleView.vue?vue&type=template&id=261be19a&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FlexiquoteModuleView_vue_vue_type_template_id_261be19a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/columns.js":
/*!**********************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/columns.js ***!
  \**********************************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Module Description', 'modDesc', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Is Base', 'isBase', true, 'asc', 'centered')];


/***/ }),

/***/ "./src/views/superadmin/flexiquotemodule/storeMixin.js":
/*!*************************************************************!*\
  !*** ./src/views/superadmin/flexiquotemodule/storeMixin.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var flexiquoteModuleName = 'flexiquotemodule';
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      savingStatus: null,
      showSavingStatus: false,
      toastNotificationEnabled: false
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(flexiquoteModuleName, {
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    snapshots: 'snapshots',
    hasError: 'hasError',
    saving: 'saving',
    returnRoute: 'returnRoute'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['debounceDelay'])),
  watch: {
    hasError: function hasError(val) {
      if (val) {
        this.$notification.error('', 'Save Failed');
      }
    },
    saving: function saving(val) {
      var _this = this;
      this.showSavingStatus = true;
      this.savingStatus = val ? 'Saving ...' : !this.hasError ? 'Saved' : '';
      if (!val) {
        setTimeout(function () {
          _this.showSavingStatus = false;
        }, 2000);
      }
    }
  },
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(flexiquoteModuleName, ['getStoreItem', 'addStoreItem', 'clearSnapshots', 'saveSnapshot', 'saveInitialSnapshots', 'setReturnRoute'])), {}, {
    openToastNotification: function openToastNotification() {
      if (!this.hasError) {
        this.$notification.success('', 'Information has been successfully saved');
      }
    }
  })
});

/***/ })

}]);
//# sourceMappingURL=superadmin-flexiquotemodule-chunk.js.map