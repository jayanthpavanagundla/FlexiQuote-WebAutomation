(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["insurer-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _InsurerService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./InsurerService */ "./src/views/insurer/InsurerService.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _enums_QuoteTemplateTypes__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/enums/QuoteTemplateTypes */ "./src/enums/QuoteTemplateTypes.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var lodash_startcase__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash.startcase */ "./node_modules/lodash.startcase/index.js");
/* harmony import */ var lodash_startcase__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_startcase__WEBPACK_IMPORTED_MODULE_30__);































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerDetail',
  inject: ['$vv'],
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_27__["FocusInserted"]
  },
  components: {
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_24__["TheMask"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_25___default.a
  },
  props: {
    insurerId: String,
    entity: null
  },
  data: function data() {
    return {
      glAccountListCombo: null,
      quoteTemplateListCombo: null,
      arnieBrands: null,
      protoData: {},
      invalids: [],
      selectedTemplateObject: {},
      selectedGlAccountObject: {},
      isLoading: true,
      modules: [],
      defaultConsumables: [],
      nameExists: false,
      repxinsurercodes: null,
      selectedRepxBrandsObject: []
    };
  },
  computed: {
    ecomType: {
      get: function get() {
        if (this.entity.pnet) {
          return this.ecomTypeEnum.PNET;
        } else if (this.entity.orm) {
          return this.ecomTypeEnum.ORM;
        } else if (this.entity.estimage) {
          return this.ecomTypeEnum.EstImage;
        } else {
          return this.ecomTypeEnum.None;
        }
      },
      set: function set(newValue) {
        if (newValue === this.ecomTypeEnum.None) {
          this.entity.pnet = false;
          this.entity.orm = false;
          this.entity.estimage = false;
        } else if (newValue === this.ecomTypeEnum.PNET) {
          this.entity.pnet = true;
          this.entity.orm = false;
          this.entity.excessGST = true;
          this.entity.estimage = false;
          this.entity.quotingMethod = 'D';
        } else if (newValue === this.ecomTypeEnum.ORM) {
          this.entity.pnet = false;
          this.entity.orm = true;
          this.entity.excessGST = false;
          this.entity.estimage = false;
          this.entity.quotingMethod = 'H';
        } else if (newValue === this.ecomTypeEnum.EstImage) {
          this.entity.pnet = false;
          this.entity.orm = false;
          this.entity.excessGST = false;
          this.entity.estimage = true;
          this.entity.quotingMethod = 'H';
        }
      }
    },
    ecomTypeEnum: function ecomTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["EcomTypes"];
    },
    pdrEnum: function pdrEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["PdrTypes"];
    },
    labourTimesTypeEnum: function labourTimesTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"];
    },
    isNtar: function isNtar() {
      return this.entity && (this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].NTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].LTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].eMTA);
    },
    hasPdr: function hasPdr() {
      if (!this.modules) {
        return false;
      }
      var findPdr = function findPdr(obj) {
        return obj.moduleDescription === _enums__WEBPACK_IMPORTED_MODULE_26__["FlexiQuoteModuleTypes"].PdrQuote;
      };
      var index = this.modules.find(findPdr);
      return index !== undefined;
    },
    $v: function $v() {
      return this.$vv ? this.$vv : this.$v;
    },
    audaNetLockTypes: function audaNetLockTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["AudaNetLockTypes"];
    },
    quoteTemplateTypeKeys: function quoteTemplateTypeKeys() {
      return _enums_QuoteTemplateTypes__WEBPACK_IMPORTED_MODULE_28__["QuoteTemplateTypeKeys"];
    },
    repxinsurercodesAvailable: function repxinsurercodesAvailable() {
      var _this = this;
      if (this.repxinsurercodes != null) {
        var finds = [];
        if (this.entity.insurerRepxBrands) {
          this.entity.insurerRepxBrands.forEach(function (brand, index) {
            var repxBrand = _this.repxinsurercodes.filter(function (r) {
              return r.repxInsurerCodeID == brand.repxInsurerCodeID;
            });
            if (repxBrand.length > 0) {
              finds.push(repxBrand);
            }
          });
        }
        var filterItem = this.repxinsurercodes.filter(function (stage) {
          return !finds.some(function (a) {
            return a.repxInsurerCodeID == stage.repxInsurerCodeID;
          });
        });
        return filterItem;
      }
    }
  },
  watch: {
    selectedTemplateObject: function selectedTemplateObject(newVal, oldVal) {
      if (newVal != null) {
        this.entity.templateId = newVal.id;
      } else {
        this.entity.templateId = null;
      }
    },
    selectedGlAccountObject: function selectedGlAccountObject(newVal, oldVal) {
      if (newVal != null) {
        this.entity.insurerGLCode = newVal.accountNo;
      } else {
        this.entity.insurerGLCode = '';
      }
    },
    'entity.labourType': function entityLabourType(newVal, oldVal) {
      this.entity.autoPaintLoading = this.isNtar;
      this.assignConsumables(newVal);
    },
    'entity.insurerGLCode': function entityInsurerGLCode(newVal) {
      this.selectedGlAccountObject = this.glAccountListCombo.find(function (g) {
        return g.accountNo === newVal;
      });
    },
    'entity.templateId': function entityTemplateId(newVal) {
      this.selectedTemplateObject = this.quoteTemplateListCombo.find(function (t) {
        return t.id === newVal;
      });
    },
    selectedRepxBrandsObject: function selectedRepxBrandsObject(newVal, oldVal) {
      var _this2 = this;
      if (newVal != null) {
        var selected = this.selectedRepxBrandsObject.map(function (e) {
          return {
            repxInsurerCodeID: e.repxInsurerCodeID
          };
        });
        if (!this.entity.insurerRepxBrands) {
          var newItems = [];
          selected.forEach(function (item, index) {
            newItems.push({
              repxInsurerCodeID: item.repxInsurerCodeID,
              insurerID: _this2.entity.InsurerId,
              isNew: true
            });
          });
          this.entity.insurerRepxBrands = newItems;
        } else {
          var _newItems = selected.filter(function (code) {
            return !_this2.entity.insurerRepxBrands.some(function (brand) {
              return code.repxInsurerCodeID === brand.repxInsurerCodeID;
            });
          });
          if (_newItems.length > 0) {
            _newItems.forEach(function (item, index) {
              _this2.entity.insurerRepxBrands.push({
                repxInsurerCodeID: item.repxInsurerCodeID,
                insurerID: _this2.entity.InsurerId,
                isNew: true
              });
            });
          }
          var toDeteleItems = this.entity.insurerRepxBrands.filter(function (brand) {
            return !selected.some(function (code) {
              return code.repxInsurerCodeID === brand.repxInsurerCodeID;
            });
          });
          if (toDeteleItems.length > 0) {
            toDeteleItems.forEach(function (item, index) {
              var repxBrand = _this2.entity.insurerRepxBrands.find(function (r) {
                return r.repxInsurerCodeID == item.repxInsurerCodeID;
              });
              repxBrand.isDeleted = true;
            });
          }
        }
      } else {
        this.entity.insurerRepxBrands = null;
      }
    }
  },
  created: function created() {
    var _this3 = this;
    this.getData();
    this.getModules();
    this.getDefaultConsumables();
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].EntitySaved, function (data) {
      _this3.onEntitySaved(data);
    });
  },
  mounted: function mounted() {
    this.isLoading = false;
    this.$v.detailGroup.$touch();
  },
  methods: {
    getData: function getData() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        var templates, _yield$Promise$all, _yield$Promise$all2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getQuoteTemplateListComboProto();
            case 1:
              templates = _context.v;
              _context.n = 2;
              return Promise.all([_InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getGlAccountListComboProto(), _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getArnieBrand(), templates.filter(function (template) {
                return template.quoteType == _this4.quoteTemplateTypeKeys.Insurer;
              }), _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getRepxInsurerCodes()]);
            case 2:
              _yield$Promise$all = _context.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_yield$Promise$all, 4);
              _this4.glAccountListCombo = _yield$Promise$all2[0];
              _this4.arnieBrands = _yield$Promise$all2[1];
              _this4.quoteTemplateListCombo = _yield$Promise$all2[2];
              _this4.repxinsurercodes = _yield$Promise$all2[3];
              _this4.selectedGlAccountObject = _this4.glAccountListCombo.find(function (g) {
                return g.accountNo === _this4.entity.insurerGLCode;
              });
              _this4.selectedTemplateObject = _this4.quoteTemplateListCombo.find(function (t) {
                return t.id === _this4.entity.templateId;
              });
              if (_this4.entity.insurerRepxBrands) _this4.selectedRepxBrandsObject = _this4.repxinsurercodes.filter(function (repx) {
                return _this4.entity.insurerRepxBrands.some(function (a) {
                  return a.repxInsurerCodeID == repx.repxInsurerCodeID;
                });
              });
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    onChangeInsurerBrand: function onChangeInsurerBrand(event) {
      this.entity.arnie = this.entity.insurerBrand !== '' && this.entity.insurerBrand !== '0';
    },
    checkInUse: function checkInUse() {
      this.$emit('entityDelete');
    },
    getModules: function getModules() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var moduleKey;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              moduleKey = "".concat(_this5.$userInfo.sessionId, "|").concat(_this5.$route.meta.mkey);
              _this5.modules = JSON.parse(sessionStorage.getItem(moduleKey));
              if (_this5.modules) {
                _context2.n = 2;
                break;
              }
              _context2.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getModules();
            case 1:
              _this5.modules = _context2.v;
              sessionStorage.setItem(moduleKey, JSON.stringify(_this5.modules));
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getDefaultConsumables: function getDefaultConsumables() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var consumableKey;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              consumableKey = "".concat(_this6.$userInfo.sessionId, "|").concat(_this6.$route.meta.ckey);
              _this6.defaultConsumables = JSON.parse(sessionStorage.getItem(consumableKey));
              if (_this6.defaultConsumables) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].getDefaultNtarConsumables();
            case 1:
              _this6.defaultConsumables = _context3.v;
              sessionStorage.setItem(consumableKey, JSON.stringify(_this6.defaultConsumables));
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    checkNameExists: lodash_debounce__WEBPACK_IMPORTED_MODULE_29___default()(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            _context4.n = 1;
            return this.assertNameExists();
          case 1:
            return _context4.a(2);
        }
      }, _callee4, this);
    })), 500),
    assertNameExists: function assertNameExists() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_23__["default"].assertNameExists(_this7.entity.insurerId, _this7.entity.name);
            case 1:
              _this7.nameExists = _context5.v;
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    assignConsumables: function assignConsumables(type) {
      var findCon = function findCon(typeId) {
        return function (obj) {
          return obj.typeId === typeId;
        };
      };
      if (type === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].NTAR || type === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].LTAR) {
        this.entity.panelCons = this.defaultConsumables.find(findCon(1)).value;
        this.entity.paintCons = this.defaultConsumables.find(findCon(3)).value;
        this.entity.panelConsMin = this.defaultConsumables.find(findCon(2)).value;
      } else if (type === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].eMTA) {
        this.entity.panelCons = this.defaultConsumables.find(findCon(5)).value;
        this.entity.paintCons = 0;
        this.entity.panelConsMin = 0;
      } else if (type === _enums__WEBPACK_IMPORTED_MODULE_26__["LabourTimeTypes"].RACQ) {
        this.entity.paintCons = this.defaultConsumables.find(findCon(4)).value;
        this.entity.panelCons = 0;
        this.entity.panelConsMin = 0;
      } else {
        this.entity.panelCons = 0;
        this.entity.paintCons = 0;
        this.entity.panelConsMin = 0;
      }
    },
    onEntitySaved: function onEntitySaved() {
      this.nameExists = false;
    },
    getVuelidationErrors: function getVuelidationErrors() {
      var _this8 = this;
      // console.log(this.$v.entity.$flattenParams())
      if (!(this.entity && this.$v.entity.$invalid)) {
        // console.log('no errors!!!')
        return [];
      }
      var buffer = [];
      Object.keys(this.$v.entity).forEach(function (key) {
        // console.log(`${key} : ${typeof this.$v.entity[key]}`)
        if (!key.startsWith('$') && Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this8.$v.entity[key]) === 'object' && _this8.$v.entity[key].$invalid) {
          // console.log(this.$v.entity[key].$invalid)
          buffer.push({
            type: key,
            message: 'vuelidate.' + key
          });
        }
      });
      return buffer;
    },
    onReload: function onReload() {
      var _this9 = this;
      this.selectedGlAccountObject = this.glAccountListCombo.find(function (g) {
        return g.accountNo === _this9.entity.insurerGLCode;
      });
      this.selectedTemplateObject = this.quoteTemplateListCombo.find(function (t) {
        return t.id === _this9.entity.templateId;
      });
    },
    toggleActive: function toggleActive(active) {
      this.entity.active = active;
      if (active) {
        this.assertNameExists();
      } else {
        this.checkInUse();
      }
    },
    startCase: function startCase(value) {
      return lodash_startcase__WEBPACK_IMPORTED_MODULE_30___default()(value);
    },
    audaNetLockTypeOnChange: function audaNetLockTypeOnChange(event) {
      this.entity.audaNetLockType = event.target.checked ? _enums__WEBPACK_IMPORTED_MODULE_26__["AudaNetLockTypes"].LockOnRFQ : _enums__WEBPACK_IMPORTED_MODULE_26__["AudaNetLockTypes"].NeverLock;
    },
    inScopeOnChange: function inScopeOnChange(event) {
      this.entity.inScope = !!event.target.checked;
    },
    autoBookedInOnChange: function autoBookedInOnChange(event) {
      this.entity.autoBookedInForDueInOut == event.target.checked;
    }
  },
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6(to, from, next) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
        while (1) switch (_context6.n) {
          case 0:
            next();
          case 1:
            return _context6.a(2);
        }
      }, _callee6);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/insurer/route-types.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerSideMenu',
  inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    isNtar: {
      type: Boolean,
      default: false
    },
    entityName: {
      type: String,
      default: ''
    },
    isError: null
  },
  data: function data() {
    return {
      activeMenuItem: 'detail',
      isActiveClass: 'is-active'
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_1__["default"];
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.regexp.dot-all.js */ "./node_modules/core-js/modules/es.regexp.dot-all.js");
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.regexp.sticky.js */ "./node_modules/core-js/modules/es.regexp.sticky.js");
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.string.match.js */ "./node_modules/core-js/modules/es.string.match.js");
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _InsurerSideMenu__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./InsurerSideMenu */ "./src/views/insurer/InsurerSideMenu.vue");
/* harmony import */ var _InsurerService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./InsurerService */ "./src/views/insurer/InsurerService.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./route-types */ "./src/views/insurer/route-types.js");
/* harmony import */ var _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/views/quickinvoice/route-types */ "./src/views/quickinvoice/route-types.js");
/* harmony import */ var _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(_views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _InsurerValidation__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./InsurerValidation */ "./src/views/insurer/InsurerValidation.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./storeMixin */ "./src/views/insurer/storeMixin.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");

















































// import Long from 'long'
// import ProtoBuf from 'protobufjs'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'InsurerView',
  components: {
    InsurerSideMenu: _InsurerSideMenu__WEBPACK_IMPORTED_MODULE_29__["default"],
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_31__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_39__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_39__["SaveConflictModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_39__["ConfirmModal"]
  },
  mixins: [_InsurerValidation__WEBPACK_IMPORTED_MODULE_36__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_41__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String,
    name: String,
    iid: String
  },
  data: function data() {
    return {
      entity: null,
      activeSideMenu: 'detail',
      initialising: true,
      selectedIndexByRoute: {
        InsurerConsumables: 0,
        InsurerLoadingValues: 0,
        InsurerPaintMaterials: 0,
        InsurerSpecialRates: 0
      },
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      isConfirmModalActive: false,
      toRoute: null,
      deleteAndSave: true,
      entityProto: null,
      isEditValues: false,
      isConsumableError: {
        isError: false,
        CMI: false,
        PMI: false,
        LVI: false,
        SPI: false
      }
    };
  },
  computed: {
    buttonCSS: function buttonCSS() {
      return 'is-inverted';
    },
    routeList: function routeList() {
      return this.$route.matched;
    },
    isNtar: function isNtar() {
      return this.entity && (this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_40__["LabourTimeTypes"].NTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_40__["LabourTimeTypes"].LTAR || this.entity.labourType === _enums__WEBPACK_IMPORTED_MODULE_40__["LabourTimeTypes"].eMTA);
    },
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error || this.$v.emailsPhonesGroup.$error || this.$v.addressesGroup.$error || this.$v.contactsGroup.$error;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_42___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(this.entity));
        }
      }, 250),
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var payload;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _InsurerService__WEBPACK_IMPORTED_MODULE_30__["default"].clearPreviousSessionStorage(_this.$userInfo.sessionId);
            if (!(_this.$route.query.mode === 'new')) {
              _context.n = 2;
              break;
            }
            _this.$showSpinner('Creating...');
            payload = new _classes__WEBPACK_IMPORTED_MODULE_45__["InsurerPayload"](_this.$route.query.name, false);
            _context.n = 1;
            return _this.addStoreItem(payload);
          case 1:
            _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(_this.currentSnapshot);
            _this.persistQueries();
            _this.replaceRoute(_this.entity.insurerId);
            _this.$hideSpinner();
            _context.n = 3;
            break;
          case 2:
            _this.getEntity();
          case 3:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {
    // this.clearSessionStorage()
    // this.clearSnapshots(this.entity.insurerId)
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _t = action;
              _context2.n = _t === _enums__WEBPACK_IMPORTED_MODULE_40__["AppHeaderButtonTypes"].AddNew ? 1 : _t === _enums__WEBPACK_IMPORTED_MODULE_40__["AppHeaderButtonTypes"].Print ? 2 : _t === _enums__WEBPACK_IMPORTED_MODULE_40__["AppHeaderButtonTypes"].Delete ? 3 : _t === _enums__WEBPACK_IMPORTED_MODULE_40__["AppHeaderButtonTypes"].Save ? 4 : _t === _enums__WEBPACK_IMPORTED_MODULE_40__["AppHeaderButtonTypes"].Cancel ? 5 : 6;
              break;
            case 1:
              return _context2.a(3, 6);
            case 2:
              // var url = `${process.env.VUE_APP_ROOT_URI}/modules/reports/printpreview.aspx?reportname=rptTableInsurerDetails&CompanyID=${
              //   this.$userInfo.companyId
              // }&InsurerID=${this.entity.insurerId}`
              // window.open(url, '_blank')
              _this2.print();
              return _context2.a(3, 6);
            case 3:
              _this2.deleteAndSave = true;
              _this2.deleteEntity(true, false, true);
              return _context2.a(3, 6);
            case 4:
              _this2.save();
              return _context2.a(3, 6);
            case 5:
              _this2.cancel();
              return _context2.a(3, 6);
            case 6:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var reset, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context3.p = 1;
              _this3.$showSpinner();
              if (reset) {
                _this3.clearSnapshots(_this3.$route.params.insurerId);
              }
              if (_this3.currentSnapshot) {
                _context3.n = 2;
                break;
              }
              _context3.n = 2;
              return _this3.getStoreItem(_this3.$route.params.insurerId);
            case 2:
              _this3.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(_this3.currentSnapshot);
              _context3.n = 4;
              break;
            case 3:
              _context3.p = 3;
              _t2 = _context3.v;
              if (_t2.response) {
                _components_EventBus__WEBPACK_IMPORTED_MODULE_35__["default"].$emit('serviceError', _t2.response.status);
                _this3.$notification.openMessageXhrError('', _t2);
              } else {
                console.error(_t2);
              }
            case 4:
              _context3.p = 4;
              _this3.$hideSpinner();
              return _context3.f(4);
            case 5:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 3, 4, 5]]);
      }))();
    },
    // async getEntityProto() {
    //   this.entityProto = await InsurerService.getInsurerProto(this.$route.params.insurerId)
    //   // console.log(this.entityProto.InsurerID.hi.toString())
    //   // console.log(this.bytesToGuidString(this.bclGuidtoBytes(this.entityProto.InsurerID)))
    // },
    // bclGuidtoBytes(bclGuid) {
    //   const low = Long.fromString('4687570604103417836', true) // Long.fromString(bclGuid.lo.toString(), true)
    //   // console.log(low)
    //   const high = Long.fromString('17075442052373025196', true) // Long.fromString(bclGuid.hi.toString(), true)
    //   // console.log(high)
    //   const highBytes = high.toBytesLE()
    //   const lowBytes = low.toBytesLE()
    //   // console.log(lowBytes, highBytes)
    //   const bytes = lowBytes.concat(highBytes)
    //   // console.log(bytes)
    //   // console.log(this.bytesToGuidString(bytes))
    //   return bytes
    // },
    print: function print() {
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        InsurerID: this.entity.insurerId
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_47__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_45__["Emailer"]();
      emailer.assetId = this.entity.insurerId;
      emailer.subject = 'Insurer Table Detail';
      emailer.reportName = 'rptTableInsurerDetails';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_46__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    },
    bytesToGuidString: function bytesToGuidString(byteArray) {
      return Array.from(byteArray, function (byte) {
        return ('0' + (byte & 0xff).toString(16)).slice(-2);
      }).join('').replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
    },
    guidStringToBytes: function guidStringToBytes(guid) {
      var bytes = [];
      guid.split('-').map(function (number, index) {
        var bytesInChar = index < 3 ? number.match(/.{1,2}/g).reverse() : number.match(/.{1,2}/g);
        bytesInChar.map(function (byte) {
          bytes.push(parseInt(byte, 16));
        });
      });
      return bytes;
    },
    save: function save(isDelete) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var message, title, response, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              message = 'Validation errors. Please fix before saving';
              title = 'Insurer';
              _context4.p = 1;
              _this4.$showSpinner('Saving...');
              _this4.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(_this4.entity));
              if (!(!_this4.validateError && !_this4.isConsumableError.isError)) {
                _context4.n = 12;
                break;
              }
              if (!_this4.entity.isNew) {
                _context4.n = 3;
                break;
              }
              _context4.n = 2;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_30__["default"].postInsurer(_this4.entity);
            case 2:
              response = _context4.v;
              _context4.n = 6;
              break;
            case 3:
              if (!_this4.snapshotDiff) {
                _context4.n = 5;
                break;
              }
              _context4.n = 4;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_30__["default"].putInsurer(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(_this4.entity), _this4.snapshotDiff);
            case 4:
              response = _context4.v;
              _context4.n = 6;
              break;
            case 5:
              _this4.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
              return _context4.a(2, false);
            case 6:
              if (!_this4.isSaveContinue) {
                _context4.n = 7;
                break;
              }
              _this4.$notification.openNotificationWithType('success', title, isDelete ? 'Insurer set to In-Active' : 'Save successful');
              _context4.n = 11;
              break;
            case 7:
              if (!(response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_38__["default"].NO_CONTENT)) {
                _context4.n = 9;
                break;
              }
              _context4.n = 8;
              return _this4.getEntity(true);
            case 8:
              // Refresh page data
              // this.dataChanged = false
              _this4.$notification.openNotificationWithType('success', title, isDelete ? 'Insurer set to In-Active' : 'Save successful');
              _context4.n = 11;
              break;
            case 9:
              if (!(response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_38__["default"].CREATED)) {
                _context4.n = 11;
                break;
              }
              _context4.n = 10;
              return _this4.getEntity(true);
            case 10:
              _this4.$notification.openNotificationWithType('success', title, 'New insurer added');
            case 11:
              _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_40__["EventHubTypes"].EntitySaved);
              _this4.isEditValues = false;
              return _context4.a(2, true);
            case 12:
              _this4.$notification.openNotificationWithType('danger', title, message);
              return _context4.a(2, false);
            case 13:
              _context4.n = 15;
              break;
            case 14:
              _context4.p = 14;
              _t3 = _context4.v;
              if (_t3.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_38__["default"].CONFLICT) {
                _this4.isSaveConflictModalActive = true;
              } else {
                _this4.$notification.openMessageXhrError('', _t3);
              }
              return _context4.a(2, false);
            case 15:
              _context4.p = 15;
              _this4.$hideSpinner();
              return _context4.f(15);
            case 16:
              return _context4.a(2);
          }
        }, _callee4, null, [[1, 14, 15, 16]]);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(this.entity));
      var returnUrl = '';
      if (this.returnUrl) {
        if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
          this.isUnsavedModalActive = true;
          return;
        }
        this.$showSpinner('Returning...');
        if (this.iid) {
          // Return to Quick Invoice
          returnUrl = "".concat(this.returnUrl, "&type=").concat(this.type, "&iid=").concat(this.iid);
        } else {
          // Return to Quote
          var refreshId = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].createShortGuid(this.entity.insurerId);
          returnUrl = "".concat(this.returnUrl, "&refresh=insurer&refreshId=").concat(refreshId);
        }
        this.clearSessionStorage();
        this.clearSnapshots(this.entity.insurerId);
        window.location.href = returnUrl;
      } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_44___default()(this.returnRoute)) {
        this.$router.push({
          path: this.returnRoute.path
        });
      } else if (this.toRoute !== null) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        this.$router.push({
          name: _route_types__WEBPACK_IMPORTED_MODULE_32__["default"].InsurerListView.name
        });
      }
      // console.log(returnUrl)
    },
    replaceRoute: function replaceRoute(id) {
      // console.log(this.returnUrl)
      var newMeta = Object.assign(this.$route.meta, {
        isNew: true,
        returnUrl: this.returnUrl,
        type: this.type,
        name: this.name,
        iid: this.iid
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_32__["default"].InsurerDetail.name,
        params: {
          insurerId: id
        },
        meta: newMeta
      });
    },
    gotoNew: function gotoNew() {
      var id = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].newGuid();
      this.$router.push({
        name: _route_types__WEBPACK_IMPORTED_MODULE_32__["default"].InsurerDetail.name,
        params: {
          insurerId: id
        },
        query: {
          mode: 'new'
        }
      });
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isConfirmModalActive = false;
      this.isSaveContinue = false;
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.isUnsavedModalActive = false;
              _this5.isSaveContinue = true;
              _context5.n = 1;
              return _this5.save();
            case 1:
              _this5.isSaveContinue = _context5.v;
              if (_this5.isSaveContinue) {
                _this5.cancel();
              }
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    reloadData: function reloadData() {
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
      this.getEntity(true);
    },
    deleteEntity: function deleteEntity(check, value, saveEntity) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var isInUse, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isConfirmModalActive = false;
              if (!check) {
                _context6.n = 2;
                break;
              }
              _context6.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_30__["default"].assertUsed(_this6.entity.insurerId);
            case 1:
              _t4 = _context6.v;
              _context6.n = 3;
              break;
            case 2:
              _t4 = false;
            case 3:
              isInUse = _t4;
              if (isInUse) {
                _this6.isConfirmModalActive = true;
              } else {
                _this6.entity.active = value;
                if (saveEntity) {
                  _this6.save(true);
                }
              }
            case 4:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    onEntityDelete: function onEntityDelete() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        var isInUse;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this7.deleteAndSave = false;
              _context7.n = 1;
              return _InsurerService__WEBPACK_IMPORTED_MODULE_30__["default"].assertUsed(_this7.entity.insurerId);
            case 1:
              isInUse = _context7.v;
              if (isInUse) {
                _this7.isConfirmModalActive = true;
              }
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.isNew) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|insurer|isNew"), this.isNew);
      }
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|insurer|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|insurer|type"), this.type);
      }
      if (this.name) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|insurer|name"), this.name);
      }
      if (this.iid) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|insurer|iid"), this.iid);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|insurer|isNew"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|insurer|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|insurer|type"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|insurer|name"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|insurer|iid"));
    },
    clearSessionStorage: function clearSessionStorage() {
      if (this.$userInfo) {
        var moduleKey = "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.mkey);
        var consumableKey = "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.ckey);
        sessionStorage.removeItem(moduleKey);
        sessionStorage.removeItem(consumableKey);
        this.removeQueries();
      }
    },
    clearPreviousSessionStorage: function clearPreviousSessionStorage() {
      var regAll = new RegExp('insurer', 'i');
      var regCurrent = new RegExp("".concat(this.$userInfo.sessionId), 'i');
      Object.keys(sessionStorage).filter(function (s) {
        return regAll.test(s) && !regCurrent.test(s);
      }).forEach(function (s) {
        // sessionStorage.removeItem(s)
      });
    },
    // Add Versions to all the consumables
    addVersions: function addVersions(value) {
      // Get Max Version form all the consumable
      var insurerConsumablesVersion = Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      }));
      var insurerPaintMaterialVersion = Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      }));
      var insurerLoadingValuesVersion = Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      }));
      var insurerSpecialRatesVersion = Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }));

      // If maxVersion doesn't match
      if (insurerConsumablesVersion !== value) {
        this.addInsurerConsumablesVersions(insurerConsumablesVersion, value);
      }
      if (insurerPaintMaterialVersion !== value) {
        this.addInsurerPaintMaterialsVersions(insurerPaintMaterialVersion, value);
      }
      if (insurerLoadingValuesVersion !== value) {
        this.addInsurerLoadingValuesVersions(insurerLoadingValuesVersion, value);
      }
      if (insurerSpecialRatesVersion !== value) {
        this.addInsurerSpecialRatesVersions(insurerSpecialRatesVersion, value);
      }
      this.isEditValues = true;
    },
    addInsurerConsumablesVersions: function addInsurerConsumablesVersions(currentVersion, maxVersion) {
      var _this8 = this;
      var prevVersion = this.entity.insurerConsumables.filter(function (i) {
        return i.versionNo === currentVersion;
      });
      for (var i = currentVersion + 1; i <= maxVersion; i++) {
        var newList = JSON.parse(JSON.stringify(prevVersion));
        newList.forEach(function (item) {
          item.versionNo = i;
          item.consumablesId = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].newGuid();
          item.isNew = true;
          _this8.entity.insurerConsumables.push(item);
        });
      }
    },
    addInsurerPaintMaterialsVersions: function addInsurerPaintMaterialsVersions(currentVersion, maxVersion) {
      var _this9 = this;
      var prevVersion = this.entity.insurerPaintMaterials.filter(function (i) {
        return i.versionNo === currentVersion;
      });
      for (var i = currentVersion + 1; i <= maxVersion; i++) {
        var newList = JSON.parse(JSON.stringify(prevVersion));
        newList.forEach(function (item) {
          item.versionNo = i;
          item.paintTypeId = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].newGuid();
          item.isNew = true;
          _this9.entity.insurerPaintMaterials.push(item);
        });
      }
    },
    addInsurerLoadingValuesVersions: function addInsurerLoadingValuesVersions(currentVersion, maxVersion) {
      var _this0 = this;
      var prevVersion = this.entity.insurerLoadingValues.filter(function (i) {
        return i.versionNo === currentVersion;
      });
      for (var i = currentVersion + 1; i <= maxVersion; i++) {
        var newList = JSON.parse(JSON.stringify(prevVersion));
        newList.forEach(function (item) {
          item.versionNo = i;
          item.ntarLoadingValueId = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].newGuid();
          item.isNew = true;
          _this0.entity.insurerLoadingValues.push(item);
        });
      }
    },
    addInsurerSpecialRatesVersions: function addInsurerSpecialRatesVersions(currentVersion, maxVersion) {
      var _this1 = this;
      var prevVersion = this.entity.insurerSpecialRates.filter(function (i) {
        return i.versionNo === currentVersion;
      });
      for (var i = currentVersion + 1; i <= maxVersion; i++) {
        var newList = JSON.parse(JSON.stringify(prevVersion));
        newList.forEach(function (item) {
          item.versionNo = i;
          item.specialRatesId = _components_Guid__WEBPACK_IMPORTED_MODULE_37__["default"].newGuid();
          item.isNew = true;
          _this1.entity.insurerSpecialRates.push(item);
        });
      }
    },
    onEdit: function onEdit(value) {
      this.isEditValues = !value;
    },
    checkError: function checkError() {
      var maxVersion = this.getMaximumVersion();
      var checkCMI = this.entity.insurerConsumables.find(function (i) {
        return i.versionNo === maxVersion && i.value <= 0.0;
      });
      var checkLVI = this.entity.insurerLoadingValues.find(function (i) {
        return i.versionNo === maxVersion && i.value <= 0.0;
      });
      var checkPMI = this.entity.insurerPaintMaterials.find(function (i) {
        return i.versionNo === maxVersion && i.value <= 0.0;
      });
      var checkSPI = this.entity.insurerSpecialRates.find(function (i) {
        return i.versionNo === maxVersion && i.value <= 0.0;
      });
      if (checkCMI || checkLVI || checkPMI || checkSPI) {
        this.isConsumableError.CMI = checkCMI ? true : false;
        this.isConsumableError.LVI = checkLVI ? true : false;
        this.isConsumableError.PMI = checkPMI ? true : false;
        this.isConsumableError.SPI = checkSPI ? true : false;
        this.isConsumableError.isError = true;
      } else {
        this.isConsumableError.CMI = false;
        this.isConsumableError.LVI = false;
        this.isConsumableError.PMI = false;
        this.isConsumableError.SPI = false;
        this.isConsumableError.isError = false;
      }
    },
    // Get Maximum values from all the Values
    getMaximumVersion: function getMaximumVersion() {
      var value = [Math.max.apply(Math, this.entity.insurerConsumables.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerPaintMaterials.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerLoadingValues.map(function (c) {
        return c.versionNo;
      })), Math.max.apply(Math, this.entity.insurerSpecialRates.map(function (c) {
        return c.versionNo;
      }))];
      return Math.max.apply(Math, value);
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_43___default()(this.entity));
    console.log(this.snapshotDiff);
    if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      if (to.name === _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_33___default.a.QuickInvoiceDetail.name) {
        var payload = new _classes__WEBPACK_IMPORTED_MODULE_45__["QuickInvoiceAssetPayload"](this.entity.insurerId, _enums__WEBPACK_IMPORTED_MODULE_40__["AssetTypes"].Insurer, this.entity.insurerGLCode);
        this.setQuickInvoiceAsset(payload);
      } else if (to.name === _views_quote_route_types__WEBPACK_IMPORTED_MODULE_34__["default"].QuoteDetail.name) {
        this.setQuoteInsurer(this.entity);
      }
      // Clean vuex store for now
      this.clearSnapshots(this.entity.insurerId);
      this.clearSessionStorage();
      this.setReturnRoute({});
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);










var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info")]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.name,
      expression: "entity.name"
    }, {
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }],
    staticClass: "input is-capitalized",
    class: {
      "is-danger": _vm.$v.entity.name.$error,
      "is-warning": _vm.nameExists
    },
    attrs: {
      name: "name",
      type: "text",
      placeholder: "Insurer Name",
      maxlength: "120"
    },
    domProps: {
      value: _vm.entity.name
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "name", $event.target.value);
      }, function ($event) {
        _vm.$v.entity.name.$touch();
        _vm.checkNameExists();
      }]
    }
  }), _vm.$v.entity && !_vm.$v.entity.name.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Name is required. ")]) : _vm._e(), _vm.nameExists ? _c("span", {
    staticClass: "help is-warning"
  }, [_vm._v("Name already exists. ")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ABN")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control has-icons-right"
  }, [_vm.$company.info && _vm.$company.info.countryCode === "AU" ? _c("the-mask", {
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.entity.abn.$error
    },
    attrs: {
      type: "text",
      placeholder: "ABN",
      mask: ["## ### ### ###"]
    },
    nativeOn: {
      input: function input($event) {
        return _vm.$v.entity.abn.$touch();
      }
    },
    model: {
      value: _vm.entity.abn,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "abn", $$v);
      },
      expression: "entity.abn"
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.abn,
      expression: "entity.abn"
    }],
    ref: "abn",
    staticClass: "input is-uppercase",
    attrs: {
      id: "abn",
      maxlength: "12"
    },
    domProps: {
      value: _vm.entity.abn
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "abn", $event.target.value);
      }, function ($event) {
        return _vm.$v.entity.abn.$touch();
      }]
    }
  }), !_vm.$v.entity.abn.$error && _vm.entity.abn && _vm.$company.info && _vm.$company.info.countryCode === "AU" ? _c("span", {
    staticClass: "icon has-text-success is-right"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]) : _vm._e(), _vm.$v.entity && !_vm.$v.entity.abn.minLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ABN must be at least " + _vm._s(_vm.$v.entity.abn.$params.minLength.min) + " letters.")]) : _vm.$v.entity && !_vm.$v.entity.abn.validAbn ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ABN format is invalid.")]) : _vm._e()], 1)])])]), _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ARBN")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control has-icons-right"
  }, [_c("the-mask", {
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.entity.arbn.$error
    },
    attrs: {
      type: "text",
      placeholder: "ARBN",
      mask: ["### ### ###"]
    },
    nativeOn: {
      input: function input($event) {
        return _vm.$v.entity.arbn.$touch();
      }
    },
    model: {
      value: _vm.entity.arbn,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "arbn", $$v);
      },
      expression: "entity.arbn"
    }
  }), !_vm.$v.entity.arbn.$error && _vm.entity.arbn ? _c("span", {
    staticClass: "icon has-text-success is-right"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]) : _vm._e(), _vm.$v.entity && !_vm.$v.entity.arbn.minLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ARBN must be at least " + _vm._s(_vm.$v.entity.arbn.$params.minLength.min) + " letters.")]) : _vm._e()], 1)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("G/L Account")]), _c("div", {
    staticClass: "control"
  }, [_vm.glAccountListCombo ? _c("multiselect", {
    attrs: {
      options: _vm.glAccountListCombo,
      placeholder: "Select account",
      label: "displayName",
      "track-by": "accountNo",
      "deselect-label": "Can't remove this value",
      "allow-empty": false
    },
    model: {
      value: _vm.selectedGlAccountObject,
      callback: function callback($$v) {
        _vm.selectedGlAccountObject = $$v;
      },
      expression: "selectedGlAccountObject"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("G/L account not found.")])]) : _vm._e()], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Repairer ID")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.repairerId,
      expression: "entity.repairerId"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Repairer ID"
    },
    domProps: {
      value: _vm.entity.repairerId
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "repairerId", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("BSB")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.entity.bsb.$error
    },
    attrs: {
      type: "text",
      placeholder: "BSB",
      mask: ["###-###"]
    },
    nativeOn: {
      input: function input($event) {
        return _vm.$v.entity.bsb.$touch();
      }
    },
    model: {
      value: _vm.entity.bsb,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "bsb", $$v);
      },
      expression: "entity.bsb"
    }
  }), _vm.$v.entity && !_vm.$v.entity.bsb.minLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("BSB must be at least " + _vm._s(_vm.$v.entity.bsb.$params.minLength.min) + " letters.")]) : _vm._e()], 1)])])]), _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Account No.")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.accoutNo,
      expression: "entity.accoutNo"
    }],
    staticClass: "input uppercase",
    attrs: {
      type: "text",
      placeholder: "Account No."
    },
    domProps: {
      value: _vm.entity.accoutNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "accoutNo", $event.target.value);
      }
    }
  })])])])])])]), _c("div", {
    staticClass: "pretty p-icon p-curve p-smooth p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.exported,
      expression: "entity.exported"
    }],
    attrs: {
      type: "checkbox",
      disabled: !_vm.$userInfo.isSupportUser
    },
    domProps: {
      checked: Array.isArray(_vm.entity.exported) ? _vm._i(_vm.entity.exported, null) > -1 : _vm.entity.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.entity.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.entity, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.entity, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.entity, "exported", $$c);
        }
      }
    }
  }), _vm._m(0)]), _c("div", {
    staticClass: "is-divider"
  }), _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": _vm.entity.active
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": !_vm.entity.active
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("In-Active")])])]) : _vm._e()])]), _c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Times & Method")]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Labour Times")]), _c("div", {
    staticClass: "field is-grouped"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.labourType,
      expression: "entity.labourType"
    }],
    staticClass: "select-width",
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "labourType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.labourTimesTypeEnum, function (labourType, propertyName, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: propertyName
      }
    }, [_vm._v(" " + _vm._s(labourType) + " ")]);
  }), 0)])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isNtar,
      expression: "isNtar"
    }],
    staticClass: "field has-checkradio"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.autoPaintLoading,
      expression: "entity.autoPaintLoading"
    }],
    staticClass: "is-checkradio is-primary",
    class: {
      "has-background-color": _vm.entity.autoPaintLoading
    },
    attrs: {
      id: "auto-paint-loading",
      type: "checkbox",
      name: "auto-paint-loading"
    },
    domProps: {
      checked: Array.isArray(_vm.entity.autoPaintLoading) ? _vm._i(_vm.entity.autoPaintLoading, null) > -1 : _vm.entity.autoPaintLoading
    },
    on: {
      change: function change($event) {
        var $$a = _vm.entity.autoPaintLoading,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.entity, "autoPaintLoading", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.entity, "autoPaintLoading", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.entity, "autoPaintLoading", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "auto-paint-loading"
    }
  }, [_vm._v("Auto Paint Loading")])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("E-Com Type")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select",
    class: {
      "is-disabled": _vm.entity.arnie
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.ecomType,
      expression: "ecomType"
    }],
    staticClass: "select-width",
    attrs: {
      disabled: _vm.entity.arnie
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.ecomType = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    domProps: {
      value: _vm.ecomTypeEnum.None
    }
  }), _c("option", {
    domProps: {
      value: _vm.ecomTypeEnum.ORM
    }
  }, [_vm._v("ORM")]), _c("option", {
    domProps: {
      value: _vm.ecomTypeEnum.PNET
    }
  }, [_vm._v("PNET")]), _c("option", {
    domProps: {
      value: _vm.ecomTypeEnum.EstImage
    }
  }, [_vm._v("EstImage")])])])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Arnie Brand")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select",
    class: {
      "is-disabled": _vm.entity.pnet || _vm.entity.orm
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.insurerBrand,
      expression: "entity.insurerBrand"
    }],
    staticClass: "select-width",
    attrs: {
      disabled: _vm.entity.pnet || _vm.entity.orm
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "insurerBrand", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.onChangeInsurerBrand($event);
      }]
    }
  }, [_c("option"), _vm._l(_vm.arnieBrands, function (brand, index) {
    return _c("option", {
      key: brand,
      domProps: {
        value: index + 1
      }
    }, [_vm._v(" " + _vm._s(brand) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("RepX Brand")]), _c("div", {
    staticClass: "control"
  }, [_vm.repxinsurercodesAvailable ? _c("multiselect", {
    attrs: {
      options: _vm.repxinsurercodesAvailable,
      multiple: true,
      "close-on-select": false,
      "clear-on-select": true,
      "preserve-search": true,
      taggable: true,
      placeholder: "Please select RepX brand",
      label: "code",
      "track-by": "repxInsurerCodeID",
      "show-labels": false,
      disabled: !(_vm.entity.pnet || _vm.entity.orm)
    },
    model: {
      value: _vm.selectedRepxBrandsObject,
      callback: function callback($$v) {
        _vm.selectedRepxBrandsObject = $$v;
      },
      expression: "selectedRepxBrandsObject"
    }
  }) : _vm._e()], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Template")]), _c("div", {
    staticClass: "control"
  }, [_vm.quoteTemplateListCombo ? _c("multiselect", {
    attrs: {
      options: _vm.quoteTemplateListCombo,
      placeholder: "Select quote template",
      label: "name",
      "track-by": "id"
    },
    model: {
      value: _vm.selectedTemplateObject,
      callback: function callback($$v) {
        _vm.selectedTemplateObject = $$v;
      },
      expression: "selectedTemplateObject"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Template not found.")])]) : _vm._e()], 1)]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess Type")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.excessGST,
      expression: "entity.excessGST"
    }],
    attrs: {
      id: "chk-pretty-excess-type",
      name: "chk-pretty-excess-type",
      type: "radio"
    },
    domProps: {
      value: false,
      checked: _vm._q(_vm.entity.excessGST, false)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.entity, "excessGST", false);
      }
    }
  }), _vm._m(3)]), _c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.excessGST,
      expression: "entity.excessGST"
    }],
    attrs: {
      id: "chk-pretty-excess-type",
      name: "chk-pretty-excess-type",
      type: "radio"
    },
    domProps: {
      value: true,
      checked: _vm._q(_vm.entity.excessGST, true)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.entity, "excessGST", true);
      }
    }
  }), _vm._m(4)])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quoting Method")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.quotingMethod,
      expression: "entity.quotingMethod"
    }],
    attrs: {
      id: "chk-pretty-quotemethod1",
      name: "chk-pretty-quotemethod1",
      type: "radio"
    },
    domProps: {
      value: "H",
      checked: _vm._q(_vm.entity.quotingMethod, "H")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.entity, "quotingMethod", "H");
      }
    }
  }), _vm._m(5)]), _c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.quotingMethod,
      expression: "entity.quotingMethod"
    }],
    attrs: {
      id: "chk-pretty-quotemethod2",
      name: "chk-pretty-quotemethod2",
      type: "radio"
    },
    domProps: {
      value: "D",
      checked: _vm._q(_vm.entity.quotingMethod, "D")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.entity, "quotingMethod", "D");
      }
    }
  }), _vm._m(6)])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("AudaNet Settings ")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: _vm.entity.audaNetLockType ? true : false
    },
    on: {
      change: _vm.audaNetLockTypeOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.startCase(Object.keys(_vm.audaNetLockTypes)[_vm.entity.audaNetLockType])))])])])])]), _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("AudaNet Work Provider Map")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.audaNetWorkProviderMapping,
      expression: "entity.audaNetWorkProviderMapping"
    }],
    staticClass: "select-width",
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "audaNetWorkProviderMapping", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option"), _vm._l(_vm.entity.workProviders, function (provider, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: provider
      }
    }, [_vm._v(" " + _vm._s(provider) + " ")]);
  })], 2)])])])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field is-flex"
  }, [_c("div", [_c("label", {
    staticClass: "label"
  }, [_vm._v("Show In Scope")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: !!_vm.entity.inScope
    },
    on: {
      change: _vm.inScopeOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.entity.inScope ? "On" : "Off"))])])])])]), _c("div", {
    staticClass: "is-divider-vertical"
  }), _c("div", {}, [_c("label", {
    staticClass: "label"
  }, [_c("span", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        enabled: true
      },
      expression: "{ enabled: true }"
    }],
    attrs: {
      content: "Auto transition job stage to Booked In when setting Estimated Job Start/End"
    }
  }, [_vm._v("Auto Booked In ")])]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        enabled: true
      },
      expression: "{ enabled: true }"
    }],
    staticClass: "pretty p-switch p-fill",
    attrs: {
      content: "Auto transition job stage to Booked In when setting Estimated Job Start/End"
    }
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.autoBookedInForDueInOut,
      expression: "entity.autoBookedInForDueInOut"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      checked: _vm.entity.autoBookedInForDueInOut
    }, "checked", Array.isArray(_vm.entity.autoBookedInForDueInOut) ? _vm._i(_vm.entity.autoBookedInForDueInOut, null) > -1 : _vm.entity.autoBookedInForDueInOut),
    on: {
      change: [function ($event) {
        var $$a = _vm.entity.autoBookedInForDueInOut,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.entity, "autoBookedInForDueInOut", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.entity, "autoBookedInForDueInOut", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.entity, "autoBookedInForDueInOut", $$c);
        }
      }, _vm.autoBookedInOnChange]
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.entity.autoBookedInForDueInOut ? "On" : "Off"))])])])])]), _c("div", {
    staticClass: "is-divider-vertical"
  }), _c("div", {}, [_vm._m(7), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.damageSeverity,
      expression: "entity.damageSeverity"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.entity.damageSeverity) ? _vm._i(_vm.entity.damageSeverity, null) > -1 : _vm.entity.damageSeverity
    },
    on: {
      change: function change($event) {
        var $$a = _vm.entity.damageSeverity,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.entity, "damageSeverity", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.entity, "damageSeverity", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.entity, "damageSeverity", $$c);
        }
      }
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.entity.damageSeverity ? "On" : "Off"))])])])])])]), _vm.hasPdr ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _vm.hasPdr ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("PDR Type")]), _c("div", {
    staticClass: "control"
  }, _vm._l(_vm.pdrEnum, function (pdrType, propertyName, index) {
    return _c("div", {
      key: index,
      staticClass: "pretty p-default p-round p-smooth"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.entity.pdrType,
        expression: "entity.pdrType"
      }],
      attrs: {
        id: "chk-pretty-pdr".concat(index),
        name: "chk-pretty-".concat(index),
        type: "radio"
      },
      domProps: {
        value: pdrType,
        checked: _vm._q(_vm.entity.pdrType, pdrType)
      },
      on: {
        change: function change($event) {
          return _vm.$set(_vm.entity, "pdrType", pdrType);
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("label", {
      attrs: {
        for: "pdr".concat(index)
      }
    }, [_vm._v(_vm._s(propertyName))])])]);
  }), 0)]) : _vm._e()])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", [_vm._v("Exported")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Excess (Ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Excess (Inc GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Hour")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Dollar")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("label", {
    staticClass: "label"
  }, [_c("span", [_vm._v(" Show Damage Severity ")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" " + _vm._s(_vm.entityName) + " ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.detailGroup.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerDetail.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.detailGroup.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": null
    }
  }, [_vm._v(" Detail Info ")])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerRatesMarkups.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_vm._v("Rates & Markups ")])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.addressesGroup.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerAddress.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.addressesGroup.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.addressesGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.addressesGroup.$error ? "" : null
    }
  }, [_vm._v(" Addresses ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.emailsPhonesGroup.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerPhoneEmail.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.emailsPhonesGroup.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.emailsPhonesGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.emailsPhonesGroup.$error ? "" : null
    }
  }, [_vm._v(" Phones/Emails ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.contactsGroup.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerContacts.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.contactsGroup.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.contactsGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.contactsGroup.$error ? "" : null
    }
  }, [_vm._v(" Contacts ")])])], 1)]), _vm.isNtar ? _c("p", {
    staticClass: "menu-label"
  }, [_vm._v(" NTAR ")]) : _vm._e(), _vm.isNtar ? _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.isError.CMI
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerConsumables.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.isError.CMI ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.isError.CMI
    },
    attrs: {
      "data-badge": _vm.isError.CMI ? "" : null
    }
  }, [_vm._v(" Consumables ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.isError.LVI
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerLoadingValues.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.isError.LVI ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.isError.LVI
    },
    attrs: {
      "data-badge": _vm.isError.LVI ? "" : null
    }
  }, [_vm._v(" Loading Values ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.isError.PMI
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerPaintMaterials.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.isError.PMI ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.isError.PMI
    },
    attrs: {
      "data-badge": _vm.isError.PMI ? "" : null
    }
  }, [_vm._v(" Paint Materials ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.isError.SPI
    },
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerSpecialRates.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.isError.SPI ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.isError.SPI
    },
    attrs: {
      "data-badge": _vm.isError.SPI ? "" : null
    }
  }, [_vm._v(" Special Rates ")])])], 1)]) : _vm._e(), _c("p", {
    staticClass: "menu-label"
  }, [_vm._v(" Others ")]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.InsurerAutoItems.name,
        params: {
          insurerId: _vm.$route.params.insurerId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_vm._v("Auto Items ")])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      title: "Insurer ".concat(_vm.$route.meta.title),
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.entity && !_vm.entity.isNew,
      "show-delete": _vm.entity && _vm.entity.active && !_vm.entity.isNew
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("insurer-side-menu", {
    ref: "sideMenu",
    attrs: {
      "is-ntar": _vm.isNtar,
      "entity-name": _vm.entity.name,
      "is-error": _vm.isConsumableError
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      entity: _vm.entity,
      "is-error": _vm.isConsumableError,
      "is-edit-values": _vm.isEditValues,
      "is-tiled": false,
      "asset-type": "4",
      "asset-id": _vm.entity.insurerId,
      "route-name": _vm.$route.name
    },
    on: {
      entityDelete: function entityDelete($event) {
        return _vm.onEntityDelete();
      },
      "add-versions": _vm.addVersions,
      "on-edit": _vm.onEdit,
      "set-error": _vm.checkError
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(false, false, _vm.deleteAndSave);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false, true, false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Insurer is in use")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.entity.name))]), _vm._v(" is in use. Set to "), _c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v("In-Active")]), _vm._v(" anyway? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-d29fc070] {\n  margin: 1.2em 0;\n}\ninput.uppercase[data-v-d29fc070] {\n  text-transform: uppercase;\n}\ninput.uppercase[data-v-d29fc070]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-d29fc070]::-moz-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-d29fc070]:-moz-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-d29fc070]:-ms-input-placeholder {\n  text-transform: none;\n}\n.field.has-checkradio .control[data-v-d29fc070] {\n  position: relative;\n  top: 48%;\n  -webkit-transform: translateY(-50%);\n          transform: translateY(-50%);\n}\n.select-width[data-v-d29fc070] {\n  min-width: 8.125em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "aside[data-v-1cb9048d] {\n  min-height: 100%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/_baseTrim.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_baseTrim.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var trimmedEndIndex = __webpack_require__(/*! ./_trimmedEndIndex */ "./node_modules/lodash/_trimmedEndIndex.js");

/** Used to match leading whitespace. */
var reTrimStart = /^\s+/;

/**
 * The base implementation of `_.trim`.
 *
 * @private
 * @param {string} string The string to trim.
 * @returns {string} Returns the trimmed string.
 */
function baseTrim(string) {
  return string
    ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, '')
    : string;
}

module.exports = baseTrim;


/***/ }),

/***/ "./node_modules/lodash/_trimmedEndIndex.js":
/*!*************************************************!*\
  !*** ./node_modules/lodash/_trimmedEndIndex.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to match a single whitespace character. */
var reWhitespace = /\s/;

/**
 * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
 * character of `string`.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {number} Returns the index of the last non-whitespace character.
 */
function trimmedEndIndex(string) {
  var index = string.length;

  while (index-- && reWhitespace.test(string.charAt(index))) {}
  return index;
}

module.exports = trimmedEndIndex;


/***/ }),

/***/ "./node_modules/lodash/debounce.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/debounce.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    now = __webpack_require__(/*! ./now */ "./node_modules/lodash/now.js"),
    toNumber = __webpack_require__(/*! ./toNumber */ "./node_modules/lodash/toNumber.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        timeWaiting = wait - timeSinceLastCall;

    return maxing
      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
      : timeWaiting;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

module.exports = debounce;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/lodash/now.js":
/*!************************************!*\
  !*** ./node_modules/lodash/now.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

module.exports = now;


/***/ }),

/***/ "./node_modules/lodash/toNumber.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/toNumber.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseTrim = __webpack_require__(/*! ./_baseTrim */ "./node_modules/lodash/_baseTrim.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = toNumber;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("43b22d92", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("55023262", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/validateForms/Address.js":
/*!*********************************************!*\
  !*** ./src/assets/validateForms/Address.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  addresses: {
    $each: {
      address1: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbPostcode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Contacts.js":
/*!**********************************************!*\
  !*** ./src/assets/validateForms/Contacts.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _Phones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _Emails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Emails */ "./src/assets/validateForms/Emails.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  contacts: {
    $each: {
      contact: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
        firstName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        },
        lastName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        }
      }, _Address__WEBPACK_IMPORTED_MODULE_2__["default"]), _Phones__WEBPACK_IMPORTED_MODULE_3__["default"]), _Emails__WEBPACK_IMPORTED_MODULE_4__["default"])
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Emails.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Emails.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  emails: {
    $each: {
      address: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["email"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Phones.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Phones.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  phones: {
    $each: {
      no: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/insurer/InsurerDetail.vue":
/*!*********************************************!*\
  !*** ./src/views/insurer/InsurerDetail.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true */ "./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true");
/* harmony import */ var _InsurerDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerDetail.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true */ "./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _InsurerDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "d29fc070",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js":
/*!*********************************************************************!*\
  !*** ./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true":
/*!******************************************************************************************************!*\
  !*** ./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=style&index=0&id=d29fc070&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_style_index_0_id_d29fc070_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true":
/*!***************************************************************************************!*\
  !*** ./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerDetail.vue?vue&type=template&id=d29fc070&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerDetail_vue_vue_type_template_id_d29fc070_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/InsurerSideMenu.vue":
/*!***********************************************!*\
  !*** ./src/views/insurer/InsurerSideMenu.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true */ "./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true");
/* harmony import */ var _InsurerSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerSideMenu.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true */ "./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _InsurerSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1cb9048d",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true":
/*!********************************************************************************************************!*\
  !*** ./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=style&index=0&id=1cb9048d&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_style_index_0_id_1cb9048d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true":
/*!*****************************************************************************************!*\
  !*** ./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerSideMenu.vue?vue&type=template&id=1cb9048d&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerSideMenu_vue_vue_type_template_id_1cb9048d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/InsurerValidation.js":
/*!************************************************!*\
  !*** ./src/views/insurer/InsurerValidation.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/assets/validateForms/Contacts */ "./src/assets/validateForms/Contacts.js");
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/store */ "./src/store/index.js");








var countryCode = function countryCode() {
  var company = _store__WEBPACK_IMPORTED_MODULE_7__["default"].getters['company/company'];
  return company.info ? company.info.countryCode : '';
};
var shouldValidateAbn = function shouldValidateAbn() {
  if (countryCode() === 'AU') {
    return true;
  } else {
    return false;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.name', 'entity.abn', 'entity.arbn', 'entity.bsb'],
    emailsPhonesGroup: ['entity.emails', 'entity.phones'],
    addressesGroup: ['entity.addresses'],
    contactsGroup: ['entity.contacts'],
    entity: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      name: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
      },
      abn: {
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["minLength"])(Object(_components_validators__WEBPACK_IMPORTED_MODULE_6__["abnMinLength"])(countryCode())),
        validAbn: function validAbn(value) {
          if (shouldValidateAbn()) {
            return Object(_components_validators__WEBPACK_IMPORTED_MODULE_6__["abnValidator"])(value);
          } else {
            return true;
          }
        }
      },
      arbn: {
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["minLength"])(9)
      },
      bsb: {
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["minLength"])(6)
      }
    }, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_4__["default"]), _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_3__["default"]), _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_2__["default"]), _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_5__["default"]), {}, {
      insurerConsumables: {
        $each: {
          value: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
          }
        }
      },
      insurerLoadingValues: {
        $each: {
          value: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
          }
        }
      },
      insurerPaintMaterials: {
        $each: {
          value: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
          }
        }
      },
      insurerSpecialRates: {
        $each: {
          value: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
          }
        }
      }
    })
  }
});

/***/ }),

/***/ "./src/views/insurer/InsurerView.vue":
/*!*******************************************!*\
  !*** ./src/views/insurer/InsurerView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InsurerView.vue?vue&type=template&id=9f387848 */ "./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848");
/* harmony import */ var _InsurerView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InsurerView.vue?vue&type=script&lang=js */ "./src/views/insurer/InsurerView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InsurerView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__["render"],
  _InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/insurer/InsurerView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/insurer/InsurerView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/insurer/InsurerView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848":
/*!*************************************************************************!*\
  !*** ./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848 ***!
  \*************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./InsurerView.vue?vue&type=template&id=9f387848 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/insurer/InsurerView.vue?vue&type=template&id=9f387848");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InsurerView_vue_vue_type_template_id_9f387848__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/insurer/storeMixin.js":
/*!*****************************************!*\
  !*** ./src/views/insurer/storeMixin.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'insurers';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quickinvoices', {
    setQuickInvoiceAsset: 'setAsset'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quotes', {
    setQuoteInsurer: 'setInsurer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=insurer-chunk.js.map