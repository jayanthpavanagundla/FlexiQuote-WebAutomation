(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[28],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/SignIn.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _AuthCard_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./AuthCard.vue */ "./src/views/auth/AuthCard.vue");
/* harmony import */ var _NewPasswordPanel_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./NewPasswordPanel.vue */ "./src/views/auth/NewPasswordPanel.vue");
/* harmony import */ var _TermsAcceptanceModal_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./TermsAcceptanceModal.vue */ "./src/views/auth/TermsAcceptanceModal.vue");
/* harmony import */ var _route_types_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./route-types.js */ "./src/views/auth/route-types.js");
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ErrorMessage */ "./src/views/auth/ErrorMessage.js");
/* harmony import */ var _returnUrl__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./returnUrl */ "./src/views/auth/returnUrl.js");
/* harmony import */ var _loginNavigation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./loginNavigation */ "./src/views/auth/loginNavigation.js");
/* harmony import */ var _services_platform_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/services/platform.js */ "./src/services/platform.js");
/* harmony import */ var _legacyRememberCookies__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./legacyRememberCookies */ "./src/views/auth/legacyRememberCookies.js");

















var REMEMBER_KEY = 'fq.rememberedLogin';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SignInView',
  components: {
    AuthCard: _AuthCard_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    NewPasswordPanel: _NewPasswordPanel_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    TermsAcceptanceModal: _TermsAcceptanceModal_vue__WEBPACK_IMPORTED_MODULE_10__["default"]
  },
  data: function data() {
    return {
      panel: 'login',
      companyLoginId: '',
      username: '',
      password: '',
      passwordVisible: false,
      rememberMe: false,
      // Held only while the first-login password change is in progress.
      passwordChangeTicket: '',
      // Held here rather than anywhere durable, so closing the tab abandons the ticket - an
      // unaccepted sign-in should leave nothing behind.
      pendingTerms: null,
      termsTicket: '',
      // Which terms button is working: 'accept', 'cancel', or null. Separate from isSubmitting so
      // the spinner lands on the button that was pressed rather than on both.
      termsAction: null,
      // Kept apart from errorMessage, which renders on the login card behind the modal overlay
      // and so would never be seen while the modal is open.
      termsError: '',
      isSubmitting: false,
      errorMessage: ''
    };
  },
  created: function created() {
    // PCK-655: our own remember-me wins; the legacy cookies only fill the gaps.
    var remembered = this.readRememberedLogin();
    var legacy = Object(_legacyRememberCookies__WEBPACK_IMPORTED_MODULE_16__["readLegacyRememberedLogin"])();
    this.companyLoginId = remembered.companyLoginId || legacy.companyLoginId;
    this.username = remembered.username || legacy.username;
    this.rememberMe = !!(this.companyLoginId || this.username);
  },
  methods: {
    readRememberedLogin: function readRememberedLogin() {
      try {
        var remembered = JSON.parse(localStorage.getItem(REMEMBER_KEY) || 'null');
        if (remembered) {
          return {
            companyLoginId: (remembered.companyLoginId || '').trim(),
            username: (remembered.username || '').trim()
          };
        }
      } catch (e) {/* corrupt entry - fall through to an empty result */}
      return {
        companyLoginId: '',
        username: ''
      };
    },
    signIn: function signIn() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var result, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.errorMessage = '';
              _this.$v.$touch();
              if (!_this.$v.$error) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              _this.isSubmitting = true;
              _context.p = 2;
              _context.n = 3;
              return _this.submitCredentials();
            case 3:
              result = _context.v;
              if (!result.requiresPasswordChange) {
                _context.n = 4;
                break;
              }
              _this.passwordChangeTicket = result.ticket;
              _this.panel = 'newaccount';
              return _context.a(2);
            case 4:
              if (!result.requiresTermsAcceptance) {
                _context.n = 5;
                break;
              }
              _this.termsTicket = result.ticket;
              _this.pendingTerms = result.terms;
              return _context.a(2);
            case 5:
              _this.rememberCredentials();
              _this.enterApp();
              _context.n = 7;
              break;
            case 6:
              _context.p = 6;
              _t = _context.v;
              _this.errorMessage = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_12__["getApiErrorMessage"])(_t, 'Sign In failed. Please try again.');
            case 7:
              _context.p = 7;
              _this.isSubmitting = false;
              return _context.f(7);
            case 8:
              return _context.a(2);
          }
        }, _callee, null, [[2, 6, 7, 8]]);
      }))();
    },
    /** Records the acceptance and finishes the sign-in in one call, with no re-entry of credentials. */acceptTerms: function acceptTerms() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _detectPlatform, osId, browserId, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              _this2.termsError = '';
              _this2.termsAction = 'accept';
              _context2.p = 1;
              _detectPlatform = Object(_services_platform_js__WEBPACK_IMPORTED_MODULE_15__["detectPlatform"])(), osId = _detectPlatform.osId, browserId = _detectPlatform.browserId;
              _context2.n = 2;
              return _this2.$auth.terms.accept({
                ticket: _this2.termsTicket,
                termsAndConditionsId: _this2.pendingTerms.id,
                osId: osId,
                browserId: browserId,
                location: ''
              });
            case 2:
              _this2.pendingTerms = null;
              _this2.termsTicket = '';
              _this2.rememberCredentials();
              _this2.enterApp();
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t2 = _context2.v;
              // Reported into the modal, not onto the login card: the modal stays open on failure so
              // the user can retry, and the card's alert is behind the overlay.
              _this2.termsError = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_12__["getApiErrorMessage"])(_t2, 'Your acceptance could not be recorded. Please try again.');
            case 4:
              _context2.p = 4;
              _this2.termsAction = null;
              return _context2.f(4);
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3, 4, 5]]);
      }))();
    },
    /**
     * A full navigation rather than a state reset: it takes the entered credentials, the ticket
     * and the modal with the page, so nothing from the abandoned sign-in survives. The returnUrl
     * is carried over so a later successful sign-in still lands where the user was headed.
     */
    declineTerms: function declineTerms() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var ticket;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              ticket = _this3.termsTicket;
              _this3.termsError = '';
              _this3.termsAction = 'cancel';
              _context3.p = 1;
              if (!ticket) {
                _context3.n = 2;
                break;
              }
              _context3.n = 2;
              return _this3.$auth.terms.decline(ticket);
            case 2:
              _context3.n = 3;
              return Object(_loginNavigation__WEBPACK_IMPORTED_MODULE_14__["goToLogin"])({
                returnUrl: _this3.$route.query.returnUrl
              });
            case 3:
              _context3.p = 3;
              // On success the page is already unloading and this never matters. It matters if the
              // navigation is ever blocked - otherwise both buttons stay disabled with no message and
              // the user has no way out of the modal at all.
              _this3.termsAction = null;
              return _context3.f(3);
            case 4:
              return _context3.a(2);
          }
        }, _callee3, null, [[1,, 3, 4]]);
      }))();
    },
    submitCredentials: function submitCredentials() {
      var _detectPlatform2 = Object(_services_platform_js__WEBPACK_IMPORTED_MODULE_15__["detectPlatform"])(),
        osId = _detectPlatform2.osId,
        browserId = _detectPlatform2.browserId;
      return this.$auth.login({
        companyLoginId: this.companyLoginId,
        username: this.username,
        password: this.password,
        machineId: '',
        osId: osId,
        browserId: browserId,
        // Geolocation capture is out of scope for FQ-3057. UserSession.Location is write-only in
        // this codebase, so an empty value costs nothing today.
        location: ''
      });
    },
    changePassword: function changePassword(newPassword) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var result, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              _this4.errorMessage = '';
              _this4.isSubmitting = true;
              _context4.p = 1;
              _context4.n = 2;
              return _this4.$auth.changePassword({
                ticket: _this4.passwordChangeTicket,
                oldPassword: _this4.password,
                newPassword: newPassword
              });
            case 2:
              // The ticket is spent, so sign in again with the new password to get a token.
              _this4.password = newPassword;
              _this4.passwordChangeTicket = '';
              _context4.n = 3;
              return _this4.submitCredentials();
            case 3:
              result = _context4.v;
              if (!(result && result.requiresTermsAcceptance)) {
                _context4.n = 4;
                break;
              }
              _this4.panel = 'login';
              _this4.termsTicket = result.ticket;
              _this4.pendingTerms = result.terms;
              return _context4.a(2);
            case 4:
              _this4.rememberCredentials();
              _this4.enterApp();
              _context4.n = 6;
              break;
            case 5:
              _context4.p = 5;
              _t3 = _context4.v;
              _this4.errorMessage = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_12__["getApiErrorMessage"])(_t3, 'Could not change your password. Please try again.');
            case 6:
              _context4.p = 6;
              _this4.isSubmitting = false;
              return _context4.f(6);
            case 7:
              return _context4.a(2);
          }
        }, _callee4, null, [[1, 5, 6, 7]]);
      }))();
    },
    rememberCredentials: function rememberCredentials() {
      if (this.rememberMe) {
        localStorage.setItem(REMEMBER_KEY, JSON.stringify({
          companyLoginId: this.companyLoginId,
          username: this.username
        }));
      } else {
        localStorage.removeItem(REMEMBER_KEY);
      }
    },
    enterApp: function enterApp() {
      // Full navigation, not router.push: App.vue runs loadResources once on router.onReady,
      // so an in-app transition would render the shell with no user or permissions loaded.
      window.location.assign(Object(_returnUrl__WEBPACK_IMPORTED_MODULE_13__["resolveAppUrl"])(this.$route.query.returnUrl));
    },
    goToForgotPassword: function goToForgotPassword() {
      this.$router.push({
        name: _route_types_js__WEBPACK_IMPORTED_MODULE_11__["default"].ForgotPasswordView.name
      });
    }
  },
  validations: {
    companyLoginId: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7__["required"]
    },
    username: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7__["required"]
    },
    password: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_7__["required"]
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _components_BulmaModal_BaseModalEx_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/BulmaModal/BaseModalEx.vue */ "./src/components/BulmaModal/BaseModalEx.vue");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_3__);



// Luxon directly rather than @/utils/DateFunctions, which imports @/store and pulls the router,
// NavService and the whole API layer in behind it. This component renders on the login page
// before any of that exists, and the format below is the one formatDateLong uses.


// Fractional element heights and non-integer device pixel ratios mean scrollTop + clientHeight
// lands a pixel or two short of scrollHeight at the bottom. Without this tolerance the button
// never enables on some displays.
var SCROLL_TOLERANCE_PX = 2;
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'TermsAcceptanceModal',
  components: {
    BaseModalEx: _components_BulmaModal_BaseModalEx_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    /** From the sign-in response: { id, versionNumber, effectiveFromUtc, contentUrl }. */
    terms: {
      type: Object,
      default: null
    },
    /**
     * Which button is currently working: 'accept', 'cancel', or null. Named rather than a plain
     * boolean so the spinner lands on the button that was actually pressed - one shared flag put
     * it on both.
     */
    busyAction: {
      type: String,
      default: null,
      validator: function validator(v) {
        return v === null || v === 'accept' || v === 'cancel';
      }
    },
    /**
     * A failed acceptance, shown inside the modal. The login page's own error alert sits behind
     * the overlay, so anything reported there while this is open is invisible.
     */
    submitError: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      content: '',
      isLoading: true,
      loadError: '',
      // Latched, never cleared: once read, resizing or zooming must not take the button away.
      hasReadToEnd: false
    };
  },
  computed: {
    isBusy: function isBusy() {
      return !!this.busyAction;
    },
    /**
     * Whether the terms have been read and are acceptable, ignoring any request already in
     * flight. Kept separate from canAccept so the hint below does not blink out and back while a
     * button is working - being busy is not a reason the terms are unread.
     *
     * `content` and `loadError` matter here, not just `hasReadToEnd`: an empty scroll container
     * reports scrollHeight === clientHeight === 0, which satisfies the scrolled-to-the-end test.
     * Without them a failed fetch would enable the button over a document that never rendered.
     */
    isReadyToAccept: function isReadyToAccept() {
      return this.hasReadToEnd && !!this.content && !this.loadError && !this.isLoading;
    },
    canAccept: function canAccept() {
      return this.isReadyToAccept && !this.isBusy;
    },
    /**
     * Why Accept & Continue is disabled, or null when it is not. A disabled button with no
     * explanation is the worst case here - the user cannot proceed and cannot tell why.
     *
     * Null rather than an empty string: Vue drops the title attribute entirely for null, where
     * '' would leave an empty tooltip behind.
     */
    acceptBlockedReason: function acceptBlockedReason() {
      if (this.isReadyToAccept) return null;
      if (this.isLoading) return 'The terms are still loading';
      if (this.loadError) return 'The terms could not be loaded';
      return 'Scroll to the end to continue';
    },
    effectiveDate: function effectiveDate() {
      if (!this.terms) return '';
      // EffectiveFromUtc is an EF DateTime with Kind=Unspecified, so it serialises without a Z
      // and would otherwise be read in the browser's zone - showing the wrong day to anyone west
      // of UTC, against a value the server compares in UTC.
      return luxon__WEBPACK_IMPORTED_MODULE_3__["DateTime"].fromISO(this.terms.effectiveFromUtc, {
        zone: 'utc'
      }).toFormat('ccc, d MMM yyyy');
    }
  },
  mounted: function mounted() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var current, _t;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.p = _context.n) {
          case 0:
            // A resize can turn a scrolling document into a non-scrolling one, which fires no scroll
            // event - so the gate has to be re-evaluated on resize as well as on scroll.
            window.addEventListener('resize', _this.evaluateScroll);
            _context.p = 1;
            _context.n = 2;
            return _this.$auth.terms.getCurrent();
          case 2:
            current = _context.v;
            // The body comes from here, but the id being accepted came from the sign-in response. If a
            // new version became effective in between the user would read one document and accept
            // another. The server rejects that pairing; this stops the modal offering it.
            if (current && _this.terms && current.id !== _this.terms.id) {
              _this.loadError = 'The Terms & Conditions have been updated. Please sign in again to review them.';
            } else {
              _this.content = current && current.content || '';
              if (!_this.content) {
                _this.loadError = 'The Terms & Conditions could not be loaded. Please try signing in again.';
              }
            }
            _context.n = 4;
            break;
          case 3:
            _context.p = 3;
            _t = _context.v;
            _this.loadError = 'The Terms & Conditions could not be loaded. Please try signing in again.';
          case 4:
            _context.p = 4;
            _this.isLoading = false;
            return _context.f(4);
          case 5:
            _context.n = 6;
            return _this.$nextTick();
          case 6:
            _this.evaluateScroll();
          case 7:
            return _context.a(2);
        }
      }, _callee, null, [[1, 3, 4, 5]]);
    }))();
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.evaluateScroll);
  },
  methods: {
    evaluateScroll: function evaluateScroll() {
      if (this.hasReadToEnd) return;

      // Nothing rendered means nothing was read. An empty container measures as fully scrolled,
      // so without this the gate would latch open on a failed load.
      if (!this.content || this.loadError) return;
      var el = this.$refs.scroller;
      if (!el) return;
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - SCROLL_TOLERANCE_PX) {
        this.hasReadToEnd = true;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("auth-card", {
    attrs: {
      title: "Sign in",
      "error-message": _vm.errorMessage
    }
  }, [_vm.panel === "newaccount" ? _c("new-password-panel", {
    attrs: {
      "id-prefix": "signin",
      username: _vm.username,
      "is-submitting": _vm.isSubmitting
    },
    on: {
      submit: _vm.changePassword
    }
  }) : _c("form", {
    on: {
      submit: function submit($event) {
        $event.preventDefault();
        return _vm.signIn.apply(null, arguments);
      }
    }
  }, [_c("div", {
    staticClass: "control mb-4"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "companyid"
    }
  }, [_vm._v("Company ID")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyLoginId,
      expression: "companyLoginId"
    }],
    staticClass: "input",
    attrs: {
      id: "companyid",
      type: "text",
      placeholder: "Company ID",
      maxlength: "10",
      autocomplete: "organization",
      required: "",
      disabled: _vm.isSubmitting
    },
    domProps: {
      value: _vm.companyLoginId
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.companyLoginId = $event.target.value;
      }
    }
  }), _vm.$v.companyLoginId.$dirty && !_vm.$v.companyLoginId.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "username"
    }
  }, [_vm._v("Username")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.username,
      expression: "username"
    }],
    staticClass: "input",
    attrs: {
      id: "username",
      type: "text",
      placeholder: "Username",
      autocomplete: "username",
      required: "",
      disabled: _vm.isSubmitting
    },
    domProps: {
      value: _vm.username
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.username = $event.target.value;
      }
    }
  }), _vm.$v.username.$dirty && !_vm.$v.username.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "field password-field"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "password"
    }
  }, [_vm._v("Password")]), _c("div", {
    staticClass: "control has-icons-right"
  }, [(_vm.passwordVisible ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.password,
      expression: "password"
    }],
    staticClass: "input",
    attrs: {
      id: "password",
      placeholder: "Password",
      autocomplete: "current-password",
      required: "",
      disabled: _vm.isSubmitting,
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.password) ? _vm._i(_vm.password, null) > -1 : _vm.password
    },
    on: {
      change: function change($event) {
        var $$a = _vm.password,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.password = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.password = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.password = $$c;
        }
      }
    }
  }) : (_vm.passwordVisible ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.password,
      expression: "password"
    }],
    staticClass: "input",
    attrs: {
      id: "password",
      placeholder: "Password",
      autocomplete: "current-password",
      required: "",
      disabled: _vm.isSubmitting,
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.password, null)
    },
    on: {
      change: function change($event) {
        _vm.password = null;
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.password,
      expression: "password"
    }],
    staticClass: "input",
    attrs: {
      id: "password",
      placeholder: "Password",
      autocomplete: "current-password",
      required: "",
      disabled: _vm.isSubmitting,
      type: _vm.passwordVisible ? "text" : "password"
    },
    domProps: {
      value: _vm.password
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.password = $event.target.value;
      }
    }
  }), _c("span", {
    staticClass: "icon is-small is-right is-clickable",
    on: {
      click: function click($event) {
        _vm.passwordVisible = !_vm.passwordVisible;
      }
    }
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.passwordVisible ? "mdi-eye-outline" : "mdi-eye-off-outline"
  })])]), _vm.$v.password.$dirty && !_vm.$v.password.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "field remember-me-container is-flex is-justify-content-space-between is-align-items-center"
  }, [_c("label", {
    staticClass: "checkbox"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.rememberMe,
      expression: "rememberMe"
    }],
    attrs: {
      type: "checkbox",
      disabled: _vm.isSubmitting
    },
    domProps: {
      checked: Array.isArray(_vm.rememberMe) ? _vm._i(_vm.rememberMe, null) > -1 : _vm.rememberMe
    },
    on: {
      change: function change($event) {
        var $$a = _vm.rememberMe,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.rememberMe = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.rememberMe = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.rememberMe = $$c;
        }
      }
    }
  }), _vm._v(" Remember me ")]), _c("a", {
    on: {
      click: function click($event) {
        $event.preventDefault();
        return _vm.goToForgotPassword.apply(null, arguments);
      }
    }
  }, [_vm._v("Forgot Password?")])])]), _c("div", {
    staticClass: "control is-flex is-justify-content-end"
  }, [_c("button", {
    staticClass: "button is-primary",
    attrs: {
      type: "submit",
      disabled: _vm.isSubmitting
    }
  }, [_c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.isSubmitting ? "mdi-loading mdi-spin" : "mdi-arrow-right"
  })]), _vm._v(" Sign In ")])])]), _vm.pendingTerms ? _c("terms-acceptance-modal", {
    attrs: {
      terms: _vm.pendingTerms,
      "busy-action": _vm.termsAction,
      "submit-error": _vm.termsError
    },
    on: {
      accept: _vm.acceptTerms,
      cancel: _vm.declineTerms
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: true,
      "can-cancel": false,
      "has-modal-card": "",
      "min-width": 42,
      "max-height": 90,
      role: "dialog",
      "aria-modal": "true"
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("span", {
    staticClass: "title-badge has-background-primary mr-4"
  }, [_c("i", {
    staticClass: "mdi mdi-24px mdi-file-document-outline"
  })]), _c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Terms & Conditions Update")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("p", {
    staticClass: "mb-4"
  }, [_vm._v("Please take a moment to review what’s changed below.")]), _vm.loadError ? _c("p", {
    staticClass: "help is-danger mb-3"
  }, [_vm._v(_vm._s(_vm.loadError))]) : _vm._e(), _vm.isLoading ? _c("div", {
    staticClass: "terms-viewport is-flex is-flex-direction-column is-justify-content-center has-text-centered has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-24px mdi-loading mdi-spin"
  }), _c("p", {
    staticClass: "mt-2"
  }, [_vm._v("Loading the terms…")])]) : _c("div", {
    ref: "scroller",
    staticClass: "terms-viewport terms-content content",
    attrs: {
      tabindex: "0"
    },
    domProps: {
      innerHTML: _vm._s(_vm.content)
    },
    on: {
      scroll: _vm.evaluateScroll
    }
  }), _c("div", {
    staticClass: "terms-meta is-flex is-justify-content-space-between is-align-items-baseline mt-3"
  }, [_vm.terms ? _c("span", {
    staticClass: "is-size-7 has-text-grey"
  }, [_vm._v(" Version " + _vm._s(_vm.terms.versionNumber) + " · Effective " + _vm._s(_vm.effectiveDate) + " ")]) : _c("span"), _vm.terms && _vm.terms.contentUrl ? _c("a", {
    staticClass: "is-size-7 has-text-primary has-text-weight-medium",
    attrs: {
      href: _vm.terms.contentUrl,
      target: "_blank",
      rel: "noopener noreferrer"
    }
  }, [_vm._v(" Download full PDF "), _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-arrow-down"
  })])]) : _vm._e()])]), _c("footer", {
    staticClass: "modal-card-foot is-flex-direction-column is-align-items-stretch"
  }, [_vm.submitError ? _c("p", {
    staticClass: "help is-danger has-text-right mb-2",
    attrs: {
      role: "alert"
    }
  }, [_vm._v(_vm._s(_vm.submitError))]) : _vm._e(), _c("p", {
    staticClass: "accept-hint is-size-7 has-text-grey has-text-right mb-2"
  }, [_vm._v(" " + _vm._s(_vm.acceptBlockedReason) + " ")]), _c("div", {
    staticClass: "is-flex is-justify-content-flex-end is-align-items-center"
  }, [_c("button", {
    staticClass: "button mr-3",
    attrs: {
      type: "button",
      disabled: _vm.isBusy
    },
    on: {
      click: function click($event) {
        return _vm.$emit("cancel");
      }
    }
  }, [_c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.busyAction === "cancel" ? "mdi-loading mdi-spin" : "mdi-arrow-left"
  })]), _vm._v(" Cancel and log out ")]), _c("button", {
    staticClass: "button is-success accept-button",
    attrs: {
      type: "button",
      disabled: !_vm.canAccept,
      title: _vm.acceptBlockedReason
    },
    on: {
      click: function click($event) {
        return _vm.$emit("accept");
      }
    }
  }, [_c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.busyAction === "accept" ? "mdi-loading mdi-spin" : "mdi-check"
  })]), _vm._v(" Accept & Continue ")])]), _c("p", {
    staticClass: "is-size-7 has-text-grey mt-4 mb-0"
  }, [_vm._v(" Recorded against "), _c("strong", {
    staticClass: "has-text-grey-light"
  }, [_vm._v("your user account")]), _vm._v(" with today’s date and time for audit purposes. ")])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".label[data-v-2758517f] {\n  font-weight: 500;\n}\n.password-field[data-v-2758517f] {\n  margin-bottom: 40px;\n}\n.remember-me-container[data-v-2758517f] {\n  font-size: 0.9rem;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".modal-card-head[data-v-434dd88c] {\n  padding: 1.5rem;\n}\n.modal-card-title[data-v-434dd88c] {\n  margin-bottom: 0;\n  font-size: 1.35rem;\n  font-weight: 700;\n  -ms-flex-negative: 1;\n      flex-shrink: 1;\n}\n.title-badge[data-v-434dd88c] {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-flex: 0;\n      -ms-flex: 0 0 auto;\n          flex: 0 0 auto;\n  width: 2.75rem;\n  height: 2.75rem;\n  border-radius: 0.65rem;\n  color: #fff;\n}\n.modal-card-body[data-v-434dd88c] {\n  padding: 1.5rem;\n}\n.terms-viewport[data-v-434dd88c] {\n  height: 17rem;\n  border: 1px solid rgba(127, 127, 127, 0.35);\n  border-radius: 6px;\n}\n.terms-content[data-v-434dd88c] {\n  overflow-y: auto;\n  padding: 1rem 1.25rem;\n  scrollbar-gutter: stable;\n}\n.terms-content[data-v-434dd88c] > :first-child {\n  margin-top: 0;\n}\n.terms-meta a[data-v-434dd88c] {\n  white-space: nowrap;\n}\n.modal-card-foot[data-v-434dd88c] {\n  padding: 1.25rem 1.5rem 1.5rem;\n}\n.accept-hint[data-v-434dd88c] {\n  min-height: 1.15rem;\n}\n.accept-button[data-v-434dd88c] {\n  padding-left: 1.5rem;\n  padding-right: 1.5rem;\n  font-weight: 600;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("0228877d", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("865bb210", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/auth/SignIn.vue":
/*!***********************************!*\
  !*** ./src/views/auth/SignIn.vue ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SignIn.vue?vue&type=template&id=2758517f&scoped=true */ "./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true");
/* harmony import */ var _SignIn_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SignIn.vue?vue&type=script&lang=js */ "./src/views/auth/SignIn.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true */ "./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SignIn_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2758517f",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/SignIn.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/SignIn.vue?vue&type=script&lang=js":
/*!***********************************************************!*\
  !*** ./src/views/auth/SignIn.vue?vue&type=script&lang=js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SignIn.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true":
/*!********************************************************************************************!*\
  !*** ./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=style&index=0&id=2758517f&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_style_index_0_id_2758517f_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true":
/*!*****************************************************************************!*\
  !*** ./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SignIn.vue?vue&type=template&id=2758517f&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/SignIn.vue?vue&type=template&id=2758517f&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SignIn_vue_vue_type_template_id_2758517f_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/auth/TermsAcceptanceModal.vue":
/*!*************************************************!*\
  !*** ./src/views/auth/TermsAcceptanceModal.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true */ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true");
/* harmony import */ var _TermsAcceptanceModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TermsAcceptanceModal.vue?vue&type=script&lang=js */ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true */ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _TermsAcceptanceModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "434dd88c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/TermsAcceptanceModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./TermsAcceptanceModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=style&index=0&id=434dd88c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_style_index_0_id_434dd88c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true":
/*!*******************************************************************************************!*\
  !*** ./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/TermsAcceptanceModal.vue?vue&type=template&id=434dd88c&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TermsAcceptanceModal_vue_vue_type_template_id_434dd88c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/auth/legacyRememberCookies.js":
/*!*************************************************!*\
  !*** ./src/views/auth/legacyRememberCookies.js ***!
  \*************************************************/
/*! exports provided: readLegacyRememberedLogin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "readLegacyRememberedLogin", function() { return readLegacyRememberedLogin; });
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.starts-with.js */ "./node_modules/core-js/modules/es.string.starts-with.js");
/* harmony import */ var core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_starts_with_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__);







/**
 * PCK-655: the legacy sign-in page's Remember me cookies, used to seed this page the first
 * time a user arrives here. They expire after a day and nothing refreshes them once the
 * legacy page is redirected away, so this is a one-off migration seed, not a store.
 */
var COMPANY_COOKIE = 'CompanyLoginId';
var USERNAME_COOKIE = 'Username';
function readCookie(name) {
  var prefix = "".concat(name, "=");
  var entry = document.cookie.split('; ').find(function (c) {
    return c.startsWith(prefix);
  });
  if (!entry) return '';
  var raw = entry.slice(prefix.length);
  try {
    return decodeURIComponent(raw).trim();
  } catch (e) {
    return raw.trim(); // malformed encoding - the raw value beats nothing
  }
}

// Either field is blank when its cookie is missing, empty or whitespace-only.
function readLegacyRememberedLogin() {
  return {
    companyLoginId: readCookie(COMPANY_COOKIE),
    username: readCookie(USERNAME_COOKIE)
  };
}

/***/ })

}]);
//# sourceMappingURL=28.js.map