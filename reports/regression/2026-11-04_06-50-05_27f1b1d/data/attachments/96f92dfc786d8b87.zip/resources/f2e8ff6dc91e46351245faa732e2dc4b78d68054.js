(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["contact-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/AssetSearchModal.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/AssetSearchModal.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _enums_AssetTypes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/enums/AssetTypes */ "./src/enums/AssetTypes.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _views_company_CompanyService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/views/company/CompanyService */ "./src/views/company/CompanyService.js");
/* harmony import */ var _views_customer_CustomerService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/views/customer/CustomerService */ "./src/views/customer/CustomerService.js");
/* harmony import */ var _views_contact_ContactService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/views/contact/ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var _views_vendor_VendorService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/views/vendor/VendorService */ "./src/views/vendor/VendorService.js");
/* harmony import */ var _views_insurer_InsurerService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/views/insurer/InsurerService */ "./src/views/insurer/InsurerService.js");
/* harmony import */ var _assets_validateForms_AssetSearchForm__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/assets/validateForms/AssetSearchForm */ "./src/assets/validateForms/AssetSearchForm.js");














/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    CardModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_4__["CardModal"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_5__["BulmaAutocomplete"]
  },
  mixins: [_assets_validateForms_AssetSearchForm__WEBPACK_IMPORTED_MODULE_13__["default"]],
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    assetType: {
      type: String,
      default: ''
    },
    asset: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      assetName: String,
      options: []
    };
  },
  computed: {
    assetTypes: function assetTypes() {
      return _enums_AssetTypes__WEBPACK_IMPORTED_MODULE_6__["default"];
    }
  },
  mounted: function mounted() {
    this.form.assetType = this.assetType;
    this.form.asset = this.asset;
    if (this.asset && this.asset.value) {
      this.assetName = this.asset.value;
    } else {
      this.assetName = '';
    }
    setTimeout(function () {
      document.getElementById('searcher').focus();
    }, 500);
  },
  methods: {
    search: lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(key) {
        var rs, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (key) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              rs = {};
              _t = this.form.assetType.toString();
              _context.n = _t === '0' ? 2 : _t === '1' ? 4 : _t === '2' ? 6 : _t === '3' ? 8 : _t === '4' ? 10 : 12;
              break;
            case 2:
              _context.n = 3;
              return _views_company_CompanyService__WEBPACK_IMPORTED_MODULE_8__["default"].searchCompanyByName(key);
            case 3:
              rs = _context.v;
              return _context.a(3, 12);
            case 4:
              _context.n = 5;
              return _views_customer_CustomerService__WEBPACK_IMPORTED_MODULE_9__["default"].searchCustomerByName(key);
            case 5:
              rs = _context.v;
              return _context.a(3, 12);
            case 6:
              _context.n = 7;
              return _views_contact_ContactService__WEBPACK_IMPORTED_MODULE_10__["default"].searchContactByName(key);
            case 7:
              rs = _context.v;
              return _context.a(3, 12);
            case 8:
              _context.n = 9;
              return _views_vendor_VendorService__WEBPACK_IMPORTED_MODULE_11__["default"].searchVendorByName(key);
            case 9:
              rs = _context.v;
              return _context.a(3, 12);
            case 10:
              _context.n = 11;
              return _views_insurer_InsurerService__WEBPACK_IMPORTED_MODULE_12__["default"].searchInsurerByName(key);
            case 11:
              rs = _context.v;
              return _context.a(3, 12);
            case 12:
              this.options = rs.data.list;
            case 13:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    change: function change(val) {
      this.form.asset = val;
      console.log(this.form.asset);
    },
    typeChanged: function typeChanged() {
      this.assetName = '';
      this.form.asset = null;
      this.options = [];
    },
    ok: function ok() {
      if (this.$v.$invalid) {
        this.$v.$touch();
      } else {
        this.$emit('ok', {
          assetType: this.form.assetType,
          asset: {
            key: this.form.asset.key,
            value: this.form.asset.value
          },
          isDirty: this.$v.$dirty
        });
        this.visible = false;
      }
    },
    close: function close() {
      // If this is not here
      // Dialog will not show up if [x] or outside of modal is clicked
      this.visible = false;
    },
    cancel: function cancel() {
      this.visible = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactAsset.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactAsset.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_get_own_property_names_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.get-own-property-names.js */ "./node_modules/core-js/modules/es.object.get-own-property-names.js");
/* harmony import */ var core_js_modules_es_object_get_own_property_names_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_get_own_property_names_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var _enums_AssetTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/enums/AssetTypes */ "./src/enums/AssetTypes.js");
/* harmony import */ var _components_AssetSearchModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/AssetSearchModal */ "./src/components/AssetSearchModal.vue");







var AssetSearchComponent = vue__WEBPACK_IMPORTED_MODULE_4__["default"].extend(_components_AssetSearchModal__WEBPACK_IMPORTED_MODULE_6__["default"]);
/* harmony default export */ __webpack_exports__["default"] = ({
  props: {
    entity: null,
    isTiled: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      cardModal: null
    };
  },
  computed: {
    assetTypes: function assetTypes() {
      return Object.getOwnPropertyNames(_enums_AssetTypes__WEBPACK_IMPORTED_MODULE_5__["default"]);
      // return AssetTypes
    }
  },
  methods: {
    addAsset: function addAsset() {
      var _this = this;
      var asset = {
        id: '00000000-0000-0000-0000-000000000000',
        assetType: '1',
        assetId: '',
        name: '',
        isNew: true,
        isDeleted: false
      };
      this.cardModal = new AssetSearchComponent({
        el: document.createElement('div'),
        propsData: {
          visible: false,
          assetType: asset.assetType
        }
      }).$on('ok', function (res) {
        asset.assetType = res.assetType;
        asset.assetId = res.asset.key;
        asset.name = res.asset.value;
        _this.entity.assets.push(asset);
      });
      this.cardModal.visible = true;
    },
    editAsset: function editAsset(asset) {
      this.cardModal = new AssetSearchComponent({
        el: document.createElement('div'),
        propsData: {
          visible: false,
          assetType: asset.assetType,
          asset: {
            key: asset.assetId,
            value: asset.name
          }
        }
      }).$on('ok', function (res) {
        asset.assetType = res.assetType;
        asset.assetId = res.asset.key;
        asset.name = res.asset.value;
        asset.isDirty = res.isDirty;
      });
      this.cardModal.visible = true;
    },
    removeAsset: function removeAsset(idx) {
      var asset = this.entity.assets[idx];
      if (asset.isNew) {
        this.entity.assets.splice(idx, 1);
      } else {
        asset.isDeleted = true;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactNew.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactNew.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./storeMixin */ "./src/views/contact/storeMixin.js");



// import ContactService from './ContactService'

// import _isEmpty from 'lodash/isEmpty'

/* harmony default export */ __webpack_exports__["default"] = ({
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_3__["default"]],
  mounted: function mounted() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var fName, lName;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            document.title = 'Creating New Contact';
            fName = '';
            lName = '';
            if (_this.$route.query.fname) {
              fName = _this.$route.query.fname;
            }
            if (_this.$route.query.lname) {
              lName = _this.$route.query.lname;
            }
            _this.addStoreItem(["".concat(fName, " ").concat(lName)]);
            // const res = await ContactService.getNewContact(fName, lName)

            // // this.$store.dispatch('contacts/store', res.data)
            // if (this.newAsset && !_isEmpty(this.newAsset)) {
            //   res.data.assets.push(this.newAsset)
            // }
            // const item = {
            //   id: res.data.id,
            //   entity: res.data
            // }
            // this.saveStoreItem(item)

            // this.$router.replace({
            //   name: 'ContactDetail',
            //   params: {
            //     contactId: res.data.id
            //   },
            //   query: this.$route.query
            // })
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ContactService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./route-types */ "./src/views/contact/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _ContactFormValidation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ContactFormValidation */ "./src/views/contact/ContactFormValidation.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/views/quickinvoice/route-types */ "./src/views/quickinvoice/route-types.js");
/* harmony import */ var _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _views_sundrycreditor_route_types__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/views/sundrycreditor/route-types */ "./src/views/sundrycreditor/route-types.js");
/* harmony import */ var _views_purchaseorder_route_types__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/views/purchaseorder/route-types */ "./src/views/purchaseorder/route-types.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./storeMixin */ "./src/views/contact/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");













// import EventBus from '@/components/EventBus'













/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ContactView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_10__["default"],
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_11__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__["SaveConflictModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__["ConfirmModal"]
  },
  mixins: [_ContactFormValidation__WEBPACK_IMPORTED_MODULE_12__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_19__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    params: String,
    firstname: String,
    lastname: String,
    assetType: String,
    assetId: String,
    assetName: String
  },
  data: function data() {
    return {
      entity: null,
      dataChanged: false,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isSkipSave: false,
      isAddNew: false,
      isDeleteConfirmModalActive: false,
      toRoute: null
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error || this.$v.emailsPhonesGroup.$error || this.$v.addressesGroup.$error;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_9___default.a;
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var payload;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (!(_this.$route.query.mode === 'new')) {
              _context.n = 2;
              break;
            }
            _this.$showSpinner('Creating...');
            payload = new _classes__WEBPACK_IMPORTED_MODULE_22__["ContactPayload"]("".concat(_this.firstname, " ").concat(_this.lastname), _this.assetId, _this.assetType, _this.assetName, false);
            _context.n = 1;
            return _this.addStoreItem(payload);
          case 1:
            _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default()(_this.currentSnapshot);
            _this.persistQueries();
            _this.replaceRoute(_this.entity.id);
            _this.$hideSpinner();
            _context.n = 3;
            break;
          case 2:
            _this.getEntity();
          case 3:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {
    this.clearSessionStorage();
    this.clearSnapshots(this.entity.id);
  },
  methods: {
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _this2.entity = null;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSnapshots(_this2.$route.params.contactId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.contactId);
            case 2:
              _this2.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default()(_this2.currentSnapshot);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              // EventBus.$emit('serviceError', e.response.status)
              console.log(_t);
              // this.$notification.openMessageXhrError('', e)
            case 4:
              _context2.p = 4;
              _this2.$hideSpinner();
              return _context2.f(4);
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3, 4, 5]]);
      }))();
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Delete:
          this.deleteAndSave = true;
          this.deleteEntity(true, false, true);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_14__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    onToggleActive: function onToggleActive() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!_this3.entity.isActive) {
                _context3.n = 1;
                break;
              }
              _context3.n = 2;
              break;
            case 1:
              _this3.deleteAndSave = false;
              _context3.n = 2;
              return _this3.deleteEntity(true, _this3.entity.isActive, false);
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    deleteEntity: function deleteEntity(check, value, saveEntity) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var isInUse, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isDeleteConfirmModalActive = false;
              if (!check) {
                _context4.n = 2;
                break;
              }
              _context4.n = 1;
              return _ContactService__WEBPACK_IMPORTED_MODULE_8__["default"].assertUsed(_this4.entity.id);
            case 1:
              _t2 = _context4.v;
              _context4.n = 3;
              break;
            case 2:
              _t2 = false;
            case 3:
              isInUse = _t2;
              if (isInUse) {
                _this4.isDeleteConfirmModalActive = true;
              } else {
                _this4.entity.isActive = value;
                if (saveEntity) {
                  _this4.save(true);
                }
              }
            case 4:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    print: function print() {
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        ContactID: this.entity.id
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_22__["Emailer"]();
      emailer.assetId = this.entity.id;
      emailer.subject = 'Contact Profile Detail';
      emailer.reportName = 'rptTableContactProfileDetails';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_23__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    },
    save: function save(isDelete) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              if (!_this5.$v.$invalid) {
                _context5.n = 1;
                break;
              }
              _this5.$notification.validationError('Contact');
              return _context5.a(2, false);
            case 1:
              _this5.$showSpinner();
              _context5.p = 2;
              _this5.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default()(_this5.entity));
              if (!_this5.entity.isNew) {
                _context5.n = 5;
                break;
              }
              _context5.n = 3;
              return _ContactService__WEBPACK_IMPORTED_MODULE_8__["default"].postContact(_this5.entity);
            case 3:
              _this5.$notification.success('Save', 'Successful');
              _this5.dataChanged = false;
              _context5.n = 4;
              return _this5.getEntity(true);
            case 4:
              _context5.n = 9;
              break;
            case 5:
              if (!_this5.snapshotDiff) {
                _context5.n = 8;
                break;
              }
              _this5.entity.deepDiff = JSON.stringify(_this5.snapshotDiff);
              _context5.n = 6;
              return _ContactService__WEBPACK_IMPORTED_MODULE_8__["default"].putContact(_this5.entity);
            case 6:
              _this5.$notification.openNotificationWithType('success', 'Contact', isDelete ? 'Contact set to In-Active' : 'Save successful');
              _context5.n = 7;
              return _this5.getEntity(true);
            case 7:
              _context5.n = 9;
              break;
            case 8:
              _this5.$notification.openNotificationWithType('warning', 'Contact', 'No changes detected. Not saved');
            case 9:
              _this5.$hideSpinner();
              return _context5.a(2, true);
            case 10:
              _context5.p = 10;
              _t3 = _context5.v;
              if (_t3.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_13__["default"].CONFLICT) {
                _this5.isSaveConflictModalActive = true;
              } else {
                _this5.$notification.openMessageXhrError('', _t3);
              }
              _this5.$hideSpinner();
              return _context5.a(2, false);
          }
        }, _callee5, null, [[2, 10]]);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default()(this.entity));
      if (this.returnUrl) {
        if (this.snapshotDiff && !this.isSkipSave) {
          this.isUnsavedModalActive = true;
        } else {
          this.$showSpinner('Returning...');
          var url = "".concat("").concat(this.returnUrl, "&params=").concat(this.params, "&contactId=").concat(this.$route.params.contactId);
          this.clearSessionStorage();
          this.clearSnapshots(this.entity.id);
          window.location.href = url;
        }
      } else {
        if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21___default()(this.returnRoute)) {
          this.$router.push({
            path: this.returnRoute.path
          });
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else {
          this.$router.push({
            path: _route_types__WEBPACK_IMPORTED_MODULE_9___default.a.ContactListView.path
          });
        }
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.toRoute = null;
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var saveResult;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isUnsavedModalActive = false;
              if (!_this6.validateError) {
                _context6.n = 1;
                break;
              }
              _this6.$notification.validationError('Contact save');
              _context6.n = 3;
              break;
            case 1:
              _context6.n = 2;
              return _this6.save();
            case 2:
              saveResult = _context6.v;
              if (saveResult) {
                _this6.cancel();
              }
            case 3:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    reloadData: function reloadData() {
      this.isSaveConflictModalActive = false;
      this.getEntity(true);
    },
    replaceRoute: function replaceRoute(id) {
      // console.log(this.returnUrl)
      var newMeta = Object.assign(this.$route.meta, {
        isNew: true,
        returnUrl: this.returnUrl,
        params: this.params,
        firstname: this.firstname,
        lastname: this.lastname,
        assetType: this.assetType,
        assetId: this.assetId,
        assetName: this.assetName
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_9___default.a.ContactDetail.name,
        params: {
          contactId: id
        },
        meta: newMeta
      });
    },
    persistQueries: function persistQueries() {
      if (this.isNew) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|isNew"), this.isNew);
      }
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|returnUrl"), this.returnUrl);
      }
      if (this.params) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|params"), this.params);
      }
      if (this.firstname) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|firstname"), this.firstname);
      }
      if (this.lastname) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|lastname"), this.lastname);
      }
      if (this.assetType) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|assetType"), this.assetType);
      }
      if (this.assetId) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|assetId"), this.assetId);
      }
      if (this.assetName) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|contact|assetName"), this.assetName);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|isNew"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|params"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|firstname"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|lastname"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|assetType"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|assetId"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|contact|assetName"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_20___default()(this.entity));
    // console.log(this.snapshotDiff)
    if (this.snapshotDiff && !this.isSkipSave) {
      this.toRoute = to;
      this.$router.replace(from.path);
      this.isUnsavedModalActive = true;
    } else {
      if (to.name === _views_quickinvoice_route_types__WEBPACK_IMPORTED_MODULE_16___default.a.QuickInvoiceDetail.name) {
        if (!this.entity.isNew) {
          this.setQuickInvoiceContactId(this.entity.id);
        }
      }
      if (to.name === _views_sundrycreditor_route_types__WEBPACK_IMPORTED_MODULE_17__["default"].SundryCreditorDetail.name) {
        if (!this.entity.isNew) {
          this.setSundryCreditorContact({
            contact: {
              key: this.entity.id,
              value: "".concat(this.entity.firstName, " ").concat(this.entity.lastName)
            }
          });
        }
      }
      if (to.name === _views_purchaseorder_route_types__WEBPACK_IMPORTED_MODULE_18__["default"].PurchaseOrderDetail.name) {
        if (!this.entity.isNew) {
          this.setPurchaseOrderContact({
            contact: {
              key: this.entity.id,
              value: "".concat(this.entity.firstName, " ").concat(this.entity.lastName)
            }
          });
        }
      }
      this.setReturnRoute({});
      this.clearSnapshots(this.entity.id);
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("card-modal", {
    attrs: {
      visible: _vm.visible,
      title: "Asset Search"
    },
    on: {
      ok: _vm.ok,
      close: _vm.close,
      cancel: _vm.cancel
    }
  }, [_c("div", {
    staticClass: "content",
    staticStyle: {
      height: "350px"
    }
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Type")])]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.form.assetType,
      expression: "form.assetType"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.form, "assetType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, _vm.typeChanged]
    }
  }, _vm._l(_vm.assetTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: a
      }
    }, [_vm._v(_vm._s(b))]);
  }), 0)])])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Asset")])]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      id: "searcher",
      data: _vm.options,
      "keep-first": true,
      expanded: true,
      type: _vm.$v.form.asset.required ? "" : "is-danger"
    },
    on: {
      input: _vm.search,
      select: _vm.change
    },
    model: {
      value: _vm.assetName,
      callback: function callback($$v) {
        _vm.assetName = $$v;
      },
      expression: "assetName"
    }
  }), !_vm.$v.form.asset.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Asset is required")]) : _vm._e()], 1)])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9 ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "tile is-parent": _vm.isTiled
    }
  }, [_c("article", {
    class: {
      "tile is-child box": _vm.isTiled
    }
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Links")]), _c("table", {
    staticClass: "table is-fullwidth is-narrow"
  }, [_vm._m(0), _c("tbody", _vm._l(_vm.entity.assets, function (i, idx) {
    return _c("tr", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !i.isDeleted,
        expression: "!i.isDeleted"
      }],
      key: idx
    }, [_c("td", [_vm._v(_vm._s(idx + 1))]), _c("td", [_vm._v(_vm._s(_vm.assetTypes[i.assetType - 1]))]), _c("td", [_vm._v(_vm._s(i.name))]), _c("td", {
      staticStyle: {
        "text-align": "right"
      }
    }, [_c("button", {
      staticClass: "button is-primary is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.editAsset(i);
        }
      }
    }, [_vm._m(1, true)]), _c("button", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.removeAsset(idx);
        }
      }
    }, [_vm._m(2, true)])])]);
  }), 0)]), _c("div", {
    staticClass: "has-text-right"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Add new link"
    },
    on: {
      click: function click($event) {
        return _vm.addAsset();
      }
    }
  }, [_vm._m(3)])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v(" No. ")]), _c("th", [_vm._v(" Type ")]), _c("th", [_vm._v(" Name ")]), _c("th")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-lead-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9 ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm._m(0);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "level",
    staticStyle: {
      height: "80vh"
    }
  }, [_c("div", {
    staticClass: "level-item"
  }, [_c("i", {
    staticClass: "mdi mdi-spin mdi-loading",
    attrs: {
      "aria-hidden": "true"
    }
  }), _c("span", [_vm._v("  Preparing new contact...")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactView.vue?vue&type=template&id=363f622c":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/contact/ContactView.vue?vue&type=template&id=363f622c ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.entity ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-delete": _vm.entity.isActive && !_vm.entity.isNew,
      "show-print": !_vm.entity.isNew
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_c("strong", [_vm._v(_vm._s(_vm.entity.firstName ? _vm.entity.firstName : "Name") + " " + _vm._s(_vm.entity.lastName))])])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ContactDetail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.detailGroup.$error ? "" : null
    }
  }, [_vm._v(" Detail Info ")])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ContactAsset.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      append: ""
    }
  }, [_vm._v("Links")])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ContactAddress.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      append: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.addressesGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.addressesGroup.$error ? "" : null
    }
  }, [_vm._v(" Addresses ")])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ContactPhoneEmail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      append: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.emailsPhonesGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.emailsPhonesGroup.$error ? "" : null
    }
  }, [_vm._v(" Phones/Emails ")])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ContactRemark.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      append: ""
    }
  }, [_vm._v("Remarks")])], 1)])])])], 1), _c("div", {
    staticClass: "column"
  }, [_c("router-view", {
    attrs: {
      entity: _vm.entity
    },
    on: {
      toggleActive: _vm.onToggleActive
    }
  })], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isDeleteConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(false, false, _vm.deleteAndSave);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false, true, false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Contact is in use")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.entity.firstName) + " " + _vm._s(_vm.entity.lastName))]), _vm._v(" is in use. Set to "), _c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v("In-Active")]), _vm._v(" anyway? ")])])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./src/assets/validateForms/Address.js":
/*!*********************************************!*\
  !*** ./src/assets/validateForms/Address.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  addresses: {
    $each: {
      address1: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbPostcode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/AssetSearchForm.js":
/*!*****************************************************!*\
  !*** ./src/assets/validateForms/AssetSearchForm.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      form: {
        assetType: 0,
        asset: {
          key: '',
          value: ''
        }
      }
    };
  },
  validations: {
    form: {
      assetType: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      asset: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Emails.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Emails.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  emails: {
    $each: {
      address: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["email"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Phones.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Phones.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  phones: {
    $each: {
      no: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/components/AssetSearchModal.vue":
/*!*********************************************!*\
  !*** ./src/components/AssetSearchModal.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AssetSearchModal.vue?vue&type=template&id=37aa0a85 */ "./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85");
/* harmony import */ var _AssetSearchModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AssetSearchModal.vue?vue&type=script&lang=js */ "./src/components/AssetSearchModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AssetSearchModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/AssetSearchModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/AssetSearchModal.vue?vue&type=script&lang=js":
/*!*********************************************************************!*\
  !*** ./src/components/AssetSearchModal.vue?vue&type=script&lang=js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssetSearchModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./AssetSearchModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/AssetSearchModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssetSearchModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85":
/*!***************************************************************************!*\
  !*** ./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85 ***!
  \***************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./AssetSearchModal.vue?vue&type=template&id=37aa0a85 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/AssetSearchModal.vue?vue&type=template&id=37aa0a85");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssetSearchModal_vue_vue_type_template_id_37aa0a85__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/ContactAsset.vue":
/*!********************************************!*\
  !*** ./src/views/contact/ContactAsset.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactAsset.vue?vue&type=template&id=407543f9 */ "./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9");
/* harmony import */ var _ContactAsset_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactAsset.vue?vue&type=script&lang=js */ "./src/views/contact/ContactAsset.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactAsset_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/contact/ContactAsset.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/contact/ContactAsset.vue?vue&type=script&lang=js":
/*!********************************************************************!*\
  !*** ./src/views/contact/ContactAsset.vue?vue&type=script&lang=js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactAsset_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactAsset.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactAsset.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactAsset_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9":
/*!**************************************************************************!*\
  !*** ./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9 ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactAsset.vue?vue&type=template&id=407543f9 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactAsset.vue?vue&type=template&id=407543f9");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactAsset_vue_vue_type_template_id_407543f9__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/ContactFormValidation.js":
/*!****************************************************!*\
  !*** ./src/views/contact/ContactFormValidation.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.firstName', 'entity.lastName'],
    emailsPhonesGroup: ['entity.emails', 'entity.phones'],
    addressesGroup: ['entity.addresses'],
    entity: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      firstName: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
      },
      lastName: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
      }
    }, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_2__["default"]), _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_3__["default"]), _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_4__["default"])
  }
});

/***/ }),

/***/ "./src/views/contact/ContactNew.vue":
/*!******************************************!*\
  !*** ./src/views/contact/ContactNew.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactNew.vue?vue&type=template&id=3bd212e9 */ "./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9");
/* harmony import */ var _ContactNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactNew.vue?vue&type=script&lang=js */ "./src/views/contact/ContactNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/contact/ContactNew.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/contact/ContactNew.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/contact/ContactNew.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactNew.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9":
/*!************************************************************************!*\
  !*** ./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9 ***!
  \************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactNew.vue?vue&type=template&id=3bd212e9 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactNew.vue?vue&type=template&id=3bd212e9");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactNew_vue_vue_type_template_id_3bd212e9__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/ContactView.vue":
/*!*******************************************!*\
  !*** ./src/views/contact/ContactView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ContactView.vue?vue&type=template&id=363f622c */ "./src/views/contact/ContactView.vue?vue&type=template&id=363f622c");
/* harmony import */ var _ContactView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ContactView.vue?vue&type=script&lang=js */ "./src/views/contact/ContactView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ContactView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/contact/ContactView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/contact/ContactView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/contact/ContactView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/contact/ContactView.vue?vue&type=template&id=363f622c":
/*!*************************************************************************!*\
  !*** ./src/views/contact/ContactView.vue?vue&type=template&id=363f622c ***!
  \*************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ContactView.vue?vue&type=template&id=363f622c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/contact/ContactView.vue?vue&type=template&id=363f622c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactView_vue_vue_type_template_id_363f622c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/contact/storeMixin.js":
/*!*****************************************!*\
  !*** ./src/views/contact/storeMixin.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'contacts';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'addNewEntity', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quickinvoices', {
    setQuickInvoiceContactId: 'setContactId'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('sundrycreditors', {
    setSundryCreditorContact: 'setContact'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('purchaseorders', {
    setPurchaseOrderContact: 'setContact'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=contact-chunk.js.map