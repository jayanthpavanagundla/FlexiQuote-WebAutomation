(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vehicle-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _views_customer_CustomerService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/views/customer/CustomerService */ "./src/views/customer/CustomerService.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_9__);










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleCustomer',
  components: {
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_9___default.a
  },
  mixins: [_components_directives__WEBPACK_IMPORTED_MODULE_6__["InputValidationDirective"], _storeMixin__WEBPACK_IMPORTED_MODULE_7__["default"]],
  inject: ['$vv'],
  props: {
    value: {
      type: Object
    }
  },
  data: function data() {
    return {
      customers: [],
      isCustomerLoading: false,
      customerExists: false,
      assetFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_8__["default"].empty(),
        assetName: '',
        pageIndex: 1,
        pageSize: 50
      }
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv;
    },
    customerId: function customerId() {
      if (this.value && this.value.key) {
        return this.value.key;
      }
      return '';
    },
    customerText: function customerText() {
      if (this.value && this.value.value) {
        return this.value.value;
      } else {
        return '';
      }
    }
  },
  mounted: function mounted() {
    if (this.customerId !== '') {
      this.customerExists = true;
      this.customers.push(this.value);
    } else {
      this.customerExists = false;
      this.getCustomersDropdown();
    }
  },
  methods: {
    getCustomersDropdown: function () {
      var _getCustomersDropdown = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              this.isCustomerLoading = true;
              if (query && this.value) {
                this.$emit('input', null);
              }
              this.assetFilter.name = query;
              _context.n = 1;
              return _views_customer_CustomerService__WEBPACK_IMPORTED_MODULE_5__["default"].getCustomerDropdownProto(this.assetFilter);
            case 1:
              this.customers = _context.v;
              this.isCustomerLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      function getCustomersDropdown(_x) {
        return _getCustomersDropdown.apply(this, arguments);
      }
      return getCustomersDropdown;
    }(),
    searchCustomer: lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default()(function (val) {
      if (val === '') {
        return;
      }
      if (this.value && this.value.value) {
        if (val === this.value.value) {
          return;
        }
      }
      this.$emit('input', null);
      this.customerExists = false;
      this.getCustomersDropdown(val);
    }, 500),
    changeCustomer: function changeCustomer(val) {
      if (val) {
        this.customerExists = true;
      } else {
        this.customerExists = false;
      }
      this.$emit('input', val);
    },
    addCustomer: function addCustomer() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this.setCustomerReturnRoute(_this.$route);
              _this.addStoreCustomer(_this.assetFilter.name);
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    editCustomer: function editCustomer() {
      this.setCustomerReturnRoute(this.$route);
      this.editStoreCustomer(this.customerId);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _VehicleService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./VehicleService */ "./src/views/vehicle/VehicleService.js");
/* harmony import */ var _VehicleEngine__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./VehicleEngine */ "./src/views/vehicle/VehicleEngine.vue");
/* harmony import */ var _VehicleModel__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./VehicleModel */ "./src/views/vehicle/VehicleModel.vue");
/* harmony import */ var _VehicleCustomer__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./VehicleCustomer */ "./src/views/vehicle/VehicleCustomer.vue");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_VehicleLookupModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/VehicleLookupModal */ "./src/components/VehicleLookupModal/index.js");
























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleDetail',
  inject: ['$vv'],
  components: {
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_18__["TheMask"],
    VehicleEngine: _VehicleEngine__WEBPACK_IMPORTED_MODULE_15__["default"],
    VehicleModel: _VehicleModel__WEBPACK_IMPORTED_MODULE_16__["default"],
    VehicleCustomer: _VehicleCustomer__WEBPACK_IMPORTED_MODULE_17__["default"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_21__["BulmaAutocomplete"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_22__["default"],
    VehicleLookupModal: _components_VehicleLookupModal__WEBPACK_IMPORTED_MODULE_23__["VehicleLookupModal"]
  },
  mixins: [_components_directives__WEBPACK_IMPORTED_MODULE_13__["InputValidationDirective"], _storeMixin__WEBPACK_IMPORTED_MODULE_20__["default"]],
  props: {
    entity: null
  },
  data: function data() {
    return {
      isLoaded: false,
      regoInUse: false,
      months: {
        1: '01',
        2: '02',
        3: '03',
        4: '04',
        5: '05',
        6: '06',
        7: '07',
        8: '08',
        9: '09',
        10: '10',
        11: '11',
        12: '12'
      },
      connectedQuoteNos: [],
      isVehicleLookupModalActive: false
    };
  },
  computed: {
    transmissionTypes: function transmissionTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["TransmissionTypes"];
    },
    bodyStyles: function bodyStyles() {
      // return this.$store.getters['vehicleOptions/bodyShapes']
      return this.storeBodyShapes;
    },
    bodyStyles2: function bodyStyles2() {
      var _this = this;
      var bodyShape = this.bodyStyles.find(function (d) {
        return d.id === _this.entity.bodyId;
      });
      if (bodyShape) {
        return bodyShape.shapes;
      }
      return [];
    },
    colours: function colours() {
      var input = this.entity && this.entity.colour ? this.entity.colour.toLowerCase() : '';

      // return this.$store.getters['vehicleOptions/colours'].filter(d => d.toLowerCase().indexOf(input) > -1)
      return this.storeColours.filter(function (d) {
        return d.toLowerCase().indexOf(input) > -1;
      });
    },
    paintGroups: function paintGroups() {
      // return this.$store.getters['vehicleOptions/paintGroups']
      return this.storePaintGroups;
    },
    colour: function colour() {
      return this.entity.colour;
    },
    $v: function $v() {
      return this.$vv;
    },
    paintGroupTypes: function paintGroupTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["PaintGroupTypes"];
    },
    stateRegoTypes: function stateRegoTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_12__["StateRegoTypes"];
    }
  },
  mounted: function mounted() {
    this.getConnectedQuoteNos();
  },
  methods: {
    bodyChanged: function bodyChanged() {
      var bodyId2 = this.bodyStyles2.find(function (b) {
        return b.name.length > 0;
      });
      this.entity.bodyId2 = bodyId2.id;
      this.$refs.bodyId2.focus();
    },
    toggleActive: lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default()(function (toggle) {
      this.entity.isActive = toggle;
      if (this.entity.isActive) {
        this.checkRego();
      }
      this.$emit('toggleActive');
    }, 100),
    checkYear: function checkYear(e) {
      var year = e.target.value;
      if (year && year.length === 2) {
        var strYear = "01/01/".concat(year);
        var newDate = new Date(strYear);
        this.entity.buildYear = newDate.getFullYear().toString();
      } else if (year.length !== 4) {
        this.entity.buildYear = '';
      }
    },
    checkRego: lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(e) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              this.regoInUse = false;
              if (!this.entity.rego) {
                _context.n = 2;
                break;
              }
              _context.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_14__["default"].assertRegoUsed(this.entity.id, this.entity.rego);
            case 1:
              this.regoInUse = _context.v;
            case 2:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    getConnectedQuoteNos: function getConnectedQuoteNos() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_14__["default"].getConnectedQuoteNos(_this2.entity.id);
            case 1:
              _this2.connectedQuoteNos = _context2.v;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    closeVehicleLookupModal: function closeVehicleLookupModal() {
      this.isVehicleLookupModalActive = false;
    },
    translateBodyType: function translateBodyType(bodyType, entity) {
      if (bodyType.toLowerCase().includes('sedan')) {
        entity.bodyId = '4';
        entity.bodyId2 = '4S';
      } else if (bodyType.toLowerCase().includes('wagon')) {
        entity.bodyId = 'W';
        entity.bodyId2 = 'WG';
      }
    },
    select: function select(model, vehicle) {
      // console.log('select', model, vehicle)
      this.entity.model = model;
      this.entity.vin = vehicle.vin;
      this.entity.colour = vehicle.colour;
      this.entity.engineNo = vehicle.engine_number;
      this.entity.buildYear = vehicle.year_of_manufacture;
      this.entity.stateRego = vehicle.stateRego;
      this.translateBodyType(vehicle.factory ? vehicle.factory.body : vehicle.body_type, this.entity);
      if (vehicle.factory) {
        this.entity.cylinders = vehicle.factory.cylinders;
        this.entity.engineSize = vehicle.factory.litres;
        this.entity.buildYear = vehicle.factory.buildYear;
      }
    },
    selectPaintGroup: function selectPaintGroup(event) {
      if (event.target.value !== _enums__WEBPACK_IMPORTED_MODULE_12__["PaintGroupTypes"].M3) {
        this.entity.paintGroupPlus = false;
      }
      // console.log(event.target.value)
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleEngine',
  inject: ['$vv'],
  components: {
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_2__["TheMask"]
  },
  mixins: [_components_directives__WEBPACK_IMPORTED_MODULE_1__["InputValidationDirective"]],
  props: {
    entity: null
  },
  data: function data() {
    return {
      vinTokens: {
        '#': {
          pattern: /[0-9a-zA-Z]/
        }
      },
      vinMask: Array(18).join('#'),
      // length of vin field
      engineSizeTokens: {
        P: {
          pattern: /[0-9, .]/
        }
      },
      engineSizeMask: Array(5).join('P')
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var _VehicleService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./VehicleService */ "./src/views/vehicle/VehicleService.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/carmodel/UnscheduledModelModal */ "./src/components/carmodel/UnscheduledModelModal.vue");
/* harmony import */ var _components_carmodel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/carmodel */ "./src/components/carmodel/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");






// import _debounce from 'lodash.debounce'





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleModel',
  inject: ['$vv'],
  components: {
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_6__["BulmaAutocomplete"],
    CarModelSearchModal: _components_carmodel__WEBPACK_IMPORTED_MODULE_9__["CarModelSearchModal"]
  },
  mixins: [_components_directives__WEBPACK_IMPORTED_MODULE_7__["InputValidationDirective"], _storeMixin__WEBPACK_IMPORTED_MODULE_10__["default"]],
  props: {
    entity: null
  },
  data: function data() {
    return {
      models: [],
      modelText: '',
      searchingModel: false,
      showVehicleSearchModal: false,
      ntarLtarStatus: ''
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv;
    },
    modelId: function modelId() {
      if (this.entity && this.entity.model && this.entity.model.id) {
        return this.entity.model.id;
      }
      return '';
    }
  },
  watch: {
    'entity.model': {
      handler: function handler(newVal, oldVal) {
        this.modelText = this.entity.model.name;
        this.getNtarLtarStatus();
      },
      deep: true
    },
    'entity.bodyId': {
      handler: function () {
        var _handler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
            while (1) switch (_context.n) {
              case 0:
                this.getNtarLtarStatus();
              case 1:
                return _context.a(2);
            }
          }, _callee, this);
        }));
        function handler(_x, _x2) {
          return _handler.apply(this, arguments);
        }
        return handler;
      }()
    },
    'entity.bodyId2': {
      handler: function () {
        var _handler2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
            while (1) switch (_context2.n) {
              case 0:
                this.getNtarLtarStatus();
              case 1:
                return _context2.a(2);
            }
          }, _callee2, this);
        }));
        function handler(_x3, _x4) {
          return _handler2.apply(this, arguments);
        }
        return handler;
      }()
    }
  },
  created: function created() {
    this.getNtarLtarStatus();
  },
  mounted: function mounted() {
    if (this.entity && this.entity.model && this.entity.model.name) {
      this.modelText = this.entity.model.name;
    }
  },
  methods: {
    searchModel: function searchModel(val) {
      var _this = this;
      console.log('search ', val);
      this.modelText = val;
      this.models = [];
      if (val === '') {
        return;
      }
      if (this.entity && this.entity.model && this.entity.model.name) {
        if (val === this.entity.model.name) {
          return;
        }
      }
      this.searchingModel = true;
      _VehicleService__WEBPACK_IMPORTED_MODULE_5__["default"].searchModelByName(val).then(function (res) {
        _this.models = res.data.list;
        _this.searchingModel = false;
      });
    },
    // searchModel: _debounce(function(val) {
    //   console.log('search ' + val)
    //   this.modelText = val
    //   this.models = []
    //
    //   if (val === '') {
    //     return
    //   }
    //
    //   if (this.entity && this.entity.model && this.entity.model.nameWithCylinders) {
    //     if (val === this.entity.model.nameWithCylinders) {
    //       return
    //     }
    //   }
    //
    //   this.searchingModel = true
    //   VehicleService.searchModelByName(val).then(res => {
    //     this.models = res.data.list
    //     this.searchingModel = false
    //   })
    // }, 500),
    checkMultipleModelCustomExists: function checkMultipleModelCustomExists() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var exists;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_5__["default"].checkMultipleModelCustomExists(_this2.entity.id, _this2.entity.model.id);
            case 1:
              exists = _context3.v;
              if (exists) {
                console.log('exists copymodel');
                _this2.copyModel();
              } else {
                console.log('not exists editmodel');
                _this2.editModel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    changeModel: function changeModel(val) {
      console.log("".concat(val, " - ").concat(this.modelText));
      if (val) {
        this.entity.model = val;
      } else if (!val && this.modelText === '') {
        this.entity.model = null;
      }
    },
    addModel: function addModel() {
      var _this3 = this;
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_4__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_8__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          name: this.modelText,
          bodyStyles: this.storeBodyShapes // this.$store.getters['vehicleOptions/bodyShapes']
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this3.modelText = res.name;
        _this3.entity.model = res;
        _this3.entity.model.isNew = false;
      });
    },
    copyModel: function copyModel() {
      var _this4 = this;
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_4__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_8__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          bodyStyles: this.storeBodyShapes,
          // this.$store.getters['vehicleOptions/bodyShapes'],
          copyModelId: this.entity.model.id
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this4.modelText = res.name;
        _this4.entity.model = res;
        _this4.entity.model.isNew = false; // ??
      });
    },
    editModel: function editModel() {
      var _this5 = this;
      if (!this.entity.model.isUnscheduled) {
        return;
      }
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_4__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_8__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          bodyStyles: this.storeBodyShapes,
          // this.$store.getters['vehicleOptions/bodyShapes'],
          modelId: this.entity.model.id
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this5.modelText = res.name;
        _this5.entity.model = res;
      });
    },
    searchModelPopup: function searchModelPopup() {
      this.showVehicleSearchModal = true;
      // const SearchComponent = Vue.extend(CarModelSearchModal)
      // const props = {
      //   el: document.createElement('div'),
      //   propsData: {
      //     visible: true
      //   }
      // }
      // new SearchComponent(props).$on('ok', res => {
      //   this.modelText = res.name
      //   this.entity.model = res
      // })
    },
    selectModel: function selectModel(model) {
      if (model) {
        this.modelText = model.name;
        this.entity.model = model;
      }
      this.showVehicleSearchModal = false;
    },
    getNtarLtarStatus: function getNtarLtarStatus() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (!_this6.entity.model) {
                _context4.n = 2;
                break;
              }
              _context4.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_5__["default"].getNtarLtarStatusByScheduleBody(_this6.entity.model.scheduleId, _this6.entity.bodyId);
            case 1:
              _this6.ntarLtarStatus = _context4.v;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_2__["default"]],
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.addStoreItem(_this.$route.query);
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _VehicleService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./VehicleService */ "./src/views/vehicle/VehicleService.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _VehicleFormValidation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./VehicleFormValidation */ "./src/views/vehicle/VehicleFormValidation.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./route-types */ "./src/views/vehicle/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _views_customer_route_types__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/views/customer/route-types */ "./src/views/customer/route-types.js");
/* harmony import */ var _views_customer_route_types__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_views_customer_route_types__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_8__["default"],
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_9__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__["SaveConflictModal"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__["ConfirmModal"]
  },
  mixins: [_VehicleFormValidation__WEBPACK_IMPORTED_MODULE_10__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_17__["default"]],
  props: {
    isNew: Boolean
  },
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      isToggleModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null
    };
  },
  computed: {
    validateError: function validateError() {
      this.$v.$touch();
      return this.$v.$error;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_11___default.a;
    },
    customerRoutes: function customerRoutes() {
      return _views_customer_route_types__WEBPACK_IMPORTED_MODULE_13___default.a;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.entity));
        }
      }, 500),
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _t = action;
              _context2.n = _t === _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].AddNew ? 1 : _t === _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Print ? 2 : _t === _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Delete ? 3 : _t === _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Save ? 4 : _t === _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Cancel ? 5 : 6;
              break;
            case 1:
              return _context2.a(3, 6);
            case 2:
              _this2.print();
              return _context2.a(3, 6);
            case 3:
              _this2.checkBeforeDelete();
              return _context2.a(3, 6);
            case 4:
              _this2.save();
              return _context2.a(3, 6);
            case 5:
              _this2.cancel();
              return _context2.a(3, 6);
            case 6:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var reset, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context3.p = 1;
              _this3.$showSpinner();
              if (reset) {
                _this3.clearSnapshots(_this3.$route.params.vehicleId);
              }
              if (_this3.currentSnapshot) {
                _context3.n = 2;
                break;
              }
              _context3.n = 2;
              return _this3.getStoreItem(_this3.$route.params.vehicleId);
            case 2:
              _this3.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(_this3.currentSnapshot);
              _context3.n = 4;
              break;
            case 3:
              _context3.p = 3;
              _t2 = _context3.v;
              _this3.$notification.openMessageXhrError('', _t2);
            case 4:
              _this3.$hideSpinner();
            case 5:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var title, response, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              title = 'Vehicle';
              if (!_this4.validateError) {
                _context4.n = 1;
                break;
              }
              _this4.$notification.validationError(title);
              return _context4.a(2, false);
            case 1:
              _context4.p = 1;
              _this4.$showSpinner('Saving...');
              _this4.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(_this4.entity));
              if (!_this4.entity.isNew) {
                _context4.n = 3;
                break;
              }
              _context4.n = 2;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_7__["default"].postEntity(_this4.entity);
            case 2:
              response = _context4.v;
              _context4.n = 6;
              break;
            case 3:
              if (!_this4.snapshotDiff) {
                _context4.n = 5;
                break;
              }
              _context4.n = 4;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_7__["default"].putEntity(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(_this4.entity), _this4.snapshotDiff);
            case 4:
              response = _context4.v;
              _context4.n = 6;
              break;
            case 5:
              _this4.$notification.openNotificationWithType('warning', 'Save', 'No changes. Not saved');
            case 6:
              _this4.$hideSpinner();
              if (!_this4.isSaveContinue) {
                _context4.n = 7;
                break;
              }
              _this4.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " set to In-Active") : 'Save successful');
              _context4.n = 11;
              break;
            case 7:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_15__["default"].NO_CONTENT)) {
                _context4.n = 9;
                break;
              }
              _context4.n = 8;
              return _this4.getEntity(true);
            case 8:
              _this4.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " set to In-Active") : 'Save successful');
              _context4.n = 11;
              break;
            case 9:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_15__["default"].CREATED)) {
                _context4.n = 11;
                break;
              }
              _context4.n = 10;
              return _this4.getEntity(true);
            case 10:
              _this4.$notification.openNotificationWithType('success', title, "New  ".concat(title, "  added"));
            case 11:
              return _context4.a(2, true);
            case 12:
              _context4.p = 12;
              _t3 = _context4.v;
              _this4.$hideSpinner();
              if (_t3.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_15__["default"].CONFLICT) {
                _this4.isSaveConflictModalActive = true;
              } else {
                _this4.$notification.openMessageXhrError(title, _t3);
              }
              return _context4.a(2, false);
          }
        }, _callee4, null, [[1, 12]]);
      }))();
    },
    deleteEntity: function deleteEntity(confirmDelete, save) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.isConfirmModalActive = false;
              _this5.isToggleModalActive = false;
              if (confirmDelete) {
                _this5.entity.isActive = false;
                // save snapshots immediately not waiting for debounce
                if (save) {
                  _this5.save(true);
                }
              } else {
                _this5.entity.isActive = true;
              }
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.entity));
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        console.log(this.snapshotDiff);
        this.isUnsavedModalActive = true;
      } else {
        if (this.$route.query.returnUrl) {
          var url = "".concat(this.$route.query.returnUrl, "?true&params=").concat(this.$route.query.params, "&vid=").concat(this.$route.params.vehicleId);
          window.location.href = url;
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_20___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_11___default.a.VehicleListView.name
          });
        }
      }
    },
    saveContinue: function saveContinue() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isUnsavedModalActive = false;
              _this6.isSaveContinue = true;
              _context6.n = 1;
              return _this6.save();
            case 1:
              _this6.isSaveContinue = _context6.v;
              if (_this6.isSaveContinue) {
                _this6.cancel();
              }
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    print: function print() {
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        VehicleID: this.entity.id
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_22__["Emailer"]();
      emailer.assetId = this.entity.id;
      emailer.subject = 'Vehicle Table Detail';
      emailer.reportName = 'rptTableVehicleDetails';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
    },
    reloadData: function reloadData() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this7.isSaveConflictModalActive = false;
              _this7.isSaveContinue = false;
              _this7.getEntity(true);
              // this.$eventHub.$emit(EventHubTypes.EntityReload)
            case 1:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    checkBeforeDelete: function checkBeforeDelete() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        var isInUse;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this8.$showSpinner();
              _context8.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_7__["default"].assertUsed(_this8.entity.id);
            case 1:
              isInUse = _context8.v;
              _this8.$hideSpinner();
              if (isInUse) {
                _this8.isConfirmModalActive = true;
              } else {
                _this8.deleteEntity(true, true);
              }
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    onToggleActive: function onToggleActive() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        var isInUse;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              if (!_this9.entity.isActive) {
                _context9.n = 1;
                break;
              }
              _context9.n = 3;
              break;
            case 1:
              _this9.$showSpinner();
              _context9.n = 2;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_7__["default"].assertUsed(_this9.entity.id);
            case 2:
              isInUse = _context9.v;
              _this9.$hideSpinner();
              if (isInUse) {
                _this9.isToggleModalActive = true;
              } else {
                _this9.deleteEntity(true, false);
              }
            case 3:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.entity));
    var isEditCustomer = to.name === this.customerRoutes.CustomerDetail.name;
    if (isEditCustomer) {
      next();
    } else if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
      console.log(this.snapshotDiff);
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entity.id);
      if (to.name === _views_quote_route_types__WEBPACK_IMPORTED_MODULE_12__["default"].QuoteDetail.name) {
        this.setQuoteVehicleCustomer({
          vehicleId: !this.entity.isNew ? this.entity.id : this.$guid.empty(),
          customerId: this.entity.customer && !this.entity.isNew ? this.entity.customer.key : this.$guid.empty()
        });
      }
      this.setReturnRoute({});
      next();
    }
  }
  // Cant destroy the session in case it's going to customer page
  // beforeDestroy() {
  //   sessionStorage.removeItem(this.entity.id)
  // }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Company / Name")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_vm.customers ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.customer.$error
    },
    attrs: {
      value: _vm.value,
      "deselect-label": "Can't remove this value",
      "track-by": "key",
      label: "value",
      placeholder: "Select a customer",
      options: _vm.customers,
      loading: _vm.isCustomerLoading,
      "internal-search": false,
      "options-limit": _vm.assetFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      input: _vm.changeCustomer,
      "search-change": _vm.searchCustomer
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", [_vm._v(_vm._s(props.option.value))])];
      }
    }], null, false, 2400269036)
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Customer not found.")])]) : _vm._e(), !_vm.$v.entity.customer.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Company / name is required")]) : _vm._e()], 1), _c("p", {
    staticClass: "control"
  }, [!_vm.customerExists ? _c("a", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Add customer"
    },
    on: {
      click: _vm.addCustomer
    }
  }, [_vm._m(0)]) : _vm._e(), _vm.customerExists ? _c("a", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Edit customer"
    },
    on: {
      click: _vm.editCustomer
    }
  }, [_vm._m(1)]) : _vm._e()])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);









var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(0), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.connectedQuoteNos.length > 0,
      expression: "connectedQuoteNos.length > 0"
    }],
    staticClass: "tags has-addons"
  }, [_c("span", {
    staticClass: "tag is-dark"
  }, [_vm._v("Quote Nos")]), _c("span", {
    staticClass: "tag is-info"
  }, [_vm._v(_vm._s(_vm.connectedQuoteNos.join(",")))])])])]), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Rego")]), _c("div", {
    staticClass: "field is-narrow has-validation has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.rego,
      expression: "entity.rego"
    }, {
      name: "fq-validate",
      rawName: "v-fq-validate",
      value: _vm.$v.entity.rego,
      expression: "$v.entity.rego"
    }],
    ref: "rego",
    staticClass: "input is-uppercase rego",
    attrs: {
      type: "text",
      placeholder: "Rego"
    },
    domProps: {
      value: _vm.entity.rego
    },
    on: {
      keyup: _vm.checkRego,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "rego", $event.target.value);
      }
    }
  }), !_vm.$v.entity.rego.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Rego is required")]) : _vm._e(), _vm.regoInUse ? _c("span", {
    staticClass: "help is-warning"
  }, [_vm._v("Rego already exists")]) : _vm._e()]), _vm.$company.info.countryCode === "AU" ? _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Rego lookup service"
    },
    on: {
      click: function click($event) {
        _vm.isVehicleLookupModalActive = true;
      }
    }
  }, [_vm._m(1)])]) : _vm._e()])])]), _vm.$company.info.countryCode === "AU" ? _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("State")]), _c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-narrow"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.stateRego,
      expression: "entity.stateRego"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "stateRego", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.stateRegoTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: b
      }
    }, [_vm._v(_vm._s(a))]);
  })], 2)])])])]) : _vm._e()]), _c("vehicle-customer", {
    model: {
      value: _vm.entity.customer,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "customer", $$v);
      },
      expression: "entity.customer"
    }
  }), _c("vehicle-model", {
    attrs: {
      entity: _vm.entity
    }
  }), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Body Style")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select",
    class: {
      "is-danger": _vm.$v.entity.bodyId.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.bodyId,
      expression: "entity.bodyId"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "bodyId", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, _vm.bodyChanged]
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.bodyStyles, function (s, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: s.id
      }
    }, [_vm._v(" " + _vm._s(s.name) + " ")]);
  })], 2)]), !_vm.$v.entity.bodyId.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Required")]) : _vm._e()]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select",
    class: {
      "is-danger": _vm.$v.entity.bodyId2.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.bodyId2,
      expression: "entity.bodyId2"
    }],
    ref: "bodyId2",
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "bodyId2", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.bodyStyles2, function (s, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: s.id
      }
    }, [_vm._v(" " + _vm._s(s.name) + " ")]);
  })], 2)]), !_vm.$v.entity.bodyId2.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Required")]) : _vm._e()])]), _c("label", {
    staticClass: "label"
  }, [_vm._v("Built")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.buildMonth,
      expression: "entity.buildMonth"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "buildMonth", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("MM")]), _vm._l(_vm.months, function (value, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: key
      }
    }, [_vm._v(_vm._s(value))]);
  })], 2)])]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "Year",
      mask: ["####"]
    },
    nativeOn: {
      blur: function blur($event) {
        return _vm.checkYear.apply(null, arguments);
      }
    },
    model: {
      value: _vm.entity.buildYear,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "buildYear", $$v);
      },
      expression: "entity.buildYear"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Transmission")]), _c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.transmissionType,
      expression: "entity.transmissionType"
    }],
    staticClass: "control-min-width",
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "transmissionType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.transmissionTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: b
      }
    }, [_vm._v(_vm._s(a))]);
  })], 2)])])])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Paint Group")]), _c("div", {
    staticClass: "is-flex"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select",
    class: {
      "is-danger": _vm.$v.entity.paintGroup.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.paintGroup,
      expression: "entity.paintGroup"
    }],
    ref: "paintGroup",
    staticClass: "control-min-width",
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.entity, "paintGroup", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.selectPaintGroup($event);
      }]
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.paintGroups, function (p, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: p.key
      }
    }, [_vm._v(" " + _vm._s(p.value) + " ")]);
  })], 2)]), !_vm.$v.entity.paintGroup.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Paint group is required")]) : _vm._e()]), _vm.entity.paintGroup === _vm.paintGroupTypes.M3 ? _c("div", {
    staticClass: "control is-flex is-align-items-center pl-4"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.paintGroupPlus,
      expression: "entity.paintGroupPlus"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.entity.paintGroupPlus) ? _vm._i(_vm.entity.paintGroupPlus, null) > -1 : _vm.entity.paintGroupPlus
    },
    on: {
      change: function change($event) {
        var $$a = _vm.entity.paintGroupPlus,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.entity, "paintGroupPlus", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.entity, "paintGroupPlus", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.entity, "paintGroupPlus", $$c);
        }
      }
    }
  }), _vm._m(2)])]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Colour")]), _c("p", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    staticClass: "is-capitalized control-min-width",
    attrs: {
      data: _vm.colours,
      "keep-first": true,
      expanded: true
    },
    model: {
      value: _vm.entity.colour,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "colour", $$v);
      },
      expression: "entity.colour"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Odometer")]), _c("div", {
    staticClass: "control is-narrow"
  }, [_c("vue-numeric", {
    staticClass: "input control-min-width",
    attrs: {
      maxlength: "10",
      min: 0,
      max: 9999999999,
      "empty-value": null,
      separator: "",
      placeholder: "Odometer",
      precision: 0
    },
    model: {
      value: _vm.entity.odometer,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "odometer", $$v);
      },
      expression: "entity.odometer"
    }
  })], 1)])])])])]), _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": _vm.entity.isActive
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(3), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": !_vm.entity.isActive
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(4), _c("span", [_vm._v("In-Active")])])]) : _vm._e()], 1)]), _c("div", {
    staticClass: "tile is-vertical is-3"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("vehicle-engine", {
    staticClass: "tile is-child box",
    attrs: {
      entity: _vm.entity
    }
  })], 1), _c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Codes")]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "trimcode"
    }
  }, [_vm._v("Trim Code")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.trimCode,
      expression: "entity.trimCode"
    }],
    staticClass: "input",
    attrs: {
      id: "trimcode",
      type: "text",
      placeholder: "S"
    },
    domProps: {
      value: _vm.entity.trimCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "trimCode", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "optioncode"
    }
  }, [_vm._v("Option Code")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.optionCode,
      expression: "entity.optionCode"
    }],
    staticClass: "input",
    attrs: {
      id: "optioncode",
      type: "text",
      placeholder: "O"
    },
    domProps: {
      value: _vm.entity.optionCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "optionCode", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label",
    attrs: {
      for: "toyotamodelno"
    }
  }, [_vm._v("Toyota Model No")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.toyotaModelNo,
      expression: "entity.toyotaModelNo"
    }],
    staticClass: "input",
    attrs: {
      id: "toyotamodelno",
      type: "text",
      placeholder: "e.g. ABC123"
    },
    domProps: {
      value: _vm.entity.toyotaModelNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "toyotaModelNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Paint Code")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.paintCode,
      expression: "entity.paintCode"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "#"
    },
    domProps: {
      value: _vm.entity.paintCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "paintCode", $event.target.value);
      }
    }
  })])])])])]), _vm.isVehicleLookupModalActive ? _c("vehicle-lookup-modal", {
    attrs: {
      active: _vm.isVehicleLookupModalActive,
      "state-rego": _vm.entity.stateRego
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isVehicleLookupModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeVehicleLookupModal();
      },
      select: _vm.select
    },
    model: {
      value: _vm.entity.rego,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "rego", $$v);
      },
      expression: "entity.rego"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Make/Model Lookup")])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Details")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", [_vm._v("M3+")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", [_c("p", {
    staticClass: "title"
  }, [_vm._v("Engine")]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("VIN")]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    directives: [{
      name: "fq-validate",
      rawName: "v-fq-validate",
      value: _vm.$v.entity.vin,
      expression: "$v.entity.vin"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      name: "vin",
      mask: _vm.vinMask,
      tokens: _vm.vinTokens
    },
    model: {
      value: _vm.entity.vin,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "vin", $$v);
      },
      expression: "entity.vin"
    }
  })], 1), !_vm.$v.entity.vin.customMinLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Vin should have at least 7 characters")]) : _vm._e(), !_vm.$v.entity.vin.maxLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Vin max 17 characters")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Engine no")]), _c("p", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.entity.engineNo,
      expression: "entity.engineNo"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "ABCD1234"
    },
    domProps: {
      value: _vm.entity.engineNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.entity, "engineNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("No. of cylinders")]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 6",
      mask: ["###"]
    },
    model: {
      value: _vm.entity.cylinders,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "cylinders", $$v);
      },
      expression: "entity.cylinders"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Engine size")]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 1300",
      mask: _vm.engineSizeMask,
      tokens: _vm.engineSizeTokens
    },
    model: {
      value: _vm.entity.engineSize,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "engineSize", $$v);
      },
      expression: "entity.engineSize"
    }
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Model")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary",
    on: {
      click: _vm.searchModelPopup
    }
  }, [_vm._m(0)])]), _c("p", {
    staticClass: "control is-expanded"
  }, [_c("bulma-autocomplete", {
    attrs: {
      value: _vm.modelText,
      data: _vm.models,
      field: "name",
      "keep-first": true,
      loading: _vm.searchingModel,
      expanded: true,
      type: _vm.$v.entity.model.required ? "" : "is-danger"
    },
    on: {
      input: _vm.searchModel,
      select: _vm.changeModel
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_c("div", {
          staticClass: "tags is-pulled-right"
        }, [_c("span", {
          staticClass: "tag is-info"
        }, [_vm._v(" " + _vm._s(props.option.cylinders) + " Cylinders ")]), _c("span", {
          staticClass: "tag is-info"
        }, [_vm._v(" " + _vm._s(props.option.production) + " ")])])]), _c("span", [_vm._v(_vm._s(props.option.name))])];
      }
    }])
  }), !_vm.$v.entity.model.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Model is required")]) : _vm._e()], 1), _c("p", {
    staticClass: "control"
  }, [_vm.modelId === "" ? _c("a", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Add unscheduled model"
    },
    on: {
      click: _vm.addModel
    }
  }, [_vm._m(1)]) : _vm._e(), _vm.modelId !== "" && _vm.entity.model.isUnscheduled ? _c("a", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Edit unscheduled model"
    },
    on: {
      click: _vm.checkMultipleModelCustomExists
    }
  }, [_vm._m(2)]) : _vm._e(), _vm.modelId !== "" && !_vm.entity.model.isUnscheduled ? _c("a", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Create unscheduled model"
    },
    on: {
      click: _vm.copyModel
    }
  }, [_vm._m(3)]) : _vm._e()])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_vm.entity && _vm.entity.model ? _c("div", {
    staticClass: "field"
  }, [_c("p", {
    staticClass: "tags"
  }, [_vm.entity.model.cylinders ? _c("span", {
    staticClass: "tag is-info"
  }, [_vm._v(_vm._s(_vm.entity.model.cylinders) + " Cylinders")]) : _vm._e(), _c("span", {
    staticClass: "tag is-info"
  }, [_vm._v(_vm._s(_vm.entity.model.production))]), _vm.entity.model.isUnscheduled ? _c("span", {
    staticClass: "tag is-info"
  }, [_vm._v("Unscheduled")]) : _vm._e()])]) : _vm._e()]), _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end"
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.ntarLtarStatus,
      expression: "ntarLtarStatus"
    }],
    staticClass: "field"
  }, [_c("span", {
    staticClass: "tag is-success animate__animated animate__pulse animate__repeat-3 tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "".concat(_vm.ntarLtarStatus, " schedule and times found")
    }
  }, [_vm._v(_vm._s(_vm.ntarLtarStatus) + " Hours On - " + _vm._s(_vm.entity && _vm.entity.model ? _vm.entity.model.scheduleId : ""))])])])]), _c("car-model-search-modal", {
    attrs: {
      visible: _vm.showVehicleSearchModal
    },
    on: {
      ok: _vm.selectModel,
      cancel: function cancel($event) {
        _vm.showVehicleSearchModal = false;
      }
    }
  })], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm._m(0);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "level",
    staticStyle: {
      height: "80vh"
    }
  }, [_c("div", {
    staticClass: "level-item"
  }, [_c("i", {
    staticClass: "mdi mdi-spin mdi-loading",
    attrs: {
      "aria-hidden": "true"
    }
  }), _c("span", [_vm._v("  Preparing new vehicle... ")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.entity ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-delete": _vm.entity.isActive && !_vm.entity.isNew,
      "show-print": !_vm.entity.isNew
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_c("strong", [_vm._v(_vm._s(_vm.entity.rego ? _vm.entity.rego : "Rego"))])])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.VehicleDetail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active"
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.$invalid
    },
    attrs: {
      "data-badge": _vm.$v.$invalid ? "" : null
    }
  }, [_vm._v(" Detail Info ")])])], 1)])])])], 1), _c("div", {
    staticClass: "column"
  }, [_c("router-view", {
    attrs: {
      entity: _vm.entity
    },
    on: {
      toggleActive: _vm.onToggleActive
    }
  })], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true, true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Vehicle is in use")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.entity.rego))]), _vm._v(" is in use. Set to "), _c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v("In-Active")]), _vm._v(" anyway? ")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isToggleModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isToggleModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true, false);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Vehicle is in use")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.entity.rego))]), _vm._v(" is in use. Set to "), _c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v("In-Active")]), _vm._v(" anyway? ")])])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n/*Prevent label line wrapping in vehicle detail page*/\n\n/*Original flex-grow is 5*/\n.field-body {\n  -webkit-box-flex: 3;\n      -ms-flex-positive: 3;\n          flex-grow: 3;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-7dbcb630] {\n  margin: 1.2em 0;\n}\n.control-min-width[data-v-7dbcb630] {\n  min-width: 18em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/_baseTrim.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_baseTrim.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var trimmedEndIndex = __webpack_require__(/*! ./_trimmedEndIndex */ "./node_modules/lodash/_trimmedEndIndex.js");

/** Used to match leading whitespace. */
var reTrimStart = /^\s+/;

/**
 * The base implementation of `_.trim`.
 *
 * @private
 * @param {string} string The string to trim.
 * @returns {string} Returns the trimmed string.
 */
function baseTrim(string) {
  return string
    ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, '')
    : string;
}

module.exports = baseTrim;


/***/ }),

/***/ "./node_modules/lodash/_trimmedEndIndex.js":
/*!*************************************************!*\
  !*** ./node_modules/lodash/_trimmedEndIndex.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to match a single whitespace character. */
var reWhitespace = /\s/;

/**
 * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
 * character of `string`.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {number} Returns the index of the last non-whitespace character.
 */
function trimmedEndIndex(string) {
  var index = string.length;

  while (index-- && reWhitespace.test(string.charAt(index))) {}
  return index;
}

module.exports = trimmedEndIndex;


/***/ }),

/***/ "./node_modules/lodash/debounce.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/debounce.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    now = __webpack_require__(/*! ./now */ "./node_modules/lodash/now.js"),
    toNumber = __webpack_require__(/*! ./toNumber */ "./node_modules/lodash/toNumber.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        timeWaiting = wait - timeSinceLastCall;

    return maxing
      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
      : timeWaiting;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

module.exports = debounce;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/lodash/now.js":
/*!************************************!*\
  !*** ./node_modules/lodash/now.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

module.exports = now;


/***/ }),

/***/ "./node_modules/lodash/toNumber.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/toNumber.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseTrim = __webpack_require__(/*! ./_baseTrim */ "./node_modules/lodash/_baseTrim.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = toNumber;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("55da24dd", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("15c48bee", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/vehicle/VehicleCustomer.vue":
/*!***********************************************!*\
  !*** ./src/views/vehicle/VehicleCustomer.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleCustomer.vue?vue&type=template&id=567bb97d */ "./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d");
/* harmony import */ var _VehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleCustomer.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleCustomer.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleCustomer.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d":
/*!*****************************************************************************!*\
  !*** ./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleCustomer.vue?vue&type=template&id=567bb97d */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleCustomer.vue?vue&type=template&id=567bb97d");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleCustomer_vue_vue_type_template_id_567bb97d__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleDetail.vue":
/*!*********************************************!*\
  !*** ./src/views/vehicle/VehicleDetail.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true */ "./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true");
/* harmony import */ var _VehicleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleDetail.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true */ "./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7dbcb630",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js":
/*!*********************************************************************!*\
  !*** ./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true":
/*!******************************************************************************************************!*\
  !*** ./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=style&index=0&id=7dbcb630&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_style_index_0_id_7dbcb630_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true":
/*!***************************************************************************************!*\
  !*** ./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleDetail.vue?vue&type=template&id=7dbcb630&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleDetail_vue_vue_type_template_id_7dbcb630_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleEngine.vue":
/*!*********************************************!*\
  !*** ./src/views/vehicle/VehicleEngine.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleEngine.vue?vue&type=template&id=115637a1 */ "./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1");
/* harmony import */ var _VehicleEngine_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleEngine.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleEngine_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleEngine.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js":
/*!*********************************************************************!*\
  !*** ./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleEngine_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleEngine.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleEngine.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleEngine_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1":
/*!***************************************************************************!*\
  !*** ./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1 ***!
  \***************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleEngine.vue?vue&type=template&id=115637a1 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleEngine.vue?vue&type=template&id=115637a1");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleEngine_vue_vue_type_template_id_115637a1__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleFormValidation.js":
/*!****************************************************!*\
  !*** ./src/views/vehicle/VehicleFormValidation.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

var customMinLength = function customMinLength(value, vehicle) {
  if (vehicle && vehicle.bodyId && vehicle.bodyId.toUpperCase() === 'O') {
    return true;
  } else if (value !== null || value != undefined) {
    return value.length >= 7 || value.length === 0;
  }
  return true;
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    entity: {
      rego: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      customer: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      model: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      bodyId: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      bodyId2: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      paintGroup: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      vin: {
        customMinLength: customMinLength,
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(17)
      }
    }
  }
});

/***/ }),

/***/ "./src/views/vehicle/VehicleModel.vue":
/*!********************************************!*\
  !*** ./src/views/vehicle/VehicleModel.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleModel.vue?vue&type=template&id=701b3ecc */ "./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc");
/* harmony import */ var _VehicleModel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleModel.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleModel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleModel.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js":
/*!********************************************************************!*\
  !*** ./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleModel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleModel.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleModel.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleModel_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc":
/*!**************************************************************************!*\
  !*** ./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleModel.vue?vue&type=template&id=701b3ecc */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleModel.vue?vue&type=template&id=701b3ecc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleModel_vue_vue_type_template_id_701b3ecc__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleNew.vue":
/*!******************************************!*\
  !*** ./src/views/vehicle/VehicleNew.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleNew.vue?vue&type=template&id=f748045e */ "./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e");
/* harmony import */ var _VehicleNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleNew.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleNew.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleNew.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e":
/*!************************************************************************!*\
  !*** ./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e ***!
  \************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleNew.vue?vue&type=template&id=f748045e */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleNew.vue?vue&type=template&id=f748045e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleNew_vue_vue_type_template_id_f748045e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleView.vue":
/*!*******************************************!*\
  !*** ./src/views/vehicle/VehicleView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleView.vue?vue&type=template&id=021a5778 */ "./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778");
/* harmony import */ var _VehicleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleView.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css */ "./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VehicleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css":
/*!***************************************************************************************!*\
  !*** ./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=style&index=0&id=021a5778&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_style_index_0_id_021a5778_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778":
/*!*************************************************************************!*\
  !*** ./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778 ***!
  \*************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleView.vue?vue&type=template&id=021a5778 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleView.vue?vue&type=template&id=021a5778");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleView_vue_vue_type_template_id_021a5778__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/storeMixin.js":
/*!*****************************************!*\
  !*** ./src/views/vehicle/storeMixin.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'vehicles';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])('vehicleOptions', {
    storeBodyShapes: 'bodyShapes',
    storeColours: 'colours',
    storePaintGroups: 'paintGroups'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('vehicleOptions', ['refreshColour'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('customers', {
    setCustomerReturnRoute: 'setReturnRoute',
    editStoreCustomer: 'editStoreItem',
    addStoreCustomer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quotes', {
    setQuoteVehicleCustomer: 'setVehicleCustomer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=vehicle-chunk.js.map