(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[16],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_25__);


























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyIntegrationSetting',
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_21__["default"]],
  props: {
    defaultActiveTabIndex: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      activeTabIndex: 0,
      autoUpdate: null,
      companyExternalSettings: null,
      lastModified: null,
      passwordEnabled: false,
      showPassword: false,
      timeOutId: null,
      isNew: false
    };
  },
  columns: {
    left: [{
      label: 'tagLabel',
      value: 'tag'
    }, {
      label: 'usernameLabel',
      value: 'username'
    }, {
      label: 'passwordLabel',
      value: 'password'
    }, {
      label: 'servernameLabel',
      value: 'serverName'
    }, {
      label: 'portLabel',
      value: 'port'
    }
    // { label: 'tokenLabel', value: 'token' }
    ],
    right: [{
      label: 'property1Label',
      value: 'property1'
    }, {
      label: 'property2Label',
      value: 'property2'
    }, {
      label: 'property3Label',
      value: 'property3'
    }, {
      label: 'property4Label',
      value: 'property4'
    }, {
      label: 'property5Label',
      value: 'property5'
    }]
  },
  computed: {
    activeCompanyExternalSetting: function activeCompanyExternalSetting() {
      if (this.companyExternalSettings && this.companyExternalSettings[this.activeTabIndex]) {
        return this.companyExternalSettings[this.activeTabIndex];
      }
      return null;
    },
    externalSettingTypes: function externalSettingTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_23__["ExternalSettingTypes"];
    },
    isEstimageSettingPage: function isEstimageSettingPage() {
      console.log('active setting: ', this.activeCompanyExternalSetting);
      return this.activeCompanyExternalSetting && this.activeCompanyExternalSetting.settingName === this.externalSettingTypes.SETTING_ESTIMAGE;
    },
    isPartsCheckSettingPage: function isPartsCheckSettingPage() {
      return this.activeCompanyExternalSetting && this.activeCompanyExternalSetting.settingName === this.externalSettingTypes.SETTING_PARTSCHECK;
    },
    // PartsCheck: Property5 = Auto Sync (2 = On), Property3 = Smart Receipted Documents (1 = On).
    // Smart receipting runs inside the auto-sync chain, so it depends on Auto Sync being on.
    partsCheckExternalSetting: function partsCheckExternalSetting() {
      var _this = this;
      return (this.companyExternalSettings || []).find(function (s) {
        return s.settingName === _this.externalSettingTypes.SETTING_PARTSCHECK;
      }) || null;
    },
    partsCheckAutoSync: function partsCheckAutoSync() {
      return this.partsCheckExternalSetting ? this.partsCheckExternalSetting.property5 : undefined;
    },
    isPartsCheckAutoSyncOn: function isPartsCheckAutoSyncOn() {
      return (this.partsCheckAutoSync || '').trim() === '2';
    },
    isEstimageEnabledLabel: function isEstimageEnabledLabel() {
      return this.activeCompanyExternalSetting && this.activeCompanyExternalSetting[column.label] === this.externalSettingTypes.SETTING_ESTIMAGE;
    }
  },
  watch: {
    companyExternalSettings: {
      handler: function handler(val) {
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(val)
        });
        if (typeof this.autoUpdate === 'function') this.autoUpdate(val);
      },
      deep: true
    },
    isEstimageSettingPage: function isEstimageSettingPage(val) {
      if (this.lastModified !== null) {
        if (val) {
          console.log('watch is estimage true');
          this.fetchEstimageSetting();
        } else {
          console.log('watch is estimage false');
          this.stopFetchEstimageSetting();
        }
      }
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee() {
      var newCompany, _t, _t2, _t3, _t4;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this2.activeTabIndex = _this2.defaultActiveTabIndex;
            _this2.$showSpinner();
            if (!(_this2.$route.params.companyId === 'new')) {
              _context.n = 4;
              break;
            }
            _this2.isNew = true;
            newCompany = _this2.$store.getters['companysetting/newCompany'];
            if (!(newCompany && newCompany.companyExternalSettings)) {
              _context.n = 1;
              break;
            }
            _this2.companyExternalSettings = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(newCompany.companyExternalSettings);
            _context.n = 3;
            break;
          case 1:
            _t = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
            _context.n = 2;
            return _this2.getStoreItem({
              serviceFunction: 'getNewCompanyExternalSettings'
            });
          case 2:
            _t2 = _context.v;
            _this2.companyExternalSettings = _t(_t2);
          case 3:
            _context.n = 6;
            break;
          case 4:
            _t3 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
            _context.n = 5;
            return _this2.getStoreItem({
              serviceFunction: 'getCompanyExternalSettings',
              params: _this2.$route.params.companyId
            });
          case 5:
            _t4 = _context.v;
            _this2.companyExternalSettings = _t3(_t4);
          case 6:
            if (_this2.isNew) _this2.setStateProperty({
              key: 'companyExternalSettings',
              value: _this2.companyExternalSettings
            });
            _this2.initializeAutoUpdate();
            _this2.$hideSpinner();
          case 7:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    dateTimeToLocal: function dateTimeToLocal(datetime) {
      var z = datetime.includes('Z') ? '' : 'Z';
      return datetime + z;
    },
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdate === 'function' && typeof this.autoUpdate.cancel === 'function') {
        this.autoUpdate.cancel();
      }
      this.autoUpdate = function () {};
    },
    disableFetchEstimageSetting: function disableFetchEstimageSetting() {
      console.log('disable fetch estimage');
      if (typeof this.fetchEstimageSetting === 'function' && typeof this.fetchEstimageSetting.cancel === 'function') {
        this.fetchEstimageSetting.cancel();
      }
      this.fetchEstimageSetting = function () {};
    },
    fetchEstimageSetting: function fetchEstimageSetting() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee2() {
        var settings, _t5, _t6;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              console.log('Fetching company external settings');
              _t5 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context2.n = 1;
              return _this3.getStoreItem({
                serviceFunction: 'getCompanyExternalSettings',
                params: _this3.$route.params.companyId
              });
            case 1:
              _t6 = _context2.v;
              settings = _t5(_t6);
              _this3.companyExternalSettings[_this3.activeTabIndex].modifiedDate = settings[_this3.activeTabIndex].modifiedDate;
              if (!(_this3.companyExternalSettings[_this3.activeTabIndex].property4 !== settings[_this3.activeTabIndex].property4)) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this3.$store.dispatch('company/getCompanySetting');
            case 2:
              _this3.companyExternalSettings[_this3.activeTabIndex].property4 = settings[_this3.activeTabIndex].property4;
              if (_this3.lastModified === _this3.activeCompanyExternalSetting.modifiedDate) {
                // Schedule the next fetch after 5 seconds (5000 ms)
                if (_this3.isEstimageSettingPage) {
                  _this3.timeOutId = setTimeout(_this3.fetchEstimageSetting, 1000 * 5);
                  console.log('keep on checking ' + _this3.timeOutId);
                }
              } else {
                _this3.lastModified = null;
                _this3.stopFetchEstimageSetting();
              }
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    stopFetchEstimageSetting: function stopFetchEstimageSetting() {
      clearTimeout(this.timeOutId); // Stop the timeout
      this.timeOutId = null;
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this4 = this;
      this.autoUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default()(/*#__PURE__*/function () {
        var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee3(value) {
          var _t7;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context3) {
            while (1) switch (_context3.n) {
              case 0:
                _t7 = _this4.snapshotDiff;
                if (!_t7) {
                  _context3.n = 1;
                  break;
                }
                _context3.n = 1;
                return _this4.updateExternalSetting(value);
              case 1:
                return _context3.a(2);
            }
          }, _callee3);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    randomPassword: function randomPassword(length, nonAlphaLength) {
      var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP1234567890';
      var nonAlphaChars = '!@#$%^*()_+~|}{[]:;?,./-=';
      var pass = '';
      for (var x = 0; x < length; x++) {
        var i = Math.floor(Math.random() * chars.length);
        pass += chars.charAt(i);
      }
      for (var y = 0; y < nonAlphaLength; y++) {
        var n = Math.floor(Math.random() * nonAlphaChars.length);
        var pos = Math.floor(Math.random() * pass.length);
        pass = pass.substring(0, pos) + nonAlphaChars.charAt(n) + pass.substring(pos + nonAlphaChars.charAt(n).length);
      }
      this.activeCompanyExternalSetting['password'] = pass;
    },
    requirePasswordGeneration: function requirePasswordGeneration(column) {
      var _this5 = this;
      var integrations = ['BodyNet', 'WebTrim', 'Planning Plus'];
      return column.value == 'password' && integrations.some(function (i) {
        return i == _this5.activeCompanyExternalSetting['settingName'];
      });
    },
    requirePasswordInvisible: function requirePasswordInvisible(column) {
      var _this6 = this;
      var integrations = ['ORM', 'PNET', 'Audatex'];
      return column.value == 'password' && integrations.some(function (i) {
        return i == _this6.activeCompanyExternalSetting['settingName'];
      });
    },
    isDiable: function isDiable(column) {
      var _this7 = this;
      if (this.isPartsCheckSmartReceiptingColumn(column)) {
        return !this.isPartsCheckAutoSyncOn;
      }
      var integrations = ['Estimage'];
      return column.value == 'property4' && integrations.some(function (i) {
        return i == _this7.activeCompanyExternalSetting['settingName'];
      });
    },
    isPartsCheckSmartReceiptingColumn: function isPartsCheckSmartReceiptingColumn(column) {
      return this.isPartsCheckSettingPage && column.value === 'property3';
    },
    updateExternalSetting: function updateExternalSetting(externalSetting) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee4() {
        var _iterator, _step, _loop, _t8, _t9, _t0;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              if (_this8.snapshotDiff) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              _this8.$v.$touch();
              if (!_this8.$v.$error) {
                _context5.n = 2;
                break;
              }
              return _context5.a(2);
            case 2:
              if (!_this8.isNew) {
                _context5.n = 3;
                break;
              }
              _this8.setStateProperty({
                key: 'companyExternalSettings',
                value: externalSetting
              });
              return _context5.a(2);
            case 3:
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(externalSetting);
              _context5.p = 4;
              _loop = /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _loop() {
                var item, _this8$baseSnapshot$f, _this8$baseSnapshot$f2, baseItem, diff;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context4) {
                  while (1) switch (_context4.n) {
                    case 0:
                      item = _step.value;
                      _this8$baseSnapshot$f = _this8.baseSnapshot.filter(function (i) {
                        return i.companyExternalSettingId == item.companyExternalSettingId;
                      }), _this8$baseSnapshot$f2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this8$baseSnapshot$f, 1), baseItem = _this8$baseSnapshot$f2[0];
                      diff = deep_diff__WEBPACK_IMPORTED_MODULE_22__["DeepDiff"].diff(baseItem, item);
                      item.deepDiff = diff ? JSON.stringify(diff) : null;
                    case 1:
                      return _context4.a(2);
                  }
                }, _loop);
              });
              _iterator.s();
            case 5:
              if ((_step = _iterator.n()).done) {
                _context5.n = 7;
                break;
              }
              return _context5.d(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_loop()), 6);
            case 6:
              _context5.n = 5;
              break;
            case 7:
              _context5.n = 9;
              break;
            case 8:
              _context5.p = 8;
              _t8 = _context5.v;
              _iterator.e(_t8);
            case 9:
              _context5.p = 9;
              _iterator.f();
              return _context5.f(9);
            case 10:
              _t9 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context5.n = 11;
              return _this8.editStoreItem({
                serviceFunction: 'updateCompanyExternalSetting',
                entity: externalSetting,
                params: _this8.$route.params.companyId
              });
            case 11:
              _t0 = _context5.v;
              _this8.companyExternalSettings = _t9(_t0);
              if (_this8.toastNotificationEnabled) {
                _this8.openToastNotification();
              }
            case 12:
              return _context5.a(2);
          }
        }, _callee4, null, [[4, 8, 9, 10]]);
      }))();
    },
    popupWindow: function popupWindow(url, windowName, win, w, h) {
      var y = win.top.outerHeight / 2 + win.top.screenY - h / 2;
      var x = win.top.outerWidth / 2 + win.top.screenX - w / 2;
      return win.open(url, windowName, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=".concat(w, ", height=").concat(h, ", top=").concat(y, ", left=").concat(x));
    },
    connectEstimage: function connectEstimage() {
      var _arguments = arguments,
        _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee5() {
        var isTest, estImageConfig, estImageUrl, estimageClientId, url, w, h, y, x;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              isTest = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _this9.$showSpinner();
              if (!(_this9.activeCompanyExternalSetting.username === null || _this9.activeCompanyExternalSetting.username === '')) {
                _context6.n = 1;
                break;
              }
              _this9.$notification.openNotificationWithType('danger', 'Estimage', 'Username cannot be blank!');
              _this9.$hideSpinner();
              return _context6.a(2, false);
            case 1:
              if (!_this9.snapshotDiff) {
                _context6.n = 2;
                break;
              }
              _context6.n = 2;
              return _this9.updateExternalSetting(_this9.companyExternalSettings);
            case 2:
              _context6.n = 3;
              return _services__WEBPACK_IMPORTED_MODULE_24__["EstImageService"].getEstimageConfig();
            case 3:
              estImageConfig = _context6.v;
              estImageUrl = isTest ? estImageConfig.estImageUrlTest : estImageConfig.estImageUrl;
              estimageClientId = isTest ? estImageConfig.estImageClientIdTest : estImageConfig.estImageClientId;
              _this9.lastModified = _this9.activeCompanyExternalSetting.modifiedDate;
              _this9.fetchEstimageSetting();
              url = "".concat(estImageUrl, "/oauth/authorize?response_type=code&client_id=").concat(estimageClientId, "&redirect_uri=").concat(estImageConfig.estImageRedirectUrl, "/auth");
              w = 800;
              h = 650;
              y = window.top.outerHeight / 2 + window.top.screenY - h / 2;
              x = window.top.outerWidth / 2 + window.top.screenX - w / 2;
              _this9.$hideSpinner();
              if (!(!estImageUrl || !estimageClientId || !estImageConfig.estImageRedirectUrl)) {
                _context6.n = 4;
                break;
              }
              _this9.$notification.openNotificationWithType('danger', 'Estimage', 'Could not connect to EstImage. Config is missing.');
              _context6.n = 5;
              break;
            case 4:
              return _context6.a(2, window.open(url, 'Estimage Online Authorisation', "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=".concat(w, ", height=").concat(h, ", top=").concat(y, ", left=").concat(x)));
            case 5:
              return _context6.a(2);
          }
        }, _callee5);
      }))();
    }
  },
  validations: function validations() {
    var _this0 = this;
    return {
      activeCompanyExternalSetting: {
        password: {
          maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_25__["maxLength"])(50)
        },
        property3: {
          // Only PartsCheck gives Property3 a meaning (Smart Receipted Documents): blank, 0 or 1.
          smartReceiptingValue: function smartReceiptingValue(value) {
            return !_this0.isPartsCheckSettingPage || !value || ['0', '1'].includes(value.trim());
          }
        }
      }
    };
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this1 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee6() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            _this1.disableAutoUpdate();
            _this1.disableFetchEstimageSetting();
            _this1.toastNotificationEnabled = true;
            _context7.n = 1;
            return _this1.updateExternalSetting(_this1.companyExternalSettings);
          case 1:
            _this1.clearSnapshots();
            _this1.toastNotificationEnabled = false;
            next();
          case 2:
            return _context7.a(2);
        }
      }, _callee6);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator || _vm.$userInfo.isSystemAdministrator ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_vm._m(0), !_vm.hasError && _vm.showSavingStatus && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "tabs is-boxed"
  }, [_c("ul", _vm._l(_vm.companyExternalSettings, function (companyExternalSetting, index) {
    return _c("li", {
      key: index,
      class: {
        "is-active": _vm.activeTabIndex === index
      }
    }, [_c("a", {
      on: {
        click: function click($event) {
          _vm.activeTabIndex = index;
        }
      }
    }, [_vm._v(_vm._s(companyExternalSetting.settingName))])]);
  }), 0)])]), _vm.activeCompanyExternalSetting ? _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, _vm._l(_vm.$options.columns.left, function (column, index) {
    return _c("div", {
      key: index,
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label"
    }, [_vm._v(_vm._s(_vm.activeCompanyExternalSetting[column.label]))]), _vm.requirePasswordInvisible(column) ? _c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control is-expanded"
    }, [(_vm.showPassword ? "text" : "password") === "checkbox" ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.activeCompanyExternalSetting[column.value],
        expression: "activeCompanyExternalSetting[column.value]"
      }],
      staticClass: "input",
      attrs: {
        disabled: !_vm.passwordEnabled,
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(_vm.activeCompanyExternalSetting[column.value]) ? _vm._i(_vm.activeCompanyExternalSetting[column.value], null) > -1 : _vm.activeCompanyExternalSetting[column.value]
      },
      on: {
        change: function change($event) {
          var $$a = _vm.activeCompanyExternalSetting[column.value],
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(_vm.activeCompanyExternalSetting, column.value, $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(_vm.activeCompanyExternalSetting, column.value, $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(_vm.activeCompanyExternalSetting, column.value, $$c);
          }
        }
      }
    }) : (_vm.showPassword ? "text" : "password") === "radio" ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.activeCompanyExternalSetting[column.value],
        expression: "activeCompanyExternalSetting[column.value]"
      }],
      staticClass: "input",
      attrs: {
        disabled: !_vm.passwordEnabled,
        type: "radio"
      },
      domProps: {
        checked: _vm._q(_vm.activeCompanyExternalSetting[column.value], null)
      },
      on: {
        change: function change($event) {
          return _vm.$set(_vm.activeCompanyExternalSetting, column.value, null);
        }
      }
    }) : _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.activeCompanyExternalSetting[column.value],
        expression: "activeCompanyExternalSetting[column.value]"
      }],
      staticClass: "input",
      attrs: {
        disabled: !_vm.passwordEnabled,
        type: _vm.showPassword ? "text" : "password"
      },
      domProps: {
        value: _vm.activeCompanyExternalSetting[column.value]
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(_vm.activeCompanyExternalSetting, column.value, $event.target.value);
        }
      }
    }), !_vm.$v.activeCompanyExternalSetting.password.maxLength ? _c("span", {
      staticClass: "help is-danger ml-1"
    }, [_vm._v("Password must not exceed 50 characters.")]) : _vm._e()]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button",
      on: {
        click: function click($event) {
          _vm.passwordEnabled = !_vm.passwordEnabled;
        }
      }
    }, [_vm._m(1, true)])]), _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button",
      on: {
        click: function click($event) {
          _vm.showPassword = !_vm.showPassword;
        }
      }
    }, [_c("span", {
      staticClass: "icon has-text-primary"
    }, [_c("span", {
      staticClass: "mso mso-24px"
    }, [_vm._v(" " + _vm._s(_vm.showPassword ? "visibility" : "visibility_off") + " ")])])])])]) : _c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.activeCompanyExternalSetting[column.value],
        expression: "activeCompanyExternalSetting[column.value]"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        disabled: _vm.requirePasswordGeneration(column) || _vm.isDiable(column)
      },
      domProps: {
        value: _vm.activeCompanyExternalSetting[column.value]
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(_vm.activeCompanyExternalSetting, column.value, $event.target.value);
        }
      }
    })]), _vm.requirePasswordGeneration(column) ? _c("p", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button is-primary",
      on: {
        click: function click($event) {
          return _vm.randomPassword(32, 6);
        }
      }
    }, [_vm._v(" Generate ")])]) : _vm._e()])]);
  }), 0), _c("div", {
    staticClass: "column is-half"
  }, _vm._l(_vm.$options.columns.right, function (column, index) {
    return _c("div", {
      key: index,
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label"
    }, [_vm._v(_vm._s(_vm.activeCompanyExternalSetting[column.label]) + " "), _vm.isEstimageSettingPage && _vm.activeCompanyExternalSetting[column.label] === "Enable Estimage Online" ? _c("span", {
      staticClass: "has-text-weight-normal is-italic is-size-7"
    }, [_vm._v(" ("), _vm.$userInfo.isSupportUser ? _c("span", [_c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("2")]), _vm._v(" = Test, ")]) : _vm._e(), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("1")]), _vm._v(" = On and "), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("0")]), _vm._v(" = Off) ")]) : _vm._e(), _vm.isEstimageSettingPage && _vm.activeCompanyExternalSetting[column.label] === "Auto Sync" ? _c("span", {
      staticClass: "has-text-weight-normal is-italic is-size-7"
    }, [_vm._v(" ("), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("1")]), _vm._v(" = On and "), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("0")]), _vm._v(" = Off) ")]) : _vm._e(), _vm.isPartsCheckSettingPage && _vm.activeCompanyExternalSetting[column.label] === "Auto Sync" ? _c("span", {
      staticClass: "has-text-weight-normal is-italic is-size-7"
    }, [_vm._v(" ("), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("2")]), _vm._v(" = On and "), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("0")]), _vm._v(" = Off) ")]) : _vm._e(), _vm.isPartsCheckSmartReceiptingColumn(column) ? _c("span", {
      staticClass: "has-text-weight-normal is-italic is-size-7"
    }, [_vm._v(" ("), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("1")]), _vm._v(" = On and "), _c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("0")]), _vm._v(" = Off, requires Auto Sync) ")]) : _vm._e()]), _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.activeCompanyExternalSetting[column.value],
        expression: "activeCompanyExternalSetting[column.value]"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        disabled: _vm.requirePasswordGeneration(column) || _vm.isDiable(column)
      },
      domProps: {
        value: _vm.activeCompanyExternalSetting[column.value]
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(_vm.activeCompanyExternalSetting, column.value, $event.target.value);
        }
      }
    }), _vm.isPartsCheckSmartReceiptingColumn(column) ? [!_vm.isPartsCheckAutoSyncOn ? _c("span", {
      staticClass: "help is-italic has-text-grey"
    }, [_vm._v("Set Auto Sync to 2 to turn on Smart Receipted Documents.")]) : !_vm.$v.activeCompanyExternalSetting.property3.smartReceiptingValue ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Enter 1 (On) or 0 (Off).")]) : _vm._e()] : _vm._e()], 2);
  }), 0)]) : _vm._e(), _vm.isEstimageSettingPage ? _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "flex-row"
  }, [_c("div", {
    staticClass: "mr-4"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: function click($event) {
        return _vm.connectEstimage(false);
      }
    }
  }, [_vm._m(2), _c("span", [_vm.activeCompanyExternalSetting.property4 === "1" ? _c("span", [_vm._v("Re-")]) : _vm._e(), _vm._v("Connect to Estimage")])]), _vm.activeCompanyExternalSetting.property4 === "1" ? _c("span", {
    staticClass: "help is-italic has-text-grey"
  }, [_vm._v("Last connected: " + _vm._s(_vm.$filters.formatDateTimeLocale(_vm.dateTimeToLocal(_vm.activeCompanyExternalSetting.modifiedDate), _vm.$userInfo.locale)) + " ")]) : _vm._e()]), _vm.$userInfo.isSupportUser ? _c("div", {
    staticClass: "mr-4"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: function click($event) {
        return _vm.connectEstimage(true);
      }
    }
  }, [_vm._m(3), _c("span", [_vm.activeCompanyExternalSetting.property4 === "2" ? _c("span", [_vm._v("Re-")]) : _vm._e(), _vm._v("Connect to Test Estimage")])]), _vm.activeCompanyExternalSetting.property4 === "2" ? _c("span", {
    staticClass: "help is-italic has-text-grey"
  }, [_vm._v("Last connected: " + _vm._s(_vm.$filters.formatDateTimeLocale(_vm.dateTimeToLocal(_vm.activeCompanyExternalSetting.modifiedDate), _vm.$userInfo.locale)) + " ")]) : _vm._e()]) : _vm._e()])]), _vm._m(4)]) : _vm._e()])]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Integration")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("edit")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("cached")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("cached")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column is-half is-flex is-justify-content-right is-align-items-center"
  }, [_c("span", {
    staticClass: "icon is-small has-text-primary mr-1"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("info")])]), _c("span", {
    staticClass: "help is-primary is-italic"
  }, [_vm._v("Reconnection may periodically be required.")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".tabs ul[data-v-ff629e52] {\n  width: 10em;\n}\ndiv.flex-row[data-v-ff629e52] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("0c1107d4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/companysetting/CompanyIntegrationSetting.vue":
/*!****************************************************************!*\
  !*** ./src/views/companysetting/CompanyIntegrationSetting.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true */ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true");
/* harmony import */ var _CompanyIntegrationSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyIntegrationSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true */ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CompanyIntegrationSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "ff629e52",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyIntegrationSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyIntegrationSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true":
/*!*************************************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=style&index=0&id=ff629e52&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_style_index_0_id_ff629e52_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyIntegrationSetting.vue?vue&type=template&id=ff629e52&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyIntegrationSetting_vue_vue_type_template_id_ff629e52_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=16.js.map