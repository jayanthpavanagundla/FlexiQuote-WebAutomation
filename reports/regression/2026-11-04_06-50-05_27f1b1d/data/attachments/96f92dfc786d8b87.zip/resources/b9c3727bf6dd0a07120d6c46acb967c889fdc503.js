(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["superadmin-systemmessage-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _systemMessageService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./systemMessageService */ "./src/views/superadmin/systemmessage/systemMessageService.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storeMixin */ "./src/views/superadmin/systemmessage/storeMixin.js");
/* harmony import */ var _SystemMessageValidation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./SystemMessageValidation */ "./src/views/superadmin/systemmessage/SystemMessageValidation.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12__);













/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SystemMessageDetail',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_8__["BaseModalEx"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_10__["default"], _SystemMessageValidation__WEBPACK_IMPORTED_MODULE_11__["default"]],
  data: function data() {
    return {
      isLoading: false,
      isLoadingMore: false,
      hasMoreMessages: true,
      messages: [],
      selectedTab: 'current',
      isEditing: false,
      editingMessageId: null,
      innerEntity: {
        systemMessageId: null,
        title: '',
        caption: '',
        message: '',
        type: '',
        linkText: '',
        linkUrl: '',
        startAtUtc: null,
        endAtUtc: null,
        isDraft: false,
        active: false,
        deleted: false
      },
      filter: {
        sortColumn: '',
        sortOrder: '',
        pageIndex: 1,
        pageSize: 10
      },
      messageTypes: [{
        value: 'info',
        label: 'Information'
      }, {
        value: 'warning',
        label: 'Warning'
      }, {
        value: 'success',
        label: 'Success'
      }, {
        value: 'danger',
        label: 'Danger'
      }],
      dateFormats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L LT', 'DD-MM-YYYY HH:mm', 'DD/MM/YYYY HH:mm'],
        data: ['L LT', 'DD-MM-YYYY HH:mm', 'DD/MM/YYYY HH:mm'],
        dayPopover: 'L'
      },
      isDeleteModalActive: false,
      messageToDelete: null
    };
  },
  computed: {
    filteredMessages: function filteredMessages() {
      if (!this.messages || this.messages.length === 0) {
        return [];
      }
      if (this.selectedTab === 'archived') {
        // Archived: messages whose end date has passed
        var _now = new Date();
        return this.messages.filter(function (m) {
          if (m.isDraft || !m.endAtUtc) {
            return false;
          }
          var endAt = m.endAtUtc instanceof Date ? m.endAtUtc : new Date(m.endAtUtc);
          return endAt < _now;
        });
      }

      // System Messages: current and upcoming messages (including drafts)
      var now = new Date();
      return this.messages.filter(function (m) {
        if (m.isDraft || !m.endAtUtc) {
          return true;
        }
        var endAt = m.endAtUtc instanceof Date ? m.endAtUtc : new Date(m.endAtUtc);
        return endAt >= now;
      });
    },
    dateAttrs: function dateAttrs() {
      return [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080',
          fillMode: 'light'
        },
        dates: new Date()
      }];
    }
  },
  watch: {
    selectedTab: function selectedTab() {
      var _this = this;
      // Reset scroll position when switching tabs
      this.$nextTick(function () {
        if (_this.$refs.messagesContainer) {
          _this.$refs.messagesContainer.scrollTop = 0;
        }
      });
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _this2.loadMessages();
          case 1:
            _context.n = 2;
            return _this2.getEntity();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    getEntity: function getEntity() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (!_this3.editingMessageId) {
                _context2.n = 1;
                break;
              }
              _context2.n = 1;
              return _this3.getStoreItem(_this3.editingMessageId);
            case 1:
              if (_this3.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this3.addStoreItem();
            case 2:
              if (_this3.currentSnapshot) {
                _this3.innerEntity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12___default()(_this3.currentSnapshot);
              }
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    loadMessages: function loadMessages() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var result, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              _this4.isLoading = true;
              _this4.filter.pageIndex = 1;
              _this4.hasMoreMessages = true;
              _context3.p = 1;
              _context3.n = 2;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].getMessages(_this4.filter);
            case 2:
              result = _context3.v;
              _this4.messages = result || [];
              if (_this4.messages.length < _this4.filter.pageSize) {
                _this4.hasMoreMessages = false;
              }
              _context3.n = 4;
              break;
            case 3:
              _context3.p = 3;
              _t = _context3.v;
              _this4.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to load messages');
              console.error('Error loading messages:', _t);
            case 4:
              _context3.p = 4;
              _this4.isLoading = false;
              return _context3.f(4);
            case 5:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 3, 4, 5]]);
      }))();
    },
    loadMoreMessages: function loadMoreMessages() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var result, newMessages, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              if (!(_this5.isLoadingMore || !_this5.hasMoreMessages)) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              _this5.isLoadingMore = true;
              _this5.filter.pageIndex++;
              _context4.p = 2;
              _context4.n = 3;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].getMessages(_this5.filter);
            case 3:
              result = _context4.v;
              newMessages = result || [];
              if (newMessages.length > 0) {
                _this5.messages = [].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this5.messages), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newMessages));
              }
              if (newMessages.length < _this5.filter.pageSize) {
                _this5.hasMoreMessages = false;
              }
              _context4.n = 5;
              break;
            case 4:
              _context4.p = 4;
              _t2 = _context4.v;
              _this5.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to load more messages');
              console.error('Error loading more messages:', _t2);
              _this5.filter.pageIndex--;
            case 5:
              _context4.p = 5;
              _this5.isLoadingMore = false;
              return _context4.f(5);
            case 6:
              return _context4.a(2);
          }
        }, _callee4, null, [[2, 4, 5, 6]]);
      }))();
    },
    onScroll: function onScroll(event) {
      var container = event.target;
      var scrollBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
      if (scrollBottom < 100 && !this.isLoadingMore && this.hasMoreMessages) {
        this.loadMoreMessages();
      }
    },
    truncateText: function truncateText(text, maxLength) {
      if (!text) return '';
      if (text.length <= maxLength) return text;
      return text.substring(0, maxLength) + '...';
    },
    formatDisplayDate: function formatDisplayDate(date) {
      if (!date) return 'N/A';
      return this.$filters.formatDateTimeLocale(date, this.$userInfo.locale);
    },
    getMessageTypeClass: function getMessageTypeClass(type) {
      var classes = {
        info: 'is-info',
        warning: 'is-warning',
        danger: 'is-danger',
        success: 'is-success'
      };
      return classes[type] || 'is-info';
    },
    validateForm: function validateForm() {
      this.$v.$touch();
      return !this.$v.$invalid;
    },
    saveAsDraft: function saveAsDraft() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        var payload, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              if (_this6.validateForm()) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              _this6.$showSpinner('Saving...');
              _context5.p = 2;
              payload = _this6.preparePayload(true, false);
              if (!_this6.isEditing) {
                _context5.n = 4;
                break;
              }
              _context5.n = 3;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].updateMessage(_this6.editingMessageId, payload);
            case 3:
              _context5.n = 5;
              break;
            case 4:
              _context5.n = 5;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].createMessage(payload);
            case 5:
              _this6.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12___default()(_this6.innerEntity));
              _this6.$notification.openNotificationWithType('success', 'System Messages', 'Message saved as draft');
              _this6.reset();
              _context5.n = 6;
              return _this6.getEntity();
            case 6:
              _context5.n = 7;
              return _this6.loadMessages();
            case 7:
              _context5.n = 9;
              break;
            case 8:
              _context5.p = 8;
              _t3 = _context5.v;
              _this6.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to save message');
              console.error('Error saving message:', _t3);
            case 9:
              _context5.p = 9;
              _this6.$hideSpinner();
              return _context5.f(9);
            case 10:
              return _context5.a(2);
          }
        }, _callee5, null, [[2, 8, 9, 10]]);
      }))();
    },
    saveAndActivate: function saveAndActivate() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var payload, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.p = _context6.n) {
            case 0:
              if (_this7.validateForm()) {
                _context6.n = 1;
                break;
              }
              return _context6.a(2);
            case 1:
              _this7.$showSpinner('Saving...');
              _context6.p = 2;
              payload = _this7.preparePayload(false, true);
              if (!_this7.isEditing) {
                _context6.n = 4;
                break;
              }
              _context6.n = 3;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].updateMessage(_this7.editingMessageId, payload);
            case 3:
              _context6.n = 5;
              break;
            case 4:
              _context6.n = 5;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].createMessage(payload);
            case 5:
              _this7.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12___default()(_this7.innerEntity));
              _this7.$notification.openNotificationWithType('success', 'System Messages', 'Message saved and activated');
              _this7.reset();
              _context6.n = 6;
              return _this7.getEntity();
            case 6:
              _context6.n = 7;
              return _this7.loadMessages();
            case 7:
              _context6.n = 9;
              break;
            case 8:
              _context6.p = 8;
              _t4 = _context6.v;
              _this7.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to save message');
              console.error('Error saving message:', _t4);
            case 9:
              _context6.p = 9;
              _this7.$hideSpinner();
              return _context6.f(9);
            case 10:
              return _context6.a(2);
          }
        }, _callee6, null, [[2, 8, 9, 10]]);
      }))();
    },
    preparePayload: function preparePayload(isDraft, isActive) {
      return {
        systemMessageId: this.innerEntity.systemMessageId,
        title: this.innerEntity.title,
        caption: this.innerEntity.caption,
        message: this.innerEntity.message,
        type: this.innerEntity.type,
        linkText: this.innerEntity.linkText,
        linkUrl: this.innerEntity.linkUrl,
        startAtUtc: this.innerEntity.startAtUtc ? this.innerEntity.startAtUtc.toISOString() : null,
        endAtUtc: this.innerEntity.endAtUtc ? this.innerEntity.endAtUtc.toISOString() : null,
        isDraft: isDraft,
        active: isActive,
        deleted: this.innerEntity.deleted || false
      };
    },
    editMessage: function editMessage(message) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this8.isEditing = true;
              _this8.editingMessageId = message.systemMessageId;
              _context7.n = 1;
              return _this8.getEntity();
            case 1:
              if (!_this8.innerEntity || !_this8.innerEntity.title) {
                _this8.innerEntity = {
                  systemMessageId: message.systemMessageId,
                  title: message.title,
                  caption: message.caption,
                  message: message.message || '',
                  type: message.type,
                  linkText: message.linkText || '',
                  linkUrl: message.linkUrl || '',
                  startAtUtc: message.startAtUtc ? new Date(message.startAtUtc) : null,
                  endAtUtc: message.endAtUtc ? new Date(message.endAtUtc) : null,
                  active: message.active,
                  deleted: message.deleted || false
                };
                _this8.saveInitialSnapshots(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_12___default()(_this8.innerEntity));
              }
              _this8.$v.$reset();
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    cancelEdit: function cancelEdit() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this9.reset();
              _context8.n = 1;
              return _this9.getEntity();
            case 1:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    reset: function reset() {
      this.isEditing = false;
      this.editingMessageId = null;
      this.innerEntity = {
        systemMessageId: null,
        title: '',
        caption: '',
        message: '',
        type: '',
        linkText: '',
        linkUrl: '',
        startAtUtc: null,
        endAtUtc: null,
        active: false,
        deleted: false
      };
      this.$v.$reset();
      this.clearSnapshots();
    },
    confirmDelete: function confirmDelete(message) {
      this.messageToDelete = message;
      this.isDeleteModalActive = true;
    },
    deleteMessage: function deleteMessage() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee9() {
        var _this0$messageToDelet, _t5;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context9) {
          while (1) switch (_context9.p = _context9.n) {
            case 0:
              if (_this0.messageToDelete) {
                _context9.n = 1;
                break;
              }
              return _context9.a(2);
            case 1:
              _this0.$showSpinner('Deleting...');
              _context9.p = 2;
              _context9.n = 3;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].deleteMessage(_this0.messageToDelete.systemMessageId);
            case 3:
              _this0.$notification.openNotificationWithType('success', 'System Messages', 'Message deleted');
              _this0.isDeleteModalActive = false;
              _this0.messageToDelete = null;
              if (!(_this0.editingMessageId === ((_this0$messageToDelet = _this0.messageToDelete) === null || _this0$messageToDelet === void 0 ? void 0 : _this0$messageToDelet.systemMessageId))) {
                _context9.n = 4;
                break;
              }
              _this0.reset();
              _context9.n = 4;
              return _this0.getEntity();
            case 4:
              _context9.n = 5;
              return _this0.loadMessages();
            case 5:
              _context9.n = 7;
              break;
            case 6:
              _context9.p = 6;
              _t5 = _context9.v;
              _this0.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to delete message');
              console.error('Error deleting message:', _t5);
            case 7:
              _context9.p = 7;
              _this0.$hideSpinner();
              return _context9.f(7);
            case 8:
              return _context9.a(2);
          }
        }, _callee9, null, [[2, 6, 7, 8]]);
      }))();
    },
    restoreMessage: function restoreMessage(message) {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee0() {
        var now, endDate, payload, _t6;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context0) {
          while (1) switch (_context0.p = _context0.n) {
            case 0:
              if (message) {
                _context0.n = 1;
                break;
              }
              return _context0.a(2);
            case 1:
              _this1.$showSpinner('Restoring...');
              _context0.p = 2;
              now = new Date();
              now.setSeconds(0, 0);
              if (now.getMinutes() % 5 !== 0) {
                now.setMinutes(now.getMinutes() + (5 - now.getMinutes() % 5));
              }
              endDate = new Date(now.getTime() + 5 * 60 * 1000);
              payload = {
                systemMessageId: message.systemMessageId,
                title: message.title,
                caption: message.caption,
                message: message.message,
                type: message.type,
                linkText: message.linkText,
                linkUrl: message.linkUrl,
                startAtUtc: now.toISOString(),
                endAtUtc: endDate.toISOString(),
                isDraft: false,
                active: true,
                deleted: message.deleted || false
              };
              _context0.n = 3;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].updateMessage(message.systemMessageId, payload);
            case 3:
              _this1.$notification.openNotificationWithType('success', 'System Messages', 'Message restored');
              _context0.n = 4;
              return _this1.loadMessages();
            case 4:
              _this1.selectedTab = 'current';
              _context0.n = 6;
              break;
            case 5:
              _context0.p = 5;
              _t6 = _context0.v;
              _this1.$notification.openNotificationWithType('danger', 'System Messages', 'Failed to restore message');
              console.error('Error restoring message:', _t6);
            case 6:
              _context0.p = 6;
              _this1.$hideSpinner();
              return _context0.f(6);
            case 7:
              return _context0.a(2);
          }
        }, _callee0, null, [[2, 5, 6, 7]]);
      }))();
    },
    handleToggleChange: function handleToggleChange(message, event) {
      if (!message || message.isDraft) return;
      var newActiveStatus = !!event.target.checked;
      this.updateMessageStatus(message, newActiveStatus);
    },
    toggleMessageStatus: function toggleMessageStatus(message) {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee1() {
        var newActiveStatus;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (!(!message || message.isDraft)) {
                _context1.n = 1;
                break;
              }
              return _context1.a(2);
            case 1:
              newActiveStatus = !message.active;
              _context1.n = 2;
              return _this10.updateMessageStatus(message, newActiveStatus);
            case 2:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    updateMessageStatus: function updateMessageStatus(message, newActiveStatus) {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee10() {
        var statusText, payload, _t7;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context10) {
          while (1) switch (_context10.p = _context10.n) {
            case 0:
              statusText = newActiveStatus ? 'activated' : 'deactivated';
              _this11.$showSpinner("".concat(newActiveStatus ? 'Activating' : 'Deactivating', "..."));
              _context10.p = 1;
              payload = {
                systemMessageId: message.systemMessageId,
                title: message.title,
                caption: message.caption,
                message: message.message,
                type: message.type,
                linkText: message.linkText,
                linkUrl: message.linkUrl,
                startAtUtc: message.startAtUtc,
                endAtUtc: message.endAtUtc,
                active: newActiveStatus,
                deleted: message.deleted || false
              };
              _context10.n = 2;
              return _systemMessageService__WEBPACK_IMPORTED_MODULE_9__["default"].updateMessage(message.systemMessageId, payload);
            case 2:
              _this11.$notification.openNotificationWithType('success', 'System Messages', "Message ".concat(statusText, " successfully"));
              _context10.n = 3;
              return _this11.loadMessages();
            case 3:
              _context10.n = 5;
              break;
            case 4:
              _context10.p = 4;
              _t7 = _context10.v;
              _this11.$notification.openNotificationWithType('danger', 'System Messages', "Failed to ".concat(statusText, " message"));
              console.error("Error ".concat(statusText, " message:"), _t7);
            case 5:
              _context10.p = 5;
              _this11.$hideSpinner();
              return _context10.f(5);
            case 6:
              return _context10.a(2);
          }
        }, _callee10, null, [[1, 4, 5, 6]]);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storeMixin */ "./src/views/superadmin/systemmessage/storeMixin.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SystemMessageView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_4__["default"]],
  data: function data() {
    return {};
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _t = action;
              _context.n = _t === _enums__WEBPACK_IMPORTED_MODULE_3__["AppHeaderButtonTypes"].AddNew ? 1 : _t === _enums__WEBPACK_IMPORTED_MODULE_3__["AppHeaderButtonTypes"].Print ? 4 : _t === _enums__WEBPACK_IMPORTED_MODULE_3__["AppHeaderButtonTypes"].Delete ? 5 : _t === _enums__WEBPACK_IMPORTED_MODULE_3__["AppHeaderButtonTypes"].Save ? 6 : _t === _enums__WEBPACK_IMPORTED_MODULE_3__["AppHeaderButtonTypes"].Cancel ? 7 : 8;
              break;
            case 1:
              if (!(_this.$refs.currentChild && _this.$refs.currentChild.getEntity)) {
                _context.n = 3;
                break;
              }
              _context.n = 2;
              return _this.$refs.currentChild.reset();
            case 2:
              _context.n = 3;
              return _this.$refs.currentChild.getEntity();
            case 3:
              return _context.a(3, 8);
            case 4:
              return _context.a(3, 8);
            case 5:
              return _context.a(3, 8);
            case 6:
              return _context.a(3, 8);
            case 7:
              return _context.a(3, 8);
            case 8:
              return _context.a(2);
          }
        }, _callee);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm$messageToDelete;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "fixed-grid has-12-cols"
  }, [_c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell is-col-span-6 left-column"
  }, [_c("article", {
    staticClass: "box detail-page-tile is-flex-grow-1 is-flex is-flex-direction-column pt-2",
    staticStyle: {
      "max-height": "calc(120vh - 8rem)"
    }
  }, [_c("div", {
    staticClass: "tabs mb-4"
  }, [_c("ul", [_c("li", {
    staticClass: "sub-title",
    class: {
      "is-active": _vm.selectedTab === "current"
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        $event.preventDefault();
        _vm.selectedTab = "current";
      }
    }
  }, [_c("span", [_vm._v("System Messages")])])]), _c("li", {
    staticClass: "sub-title",
    class: {
      "is-active": _vm.selectedTab === "archived"
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        $event.preventDefault();
        _vm.selectedTab = "archived";
      }
    }
  }, [_c("span", [_vm._v("Archived Messages")])])])])]), _vm.isLoading ? _c("div", {
    staticClass: "has-text-centered p-4"
  }, [_vm._m(0), _c("p", {
    staticClass: "mt-2"
  }, [_vm._v("Loading messages...")])]) : _c("div", {
    ref: "messagesContainer",
    staticClass: "is-flex-grow-1 is-overflow-y-auto pt-4 pr-4",
    staticStyle: {
      "max-height": "calc(120vh)"
    },
    on: {
      scroll: _vm.onScroll
    }
  }, [_vm.filteredMessages.length === 0 ? _c("div", {
    staticClass: "has-text-centered p-4 has-text-grey"
  }, [_c("span", {
    staticClass: "msr msr-36px has-text-grey"
  }, [_vm._v(" add_comment ")]), _c("p", {
    staticClass: "mt-2"
  }, [_vm._v(" " + _vm._s(_vm.selectedTab === "current" ? "No system-wide messages are currently published." : "No archived messages.") + " ")]), _vm.selectedTab === "current" ? _c("p", {
    staticClass: "mt-2"
  }, [_vm._v(" Add a new message to keep users informed of any issues or announcements. ")]) : _vm._e()]) : _vm._e(), _vm._l(_vm.filteredMessages, function (message) {
    return _c("div", {
      key: message.systemMessageId,
      staticClass: "message-card mb-6",
      staticStyle: {
        position: "relative"
      }
    }, [_c("span", {
      staticClass: "is-size-7 has-text-grey",
      staticStyle: {
        position: "absolute",
        top: "-1.2rem",
        left: "0"
      }
    }, [_vm._v(" " + _vm._s(message.modifiedByName || message.createdByName) + " - " + _vm._s(_vm.$filters.formatDateTimeLocale(message.modifiedDate || message.createdDate, _vm.$userInfo.locale)) + " ")]), _c("div", {
      staticClass: "is-flex is-justify-content-space-between is-align-items-start mb-2"
    }, [_c("div", {
      staticClass: "is-flex is-align-items-center"
    }, [_c("span", {
      staticClass: "message-indicator mr-2",
      class: _vm.getMessageTypeClass(message.type)
    }), _c("div", {
      staticClass: "message-title has-text-weight-semibold"
    }, [_vm._v(" " + _vm._s(message.title) + " ")])]), _c("div", {
      staticClass: "is-flex is-align-items-center"
    }, [message.isDraft ? _c("span", {
      staticClass: "tag is-rounded mr-2"
    }, [_vm._v(" Draft ")]) : message.active ? _c("span", {
      staticClass: "tag is-success mr-2 has-text-light"
    }, [_vm._m(1, true), _vm._v("  Active ")]) : _c("span", [_vm._m(2, true)]), !message.isDraft && _vm.selectedTab === "current" ? _c("div", {
      staticClass: "pretty p-switch p-fill"
    }, [_c("input", {
      attrs: {
        type: "checkbox"
      },
      domProps: {
        checked: !!message.active
      },
      on: {
        change: function change($event) {
          return _vm.handleToggleChange(message, $event);
        }
      }
    }), _vm._m(3, true)]) : _vm._e(), _c("button", {
      staticClass: "button is-small is-white tooltip is-tooltip-bottom ml-1",
      attrs: {
        "data-tooltip": "Edit"
      },
      on: {
        click: function click($event) {
          return _vm.editMessage(message);
        }
      }
    }, [_vm._m(4, true)]), _c("button", {
      staticClass: "button is-small is-white tooltip is-tooltip-bottom ml-1",
      attrs: {
        "data-tooltip": "Delete"
      },
      on: {
        click: function click($event) {
          return _vm.confirmDelete(message);
        }
      }
    }, [_vm._m(5, true)]), _vm.selectedTab === "archived" ? _c("button", {
      staticClass: "button is-small is-white tooltip is-tooltip-bottom ml-1",
      attrs: {
        "data-tooltip": "Restore"
      },
      on: {
        click: function click($event) {
          return _vm.restoreMessage(message);
        }
      }
    }, [_vm._m(6, true)]) : _vm._e()])]), _c("div", {
      staticClass: "message-content mb-2 is-size-7"
    }, [_vm._v(" " + _vm._s(_vm.truncateText(message.caption, 150)) + " ")]), message.startAtUtc || message.endAtUtc ? _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7 has-text-grey"
    }, [_vm._m(7, true), _c("span", [_vm._v(" " + _vm._s(_vm.formatDisplayDate(message.startAtUtc)) + " - " + _vm._s(_vm.formatDisplayDate(message.endAtUtc)) + " ")])]) : _vm._e()]);
  }), _vm.isLoadingMore ? _c("div", {
    staticClass: "has-text-centered p-4"
  }, [_vm._m(8), _c("span", {
    staticClass: "ml-2"
  }, [_vm._v("Loading more...")])]) : _vm._e(), !_vm.hasMoreMessages && _vm.filteredMessages.length > 0 ? _c("div", {
    staticClass: "has-text-centered p-4 has-text-grey is-size-7"
  }, [_c("span", [_vm._v("— End of messages —")])]) : _vm._e()], 2)])]), _c("div", {
    staticClass: "cell is-col-span-6"
  }, [_c("article", {
    staticClass: "box detail-page-tile is-flex is-flex-direction-column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v(_vm._s(_vm.isEditing ? "Edit Message" : "Create New Message"))]), _c("div", {
    staticClass: "is-flex-grow-1"
  }, [_c("div", {
    staticClass: "field"
  }, [_vm._m(9), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.title,
      expression: "innerEntity.title"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.innerEntity.title.$error
    },
    attrs: {
      type: "text",
      placeholder: "Add message title"
    },
    domProps: {
      value: _vm.innerEntity.title
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEntity, "title", $event.target.value);
      }
    }
  })]), !_vm.$v.innerEntity.title.required && _vm.$v.innerEntity.title.$dirty ? _c("p", {
    staticClass: "help is-danger"
  }, [_vm._v("Message title is required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_vm._m(10), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.caption,
      expression: "innerEntity.caption"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": _vm.$v.innerEntity.caption.$error
    },
    attrs: {
      rows: "3",
      placeholder: "Brief message shown by default"
    },
    domProps: {
      value: _vm.innerEntity.caption
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEntity, "caption", $event.target.value);
      }
    }
  })]), !_vm.$v.innerEntity.caption.required && _vm.$v.innerEntity.caption.$dirty ? _c("p", {
    staticClass: "help is-danger"
  }, [_vm._v("Short message is required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Detailed Message (optional)")]), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.message,
      expression: "innerEntity.message"
    }],
    staticClass: "textarea",
    attrs: {
      rows: "4",
      placeholder: "Additional details shown when the user clicks 'Read More'"
    },
    domProps: {
      value: _vm.innerEntity.message
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEntity, "message", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_vm._m(11), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    class: {
      "is-danger": _vm.$v.innerEntity.type.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.type,
      expression: "innerEntity.type"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerEntity, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.messageTypes, function (type) {
    return _c("option", {
      key: type.value,
      domProps: {
        value: type.value
      }
    }, [_vm._v(" " + _vm._s(type.label) + " ")]);
  })], 2)])]), !_vm.$v.innerEntity.type.required && _vm.$v.innerEntity.type.$dirty ? _c("p", {
    staticClass: "help is-danger"
  }, [_vm._v("Message type is required")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_vm._m(12), _c("div", {
    staticClass: "columns is-mobile"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.dateFormats,
      attributes: _vm.dateAttrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone(),
      "minute-increment": 5,
      mode: "dateTime"
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          class: {
            "is-danger": _vm.$v.innerEntity.startAtUtc.$error
          },
          attrs: {
            type: "text",
            placeholder: "Start Date & Time"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), !_vm.$v.innerEntity.startAtUtc.required && _vm.$v.innerEntity.startAtUtc.$dirty ? _c("p", {
          staticClass: "help is-danger"
        }, [_vm._v("Start date & time is required")]) : _vm._e(), _vm.$v.innerEntity.startAtUtc.required && _vm.$v.innerEntity.startAtUtc.$error && !_vm.$v.innerEntity.startAtUtc.minDate ? _c("p", {
          staticClass: "help is-danger"
        }, [_vm._v("Start date must be today or later")]) : _vm._e()];
      }
    }]),
    model: {
      value: _vm.innerEntity.startAtUtc,
      callback: function callback($$v) {
        _vm.$set(_vm.innerEntity, "startAtUtc", $$v);
      },
      expression: "innerEntity.startAtUtc"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.dateFormats,
      attributes: _vm.dateAttrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone(),
      "minute-increment": 5,
      mode: "dateTime"
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref2) {
        var inputValue = _ref2.inputValue,
          inputEvents = _ref2.inputEvents;
        return [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          class: {
            "is-danger": _vm.$v.innerEntity.endAtUtc.$error
          },
          attrs: {
            type: "text",
            placeholder: "End Date & Time"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), !_vm.$v.innerEntity.endAtUtc.required && _vm.$v.innerEntity.endAtUtc.$dirty ? _c("p", {
          staticClass: "help is-danger"
        }, [_vm._v("End date & time is required")]) : _vm._e(), _vm.$v.innerEntity.endAtUtc.required && _vm.$v.innerEntity.endAtUtc.$error && !_vm.$v.innerEntity.endAtUtc.greaterThanStartDate ? _c("p", {
          staticClass: "help is-danger"
        }, [_vm._v("End date must be after start date")]) : _vm._e()];
      }
    }]),
    model: {
      value: _vm.innerEntity.endAtUtc,
      callback: function callback($$v) {
        _vm.$set(_vm.innerEntity, "endAtUtc", $$v);
      },
      expression: "innerEntity.endAtUtc"
    }
  })], 1)])]), _c("hr", {
    staticClass: "my-4"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Link Text")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.linkText,
      expression: "innerEntity.linkText"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Add text for link"
    },
    domProps: {
      value: _vm.innerEntity.linkText
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEntity, "linkText", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Link URL")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEntity.linkUrl,
      expression: "innerEntity.linkUrl"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Add link URL"
    },
    domProps: {
      value: _vm.innerEntity.linkUrl
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEntity, "linkUrl", $event.target.value);
      }
    }
  })])])]), _c("div", {
    staticClass: "is-flex is-justify-content-flex-end pt-4",
    staticStyle: {
      "border-top": "1px solid var(--bulma-border)"
    }
  }, [_vm.isEditing ? _c("button", {
    staticClass: "button mr-2",
    on: {
      click: _vm.cancelEdit
    }
  }, [_c("span", {
    staticClass: "msr msr-18px mr-1"
  }, [_vm._v(" close ")]), _c("span", [_vm._v("Cancel")])]) : _vm._e(), _c("button", {
    staticClass: "button mr-2",
    on: {
      click: _vm.saveAsDraft
    }
  }, [_c("span", {
    staticClass: "msr msr-18px mr-1"
  }, [_vm._v(" edit ")]), _c("span", [_vm._v("Save as Draft")])]), _c("button", {
    staticClass: "button is-success",
    on: {
      click: _vm.saveAndActivate
    }
  }, [_c("span", {
    staticClass: "msr msr-18px mr-1"
  }, [_vm._v(" save ")]), _c("span", [_vm._v("Save & Activate")])])])])])]), _c("base-modal-ex", {
    attrs: {
      active: _vm.isDeleteModalActive,
      "animation-in": "zoomIn",
      "animation-out": "zoomOut",
      "animation-duration": 0.3,
      "can-cancel": false,
      "min-width": 40,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteModalActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Confirm Delete")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("p", [_vm._v("Are you sure you want to delete this system message?")]), _c("p", {
    staticClass: "has-text-weight-semibold mt-2"
  }, [_vm._v(_vm._s((_vm$messageToDelete = _vm.messageToDelete) === null || _vm$messageToDelete === void 0 ? void 0 : _vm$messageToDelete.title))])]), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("button", {
    staticClass: "button mr-2",
    on: {
      click: function click($event) {
        _vm.isDeleteModalActive = false;
      }
    }
  }, [_c("span", {
    staticClass: "msr msr-18px mr-1"
  }, [_vm._v(" close ")]), _vm._v(" Cancel ")]), _c("button", {
    staticClass: "button is-danger",
    on: {
      click: _vm.deleteMessage
    }
  }, [_c("span", {
    staticClass: "msr msr-18px mr-1"
  }, [_vm._v(" delete ")]), _c("span", [_vm._v("Delete")])])])])], 1)])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-large"
  }, [_c("i", {
    staticClass: "mdi mdi-loading mdi-spin mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-16px"
  }, [_vm._v("check_circle")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "tag is-danger mr-2 has-text-light"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("span", {
    staticClass: "msr msr-16px"
  }, [_vm._v("do_not_disturb_on")])]), _vm._v("  Inactive ")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-restore mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-clock-outline mdi-14px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-loading mdi-spin mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("label", {
    staticClass: "label"
  }, [_vm._v("Message Title "), _c("span", {
    staticClass: "has-text-danger"
  }, [_vm._v("*")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("label", {
    staticClass: "label"
  }, [_vm._v("Short Message "), _c("span", {
    staticClass: "has-text-danger"
  }, [_vm._v("*")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("label", {
    staticClass: "label"
  }, [_vm._v("Message Type "), _c("span", {
    staticClass: "has-text-danger"
  }, [_vm._v("*")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("label", {
    staticClass: "label"
  }, [_vm._v("Display Duration "), _c("span", {
    staticClass: "has-text-danger"
  }, [_vm._v("*")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo.isSystemAdministrator ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": false,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": false,
      "show-lock": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("router-view", {
    ref: "currentChild"
  })], 1)])], 1) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v("You do not have permissions on this page")])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".message-card[data-v-7195d691] {\n  padding: 1rem;\n  border: 1px solid var(--bulma-border);\n  border-radius: 8px;\n  background: var(--bulma-scheme-main);\n  -webkit-transition: -webkit-box-shadow 0.2s ease;\n  transition: -webkit-box-shadow 0.2s ease;\n  transition: box-shadow 0.2s ease;\n  transition: box-shadow 0.2s ease, -webkit-box-shadow 0.2s ease;\n}\n.message-card[data-v-7195d691]:hover {\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);\n}\n.message-indicator[data-v-7195d691] {\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  display: inline-block;\n}\n.message-indicator.is-info[data-v-7195d691] {\n  background-color: var(--bulma-info);\n}\n.message-indicator.is-warning[data-v-7195d691] {\n  background-color: var(--bulma-warning);\n}\n.message-indicator.is-danger[data-v-7195d691] {\n  background-color: var(--bulma-danger);\n}\n.message-indicator.is-success[data-v-7195d691] {\n  background-color: var(--bulma-success);\n}\n.message-title[data-v-7195d691] {\n  font-size: 1rem;\n  color: var(--bulma-text-strong);\n}\n.message-content[data-v-7195d691] {\n  line-height: 1.4;\n}\n.left-column[data-v-7195d691] {\n  position: relative;\n}\n.left-column[data-v-7195d691]::after {\n  content: \"\";\n  position: absolute;\n  top: 10%;\n  right: 0;\n  width: 1px;\n  height: 80%;\n  background-color: var(--bulma-border);\n}\n.sub-title[data-v-7195d691] {\n  font-weight: var(--bulma-weight-semibold);\n  font-size: 1.25rem;\n  white-space: nowrap;\n}\n.tabs ul li.sub-title a[data-v-7195d691] {\n  border-bottom: 3px solid transparent;\n  color: var(--bulma-text);\n}\n.tabs ul li.sub-title.is-active a[data-v-7195d691] {\n  border-bottom-color: var(--bulma-primary);\n  color: var(--bulma-text-strong);\n}\n.pretty.p-switch.p-fill input:not(:checked) ~ .state.p-primary[data-v-7195d691]::before {\n  background-color: var(--bulma-border) !important;\n}\n.pretty.p-switch.p-fill input:not(:checked) ~ .state.p-primary label[data-v-7195d691]::after {\n  background-color: #fff !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3e685aa2", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue":
/*!********************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageDetail.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true */ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true");
/* harmony import */ var _SystemMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SystemMessageDetail.vue?vue&type=script&lang=js */ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true */ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SystemMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7195d691",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/systemmessage/SystemMessageDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js":
/*!********************************************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true":
/*!*****************************************************************************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=style&index=0&id=7195d691&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_style_index_0_id_7195d691_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true":
/*!**************************************************************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true ***!
  \**************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageDetail.vue?vue&type=template&id=7195d691&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageDetail_vue_vue_type_template_id_7195d691_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageValidation.js":
/*!***********************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageValidation.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

var minDate = function minDate(value) {
  if (!value) return true;
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  var inputDate = new Date(value);
  inputDate.setHours(0, 0, 0, 0);
  return inputDate >= today;
};
var greaterThanStartDate = function greaterThanStartDate(value, vm) {
  if (!value || !vm.startAtUtc) return true;
  var endDate = new Date(value);
  var startDate = new Date(vm.startAtUtc);
  return endDate > startDate;
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    innerEntity: {
      title: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      caption: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      type: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      message: {},
      linkText: {},
      linkUrl: {},
      startAtUtc: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        minDate: minDate
      },
      endAtUtc: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        greaterThanStartDate: greaterThanStartDate
      }
    }
  }
});

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageView.vue":
/*!******************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageView.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true */ "./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true");
/* harmony import */ var _SystemMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SystemMessageView.vue?vue&type=script&lang=js */ "./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SystemMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7caace36",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/superadmin/systemmessage/SystemMessageView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/superadmin/systemmessage/SystemMessageView.vue?vue&type=template&id=7caace36&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SystemMessageView_vue_vue_type_template_id_7caace36_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/superadmin/systemmessage/storeMixin.js":
/*!**********************************************************!*\
  !*** ./src/views/superadmin/systemmessage/storeMixin.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var systemMessageModuleName = 'systemmessage';
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {};
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(systemMessageModuleName, {
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    snapshots: 'snapshots',
    returnRoute: 'returnRoute'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['debounceDelay'])),
  watch: {},
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(systemMessageModuleName, ['getStoreItem', 'addStoreItem', 'clearSnapshots', 'saveSnapshot', 'saveInitialSnapshots', 'setReturnRoute']))
});

/***/ })

}]);
//# sourceMappingURL=superadmin-systemmessage-chunk.js.map