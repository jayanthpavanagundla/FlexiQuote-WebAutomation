(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["returnparts-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SubtitleTotals',
  props: {
    labels: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    totals: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    shows: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {};
  },
  computed: {},
  created: function created() {},
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _ReturnPartsItemList__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ReturnPartsItemList */ "./src/views/returnparts/ReturnPartsItemList.vue");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./columns */ "./src/views/returnparts/columns.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_SubtitleTotals__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/SubtitleTotals */ "./src/components/SubtitleTotals/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");










// import DealerCreditEntryService from './BankUndepositedFundService'










// import { roundAwayFromZero } from '@/components/utils/AccountingFunctions'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsDetail',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, _ReturnPartsItemList__WEBPACK_IMPORTED_MODULE_11__["default"].name, _ReturnPartsItemList__WEBPACK_IMPORTED_MODULE_11__["default"]), "BulmaTable", _components_BulmaTable__WEBPACK_IMPORTED_MODULE_10__["default"]), "SubtitleTotals", _components_SubtitleTotals__WEBPACK_IMPORTED_MODULE_17__["default"]), "VueNumeric", _components_VueNumeric__WEBPACK_IMPORTED_MODULE_13__["default"]),
  props: {
    vendorDetail: {
      type: Object
    },
    vendorFilter: {
      type: Object
    },
    readOnly: Boolean,
    value: Object
  },
  data: function data() {
    return {
      emptyGuid: _components_Guid__WEBPACK_IMPORTED_MODULE_16__["default"].empty(),
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default()(this.value),
      isTableLoading: false,
      totalRows: 0,
      isReturnPartItemListActive: true,
      returnTotalAmount: 0.0,
      gstAmount: 0.0,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      selectedRow: null
    };
  },
  computed: {
    $v: function $v() {},
    columns: function columns() {
      var cols = _columns__WEBPACK_IMPORTED_MODULE_12__["ReturnPartsDetail"];
      if (this.innerValue.returnPartsItem.length === 0) {
        cols[11].isVisible = false;
      } else {
        cols[11].isVisible = true;
      }
      return cols;
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            return _context.a(2);
        }
      }, _callee);
    }))();
  } // this.getData()
  ,
  mounted: function mounted() {},
  methods: {
    toggleReturnPartItemList: function toggleReturnPartItemList() {
      this.isReturnPartItemListActive = !this.isReturnPartItemListActive;
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    addBlankItem: function addBlankItem() {
      var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_15__["ReturnItemPartsModel"](this.innerValue.vendorId);
      this.innerValue.returnPartsItem.push(newItem);
    },
    calculateTotalLoad: function calculateTotalLoad() {
      this.returnTotalAmount = 0.0;
      this.gstAmount = 0.0;
      for (var i = 0; i < this.innerValue.returnPartsItem.length; i++) {
        if (this.innerValue.returnPartsItem[i].returning > 0) {
          this.returnTotalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.returnTotalAmount + this.innerValue.returnPartsItem[i].returning * this.innerValue.returnPartsItem[i].invcAmount, 2);
        }
      }
      if (this.returnTotalAmount > 0) {
        if (this.innerValue.gstDivisor > 0) {
          this.gstAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.returnTotalAmount / this.innerValue.gstDivisor, 2);
        } else {
          this.gstAmount = 0.0;
        }
      }
    },
    calculateTotal: function calculateTotal(item, index) {
      this.returnTotalAmount = 0.0;
      this.gstAmount = 0.0;
      for (var i = 0; i < this.innerValue.returnPartsItem.length; i++) {
        if (this.innerValue.returnPartsItem[i].returning > 0) {
          this.returnTotalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.returnTotalAmount + this.innerValue.returnPartsItem[i].returning * this.innerValue.returnPartsItem[i].invcAmount, 2);
        }
      }
      if (this.returnTotalAmount > 0) {
        if (this.innerValue.gstDivisor > 0) {
          this.gstAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.returnTotalAmount / this.innerValue.gstDivisor, 2);
        } else {
          this.gstAmount = 0.0;
        }
      }
      if (this.innerValue.returnPartsItem[index].isNewLine === true) {
        this.innerValue.returnPartsItem[index].totalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.innerValue.returnPartsItem[index].returning * this.innerValue.returnPartsItem[index].invcAmount, 2);
      } else {
        this.innerValue.returnPartsItem[index].totalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_18__["roundAwayFromZero"])(this.innerValue.returnPartsItem[index].returning * this.innerValue.returnPartsItem[index].invcAmount, 2);
      }
    },
    deleteItem: function deleteItem(item, index) {
      if (item.isNewLine) {
        var itemIndex = this.innerValue.returnPartsItem.map(function (obj) {
          return obj.returnPartsID;
        }).indexOf(item.returnPartsID);
        if (itemIndex >= 0) {
          this.innerValue.returnPartsItem.splice(itemIndex, 1);
        }
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_1__);

// import _cloneDeep from 'lodash/cloneDeep'


// import { roundAwayFromZero } from '@/components/utils/AccountingFunctions'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsDetailValue',
  inject: ['$vv'],
  components: {
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_1__["TheMask"]
  },
  directives: {
    mask: vue_the_mask__WEBPACK_IMPORTED_MODULE_1__["mask"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_0__["NumberFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_0__["DateTimeFiltersMixin"]],
  props: {
    vendorAbn: String,
    returnNo: String,
    vendorId: String,
    returnDate: String,
    readOnly: Boolean
  },
  data: function data() {
    return {
      isReturnedPartsValue: '1',
      returnDetail: {
        abn: this.vendorAbn,
        number: this.returnNo,
        id: this.vendorId,
        date: this.returnDate
      },
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  },
  watch: {
    vendorId: {
      handler: function handler(newVal, oldVal) {
        this.returnDetail.id = newVal;
      }
    },
    vendorAbn: {
      handler: function handler(newVal, oldVal) {
        this.returnDetail.abn = newVal;
      }
    },
    'returnDetail.abn': {
      handler: function handler(newVal, oldVal) {
        this.changeValue();
      }
    },
    'returnDetail.date': {
      handler: function handler(newVal, oldVal) {
        this.changeValue();
      }
    }
  },
  mounted: function mounted() {
    this.$v.detailGroup.$touch();
  },
  created: function created() {},
  methods: {
    changeValue: function changeValue() {
      // this.returnDetail.abn = this.vendorAbn
      // this.returnDetail.no = this.returnNo
      // this.returnDetail.id = this.vendorId
      var date = new Date(this.returnDetail.date);
      this.returnDetail.date = date.toISOString().split('.')[0] + 'Z';
      this.$emit('changevalue', this.returnDetail);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ReturnPartsService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ReturnPartsService */ "./src/views/returnparts/ReturnPartsService.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./columns */ "./src/views/returnparts/columns.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__);











// import { calcTotalExGst, calcGst, roundAwayFromZero } from '@/components/utils/AccountingFunctions'




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsItemList',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_11__["default"]
  },
  props: {
    value: Object,
    vendorFilter: {
      type: Object
    }
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default()(this.value),
      returnPartsItems: [],
      totalRows: 0,
      receiptDate: new Date().toISOString(),
      emptyGuid: _components_Guid__WEBPACK_IMPORTED_MODULE_10__["default"].empty(),
      filter: {
        query: '',
        isReceiptDate: false,
        receiptDate: new Date().toISOString(),
        vendorId: null,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_12__["ReturnPartsItems"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_12__["ReturnPartsItems"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 4
      },
      isShowAllReceipt: false,
      selectedRow: null,
      isTableLoading: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_12__["ReturnPartsItems"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
        this.$emit('input', newVal);
      },
      deep: true
    },
    receiptDate: function receiptDate(newVal, oldVal) {
      if (newVal) {
        this.filter.receiptDate = this.receiptDate.toISOString();
      }
      this.filter.pageIndex = 1;
      this.getData();
    },
    isShowAllReceipt: function isShowAllReceipt(newVal, oldVal) {
      if (newVal) {
        this.receiptDate = new Date();
        this.filter.receiptDate = this.receiptDate.toISOString();
        this.filter.isReceiptDate = true;
      } else {
        this.receiptDate = new Date();
        this.receiptDate.setMonth(this.receiptDate.getMonth() - 2);
        this.filter.receiptDate = this.receiptDate.toISOString();
        this.filter.isReceiptDate = false;
      }
      this.getData();
    },
    vendorFilter: {
      handler: function handler(newVal, oldVal) {
        this.filter.vendorId = newVal.vendorId;
        // this.innerValue.vendorId = this.vendorFilter.vendorId
        if (newVal !== null) {
          this.getData();
        }
      },
      deep: true
    }
  },
  created: function created() {
    this.receiptDate = new Date();
    this.receiptDate.setMonth(this.receiptDate.getMonth() - 2);
    this.filter.receiptDate = this.receiptDate.toISOString();
    this.getData();
  },
  mounted: function mounted() {},
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    getData: function getData() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!(_this.vendorFilter.vendorId !== null && _this.vendorFilter.vendorId !== _components_Guid__WEBPACK_IMPORTED_MODULE_10__["default"].empty())) {
                _context.n = 2;
                break;
              }
              _this.filter.vendorId = _this.vendorFilter.vendorId;
              _this.isTableLoading = true;
              _context.n = 1;
              return _ReturnPartsService__WEBPACK_IMPORTED_MODULE_8__["default"].getReturnPartsItems(_this.filter);
            case 1:
              _this.returnPartsItems = _context.v;
              if (_this.returnPartsItems) {
                // this.innerValue.returnPartsListItem = this.returnPartsItems
                _this.totalRows = _this.returnPartsItems.length > 0 ? _this.returnPartsItems[0].totalRows : 0;
              } else {
                _this.totalRows = 0;
              }
              _this.isTableLoading = false;
              _this.$emit('calculateTotal');
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.getData();
    },
    reset: function reset() {
      this.filter.pageIndex = 1;
      this.filter.query = '';
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.getData();
    },
    search: lodash_debounce__WEBPACK_IMPORTED_MODULE_9___default()(function () {
      this.filter.pageIndex = 1;
      this.getData();
    }, 500),
    addBlankItem: function addBlankItem() {
      var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__["ReturnItemPartsModel"](this.innerValue.vendorId);
      this.value.returnPartsItem.push(newItem);
    },
    addNewItem: function addNewItem(item, index) {
      // Find item by item no
      var itemExist = this.innerValue.returnPartsItem.filter(function (i) {
        return i.poItemId === item.poItemID && i.creditorInvoiceId === item.creditorInvoiceId;
      });
      if (itemExist.length !== 0) {
        this.$notification.openNotificationWithType('warning', 'Return Parts', 'Item is already in selected list. Item not added.');
      } else if (this.innerValue.returnPartsItem.length !== 0 && item.poNumber !== this.innerValue.returnPartsItem[0].poNumber) {
        this.$notification.openNotificationWithType('warning', 'Return Parts', 'Item can not be addedd to different purchase order no');
      } else {
        var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_13__["ReturnItemPartsModel"](item.vendorId, item.crReturnNo, item.creditReturnId, item.creditorInvoiceId, item.invcAmount, item.invoiceNo, item.invoiceRef, item.model, item.partNo, item.poItemID, item.poNumber, item.poRetQty, item.qtyCredited, item.quoteNo, item.recDate, item.rced, item.return, item.returnPartsID, item.returned, item.returning, item.script, item.totalAmount, item.totalReturned);
        this.innerValue.returnPartsItem.push(newItem);
      }
    },
    isAddItem: function isAddItem(item, index) {
      if (this.innerValue.returnPartsItem.length !== 0) {
        var itemExist = this.innerValue.returnPartsItem.filter(function (i) {
          return i.poItemId === item.poItemID && i.creditorInvoiceId === item.creditorInvoiceId;
        });
        if (itemExist.length !== 0 || item.poNumber !== this.innerValue.returnPartsItem[0].poNumber) {
          return false;
        } else {
          return true;
        }
      } else {
        return true;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./columns */ "./src/views/returnparts/columns.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18__);



















// import { TheMask } from 'vue-the-mask'

// import DealerCreditEntryAttachmentsModal from './DealerCreditEntryAttachmentsModal'
// import { roundAwayFromZero } from '@/components/utils/AccountingFunctions'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsRemarks',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_14__["default"],
    RemarkModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__["RemarkModal"]
  },
  directives: {
    mask: vue_the_mask__WEBPACK_IMPORTED_MODULE_12__["mask"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_11__["NumberFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_11__["DateTimeFiltersMixin"]],
  props: {
    value: null,
    readOnly: Boolean
  },
  data: function data() {
    return {
      isRemarkModalActive: false,
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_18___default()(this.value),
      printedFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_13__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_13__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 2
      },
      editRemarkRowNumber: -1,
      editPrintedRemarkRowNumber: -1,
      isTableLoading: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_13__["RemarkColumns"];
    },
    printedRemarkTotalRows: function printedRemarkTotalRows() {
      return this.innerValue.printedRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].PrintedRemark && !r.isDeleted;
      }).length;
    },
    remarkTotalRows: function remarkTotalRows() {
      return this.innerValue.remarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].Remark && !r.isDeleted;
      }).length;
    },
    remarkTypes: function remarkTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"];
    },
    activePrintedRemarks: function activePrintedRemarks() {
      return this.innerValue.printedRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].PrintedRemark && !r.isDeleted;
      });
    },
    pagedPrintedRemarks: function pagedPrintedRemarks() {
      return this.activePrintedRemarks.slice((this.printedFilter.pageIndex - 1) * this.printedFilter.pageSize, this.printedFilter.pageIndex * this.printedFilter.pageSize);
    },
    activeRemarks: function activeRemarks() {
      return this.innerValue.remarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].Remark && !r.isDeleted;
      });
    },
    pagedRemarks: function pagedRemarks() {
      return this.activeRemarks.slice((this.filter.pageIndex - 1) * this.filter.pageSize, this.filter.pageIndex * this.filter.pageSize);
    } // pagedPrintedRemarks() {
    //   return this.activePrintedRemarks.slice(
    //     (this.printedFilter.pageIndex - 1) * this.printedFilter.pageSize,
    //     this.printedFilter.pageIndex * this.printedFilter.pageSize
    //   )
    // }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
      },
      deep: true
    },
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  methods: {
    deleteRemark: function deleteRemark(index, remarkId, remarkType) {
      var deletedRemark;
      if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].Remark) {
        deletedRemark = this.activeRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew) {
          var _index = this.innerValue.remarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.remarks.splice(_index, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      } else if (remarkType === _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].PrintedRemark) {
        deletedRemark = this.activePrintedRemarks.find(function (r) {
          return r.remarkId == remarkId;
        });
        if (deletedRemark.isNew) {
          var _index2 = this.innerValue.printedRemarks.findIndex(function (r) {
            return r.remarkId === deletedRemark.remarkId;
          });
          this.innerValue.printedRemarks.splice(_index2, 1);
        } else {
          deletedRemark.isDeleted = true;
        }
      }
    },
    addRemarks: function addRemarks(remark, printedRemark) {
      if (remark) {
        var newRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_16__["RemarkModel"](this.innerValue.creditReturnMainId, _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].Remark, remark);
        this.innerValue.remarks.push(newRemark);
      }
      if (printedRemark) {
        var newPrintedRemark = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_16__["RemarkModel"](this.innerValue.creditReturnMainId, _enums__WEBPACK_IMPORTED_MODULE_15__["RemarkTypes"].PrintedRemark, printedRemark);
        this.innerValue.printedRemarks.push(newPrintedRemark);
      }
      this.toggleRemarkModal();
    },
    toggleRemarkModal: function toggleRemarkModal() {
      this.isRemarkModalActive = !this.isRemarkModalActive;
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
    },
    onPrintedRemarksPageChange: function onPrintedRemarksPageChange(pageIndex) {
      this.printedFilter.pageIndex = pageIndex;
    },
    sort: function sort(name, order) {},
    editRemark: function editRemark(row) {
      this.editRemarkRowNumber !== row ? this.editRemarkRowNumber = row : this.editRemarkRowNumber = -1;
      this.editPrintedRemarkRowNumber = -1;
    },
    editPrintedRemark: function editPrintedRemark(row) {
      this.editPrintedRemarkRowNumber !== row ? this.editPrintedRemarkRowNumber = row : this.editPrintedRemarkRowNumber = -1;
      this.editRemarkRowNumber = -1;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _views_vendor_VendorService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/views/vendor/VendorService */ "./src/views/vendor/VendorService.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./route-types */ "./src/views/returnparts/route-types.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10__);











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsSideMenu',
  components: {
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_8___default.a,
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_4__["NumberFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_4__["DateTimeFiltersMixin"]],
  props: {
    value: Object,
    isNew: Boolean,
    readOnly: Boolean
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_10___default()(this.value),
      vendors: [],
      vendorsName: [],
      isVendorLoading: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      assetFilter: {
        id: _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty(),
        name: '',
        pageIndex: 1,
        pageSize: 50
      },
      selectedVendor: {
        abn: '',
        id: '',
        name: '',
        totalRows: ''
      }
    };
  },
  computed: {
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_9__["default"];
    }
  },
  watch: {
    // innerValue: {
    //   handler: function(newVal, oldVal) {
    //     this.$emit('input', newVal)
    //   },
    //   deep: true
    // },
    // receiptDate: function(newVal, oldVal) {
    //   if (newVal) {
    //     this.innerValue.receiptDate = this.receiptDate.toISOString()
    //   }
    // },
    // isShowReceipt: function(newVal, oldVal) {
    //   if (newVal) {
    //     this.receiptDate = new Date()
    //     this.innerValue.receiptDate = this.receiptDate.toISOString()
    //     this.innerValue.isReceiptDate = true
    //   } else {
    //     this.receiptDate = new Date()
    //     this.receiptDate.setMonth(this.receiptDate.getMonth() - 6)
    //     this.innerValue.receiptDate = this.receiptDate.toISOString()
    //     this.innerValue.isReceiptDate = false
    //   }
    // }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            // console.log('Get Vendor')
            _this.getVendorsDropdown();
            // this.selectedVendor = this.value.selectedVendor !== null ? this.value.selectedVendor : ''
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    selectVendor: function selectVendor(selected) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.selectedVendor = selected;
              _this2.$emit('changedetail', _this2.selectedVendor);
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    removeVendor: function removeVendor() {},
    // onFilterClick() {
    //   this.$emit('input', true)
    // },
    // onResetClick() {
    //   this.$emit('reset')
    // },
    getVendorsDropdown: function getVendorsDropdown() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isVendorLoading = true;
              if (_this3.innerValue.vendorId !== null) {
                _this3.assetFilter.id = _this3.innerValue.vendorId;
              }
              _context3.n = 1;
              return _views_vendor_VendorService__WEBPACK_IMPORTED_MODULE_5__["default"].getVendorDropdownProto2(_this3.assetFilter);
            case 1:
              _this3.vendors = _context3.v;
              if (_this3.assetFilter.id !== _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty()) {
                _this3.selectedVendor = _this3.vendors;
                _this3.innerValue.vendorId = _this3.vendors[0].id;
              }
              _this3.isVendorLoading = false;
              return _context3.a(2, _this3.vendors);
          }
        }, _callee3);
      }))();
    },
    getVendorDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              this.isVendorLoading = true;
              this.assetFilter.name = query;
              _context4.n = 1;
              return _views_vendor_VendorService__WEBPACK_IMPORTED_MODULE_5__["default"].getVendorDropdownProto2(this.assetFilter);
            case 1:
              this.vendors = _context4.v;
              this.isVendorLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500)
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _ReturnPartsSideMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ReturnPartsSideMenu */ "./src/views/returnparts/ReturnPartsSideMenu.vue");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _ReturnPartsValidation__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./ReturnPartsValidation */ "./src/views/returnparts/ReturnPartsValidation.js");
/* harmony import */ var _ReturnPartsDetail__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ReturnPartsDetail */ "./src/views/returnparts/ReturnPartsDetail.vue");
/* harmony import */ var _ReturnPartsDetailValue__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./ReturnPartsDetailValue */ "./src/views/returnparts/ReturnPartsDetailValue.vue");
/* harmony import */ var _ReturnPartsRemarks__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./ReturnPartsRemarks */ "./src/views/returnparts/ReturnPartsRemarks.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./route-types */ "./src/views/returnparts/route-types.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./storeMixin */ "./src/views/returnparts/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _ReturnPartsService__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./ReturnPartsService */ "./src/views/returnparts/ReturnPartsService.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_32__);















// import ReturnPartsService from './ReturnPartsService'


















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReturnPartsView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_21__["default"]
  }, _ReturnPartsSideMenu__WEBPACK_IMPORTED_MODULE_14__["default"].name, _ReturnPartsSideMenu__WEBPACK_IMPORTED_MODULE_14__["default"]), _ReturnPartsDetail__WEBPACK_IMPORTED_MODULE_17__["default"].name, _ReturnPartsDetail__WEBPACK_IMPORTED_MODULE_17__["default"]), _ReturnPartsDetailValue__WEBPACK_IMPORTED_MODULE_18__["default"].name, _ReturnPartsDetailValue__WEBPACK_IMPORTED_MODULE_18__["default"]), _ReturnPartsRemarks__WEBPACK_IMPORTED_MODULE_19__["default"].name, _ReturnPartsRemarks__WEBPACK_IMPORTED_MODULE_19__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__["UnsavedModal"]), "SaveConflictModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__["SaveConflictModal"]), "ConfirmModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__["ConfirmModal"]),
  mixins: [_ReturnPartsValidation__WEBPACK_IMPORTED_MODULE_16__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_25__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      entitySummaries: null,
      activeReturnPartItems: null,
      filter: {
        vendorId: null,
        isReceiptDate: true,
        receiptDate: new Date()
      },
      vendorDetail: {
        vendorId: '',
        vendorName: '',
        vendorAbn: '',
        returnNo: '',
        returnDate: new Date()
      },
      readOnly: false,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      isSave: false,
      toRoute: null // stores "to" route of beforeRouteLeave
    };
  },
  computed: {},
  watch: {},
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.returnUrl) {
              _this.persistQueries();
              _this.replaceRoute(_this.$route.params.creditReturnMainId);
            }
            _context.n = 1;
            return _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Delete:
          this.isConfirmModalActive = true;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.creditReturnMainId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.creditReturnMainId);
            case 2:
              _this2.entitySummaries = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this2.currentSnapshot);
              if (_this2.entitySummaries.returnPartsItem) {
                _this2.activeReturnPartItems = _this2.entitySummaries.returnPartsItem;
              }
              if (_this2.entitySummaries) {
                _this2.filter.vendorId = null;
                _this2.filter.vendorId = _this2.entitySummaries.vendorId;
              }
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('', _t);
            case 4:
              _this2.$hideSpinner();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    changeVendorDetail: function changeVendorDetail(value) {
      this.entitySummaries.vendorName = value.name;
      this.entitySummaries.vendorId = value.id;
      this.entitySummaries.vendorAbn = value.abn;
      this.entitySummaries.returnPartsItem = [];
      this.activeReturnPartItems = [];
      this.filter.isReceiptDate = value.isReceiptDate;
      this.filter.receiptDate = value.receiptDate;
      this.filter.vendorId = value.id === null ? _components_Guid__WEBPACK_IMPORTED_MODULE_15__["default"].empty() : value.id;
    },
    changeEntity: function changeEntity(value) {
      this.entitySummaries.vendorAbn = value.abn;
      this.entitySummaries.returnDate = value.date;
    },
    filterList: function filterList(value) {
      var _this3 = this;
      if (value) {
        var date = new Date(new Date(this.filter.receiptDate).getFullYear(), new Date(this.filter.receiptDate).getMonth(), new Date(this.filter.receiptDate).getDate()).toISOString();
        if (!this.filter.isReceiptDate) {
          this.activeReturnPartItems = this.entitySummaries.returnPartsItem;
          this.entitySummaries.returnPartsItem = this.activeReturnPartItems.filter(function (i) {
            return i.poNumber.toLowerCase().includes(_this3.filter.poNo.toLowerCase()) && i.quoteNo.toLowerCase().includes(_this3.filter.quoteNo.toLowerCase()) && new Date(i.recDate).toISOString() >= date;
          });
        } else {
          this.activeReturnPartItems = this.entitySummaries.returnPartsItem;
          this.entitySummaries.returnPartsItem = this.activeReturnPartItems.filter(function (a) {
            return a.poNumber.toLowerCase().includes(_this3.filter.poNo.toLowerCase()) && a.quoteNo.toLowerCase().includes(_this3.filter.quoteNo.toLowerCase());
          });
        }
      }
    },
    resetList: function resetList() {
      this.filter.isReceiptDate = true;
      this.filter.receiptDate = new Date();
      this.filter.poNo = '';
      this.filter.quoteNo = '';
      this.entitySummaries.returnPartsItem = this.activeReturnPartItems;
    },
    save: function save(isDelete) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var title, check, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              title = 'Return Parts';
              check = _this4.isCheck();
              if (check) {
                _context3.n = 1;
                break;
              }
              _this4.$notification.openNotificationWithType('danger', title, 'Validation errors. Returning quantity is greater than Received quantity');
              return _context3.a(2, false);
            case 1:
              if (!(_this4.entitySummaries.returnPartsItem.filter(function (i) {
                return i.returning === 0;
              }).length > 0)) {
                _context3.n = 2;
                break;
              }
              _this4.$notification.openNotificationWithType('danger', title, 'Validation errors. Returning quantity cannot be zero');
              return _context3.a(2, false);
            case 2:
              if (_this4.$v.entitySummaries.vendorAbn.validAbn) {
                _context3.n = 3;
                break;
              }
              _this4.$notification.openNotificationWithType('danger', title, 'Validation errors. ABN is Invalid');
              return _context3.a(2, false);
            case 3:
              _context3.p = 3;
              _this4.$showSpinner('Saving...');
              _this4.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this4.entitySummaries));
              if (!_this4.entitySummaries.isNew) {
                _context3.n = 5;
                break;
              }
              _context3.n = 4;
              return _ReturnPartsService__WEBPACK_IMPORTED_MODULE_28__["default"].postEntity(_this4.entitySummaries);
            case 4:
              response = _context3.v;
              _context3.n = 8;
              break;
            case 5:
              if (!_this4.snapshotDiff) {
                _context3.n = 7;
                break;
              }
              _context3.n = 6;
              return _ReturnPartsService__WEBPACK_IMPORTED_MODULE_28__["default"].putReturnParts(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(_this4.entitySummaries), _this4.snapshotDiff);
            case 6:
              response = _context3.v;
              _context3.n = 8;
              break;
            case 7:
              _this4.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 8:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].NO_CONTENT)) {
                _context3.n = 12;
                break;
              }
              if (!isDelete) {
                _context3.n = 9;
                break;
              }
              _this4.$notification.openNotificationWithType('success', title, isDelete ? 'Return Part deleted' : 'Save successful');
              _this4.$router.push({
                name: _route_types__WEBPACK_IMPORTED_MODULE_20__["default"].ReturnPartsListView.name
              });
              _context3.n = 11;
              break;
            case 9:
              _context3.n = 10;
              return _this4.getEntity(true);
            case 10:
              _this4.filter.vendorId = _this4.entitySummaries.vendorId;
              _this4.$notification.openNotificationWithType('success', title, isDelete ? 'Return Part deleted' : 'Save successful');
            case 11:
              _context3.n = 14;
              break;
            case 12:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].CREATED)) {
                _context3.n = 14;
                break;
              }
              _context3.n = 13;
              return _this4.getEntity(true);
            case 13:
              _this4.filter.vendorId = _this4.entitySummaries.vendorId;
              _this4.isSave = true;
              _this4.readOnly = true;
              _this4.$notification.openNotificationWithType('success', title, 'Save successful');
            case 14:
              _this4.$hideSpinner();
              _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 15:
              _context3.p = 15;
              _t2 = _context3.v;
              _this4.$hideSpinner();
              if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_23__["default"].CONFLICT) {
                _this4.isSaveConflictModalActive = true;
              } else {
                _this4.$notification.openMessageXhrError('Return Parts', _t2);
              }
              return _context3.a(2, false);
          }
        }, _callee3, null, [[3, 15]]);
      }))();
    },
    isCheck: function isCheck() {
      for (var index = 0; index < this.entitySummaries.returnPartsItem.length; index++) {
        var isNew = this.entitySummaries.returnPartsItem[index].isNewLine;
        var currReturn = this.entitySummaries.returnPartsItem[index].return;
        var returning = this.entitySummaries.returnPartsItem[index].returning;
        var returned = this.entitySummaries.returnPartsItem[index].returned;
        var received = this.entitySummaries.returnPartsItem[index].rced;
        // const totalReturn = this.entitySummaries.returnPartsItem[index].rced - this.entitySummaries.returnPartsItem[index].returned
        // const totalReturned = return1 + returned
        if (received === returned) {
          if (returning > currReturn) {
            return false;
          }
        }
        if (received !== returned) {
          if (currReturn === returned) {
            if (returning > received) {
              return false;
            }
          } else {
            if (returning + returned > received && isNew || returned - currReturn + returning > received && !isNew) {
              return false;
            }
          }
        }
      }
      return true;
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      this.isConfirmModalActive = false;
      if (confirmDelete) {
        this.entitySummaries.deleted = true;
        // save snapshots immediately not waiting for debounce
        this.save(true);
      }
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(this.entitySummaries));
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        this.isUnsavedModalActive = true;
      } else {
        if (this.returnUrl) {
          this.clearSessionStorage();
          this.clearSnapshots(this.entitySummaries.creditReturnMainId);
          window.location.href = "".concat("").concat(this.returnUrl);
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_32___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_20__["default"].ReturnPartsListView.name
          });
        }
      }
    },
    print: function print() {
      var params = {
        REPORTTITLE: 'Credit Return',
        CompanyID: this.$userInfo.companyId,
        CREDITNO: this.entitySummaries.prefix + this.entitySummaries.creditNo,
        VendorID: this.entitySummaries.vendorId
      };

      // Create KeyValuePairs and add to vuex for later retrieval by PrintPreviewEx component
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_29__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var parameterId = this.$guid.newGuid();
      _store_utils__WEBPACK_IMPORTED_MODULE_31__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_30__["Emailer"]();
      // emailer.assetId = this.entitySummaries.creditReturnMainId
      emailer.subject = 'Credit Return';
      emailer.reportName = 'AT_CREDITRETURN';
      this.addEmailer(emailer);
      _store_utils__WEBPACK_IMPORTED_MODULE_31__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_27__["default"].PrintPreview.name,
        params: {
          reportName: 'AT_CREDITRETURN'
        },
        query: {
          parameterId: parameterId,
          emailerId: emailer.id
        }
      });
      // const routeData = this.$router.resolve({
      //   name: PrintPreviewRoutes.PrintPreview.name,
      //   params: { reportName: 'AT_CREDITRETURN' },
      //   query: { parameterId: parameterId, emailerId: emailer.id, isNewTab: true }
      // })
      // window.open(routeData.href, '_blank')
      this.$hideSpinner();
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this5.isUnsavedModalActive = false;
              _this5.isSkipSave = false;
              _this5.isSaveContinue = true;
              _context4.n = 1;
              return _this5.save(false);
            case 1:
              _this5.isSaveContinue = _context4.v;
              if (_this5.isSaveContinue) {
                _this5.cancel();
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entitySummaries.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
    },
    reloadData: function reloadData() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this6.isSaveConflictModalActive = false;
              _this6.isSaveContinue = false;
              _context5.n = 1;
              return _this6.getEntity(true);
            case 1:
              _this6.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntityReload);
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|returnparts|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|returnparts|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickinvoice|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickinvoice|type"), this.type);
      }
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_20__["default"].ReturnPartsDetail.name,
        params: {
          invoiceId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_26___default()(this.entitySummaries));
    if (this.snapshotDiff && this.isSkipSave && this.isSaveContinue) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entitySummaries.creditReturnMainId);
      this.clearSessionStorage();
      this.clearRouteMeta();
      if (to.name !== _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_27__["default"].PrintPreview.name) {
        this.setReturnRoute({});
      }
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "subtitle"
  }, _vm._l(_vm.totals, function (value, index) {
    return _c("span", {
      key: index
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.shows[index],
        expression: "shows[index]"
      }]
    }, [_vm._v(" " + _vm._s(_vm.labels[index]) + ": "), _c("span", {
      class: [value >= 0 ? "has-text-success" : "has-text-danger"]
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(value, _vm.$userInfo.locale)))])]), _c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: index < _vm.totals.length - 1 && _vm.shows[index + 1],
        expression: "index < totals.length - 1 && shows[index + 1]"
      }]
    }, [_vm._v(",")])]);
  }), 0);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_vm.innerValue ? _c("subtitle-totals", {
    staticClass: "title is-6",
    attrs: {
      labels: ["".concat(_vm.innerValue.prefix).concat(_vm.innerValue.creditNo, " - Return Total"), "GST"],
      totals: [_vm.returnTotalAmount, _vm.gstAmount],
      shows: [true, true]
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-pulled-right"
  }, [_c("p", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button is-primary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Add return part item"
    },
    on: {
      click: function click($event) {
        return _vm.toggleReturnPartItemList();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi",
    class: {
      "mdi-plus": !_vm.isReturnPartItemListActive,
      "mdi-minus": _vm.isReturnPartItemListActive
    }
  })]), _c("span", [_vm._v(_vm._s(_vm.isReturnPartItemListActive ? "Close" : "Add"))])])])])])]), _vm.innerValue !== null ? _c("return-parts-item-list", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isReturnPartItemListActive,
      expression: "isReturnPartItemListActive"
    }],
    attrs: {
      "is-return-part-list": _vm.isReturnPartItemListActive,
      "vendor-filter": _vm.vendorFilter
    },
    on: {
      calculateTotal: function calculateTotal($event) {
        return _vm.calculateTotalLoad();
      }
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }) : _vm._e(), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isReturnPartItemListActive,
      expression: "isReturnPartItemListActive"
    }],
    staticClass: "is-divider"
  }), _c("div", {
    staticStyle: {
      "overflow-y": "auto",
      height: "400px"
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "total-rows": !_vm.innerValue ? 0 : _vm.innerValue.returnPartsItem.length,
      "show-pagination": false
    }
  }, [_vm._l(_vm.innerValue.returnPartsItem, function (item, index) {
    return _c("tr", {
      key: item.returnPartsID,
      class: {
        "is-selected": _vm.selectedRow === index
      }
    }, [_c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.poNumber))])]), _c("td", [_c("div", {
      staticClass: "has-text-left"
    }, [_vm._v(_vm._s(item.invoiceNo))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(item.recDate, _vm.$userInfo.locale)))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.model))])]), _c("td", {
      attrs: {
        width: "5%"
      }
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        minus: false,
        placeholder: "Qty",
        min: 0,
        disabled: true
      },
      model: {
        value: item.rced,
        callback: function callback($$v) {
          _vm.$set(item, "rced", _vm._n($$v));
        },
        expression: "item.rced"
      }
    })], 1), _c("td", {
      attrs: {
        width: "5%"
      }
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        minus: false,
        placeholder: "Qty",
        min: 0,
        disabled: true
      },
      model: {
        value: item.returned,
        callback: function callback($$v) {
          _vm.$set(item, "returned", _vm._n($$v));
        },
        expression: "item.returned"
      }
    })], 1), _c("td", {
      attrs: {
        width: "5%"
      }
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        minus: false,
        placeholder: "Qty",
        min: 0,
        disabled: _vm.readOnly
      },
      on: {
        blur: function blur($event) {
          return _vm.calculateTotal(item, index);
        }
      },
      model: {
        value: item.returning,
        callback: function callback($$v) {
          _vm.$set(item, "returning", _vm._n($$v));
        },
        expression: "item.returning"
      }
    })], 1), _c("td", {
      attrs: {
        width: "12%"
      }
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        minus: false,
        placeholder: "Amount Required",
        min: 0.0,
        precision: 2,
        disabled: !item.isNewLine
      },
      on: {
        blur: function blur($event) {
          return _vm.calculateTotal(item, index);
        }
      },
      model: {
        value: item.totalAmount,
        callback: function callback($$v) {
          _vm.$set(item, "totalAmount", _vm._n($$v));
        },
        expression: "item.totalAmount"
      }
    })], 1), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.partNo,
        expression: "item.partNo"
      }],
      staticClass: "input",
      attrs: {
        disabled: _vm.readOnly,
        type: "text",
        placeholder: "Part No."
      },
      domProps: {
        value: item.partNo
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "partNo", $event.target.value);
        }
      }
    })])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.script,
        expression: "item.script"
      }],
      staticClass: "input",
      attrs: {
        disabled: !item.isNewLine,
        type: "text",
        placeholder: "Description"
      },
      domProps: {
        value: item.script
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "script", $event.target.value);
        }
      }
    })])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.quoteNo))])]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("a", {
      staticClass: "button is-danger is-small is-inverted",
      attrs: {
        disabled: !item.isNewLine
      },
      on: {
        click: function click($event) {
          return _vm.deleteItem(item, index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])], 2)], 1)], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369 ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Return No. " + _vm._s(_vm.returnDetail.number) + " ")])]), _c("div", [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column field"
  }, [_vm._m(0), _c("div", {
    staticClass: "control has-icons-right"
  }, [_vm.$company.info.countryCode === "AU" ? _c("the-mask", {
    ref: "abn",
    staticClass: "input abn",
    class: {
      "is-static": _vm.vendorId === "",
      "is-danger": _vm.$v.entitySummaries.vendorAbn.$error
    },
    attrs: {
      id: "abn",
      name: "abn",
      disabled: _vm.readOnly,
      placeholder: "Vendor ABN",
      mask: ["## ### ### ###"]
    },
    on: {
      change: function change($event) {
        return _vm.changeValue();
      }
    },
    model: {
      value: _vm.returnDetail.abn,
      callback: function callback($$v) {
        _vm.$set(_vm.returnDetail, "abn", $$v);
      },
      expression: "returnDetail.abn"
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.returnDetail.abn,
      expression: "returnDetail.abn"
    }],
    ref: "abn",
    staticClass: "input is-uppercase",
    attrs: {
      id: "abn",
      maxlength: "12"
    },
    domProps: {
      value: _vm.returnDetail.abn
    },
    on: {
      change: function change($event) {
        return _vm.changeValue();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.returnDetail, "abn", $event.target.value);
      }
    }
  }), !_vm.$v.entitySummaries.vendorAbn.$error && _vm.$v.entitySummaries.vendorAbn.validAbn && _vm.$v.entitySummaries.vendorAbn.minLength && _vm.$v.entitySummaries.vendorAbn.required && _vm.$company.info.countryCode === "AU" ? _c("span", {
    staticClass: "icon has-text-success is-right"
  }, [_c("i", {
    staticClass: "mdi mdi-check mdi-18px"
  })]) : _vm._e(), _vm.returnDetail.abn === "" && _vm.$company.info.isWithHold ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v(" This vendor does not have an ABN. You will be required to with hold " + _vm._s(_vm.$userInfo.withHoldingTax) + "% of the invoice. ")]) : _vm.$v.entitySummaries && !_vm.$v.entitySummaries.vendorAbn.validAbn ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ABN is invalid.")]) : _vm._e(), _vm.$v.entitySummaries && !_vm.$v.entitySummaries.vendorAbn.minLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("ABN must be at least " + _vm._s(_vm.$v.entitySummaries.vendorAbn.$params.minLength.min) + " letters.")]) : _vm._e()], 1)]), _c("div", {
    staticClass: "column field"
  }, [_c("div", {
    staticClass: "control"
  }, [_vm._m(1), _c("div", {
    staticClass: "field is-narrow is-pulled-left"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: function input($event) {
        _vm.returnDetail.date = _vm.$filters.fromISOWithCurrentTime($event.toISOString());
      }
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_vm.returnDetail.id === "" || _vm.readOnly ? _c("input", {
          staticClass: "input",
          class: {
            "is-danger": _vm.$v.entitySummaries.returnDate.$invalid
          },
          attrs: {
            type: "text",
            readonly: "",
            disabled: true,
            placeholder: "Select Credit Date"
          },
          domProps: {
            value: _vm.$filters.formatDateTimezone(_vm.returnDetail.date, _vm.$userInfo.locale)
          }
        }) : _c("input", _vm._g({
          staticClass: "input",
          class: {
            "is-danger": _vm.$v.entitySummaries.returnDate.$invalid
          },
          attrs: {
            type: "text",
            readonly: "",
            placeholder: "Select Credit Date"
          },
          domProps: {
            value: inputValue
          },
          on: {
            input: function input($event) {
              return _vm.changeValue();
            }
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })]), !_vm.$v.entitySummaries.returnDate.required ? _c("span", {
          staticClass: "help is-danger"
        }, [_vm._v("Return Date is required. ")]) : _vm._e()])])];
      }
    }]),
    model: {
      value: _vm.returnDetail.date,
      callback: function callback($$v) {
        _vm.$set(_vm.returnDetail, "date", $$v);
      },
      expression: "returnDetail.date"
    }
  })], 1)])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vendor ABN")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is"
  }, [_vm._v("Return Date")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left has-icons-right"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.filter.query,
      expression: "filter.query"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Start typing to filter"
    },
    domProps: {
      value: _vm.filter.query
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.filter, "query", $event.target.value);
      }, _vm.search]
    }
  }), _vm._m(0)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined",
    on: {
      click: function click($event) {
        return _vm.reset();
      }
    }
  }, [_vm._m(1)])])]), _vm._m(2), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      "popover-visibility": "false",
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": {
        timeAdjust: "00:00:00"
      },
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Date To..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.receiptDate,
      callback: function callback($$v) {
        _vm.receiptDate = $$v;
      },
      expression: "receiptDate"
    }
  })], 1)])])]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-pagination": true
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.returnPartsItems, function (item, index) {
    return _c("tr", {
      key: index,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        dblclick: function dblclick($event) {
          _vm.isAddItem(item, index) ? _vm.addNewItem(item, index) : "";
        }
      }
    }, [_c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.poNumber))])]), _c("td", [_c("div", {
      staticClass: "has-text-left"
    }, [_vm._v(_vm._s(item.invoiceNo))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(item.recDate, _vm.$userInfo.locale)))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.model))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.rced))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.returned))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(" " + _vm._s(item.returning) + " ")])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.totalAmount, _vm.$userInfo.locale)))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.partNo))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.script))])]), _c("td", [_c("div", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.quoteNo))])]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm.isAddItem(item, index) ? _c("div", {
      staticClass: "has-text-centered"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Click or double-click row to add item"
      },
      on: {
        click: function click($event) {
          return _vm.addNewItem(item, index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-plus mdi-24px"
    })])])]) : _c("div", {
      staticClass: "is-flex is-justify-content-center"
    }, [_c("span", {
      staticClass: "icon is-small has-text-grey"
    }, [_c("i", {
      staticClass: "mdi mdi-plus mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])], 2)], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "is-flex is-align-items-center mr-2"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("From Receipt Date")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", [_c("div", {
    staticClass: "columns is-gapless"
  }, [_vm._m(0), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("div", {
    staticClass: "is-pulled-right"
  }, [_c("a", {
    staticClass: "button is-small is-success tooltip",
    attrs: {
      "data-tooltip": "Add Remarks"
    },
    on: {
      click: function click($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Remarks")])])])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.printedFilter.pageIndex,
      "page-size": _vm.printedFilter.pageSize,
      "total-rows": _vm.printedRemarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.printedFilter.sortColumn,
      "sort-order": _vm.printedFilter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPrintedRemarksPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedPrintedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "is-remark"
    }, [_c("div", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.editPrintedRemarkRowNumber === -1 || _vm.editPrintedRemarkRowNumber !== index,
        expression: "editPrintedRemarkRowNumber === -1 || editPrintedRemarkRowNumber !== index"
      }]
    }, [_vm._v(_vm._s(remark.remarks))]), _vm.editPrintedRemarkRowNumber === index ? _c("textarea", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: remark.remarks,
        expression: "remark.remarks"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted"
      }],
      staticClass: "textarea",
      attrs: {
        rows: "3"
      },
      domProps: {
        value: remark.remarks
      },
      on: {
        blur: function blur($event) {
          _vm.editPrintedRemarkRowNumber = -1;
        },
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(remark, "remarks", $event.target.value);
        }
      }
    }) : _vm._e()]), _c("td", {
      staticClass: "has-text-centered is-content-width has-vertical-middle"
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.editPrintedRemark(index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [_vm.editPrintedRemarkRowNumber !== index ? "mdi-lead-pencil" : "mdi-check"]
    })])]), _c("a", {
      staticClass: "button is-danger is-small is-inverted",
      on: {
        click: function click($event) {
          return _vm.deleteRemark(index, remark.remarkId, remark.remarkTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered remark-height"
  }, [_c("span", {
    attrs: {
      icon: "icon is-medium"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-20px mdi-dots-horizontal mdi-inactive-color mdi-inactive"
  })])])])])], 2), _vm.isRemarkModalActive ? _c("remark-modal", {
    attrs: {
      "show-remark": true,
      "show-printed-remark": true,
      "show-recurring-remark": true,
      active: _vm.isRemarkModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRemarkModalActive = $event;
      },
      add: _vm.addRemarks,
      cancel: function cancel($event) {
        return _vm.toggleRemarkModal();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Add Return Parts Remarks")])]) : _vm._e()], 1)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title is-6"
  }, [_vm._v("Printed Remarks")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Select Vendor ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_vm.vendors ? _c("multiselect", {
    attrs: {
      "track-by": "name",
      label: "name",
      disabled: !_vm.isNew,
      "show-labels": false,
      options: _vm.vendors,
      "options-limit": _vm.assetFilter.pageSize,
      loading: _vm.isVendorLoading,
      "internal-search": false,
      searchable: true,
      "allow-empty": false,
      placeholder: "Select a Vendor"
    },
    on: {
      select: _vm.selectVendor,
      remove: _vm.removeVendor,
      "search-change": _vm.getVendorDropdownFilter
    },
    model: {
      value: _vm.selectedVendor,
      callback: function callback($$v) {
        _vm.selectedVendor = $$v;
      },
      expression: "selectedVendor"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Factorer not found.")])]) : _vm._e()], 1)])])]), _c("hr")])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.entitySummaries && _vm.entitySummaries.returnPartsItem.length != 0,
      "show-delete": _vm.entitySummaries && !_vm.entitySummaries.deleted && !_vm.entitySummaries.isNew && _vm.entitySummaries.returnPartsItem.length != 0,
      "show-save": !_vm.isSave && _vm.entitySummaries && _vm.entitySummaries.returnPartsItem.length != 0
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entitySummaries ? _c("return-parts-side-menu", {
    attrs: {
      "is-new": _vm.entitySummaries.isNew
    },
    on: {
      changedetail: function changedetail($event) {
        return _vm.changeVendorDetail($event);
      },
      filter: function filter($event) {
        return _vm.filterList($event);
      },
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm.entitySummaries ? _c("return-parts-detail", {
    attrs: {
      "vendor-filter": _vm.filter,
      "read-only": _vm.readOnly
    },
    model: {
      value: _vm.entitySummaries,
      callback: function callback($$v) {
        _vm.entitySummaries = $$v;
      },
      expression: "entitySummaries"
    }
  }) : _vm._e()], 1)]), _c("div", {
    staticClass: "tile is-horizontal"
  }, [_c("div", {
    staticClass: "tile is-parent is-5"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm.entitySummaries ? _c("return-parts-detail-value", {
    attrs: {
      "vendor-abn": _vm.entitySummaries.vendorAbn,
      "return-no": _vm.entitySummaries.prefix + _vm.entitySummaries.creditNo,
      "vendor-id": _vm.entitySummaries.vendorId,
      "return-date": _vm.entitySummaries.returnDate,
      "read-only": _vm.readOnly
    },
    on: {
      changevalue: function changevalue($event) {
        return _vm.changeEntity($event);
      }
    }
  }) : _vm._e()], 1)]), _c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm.entitySummaries ? _c("return-parts-remarks", {
    attrs: {
      "read-only": _vm.readOnly
    },
    model: {
      value: _vm.entitySummaries,
      callback: function callback($$v) {
        _vm.entitySummaries = $$v;
      },
      expression: "entitySummaries"
    }
  }) : _vm._e()], 1)])])])]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])]), _vm.entitySummaries ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Return Part")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Return Part No: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entitySummaries.prefix).concat(_vm.entitySummaries.creditNo)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".remark-height[data-v-5233fbbc] {\n  height: 1px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3dfdc7f8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue":
/*!**********************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubtitleTotals.vue?vue&type=template&id=25fd27af */ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af");
/* harmony import */ var _SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SubtitleTotals.vue?vue&type=script&lang=js */ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/SubtitleTotals/SubtitleTotals.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SubtitleTotals.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af":
/*!****************************************************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SubtitleTotals.vue?vue&type=template&id=25fd27af */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/SubtitleTotals/index.js":
/*!************************************************!*\
  !*** ./src/components/SubtitleTotals/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SubtitleTotals__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubtitleTotals */ "./src/components/SubtitleTotals/SubtitleTotals.vue");

/* harmony default export */ __webpack_exports__["default"] = (_SubtitleTotals__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetail.vue":
/*!*****************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetail.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsDetail.vue?vue&type=template&id=3c081ad0 */ "./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0");
/* harmony import */ var _ReturnPartsDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsDetail.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReturnPartsDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0":
/*!***********************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0 ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsDetail.vue?vue&type=template&id=3c081ad0 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetail.vue?vue&type=template&id=3c081ad0");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetail_vue_vue_type_template_id_3c081ad0__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetailValue.vue":
/*!**********************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetailValue.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsDetailValue.vue?vue&type=template&id=05200369 */ "./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369");
/* harmony import */ var _ReturnPartsDetailValue_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsDetailValue.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReturnPartsDetailValue_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsDetailValue.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetailValue_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsDetailValue.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetailValue_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369":
/*!****************************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369 ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsDetailValue.vue?vue&type=template&id=05200369 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsDetailValue.vue?vue&type=template&id=05200369");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsDetailValue_vue_vue_type_template_id_05200369__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/ReturnPartsItemList.vue":
/*!*******************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsItemList.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsItemList.vue?vue&type=template&id=30452e50 */ "./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50");
/* harmony import */ var _ReturnPartsItemList_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsItemList.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReturnPartsItemList_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsItemList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsItemList_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsItemList.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsItemList_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50":
/*!*************************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50 ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsItemList.vue?vue&type=template&id=30452e50 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsItemList.vue?vue&type=template&id=30452e50");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsItemList_vue_vue_type_template_id_30452e50__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/ReturnPartsRemarks.vue":
/*!******************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsRemarks.vue ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true */ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true");
/* harmony import */ var _ReturnPartsRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsRemarks.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true */ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ReturnPartsRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5233fbbc",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsRemarks.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js":
/*!******************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsRemarks.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true":
/*!***************************************************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=style&index=0&id=5233fbbc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_style_index_0_id_5233fbbc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true":
/*!************************************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsRemarks.vue?vue&type=template&id=5233fbbc&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsRemarks_vue_vue_type_template_id_5233fbbc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/ReturnPartsSideMenu.vue":
/*!*******************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsSideMenu.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsSideMenu.vue?vue&type=template&id=77493946 */ "./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946");
/* harmony import */ var _ReturnPartsSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsSideMenu.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReturnPartsSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946":
/*!*************************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946 ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsSideMenu.vue?vue&type=template&id=77493946 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsSideMenu.vue?vue&type=template&id=77493946");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsSideMenu_vue_vue_type_template_id_77493946__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/ReturnPartsValidation.js":
/*!********************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsValidation.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/store */ "./src/store/index.js");



var countryCode = function countryCode() {
  var company = _store__WEBPACK_IMPORTED_MODULE_2__["default"].getters['company/company'];
  return company.info.countryCode;
};
var shouldValidateAbn = function shouldValidateAbn() {
  if (countryCode() === 'AU') {
    return true;
  } else {
    return false;
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entitySummaries.vendorAbn', 'entitySummaries.returnDate'],
    entitySummaries: {
      vendorAbn: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        minLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["minLength"])(Object(_components_validators__WEBPACK_IMPORTED_MODULE_1__["abnMinLength"])(countryCode())),
        validAbn: function validAbn(value) {
          if (shouldValidateAbn()) {
            return Object(_components_validators__WEBPACK_IMPORTED_MODULE_1__["abnValidator"])(value);
          } else {
            return true;
          }
        }
      },
      returnDate: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsView.vue":
/*!***************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsView.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReturnPartsView.vue?vue&type=template&id=b9b3eaa8 */ "./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8");
/* harmony import */ var _ReturnPartsView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReturnPartsView.vue?vue&type=script&lang=js */ "./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReturnPartsView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/returnparts/ReturnPartsView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8":
/*!*********************************************************************************!*\
  !*** ./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReturnPartsView.vue?vue&type=template&id=b9b3eaa8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/returnparts/ReturnPartsView.vue?vue&type=template&id=b9b3eaa8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReturnPartsView_vue_vue_type_template_id_b9b3eaa8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/returnparts/columns.js":
/*!******************************************!*\
  !*** ./src/views/returnparts/columns.js ***!
  \******************************************/
/*! exports provided: Columns, ReturnPartsDetail, RemarkColumns, ReturnPartsItems */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReturnPartsDetail", function() { return ReturnPartsDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RemarkColumns", function() { return RemarkColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReturnPartsItems", function() { return ReturnPartsItems; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Return No.', 'returnNoRef', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Return Date', 'returnDate', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Vendor', 'vendorName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Order No.', 'purchaseOrderNoRef', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No.', 'quoteNoRef', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var ReturnPartsDetail = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('PO No.', 'poNumber', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Inv No.', 'invoiceNo', false, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Inv Date', 'recDate', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Model', 'model', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Recd', 'rced', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Retd', 'return', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Returning', 'returning', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Incl. GST', 'totalAmount', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Part No.', 'partNo', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Item Desc', 'script', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No', 'quoteNo', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'asc', 'centered')];
var ReturnPartsItems = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('PO No.', 'poNumber', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Inv No.', 'invoiceNo', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Inv Date', 'recDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Model', 'model', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Recd', 'rced', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Retd', 'return', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Returning', 'returning', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Incl. GST', 'totalAmount', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Part No.', 'partNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Item Desc', 'script', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'asc', 'centered')];
var RemarkColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Created', 'remarkDateTime', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Remark', 'remarks', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'asc', 'centered')];


/***/ }),

/***/ "./src/views/returnparts/storeMixin.js":
/*!*********************************************!*\
  !*** ./src/views/returnparts/storeMixin.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'returnparts';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    readOnlyView: 'readOnlyView'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute', 'setReadOnlyView'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('returnparts', {
    setReturnPartsReturnRoute: 'setReturnRoute',
    setReturnPartsReadOnlyView: 'setReadOnlyView'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=returnparts-chunk.js.map