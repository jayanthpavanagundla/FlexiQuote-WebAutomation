(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ormmessagelist-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    value: null
  },
  data: function data() {
    return {};
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _OrmMessageListSideMenu__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./OrmMessageListSideMenu */ "./src/views/ormmessage/OrmMessageListSideMenu.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./route-types */ "./src/views/ormmessage/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./OrmMessageService */ "./src/views/ormmessage/OrmMessageService.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./columns */ "./src/views/ormmessage/columns.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./storeMixin */ "./src/views/ormmessage/storeMixin.js");
/* harmony import */ var _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/LoadQuoteSteps */ "./src/components/LoadQuoteSteps/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _OrmMessageValidation__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./OrmMessageValidation */ "./src/views/ormmessage/OrmMessageValidation.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _components_NavService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/NavService */ "./src/components/NavService.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");






































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_16__["default"],
    OrmMessageListSideMenu: _OrmMessageListSideMenu__WEBPACK_IMPORTED_MODULE_18__["default"],
    LoadQuoteModal: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["LoadQuoteModal"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_20__["default"],
    LoadQuoteSteps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["LoadQuoteSteps"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__["ConfirmModal"]
  },
  mixins: [_OrmMessageValidation__WEBPACK_IMPORTED_MODULE_28__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_23__["DateTimeFiltersMixin"], _storeMixin__WEBPACK_IMPORTED_MODULE_24__["default"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      // quoteEntity: null,
      isTableLoading: false,
      isEarlierMessageModalActive: false,
      minimalMessageNoIndex: 0,
      entitySummaries: {},
      countSummaries: null,
      totalRows: 0,
      filter: {
        quoteNo: '',
        rego: '',
        claimNo: '',
        messageTypeId: 0,
        messageStatusId: _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_22__["Columns"].length - 2].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_22__["Columns"].length - 2].defaultOrder,
        pageIndex: 1,
        pageSize: 18,
        customerNameOrContactNo: ''
      },
      selectedRow: null,
      isLoadQuoteModalActive: false,
      currentStep: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].CreateAssign.id,
      loadOptions: {
        messageId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        messageTypeId: _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote,
        quoteId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        insurerId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        isCreateQuote: true,
        customerId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        originalCustomerId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        customerOption: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["CustomerOptionTypes"].Create,
        title: '',
        customerName: '',
        firstname: '',
        lastname: '',
        isPerson: false,
        regoNo: '',
        claimNo: '',
        vehicleId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        isOverwriteVehicle: false,
        isOverwriteOrmMessageNo: false
      },
      vehicleExists: false,
      steps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"],
      isConfirmModalActive: false,
      isOrmMessageNoModalActive: false,
      isMessageOperationConfirmModalActive: false,
      messageOperationTypeId: '',
      quoteNo: '',
      quoteId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
      expectedOrmMessageNo: 0,
      selectedMessage: null,
      savedLoadOptions: null,
      autoSyncStatus: 0,
      unreadOffset: 'has-badge-child-offset2',
      readOffset: 'has-badge-child-offset2',
      toSendOffset: 'has-badge-child-offset2',
      sentOffset: 'has-badge-child-offset2',
      deletedOffset: 'has-badge-child-offset2',
      syncFailedOffset: 'has-badge-child-offset2',
      syncedOffset: 'has-badge-child-offset2'
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"];
    },
    returnRoute: function returnRoute() {
      return sessionStorage.getItem("".concat(this.$userInfo.sessionId, "|ormmessage|returnUrl"));
    },
    hasReturnRoute: function hasReturnRoute() {
      return this.returnRoute !== null && this.returnRoute !== undefined && this.returnRoute !== '';
    },
    messageStatusTypes: function messageStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"];
    },
    messageTypes: function messageTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"];
    },
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    canEditMessage: function canEditMessage() {
      return this.$user.info.isSupportUser;
    },
    canMarkMessageRead: function canMarkMessageRead() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead;
    },
    canMarkMessageUnread: function canMarkMessageUnread() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read || this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].SyncFailed || this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Synced;
    },
    canDeleteMessage: function canDeleteMessage() {
      // Refs #2213
      return this.filter.messageStatusId !== _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted && this.$user.info.isSupportUser;
    },
    canUndeleteMessage: function canUndeleteMessage() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted && this.$user.info.isSupportUser;
    },
    lastStep: function lastStep() {
      if (this.steps.OverwriteVehicle.enabled) {
        return this.steps.OverwriteVehicle;
      } else {
        return this.steps.UpdateCustomer;
      }
    },
    enableContinue: function enableContinue() {
      return this.lastStep.id === this.currentStep;
    }
  },
  watch: {
    'loadOptions.firstname': function loadOptionsFirstname(newVal, oldVal) {
      this.loadOptions.customerName = "".concat(this.loadOptions.lastname, ", ").concat(this.loadOptions.firstname);
    },
    'loadOptions.lastname': function loadOptionsLastname(newVal, oldVal) {
      this.loadOptions.customerName = "".concat(this.loadOptions.lastname, ", ").concat(this.loadOptions.firstname);
    }
  },
  created: function created() {
    this.getEntitySummaries();
    this.getCountSummaries();
    this.GetAutoSyncStatus();
    // this.quoteEntity = await OrmMessageService.getQuoteEntity('87EEDFF3-1F83-4536-A448-380A8069D275')
    // OrmMessageService.auditTrailTest()
  },
  mounted: function mounted() {},
  methods: {
    cancel: function cancel() {
      if (this.hasReturnRoute) {
        this.$router.push({
          path: this.returnRoute
        });
        sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|ormmessage|returnUrl"));
      }
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getEntitySummaries();
    },
    resetList: function resetList() {
      this.filter.quoteNo = '';
      this.filter.rego = '';
      this.filter.claimNo = '';
      this.filter.messageTypeId = 0;
      this.filter.sortColumn = _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_22__["Columns"].length - 2].name;
      this.filter.sortOrder = _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_22__["Columns"].length - 2].defaultOrder;
      this.filter.pageIndex = 1;
      this.filter.pageSize = 18;
      this.filter.customerNameOrContactNo = '';
      this.persistFilter();
      this.getEntitySummaries();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getEntitySummaries();
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getEntitySummaries();
    },
    tabClicked: function tabClicked(messageSatusId) {
      if (this.filter.messageStatusId !== messageSatusId) {
        this.filter.messageStatusId = messageSatusId;
        this.filter.pageIndex = 1;
        this.selectedRow = null;
        this.persistFilter();
        this.getEntitySummaries();
        this.getCountSummaries();
      }
    },
    getEntitySummaries: function getEntitySummaries() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _this.retrieveFilter();
              _context.n = 1;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    GetAutoSyncStatus: function GetAutoSyncStatus() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var companyExternalSettings;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_31__["CompanyService"].getCompanyExternalSetting('ORM');
            case 1:
              companyExternalSettings = _context2.v;
              _this2.autoSyncStatus = Number(companyExternalSettings.property4);
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getCountSummaries: function getCountSummaries() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].getCountSummaries();
            case 1:
              _this3.countSummaries = _context3.v;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getCount: function getCount(messageStatusId) {
      if (this.countSummaries) {
        var summary = this.countSummaries.find(function (c) {
          return c.statusId === messageStatusId;
        });
        var count = 0;
        if (messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend) {
          var failedSummary = this.countSummaries.find(function (c) {
            return c.statusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Failed;
          });
          count = summary.messageCount + failedSummary.messageCount;
        } else {
          count = summary.messageCount;
        }
        this.setBadgeOffset(messageStatusId, count);
        return count;
      }
    },
    setBadgeOffset: function setBadgeOffset(messageStatusId, count) {
      var offset = 'has-badge-child-offset2';
      if (count >= 10 && count <= 99) {
        offset = 'has-badge-child-offset3';
      } else if (count >= 100 && count <= 999) {
        offset = 'has-badge-child-offset4';
      } else if (count >= 1000 && count <= 9999) {
        offset = 'has-badge-child-offset5';
      } else if (count >= 10000) {
        offset = 'has-badge-child-offset6';
      }
      switch (messageStatusId) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead:
          this.unreadOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read:
          this.readOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend:
          this.toSendOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Sent:
          this.sentOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted:
          this.deletedOffset = offset;
          break;
      }
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    canPrintMessage: function canPrintMessage(messageTypeId) {
      var canPrint = messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_Quote || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_JobCancelled || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentAuthorised || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentDeclined || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_Error;
      return canPrint && this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read;
    },
    canLoadMessage: function canLoadMessage(messageTypeId) {
      var canLoad = messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote && this.autoSyncStatus !== 1 && this.autoSyncStatus !== 2 || messageTypeId !== _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote && this.autoSyncStatus !== 2;
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead && !this.$licenceExpired && canLoad;
    },
    canResendMessage: function canResendMessage(messageStatusId) {
      var canResend = this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Sent || this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend && messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Failed;
      return canResend;
    },
    updateMessageStatus: function updateMessageStatus(messageId, messageStatusId) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              _context4.p = 0;
              _context4.n = 1;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].updateMessageStatus(messageId, messageStatusId);
            case 1:
              _context4.n = 3;
              break;
            case 2:
              _context4.p = 2;
              _t = _context4.v;
              _this4.$notification.openMessageXhrError('ORM Message', _t);
            case 3:
              _this4.getEntitySummaries();
              _this4.getCountSummaries();
            case 4:
              return _context4.a(2);
          }
        }, _callee4, null, [[0, 2]]);
      }))();
    },
    markMessageAsRead: function markMessageAsRead(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read);
    },
    markMessageAsUnread: function markMessageAsUnread(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead);
    },
    markMessageAsToSend: function markMessageAsToSend(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend);
    },
    markMessageAsDeleted: function markMessageAsDeleted(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted);
    },
    unDeleteMessage: function unDeleteMessage(messageId, messageDirection) {
      if (messageDirection === 0) {
        // Incoming messages
        this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read);
      } else {
        // Outgoing messages
        this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Sent);
      }
    },
    addNew: function addNew() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.addStoreItem();
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    print: function print(messageId, messageTypeId) {
      var reportName = '';
      var messageType = Object.keys(_enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"]).find(function (k) {
        return _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"][k] === messageTypeId;
      });
      switch (messageTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote:
          reportName = 'rptOrmQuoteRequest';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_Quote:
          reportName = 'rptOrmAdjust';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_JobCancelled:
          reportName = 'rptOrmJobCancelled';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentDeclined:
          reportName = 'rptOrmPayDecline';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentAuthorised:
          reportName = 'rptOrmPaymentAdvice';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_Error:
          reportName = 'rptOrmErrorMsg';
          break;
      }
      if (reportName) {
        var params = {
          CompanyID: this.$userInfo.companyId,
          MessageID: messageId
        };
        if (reportName == 'rptOrmQuoteRequest') {
          params = {
            CompanyID: this.$userInfo.companyId,
            MessageID: messageId,
            timezoneoffset: this.$filters.getSiteTimezoneOffset()
          };
        }
        var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_35__["KeyValuePairModel"].convertToKeyValuePairs(params);
        var parameterId = this.$guid.newGuid();
        _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
        var emailer = new _classes__WEBPACK_IMPORTED_MODULE_34__["Emailer"]();
        emailer.remark = "ORM ".concat(messageType);
        emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_17__["RemarkTypes"].Remark;
        emailer.subject = "ORM ".concat(messageType);
        emailer.reportName = "ORM_".concat(messageType);
        _store_utils__WEBPACK_IMPORTED_MODULE_33__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
        var routeData = this.$router.resolve({
          name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_36__["default"].PrintPreview.name,
          params: {
            reportName: reportName
          },
          query: {
            parameterId: parameterId,
            emailerId: emailer.id,
            isNewTab: true
          }
        });
        window.open(routeData.href, '_blank');
      }
    },
    previous: function previous() {
      this.currentStep--;
      if (this.currentStep === this.steps.CreateAssign.id) {
        this.$v.loadOptions.quoteId.$reset();
      } else if (this.currentStep === this.steps.SelectInsurer.id) {
        this.$v.loadOptions.insurerId.$reset();
      } else if (this.currentStep === this.steps.UpdateCustomer.id) {
        this.$v.loadOptions.customerId.$reset();
      }
    },
    next: function next() {
      switch (this.currentStep) {
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].CreateAssign.id:
          this.$v.loadOptions.quoteId.$touch();
          if (!this.$v.loadOptions.quoteId.$error || this.loadOptions.isCreateQuote) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].SelectInsurer.id:
          this.$v.loadOptions.insurerId.$touch();
          if (!this.$v.loadOptions.insurerId.$error) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].UpdateCustomer.id:
          this.$v.loadOptions.customerId.$touch();
          if (!this.$v.loadOptions.customerId.$error || this.loadOptions.customerOption === _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["CustomerOptionTypes"].Create) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].OverwriteVehicle.id:
          break;
      }
    },
    closeModal: function closeModal() {
      this.isLoadQuoteModalActive = false;
      this.reset();
    },
    loadMessage: function loadMessage() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var result, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.p = _context6.n) {
            case 0:
              _this6.$showSpinner('Loading quote');
              _context6.p = 1;
              _this6.isLoadQuoteModalActive = false;
              _this6.isOrmMessageNoModalActive = false;
              _context6.n = 2;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].loadMessage(_this6.loadOptions);
            case 2:
              result = _context6.v;
              _this6.quoteId = result.data;
              console.log(_this6.quoteId);
              _this6.getEntitySummaries();
              _this6.getCountSummaries();
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].validGuid(_this6.quoteId)) {
                _context6.n = 4;
                break;
              }
              _context6.n = 3;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].getQuoteNo(_this6.quoteId);
            case 3:
              _this6.quoteNo = _context6.v;
              _this6.print(_this6.loadOptions.messageId, _this6.loadOptions.messageTypeId);
              if (_this6.loadOptions.isCreateQuote && _this6.loadOptions.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote) {
                _this6.createAuditTrail(_this6.quoteId, 'insert', '');
              } else {
                // TODO: create update AuditTrail entry
              }
              _this6.savedLoadOptions = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_this6.loadOptions);
              _this6.isConfirmModalActive = true;
            case 4:
              _context6.n = 6;
              break;
            case 5:
              _context6.p = 5;
              _t2 = _context6.v;
              throw _t2;
            case 6:
              _context6.p = 6;
              _this6.reset();
              _this6.$hideSpinner();
              return _context6.f(6);
            case 7:
              return _context6.a(2);
          }
        }, _callee6, null, [[1, 5, 6, 7]]);
      }))();
    },
    reset: function reset() {
      this.loadOptions.messageId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.loadOptions.messageTypeId = _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote;
      this.loadOptions.quoteId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.loadOptions.isCreateQuote = true;
      this.loadOptions.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.loadOptions.customerOption = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["CustomerOptionTypes"].Create;
      this.loadOptions.isOverwriteVehicle = false;
      this.loadOptions.customerId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.loadOptions.title = '';
      this.loadOptions.customerName = '';
      this.loadOptions.firstname = '';
      this.loadOptions.lastname = '';
      this.loadOptions.isPerson = false;
      this.loadOptions.regoNo = '';
      this.loadOptions.claimNo = '';
      this.loadOptions.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.loadOptions.isOverwriteOrmMessageNo = false;
      this.currentStep = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_25__["Steps"].CreateAssign.id;
      this.selectedMessage = null;
      // Reset validation objects
      this.$v.loadOptions.$reset();
    },
    getEntityWithMinimumMessageNo: function getEntityWithMinimumMessageNo(entities) {
      var entity = entities.reduce(function (prev, current) {
        return prev.ormMessageNo < current.ormMessageNo ? prev : current;
      });
      return entity;
    },
    // get the entity with the minimum message no in the page context
    getMinimumMessageNoEntityIndex: function getMinimumMessageNoEntityIndex() {
      var res = 0;
      for (var i = 0; i < this.entitySummaries.length; i++) {
        if (this.entitySummaries[i].ormMessageNo < this.entitySummaries[res].ormMessageNo) {
          res = i;
        }
      }
      return res;
    },
    getRequestsInSameClaim: function getRequestsInSameClaim() {
      var _this7 = this;
      return this.entitySummaries.filter(function (x) {
        return x.claimNo === _this7.selectedMessage.claimNo && x.regoNo === _this7.selectedMessage.regoNo && x.reinstatementNo === _this7.selectedMessage.reinstatementNo && x.messageId !== _this7.selectedMessage.messageId;
      });
    },
    load: function load(index) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        var requestsInSameClaim, mininumMessage, names;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this8.isEarlierMessageModalActive = false;

              // get message in given index
              // entity summaries is an array
              _this8.selectedMessage = _this8.entitySummaries[index];
              // get a list of requests in the same claim
              requestsInSameClaim = _this8.getRequestsInSameClaim(); // if there are more than one request in the same claim
              // get the entity with the minimum message no
              // and set the selectedMessage to that entity
              if (!(requestsInSameClaim.length > 0)) {
                _context7.n = 1;
                break;
              }
              // get the entity with the minimum message no with same rego and claim number in the page context
              // const minimumMessageNoEntityIndex = this.getMinimumMessageNoEntityIndex()
              mininumMessage = _this8.getEntityWithMinimumMessageNo(requestsInSameClaim); // if current selected message is not the minimum message no entity
              if (!(_this8.selectedMessage.ormMessageNo > mininumMessage.ormMessageNo)) {
                _context7.n = 1;
                break;
              }
              // asign state to the minimum message no entity
              _this8.minimalMessageNoIndex = mininumMessage.rowNumber - 1;
              // open up the confirmation dialog
              _this8.isEarlierMessageModalActive = true;
              return _context7.a(2);
            case 1:
              // Set loadOptions properties based on the selectedMessage's properties
              _this8.loadOptions.messageId = _this8.selectedMessage.messageId;
              _this8.loadOptions.messageTypeId = _this8.selectedMessage.messageTypeId;
              _this8.loadOptions.regoNo = _this8.selectedMessage.regoNo;
              _this8.loadOptions.claimNo = _this8.selectedMessage.claimNo;

              // Check the messageTypeId to determine the next steps

              // If the message type is a request for quote, perform additional actions
              if (_this8.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_RequestForQuote) {
                _this8.assertVehicleExists(_this8.selectedMessage.regoNo);
                _this8.loadOptions.isPerson = _this8.selectedMessage.isPerson;
                _this8.loadOptions.customerName = _this8.selectedMessage.customerName;

                // If the customer is a person, extract the last name, first name, and title from the customerName
                if (_this8.selectedMessage.isPerson) {
                  names = _this8.selectedMessage.customerName.split(', ');
                  _this8.loadOptions.lastname = names[0];
                  _this8.loadOptions.firstname = names.length > 1 ? names[1] : '';
                  _this8.loadOptions.title = _this8.selectedMessage.title;
                }
                _this8.isLoadQuoteModalActive = true;
              } else if (_this8.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentAuthorised || _this8.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_PaymentDeclined || _this8.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_JobCancelled || _this8.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_17__["MessageTypes"].QML_Quote) {
                _this8.loadOptions.quoteNo = _this8.selectedMessage.quoteNo;
                if (_this8.selectedMessage.expectedOrmMessageNo !== _this8.selectedMessage.ormMessageNo) {
                  // Prompt overwrite MessageNo
                  _this8.isOrmMessageNoModalActive = true;
                } else {
                  _this8.loadMessage();
                }
              } else {
                _this8.loadMessage();
              }
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    assertVehicleExists: function assertVehicleExists(rego) {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _context8.n = 1;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].assertVehicleExists(rego);
            case 1:
              _this9.vehicleExists = _context8.v;
              _this9.steps.OverwriteVehicle.enabled = _this9.vehicleExists;
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    gotoQuote: function gotoQuote(goto) {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        var accessModel, url, routeData;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _this0.isConfirmModalActive = false;
              if (!goto) {
                _context9.n = 2;
                break;
              }
              _context9.n = 1;
              return _components_NavService__WEBPACK_IMPORTED_MODULE_30__["default"].getAccess('A077', 'detail');
            case 1:
              accessModel = _context9.v;
              url = '';
              if (accessModel.version === '2') {
                routeData = _this0.$router.resolve({
                  name: _views_quote_route_types__WEBPACK_IMPORTED_MODULE_32__["default"].QuoteHeader.name,
                  params: {
                    quoteId: _this0.quoteId
                  }
                });
                url = routeData.href;
              } else {
                url = "".concat("", "/modules/handlers/QuoteLoading.ashx?quoteId=").concat(_this0.quoteId, "&mode=5");
              }
              window.open(url, '_blank');
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    overwriteOrmMessageNo: function overwriteOrmMessageNo(overwrite) {
      this.loadOptions.isOverwriteOrmMessageNo = overwrite;
      this.isOrmMessageNoModalActive = false;
      if (this.loadOptions.isOverwriteOrmMessageNo) {
        this.loadMessage();
      }
    },
    createAuditTrail: function createAuditTrail(entityId, operationType, deepdiff) {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee0() {
        var quote, audtiTrailItem;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              _context0.n = 1;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].getQuoteEntity(entityId);
            case 1:
              quote = _context0.v;
              audtiTrailItem = {
                auditTrailId: null,
                performedAt: new Date().toISOString,
                userId: _this1.$userInfo.userId,
                userName: _this1.$userInfo.displayName,
                userRole: _this1.$userInfo.isSupportUser ? 'Support' : 'Normal',
                userAgent: '',
                userHostAddress: '',
                userHostName: '',
                url: '',
                companyId: _this1.$userInfo.companyId,
                entityId: entityId,
                entityType: 'Quote',
                entityReference: "".concat(quote.prefix).concat(quote.quoteNo).concat(quote.suffix),
                operationType: operationType,
                deepdiff: operationType === 'update' ? JSON.stringify(deepdiff) : null,
                entity: operationType === 'insert' ? JSON.stringify(quote) : null
              }; // console.log(audtiTrailItem)
              _OrmMessageService__WEBPACK_IMPORTED_MODULE_21__["default"].postAuditTrailItem(audtiTrailItem);
            case 2:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    showMessageActionConfirmModal: function showMessageActionConfirmModal(messageId, messageStatusTypeId) {
      this.messageOperationTypeId = messageStatusTypeId;
      this.selectedMessageId = messageId;
      this.isMessageOperationConfirmModalActive = true;
    },
    changeMessageStatus: function changeMessageStatus(messageId, messageStatusTypeId) {
      switch (messageStatusTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Unread:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].UnRead);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted);
          break;
      }
      this.isMessageOperationConfirmModalActive = false;
    },
    getFolderName: function getFolderName(messageStatusTypeId) {
      switch (messageStatusTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Read:
          return 'Read';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Unread:
          return 'Unread';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].ToSend:
          return 'To Send';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["MessageStatusTypes"].Deleted:
          return 'Deleted';
          break;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    if (to.name === _route_types__WEBPACK_IMPORTED_MODULE_19___default.a.OrmMessageView.name) {
      var messageId = to.params.messageId;
      var message = this.entitySummaries.find(function (m) {
        return m.messageId === messageId;
      });
      this.setMessageSummary(message);
    }
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.rego,
      expression: "value.rego"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Rego"
    },
    domProps: {
      value: _vm.value.rego
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "rego", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.claimNo,
      expression: "value.claimNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Claim No."
    },
    domProps: {
      value: _vm.value.claimNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "claimNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.quoteNo,
      expression: "value.quoteNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Quote No."
    },
    domProps: {
      value: _vm.value.quoteNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "quoteNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.customerNameOrContactNo,
      expression: "value.customerNameOrContactNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Customer Name/Phone"
    },
    domProps: {
      value: _vm.value.customerNameOrContactNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "customerNameOrContactNo", $event.target.value);
      }
    }
  })])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": _vm.hasReturnRoute,
      "show-new": _vm.$userInfo.isSupportUser,
      "show-print": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("orm-message-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "m-3"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "tabs is-toggle is-toggle-rounded"
  }, [_c("ul", [_c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.UnRead
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.UnRead);
      }
    }
  }, [_vm._m(0), _c("span", [_c("span", {
    class: _vm.unreadOffset
  }, [_vm._v("Unread")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.UnRead ? "has-badge-info" : "has-badge-dark"],
    attrs: {
      "data-badge": _vm.getCount(_vm.messageStatusTypes.UnRead)
    }
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Read
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Read);
      }
    }
  }, [_vm._m(1), _c("span", [_c("span", {
    class: _vm.readOffset
  }, [_vm._v("Read")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Read ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Synced
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Synced);
      }
    }
  }, [_vm._m(2), _c("span", [_c("span", {
    class: _vm.syncedOffset
  }, [_vm._v("Synced")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Synced ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.ToSend
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.ToSend);
      }
    }
  }, [_vm._m(3), _c("span", [_c("span", {
    class: _vm.toSendOffset
  }, [_vm._v("To Send")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.ToSend ? "has-badge-info" : "has-badge-dark"],
    attrs: {
      "data-badge": _vm.getCount(_vm.messageStatusTypes.ToSend)
    }
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Sent
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Sent);
      }
    }
  }, [_vm._m(4), _c("span", [_c("span", {
    class: _vm.sentOffset
  }, [_vm._v("Sent")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Sent ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.SyncFailed
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.SyncFailed);
      }
    }
  }, [_vm._m(5), _c("span", [_c("span", {
    class: _vm.syncFailedOffset
  }, [_vm._v("Sync Failed")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.SyncFailed ? "has-badge-info" : "has-badge-dark"],
    attrs: {
      "data-badge": _vm.getCount(_vm.messageStatusTypes.SyncFailed)
    }
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Deleted
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Deleted);
      }
    }
  }, [_vm._m(6), _c("span", [_c("span", {
    class: _vm.deletedOffset
  }, [_vm._v("Deleted")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Deleted ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])])]), _c("div", {
    staticClass: "tags has-addons",
    staticStyle: {
      "margin-left": "auto"
    }
  }, [_c("span", {
    staticClass: "tag is-dark"
  }, [_vm._v("Last fetched")]), !_vm.isTableLoading ? _c("span", {
    staticClass: "tag is-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(new Date(), _vm.$userInfo.locale)))]) : _vm._e()])]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (entity, index) {
    return _c("tr", {
      key: entity.messageId,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm.canEditMessage ? _c("router-link", {
      attrs: {
        to: {
          path: entity.messageId
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(entity.messageType) + " ")]) : _c("span", [_vm._v(_vm._s(entity.messageType))])], 1), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.qdeStatus) + " ")]), _c("td", {
      staticClass: "has-text-centered",
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.ormMessageNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.regoNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.claimNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.claimType) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.customerName) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.mobilePhone) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.uid) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.quoteNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.vehicleDescription) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatDateTimeLocale(_vm.$filters.ensureUTCFormat(entity.createdDate), _vm.$userInfo.locale)) + " ")]), _c("td", {
      staticClass: "is-content-width"
    }, [_c("div", {
      staticClass: "has-text-centered"
    }, [_vm.canEditMessage ? _c("router-link", {
      staticClass: "button is-primary is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        to: {
          path: entity.messageId
        },
        "data-tooltip": "View/Edit XML",
        append: ""
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])]) : _vm._e(), _vm.canLoadMessage(entity.messageTypeId) ? _c("a", {
      staticClass: "button is-success is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Load Message"
      },
      on: {
        click: function click($event) {
          return _vm.load(index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-download mdi-24px"
    })])]) : _vm._e(), _vm.canMarkMessageRead ? _c("a", {
      staticClass: "button is-info is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Mark as Read"
      },
      on: {
        click: function click($event) {
          return _vm.showMessageActionConfirmModal(entity.messageId, _vm.messageStatusTypes.Read);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-email-open mdi-24px"
    })])]) : _vm._e(), _vm.canPrintMessage(entity.messageTypeId) ? _c("a", {
      staticClass: "button is-black is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Print Message"
      },
      on: {
        click: function click($event) {
          return _vm.print(entity.messageId, entity.messageTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-printer mdi-24px"
    })])]) : _vm._e(), _vm.canMarkMessageUnread ? _c("a", {
      staticClass: "button is-info is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Mark as Unread"
      },
      on: {
        click: function click($event) {
          return _vm.markMessageAsUnread(entity.messageId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-email mdi-24px"
    })])]) : _vm._e(), _vm.canResendMessage(entity.statusId) ? _c("a", {
      staticClass: "button is-link is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Resend Message"
      },
      on: {
        click: function click($event) {
          return _vm.markMessageAsToSend(entity.messageId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-send mdi-24px"
    })])]) : _vm._e(), _vm.canDeleteMessage ? _c("a", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Delete Message"
      },
      on: {
        click: function click($event) {
          return _vm.showMessageActionConfirmModal(entity.messageId, _vm.messageStatusTypes.Deleted);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])]) : _vm._e(), _vm.canUndeleteMessage ? _c("a", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": [entity.messageDirection === 0 ? "Restore to Read" : "Restore to Sent"]
      },
      on: {
        click: function click($event) {
          return _vm.unDeleteMessage(entity.messageId, entity.messageDirection);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete-restore mdi-24px"
    })])]) : _vm._e()], 1)])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])]), _c("load-quote-modal", {
    attrs: {
      active: _vm.isLoadQuoteModalActive,
      "show-icon": false,
      "previous-disabled": _vm.currentStep === _vm.steps.CreateAssign.id,
      "next-disabled": _vm.currentStep === _vm.lastStep.id,
      "continue-disabled": !_vm.enableContinue
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isLoadQuoteModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      previous: function previous($event) {
        return _vm.previous();
      },
      next: function next($event) {
        return _vm.next();
      },
      load: function load($event) {
        return _vm.loadMessage();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("ORM Load Quote")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("load-quote-steps", {
    attrs: {
      "current-step": _vm.currentStep,
      steps: _vm.steps,
      "ecom-type": "orm"
    },
    model: {
      value: _vm.loadOptions,
      callback: function callback($$v) {
        _vm.loadOptions = $$v;
      },
      expression: "loadOptions"
    }
  })], 1)]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.gotoQuote(true);
      },
      cancel: function cancel($event) {
        return _vm.gotoQuote(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Go to Quote")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.savedLoadOptions && _vm.savedLoadOptions.isCreateQuote && _vm.savedLoadOptions.messageTypeId === _vm.messageTypes.QML_RequestForQuote ? _c("span", [_vm._v("Quote created")]) : _vm.savedLoadOptions && !_vm.savedLoadOptions.isCreateQuote && _vm.savedLoadOptions.messageTypeId === _vm.messageTypes.QML_RequestForQuote ? _c("span", [_vm._v("Quote assigned")]) : _c("span", [_vm._v("Message loaded")]), _vm._v(" successfully. Go to quote "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.quoteNo)))]), _vm._v(" now? ")])]), _vm.selectedMessage ? _c("confirm-modal", {
    attrs: {
      active: _vm.isOrmMessageNoModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isOrmMessageNoModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.overwriteOrmMessageNo(true);
      },
      cancel: function cancel($event) {
        return _vm.overwriteOrmMessageNo(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("ORM MessageNo Conflict")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("p", [_vm._v(" Received "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v("MessageNo")]), _vm._v(" is different from expected MessageNo ")]), _c("br"), _c("p", {
    staticStyle: {
      "text-indent": "40px"
    }
  }, [_vm._v(" Received: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedMessage.ormMessageNo))])]), _c("p", {
    staticStyle: {
      "text-indent": "40px"
    }
  }, [_vm._v(" Expected: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedMessage.expectedOrmMessageNo))])]), _c("br"), _c("p", [_vm._v(" Load and overwrite MessageNo? ")])])]) : _vm._e(), _c("confirm-modal", {
    attrs: {
      active: _vm.isMessageOperationConfirmModalActive,
      "ok-text": "Yes"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isMessageOperationConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.changeMessageStatus(_vm.selectedMessageId, _vm.messageOperationTypeId);
      },
      cancel: function cancel($event) {
        _vm.isMessageOperationConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("ORM Message")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", [_vm._v("Message will be moved to")]), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(" " + _vm._s(_vm.getFolderName(_vm.messageOperationTypeId)) + ". ")]), _c("br"), _c("span", [_vm._v("Are you sure?")])])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isEarlierMessageModalActive,
      "ok-text": "Procced"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isEarlierMessageModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.load(_vm.minimalMessageNoIndex);
      },
      cancel: function cancel($event) {
        _vm.isEarlierMessageModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Earlier ORM Message Exists")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", [_vm._v("Please load an earlier message type "), _vm.entitySummaries.length ? _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(" " + _vm._s(_vm.entitySummaries[_vm.minimalMessageNoIndex].messageType) + " ")]) : _vm._e()]), _c("br"), _c("br"), _c("span", [_vm._v("Do you want to continue?")])])])], 1) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-email mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-email-open mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-sync mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-send mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-checkbox-marked-circle mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-alert mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.is-uppercase[data-v-5712bcd9] {\n  text-transform: uppercase;\n}\ninput.is-uppercase[data-v-5712bcd9]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-5712bcd9]::-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-5712bcd9]:-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-5712bcd9]:-ms-input-placeholder {\n  text-transform: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("770b710e", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListSideMenu.vue":
/*!*********************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListSideMenu.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true */ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true");
/* harmony import */ var _OrmMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmMessageListSideMenu.vue?vue&type=script&lang=js */ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true */ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5712bcd9",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormmessage/OrmMessageListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true":
/*!******************************************************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=style&index=0&id=5712bcd9&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_style_index_0_id_5712bcd9_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListSideMenu.vue?vue&type=template&id=5712bcd9&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListSideMenu_vue_vue_type_template_id_5712bcd9_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListView.vue":
/*!*****************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListView.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmMessageListView.vue?vue&type=template&id=94c4fbb0 */ "./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0");
/* harmony import */ var _OrmMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmMessageListView.vue?vue&type=script&lang=js */ "./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormmessage/OrmMessageListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0":
/*!***********************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0 ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageListView.vue?vue&type=template&id=94c4fbb0 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageListView.vue?vue&type=template&id=94c4fbb0");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageListView_vue_vue_type_template_id_94c4fbb0__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormmessage/OrmMessageValidation.js":
/*!******************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageValidation.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");


// import { CustomerOptionTypes } from '@/components/LoadQuoteSteps'

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    loadOptions: {
      quoteId: {
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      },
      insurerId: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      },
      invoiceDate: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      customerId: {
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/ormmessage/columns.js":
/*!*****************************************!*\
  !*** ./src/views/ormmessage/columns.js ***!
  \*****************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Type', 'messageType', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('QDE Status', 'qdeStatus', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Message No.', 'ormMessageNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'regoNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim No.', 'claimNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim Type', 'claimType', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Customer', 'customerName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Mobile No.', 'mobilePhone', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('UID', 'uid', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No.', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Vehicle', 'vehicleDescription', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Received Date', 'createdDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];


/***/ }),

/***/ "./src/views/ormmessage/storeMixin.js":
/*!********************************************!*\
  !*** ./src/views/ormmessage/storeMixin.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'ormmessages';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    messageSummary: 'messageSummary'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setMessageSummary', 'clearMessageSummary']))
});

/***/ })

}]);
//# sourceMappingURL=ormmessagelist-chunk.js.map