(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-images-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteImages.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteImages.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_QuoteImageCategory_vue__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./components/QuoteImageCategory.vue */ "./src/views/quote/components/QuoteImageCategory.vue");
/* harmony import */ var _components_QuoteImageCategoryModal_vue__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./components/QuoteImageCategoryModal.vue */ "./src/views/quote/components/QuoteImageCategoryModal.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_VueDropzone__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @/components/VueDropzone */ "./src/components/VueDropzone/index.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! mime-types */ "./node_modules/mime-types/index.js");
/* harmony import */ var mime_types__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(mime_types__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var _services_common__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! @/services/common */ "./src/services/common.js");
/* harmony import */ var _components_utils_helpers__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! @/components/utils/helpers */ "./src/components/utils/helpers.js");
/* harmony import */ var _services_uploadLimits__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! @/services/uploadLimits */ "./src/services/uploadLimits.js");




















































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteImages',
  components: {
    QuoteImageCategoryModal: _components_QuoteImageCategoryModal_vue__WEBPACK_IMPORTED_MODULE_44__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_42__["ConfirmModal"],
    QuoteImageCategory: _components_QuoteImageCategory_vue__WEBPACK_IMPORTED_MODULE_43__["default"],
    QuoteNoSearchModal: _components__WEBPACK_IMPORTED_MODULE_41__["QuoteNoSearchModal"],
    VueDropzone: _components_VueDropzone__WEBPACK_IMPORTED_MODULE_46__["default"]
  },
  props: {
    value: null
  },
  data: function data() {
    return {
      size: 200,
      images: [],
      imageIds: null,
      imagesSelected: null,
      imagesWithInfo: [],
      areThumbnailsLoaded: false,
      isLoadingImages: false,
      addCategoryModalOpen: false,
      imageCategories: null,
      isDeleteAllModalActive: false,
      isCopyImageModalActive: false,
      isDownloadImagesModalActive: false,
      hasSeclectAll: false,
      refreshComponent: true,
      uploadedImage: false,
      selectedCategory: null,
      refreshCategory: false,
      isMoveSelectedImages: false,
      isDropzoneActive: false,
      queuedFileCount: 0,
      dropzoneOptions: {
        url: "".concat("/UniqApi/v1", "/quotes/images/upload/").concat(this.value.quoteId, "/").concat(this.value.prefix).concat(this.value.quoteNo).concat(this.value.suffix, "/").concat(this.value.subQuoteNo, "/").concat(this.selectedCategory),
        dictDefaultMessage: 'Drop files here or click to upload',
        thumbnailWidth: 128,
        thumbnailHeight: 128,
        maxFilesize: 10,
        resizeWidth: 1920,
        resizeHeight: 1920,
        acceptedFiles: 'image/jpeg,image/jpg,image/png,image/gif,image/bmp',
        capture: 'image/',
        //uploadMultiple: false,
        headers: {
          Authorization: ''
        },
        accept: function accept(file, done) {
          var mimeType = file.type;
          if (mimeType !== mime_types__WEBPACK_IMPORTED_MODULE_47___default.a.contentType('jpeg')) {
            this.options.resizeMimeType = mime_types__WEBPACK_IMPORTED_MODULE_47___default.a.contentType('jpeg');
            this.options.resizeQuality = 0.95;
            done();
            return;
          }
          done();
        },
        renameFile: function renameFile(file) {
          var extension = file.name.split('.').pop();
          if (extension !== 'jpg' || extension !== 'jpeg') {
            return "".concat(file.name.substr(0, file.name.lastIndexOf('.')), ".").concat(mime_types__WEBPACK_IMPORTED_MODULE_47___default.a.extension(mime_types__WEBPACK_IMPORTED_MODULE_47___default.a.contentType('jpeg')));
            // return file.name.substr(0, file.name.lastIndexOf('.')) + '.jpg'
          } else {
            return file.name;
          }
        }
      }
    };
  },
  computed: {
    imageCount: function imageCount() {
      return this.imageIds ? this.imageIds.length : 0;
    },
    isMobile: function isMobile() {
      return _components_utils_helpers__WEBPACK_IMPORTED_MODULE_49__["isMobile"];
    },
    hasSelected: function hasSelected() {
      return this.imagesWithInfo.some(function (i) {
        return i.isSelected;
      });
    },
    selectedCount: function selectedCount() {
      return this.imagesWithInfo.reduce(function (total, item) {
        return item.isSelected ? total + 1 : total;
      }, 0);
    },
    canEditCategory: function canEditCategory() {
      return this.$userInfo.isSupportUser || this.$userInfo.isCustomerAdministrator;
    },
    selectedImagesWithInfos: function selectedImagesWithInfos() {
      return this.imagesWithInfo.filter(function (i) {
        return i.isSelected;
      });
    },
    mobileImageSourceType: function mobileImageSourceType() {
      return _enums__WEBPACK_IMPORTED_MODULE_45__["MobileImageSourceType"];
    }
  },
  watch: {
    // The notification store loads asynchronously and polls, so clear again when
    // it changes - covers arriving here before the first poll, and uploads that
    // land while this tab is already open.
    $notifications: function $notifications() {
      this.dismissNewImageNotifications();
    },
    'dropzoneOptions.capture': function dropzoneOptionsCapture(newVal, oldVal) {
      var _this = this;
      // this.dropzoneOptions.capture = newVal
      // Reload vue-dropzone component here
      if (this.isDropzoneActive === true) {
        this.isDropzoneActive = false;
        this.$nextTick(function () {
          _this.isDropzoneActive = true;
        });
      }
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this2.dropzoneOptions.capture = _components_utils_helpers__WEBPACK_IMPORTED_MODULE_49__["isMobile"].any() ? _this2.mobileImageSourceType.Gallery : _this2.mobileImageSourceType.Camera;
            _this2.dropzoneOptions.headers.Authorization = "Bearer ".concat(_services_common__WEBPACK_IMPORTED_MODULE_48__["default"].getAuthToken());
            _this2.applyUploadLimit();
            //  this.createDefaultImageCategories()
            _context.n = 1;
            return _this2.getImageCategories();
          case 1:
            _this2.getThumbnails();
            _this2.dismissNewImageNotifications();
            _this2.setImagesAsRead();
            _this2.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].EntityReloaded, _this2.getThumbnails);
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].EntityReloaded, this.getThumbnails);
  },
  methods: {
    // Opening the tab is the read action - there is no explicit "mark as read" control,
    // by design. The dot is cleared straight away rather than on the sub nav's next poll;
    // a failure here is not worth interrupting the user for, since the next poll corrects it.
    setImagesAsRead: function setImagesAsRead() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee2() {
        var quoteId, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              quoteId = _this3.value && _this3.value.quoteId;
              if (quoteId) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _context2.p = 1;
              _context2.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].setImagesAsRead(quoteId);
            case 2:
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].ImagesRead);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              console.error(_t);
            case 4:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    // Separate from the unread dot, which is now per-user read state. This clears the
    // quote's entries in the notification centre, which is its own feature and still
    // only tracks anonymous customer uploads through the public image link.
    dismissNewImageNotifications: function dismissNewImageNotifications() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee3() {
        var quoteId, unread, _iterator, _step, notification, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              quoteId = _this4.value && _this4.value.quoteId;
              if (quoteId) {
                _context3.n = 1;
                break;
              }
              return _context3.a(2);
            case 1:
              unread = (_this4.$notifications || []).filter(function (n) {
                return n.entityType === _enums__WEBPACK_IMPORTED_MODULE_45__["NotificationEntityType"].Quote && n.type === _enums__WEBPACK_IMPORTED_MODULE_45__["NotificationType"].QuoteImageUploadedIncoming && String(n.entityId).toLowerCase() === String(quoteId).toLowerCase();
              });
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(unread);
              _context3.p = 2;
              _iterator.s();
            case 3:
              if ((_step = _iterator.n()).done) {
                _context3.n = 5;
                break;
              }
              notification = _step.value;
              _context3.n = 4;
              return _this4.dismissNotification({
                id: notification.id,
                type: notification.type
              });
            case 4:
              _context3.n = 3;
              break;
            case 5:
              _context3.n = 7;
              break;
            case 6:
              _context3.p = 6;
              _t2 = _context3.v;
              _iterator.e(_t2);
            case 7:
              _context3.p = 7;
              _iterator.f();
              return _context3.f(7);
            case 8:
              return _context3.a(2);
          }
        }, _callee3, null, [[2, 6, 7, 8]]);
      }))();
    },
    // PCK-213 - the cap comes from SETTINGS_UPLOAD_MAX_FILE_SIZE_MB. VueDropzone builds Dropzone
    // once in mounted() with no watcher on options, so the live instance needs setOption as well
    // as the data object. The seeded 10 covers the gap until this resolves.
    applyUploadLimit: function applyUploadLimit() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee4() {
        var mb;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return Object(_services_uploadLimits__WEBPACK_IMPORTED_MODULE_50__["getMaxUploadFileMb"])();
            case 1:
              mb = _context4.v;
              _this5.dropzoneOptions.maxFilesize = mb;
              if (_this5.$refs.quoteImageDropzone) {
                _this5.$refs.quoteImageDropzone.setOption('maxFilesize', mb);
              }
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    getThumbnailWithInfo: function getThumbnailWithInfo(id, index) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee5() {
        var thumbnail;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].getImageThumbnailWithInfo(id, _this6.size);
            case 1:
              thumbnail = _context5.v;
              return _context5.a(2, thumbnail);
          }
        }, _callee5);
      }))();
    },
    getImageCategories: function getImageCategories() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _context6.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].getQuoteImageCategories();
            case 1:
              _this7.imageCategories = _context6.v;
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    getThumbnails: function getThumbnails() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee7() {
        var vm, promises;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this8.isLoadingImages = true;
              _this8.imagesWithInfo.splice(0, _this8.imagesWithInfo.length);
              vm = _this8;
              _context7.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].getImageIds(_this8.value.quoteId);
            case 1:
              _this8.imageIds = _context7.v;
              promises = _this8.imageIds.map(function (id, index) {
                // vm.getThumbnail(id, index)
                return vm.getThumbnailWithInfo(id, index);
              });
              _context7.n = 2;
              return Promise.all(promises);
            case 2:
              _this8.imagesWithInfo = _context7.v;
              _this8.setPrimary();
              _this8.refreshCategory = !_this8.refreshCategory;
              _this8.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].ImageCountChanged, _this8.imageIds.length);
              // this.$eventHub.$emit(`${EventHubTypes.ImageCountChanged}UpdateQuote`, this.imageIds.length)
              _this8.isLoadingImages = false;
              _this8.areThumbnailsLoaded = true;
            case 3:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    updateImage: function updateImage() {
      this.getImageCategories();
      this.getThumbnails();
    },
    moveSelectedImages: function moveSelectedImages(value) {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee8() {
        var selectedImageWithInfos, selectedQuoteImageIDs;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!value) {
                _context8.n = 3;
                break;
              }
              _this9.$showSpinner('Moving images');
              selectedImageWithInfos = _this9.imagesWithInfo.filter(function (i) {
                return i.isSelected;
              });
              selectedQuoteImageIDs = selectedImageWithInfos.map(function (i) {
                return i.quoteImageId;
              });
              _context8.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].setQuoteImagesCategory(_this9.value.quoteId, _this9.selectedCategory, selectedQuoteImageIDs);
            case 1:
              _context8.n = 2;
              return _this9.getThumbnails();
            case 2:
              _this9.isMoveSelectedImages = !value;
              _this9.$hideSpinner('Moving images');
              _context8.n = 4;
              break;
            case 3:
              _this9.isMoveSelectedImages = value;
            case 4:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    toggleImageCategory: function toggleImageCategory(value) {
      this.addCategoryModalOpen = value;
    },
    showCopyImageDialog: function showCopyImageDialog() {
      this.isCopyImageModalActive = true;
    },
    showMoveImageDialog: function showMoveImageDialog() {
      var movableImageCategories = this.getMovableImageCategories();
      if (movableImageCategories && movableImageCategories.length > 0) {
        this.selectedCategory = movableImageCategories[0].quoteImageCategoryId;
      }
      this.isMoveSelectedImages = true;
    },
    closeCopyImageModal: function closeCopyImageModal() {
      this.isCopyImageModalActive = false;
    },
    copyImagesToQuote: function copyImagesToQuote(quoteId) {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee9() {
        var selectedIds;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _this0.isCopyImageModalActive = false;
              _this0.$showSpinner('Copying images');
              selectedIds = _this0.imagesWithInfo.filter(function (i) {
                return i.isSelected;
              }).map(function (i) {
                return i.quoteImageId;
              });
              _context9.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].copyImagesToQuote(quoteId, selectedIds);
            case 1:
              _this0.$notification.openNotificationWithType('success', 'Copy images', "".concat(_this0.selectedCount, " images copied"));
              _this0.$hideSpinner();
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    showDeletAllModal: function showDeletAllModal() {
      this.isDeleteAllModalActive = true;
    },
    deleteSelectedImages: function deleteSelectedImages(confirm) {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee0() {
        var count, deletedImageIds;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              _this1.isDeleteAllModalActive = false;
              if (!confirm) {
                _context0.n = 3;
                break;
              }
              _this1.refreshComponent = false;
              _this1.$showSpinner('Removing images');
              count = _this1.selectedCount;
              deletedImageIds = _this1.imagesWithInfo.filter(function (i) {
                return i.isSelected;
              }).map(function (i) {
                return i.quoteImageId;
              });
              _context0.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].deleteMultipleImages(deletedImageIds);
            case 1:
              _this1.imagesWithInfo = _this1.imagesWithInfo.filter(function (i) {
                return !i.isSelected;
              });
              _this1.imageIds = _this1.imagesWithInfo.filter(function (i) {
                return !i.isSelected;
              }).map(function (i) {
                return i.quoteImageId;
              });
              _this1.$hideSpinner();
              _context0.n = 2;
              return _this1.$nextTick();
            case 2:
              _this1.refreshComponent = true;
              _this1.getThumbnails();
              _this1.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].ImageCountChanged, "UpdateQuote"), _this1.imagesWithInfo.length);
              _this1.$notification.openNotificationWithType('success', 'Delete images', "".concat(count, " images deleted"));
            case 3:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    setPrimary: function setPrimary(imageId) {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee1() {
        var image, hasPrimaryImage, firstImage;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (!imageId) {
                _context1.n = 2;
                break;
              }
              _context1.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].setQuoteImageIsPrimary(imageId);
            case 1:
              image = _this10.imagesWithInfo.find(function (i) {
                return i.quoteImageId === imageId;
              });
              if (image) {
                _this10.imagesWithInfo.forEach(function (i) {
                  return i.isPrimary = false;
                });
                image.isPrimary = true;
              }
              _context1.n = 3;
              break;
            case 2:
              hasPrimaryImage = _this10.imagesWithInfo.some(function (i) {
                return i.isPrimary;
              });
              if (!(!hasPrimaryImage && _this10.imagesWithInfo.length)) {
                _context1.n = 3;
                break;
              }
              firstImage = _this10.imagesWithInfo[0];
              firstImage.isPrimary = true;
              _context1.n = 3;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].setQuoteImageIsPrimary(firstImage.quoteImageId);
            case 3:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    showDownloadImagesModal: function showDownloadImagesModal() {
      this.isDownloadImagesModalActive = true;
    },
    downloadSelectedImages: function downloadSelectedImages(confirm) {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee10() {
        var imageIds, promises, i, id;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              _this11.isDownloadImagesModalActive = false;
              if (!confirm) {
                _context10.n = 4;
                break;
              }
              imageIds = _this11.imagesWithInfo.filter(function (i) {
                return i.isSelected;
              }).map(function (i) {
                return i.quoteImageId;
              });
              promises = [];
              i = 0;
            case 1:
              if (!(i < imageIds.length)) {
                _context10.n = 4;
                break;
              }
              id = imageIds[i];
              promises.push(_this11.downloadImage(id));
              if (!(promises.length === 10)) {
                _context10.n = 3;
                break;
              }
              _context10.n = 2;
              return Promise.all(promises);
            case 2:
              promises = [];
              _context10.n = 3;
              return _this11.pause(1000);
            case 3:
              i++;
              _context10.n = 1;
              break;
            case 4:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    pause: function pause(msec) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee11() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              return _context11.a(2, new Promise(function (resolve, reject) {
                setTimeout(resolve, msec || 1000);
              }));
          }
        }, _callee11);
      }))();
    },
    downloadImage: function downloadImage(id) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee12() {
        var result, blob, disposition, filenameRegex, matches, filename, link, url;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              _context12.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].downloadImage(id);
            case 1:
              result = _context12.v;
              blob = new Blob([result.data], {
                type: result.headers['content-type']
              });
              disposition = result.headers['content-disposition'];
              filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
              matches = filenameRegex.exec(disposition);
              filename = '';
              if (matches != null && matches[1]) {
                filename = matches[1].replace(/['"]/g, '');
              }
              link = document.createElement('a');
              link.style = 'display: none';
              url = window.URL.createObjectURL(blob);
              link.href = url;
              link.download = filename;
              document.body.appendChild(link);
              link.click();
              window.URL.revokeObjectURL(url);
              delete link.href;
            case 2:
              return _context12.a(2);
          }
        }, _callee12);
      }))();
    },
    setSelectedStatusAll: function setSelectedStatusAll(selected) {
      this.imagesWithInfo.forEach(function (i) {
        return i.isSelected = selected;
      });
      this.hasSeclectAll = selected;
    },
    dropzoneMounted: function dropzoneMounted() {
      this.$refs.quoteImageDropzone.getAcceptedFiles();
    },
    dropzoneFileAdded: function dropzoneFileAdded(file) {
      if (this.selectedCategory) {
        this.$refs.quoteImageDropzone.changeUrl("".concat("/UniqApi/v1", "/quotes/images/upload/").concat(this.value.quoteId, "/").concat(this.value.prefix).concat(this.value.quoteNo).concat(this.value.suffix, "/").concat(this.value.subQuoteNo, "/").concat(this.selectedCategory));
      }
      this.isClearAllActive = true;
      this.isUploading = true;
    },
    dropzoneSuccess: function dropzoneSuccess(file, response) {
      this.queuedFileCount++;
      this.imagesWithInfo = [];
    },
    dropzoneErrorMultiple: function dropzoneErrorMultiple(files, message, xhr) {},
    dropzoneSending: function dropzoneSending(file, xhr, formData) {},
    dropzoneCompleteMultiple: function dropzoneCompleteMultiple(files) {
      console.log(files.count);
    },
    dropzoneQueueComplete: function dropzoneQueueComplete(file, xhr, formData) {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee13() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context13) {
          while (1) switch (_context13.n) {
            case 0:
              _this12.getThumbnails();
              _this12.isUploading = false;
              _this12.queuedFileCount = 0;
              _this12.uploadedImage = true;
              _this12.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_45__["EventHubTypes"].ImageCountChanged, "UpdateQuote"), _this12.imagesWithInfo.length);
            case 1:
              return _context13.a(2);
          }
        }, _callee13);
      }))();
    },
    dropzoneTotalUploadProgress: function dropzoneTotalUploadProgress(totaluploadprogress, totalBytes, totalBytesSent) {},
    clearUploadedFile: function clearUploadedFile() {
      this.$refs.quoteImageDropzone.removeAllFiles();
      this.uploadedImage = false;
    },
    uploadImage: function uploadImage() {
      var _this13 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee14() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context14) {
          while (1) switch (_context14.n) {
            case 0:
              _this13.isUploadImage = !_this13.isUploadImage;
              _this13.isDropzoneActive = !_this13.isDropzoneActive;
              if (_this13.imageCategories && _this13.imageCategories.length > 0) {
                _this13.selectedCategory = _this13.imageCategories[0].quoteImageCategoryId;
              }
              if (!_this13.isUploadImage) {
                _this13.clearUploadedFile();
                _this13.refreshCategory = !_this13.refreshCategory;
              }
            case 1:
              return _context14.a(2);
          }
        }, _callee14);
      }))();
    },
    arrangeImagesOrder: function arrangeImagesOrder() {
      var _this14 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee15() {
        var imageIds, _iterator2, _step2, category;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context15) {
          while (1) switch (_context15.n) {
            case 0:
              imageIds = [];
              _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this14.$refs.quoteImageCategories);
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  category = _step2.value;
                  if (category.imagesWithInfo.length) {
                    imageIds.push.apply(imageIds, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(category.imagesWithInfo.map(function (obj) {
                      return obj.quoteImageId;
                    })));
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
              if (!imageIds) {
                _context15.n = 1;
                break;
              }
              _context15.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_40__["default"].setQuoteImagesOrderIndex(_this14.value.quoteId, imageIds);
            case 1:
              return _context15.a(2);
          }
        }, _callee15);
      }))();
    },
    getMovableImageCategories: function getMovableImageCategories() {
      var selectedImageWithInfos = this.imagesWithInfo.filter(function (i) {
        return i.isSelected;
      });
      var selectedImageCategoryIDs = selectedImageWithInfos.map(function (i) {
        return i.imageCategoryId;
      });
      var uniqueImageCategoryIDs = Array.from(new Set(selectedImageCategoryIDs));
      var selectableImageCategories = uniqueImageCategoryIDs.length == 1 ? this.imageCategories.filter(function (i) {
        return i.quoteImageCategoryId !== uniqueImageCategoryIDs[0];
      }) : this.imageCategories;
      return selectableImageCategories;
    },
    onImageCategoriesChanged: function onImageCategoriesChanged() {
      this.$notification.openNotificationWithType('success', 'Image Categories', 'Image categories updated');
      this.getImageCategories();
    },
    reload: function reload() {
      var _this15 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().m(function _callee16() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])().w(function (_context16) {
          while (1) switch (_context16.n) {
            case 0:
              _context16.n = 1;
              return _this15.getThumbnails();
            case 1:
              return _context16.a(2);
          }
        }, _callee16);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_13__);














var newGuid = '00000000-0000-0000-0000-000000000000';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteImageCategoryModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_11__["BaseModalEx"],
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_13___default.a
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      newCategoryName: '',
      categories: [],
      isDeleteModalActive: false,
      selectedCategory: null
    };
  },
  computed: {
    maxImageCategoryOrderIndex: function maxImageCategoryOrderIndex() {
      return this.categories.reduce(function (max, obj) {
        return obj.orderIndex > max ? obj.orderIndex : max;
      }, this.categories[0].orderIndex);
    },
    selectedCategoryName: function selectedCategoryName() {
      var category = this.selectedCategory;
      if (category && category.name) return category.name;
      return '';
    }
  },
  watch: {
    active: function active(value) {
      this.loadQuoteImageCategories();
      this.isActive = value;
    }
  },
  created: function created() {},
  mounted: function mounted() {
    //this.loadQuoteImageCategories()
  },
  methods: {
    createNewCategory: function createNewCategory() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              //await QuoteService.createImageCategory(this.newCategoryName)
              //this.$emit('categories-changed')
              //this.loadQuoteImageCategories()
              _this.categories.push({
                isDefault: false,
                isPrivate: false,
                name: _this.newCategoryName,
                orderIndex: _this.maxImageCategoryOrderIndex + 1,
                isRemove: false,
                quoteImageCategoryId: newGuid
              });
              _this.newCategoryName = '';
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    deleteCategory: function deleteCategory(row) {
      this.selectedCategory = row;
      this.isDeleteModalActive = true;
    },
    confirmDeleteCategory: function confirmDeleteCategory() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var row, indexToRemove, isAttached;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (_this2.selectedCategory) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              row = _this2.selectedCategory;
              indexToRemove = _this2.categories.findIndex(function (obj) {
                return obj.orderIndex === row.orderIndex;
              });
              if (!(!row.quoteImageCategoryId || row.quoteImageCategoryId == newGuid)) {
                _context2.n = 2;
                break;
              }
              if (indexToRemove !== -1) {
                _this2.categories.splice(indexToRemove, 1);
              }
              _context2.n = 4;
              break;
            case 2:
              _context2.n = 3;
              return _this2.isCategoryAttachedImage(row.quoteImageCategoryId);
            case 3:
              isAttached = _context2.v;
              if (!isAttached) {
                if (indexToRemove !== -1) {
                  _this2.categories.splice(indexToRemove, 1);
                }
              }
            case 4:
              //await QuoteService.updateQuoteImageCategory(row.quoteImageCategoryId, row.name, true)
              //this.$emit('categories-changed')
              //this.loadQuoteImageCategories()
              //this.$emit('cancel')
              _this2.closeDeleteModal();
            case 5:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    saveCategories: function saveCategories() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$showSpinner();
              _context3.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].updateImageCategories(_this3.categories);
            case 1:
              _this3.$emit('categories-changed');
              _this3.loadQuoteImageCategories();
              _this3.$hideSpinner();
              _this3.$emit('cancel');
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    isCategoryAttachedImage: function isCategoryAttachedImage(quoteImageCategoryId) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var attachedImageCount;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].getImageCategoryImagesCount(quoteImageCategoryId);
            case 1:
              attachedImageCount = _context4.v;
              if (!(attachedImageCount > 0)) {
                _context4.n = 2;
                break;
              }
              _this4.$notification.openNotificationWithType('danger', 'Unable to delete', "".concat(attachedImageCount, " images attached with category."));
              return _context4.a(2, true);
            case 2:
              return _context4.a(2, false);
          }
        }, _callee4);
      }))();
    },
    setDirty: function setDirty(category) {
      category.isDirty = true;
    },
    loadQuoteImageCategories: function loadQuoteImageCategories() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_12__["default"].getQuoteImageCategories();
            case 1:
              _this5.categories = _context5.v;
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    cancel: function cancel() {
      this.$emit('cancel');
    },
    onImageCategoryOrderChange: function onImageCategoryOrderChange(event) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              if (event.moved !== undefined) {
                //console.log(event.moved)
                //var movedItem = event.added.element
                // for (let i = 0; i < this.categories.length; i++) {
                //   this.categories[i].orderIndex = i
                // }
              }
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    checkMove: function checkMove(e) {
      return e.draggedContext.futureIndex !== 0;
    },
    closeDeleteModal: function closeDeleteModal() {
      this.selectedCategory = null;
      this.isDeleteModalActive = !this.isDeleteModalActive;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-images-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Images")]), _vm.imageCount ? _c("span", {
    staticClass: "has-badge-rounded has-badge-info has-badge-large",
    attrs: {
      "data-badge": _vm.imageCount
    }
  }) : _vm._e()]), _c("p", {
    staticClass: "subtitle"
  }, [_vm._v(_vm._s(_vm.isDropzoneActive ? "Upload images" : "Manage quote images"))])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("p", {
    staticClass: "buttons"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Move Category"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showMoveImageDialog();
      }
    }
  }, [_vm._m(0)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Copy to quote"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showCopyImageDialog();
      }
    }
  }, [_vm._m(1)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      disabled: _vm.$licenceExpired,
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Delete selected"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showDeletAllModal();
      }
    }
  }, [_vm._m(2)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.hasSelected,
      expression: "hasSelected"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Download selected"
    },
    on: {
      click: _vm.showDownloadImagesModal
    }
  }, [_vm._m(3)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isDropzoneActive,
      expression: "!isDropzoneActive"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Select all",
      disabled: _vm.isLoadingImages
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(true);
      }
    }
  }, [_vm._m(4)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isDropzoneActive,
      expression: "!isDropzoneActive"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Deselect all"
    },
    on: {
      click: function click($event) {
        return _vm.setSelectedStatusAll(false);
      }
    }
  }, [_vm._m(5)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isDropzoneActive,
      expression: "!isDropzoneActive"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Refresh",
      disabled: _vm.isLoadingImages
    },
    on: {
      click: _vm.getThumbnails
    }
  }, [_vm._m(6)]), _vm.canEditCategory ? _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isDropzoneActive,
      expression: "!isDropzoneActive"
    }],
    staticClass: "button is-primary",
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.toggleImageCategory(true);
      }
    }
  }, [_vm._m(7), _c("span", [_vm._v("Add Categories")])]) : _vm._e(), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isDropzoneActive && _vm.uploadedImage,
      expression: "isDropzoneActive && uploadedImage"
    }],
    staticClass: "button is-primary",
    on: {
      click: function click($event) {
        return _vm.clearUploadedFile(true);
      }
    }
  }, [_vm._m(8), _c("span", [_vm._v("Clear All")])]), _c("a", {
    staticClass: "button is-primary",
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.uploadImage();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi",
    class: {
      "mdi-plus": !_vm.isDropzoneActive,
      "mdi-minus": _vm.isDropzoneActive
    }
  })]), _c("span", [_vm._v(_vm._s(_vm.isDropzoneActive ? "Close" : "Add"))])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isDropzoneActive && _vm.isMobile.any(),
      expression: "isDropzoneActive && isMobile.any()"
    }],
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.dropzoneOptions.capture,
      expression: "dropzoneOptions.capture"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.dropzoneOptions, "capture", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    domProps: {
      value: _vm.mobileImageSourceType.Gallery
    }
  }, [_vm._v("From Gallery")]), _c("option", {
    domProps: {
      value: _vm.mobileImageSourceType.Camera
    }
  }, [_vm._v("From Camera")])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isDropzoneActive,
      expression: "isDropzoneActive"
    }],
    staticClass: "card-image"
  }, [_c("div", [_c("label", {
    staticClass: "label"
  }, [_vm._v("Select Image Category")]), _c("div", {
    staticClass: "select field mb-2"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedCategory,
      expression: "selectedCategory"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedCategory = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }, _vm.clearUploadedFile]
    }
  }, _vm._l(_vm.imageCategories, function (cat) {
    return _c("option", {
      key: cat.quoteImageCategoryId,
      domProps: {
        value: cat.quoteImageCategoryId
      }
    }, [_vm._v(" " + _vm._s(cat.name) + " ")]);
  }), 0)])]), _vm.isDropzoneActive ? _c("vue-dropzone", {
    ref: "quoteImageDropzone",
    attrs: {
      id: "quoteImageDropzone",
      "use-custom-slot": true,
      options: _vm.dropzoneOptions
    },
    on: {
      "vdropzone-mounted": _vm.dropzoneMounted,
      "vdropzone-file-added": _vm.dropzoneFileAdded,
      "vdropzone-success": _vm.dropzoneSuccess,
      "vdropzone-error-multiple": _vm.dropzoneErrorMultiple,
      "vdropzone-sending": _vm.dropzoneSending,
      "vdropzone-total-upload-progress": _vm.dropzoneTotalUploadProgress,
      "vdropzone-complete-multiple": _vm.dropzoneCompleteMultiple,
      "vdropzone-queue-complete": function vdropzoneQueueComplete(file) {
        return _vm.dropzoneQueueComplete(file);
      }
    }
  }) : _vm._e()], 1), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.isDropzoneActive,
      expression: "!isDropzoneActive"
    }]
  }, [_vm._l(_vm.imageCategories, function (category) {
    return [_vm.refreshComponent ? _c("quote-image-category", {
      key: category.quoteImageCategoryId,
      ref: "quoteImageCategories",
      refInFor: true,
      attrs: {
        categories: _vm.imageCategories,
        images: _vm.imagesWithInfo,
        "quote-id": _vm.value.quoteId,
        category: category.name,
        "category-id": category.quoteImageCategoryId,
        "category-order-index": category.orderIndex,
        "is-private": category.isPrivate,
        value: _vm.value,
        "has-select": _vm.hasSeclectAll,
        refresh: _vm.refreshCategory
      },
      on: {
        setPrimary: function setPrimary(imageId) {
          return _vm.setPrimary(imageId);
        },
        "update-image": _vm.updateImage,
        "arrange-images-order": _vm.arrangeImagesOrder
      }
    }) : _vm._e()];
  })], 2)])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isDeleteAllModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteAllModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteSelectedImages(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteSelectedImages(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete images")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedCount))]), _vm._v(" selected images will be deleted. Continue? ")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isDownloadImagesModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDownloadImagesModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.downloadSelectedImages(true);
      },
      cancel: function cancel($event) {
        return _vm.downloadSelectedImages(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Download images")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedCount))]), _vm._v(" selected images will be downloaded. Continue? ")])]), _c("quote-image-category-modal", {
    attrs: {
      active: _vm.addCategoryModalOpen
    },
    on: {
      cancel: function cancel($event) {
        return _vm.toggleImageCategory(false);
      },
      "categories-changed": function categoriesChanged($event) {
        return _vm.onImageCategoriesChanged();
      }
    }
  }), _vm.isCopyImageModalActive ? _c("quote-no-search-modal", {
    attrs: {
      active: _vm.isCopyImageModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCopyImageModalActive = $event;
      },
      copy: _vm.copyImagesToQuote,
      close: _vm.closeCopyImageModal
    }
  }) : _vm._e(), _c("confirm-modal", {
    attrs: {
      active: _vm.isMoveSelectedImages,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isMoveSelectedImages = $event;
      },
      ok: function ok($event) {
        return _vm.moveSelectedImages(true);
      },
      cancel: function cancel($event) {
        return _vm.moveSelectedImages(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Move to category")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Select Image Category")]), _c("div", {
    staticClass: "select field mb-2"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedCategory,
      expression: "selectedCategory"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedCategory = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, _vm._l(_vm.getMovableImageCategories(), function (cat) {
    return _c("option", {
      key: cat.quoteImageCategoryId,
      domProps: {
        value: cat.quoteImageCategoryId
      }
    }, [_vm._v(" " + _vm._s(cat.name) + " ")]);
  }), 0)])]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedCount))]), _vm._v(" selected images will be moved to selected Category. Continue? ")])])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-folder-move mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-content-copy mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete-sweep mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-download mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-select-all mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-grey"
  }, [_c("i", {
    staticClass: "mdi mdi-select-off mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-close"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_c("span", [_vm._v("Add or Edit Category")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", [_vm._v("Create New Category")])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newCategoryName,
      expression: "newCategoryName"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Please enter a new Name"
    },
    domProps: {
      value: _vm.newCategoryName
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.newCategoryName = $event.target.value;
      }
    }
  })])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "button is-secondary",
    on: {
      click: function click($event) {
        _vm.newCategoryName = "";
      }
    }
  }, [_vm._v("Clear")])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "button is-primary is-pulled-right",
    on: {
      click: function click($event) {
        return _vm.createNewCategory();
      }
    }
  }, [_vm._v("Create")])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("label", [_vm._v("Edit Existing Category")])])]), _c("draggable", {
    attrs: {
      list: _vm.categories,
      group: "categories",
      handle: ".item-drag-handle",
      move: _vm.checkMove
    },
    on: {
      change: function change(event) {
        return _vm.onImageCategoryOrderChange(event);
      }
    }
  }, _vm._l(_vm.categories, function (category, index) {
    return _c("div", {
      key: category.quoteAttachmentCategoryId,
      staticClass: "field is-horizontal"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "icon pt-2"
    }, [index != 0 ? _c("i", {
      staticClass: "mdi mdi-drag mdi-24px item-drag-handle",
      attrs: {
        "aria-hidden": "true"
      }
    }) : _vm._e()])]), _c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control is-expanded"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: category.name,
        expression: "category.name"
      }],
      staticClass: "input",
      attrs: {
        type: "text",
        placeholder: "Existing Name"
      },
      domProps: {
        value: category.name
      },
      on: {
        keyup: function keyup($event) {
          return _vm.setDirty(category);
        },
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(category, "name", $event.target.value);
        }
      }
    })]), _c("div", {
      staticClass: "control"
    }, [_c("a", {
      staticClass: "button is-secondary has-text-danger",
      class: {
        "is-hidden": category.isDefault
      },
      on: {
        click: function click($event) {
          return _vm.deleteCategory(category);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-trash-can mdi-18px"
    })])])])]), category.isPrivate ? _c("div", {
      staticClass: "control is-flex is-align-items-center pl-3"
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("i", {
      staticClass: "mdi mdi-eye-off mdi-24px"
    })])]) : _vm._e()]);
  }), 0)], 1), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; flex-direction: row-reverse;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancel();
      }
    }
  }, [_c("span", [_vm._v("Cancel")])]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Save"
    },
    on: {
      click: function click($event) {
        return _vm.saveCategories();
      }
    }
  }, [_c("span", [_vm._v("Save")])])])])])]), _c("base-modal-ex", {
    attrs: {
      active: _vm.isDeleteModalActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDeleteModalActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_c("span", [_vm._v("Delete Category")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("p", [_c("span", [_vm._v('Proceed to delete category "'), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedCategoryName))]), _vm._v('" ?')])])]), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; flex-direction: row-reverse;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.closeDeleteModal();
      }
    }
  }, [_c("span", [_vm._v("Cancel")])]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Save"
    },
    on: {
      click: function click($event) {
        return _vm.confirmDeleteCategory();
      }
    }
  }, [_c("span", [_vm._v("Confirm")])])])])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/core-js/modules/es.object.freeze.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es.object.freeze.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var FREEZING = __webpack_require__(/*! ../internals/freezing */ "./node_modules/core-js/internals/freezing.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
var onFreeze = __webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js").onFreeze;

// eslint-disable-next-line es/no-object-freeze -- safe
var $freeze = Object.freeze;
var FAILS_ON_PRIMITIVES = fails(function () { $freeze(1); });

// `Object.freeze` method
// https://tc39.es/ecma262/#sec-object.freeze
$({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES, sham: !FREEZING }, {
  freeze: function freeze(it) {
    return $freeze && isObject(it) ? $freeze(onFreeze(it)) : it;
  }
});


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".not-draggable[data-v-5d996bc4] {\n  cursor: no-drop;\n}\n.item-drag-handle[data-v-5d996bc4] {\n  cursor: move;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("931a3286", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VueDropzone/index.js":
/*!*********************************************!*\
  !*** ./src/components/VueDropzone/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// import VueDropzone from './VueDropzone'
var VueDropzone = function VueDropzone(r) {
  return __webpack_require__.e(/*! require.ensure | dropzone-components-chunk */ "dropzone-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueDropzone.vue */ "./src/components/VueDropzone/VueDropzone.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
/* harmony default export */ __webpack_exports__["default"] = (VueDropzone);

/***/ }),

/***/ "./src/services/byteUnits.js":
/*!***********************************!*\
  !*** ./src/services/byteUnits.js ***!
  \***********************************/
/*! exports provided: BYTES_PER_MB, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BYTES_PER_MB", function() { return BYTES_PER_MB; });
/**
 * PCK-213 - bytes in a megabyte. Size limits are stored and shown in MB but compared in bytes,
 * so this conversion appeared across the limit services and the uploaders.
 *
 * apps/pwa has its own copy: the two apps are separate builds with no module in common.
 */
var BYTES_PER_MB = 1024 * 1024;
/* harmony default export */ __webpack_exports__["default"] = ({
  BYTES_PER_MB: BYTES_PER_MB
});

/***/ }),

/***/ "./src/services/uploadLimits.js":
/*!**************************************!*\
  !*** ./src/services/uploadLimits.js ***!
  \**************************************/
/*! exports provided: FALLBACK_MAX_FILE_BYTES, FALLBACK_AUDANET_MAX_FILE_BYTES, getUploadLimits, getMaxUploadFileMb, getAudaNetMaxFileMb, resetUploadLimitsCache, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_MAX_FILE_BYTES", function() { return FALLBACK_MAX_FILE_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_AUDANET_MAX_FILE_BYTES", function() { return FALLBACK_AUDANET_MAX_FILE_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUploadLimits", function() { return getUploadLimits; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMaxUploadFileMb", function() { return getMaxUploadFileMb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAudaNetMaxFileMb", function() { return getAudaNetMaxFileMb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetUploadLimitsCache", function() { return resetUploadLimitsCache; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.number.is-finite.js */ "./node_modules/core-js/modules/es.number.is-finite.js");
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.freeze.js */ "./node_modules/core-js/modules/es.object.freeze.js");
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/services/byteUnits */ "./src/services/byteUnits.js");








/**
 * PCK-213 - per-file upload caps, read from the API instead of hardcoded.
 *
 * The same 10MB was written into every uploader in both apps, with nothing keeping the copies in
 * step. A shared JS constant cannot fix it because apps/web and apps/pwa are separate builds, so
 * the setting is the only single source both can read - apps/pwa has its own copy of this module.
 *
 * Memoised: the caps do not change within a page load.
 */

var FALLBACK_MAX_FILE_BYTES = 10 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"];
var FALLBACK_AUDANET_MAX_FILE_BYTES = 1.5 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"];
var FALLBACK = Object.freeze({
  maxFileBytes: FALLBACK_MAX_FILE_BYTES,
  audaNetMaxFileBytes: FALLBACK_AUDANET_MAX_FILE_BYTES
});
var cached = null;
function getUploadLimits() {
  if (!cached) {
    cached = _services_fq_api__WEBPACK_IMPORTED_MODULE_5__["default"].get('/settings/uploadlimits').then(function (response) {
      var data = response && response.data || {};
      var maxFileBytes = Number(data.maxFileBytes);
      var audaNetMaxFileBytes = Number(data.audaNetMaxFileBytes);
      return {
        maxFileBytes: Number.isFinite(maxFileBytes) && maxFileBytes > 0 ? maxFileBytes : FALLBACK.maxFileBytes,
        audaNetMaxFileBytes: Number.isFinite(audaNetMaxFileBytes) && audaNetMaxFileBytes > 0 ? audaNetMaxFileBytes : FALLBACK.audaNetMaxFileBytes
      };
    }).catch(function () {
      return FALLBACK;
    });
  }
  return cached;
}

/** Dropzone's maxFilesize option is in MB. */
function getMaxUploadFileMb() {
  return _getMaxUploadFileMb.apply(this, arguments);
}
function _getMaxUploadFileMb() {
  _getMaxUploadFileMb = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
    var limits;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
      while (1) switch (_context.n) {
        case 0:
          _context.n = 1;
          return getUploadLimits();
        case 1:
          limits = _context.v;
          return _context.a(2, limits.maxFileBytes / _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"]);
      }
    }, _callee);
  }));
  return _getMaxUploadFileMb.apply(this, arguments);
}
function getAudaNetMaxFileMb() {
  return _getAudaNetMaxFileMb.apply(this, arguments);
}

/** Test seam - drops the memoised result so each spec starts clean. */
function _getAudaNetMaxFileMb() {
  _getAudaNetMaxFileMb = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
    var limits;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
      while (1) switch (_context2.n) {
        case 0:
          _context2.n = 1;
          return getUploadLimits();
        case 1:
          limits = _context2.v;
          return _context2.a(2, limits.audaNetMaxFileBytes / _services_byteUnits__WEBPACK_IMPORTED_MODULE_6__["BYTES_PER_MB"]);
      }
    }, _callee2);
  }));
  return _getAudaNetMaxFileMb.apply(this, arguments);
}
function resetUploadLimitsCache() {
  cached = null;
}
/* harmony default export */ __webpack_exports__["default"] = ({
  getUploadLimits: getUploadLimits,
  getMaxUploadFileMb: getMaxUploadFileMb,
  getAudaNetMaxFileMb: getAudaNetMaxFileMb,
  resetUploadLimitsCache: resetUploadLimitsCache
});

/***/ }),

/***/ "./src/views/quote/QuoteImages.vue":
/*!*****************************************!*\
  !*** ./src/views/quote/QuoteImages.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteImages.vue?vue&type=template&id=1ae1e9b7 */ "./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7");
/* harmony import */ var _QuoteImages_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteImages.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteImages.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuoteImages_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteImages.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteImages.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/views/quote/QuoteImages.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImages_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImages.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteImages.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImages_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7":
/*!***********************************************************************!*\
  !*** ./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7 ***!
  \***********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImages.vue?vue&type=template&id=1ae1e9b7 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteImages.vue?vue&type=template&id=1ae1e9b7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImages_vue_vue_type_template_id_1ae1e9b7__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategoryModal.vue":
/*!****************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategoryModal.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true */ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true");
/* harmony import */ var _QuoteImageCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteImageCategoryModal.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true */ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteImageCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5d996bc4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteImageCategoryModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategoryModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true":
/*!*************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=style&index=0&id=5d996bc4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_style_index_0_id_5d996bc4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteImageCategoryModal.vue?vue&type=template&id=5d996bc4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteImageCategoryModal_vue_vue_type_template_id_5d996bc4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-images-chunk.js.map