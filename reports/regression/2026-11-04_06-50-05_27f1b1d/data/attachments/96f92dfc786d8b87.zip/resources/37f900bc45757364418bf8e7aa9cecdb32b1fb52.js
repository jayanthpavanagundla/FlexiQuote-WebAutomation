(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[6],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _TagsService__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./TagsService */ "./src/views/manageTag/TagsService.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _utils_ColorFunctions__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/utils/ColorFunctions */ "./src/utils/ColorFunctions.js");





















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ManageTagsModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__["BaseModalEx"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    },
    tags: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    tagCategoryId: {
      type: String,
      default: null
    }
  },
  data: function data() {
    return {
      isActive: this.active || false,
      localTags: JSON.parse(JSON.stringify(this.tags)),
      newTag: {
        name: '',
        shortTag: '',
        color: '#3498db'
      },
      editingTagIndex: null,
      isTagNameValid: true,
      isShortTagValid: true
    };
  },
  computed: {
    canAddTag: function canAddTag() {
      var trimmedName = this.newTag.name.trim();
      var trimmedShortTag = this.newTag.shortTag.trim();
      return trimmedName.length > 0 && trimmedShortTag.length > 0 && this.isTagNameValid && this.isShortTagValid;
    }
  },
  watch: {
    active: function active(value) {
      this.isActive = value;
      if (value) {
        this.localTags = JSON.parse(JSON.stringify(this.tags));
      }
    },
    tags: function tags(newTags) {
      this.localTags = JSON.parse(JSON.stringify(newTags));
    },
    'newTag.name': {
      handler: function handler(val) {
        var _this = this;
        if (val !== '' && val !== null) {
          var trimmedUpper = val.trim().toUpperCase();
          var tagsToCheck = this.localTags.filter(function (t) {
            return t.isDeleted !== true;
          });
          if (this.editingTagIndex !== null) {
            this.isTagNameValid = !tagsToCheck.some(function (t, idx) {
              return idx !== _this.editingTagIndex && (t.tagName || '').toUpperCase() === trimmedUpper;
            });
          } else {
            this.isTagNameValid = !tagsToCheck.some(function (t) {
              return (t.tagName || '').toUpperCase() === trimmedUpper;
            });
          }
        }
      },
      immediate: false
    },
    'newTag.shortTag': {
      handler: function handler(val) {
        var _this2 = this;
        if (val !== '' && val !== null) {
          var trimmedUpper = val.trim().toUpperCase();
          var tagsToCheck = this.localTags.filter(function (t) {
            return t.isDeleted !== true;
          });
          if (this.editingTagIndex !== null) {
            this.isShortTagValid = !tagsToCheck.some(function (t, idx) {
              return idx !== _this2.editingTagIndex && (t.shortTag || '').toUpperCase() === trimmedUpper;
            });
          } else {
            this.isShortTagValid = !tagsToCheck.some(function (t) {
              return (t.shortTag || '').toUpperCase() === trimmedUpper;
            });
          }
        }
      },
      immediate: false
    }
  },
  methods: {
    handleModalClose: function handleModalClose() {
      this.localTags = this.localTags.filter(function (tag) {
        return !tag.isNew;
      });
      this.editingTagIndex = null;
      this.newTag = {
        name: '',
        shortTag: '',
        color: '#3498db'
      };
      this.$emit('close');
    },
    addTag: function addTag() {
      var trimmedName = this.newTag.name.trim();
      var trimmedShortTag = this.newTag.shortTag.trim();
      if (!trimmedName || !trimmedShortTag) {
        this.$toast.open({
          message: 'Please fill in both Tag Name and Short Tag.',
          type: 'is-danger',
          position: 'is-top',
          queue: false
        });
        return;
      }
      if (this.editingTagIndex !== null) {
        this.localTags.splice(this.editingTagIndex, 1, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.localTags[this.editingTagIndex]), {}, {
          tagName: trimmedName,
          shortTag: trimmedShortTag,
          colorHex: this.newTag.color,
          tagCategoryID: this.tagCategoryId
        }));
        this.editingTagIndex = null;
        this.$toast.open({
          message: 'Tag is updated',
          type: 'is-success',
          position: 'is-top',
          queue: false
        });
      } else {
        this.localTags.push({
          tagID: '00000000-0000-0000-0000-000000000000',
          tagName: trimmedName,
          shortTag: trimmedShortTag,
          colorHex: this.newTag.color,
          tagCategoryID: this.tagCategoryId,
          isNew: true
        });
        this.$toast.open({
          message: 'Tag is created',
          type: 'is-success',
          position: 'is-top',
          queue: false
        });
      }
      // Reset input fields
      this.newTag.name = '';
      this.newTag.shortTag = '';
      this.newTag.color = '#3498db';
    },
    editTag: function editTag(tag) {
      var idx = this.localTags.indexOf(tag);
      if (idx !== -1) {
        this.editingTagIndex = idx;
        this.newTag = {
          name: tag.tagName,
          shortTag: tag.shortTag,
          color: tag.colorHex || '#3498db'
        };
      }
    },
    cancelEditTag: function cancelEditTag() {
      this.editingTagIndex = null;
      this.newTag = {
        name: '',
        shortTag: '',
        color: '#3498db'
      };
    },
    deleteTag: function deleteTag(tagId) {
      this.localTags = this.localTags.map(function (tag) {
        return tag.tagID === tagId ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, tag), {}, {
          isDeleted: true
        }) // Use consistent property name
        : tag;
      });
      this.$toast.open({
        message: 'Tag is deleted',
        type: 'is-danger',
        position: 'is-top',
        queue: false
      });
    },
    saveTags: function saveTags() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var original, current, result, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              // Compare localTags and original tags (ignoring object reference)
              original = JSON.stringify(_this3.tags);
              current = JSON.stringify(_this3.localTags);
              if (!(original === current)) {
                _context.n = 1;
                break;
              }
              // No changes, just close and emit
              // this.$emit('save', this.localTags)
              _this3.$emit('close');
              return _context.a(2, true);
            case 1:
              _context.p = 1;
              _this3.$showSpinner('Saving...');
              _context.n = 2;
              return _TagsService__WEBPACK_IMPORTED_MODULE_18__["default"].postTags(_this3.localTags);
            case 2:
              result = _context.v;
              if (result) {
                _this3.$toast.open({
                  message: 'Save successful',
                  type: 'is-success',
                  position: 'is-top',
                  queue: false
                });
              } else {
                _this3.$toast.open({
                  message: 'Save failed',
                  type: 'is-danger',
                  position: 'is-top',
                  queue: false
                });
              }
              return _context.a(2, true);
            case 3:
              _context.p = 3;
              _t = _context.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_19__["default"].$emit('serviceError', _t.response.status);
              _this3.$toast.open({
                message: _t,
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              return _context.a(2, false);
            case 4:
              _context.p = 4;
              _this3.$hideSpinner();
              _this3.$emit('save', _this3.localTags);
              _this3.$emit('close');
              return _context.f(4);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    },
    getTextColor: _utils_ColorFunctions__WEBPACK_IMPORTED_MODULE_20__["getTextColor"]
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "manage-tags-modal"
  }, [_c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "modal-class": "manage-tags-modal",
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": "10vw",
      "max-width": "10vw",
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title"
  }, [_vm._v("Manage Tags")])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-full"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Tag Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newTag.name,
      expression: "newTag.name"
    }],
    staticClass: "input",
    class: {
      "is-danger": !_vm.isTagNameValid
    },
    attrs: {
      type: "text",
      placeholder: "Add Name",
      maxlength: "30"
    },
    domProps: {
      value: _vm.newTag.name
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.newTag, "name", $event.target.value);
      }
    }
  }), _c("div", {
    staticClass: "help is-secondary"
  }, [_vm._v(" " + _vm._s(_vm.newTag.name.length) + "/30 ")]), !_vm.isTagNameValid ? _c("div", {
    staticClass: "tags"
  }, [_c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v(" Name already in use, choose a different name ")])]) : _vm._e()])])])]), _c("div", {
    staticClass: "columns is-vcentered is-multiline"
  }, [_c("div", {
    staticClass: "column is-3"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Add Short Tag")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newTag.shortTag,
      expression: "newTag.shortTag"
    }],
    staticClass: "input",
    class: {
      "is-danger": !_vm.isShortTagValid
    },
    attrs: {
      type: "text",
      placeholder: "ST",
      maxlength: "5"
    },
    domProps: {
      value: _vm.newTag.shortTag
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.newTag, "shortTag", $event.target.value);
      }, function ($event) {
        _vm.newTag.shortTag = $event.target.value.toUpperCase();
      }]
    }
  }), _c("div", {
    staticClass: "help is-secondary"
  }, [_vm._v(" " + _vm._s(_vm.newTag.shortTag.length) + "/5 ")]), !_vm.isShortTagValid ? _c("div", {
    staticClass: "tags"
  }, [_c("span", {
    staticClass: "tag is-danger"
  }, [_vm._v(" Short Tag already in use, choose a different short tag ")])]) : _vm._e()])])]), _c("div", {
    staticClass: "column is-7 has-text-centered"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Select Colour")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newTag.color,
      expression: "newTag.color"
    }],
    staticClass: "color-circle",
    attrs: {
      type: "color"
    },
    domProps: {
      value: _vm.newTag.color
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.newTag, "color", $event.target.value);
      }
    }
  })])])]), _c("div", {
    staticClass: "column is-2"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control pt-5"
  }, [_c("button", {
    staticClass: "button is-fullwidth tooltip bordered has-text-weight-bold",
    class: {
      "is-static": !_vm.canAddTag
    },
    attrs: {
      "data-tooltip": _vm.editingTagIndex === null ? "Add Tag" : "Update Tag",
      disabled: !_vm.canAddTag
    },
    on: {
      click: _vm.addTag
    }
  }, [_c("span", {
    staticClass: "icon has-text-primary"
  }, [_vm.editingTagIndex === null ? _c("i", {
    staticClass: "mdi mdi-plus mdi-28px"
  }) : _c("i", {
    staticClass: "mdi mdi-content-save mdi-28px"
  })])])])])])]), _c("div", {
    staticClass: "content mt-5"
  }, _vm._l(_vm.localTags.filter(function (tag) {
    return tag.isDeleted !== true;
  }), function (tag, index) {
    return _c("div", {
      key: index,
      staticClass: "box tag-item"
    }, [_c("span", {
      staticClass: "tag-short",
      style: {
        backgroundColor: tag.colorHex,
        color: _vm.getTextColor(tag.colorHex)
      }
    }, [_vm._v(_vm._s(tag.shortTag))]), _c("span", {
      staticClass: "tag-name"
    }, [_vm._v(_vm._s(tag.tagName))]), _c("div", {
      staticClass: "buttons is-right",
      staticStyle: {
        "flex-wrap": "nowrap"
      }
    }, [_vm.editingTagIndex === index ? _c("button", {
      staticClass: "button is-ghost is-small tooltip p-0 has-text-danger is-clickable mr-2",
      attrs: {
        "data-tooltip": "Cancel Edit"
      },
      on: {
        click: _vm.cancelEditTag
      }
    }, [_c("span", {
      staticClass: "material-symbols-outlined"
    }, [_vm._v("close")])]) : _c("button", {
      staticClass: "button is-ghost is-small tooltip p-0 has-text-primary is-clickable mr-2",
      attrs: {
        "data-tooltip": "Edit"
      },
      on: {
        click: function click($event) {
          return _vm.editTag(tag);
        }
      }
    }, [_c("span", {
      staticClass: "material-symbols-outlined"
    }, [_vm._v("edit")])]), _c("button", {
      staticClass: "button is-ghost is-small tooltip px-0 mr-1 has-text-grey-lighter",
      staticStyle: {
        border: "none",
        height: "auto",
        background: "transparent"
      },
      attrs: {
        "data-tooltip": "Delete"
      },
      on: {
        click: function click($event) {
          return _vm.deleteTag(tag.tagID);
        }
      }
    }, [_c("span", {
      staticClass: "material-symbols-rounded",
      on: {
        mouseenter: function mouseenter($event) {
          return $event.target.classList.add("has-text-danger");
        },
        mouseleave: function mouseleave($event) {
          return $event.target.classList.remove("has-text-danger");
        }
      }
    }, [_vm._v(" delete ")])])])]);
  }), 0)]), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: _vm.saveTags
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-20px"
  })]), _c("span", [_vm._v("Close")])])])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.color-circle[data-v-68420e6a] {\n  -moz-appearance: none;\n       appearance: none;\n  -webkit-appearance: none;\n  border: none;\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  padding: 0;\n  cursor: pointer;\n  outline: none;\n  background: none;\n  -webkit-box-shadow: 0 0 0 2px #ccc;\n          box-shadow: 0 0 0 2px #ccc; /* optional border effect */\n}\n.color-circle[data-v-68420e6a]::-webkit-color-swatch-wrapper {\n  padding: 0;\n  border-radius: 50%;\n}\n.color-circle[data-v-68420e6a]::-webkit-color-swatch {\n  border: none;\n  border-radius: 50%;\n}\n.tag-item[data-v-68420e6a] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 0.75rem 1rem;\n  margin-bottom: 0.5rem;\n  -webkit-box-shadow: none;\n          box-shadow: none; /* Remove default box shadow if desired */\n  border: 1px solid var(--border-color); /* Light border to separate items */\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".manage-tags-modal .modal-card {\n  min-width: 800px;\n  width: 10vw;\n}\n.tag-short {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  min-width: 3.5rem; /* Fixed width for consistency */\n  height: 2rem; /* Height to make it a pill shape */\n  padding: 0 0.5rem;\n  border-radius: 9999px; /* Pill shape */\n  color: white; /* Text color for the short tag */\n  font-weight: bold;\n  text-transform: uppercase;\n  font-size: 0.8rem;\n  margin-right: 1rem;\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n}\n.tag-name {\n  -webkit-box-flex: 1;\n      -ms-flex-positive: 1;\n          flex-grow: 1;\n  margin-right: 1rem;\n}\n.tag-input-fake {\n  min-height: 2.25em;\n  border: 1px solid #dbdbdb;\n  border-radius: 4px;\n  padding: 2px 40px 2px 8px;\n  -webkit-transition: border-color 0.2s;\n  transition: border-color 0.2s;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  background: #fff;\n  position: relative;\n  max-height: 300px; /* increase max-height if you want */\n  overflow-y: auto;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  resize: vertical; /* <-- add this line */\n}\n.tag-input-fake::-webkit-scrollbar {\n  height: 6px;\n}\n.tag-input-fake::-webkit-scrollbar-thumb {\n  background: #dbdbdb;\n  border-radius: 3px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("6ccb5a42", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("6b659b9f", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/utils/ColorFunctions.js":
/*!*************************************!*\
  !*** ./src/utils/ColorFunctions.js ***!
  \*************************************/
/*! exports provided: getTextColor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTextColor", function() { return getTextColor; });
function getTextColor(bgColor) {
  if (!bgColor || bgColor === 'transparent') return '#000000';
  var color = bgColor.charAt(0) === '#' ? bgColor.substring(1, 7) : bgColor;
  var r = parseInt(color.substring(0, 2), 16);
  var g = parseInt(color.substring(2, 4), 16);
  var b = parseInt(color.substring(4, 6), 16);
  var brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 155 ? '#000000' : '#ffffff';
}

/***/ }),

/***/ "./src/views/manageTag/ManageTagsModal.vue":
/*!*************************************************!*\
  !*** ./src/views/manageTag/ManageTagsModal.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true */ "./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true");
/* harmony import */ var _ManageTagsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ManageTagsModal.vue?vue&type=script&lang=js */ "./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css */ "./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css");
/* harmony import */ var _ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss */ "./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _ManageTagsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "68420e6a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/manageTag/ManageTagsModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css":
/*!*********************************************************************************************************!*\
  !*** ./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=0&id=68420e6a&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_0_id_68420e6a_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss":
/*!**********************************************************************************************!*\
  !*** ./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=style&index=1&id=68420e6a&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_style_index_1_id_68420e6a_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true":
/*!*******************************************************************************************!*\
  !*** ./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/manageTag/ManageTagsModal.vue?vue&type=template&id=68420e6a&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ManageTagsModal_vue_vue_type_template_id_68420e6a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/manageTag/TagsService.js":
/*!********************************************!*\
  !*** ./src/views/manageTag/TagsService.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  getTagsByCategory: function getTagsByCategory(category) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/tags/getTagsByCategory/".concat(category);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  postTags: function postTags(entityTags) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].post('/tags/postTags', entityTags);
  },
  updateAssetTags: function updateAssetTags(assetId, entityTags) {
    return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].post("/tags/updateAssetTags/".concat(assetId), entityTags);
  }
});

/***/ })

}]);
//# sourceMappingURL=6.js.map