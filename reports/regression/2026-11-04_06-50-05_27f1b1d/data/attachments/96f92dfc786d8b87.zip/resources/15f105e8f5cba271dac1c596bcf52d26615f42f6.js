(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["estimagemessage-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/VueCodemirror */ "./src/components/VueCodemirror/index.js");
/* harmony import */ var codemirror_mode_javascript_javascript_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! codemirror/mode/javascript/javascript.js */ "./node_modules/codemirror/mode/javascript/javascript.js");
/* harmony import */ var codemirror_mode_javascript_javascript_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(codemirror_mode_javascript_javascript_js__WEBPACK_IMPORTED_MODULE_4__);




// language js

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'EstimageMessageDetail',
  components: {
    codemirror: _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_3__["codemirror"]
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    options: null
  },
  data: function data() {
    return {
      code: '',
      editorWidth: 400
    };
  },
  computed: {},
  watch: {
    code: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {
    var _this = this;
    this.code = this.value;
    // Auto-format JSON on load
    this.$nextTick(function () {
      if (_this.code && _this.tryParseJSON(_this.code)) {
        _this.formatJSON();
      }
    });
  },
  methods: {
    onCmReady: function onCmReady(cm) {
      console.log('the editor is readied!', cm);
    },
    onCmFocus: function onCmFocus(cm) {
      console.log('the editor is focus!', cm);
    },
    onCmCodeChange: function onCmCodeChange(newCode) {
      console.log('this is new code', newCode);
      this.code = newCode;
    },
    formatJSON: function formatJSON() {
      try {
        // Parse and re-stringify with formatting
        var parsed = JSON.parse(this.code);
        this.code = JSON.stringify(parsed, null, 2);
      } catch (e) {
        console.error('Invalid JSON, could not format', e);
      }
    },
    tryParseJSON: function tryParseJSON(jsonString) {
      try {
        var o = JSON.parse(jsonString);
        if (o && Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(o) === 'object') {
          return true;
        }
      } catch (e) {}
      return false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _EstimageMessageService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./EstimageMessageService */ "./src/views/estimagemessage/EstimageMessageService.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./storeMixin */ "./src/views/estimagemessage/storeMixin.js");
/* harmony import */ var _EstimageMessageNewSideMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./EstimageMessageNewSideMenu */ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue");
/* harmony import */ var _EstimageMessageDetail__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./EstimageMessageDetail */ "./src/views/estimagemessage/EstimageMessageDetail.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./route-types */ "./src/views/estimagemessage/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/store */ "./src/store/index.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'EstimageMessageNew',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__["default"],
    EstimageMessageNewSideMenu: _EstimageMessageNewSideMenu__WEBPACK_IMPORTED_MODULE_6__["default"],
    EstimageMessageDetail: _EstimageMessageDetail__WEBPACK_IMPORTED_MODULE_7__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_12__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_12__["SaveConflictModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_5__["default"]],
  data: function data() {
    return {
      options: {
        tabSize: 4,
        styleActiveLine: true,
        lineNumbers: true,
        autoCloseTags: true,
        foldGutter: true,
        gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        highlightSelectionMatches: {
          showToken: /\w/,
          annotateScrollbar: true
        },
        line: true,
        matchBrackets: true,
        showCursorWhenSelecting: true,
        lineSeparator: '\n',
        lineWrapping: true,
        mode: 'application/xml',
        theme: 'default'
      },
      entity: null,
      estimageDetails: [],
      showEditor: true,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null
    };
  },
  computed: {},
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_14___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
        }
      }, 250),
      deep: true
    },
    '$theme.isDark': function $themeIsDark(newVal) {
      this.options.theme = newVal ? 'blackboard' : 'default';
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    if (_store__WEBPACK_IMPORTED_MODULE_16__["default"].state.userInfo.data.isSupportUser == null || !_store__WEBPACK_IMPORTED_MODULE_16__["default"].state.userInfo.data.isSupportUser) {
      next('/estimagemessages');
    } else {
      next();
    }
  },
  created: function created() {
    this.getEntity();
    // if (this.$userInfo.codemirrorTheme) {
    //   this.options.theme = this.$userInfo.codemirrorTheme
    // }
    this.options.theme = this.$theme.isDark ? 'blackboard' : 'default';
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_10__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_10__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_10__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_10__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_10__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context.p = 1;
              _this.$showSpinner();
              if (reset) {
                _this.clearSnapshots(_this.$route.params.messageId);
              }
              if (_this.currentSnapshot) {
                _context.n = 2;
                break;
              }
              _context.n = 2;
              return _this.getStoreItem(_this.$route.params.messageId);
            case 2:
              _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this.currentSnapshot);
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('', _t);
            case 4:
              _this.$hideSpinner();
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var title, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              title = 'EstImage Message';
              _this2.entity.messageDirection = parseInt(_this2.estimageDetails.messageDirection);
              _this2.entity.messageTypeId = _this2.estimageDetails.messageTypeEnum;
              _this2.entity.statusId = _this2.estimageDetails.messageStatusTypeEnum;
              _this2.entity.uid = _this2.estimageDetails.uid;
              _this2.entity.modifiedBy = _this2.$userInfo.userId;
              _this2.entity.createdBy = _this2.$userInfo.userId;
              _this2.entity.messageNo = parseInt(_this2.estimageDetails.messageNo);
              if (!(_this2.entity.messageJson === '' || _this2.entity.messageNo === undefined || _this2.entity.uid === undefined)) {
                _context2.n = 1;
                break;
              }
              _this2.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context2.a(2, false);
            case 1:
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity));
              if (!_this2.entity.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _EstimageMessageService__WEBPACK_IMPORTED_MODULE_4__["default"].postEntity(_this2.entity);
            case 2:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 3:
              if (!_this2.snapshotDiff) {
                _context2.n = 5;
                break;
              }
              _context2.n = 4;
              return _EstimageMessageService__WEBPACK_IMPORTED_MODULE_4__["default"].putEntity(_this2.entity, _this2.snapshotDiff);
            case 4:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 5:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 6:
              _this2.$hideSpinner();
              if (!_this2.isSaveContinue) {
                _context2.n = 7;
                break;
              }
              _this2.$notification.openNotificationWithType('success', title, isDelete ? 'EstImage Messages deleted' : 'Save successful');
              _context2.n = 11;
              break;
            case 7:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_11__["default"].NO_CONTENT)) {
                _context2.n = 9;
                break;
              }
              _context2.n = 8;
              return _this2.getEntity(true);
            case 8:
              _this2.$notification.openNotificationWithType('success', title, isDelete ? 'EstImage Messages deleted' : 'Save successful');
              _context2.n = 11;
              break;
            case 9:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_11__["default"].CREATED)) {
                _context2.n = 11;
                break;
              }
              _context2.n = 10;
              return _this2.getEntity(true);
            case 10:
              _this2.$notification.openNotificationWithType('success', title, 'New EstImage Messages added');
            case 11:
              _this2.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_10__["EventHubTypes"].EntitySaved);
              return _context2.a(2, true);
            case 12:
              _context2.p = 12;
              _t2 = _context2.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_15__["default"].$emit('serviceError', _t2.response.status);
              _this2.$hideSpinner();
              if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_11__["default"].CONFLICT) {
                _this2.isSaveConflictModalActive = true;
              } else {
                _this2.$notification.openMessageXhrError('EstImage Messages', _t2);
              }
              return _context2.a(2, false);
          }
        }, _callee2, null, [[1, 12]]);
      }))();
    },
    saveContinue: function saveContinue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isUnsavedModalActive = false;
              _this3.isSaveContinue = true;
              _context3.n = 1;
              return _this3.save();
            case 1:
              _this3.isSaveContinue = _context3.v;
              if (_this3.isSaveContinue) {
                _this3.cancel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
      if (this.entity.messageJson === '' || this.entity.messageNo === undefined || this.entity.uid === undefined) {
        this.$router.push({
          name: _route_types__WEBPACK_IMPORTED_MODULE_8___default.a.EstimageMessageListView.name
        });
      } else if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        this.isUnsavedModalActive = true;
      } else {
        if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_8___default.a.EstimageMessageListView.name
          });
        }
      }
    }
  },
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(to, from, next) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            this.clearSnapshots(this.entity.messageId);
            next();
          case 1:
            return _context4.a(2);
        }
      }, _callee4, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'EstimageMessageNewSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {},
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value),
      value: {
        messageStatusTypeEnum: 30,
        messageDirection: 0,
        messageTypeEnum: 42
      }
    };
  },
  computed: {
    messageStatusTypeEnum: function messageStatusTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_1__["MessageStatusTypes"];
    },
    messageTypeEnum: function messageTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_1__["MessageTypes"];
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("article", {
    staticClass: "box",
    attrs: {
      id: "container"
    }
  }, [_c("div", {
    staticClass: "estimage-codemirror"
  }, [_c("codemirror", {
    attrs: {
      options: _vm.options,
      width: _vm.editorWidth
    },
    model: {
      value: _vm.code,
      callback: function callback($$v) {
        _vm.code = $$v;
      },
      expression: "code"
    }
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6 ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.entity ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": _vm.entity !== null
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("estimage-message-new-side-menu", {
    model: {
      value: _vm.estimageDetails,
      callback: function callback($$v) {
        _vm.estimageDetails = $$v;
      },
      expression: "estimageDetails"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column m-3"
  }, [_vm.options && _vm.showEditor && _vm.entity ? _c("estimage-message-detail", {
    attrs: {
      options: _vm.options
    },
    model: {
      value: _vm.entity.messageJson,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "messageJson", $$v);
      },
      expression: "entity.messageJson"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])])], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" EstImage Message Details ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.uid,
      expression: "value.uid"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Job ID"
    },
    domProps: {
      value: _vm.value.uid
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "uid", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.messageNo,
      expression: "value.messageNo"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Message No."
    },
    domProps: {
      value: _vm.value.messageNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "messageNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.messageTypeEnum,
      expression: "value.messageTypeEnum"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "messageTypeEnum", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      disabled: "",
      value: ""
    }
  }, [_vm._v("-- Message Type --")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstImageRequestForQuote
    }
  }, [_vm._v("Request For Quote")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstImageExcessUpdate
    }
  }, [_vm._v("Excess Updated")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstImageRegoUpdate
    }
  }, [_vm._v("Rego Updated")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstImageAuthorise
    }
  }, [_vm._v("Quote Authorised")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageSuppAuthorised
    }
  }, [_vm._v("Supplementary Authorised")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstImageCancel
    }
  }, [_vm._v("Job Cancelled")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageQuote
    }
  }, [_vm._v("Quote")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageInvoice
    }
  }, [_vm._v("Tax Invoice")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageVehicle
    }
  }, [_vm._v("Vehicle Details")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageImage
    }
  }, [_vm._v("Images")]), _c("option", {
    domProps: {
      value: _vm.messageTypeEnum.EstimageRepairTimeline
    }
  }, [_vm._v("Repair Timeline")])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.messageStatusTypeEnum,
      expression: "value.messageStatusTypeEnum"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "messageStatusTypeEnum", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      disabled: "",
      value: ""
    }
  }, [_vm._v("-- Message Status --")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.ToSend
    }
  }, [_vm._v("To Send")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.Sent
    }
  }, [_vm._v("Sent")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.UnRead
    }
  }, [_vm._v("UnRead")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.Read
    }
  }, [_vm._v("Read")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.Failed
    }
  }, [_vm._v("Failed")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.InComplete
    }
  }, [_vm._v("In Complete")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.Deleted
    }
  }, [_vm._v("Deleted")]), _c("option", {
    domProps: {
      value: _vm.messageStatusTypeEnum.DeletedRecord
    }
  }, [_vm._v("Deleted Record")])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.messageDirection,
      expression: "value.messageDirection"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "messageDirection", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      disabled: "",
      value: ""
    }
  }, [_vm._v("-- Message Direction --")]), _c("option", {
    attrs: {
      value: "0"
    }
  }, [_vm._v("Incoming")]), _c("option", {
    attrs: {
      value: "1"
    }
  }, [_vm._v("Outgoing")])])])])])])]), _c("hr")])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".estimage-codemirror {\n  height: calc(100vh - 170px);\n  width: 100%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("610fbfe0", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageDetail.vue":
/*!*************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageDetail.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EstimageMessageDetail.vue?vue&type=template&id=55d2095c */ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c");
/* harmony import */ var _EstimageMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EstimageMessageDetail.vue?vue&type=script&lang=js */ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss */ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _EstimageMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/estimagemessage/EstimageMessageDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss":
/*!**********************************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=style&index=0&id=55d2095c&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_style_index_0_id_55d2095c_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c":
/*!*******************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageDetail.vue?vue&type=template&id=55d2095c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageDetail.vue?vue&type=template&id=55d2095c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageDetail_vue_vue_type_template_id_55d2095c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNew.vue":
/*!**********************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNew.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EstimageMessageNew.vue?vue&type=template&id=59414bb6 */ "./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6");
/* harmony import */ var _EstimageMessageNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EstimageMessageNew.vue?vue&type=script&lang=js */ "./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EstimageMessageNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__["render"],
  _EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/estimagemessage/EstimageMessageNew.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageNew.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNew_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6":
/*!****************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6 ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageNew.vue?vue&type=template&id=59414bb6 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNew.vue?vue&type=template&id=59414bb6");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNew_vue_vue_type_template_id_59414bb6__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue":
/*!******************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNewSideMenu.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca */ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca");
/* harmony import */ var _EstimageMessageNewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EstimageMessageNewSideMenu.vue?vue&type=script&lang=js */ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EstimageMessageNewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__["render"],
  _EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/estimagemessage/EstimageMessageNewSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageNewSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca":
/*!************************************************************************************************!*\
  !*** ./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/estimagemessage/EstimageMessageNewSideMenu.vue?vue&type=template&id=9575ccca");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_EstimageMessageNewSideMenu_vue_vue_type_template_id_9575ccca__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/estimagemessage/storeMixin.js":
/*!*************************************************!*\
  !*** ./src/views/estimagemessage/storeMixin.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'estimagemessages';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    messageSummary: 'messageSummary'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setMessageSummary', 'clearMessageSummary']))
});

/***/ })

}]);
//# sourceMappingURL=estimagemessage-chunk.js.map