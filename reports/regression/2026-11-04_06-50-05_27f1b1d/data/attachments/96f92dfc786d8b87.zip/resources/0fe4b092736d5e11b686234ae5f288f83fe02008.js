(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-builder-chunk~quote-components-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../mixins */ "./src/views/quote/mixins/index.js");









/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SupplementaryIcon',
  components: {},
  mixins: [_mixins__WEBPACK_IMPORTED_MODULE_7__["QuoteAssessmentMixin"]],
  props: {
    item: {
      type: Object,
      default: null
    },
    itemAssessments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    nextAssessmentNumber: {
      type: Number,
      default: null
    },
    quotingMethod: {
      type: String,
      default: null
    },
    iconSize: {
      type: Number,
      default: 4
    }
  },
  data: function data() {
    return {
      authorisedValueDiff: 0,
      supplementaryNo: 0
    };
  },
  computed: {
    numValuesInColumn: function numValuesInColumn() {
      if (this.isItemlabour && this.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_6__["QuotingMethodTypes"].Hour) {
        return 2;
      }
      return 1;
    },
    isItemlabour: function isItemlabour() {
      var _this = this;
      return _enums__WEBPACK_IMPORTED_MODULE_6__["ItemCategoryCodeTypes"].itemTypes.filter(function (i) {
        return i.valueCalculationType === 'Labour';
      }).some(function (c) {
        return c.code === _this.item.itemType;
      });
    },
    hasAssessments: function hasAssessments() {
      return this.itemAssessments.length > 0;
    },
    supplementaryIconColour: function supplementaryIconColour() {
      var color = 'has-text-danger';
      if (this.itemChanged(this.item, this.item.lastQuotedAssessment, this.item.lastAuthorisedAssessment, this.quotingMethod)) {
        color = 'has-text-danger';
      } else if (this.item.lastAuthorisedAssessment) {
        color = 'has-text-success';
      } else if (this.item.lastQuotedAssessment) {
        color = 'has-text-warning';
      }
      return color;
    }
  },
  watch: {
    item: {
      handler: function handler() {
        this.setSupplementaryNo();
        this.setAssessmentValueDiff();
      },
      deep: true
    }
  },
  created: function created() {
    this.setSupplementaryNo();
    this.setAssessmentValueDiff();
  },
  updated: function updated() {},
  mounted: function mounted() {},
  methods: {
    setAssessmentValueDiff: function setAssessmentValueDiff() {
      if (this.itemChanged(this.item, this.item.lastQuotedAssessment, this.item.lastAuthorisedAssessment, this.quotingMethod)) {
        if ((this.item.deleted || this.item.isDeleted) && this.item.lastAuthorisedAssessment && !this.item.lastAuthorisedAssessment.isQuoteItemDeleted) {
          this.authorisedValueDiff = -1;
        } else this.authorisedValueDiff = this.totalValue(this.item) - this.totalValue(this.item.lastAuthorisedAssessment);
      } else {
        this.authorisedValueDiff = this.getAssessmentDiff(this.item.lastQuotedAssessment, this.item.lastAuthorisedAssessment);
      }
    },
    setSupplementaryNo: function setSupplementaryNo() {
      if (this.itemChanged(this.item, this.item.lastQuotedAssessment, this.item.lastAuthorisedAssessment, this.quotingMethod)) {
        this.supplementaryNo = this.nextAssessmentNumber;
      } else {
        var _this$item$lastQuoted, _this$item$lastAuthor;
        this.supplementaryNo = ((_this$item$lastQuoted = this.item.lastQuotedAssessment) === null || _this$item$lastQuoted === void 0 ? void 0 : _this$item$lastQuoted.subQuoteNo) || ((_this$item$lastAuthor = this.item.lastAuthorisedAssessment) === null || _this$item$lastAuthor === void 0 ? void 0 : _this$item$lastAuthor.subQuoteNo);
      }
    },
    getAssessmentDiff: function getAssessmentDiff(quotedAssessment, authorisedAssessment) {
      if (!quotedAssessment && !authorisedAssessment) return null;
      if (quotedAssessment && authorisedAssessment) {
        return this.totalValue(authorisedAssessment) - this.totalValue(quotedAssessment);
      } else if (authorisedAssessment && !quotedAssessment) {
        return 1; // a positive number
      } else {
        return null;
      }
    },
    getSupplementaryNo: function getSupplementaryNo(assessment) {
      if (assessment[0]) {
        return assessment[0].subQuoteNo;
      } else if (assessment[1]) {
        return assessment[1].subQuoteNo;
      }
      return null;
    },
    totalValue: function totalValue(assessmentDetail) {
      var _this2 = this;
      if (!assessmentDetail) return null;
      if (this.isItemlabour) {
        return assessmentDetail.dollarValue;
      } else if (_enums__WEBPACK_IMPORTED_MODULE_6__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Part';
      }).some(function (c) {
        return c.code === _this2.item.itemType;
      })) {
        return assessmentDetail.itemQuantity * assessmentDetail.markupValue;
      } else if (_enums__WEBPACK_IMPORTED_MODULE_6__["ItemCategoryCodeTypes"].itemTypes.filter(function (c) {
        return c.category === 'Misc' || c.category === 'Sublet';
      }).some(function (c) {
        return c.code === _this2.item.itemType;
      })) {
        return assessmentDetail.value;
      }
    },
    hasTagValue: function hasTagValue(assessment) {
      if (assessment !== null && assessment !== void 0 && assessment.isQuoteItemDeleted || assessment !== null && assessment !== void 0 && assessment.reportOnly || !assessment) {
        return true;
      } else {
        return false;
      }
    },
    getTextColor: function getTextColor(assessment) {
      var quotedAssessment = null;
      var authorisedAssessment = null;
      if (assessment.length === 2) {
        quotedAssessment = assessment[0];
        authorisedAssessment = assessment[1];
      }
      var diff = this.getAssessmentDiff(quotedAssessment, authorisedAssessment);
      if (diff > 0) {
        return 'has-text-success';
      } else if (diff < 0) {
        return 'has-text-danger';
      } else {
        return '';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.hasAssessments ? _c("tippy", {
    attrs: {
      arrow: "",
      theme: "".concat(_vm.$theme.name),
      placement: "top"
    }
  }, [_c("div", {
    staticClass: "card narrow-line"
  }, [_c("div", {
    staticClass: "card-header p-1"
  }, [_c("span", [_vm._v("Assessment History")])]), _c("div", {
    staticClass: "card-body p-1"
  }, [_c("table", {
    staticClass: "table is-narrow is-fullwidth"
  }, [_c("thead", [_c("tr", [_c("th"), _c("th", {
    staticClass: "has-vertical-middle",
    attrs: {
      colspan: _vm.numValuesInColumn
    }
  }, [_c("span", {
    staticClass: "badge badge-sm"
  }, [_vm._v("Quoted")])]), _c("th", {
    staticClass: "has-vertical-middle",
    attrs: {
      colspan: _vm.numValuesInColumn
    }
  }, [_c("span", {
    staticClass: "badge badge-sm"
  }, [_vm._v("Authorised")])])])]), _c("tbody", _vm._l(_vm.itemAssessments, function (assessment) {
    return _c("tr", {
      key: _vm.getSupplementaryNo(assessment)
    }, [_c("td", {
      staticClass: "label-xxs has-vertical-middle"
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.getSupplementaryNo(assessment) === 0,
        expression: "getSupplementaryNo(assessment) === 0"
      }]
    }, [_vm._v("Original")]), _c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.getSupplementaryNo(assessment) > 0,
        expression: "getSupplementaryNo(assessment) > 0"
      }]
    }, [_vm._v("Supp #" + _vm._s(_vm.getSupplementaryNo(assessment)))])]), _c("td", {
      staticClass: "has-vertical-middle",
      class: _vm.hasTagValue(assessment[0]) ? "has-text-centered" : "",
      attrs: {
        colspan: _vm.hasTagValue(assessment[0]) ? _vm.numValuesInColumn : 1
      }
    }, [assessment[0] ? _c("div", [assessment[0].isQuoteItemDeleted ? _c("div", [_c("span", {
      staticClass: "badge badge-sm tag is-danger"
    }, [_vm._v(" Deleted ")])]) : assessment[0].reportOnly ? _c("div", [_c("span", {
      staticClass: "badge badge-sm tag is-info"
    }, [_vm._v(" Report Only ")])]) : _c("div", [_c("div", [_vm.numValuesInColumn > 1 ? _c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(assessment[0].hourValue)) + "h ")]) : _c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.totalValue(assessment[0]), _vm.$userInfo.locale)) + " ")])])])]) : _vm._e()]), _vm.numValuesInColumn > 1 && !_vm.hasTagValue(assessment[0]) ? _c("td", {
      staticClass: "has-vertical-middle"
    }, [_c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.totalValue(assessment[0]), _vm.$userInfo.locale)) + " ")])]) : _vm._e(), _c("td", {
      staticClass: "has-vertical-middle",
      class: _vm.hasTagValue(assessment[1]) ? "has-text-centered" : "",
      attrs: {
        colspan: _vm.hasTagValue(assessment[1]) ? _vm.numValuesInColumn : 1
      }
    }, [assessment[1] ? _c("div", [assessment[1].isQuoteItemDeleted ? _c("div", [_c("span", {
      staticClass: "badge badge-sm tag is-danger"
    }, [_vm._v(" Deleted ")])]) : assessment[1].reportOnly ? _c("div", [_c("span", {
      staticClass: "badge badge-sm tag is-info"
    }, [_vm._v(" Report Only ")])]) : _c("div", [_c("div", {
      class: _vm.getTextColor(assessment)
    }, [_vm.numValuesInColumn > 1 ? _c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(assessment[1].hourValue)) + "h ")]) : _c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.totalValue(assessment[1]), _vm.$userInfo.locale)) + " ")])])])]) : _c("div", [_c("span", {
      staticClass: "badge badge-sm tag is-warning"
    }, [_vm._v("Pending")])])]), _vm.numValuesInColumn > 1 && !_vm.hasTagValue(assessment[1]) ? _c("td", {
      class: _vm.getTextColor(assessment)
    }, [assessment[1] ? _c("span", {
      staticClass: "badge badge-sm"
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.totalValue(assessment[1]), _vm.$userInfo.locale)) + " ")]) : _vm._e()]) : _vm._e()]);
  }), 0)])])])]) : _vm._e(), _c("div", [_c("div", {
    staticClass: "supp-container"
  }, [_c("span", {
    staticClass: "has-text-weight-semibold",
    class: "is-size-".concat(_vm.iconSize, " ").concat(_vm.supplementaryIconColour)
  }, [_vm._v(_vm._s(_vm.supplementaryNo > 0 ? _vm.supplementaryNo : "O"))]), _vm.authorisedValueDiff > 0 ? _c("span", {
    staticClass: "change-icon",
    class: "is-size-".concat(_vm.iconSize + 3)
  }, [_c("i", {
    staticClass: "has-text-success mdi mdi-arrow-up-box"
  })]) : _vm._e(), _vm.authorisedValueDiff < 0 ? _c("span", {
    staticClass: "change-icon",
    class: "is-size-".concat(_vm.iconSize + 3)
  }, [_c("i", {
    staticClass: "has-text-danger mdi mdi-arrow-down-box"
  })]) : _vm._e()])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".narrow-line[data-v-295002c8] {\n  line-height: 1;\n  white-space: nowrap;\n}\n.supplement-container[data-v-295002c8] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  gap: 7px;\n}\n.authorised-icon[data-v-295002c8] {\n  height: 10px;\n  width: 10px;\n}\ntd[data-v-295002c8] {\n  padding-left: 0.5rem !important;\n}\n.supp-container[data-v-295002c8] {\n  position: relative;\n}\n.change-icon[data-v-295002c8] {\n  position: absolute;\n  top: 0;\n  right: 0;\n  margin-right: -0.1em;\n  margin-top: -0.1em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("44e7cb80", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/components/SupplementaryIcon.vue":
/*!**********************************************************!*\
  !*** ./src/views/quote/components/SupplementaryIcon.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true */ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true");
/* harmony import */ var _SupplementaryIcon_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SupplementaryIcon.vue?vue&type=script&lang=js */ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true */ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SupplementaryIcon_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "295002c8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/SupplementaryIcon.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SupplementaryIcon.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=style&index=0&id=295002c8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_style_index_0_id_295002c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/SupplementaryIcon.vue?vue&type=template&id=295002c8&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupplementaryIcon_vue_vue_type_template_id_295002c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-builder-chunk~quote-components-chunk.js.map