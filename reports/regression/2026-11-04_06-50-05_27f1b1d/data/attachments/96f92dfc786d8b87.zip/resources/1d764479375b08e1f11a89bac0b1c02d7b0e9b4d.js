(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-estimage-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./mixins/QuoteStoreMixin */ "./src/views/quote/mixins/QuoteStoreMixin.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_EstImageSendQuoteModal_vue__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/EstImageSendQuoteModal.vue */ "./src/views/quote/components/EstImageSendQuoteModal.vue");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_XmlViewer__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/XmlViewer */ "./src/components/XmlViewer/index.js");
/* harmony import */ var _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/BulmaMessage/BulmaMessage.vue */ "./src/components/BulmaMessage/BulmaMessage.vue");
/* harmony import */ var _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/Notification/NotificationBox.vue */ "./src/components/Notification/NotificationBox.vue");

























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteEstImage',
  inject: ['$vv'],
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__["default"],
    EstImageSendQuoteModal: _components_EstImageSendQuoteModal_vue__WEBPACK_IMPORTED_MODULE_19__["default"],
    XmlViewerModal: _components_XmlViewer__WEBPACK_IMPORTED_MODULE_21__["XmlViewerModal"],
    NotificationBox: _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_23__["default"],
    BulmaMessage: _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_22__["default"]
  },
  mixins: [_mixins__WEBPACK_IMPORTED_MODULE_12__["QuoteNotificationMixin"], _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_13__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_16__["DateTimeFiltersMixin"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      innerValue: null,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_14__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_14__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 8
      },
      isTableLoading: false,
      isSendQuoteModalActive: false,
      isUploadImage: false,
      isXmlViewerModalActive: false,
      modalTitle: '',
      modalIcon: '',
      selectedImageIds: [],
      modalType: '',
      messageType: 'EstImage',
      isMessageModalActive: false,
      bulmaMessageType: _enums__WEBPACK_IMPORTED_MODULE_11__["BulmaMessageType"].Info,
      notificationType: _enums__WEBPACK_IMPORTED_MODULE_11__["NotificationBoxType"].Default,
      messageTitle: '',
      notificationTitle: '',
      notificationMessage: ''
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_14__["RemarkColumns"];
    },
    remarkTotalRows: function remarkTotalRows() {
      return this.value.otherRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_11__["RemarkTypes"].EstImageSystemRemark && !r.isDeleted;
      }).length;
    },
    activeRemarks: function activeRemarks() {
      return this.value.otherRemarks.filter(function (r) {
        return r.remarkTypeId === _enums__WEBPACK_IMPORTED_MODULE_11__["RemarkTypes"].EstImageSystemRemark && !r.isDeleted;
      });
    },
    pagedRemarks: function pagedRemarks() {
      return this.activeRemarks.slice((this.filter.pageIndex - 1) * this.filter.pageSize, this.filter.pageIndex * this.filter.pageSize);
    },
    isSubmitQuoteEnabled: function isSubmitQuoteEnabled() {
      return !this.value.readOnly && !this.value.isAssessmentEnabled;
    },
    isSubmitInvoiceEnabled: function isSubmitInvoiceEnabled() {
      return this.value.invoices.some(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_11__["InvoiceTypes"].Quote && !i.deleted;
      });
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    //this.innerValue = _cloneDeep(this.value)
    this.$emit('save', false, false);
    this.loading = true;
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(this.value);
    this.loading = false;
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_11__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_17___default()(_this.value);
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_11__["EventHubTypes"].EntitySaved);
  },
  methods: {
    openUploadImageModal: function openUploadImageModal() {
      if (this.$licenceExpired) return;
      this.modalType = 'ImageSelect';
      this.isSendQuoteModalActive = true;
      this.modalTitle = 'Upload images';
      this.modalIcon = 'mdi-image-multiple';
    },
    openUploadDocumentModal: function openUploadDocumentModal() {
      if (this.$licenceExpired) return;
      this.modalType = 'DocumentSelect';
      this.isSendQuoteModalActive = true;
      this.modalTitle = 'Upload documents';
      this.modalIcon = 'mdi-file-document-multiple';
    },
    openSendQuoteModal: function openSendQuoteModal() {
      if (this.$licenceExpired) return;
      this.modalType = 'SendQuote';
      this.isSendQuoteModalActive = true;
      this.modalTitle = 'Send Quote';
      this.modalIcon = 'mdi-upload';
    },
    openUpdateVehicleModal: function openUpdateVehicleModal() {
      this.modalType = 'UpdateVehicle';
      this.isSendQuoteModalActive = true;
      this.modalTitle = 'Update Vehicle';
      this.modalIcon = 'mdi-car';
    },
    openSendInvoiceModal: function openSendInvoiceModal() {
      if (this.$licenceExpired) return;
      this.modalType = 'SendInvoice';
      this.isSendQuoteModalActive = true;
      this.modalTitle = 'Send Invoice';
      this.modalIcon = 'mdi-currency-usd';
    },
    closeModal: function closeModal() {
      this.isSendQuoteModalActive = false;
      this.modalType = '';
      this.modalTitle = '';
      this.modalIcon = '';
    },
    viewMessages: function viewMessages() {
      this.isXmlViewerModalActive = true;
    },
    updateVehicle: function updateVehicle() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var sendQuoteObject;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!_this2.$licenceExpired) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              _this2.$showSpinner('Submitting');
              sendQuoteObject = new _classes__WEBPACK_IMPORTED_MODULE_20__["EstImageSendQuoteModel"]();
              sendQuoteObject.quoteId = _this2.value.quoteId;
              _context.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_18__["EstImageService"].updateVehicle(sendQuoteObject);
            case 2:
              _this2.showSuccessToast('Vehicle details submitted.');
              _this2.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_11__["EventHubTypes"].EntityReload);
              _this2.$hideSpinner();
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getSubmitSpinnerMessage: function getSubmitSpinnerMessage(sendObject) {
      switch (this.modalType) {
        case 'ImageSelect':
          {
            var count = sendObject.imageIds ? sendObject.imageIds.length : 0;
            return "Uploading ".concat(count, " image(s) to EstImage...");
          }
        case 'DocumentSelect':
          {
            var _count = sendObject.documentIds ? sendObject.documentIds.length : 0;
            return "Uploading ".concat(_count, " document(s) to EstImage...");
          }
        case 'SendInvoice':
          return 'Submitting invoice to EstImage...';
        case 'UpdateVehicle':
          return 'Updating vehicle in EstImage...';
        default:
          return 'Submitting to EstImage...';
      }
    },
    submit: function submit(sendObject) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var uploadResult, data, _uploadResult, _data, _response, response, _response2, _response3, _response4, _response5, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!_this3.$licenceExpired) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              sendObject.quoteId = _this3.innerValue.quoteId;
              _this3.$showSpinner(_this3.getSubmitSpinnerMessage(sendObject));
              _context2.p = 2;
              if (!(_this3.modalType === 'ImageSelect')) {
                _context2.n = 4;
                break;
              }
              _context2.n = 3;
              return _services__WEBPACK_IMPORTED_MODULE_18__["EstImageService"].uploadImages(sendObject);
            case 3:
              uploadResult = _context2.v;
              data = uploadResult === null || uploadResult === void 0 ? void 0 : uploadResult.data;
              if (data !== null && data !== void 0 && data.error) {
                // Some/all images were not sent (typically a re-upload of images already in
                // EstImage). Show the per-image detail in the message dialog rather than a
                // toast so the guidance stays on screen.
                _this3.showMessageUpload('Upload images to EstImage', data);
              } else {
                _this3.showSuccessToast('Image(s) submitted.');
              }
              _context2.n = 11;
              break;
            case 4:
              if (!(_this3.modalType === 'DocumentSelect')) {
                _context2.n = 6;
                break;
              }
              _context2.n = 5;
              return _services__WEBPACK_IMPORTED_MODULE_18__["EstImageService"].uploadDocuments(sendObject);
            case 5:
              _uploadResult = _context2.v;
              _data = _uploadResult === null || _uploadResult === void 0 ? void 0 : _uploadResult.data;
              if (_data !== null && _data !== void 0 && _data.error) {
                // Some/all documents failed (e.g. duplicates). Show it in the message dialog -
                // the same treatment an image upload failure gets - so the per-document detail
                // stays on screen instead of vanishing with a toast.
                _this3.showMessageUpload('Upload documents to EstImage', _data);
              } else {
                _this3.showSuccessToast('Document(s) submitted.');
              }
              _context2.n = 11;
              break;
            case 6:
              if (!(_this3.modalType === 'SendQuote')) {
                _context2.n = 8;
                break;
              }
              _context2.n = 7;
              return _services__WEBPACK_IMPORTED_MODULE_18__["EstImageService"].sendQuote(sendObject);
            case 7:
              response = _context2.v;
              if ((_response = response) !== null && _response !== void 0 && (_response = _response.data) !== null && _response !== void 0 && _response.error) {
                _this3.$notification.openNotificationWithType('danger', 'Error on Sending Quote to EstImage', (_response2 = response) === null || _response2 === void 0 || (_response2 = _response2.data) === null || _response2 === void 0 ? void 0 : _response2.details);
              } else {
                _this3.showSuccessToast('Quote details submitted.');
              }
              _context2.n = 11;
              break;
            case 8:
              if (!(_this3.modalType === 'SendInvoice')) {
                _context2.n = 10;
                break;
              }
              _context2.n = 9;
              return _services__WEBPACK_IMPORTED_MODULE_18__["EstImageService"].sendInvoice(sendObject);
            case 9:
              response = _context2.v;
              if ((_response3 = response) !== null && _response3 !== void 0 && (_response3 = _response3.data) !== null && _response3 !== void 0 && _response3.error) {
                if (((_response4 = response) === null || _response4 === void 0 || (_response4 = _response4.data) === null || _response4 === void 0 ? void 0 : _response4.details) === 'CLAIMS_HANDLE_BY_BROKER') {
                  _this3.showMessageClaimHandleByBroker();
                } else {
                  _this3.$notification.openNotificationWithType('danger', 'Error on Sending Invoice to EstImage', (_response5 = response) === null || _response5 === void 0 || (_response5 = _response5.data) === null || _response5 === void 0 ? void 0 : _response5.details);
                }
              } else {
                _this3.showSuccessToast('Invoice details submitted.');
              }
              _context2.n = 11;
              break;
            case 10:
              _this3.$hideSpinner();
              _this3.closeModal();
              return _context2.a(2);
            case 11:
              _context2.n = 13;
              break;
            case 12:
              _context2.p = 12;
              _t = _context2.v;
              // Per-file upload outcomes come back as a 200 with error/details and are shown
              // above - reaching here means the request itself failed (auth, validation, network),
              // which the fq-api interceptor has already surfaced via the global error dialog.
              _this3.$hideSpinner();
              _this3.closeModal();
            case 13:
              _context2.p = 13;
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_11__["EventHubTypes"].EntityReload);
              _this3.$hideSpinner();
              _this3.closeModal();
              return _context2.f(13);
            case 14:
              return _context2.a(2);
          }
        }, _callee2, null, [[2, 12, 13, 14]]);
      }))();
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
    },
    sort: function sort(name, order) {},
    showMessageUpload: function showMessageUpload(title, data) {
      // Shared by the image and document uploads. Partial successes are a warning (whatever
      // uploaded is already saved); nothing sent is an error. Details is plain text from the
      // API, so escape it before it goes through v-html and keep its line breaks. The first
      // line is the summary, the rest the per-file list plus the guidance.
      var details = this.toHtmlLines(data.details);
      var separator = details.indexOf('<br>');
      this.isMessageModalActive = true;
      this.bulmaMessageType = data.successCount > 0 ? _enums__WEBPACK_IMPORTED_MODULE_11__["BulmaMessageType"].Warning : _enums__WEBPACK_IMPORTED_MODULE_11__["BulmaMessageType"].Danger;
      this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_11__["NotificationBoxType"].Default;
      this.messageTitle = title;
      this.notificationTitle = separator > -1 ? details.substring(0, separator) : details;
      this.notificationMessage = separator > -1 ? details.substring(separator + 4) : '';
    },
    toHtmlLines: function toHtmlLines(text) {
      var escaped = document.createElement('div');
      escaped.textContent = text || '';
      return escaped.innerHTML.replace(/\r\n|\r|\n/g, '<br>');
    },
    showMessageClaimHandleByBroker: function showMessageClaimHandleByBroker() {
      this.isMessageModalActive = true;
      this.bulmaMessageType = _enums__WEBPACK_IMPORTED_MODULE_11__["BulmaMessageType"].Warning;
      this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_11__["NotificationBoxType"].Default;
      this.messageTitle = 'Invoice Payment Not Sent via Estimage';
      this.notificationTitle = 'The payment workflow for the specific claim is handled by Insurer or Broker, and not directly through Estimage.<br><br><b>Action Required:</b> You must email the invoice directly to the correct party.';
      this.notificationMessage = 'You can find the required email address in the original claim file under the \'<b>Assessor</b>\' or \'<b>Claim Handler</b>\' section of the claim header in the Estimage portal.';
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-estimage-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_vm._m(0), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "dropdown is-right is-hoverable"
  }, [_vm._m(1), _c("div", {
    staticClass: "dropdown-menu",
    attrs: {
      id: "dropdown-menu-pnet",
      role: "menu"
    }
  }, [_c("div", {
    staticClass: "dropdown-content"
  }, [_vm.isSubmitQuoteEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.$company.setting.estimageOnlineEnabled,
      "is-licence-disabled": _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.openSendQuoteModal();
      }
    }
  }, [_vm._m(2), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Quote")])]) : _vm._e(), _vm.isSubmitInvoiceEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.$company.setting.estimageOnlineEnabled,
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.openSendInvoiceModal();
      }
    }
  }, [_vm._m(3), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Tax Invoice")])]) : _vm._e(), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.$company.setting.estimageOnlineEnabled,
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.updateVehicle();
      }
    }
  }, [_vm._m(4), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Update Vehicle Details")])]), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.$company.setting.estimageOnlineEnabled,
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.openUploadImageModal();
      }
    }
  }, [_vm._m(5), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Upload images")])]), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-disabled": !_vm.$licenceExpired && !_vm.$company.setting.estimageOnlineEnabled,
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.openUploadDocumentModal();
      }
    }
  }, [_vm._m(6), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Upload documents")])]), _c("hr", {
    staticClass: "dropdown-divider"
  }), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.viewMessages();
      }
    }
  }, [_vm._m(7), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("View Messages")])])])])])])]), !_vm.$company.setting.estimageOnlineEnabled ? _c("div", {
    staticClass: "notification is-warning"
  }, [_c("p", [_vm._v(" Estimage is not set up for communication between FlexiQuote and EstImage. ")]), _vm.$user.info.isCustomerAdministrator || _vm.$user.info.isSupportUser || _vm.$user.info.isSystemAdministrator ? _c("router-link", {
    attrs: {
      to: {
        name: "CompanyIntegrationSetting",
        params: {
          defaultActiveTabIndex: 9
        }
      }
    }
  }, [_vm._v("Set up EstImage")]) : _c("div", [_vm._v("We highly recommend contacting FlexiQuote Administrator to enable the integration.")])], 1) : _vm._e()]), _c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Remarks")]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.remarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "is-remark"
    }, [_c("div", [_vm._v(_vm._s(remark.remarks))])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), _vm.isSendQuoteModalActive ? _c("est-image-send-quote-modal", {
    attrs: {
      active: _vm.isSendQuoteModalActive,
      value: _vm.innerValue,
      "modal-type": _vm.modalType,
      title: _vm.modalTitle,
      "icon-name": "mdi-upload"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSendQuoteModalActive = $event;
      },
      close: _vm.closeModal,
      submit: _vm.submit
    }
  }) : _vm._e(), _vm.isXmlViewerModalActive ? _c("xml-viewer-modal", {
    attrs: {
      active: _vm.isXmlViewerModalActive,
      "quote-id": _vm.value.quoteId,
      "message-type": _vm.messageType,
      "page-size": 10
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isXmlViewerModalActive = $event;
      },
      close: function close($event) {
        _vm.isXmlViewerModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("View " + _vm._s(_vm.messageType) + " Messages")])]) : _vm._e(), _vm.isMessageModalActive ? _c("bulma-message", {
    attrs: {
      value: _vm.isMessageModalActive,
      title: _vm.messageTitle,
      type: _vm.bulmaMessageType
    },
    on: {
      close: function close($event) {
        _vm.isMessageModalActive = false;
      }
    }
  }, [_c("p", {
    staticClass: "is-size-6 mt-2",
    domProps: {
      innerHTML: _vm._s(_vm.notificationTitle)
    }
  }), _c("br"), _c("notification-box", {
    staticClass: "mt-3",
    attrs: {
      type: _vm.notificationType
    },
    scopedSlots: _vm._u([{
      key: "text-content",
      fn: function fn() {
        return [_c("div", {
          staticClass: "container"
        }, [_c("div", {
          staticClass: "columns"
        }, [_c("div", {
          staticClass: "column"
        }, [_c("p", {
          staticClass: "is-size-6",
          domProps: {
            innerHTML: _vm._s(_vm.notificationMessage)
          }
        })])])])];
      },
      proxy: true
    }], null, false, 1185385178)
  })], 1) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("EstImage")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "dropdown-trigger"
  }, [_c("button", {
    staticClass: "button",
    attrs: {
      "aria-haspopup": "true",
      "aria-controls": "dropdown-menu-pnet"
    }
  }, [_c("span", [_vm._v("EstImage")]), _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-chevron-down",
    attrs: {
      "aria-hidden": "true"
    }
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-upload mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-currency-usd mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-car mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-image-multiple mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-file-document-multiple mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-file-code mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-estimage-licence-expired .dropdown-item.is-licence-disabled {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-estimage-licence-expired .dropdown-item.is-licence-disabled > .icon,\n.quote-estimage-licence-expired .dropdown-item.is-licence-disabled > .dropdown-item-text {\n  opacity: 0.5;\n}\n.quote-estimage-licence-expired .dropdown-item.is-licence-disabled:hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 50%;\n  right: 100%;\n  -webkit-transform: translate(-0.5rem, -50%);\n          transform: translate(-0.5rem, -50%);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "a.dropdown-item-has-icon[data-v-1dbf7318] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\nspan.dropdown-item-text[data-v-1dbf7318] {\n  padding-left: 5px;\n}\n.is-disabled[data-v-1dbf7318] {\n  opacity: 0.5;\n  pointer-events: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("f4f38642", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("11147cf5", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/XmlViewer/index.js":
/*!*******************************************!*\
  !*** ./src/components/XmlViewer/index.js ***!
  \*******************************************/
/*! exports provided: XmlViewerModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XmlViewerModal", function() { return XmlViewerModal; });
// import XmlViewerModal from './XmlViewerModal'
var XmlViewerModal = function XmlViewerModal(r) {
  return Promise.all(/*! require.ensure | xmlviewer-components-chunk */[__webpack_require__.e("audittrail-chunk~estimagemessage-chunk~estimagemessageview-chunk~ormmessage-chunk~ormmessageview-chu~f9dcd210"), __webpack_require__.e("audittrail-chunk~ormmessage-chunk~ormmessageview-chunk~pnetmessage-chunk~pnetmessageview-chunk~quote~6a43fb9b"), __webpack_require__.e("xmlviewer-components-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./XmlViewerModal.vue */ "./src/components/XmlViewer/XmlViewerModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/views/quote/QuoteEstImage.vue":
/*!*******************************************!*\
  !*** ./src/views/quote/QuoteEstImage.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true */ "./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true");
/* harmony import */ var _QuoteEstImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteEstImage.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss */ "./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss");
/* harmony import */ var _QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true */ "./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteEstImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1dbf7318",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteEstImage.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss":
/*!****************************************************************************************!*\
  !*** ./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=0&id=1dbf7318&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_0_id_1dbf7318_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=style&index=1&id=1dbf7318&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_style_index_1_id_1dbf7318_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true":
/*!*************************************************************************************!*\
  !*** ./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteEstImage.vue?vue&type=template&id=1dbf7318&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteEstImage_vue_vue_type_template_id_1dbf7318_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/mixins/QuoteStoreMixin.js":
/*!***************************************************!*\
  !*** ./src/views/quote/mixins/QuoteStoreMixin.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: {}
});

/***/ })

}]);
//# sourceMappingURL=quote-estimage-chunk.js.map