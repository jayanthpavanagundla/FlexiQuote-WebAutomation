(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AppUserSideMenu',
  props: {
    minWidth: {
      type: Number,
      default: 18
    },
    visibleWidth: {
      type: Number,
      default: 1008
    },
    fixedMenu: {
      type: Boolean,
      default: false
    },
    currentRouteName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      inlineStyle: '',
      windowWidth: 0,
      windowHeigth: 0,
      toggleSideMenu: true,
      isTouchDevice: false
    };
  },
  computed: {},
  watch: {
    minWidth: function minWidth(newVal, oldVal) {
      this.inlineStyle = this.minWidth.toString() + 'vw';
    }
  },
  created: function created() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_3__["EventHubTypes"].ToggleSideMenu, function (data) {
      _this.handleSideMenuEvent(data);
    });
  },
  mounted: function mounted() {
    this.inlineStyle = this.minWidth.toString() + 'vw';
    this.$nextTick(function () {
      window.addEventListener('resize', this.getWindowWidth);
      window.addEventListener('resize', this.getWindowHeight);
      this.getWindowWidth();
      this.getWindowHeight();
    });
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.getWindowWidth);
    window.removeEventListener('resize', this.getWindowHeight);
  },
  methods: {
    handleSideMenuEvent: function handleSideMenuEvent(data) {
      this.toggleSideMenu = data || this.fixedMenu && !this.isTouchDevice;
    },
    getWindowWidth: function getWindowWidth(event) {
      this.windowWidth = window.innerWidth; // document.documentElement.clientWidth
      if (this.toggleSideMenu && this.windowWidth <= this.visibleWidth) {
        this.toggleSideMenu = false;
        this.isTouchDevice = true;
        this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_3__["EventHubTypes"].AutoHideSideMenu, true);
      } else if (!this.toggleSideMenu && this.windowWidth > this.visibleWidth) {
        this.toggleSideMenu = true;
        this.isTouchDevice = false;
        this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_3__["EventHubTypes"].AutoHideSideMenu, false);
      }
    },
    getWindowHeight: function getWindowHeight(event) {
      this.windowHeight = window.innerHeight; // document.documentElement.clientHeight
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserSideMenu.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserSideMenu.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _user_AppUserSideMenu_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../user/AppUserSideMenu.vue */ "./src/views/user/AppUserSideMenu.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/user/route-types.js");
/* harmony import */ var _views_superadmin_user_route_types_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../views/superadmin/user/route-types.js */ "./src/views/superadmin/user/route-types.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserSideMenu',
  inject: ['$vv'],
  components: {
    AppUserSideMenu: _user_AppUserSideMenu_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    value: {
      type: Object,
      required: true
    },
    entityName: {
      type: String,
      default: ''
    },
    isMobileAppUser: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      if (this.$userInfo.isSystemAdministrator && !this.$userInfo.isSupportUser) {
        return _views_superadmin_user_route_types_js__WEBPACK_IMPORTED_MODULE_2__["default"];
      } else return _route_types__WEBPACK_IMPORTED_MODULE_1__["default"];
    },
    validProfileGroup: function validProfileGroup() {
      return !this.$v.profileAddressesGroup.$error && !this.$v.profileEmailsGroup.$error && !this.$v.profilePhonesGroup.$error;
    }
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserView.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserView.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_AppDetailHeader_AppDetailHeader_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/AppDetailHeader/AppDetailHeader.vue */ "./src/components/AppDetailHeader/AppDetailHeader.vue");
/* harmony import */ var _UserSideMenu_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./UserSideMenu.vue */ "./src/views/user/UserSideMenu.vue");
/* harmony import */ var _storeMixin_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./storeMixin.js */ "./src/views/user/storeMixin.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./route-types */ "./src/views/user/route-types.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _UserValidation__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./UserValidation */ "./src/views/user/UserValidation.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../services */ "./src/services/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _auth_ErrorMessage__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../auth/ErrorMessage */ "./src/views/auth/ErrorMessage.js");
/* harmony import */ var _views_superadmin_user_route_types__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../views/superadmin/user/route-types */ "./src/views/superadmin/user/route-types.js");



















// import { EventHubTypes } from '../../enums'
 // Import the modal


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserView',
  components: {
    AppDetailHeader: _components_AppDetailHeader_AppDetailHeader_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    UserSideMenu: _UserSideMenu_vue__WEBPACK_IMPORTED_MODULE_11__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_19__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_19__["SaveConflictModal"]
  },
  mixins: [_storeMixin_js__WEBPACK_IMPORTED_MODULE_12__["default"], _UserValidation__WEBPACK_IMPORTED_MODULE_16__["default"]],
  props: {
    returnUrl: String
  },
  data: function data() {
    return {
      entity: null,
      toRoute: null,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isSkipSave: false,
      companyModules: [],
      isMobileUser: false
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error || this.$v.contactsGroup.$error ||
      // || this.$v.emailsPhonesGroup.$error || this.$v.addressesGroup.$error || this.$v.contactsGroup.$error
      this.$v.profileNameGroup.$error || this.$v.profileAddressesGroup.$error || this.$v.profileEmailsGroup.$error || this.$v.profilePhonesGroup.$error;
    },
    isAllowedAccessNewPWA: function isAllowedAccessNewPWA() {
      return this.companyModules.some(function (module) {
        return module.modDesc === _enums__WEBPACK_IMPORTED_MODULE_9__["ModuleTypes"].FlexiquotePwaAccess.name && module.enabled;
      });
    },
    isMobileAppUser: function isMobileAppUser() {
      return this.isMobileUser;
    }
  },
  created: function created() {
    this.getEntity();
    this.getCompanyModules();
  },
  mounted: function mounted() {
    this.$v.$touch();
  },
  beforeDestroy: function beforeDestroy() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_9__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_9__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_9__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|user|returnUrl"));
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _this.$showSpinner();
              _context.p = 1;
              if (reset) {
                _this.clearSnapshots(_this.$route.params.userId);
              }
              if (_this.currentSnapshot) {
                _context.n = 2;
                break;
              }
              _context.n = 2;
              return _this.getStoreItem(_this.$route.params.userId);
            case 2:
              _this.entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(_this.currentSnapshot);
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('', _t);
            case 4:
              _this.$hideSpinner();
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
      if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_15___default()(this.returnRoute)) {
        this.$router.push({
          path: this.returnRoute.path,
          query: this.returnRoute.query
        });
      } else if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        if (this.returnUrl) {
          if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
            this.isUnsavedModalActive = true;
          } else {
            this.clearSessionStorage();
            this.clearSnapshots(this.entity.userId);
            this.$showSpinner('Returning...');
          }
        } else {
          if (this.entity.isNew && this.isSkipSave) {
            this.clearSnapshots(this.entity.userId);
          }
          if (this.$userInfo.isSystemAdministrator && !this.$userInfo.isSupportUser) {
            this.$router.push({
              name: _views_superadmin_user_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].UserListView.name
            });
            return;
          } else this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_14__["default"].UserListView.name
          });
        }
      }
    },
    save: function save() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var message, title, response, errormessage, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              message = 'Validation errors. Please fix before saving';
              title = 'User';
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity));
              _this2.$v.$touch();
              // this.$v.entity.profile.assetEmails.$touch()
              // this.$v.entity.profile.assetPhones.$touch()
              // this.$v.entity.profile.assetAddresses.$touch()
              if (_this2.validateError) {
                _context2.n = 13;
                break;
              }
              if (!_this2.entity.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_17__["UserService"].postUser(_this2.entity);
            case 2:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 3:
              if (!_this2.snapshotDiff) {
                _context2.n = 5;
                break;
              }
              _context2.n = 4;
              return _services__WEBPACK_IMPORTED_MODULE_17__["UserService"].putUser(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity), _this2.snapshotDiff);
            case 4:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 5:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
              return _context2.a(2, false);
            case 6:
              if (!_this2.isSaveContinue) {
                _context2.n = 7;
                break;
              }
              _this2.$notification.openNotificationWithType('success', title, 'Save successful');
              _context2.n = 10;
              break;
            case 7:
              if (!(response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_18__["default"].NO_CONTENT)) {
                _context2.n = 9;
                break;
              }
              _context2.n = 8;
              return _this2.getEntity(true);
            case 8:
              // Refresh page data
              // this.dataChanged = false
              _this2.$refs.currentChild && _this2.$refs.currentChild.$emit('refreshProfile', _this2.entity);
              _this2.$notification.openNotificationWithType('success', title, 'Save successful');
              _context2.n = 10;
              break;
            case 9:
              if (response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_18__["default"].CREATED) {
                // await this.getEntity(true)
                // this.$refs.currentChild && this.$refs.currentChild.$emit('refreshProfile', this.entity)
                _this2.entity.isNew = false;
                _this2.clearSnapshots(_this2.entity.userId);
                _this2.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity));
                _this2.$notification.openNotificationWithType('success', title, 'New user added');
              }
            case 10:
              if (!(_this2.$userInfo.isSystemAdministrator && !_this2.$userInfo.isSupportUser)) {
                _context2.n = 11;
                break;
              }
              _this2.$router.push({
                name: _views_superadmin_user_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].UserListView.name
              });
              return _context2.a(2);
            case 11:
              _this2.$router.push({
                name: _route_types__WEBPACK_IMPORTED_MODULE_14__["default"].UserListView.name
              });
            case 12:
              return _context2.a(2, true);
            case 13:
              _this2.$notification.openNotificationWithType('danger', title, message);
              return _context2.a(2, false);
            case 14:
              _context2.n = 16;
              break;
            case 15:
              _context2.p = 15;
              _t2 = _context2.v;
              console.log(_t2);
              if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_18__["default"].CONFLICT) {
                _this2.isSaveConflictModalActive = true;
              } else if (_t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_18__["default"].BAD_REQUEST) {
                errormessage = Object(_auth_ErrorMessage__WEBPACK_IMPORTED_MODULE_20__["getErrorMessage"])(_t2.response.data.message).message;
                _this2.$notification.openNotificationWithType('danger', title, errormessage || message);
              } else {
                _this2.$notification.openMessageXhrError('', _t2);
              }
              return _context2.a(2, false);
            case 16:
              _context2.p = 16;
              _this2.$hideSpinner();
              return _context2.f(16);
            case 17:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 15, 16, 17]]);
      }))();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
      this.toRoute = null;
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isUnsavedModalActive = false;
              _this3.isSaveContinue = true;
              _context3.n = 1;
              return _this3.save();
            case 1:
              _this3.isSaveContinue = _context3.v;
              if (_this3.isSaveContinue) {
                _this3.cancel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    reloadData: function reloadData() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isSaveConflictModalActive = false;
              _this4.isSaveContinue = false;
              _this4.getEntity(true);
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    getCompanyModules: function getCompanyModules() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var result, _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              _context5.p = 0;
              _context5.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_17__["CompanySettingService"].getCompanyModules();
            case 1:
              result = _context5.v;
              _this5.companyModules = result || [];
              _context5.n = 3;
              break;
            case 2:
              _context5.p = 2;
              _t3 = _context5.v;
              _this5.$notification.openMessageXhrError('', _t3);
              _this5.companyModules = [];
            case 3:
              return _context5.a(2);
          }
        }, _callee5, null, [[0, 2]]);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
    if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
      console.log(this.snapshotDiff);
      if (this.$route.path !== from.path) {
        this.$router.replace(from.path);
      }
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      this.clearSnapshots(this.entity.userId);
      this.clearSessionStorage();
      this.setReturnRoute({});
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8 ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("transition-group", {
    attrs: {
      name: "custom-classes-transition",
      "enter-active-class": "animated slideInLeft",
      "leave-active-class": "animated slideOutLeft"
    }
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.toggleSideMenu,
      expression: "toggleSideMenu"
    }],
    key: "tile-parent",
    staticClass: "tile is-parent",
    style: {
      "min-width": _vm.inlineStyle
    }
  }, [_c("article", {
    key: "tile-child",
    staticClass: "tile is-child box detail-page-tile",
    style: {
      "min-width": _vm.inlineStyle
    }
  }, [_vm._t("side-menu")], 2)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-user-side-menu", {
    attrs: {
      "min-width": 15,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("div", {
    staticClass: "menu-label"
  }, [_c("div", {
    staticClass: "columns is-gapless mb-2"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("span", {
    staticClass: "title is-6",
    staticStyle: {
      "white-space": "nowrap"
    }
  }, [_vm._v(" Username: " + _vm._s(_vm.entityName) + " ")])])])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.detailGroup.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.UserDetail.name,
        params: {
          userId: _vm.$route.params.userId
        }
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.detailGroup.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.detailGroup.$error ? "" : null
    }
  }, [_vm._v("Details ")])])], 1), _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": !_vm.validProfileGroup
    },
    attrs: {
      to: {
        name: _vm.routeTypes.UserProfile.name,
        params: {
          userId: _vm.$route.params.userId
        }
      },
      "active-class": "is-active",
      "data-tooltip": [!_vm.validProfileGroup ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": !_vm.validProfileGroup
    },
    attrs: {
      "data-badge": !_vm.validProfileGroup ? "" : null
    }
  }, [_vm._v("User Profile")])])], 1), !_vm.isMobileAppUser ? _c("li", [_c("router-link", {
    class: {
      "tooltip is-tooltip-danger is-tooltip-right": _vm.$v.userAccessControl.$error
    },
    attrs: {
      to: {
        name: _vm.routeTypes.UserAccessControl.name,
        params: {
          userId: _vm.$route.params.userId
        }
      },
      "active-class": "is-active",
      "data-tooltip": [_vm.$v.userAccessControl.$error ? "Validation errors" : ""],
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.userAccessControl.$error
    },
    attrs: {
      "data-badge": _vm.$v.userAccessControl.$error ? "" : null
    }
  }, [_vm._v("Access Control")])])], 1) : _vm._e(), !_vm.isMobileAppUser ? _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.UserAccessRestriction.name,
        params: {
          userId: _vm.$route.params.userId
        }
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Access Restriction")])])])], 1) : _vm._e()])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.entity ? _c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      entity: _vm.entity,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": true
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }) : _vm._e(), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("user-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": "".concat(_vm.entity.username),
      "is-mobile-app-user": _vm.isMobileAppUser
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name,
      "is-allowed-access-new-pwa": _vm.isAllowedAccessNewPWA
    },
    on: {
      "mobile-app-user-changed": function mobileAppUserChanged($event) {
        _vm.isMobileUser = $event;
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./src/assets/validateForms/Address.js":
/*!*********************************************!*\
  !*** ./src/assets/validateForms/Address.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  addresses: {
    $each: {
      address1: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      stateText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      suburbPostcode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryCode: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      countryText: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Contacts.js":
/*!**********************************************!*\
  !*** ./src/assets/validateForms/Contacts.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _Phones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _Emails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Emails */ "./src/assets/validateForms/Emails.js");





/* harmony default export */ __webpack_exports__["default"] = ({
  contacts: {
    $each: {
      contact: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
        firstName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        },
        lastName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_1__["required"]
        }
      }, _Address__WEBPACK_IMPORTED_MODULE_2__["default"]), _Phones__WEBPACK_IMPORTED_MODULE_3__["default"]), _Emails__WEBPACK_IMPORTED_MODULE_4__["default"])
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Emails.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Emails.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  emails: {
    $each: {
      address: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["email"]
      }
    }
  }
});

/***/ }),

/***/ "./src/assets/validateForms/Phones.js":
/*!********************************************!*\
  !*** ./src/assets/validateForms/Phones.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  phones: {
    $each: {
      no: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/auth/ErrorMessage.js":
/*!****************************************!*\
  !*** ./src/views/auth/ErrorMessage.js ***!
  \****************************************/
/*! exports provided: getErrorMessage, getApiErrorMessage, isSignInTicketExpired */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessage", function() { return getErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApiErrorMessage", function() { return getApiErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSignInTicketExpired", function() { return isSignInTicketExpired; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);

var errorMessages = {
  'default': {
    title: 'Something wrong',
    message: 'Something wrong. Please get in touch with support.'
  },
  'password_not_meet_criteria': {
    title: 'Password not meet criteria',
    message: 'The password you provided does not meet criteria.'
  },
  'forget_password_request_not_found': {
    title: 'Forget Password Request not found',
    message: 'Forget password request not found. Please send a new request.'
  },
  'no_valid_user_found': {
    title: 'No valid user found',
    message: 'We could not locate a user matching information you provided. Please get in touch with support.'
  },
  'failed_send_email_with_mailgun': {
    title: 'Failed to send an email',
    message: 'Failed to send an email. Please get in touch with support.'
  },
  'failed_create_password_entry': {
    title: 'Failed to create password entry',
    message: 'Failed to create password entry. Please get in touch with support.'
  },
  'failed_insert_emailoutgoing': {
    title: 'Failed to insert email outgoing record',
    message: 'Failed to insert email outgoing record. Please get in touch with support.'
  },
  'password_reset_link_expired': {
    title: 'Expired password reset link',
    message: 'The password reset link has expired. Please send a new request.'
  },
  'password_reset_link_used': {
    title: 'Used password reset link',
    message: 'The password reset link has already been used. Please send a new request.'
  },
  'not_valid_user_token': {
    title: 'Invalid user token',
    message: 'Not valid user. Please contact support.'
  }
};
var getErrorMessage = function getErrorMessage(errorCode) {
  return errorMessages[errorCode] || errorMessages['default'];
};

/**
 * Text to show for a failed sign-in call.
 *
 * Distinct from getErrorMessage above, which maps known error *codes* to friendly copy. The
 * sign-in endpoints instead return literal user-facing strings ("Invalid credentials, you have
 * 3 remaining attempts", "You have been locked out. Try again in ...") deliberately matched to
 * the wording of the legacy login page, so the server's message is the message to display.
 *
 * ASP.NET Web API serialises Request.CreateErrorResponse as {"Message": "..."}, but the shape
 * varies across the endpoints and proxies involved, so each known form is checked in turn.
 *
 * A few of these endpoints do return a bare code rather than prose - the password-change path
 * surfaces 'password_not_meet_criteria' straight from UpdateUserPassword - so anything matching
 * a known code is translated rather than shown to the user verbatim.
 */
var getApiErrorMessage = function getApiErrorMessage(error, fallback) {
  var data = error && error.response ? error.response.data : null;
  var raw = null;
  if (typeof data === 'string' && data.trim()) {
    raw = data;
  } else if (data) {
    if (typeof data.Message === 'string' && data.Message.trim()) raw = data.Message;else if (typeof data.message === 'string' && data.message.trim()) raw = data.message;else if (typeof data.ExceptionMessage === 'string' && data.ExceptionMessage.trim()) raw = data.ExceptionMessage;
  }
  if (!raw) return fallback || 'Something went wrong. Please try again.';
  var trimmed = raw.trim();
  return errorMessages[trimmed] ? errorMessages[trimmed].message : trimmed;
};

/**
 * True when a sign-in step failed because its server-side ticket is gone. The only way on from
 * there is to enter the password again for a fresh ticket.
 */
var isSignInTicketExpired = function isSignInTicketExpired(error) {
  var data = error && error.response ? error.response.data : null;
  return !!data && data.code === 'signin_ticket_expired';
};

/***/ }),

/***/ "./src/views/user/AppUserSideMenu.vue":
/*!********************************************!*\
  !*** ./src/views/user/AppUserSideMenu.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AppUserSideMenu.vue?vue&type=template&id=03ffd2b8 */ "./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8");
/* harmony import */ var _AppUserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AppUserSideMenu.vue?vue&type=script&lang=js */ "./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AppUserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/AppUserSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js":
/*!********************************************************************!*\
  !*** ./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppUserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AppUserSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/AppUserSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppUserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8":
/*!**************************************************************************!*\
  !*** ./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8 ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./AppUserSideMenu.vue?vue&type=template&id=03ffd2b8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/AppUserSideMenu.vue?vue&type=template&id=03ffd2b8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppUserSideMenu_vue_vue_type_template_id_03ffd2b8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/UserSideMenu.vue":
/*!*****************************************!*\
  !*** ./src/views/user/UserSideMenu.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserSideMenu.vue?vue&type=template&id=0034f2fb */ "./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb");
/* harmony import */ var _UserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserSideMenu.vue?vue&type=script&lang=js */ "./src/views/user/UserSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/UserSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/UserSideMenu.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/views/user/UserSideMenu.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb":
/*!***********************************************************************!*\
  !*** ./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb ***!
  \***********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserSideMenu.vue?vue&type=template&id=0034f2fb */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserSideMenu.vue?vue&type=template&id=0034f2fb");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserSideMenu_vue_vue_type_template_id_0034f2fb__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/UserValidation.js":
/*!******************************************!*\
  !*** ./src/views/user/UserValidation.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/assets/validateForms/Phones */ "./src/assets/validateForms/Phones.js");
/* harmony import */ var _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/assets/validateForms/Emails */ "./src/assets/validateForms/Emails.js");
/* harmony import */ var _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/assets/validateForms/Address */ "./src/assets/validateForms/Address.js");
/* harmony import */ var _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/assets/validateForms/Contacts */ "./src/assets/validateForms/Contacts.js");
/* harmony import */ var _services_UserService__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/services/UserService */ "./src/services/UserService.js");
/* harmony import */ var _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/utils/PersonNameFunctions */ "./src/utils/PersonNameFunctions.js");


























var isUniqueUsername = /*#__PURE__*/function () {
  var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee(value) {
    var isNotUnique, _t;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          if (value) {
            _context.n = 1;
            break;
          }
          return _context.a(2, true);
        case 1:
          _context.p = 1;
          _context.n = 2;
          return _services_UserService__WEBPACK_IMPORTED_MODULE_24__["default"].checkUsernameValidity(value, this.entity.userId);
        case 2:
          isNotUnique = _context.v;
          return _context.a(2, !isNotUnique);
        case 3:
          _context.p = 3;
          _t = _context.v;
          return _context.a(2, false);
      }
    }, _callee, this, [[1, 3]]);
  }));
  return function isUniqueUsername(_x) {
    return _ref.apply(this, arguments);
  };
}();
var isUniqueEmail = /*#__PURE__*/function () {
  var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2(value) {
    var isUnique, _t2;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          if (value) {
            _context2.n = 1;
            break;
          }
          return _context2.a(2, true);
        case 1:
          _context2.p = 1;
          _context2.n = 2;
          return _services_UserService__WEBPACK_IMPORTED_MODULE_24__["default"].checkEmailValidity(value, this.entity.userId);
        case 2:
          isUnique = _context2.v;
          return _context2.a(2, isUnique);
        case 3:
          _context2.p = 3;
          _t2 = _context2.v;
          return _context2.a(2, false);
      }
    }, _callee2, this, [[1, 3]]);
  }));
  return function isUniqueEmail(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var requiredIfNotDeleted = Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
  return !model.isDeleted;
});
var emailIfNotDeleted = function emailIfNotDeleted(value, model) {
  if (model.isDeleted) return true;
  return Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["email"])(value);
};
var isAccessControlSelected = /*#__PURE__*/function () {
  var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3(value) {
    var _t3;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
      while (1) switch (_context3.p = _context3.n) {
        case 0:
          if (!(value.length <= 0)) {
            _context3.n = 1;
            break;
          }
          return _context3.a(2, false);
        case 1:
          _context3.p = 1;
          return _context3.a(2, value.filter(function (p) {
            return p.isBlock || p.isRead || p.isAdd || p.isEdit || p.isDelete || p.isPrint;
          }).length > 0);
        case 2:
          _context3.p = 2;
          _t3 = _context3.v;
          return _context3.a(2, false);
      }
    }, _callee3, null, [[1, 2]]);
  }));
  return function isAccessControlSelected(_x3) {
    return _ref3.apply(this, arguments);
  };
}();
var uniqueType = function uniqueType(value) {
  if (!Array.isArray(value)) return true;
  var types = value.filter(function (a) {
    return !a.isDeleted;
  }).map(function (a) {
    return a.type;
  });
  return new Set(types).size === types.length;
};
/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.email', 'entity.username', 'entity.password', 'entity.confirmNewPassword'],
    emailsPhonesGroup: ['entity.emails', 'entity.phones'],
    addressesGroup: ['entity.addresses'],
    contactsGroup: ['entity.contacts'],
    // Save gates on group errors, so rules outside a group never block it.
    profileNameGroup: ['entity.profile.firstName', 'entity.profile.lastName', 'entity.profile.displayName'],
    profileAddressesGroup: ['entity.profile.assetAddresses'],
    profileEmailsGroup: ['entity.profile.assetEmails'],
    profilePhonesGroup: ['entity.profile.assetPhones'],
    userAccessControl: ['entity.userAccessControl'],
    entity: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      username: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"],
        isUniqueUsername: isUniqueUsername
      },
      password: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      confirmNewPassword: {
        required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["requiredIf"])(function (model) {
          return model.isNew == true;
        })
      },
      email: {
        email: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["email"],
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"],
        isUniqueEmail: isUniqueEmail
      }
    }, _assets_validateForms_Address__WEBPACK_IMPORTED_MODULE_22__["default"]), _assets_validateForms_Emails__WEBPACK_IMPORTED_MODULE_21__["default"]), _assets_validateForms_Phones__WEBPACK_IMPORTED_MODULE_20__["default"]), _assets_validateForms_Contacts__WEBPACK_IMPORTED_MODULE_23__["default"]), {}, {
      profile: {
        // Optional, but must be a name if given - isPersonName passes on blank.
        firstName: {
          isPersonName: _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__["isPersonName"]
        },
        lastName: {
          isPersonName: _utils_PersonNameFunctions__WEBPACK_IMPORTED_MODULE_25__["isPersonName"]
        },
        // The only mandatory one, so the avatar always has a fallback. Seeded
        // from the username on create, which may carry digits, so no character
        // rule here.
        displayName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_19__["required"]
        },
        assetAddresses: {
          $each: {
            address1: {
              required: requiredIfNotDeleted
            },
            suburbText: {
              required: requiredIfNotDeleted
            },
            stateCode: {
              required: requiredIfNotDeleted
            },
            stateText: {
              required: requiredIfNotDeleted
            },
            suburbPostcode: {
              required: requiredIfNotDeleted
            },
            countryCode: {
              required: requiredIfNotDeleted
            },
            countryText: {
              required: requiredIfNotDeleted
            }
          },
          uniqueType: uniqueType
        },
        assetEmails: {
          $each: {
            address: {
              required: requiredIfNotDeleted,
              email: emailIfNotDeleted
            }
          },
          uniqueType: uniqueType
        },
        assetPhones: {
          $each: {
            no: {
              required: requiredIfNotDeleted
            }
          },
          uniqueType: uniqueType
        }
      },
      userAccessControl: {
        isAccessControlSelected: isAccessControlSelected
      }
    })
  }
});

/***/ }),

/***/ "./src/views/user/UserView.vue":
/*!*************************************!*\
  !*** ./src/views/user/UserView.vue ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserView.vue?vue&type=template&id=9ff7cd6c */ "./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c");
/* harmony import */ var _UserView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserView.vue?vue&type=script&lang=js */ "./src/views/user/UserView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/UserView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/UserView.vue?vue&type=script&lang=js":
/*!*************************************************************!*\
  !*** ./src/views/user/UserView.vue?vue&type=script&lang=js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c":
/*!*******************************************************************!*\
  !*** ./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c ***!
  \*******************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserView.vue?vue&type=template&id=9ff7cd6c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserView.vue?vue&type=template&id=9ff7cd6c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserView_vue_vue_type_template_id_9ff7cd6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/user/storeMixin.js":
/*!**************************************!*\
  !*** ./src/views/user/storeMixin.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'user';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute']))
});

/***/ })

}]);
//# sourceMappingURL=12.js.map