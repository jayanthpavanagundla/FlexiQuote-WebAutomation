(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-excessinvoice-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/views/quickinvoice/QuickInvoiceService.js */ "./src/views/quickinvoice/QuickInvoiceService.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./services */ "./src/views/quote/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./mixins/QuoteInvoiceStoreMixin */ "./src/views/quote/mixins/QuoteInvoiceStoreMixin.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _mixins_QuoteInvoiceValidationMixin__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./mixins/QuoteInvoiceValidationMixin */ "./src/views/quote/mixins/QuoteInvoiceValidationMixin.js");




























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteExcessInvoice',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_26___default.a
  },
  mixins: [_mixins_QuoteInvoiceValidationMixin__WEBPACK_IMPORTED_MODULE_27__["default"], _mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_25__["default"]],
  props: {
    value: null,
    readOnlyView: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: this.value,
      hasPendingChanges: false,
      gstPaid: false,
      excess: this.value.excess,
      ownersContribution: this.value.ownersContribution,
      discount: this.value.discount,
      // extraCharge: 0,
      gst: Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])(this.value.totalExGst * this.value.gstRate / 100),
      excessWithGst: this.value.excessWithGst,
      overrides: {
        labourTotal: 0,
        rrTotal: 0,
        repairTotal: 0,
        rwaTotal: 0,
        paintTotal: 0,
        fqTotal: 0,
        crushTotal: 0,
        cdTotal: 0,
        mechTotal: 0,
        pdrRrTotal: 0,
        pdrReTotal: 0
      },
      payerType: _enums__WEBPACK_IMPORTED_MODULE_21__["InvoicePayerTypes"].Insurer,
      customerAsset: null,
      isThirdPartyPayer: false,
      selectedAsset: null,
      assets: [],
      isAssetLoading: false,
      assetFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty(),
        assetName: '',
        showCustomer: true,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      invoice: null,
      tabInvoiceType: _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess,
      isLoadingInvoice: false,
      ocInvoice: null,
      selectedInvoiceDate: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_22__["default"];
    },
    invoiceTypes: function invoiceTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"];
    },
    hasQuoteInvoice: function hasQuoteInvoice() {
      var index = this.innerValue.invoices.findIndex(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Quote && !i.deleted;
      });
      return index >= 0;
    },
    invoicePayerTypes: function invoicePayerTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_21__["InvoicePayerTypes"];
    },
    totalExGst: function totalExGst() {
      return this.invoice.totalExGst;
    },
    totalIncGst: function totalIncGst() {
      return this.invoice.totalIncGst;
    },
    totalPayableIncGst: function totalPayableIncGst() {
      return this.invoice.totalIncGst;
    },
    showAsset: function showAsset() {
      return {
        customer: this.assetFilter.showCustomer,
        insurer: this.assetFilter.showInsurer
      };
    },
    invoiceNoReference: function invoiceNoReference() {
      return this.invoice ? "".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix, "/").concat(this.invoice.invoiceType) : '';
    },
    ocInvoiceNoReference: function ocInvoiceNoReference() {
      return this.ocInvoice ? "".concat(this.ocInvoice.prefix).concat(this.ocInvoice.invoiceNo).concat(this.ocInvoice.suffix, "/").concat(this.ocInvoice.invoiceType) : '';
    },
    isDirty: function isDirty() {
      var diff = deep_diff__WEBPACK_IMPORTED_MODULE_23___default.a.diff(this.baseInvoice, this.invoice);
      return diff;
    },
    showSave: function showSave() {
      return this.isUpdateExcessInvoice && !!this.invoice || this.hasPendingChanges;
    },
    invoiceValues: function invoiceValues() {
      if (this.invoice) {
        return this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.extraCharge;
      } else {
        return 0;
      }
    },
    ocInvoiceValues: function ocInvoiceValues() {
      if (this.ocInvoice) {
        return this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge;
      } else {
        return 0;
      }
    },
    baseInvoice: function baseInvoice() {
      if (this.baseSnapshot.invoices) {
        return lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24___default()(this.baseSnapshot.invoices.find(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess && !i.deleted;
        }));
      }
    },
    baseOcInvoice: function baseOcInvoice() {
      if (this.baseSnapshot.invoices) {
        return lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24___default()(this.baseSnapshot.invoices.find(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].OwnerContribution && !i.deleted;
        }));
      }
    },
    hasOcInvoice: function hasOcInvoice() {
      return this.ocInvoice !== null && this.ocInvoice !== undefined;
    },
    firstDayOfMonth: function firstDayOfMonth() {
      if (this.$company.setting.allowInvoicePreviousMonth) {
        return null;
      }
      var invoiceDate = new Date();
      if (!this.invoice.isNew) {
        invoiceDate = new Date("".concat(this.invoice.invoiceDate));
        return this.$filters.firstDayOfMonth(invoiceDate.getFullYear(), invoiceDate.getMonth());
      } else {
        return this.$filters.firstDayOfMonth();
      }
    },
    disableExcessWithGst: function disableExcessWithGst() {
      return !this.isUpdateExcessInvoice || this.hasQuoteInvoice || !this.$user.info.isSupportUser;
    },
    isOrm: function isOrm() {
      return this.value.orm !== null && this.value.orm !== undefined;
    },
    disableOwnerContribution: function disableOwnerContribution() {
      return !this.isUpdateExcessInvoice || this.hasQuoteInvoice || (this.value.isAudaNet || this.isOrm) && !this.$user.info.isSupportUser;
    }
  },
  watch: {
    showAsset: function showAsset(newVal, oldVal) {
      if (!newVal.customer && !newVal.insurer) {
        this.assetFilter.showCustomer = !oldVal.customer;
        this.assetFilter.showInsurer = !oldVal.insurer;
      }
      this.getAssetDropdown();
    },
    invoiceValues: function invoiceValues(newVal, oldVal) {
      if (this.invoice && this.isUpdateExcessInvoice) {
        this.recalculateTotals();
      }
    },
    ocInvoiceValues: function ocInvoiceValues(newVal, oldVal) {
      if (this.ocInvoice && this.isUpdateExcessInvoice) {
        this.ocInvoice.totalExGst = this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge;
        this.ocInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])(this.ocInvoice.totalExGst * this.ocInvoice.gstRate / 100);
        this.ocInvoice.totalIncGst = this.ocInvoice.totalExGst + this.ocInvoice.gst;
      }
    },
    'invoice.excessAmount': function invoiceExcessAmount(newVal, oldVal) {
      if (this.isUpdateExcessInvoice && newVal !== undefined) {
        this.innerValue.excess = newVal;
      }
    },
    // 'invoice.ownerContribution': function(newVal, oldVal) {
    //   if (this.isUpdateExcessInvoice && newVal !== undefined) {
    //     this.innerValue.ownersContribution = newVal
    //   }
    // },
    'invoice.gst': function invoiceGst(newVal) {
      if (this.invoice && this.isUpdateExcessInvoice) {
        this.recalculateTotals(false);
      }
    },
    'ocInvoice.gst': function ocInvoiceGst(newVal) {
      if (this.ocInvoice && this.isUpdateExcessInvoice) {
        this.ocInvoice.totalExGst = this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge;
        this.ocInvoice.totalIncGst = this.ocInvoice.totalExGst + this.ocInvoice.gst;
      }
    },
    excessWithGst: function () {
      var _excessWithGst = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee(newVal, oldVal) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!this.isUpdateExcessInvoice) {
                _context.n = 4;
                break;
              }
              if (!newVal) {
                _context.n = 1;
                break;
              }
              this.deleteOcInvoice();
              this.ownersContribution = this.innerValue.ownersContribution;
              this.invoice.extraCharge = this.innerValue.extraCharge;
              this.invoice.ownerContribution = this.ownersContribution;
              this.invoice.extraCharge = this.extraCharge;
              this.invoice.totalExGst = this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.extraCharge;
              this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])((this.invoice.excessAmount + this.invoice.ownerContribution) * this.innerValue.gstRate / 100);
              _context.n = 3;
              break;
            case 1:
              if (!(this.ownersContribution > 0 || this.extraCharge > 0)) {
                _context.n = 3;
                break;
              }
              _context.n = 2;
              return this.addOcInvoice(this.ownersContribution, this.extraCharge);
            case 2:
              this.invoice.gst = 0;
            case 3:
              this.innerValue.excessWithGst = newVal;
              this.getInvoice();
            case 4:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      function excessWithGst(_x, _x2) {
        return _excessWithGst.apply(this, arguments);
      }
      return excessWithGst;
    }(),
    selectedInvoiceDate: function selectedInvoiceDate(newVal, oldVal) {
      if (newVal) {
        this.invoice.invoiceDate = newVal.toISOString().split('.')[0] + 'Z';
        if (this.ocInvoice) {
          this.ocInvoice.invoiceDate = newVal.toISOString().split('.')[0] + 'Z';
        }
      } else {
        this.invoice.invoiceDate = null;
        if (this.ocInvoice) {
          this.ocInvoice.invoiceDate = null;
        }
      }
    }
  },
  created: function created() {
    this.$v.entity.invoices.$touch();
    this.getAssets();
    this.getInvoice();
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_21__["EventHubTypes"].EntitySaved, function () {
      _this.reloadInvoice();
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_21__["EventHubTypes"].EntitySaved);
  },
  methods: {
    getAssets: function getAssets() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var insurerAssetFilter, customerAssetFilter, insurers, customers, _yield$Promise$all, _yield$Promise$all2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              insurerAssetFilter = {
                assetId: _this2.innerValue.insurerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              customerAssetFilter = {
                assetId: _this2.innerValue.customerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              _context2.n = 1;
              return Promise.all([_views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_17__["default"].getAssetDropdownProto(insurerAssetFilter), _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_17__["default"].getAssetDropdownProto(customerAssetFilter)]);
            case 1:
              _yield$Promise$all = _context2.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_yield$Promise$all, 2);
              insurers = _yield$Promise$all2[0];
              customers = _yield$Promise$all2[1];
              _this2.insurerAsset = insurers[0];
              _this2.customerAsset = customers[0];
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    onInvoicePayerTypeClick: function onInvoicePayerTypeClick(payerType) {
      if (this.invoice.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess) {
        if (payerType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoicePayerTypes"].ThirdParty && this.isThirdPartyPayer) {
          this.invoice.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
          this.invoice.assetName = '';
          this.invoice.assetType = '';
          this.getAssetDropdown();
        } else {
          this.invoice.assetId = this.customerAsset.assetId;
          this.invoice.assetName = this.customerAsset.assetName;
          this.invoice.assetType = this.customerAsset.assetType;
          this.invoice.invoiceGlCode = this.customerAsset.assetGlCode;
          this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
          this.selectedAsset = null;
        }
      }
    },
    getInvoice: function getInvoice() {
      var _arguments = arguments,
        _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var cancel, isDelete, baseSnapshot, key;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              cancel = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              isDelete = _arguments.length > 1 && _arguments[1] !== undefined ? _arguments[1] : false;
              _this3.isLoadingInvoice = true;
              baseSnapshot = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_24___default()(_this3.baseSnapshot); // this.baseInvoice = _cloneDeep(this.baseSnapshot.invoices.find(i => i.invoiceType === InvoiceTypes.Excess && !i.deleted))
              if (!cancel) {
                _this3.invoice = _this3.innerValue.invoices.find(function (i) {
                  return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess && !i.deleted;
                });
                _this3.ocInvoice = _this3.innerValue.invoices.find(function (i) {
                  return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].OwnerContribution && !i.deleted;
                });
                if (_this3.ocInvoice) {
                  _this3.extraCharge = _this3.ocInvoice.extraCharge;
                  _this3.ownersContribution = _this3.ocInvoice.ownerContribution;
                } else if (_this3.invoice) {
                  // Excess-with-GST stores the extra charge on the Excess invoice itself
                  // (no OC invoice), so load it from there or the field shows blank. [FQ-3011]
                  _this3.extraCharge = _this3.invoice.extraCharge;
                }
              } else {
                _this3.innerValue.excess = baseSnapshot.excess;
                _this3.innerValue.ownersContribution = baseSnapshot.ownersContribution;
                _this3.innerValue.excessWithGst = baseSnapshot.excessWithGst;
                _this3.excessWithGst = _this3.innerValue.excessWithGst;
                if (_this3.ocInvoice) _this3.extraCharge = _this3.ocInvoice.extraCharge;
                _this3.ownersContribution = _this3.innerValue.ownersContribution;
                for (key in _this3.baseInvoice) {
                  if (_this3.baseInvoice.hasOwnProperty(key)) {
                    _this3.invoice[key] = _this3.baseInvoice[key];
                  }
                }
                // Mirror the load path: with no OC invoice the extra charge lives on the
                // restored Excess invoice, so refresh the field from it. [FQ-3011]
                if (!_this3.ocInvoice && _this3.invoice) {
                  _this3.extraCharge = _this3.invoice.extraCharge;
                }
                // if (this.excessWithGst && this.ocInvoice) {
                //   this.deleteOcInvoice()
                // } else if (!this.ocInvoice && (this.ownersContribution || this.extraCharge)) {
                //   this.addOcInvoice(this.ownersContribution, this.extraCharge)
                // }
              }
              if (_this3.isUpdateExcessInvoice) {
                if (_this3.excessWithGst && _this3.ocInvoice) {
                  _this3.deleteOcInvoice();
                } else if (!_this3.ocInvoice && !isDelete && (_this3.ownersContribution || _this3.extraCharge)) {
                  _this3.addOcInvoice(_this3.ownersContribution, _this3.extraCharge);
                }
              }
              if (_this3.invoice) {
                _this3.selectedInvoiceDate = new Date("".concat(_this3.invoice.invoiceDate));
              }
              _this3.isLoadingInvoice = false;
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getAssetDropdown: function getAssetDropdown() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isAssetLoading = true;
              _context4.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_17__["default"].getAssetDropdownProto(_this4.assetFilter);
            case 1:
              _this4.assets = _context4.v;
              if (_this4.assetFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty()) {
                _this4.selectedAsset = _this4.assets.find(function (c) {
                  return c.assetId === _this4.selectedAsset.assetId;
                });
              }
              _this4.isAssetLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    getAssetDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_19___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              this.isAssetLoading = true;
              this.assetFilter.assetName = query;
              _context5.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_17__["default"].getAssetDropdownProto(this.assetFilter);
            case 1:
              this.assets = _context5.v;
              this.isAssetLoading = false;
            case 2:
              return _context5.a(2);
          }
        }, _callee5, this);
      }));
      return function (_x3) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectAsset: function selectAsset(selected) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              // this.value.assetId = selected.assetId
              // this.value.assetType = selected.assetType
              // this.value.invoiceGlCode = selected.assetGlCode
              if (_this5.isThirdPartyPayer && _this5.selectedAsset) {
                _this5.invoice.assetId = selected.assetId;
                _this5.invoice.assetType = selected.assetType;
                _this5.invoice.invoiceGlCode = selected.assetGlCode;
                _this5.invoice.assetName = selected.assetName;
                _this5.assetFilter.assetId = _this5.selectedAsset.assetId;
              } else _this5.assetFilter.assetId = selected.assetId;
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    removeAsset: function removeAsset(removed) {
      this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_18__["default"].empty();
      // this.value.assetId = Guid.empty()
      // this.value.contactId = Guid.empty()
      // this.value.assetType = null
      this.getAssetDropdown();
    },
    editInvoice: function editInvoice() {
      this.updateInvoice();
      // this.isUpdateExcessInvoice = true
      this.setIsUpdateExcessInvoice(true);
      if (this.isUpdateExcessInvoice) {
        if (this.excessWithGst) {
          this.deleteOcInvoice();
          this.ownersContribution = this.innerValue.ownersContribution;
          this.invoice.extraCharge = this.innerValue.extraCharge;
          this.invoice.ownerContribution = this.ownersContribution;
          this.invoice.extraCharge = this.extraCharge;
          this.invoice.totalExGst = this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.extraCharge;
          this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])((this.invoice.excessAmount + this.invoice.ownerContribution) * this.innerValue.gstRate / 100);
        } else {
          if (this.ownersContribution > 0 || this.extraCharge > 0) {
            this.addOcInvoice(this.ownersContribution, this.extraCharge);
            this.invoice.gst = 0;
          }
        }
        this.innerValue.excessWithGst = this.excessWithGst;
        this.getInvoice();
      }
    },
    updateInvoice: function updateInvoice() {
      // this.invoice.excessWithGst = this.innerValue.excessWithGst
      if (this.invoice) {
        this.invoice.excessAmount = this.innerValue.excess;
        this.invoice.ownerContribution = this.innerValue.ownersContribution;
      }
      if (this.ocInvoice) {
        this.ownersContribution = this.innerValue.ownersContribution;
        this.ocInvoice.ownerContribution = this.innerValue.ownersContribution;
      }
      this.recalculateTotals();
    },
    cancelInvoice: function cancelInvoice() {
      // this.isUpdateExcessInvoice = false
      this.setIsUpdateExcessInvoice(false);
      this.getInvoice(true);
    },
    getMainQuoteInvoice: function getMainQuoteInvoice() {
      var _this6 = this;
      // Find Quote invoice that contains assessments with subQuoteNo === 0
      var mainQuoteInvoice = this.innerValue.invoices.find(function (invoice) {
        var _invoice$includedAsse;
        if (invoice.invoiceType !== _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Quote || invoice.deleted || invoice.isDeleted) {
          return false;
        }

        // Check if this invoice's includedAssessments contain any main quote assessments (subQuoteNo === 0)
        return (_invoice$includedAsse = invoice.includedAssessments) === null || _invoice$includedAsse === void 0 ? void 0 : _invoice$includedAsse.some(function (assessmentId) {
          var _this6$value;
          var assessment = (_this6$value = _this6.value) === null || _this6$value === void 0 || (_this6$value = _this6$value.quoteAssessments) === null || _this6$value === void 0 ? void 0 : _this6$value.find(function (a) {
            return a.assessmentID === assessmentId;
          });
          return (assessment === null || assessment === void 0 ? void 0 : assessment.subQuoteNo) === 0;
        });
      });
      return mainQuoteInvoice || null;
    },
    addInvoice: function addInvoice() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        var _this7$innerValue;
        var invoiceNo, _this7$value, mainQuoteInvoice, isCurrentQuoteMain;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              // this.isUpdateExcessInvoice = true
              _this7.setIsUpdateExcessInvoice(true);
              _this7.isLoadingInvoice = true;
              _context7.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["QuoteInvoiceService"].getNewEntity();
            case 1:
              _this7.invoice = _context7.v;
              _this7.existingInvoice = _this7.innerValue.invoices.find(function (i) {
                return !i.isNew && !i.deleted;
              });
              invoiceNo = _this7.invoice.invoiceNo;
              if (_this7.existingInvoice) {
                invoiceNo = _this7.existingInvoice.invoiceNo;
              }

              // Only reuse main quote invoice number if assessment is enabled
              if ((_this7$innerValue = _this7.innerValue) !== null && _this7$innerValue !== void 0 && _this7$innerValue.isAssessmentEnabled) {
                mainQuoteInvoice = _this7.getMainQuoteInvoice();
                isCurrentQuoteMain = (_this7$value = _this7.value) === null || _this7$value === void 0 || (_this7$value = _this7$value.quoteAssessments) === null || _this7$value === void 0 ? void 0 : _this7$value.some(function (a) {
                  return a.subQuoteNo === 0;
                });
                if (mainQuoteInvoice && isCurrentQuoteMain) {
                  invoiceNo = mainQuoteInvoice.invoiceNo;
                }
              }

              // New excess invoice values
              _this7.invoice.invoiceNo = invoiceNo;
              _this7.excessWithGst = _this7.innerValue.excessWithGst;
              _this7.invoice.gstRate = _this7.innerValue.gstRate;
              _this7.invoice.excessAmount = _this7.innerValue.excess;
              _this7.invoice.ownerContribution = _this7.innerValue.ownersContribution;
              _this7.recalculateTotals();
              _this7.invoice.invoiceType = _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess;
              _this7.invoice.invoicePayingType = _enums__WEBPACK_IMPORTED_MODULE_21__["InvoicePayerTypes"].ThirdParty;
              _this7.invoice.assetType = _enums__WEBPACK_IMPORTED_MODULE_21__["AssetTypes"].Customer;
              _this7.invoice.assetId = _this7.innerValue.customerId;
              _this7.selectedInvoiceDate = new Date(); // new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())
              _this7.invoice.includedQuotes.splice(_this7.invoice.includedQuotes.length, 1, _this7.innerValue.quoteId);
              _this7.innerValue.invoices.splice(_this7.innerValue.invoices.length, 1, _this7.invoice);
              _context7.n = 2;
              return _this7.addOcInvoice(_this7.innerValue.ownersContribution, 0);
            case 2:
              // New owner contribution invoice values
              // if (!this.innerValue.excessWithGst) {
              //   this.ocInvoice = await QuoteInvoiceService.getNewEntity()
              //   this.ocInvoice.invoiceNo = invoiceNo
              //   this.ocInvoice.excessWithGst = this.innerValue.excessWithGst
              //   this.ocInvoice.gstRate = this.innerValue.gstRate
              //   this.ocInvoice.ownerContribution = this.innerValue.ownersContribution
              //   this.ocInvoice.totalExGst = this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge
              //   this.ocInvoice.gst = roundAwayFromZero((this.ocInvoice.totalExGst * this.ocInvoice.gstRate) / 100)
              //   this.ocInvoice.totalIncGst = this.ocInvoice.totalExGst + this.ocInvoice.gst
              //   this.ocInvoice.invoiceType = InvoiceTypes.OwnerContribution
              //   this.ocInvoice.invoicePayingType = InvoicePayerTypes.ThirdParty
              //   this.ocInvoice.assetType = AssetTypes.Customer
              //   this.ocInvoice.assetId = this.innerValue.customerId
              //   this.ocInvoice.includedQuotes.splice(this.invoice.includedQuotes.length, 1, this.innerValue.quoteId)
              //   this.innerValue.invoices.splice(this.innerValue.invoices.length, 1, this.ocInvoice)
              // } else {
              //   this.ocInvoice = null
              // }

              _this7.isLoadingInvoice = false;
            case 3:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    addOcInvoice: function addOcInvoice(ownersContribution, extraCharge) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var _this8$innerValue, invoiceNo, _this8$value, mainQuoteInvoice, isCurrentQuoteMain;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!(!_this8.excessWithGst && (ownersContribution > 0 || extraCharge > 0))) {
                _context8.n = 3;
                break;
              }
              if (_this8.ocInvoice) {
                _context8.n = 2;
                break;
              }
              _this8.existingInvoice = _this8.innerValue.invoices.find(function (i) {
                return !i.deleted;
              });
              invoiceNo = _this8.invoice.invoiceNo;
              if (_this8.existingInvoice) {
                invoiceNo = _this8.existingInvoice.invoiceNo;
              }

              // Only reuse main quote invoice number if assessment is enabled
              if ((_this8$innerValue = _this8.innerValue) !== null && _this8$innerValue !== void 0 && _this8$innerValue.isAssessmentEnabled) {
                mainQuoteInvoice = _this8.getMainQuoteInvoice();
                isCurrentQuoteMain = (_this8$value = _this8.value) === null || _this8$value === void 0 || (_this8$value = _this8$value.quoteAssessments) === null || _this8$value === void 0 ? void 0 : _this8$value.some(function (a) {
                  return a.subQuoteNo === 0;
                });
                if (mainQuoteInvoice && isCurrentQuoteMain) {
                  invoiceNo = mainQuoteInvoice.invoiceNo;
                }
              }
              _context8.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["QuoteInvoiceService"].getNewEntity();
            case 1:
              _this8.ocInvoice = _context8.v;
              _this8.ocInvoice.invoiceDate = _this8.invoice.invoiceDate;
              _this8.ocInvoice.invoiceNo = invoiceNo;
              _this8.ocInvoice.excessWithGst = _this8.innerValue.excessWithGst;
              _this8.ocInvoice.gstRate = _this8.innerValue.gstRate;
              // this.ocInvoice.ownerContribution = ownersContribution // this.innerValue.ownersContribution
              // this.ocInvoice.extraCharge = extraCharge
              // this.ocInvoice.totalExGst = this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge
              // this.ocInvoice.gst = roundAwayFromZero((this.ocInvoice.totalExGst * this.ocInvoice.gstRate) / 100)
              // this.ocInvoice.totalIncGst = this.ocInvoice.totalExGst + this.ocInvoice.gst
              _this8.ocInvoice.invoiceType = _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].OwnerContribution;
              _this8.ocInvoice.invoicePayingType = _enums__WEBPACK_IMPORTED_MODULE_21__["InvoicePayerTypes"].ThirdParty;
              _this8.ocInvoice.assetType = _enums__WEBPACK_IMPORTED_MODULE_21__["AssetTypes"].Customer;
              _this8.ocInvoice.assetId = _this8.innerValue.customerId;
              _this8.ocInvoice.includedQuotes.splice(_this8.invoice.includedQuotes.length, 1, _this8.innerValue.quoteId);
              _this8.innerValue.invoices.splice(_this8.innerValue.invoices.length, 1, _this8.ocInvoice);
            case 2:
              // else if (this.baseOcInvoice) {
              //   this.ocInvoice = this.innerValue.invoices.find(i => i.invoiceId === this.baseOcInvoice.invoiceId)
              //   this.ocInvoice.deleted = false
              //   this.ocInvoice.isDeleted = false
              // }
              _this8.ocInvoice.ownerContribution = ownersContribution;
              _this8.ocInvoice.extraCharge = extraCharge;
              _this8.ocInvoice.totalExGst = _this8.ocInvoice.ownerContribution + _this8.ocInvoice.extraCharge;
              _this8.ocInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])(_this8.ocInvoice.totalExGst * _this8.ocInvoice.gstRate / 100);
              _this8.ocInvoice.totalIncGst = _this8.ocInvoice.totalExGst + _this8.ocInvoice.gst;
              _this8.invoice.ownerContribution = 0;
              _this8.invoice.extraCharge = 0;
              _this8.invoice.gst = 0;
              _context8.n = 4;
              break;
            case 3:
              _this8.ocInvoice = null;
            case 4:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    deleteInvoice: function deleteInvoice(invoiceType) {
      var hasDeletion = false;
      if (this.invoice && invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].Excess) {
        if (this.invoice.isNew) {
          var index = this.innerValue.invoices.map(function (obj) {
            return obj.invoiceId;
          }).indexOf(this.invoice.invoiceId);
          this.innerValue.invoices.splice(index, 1);
          this.invoice = null;
        } else {
          this.invoice.deleted = true;
          this.invoice.isDeleted = true;
          hasDeletion = true;
        }
      }
      if (this.ocInvoice && invoiceType === _enums__WEBPACK_IMPORTED_MODULE_21__["InvoiceTypes"].OwnerContribution) {
        if (!this.ocInvoice.isNew) hasDeletion = true;
        this.deleteOcInvoice();
      }
      this.getInvoice(false, true);
      this.setIsUpdateExcessInvoice(false);
      if (hasDeletion) this.hasPendingChanges = true;
    },
    deleteOcInvoice: function deleteOcInvoice() {
      if (this.ocInvoice) {
        // console.log('deleteOcInvoice')
        if (this.ocInvoice.isNew) {
          var index = this.innerValue.invoices.map(function (obj) {
            return obj.invoiceId;
          }).indexOf(this.ocInvoice.invoiceId);
          this.innerValue.invoices.splice(index, 1);
          this.ocInvoice = null;
        } else {
          this.ocInvoice.deleted = true;
          this.ocInvoice.isDeleted = true;
          this.ownersContribution = 0;
          this.extraCharge = 0;
        }
        if (this.invoice) {
          this.invoice.ownerContribution = this.ownersContribution;
          this.invoice.extraCharge = this.extraCharge;
        }
      }
    },
    updateTotal: function updateTotal() {
      var updateGst = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
    } // if (this.isUpdateExcessInvoice) {
    //   // this.updateInvoice()
    //   const totalExGst = this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.extraCharge
    //   if (updateGst) {
    //     if (this.innerValue.excessWithGst) {
    //       this.invoice.gst = roundAwayFromZero((totalExGst * this.innerValue.gstRate) / 100)
    //     } else {
    //       this.invoice.gst = 0
    //     }
    //   }
    //   this.invoice.totalExGst = totalExGst
    //   this.invoice.totalIncGst = this.invoice.totalExGst + this.invoice.gst
    // }
    ,
    recalculateTotals: function recalculateTotals() {
      var reset = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
      if (this.invoice) {
        if (!this.innerValue.excessWithGst) {
          this.invoice.totalExGst = this.invoice.excessAmount;
          if (reset) {
            this.invoice.gst = 0;
          }
        } else {
          this.invoice.totalExGst = this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.extraCharge;
          if (reset) {
            this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])(this.invoice.totalExGst * this.invoice.gstRate / 100);
          }
        }
        this.invoice.totalIncGst = this.invoice.totalExGst + this.invoice.gst;
      }
      if (this.ocInvoice) {
        this.ocInvoice.totalExGst = this.ocInvoice.ownerContribution + this.ocInvoice.extraCharge;
        if (reset) {
          this.ocInvoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_16__["roundAwayFromZero"])(this.ocInvoice.totalExGst * this.ocInvoice.gstRate / 100);
        }
        this.ocInvoice.totalIncGst = this.ocInvoice.totalExGst + this.ocInvoice.gst;
      }
    },
    reloadInvoice: function reloadInvoice() {
      // console.log('reloadInvoice')
      this.innerValue = this.value;
      this.hasPendingChanges = false;
      this.getInvoice();
    },
    onBlurOwnersContribution: function onBlurOwnersContribution() {
      this.innerValue.ownersContribution = this.ownersContribution;
      if (!this.excessWithGst) {
        if (this.ownersContribution > 0 || this.extraCharge > 0) {
          this.addOcInvoice(this.ownersContribution, this.extraCharge);
        } else {
          this.deleteOcInvoice();
        }
      } else {
        this.invoice.ownerContribution = this.ownersContribution;
      }
    },
    onBlurExtraCharge: function onBlurExtraCharge() {
      if (!this.excessWithGst) {
        if (this.ownersContribution > 0 || this.extraCharge > 0) {
          this.addOcInvoice(this.ownersContribution, this.extraCharge);
        } else {
          this.deleteOcInvoice();
        }
      } else {
        this.invoice.extraCharge = this.extraCharge;
      }
    },
    invoiceDateInputEvent: function invoiceDateInputEvent(event) {
      this.selectedInvoiceDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    saveInvoice: function saveInvoice() {
      this.$emit('save');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell is-flex"
  }, [_c("div", {
    staticClass: "is-flex-grow-1 is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns"
  }, [_vm._m(0), _c("div", {
    staticClass: "column is-narrow"
  }, [!_vm.isLoadingInvoice ? _c("div", {
    staticClass: "buttons"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.isUpdateExcessInvoice && _vm.invoice && !_vm.invoice.gstPaidDate,
      expression: "$user.hasEdit($route.meta.id) && !readOnlyView && !isUpdateExcessInvoice && invoice && !invoice.gstPaidDate"
    }],
    staticClass: "button tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Update Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.editInvoice();
      }
    }
  }, [_vm._m(1)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showSave && !_vm.$licenceExpired,
      expression: "showSave && !$licenceExpired"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Save Changes"
    },
    on: {
      click: function click($event) {
        return _vm.saveInvoice();
      }
    }
  }, [_vm._m(2)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasAdd(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.invoice,
      expression: "$user.hasAdd($route.meta.id) && !readOnlyView && !invoice"
    }],
    staticClass: "button tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "New Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.addInvoice();
      }
    }
  }, [_vm._m(3)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasDelete(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.isUpdateExcessInvoice && _vm.invoice && !_vm.invoice.gstPaidDate || _vm.invoice && _vm.invoice.isNew,
      expression: "$user.hasDelete($route.meta.id) && !readOnlyView && !isUpdateExcessInvoice && invoice && !invoice.gstPaidDate || (invoice && invoice.isNew)"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Delete Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.deleteInvoice(_vm.invoice.invoiceType);
      }
    }
  }, [_vm._m(4)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && _vm.isUpdateExcessInvoice && _vm.invoice && !_vm.invoice.isNew,
      expression: "$user.hasEdit($route.meta.id) && isUpdateExcessInvoice && invoice && !invoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Update from quote"
    },
    on: {
      click: function click($event) {
        return _vm.updateInvoice();
      }
    }
  }, [_vm._m(5)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && _vm.isUpdateExcessInvoice && _vm.invoice && !_vm.invoice.isNew,
      expression: "$user.hasEdit($route.meta.id) && isUpdateExcessInvoice && invoice && !invoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancelInvoice();
      }
    }
  }, [_vm._m(6)])]) : _vm._e(), _vm.invoice && _vm.invoice.gstPaidDate ? _c("span", {
    staticClass: "tag is-warning is-pulled-right tooltip is-tooltip-warning",
    attrs: {
      "data-tooltip": "GST has been paid"
    }
  }, [_vm._v("GST paid on " + _vm._s(_vm.$filters.formatDateTimezone(_vm.invoice.gstPaidDate, _vm.$userInfo.locale)))]) : _vm._e()])]), !_vm.invoice && _vm.isLoadingInvoice ? _c("div", {
    staticClass: "section"
  }, [_c("span", {
    staticClass: "is-loading-image has-text-grey has-text-centered"
  })]) : _vm.invoice ? _c("div", [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      placeholder: "Invoice No.",
      readonly: ""
    },
    domProps: {
      value: _vm.invoiceNoReference
    }
  })])]), !_vm.isUpdateExcessInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateTimezone(_vm.selectedInvoiceDate, _vm.$userInfo.locale)
    }
  })]) : _vm.$userInfo && !_vm.gstPaid && _vm.selectedInvoiceDate ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "min-date": _vm.firstDayOfMonth,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.invoiceDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Date To...",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedInvoiceDate,
      callback: function callback($$v) {
        _vm.selectedInvoiceDate = $$v;
      },
      expression: "selectedInvoiceDate"
    }
  })], 1) : _vm._e()]), _c("div", {
    staticClass: "is-divider"
  }), !_vm.isUpdateExcessInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      readonly: ""
    },
    domProps: {
      value: _vm.invoice.assetName
    }
  })]) : _vm._e(), _vm.isUpdateExcessInvoice && _vm.isThirdPartyPayer ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("div", {
    staticClass: "is-flex"
  }, [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-customer"
    }
  }, [_vm._v("Customer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showCustomer,
      expression: "assetFilter.showCustomer"
    }],
    attrs: {
      id: "chk-customer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showCustomer) ? _vm._i(_vm.assetFilter.showCustomer, null) > -1 : _vm.assetFilter.showCustomer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showCustomer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showCustomer", $$c);
        }
      }
    }
  }), _vm._m(7)])]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2 pl-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-insurer"
    }
  }, [_vm._v("Insurer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showInsurer,
      expression: "assetFilter.showInsurer"
    }],
    attrs: {
      id: "chk-insurer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showInsurer) ? _vm._i(_vm.assetFilter.showInsurer, null) > -1 : _vm.assetFilter.showInsurer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showInsurer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showInsurer", $$c);
        }
      }
    }
  }), _vm._m(8)])])])]), _c("div", {
    staticClass: "control is-expanded"
  }, [_vm.assets ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.invoices.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Select a payer",
      options: _vm.assets,
      loading: _vm.isAssetLoading,
      "internal-search": false,
      "options-limit": _vm.assetFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectAsset,
      remove: _vm.removeAsset,
      "search-change": _vm.getAssetDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetType == 1,
            "is-info": props.option.assetType == 4
          }
        }, [_vm._v(" " + _vm._s(props.option.assetType == 1 ? "Customer" : "Insurer") + " ")]), _c("span", [_vm._v(_vm._s("".concat(props.option.assetName)))])];
      }
    }], null, false, 2502510241),
    model: {
      value: _vm.selectedAsset,
      callback: function callback($$v) {
        _vm.selectedAsset = $$v;
      },
      expression: "selectedAsset"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Payer not found.")])]) : _vm._e(), _vm.$v.entity && _vm.$v.entity.invoices.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Payer is required.")]) : _vm._e()], 1)]) : _vm._e(), _vm.isUpdateExcessInvoice ? _c("div", {
    staticClass: "field"
  }, [!_vm.isThirdPartyPayer ? _c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]) : _vm._e(), _c("div", {
    staticClass: "control"
  }, [_c("div", [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-invoiceExcessWithGst"
    }
  }, [_vm._v("3rd Party")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.isThirdPartyPayer,
      expression: "isThirdPartyPayer"
    }],
    attrs: {
      id: "chk-thirdParty",
      type: "checkbox"
    },
    domProps: {
      value: _vm.invoicePayerTypes.ThirdParty,
      checked: Array.isArray(_vm.isThirdPartyPayer) ? _vm._i(_vm.isThirdPartyPayer, _vm.invoicePayerTypes.ThirdParty) > -1 : _vm.isThirdPartyPayer
    },
    on: {
      change: [function ($event) {
        var $$a = _vm.isThirdPartyPayer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = _vm.invoicePayerTypes.ThirdParty,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.isThirdPartyPayer = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.isThirdPartyPayer = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.isThirdPartyPayer = $$c;
        }
      }, function ($event) {
        return _vm.onInvoicePayerTypeClick(_vm.invoicePayerTypes.ThirdParty);
      }]
    }
  }), _vm._m(9)])])]), !_vm.customerAsset ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Private invoice disabled. Customer has been deleted")]) : _vm._e()]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess")]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pr-1 is-size-7",
    class: {
      "pretty-checkbox-label": !_vm.disableExcessWithGst
    },
    attrs: {
      for: "chk-invoiceExcessWithGst"
    }
  }, [_vm._v("Excess with GST")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.excessWithGst,
      expression: "excessWithGst"
    }],
    attrs: {
      id: "chk-invoiceExcessWithGst",
      type: "checkbox",
      disabled: _vm.disableExcessWithGst
    },
    domProps: {
      checked: Array.isArray(_vm.excessWithGst) ? _vm._i(_vm.excessWithGst, null) > -1 : _vm.excessWithGst
    },
    on: {
      change: function change($event) {
        var $$a = _vm.excessWithGst,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.excessWithGst = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.excessWithGst = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.excessWithGst = $$c;
        }
      }
    }
  }), _vm._m(10)])])]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateExcessInvoice || _vm.hasQuoteInvoice
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      }
    },
    model: {
      value: _vm.invoice.excessAmount,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "excessAmount", _vm._n($$v));
      },
      expression: "invoice.excessAmount"
    }
  })], 1)]), !_vm.hasOcInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Owner Contribution")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: _vm.disableOwnerContribution
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      },
      blur: function blur($event) {
        return _vm.onBlurOwnersContribution();
      }
    },
    model: {
      value: _vm.ownersContribution,
      callback: function callback($$v) {
        _vm.ownersContribution = _vm._n($$v);
      },
      expression: "ownersContribution"
    }
  })], 1) : _vm._e()])]), !_vm.hasOcInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Extra Charge")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateExcessInvoice
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      },
      blur: function blur($event) {
        return _vm.onBlurExtraCharge();
      }
    },
    model: {
      value: _vm.extraCharge,
      callback: function callback($$v) {
        _vm.extraCharge = _vm._n($$v);
      },
      expression: "extraCharge"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("GST")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateExcessInvoice
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal(false);
      }
    },
    model: {
      value: _vm.invoice.gst,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "gst", _vm._n($$v));
      },
      expression: "invoice.gst"
    }
  })], 1)])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Remarks")]), _c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.invoiceRemark,
      expression: "invoice.invoiceRemark"
    }],
    staticClass: "textarea",
    attrs: {
      placeholder: "",
      disabled: !_vm.isUpdateExcessInvoice,
      rows: "3"
    },
    domProps: {
      value: _vm.invoice.invoiceRemark
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.invoice, "invoiceRemark", $event.target.value);
      }
    }
  })]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.exported,
      expression: "invoice.exported"
    }],
    staticClass: "is-checkradio",
    attrs: {
      type: "checkbox",
      id: "invoice-exported",
      disabled: _vm.readOnlyView || !_vm.$userInfo.isSupportUser || !_vm.isUpdateExcessInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.invoice.exported) ? _vm._i(_vm.invoice.exported, null) > -1 : _vm.invoice.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.invoice.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.invoice, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.invoice, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.invoice, "exported", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "invoice-exported"
    }
  }, [_vm._v("Exported")])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Excl GST: "), _c("span", {
    staticClass: "has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalExGst, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Payable Incl GST: "), _c("span", {
    staticClass: "has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalPayableIncGst, _vm.$userInfo.locale)))])])])]) : _vm._e()])])]), _vm.hasOcInvoice ? _c("div", {
    staticClass: "cell is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns"
  }, [_vm._m(11), _c("div", {
    staticClass: "column is-narrow"
  }, [!_vm.isLoadingInvoice ? _c("div", {
    staticClass: "buttons"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.isUpdateExcessInvoice && _vm.ocInvoice && !_vm.ocInvoice.gstPaidDate,
      expression: "$user.hasEdit($route.meta.id) && !readOnlyView && !isUpdateExcessInvoice && ocInvoice && !ocInvoice.gstPaidDate"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Update Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.editInvoice();
      }
    }
  }, [_vm._m(12)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasAdd(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.ocInvoice,
      expression: "$user.hasAdd($route.meta.id) && !readOnlyView && !ocInvoice"
    }],
    staticClass: "button tooltip is-tooltip-left",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "New Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.addInvoice();
      }
    }
  }, [_vm._m(13)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasDelete(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.isUpdateExcessInvoice && _vm.ocInvoice && !_vm.ocInvoice.gstPaidDate || _vm.ocInvoice && _vm.ocInvoice.isNew,
      expression: "$user.hasDelete($route.meta.id) && !readOnlyView && !isUpdateExcessInvoice && ocInvoice && !ocInvoice.gstPaidDate || (ocInvoice && ocInvoice.isNew)"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Delete Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.deleteInvoice(_vm.ocInvoice.invoiceType);
      }
    }
  }, [_vm._m(14)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && _vm.isUpdateExcessInvoice && _vm.ocInvoice && !_vm.ocInvoice.isNew,
      expression: "$user.hasEdit($route.meta.id) && isUpdateExcessInvoice && ocInvoice && !ocInvoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Update from quote"
    },
    on: {
      click: function click($event) {
        return _vm.updateInvoice();
      }
    }
  }, [_vm._m(15)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && _vm.isUpdateExcessInvoice && _vm.ocInvoice && !_vm.ocInvoice.isNew,
      expression: "$user.hasEdit($route.meta.id) && isUpdateExcessInvoice && ocInvoice && !ocInvoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancelInvoice();
      }
    }
  }, [_vm._m(16)])]) : _vm._e(), _vm.ocInvoice && _vm.ocInvoice.gstPaidDate ? _c("span", {
    staticClass: "tag is-warning is-pulled-right tooltip is-tooltip-warning",
    attrs: {
      "data-tooltip": "GST has been paid"
    }
  }, [_vm._v("GST paid on " + _vm._s(_vm.$filters.formatDateTimezone(_vm.ocInvoice.gstPaidDate, _vm.$userInfo.locale)))]) : _vm._e()])]), _vm.ocInvoice ? _c("div", [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      placeholder: "Invoice No.",
      readonly: ""
    },
    domProps: {
      value: _vm.ocInvoiceNoReference
    }
  })])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Owner Contribution")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: _vm.disableOwnerContribution
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      },
      blur: function blur($event) {
        return _vm.onBlurOwnersContribution();
      }
    },
    model: {
      value: _vm.ownersContribution,
      callback: function callback($$v) {
        _vm.ownersContribution = _vm._n($$v);
      },
      expression: "ownersContribution"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Extra Charge")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateExcessInvoice
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      },
      blur: function blur($event) {
        return _vm.onBlurExtraCharge();
      }
    },
    model: {
      value: _vm.extraCharge,
      callback: function callback($$v) {
        _vm.extraCharge = _vm._n($$v);
      },
      expression: "extraCharge"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("GST")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateExcessInvoice
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal(false);
      }
    },
    model: {
      value: _vm.ocInvoice.gst,
      callback: function callback($$v) {
        _vm.$set(_vm.ocInvoice, "gst", _vm._n($$v));
      },
      expression: "ocInvoice.gst"
    }
  })], 1)])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Remarks")]), _c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.ocInvoice.invoiceRemark,
      expression: "ocInvoice.invoiceRemark"
    }],
    staticClass: "textarea",
    attrs: {
      placeholder: "",
      disabled: !_vm.isUpdateExcessInvoice,
      rows: "3"
    },
    domProps: {
      value: _vm.ocInvoice.invoiceRemark
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.ocInvoice, "invoiceRemark", $event.target.value);
      }
    }
  })]), _vm.$userInfo.isSupportUser && _vm.ocInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.ocInvoice.exported,
      expression: "ocInvoice.exported"
    }],
    staticClass: "is-checkradio",
    attrs: {
      type: "checkbox",
      id: "ocInvoice-exported",
      disabled: !_vm.isUpdateExcessInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.ocInvoice.exported) ? _vm._i(_vm.ocInvoice.exported, null) > -1 : _vm.ocInvoice.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.ocInvoice.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.ocInvoice, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.ocInvoice, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.ocInvoice, "exported", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "ocInvoice-exported"
    }
  }, [_vm._v("Exported")])])]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Excl GST: "), _c("span", {
    staticClass: "has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.ocInvoice.totalExGst, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Payable Incl GST: "), _c("span", {
    staticClass: "has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.ocInvoice.totalIncGst, _vm.$userInfo.locale)))])])])]) : _vm._e()])]) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Excess Invoice")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-content-save mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-warning"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-success"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Owner's Contribution Invoice")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-warning"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-6d1177ee] {\n  margin: 1.2em 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7abe5f6c", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteExcessInvoice.vue":
/*!************************************************!*\
  !*** ./src/views/quote/QuoteExcessInvoice.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true */ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true");
/* harmony import */ var _QuoteExcessInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteExcessInvoice.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true */ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteExcessInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6d1177ee",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteExcessInvoice.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteExcessInvoice.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=style&index=0&id=6d1177ee&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_style_index_0_id_6d1177ee_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true":
/*!******************************************************************************************!*\
  !*** ./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteExcessInvoice.vue?vue&type=template&id=6d1177ee&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteExcessInvoice_vue_vue_type_template_id_6d1177ee_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/mixins/QuoteInvoiceStoreMixin.js":
/*!**********************************************************!*\
  !*** ./src/views/quote/mixins/QuoteInvoiceStoreMixin.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");



var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapGetters"])(moduleName, {
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    isUpdateInvoice: 'isUpdateInvoice',
    isUpdateExcessInvoice: 'isUpdateExcessInvoice',
    invoiceIncludedQuotes: 'invoiceIncludedQuotes',
    isFixedGst: 'isFixedGst',
    invoiceExtraCharge: 'invoiceExtraCharge'
  })), {}, {
    fixedGst: {
      get: function get() {
        return this.isFixedGst;
      },
      set: function set(value) {
        this.setIsFixedGst(value);
      }
    },
    extraCharge: {
      get: function get() {
        return this.invoiceExtraCharge;
      },
      set: function set(value) {
        this.setInvoiceExtraCharge(value);
      }
    }
  }),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapActions"])(moduleName, ['setIsUpdateInvoice', 'setIsUpdateExcessInvoice', 'setIsFixedGst', 'addInvoiceIncludedQuotes', 'removeInvoiceIncludedQuotes', 'clearInvoiceIncludedQuotes', 'setInvoiceExtraCharge'])), {}, {
    getIncludedStatus: function getIncludedStatus(quote) {
      var isIncluded = this.invoiceIncludedQuotes.findIndex(function (s) {
        return s.quoteId === quote.quoteId;
      }) >= 0;
      return isIncluded;
    }
  })
});

/***/ }),

/***/ "./src/views/quote/mixins/QuoteInvoiceValidationMixin.js":
/*!***************************************************************!*\
  !*** ./src/views/quote/mixins/QuoteInvoiceValidationMixin.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  inject: ['$vv'],
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  }
});

/***/ })

}]);
//# sourceMappingURL=quote-excessinvoice-chunk.js.map