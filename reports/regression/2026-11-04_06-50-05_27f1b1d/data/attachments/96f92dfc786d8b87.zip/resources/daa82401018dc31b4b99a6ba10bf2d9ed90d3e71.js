(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-vehicle-damage-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.regexp.dot-all.js */ "./node_modules/core-js/modules/es.regexp.dot-all.js");
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.regexp.sticky.js */ "./node_modules/core-js/modules/es.regexp.sticky.js");
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _utils_StringFunctions__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/utils/StringFunctions */ "./src/utils/StringFunctions.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_BulmaCheckbox_BulmaCheckboxDate_vue__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../components/BulmaCheckbox/BulmaCheckboxDate.vue */ "./src/components/BulmaCheckbox/BulmaCheckboxDate.vue");






























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteVehicleDamage',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_28__["default"],
    BulmaCheckboxDate: _components_BulmaCheckbox_BulmaCheckboxDate_vue__WEBPACK_IMPORTED_MODULE_29__["default"]
  },
  props: {
    quoteId: {
      type: String,
      default: null
    }
  },
  data: function data() {
    return {
      categories: {
        Exterior: 'Exterior',
        Interior: 'Interior',
        Roof: 'Roof'
      },
      areas: {
        FrontLeft: 'Front Left',
        FrontRight: 'Front Right',
        MiddleLeft: 'Middle Left',
        MiddleRight: 'Middle Right',
        BackLeft: 'Back Left',
        BackRight: 'Back Right',
        Roof: 'Roof',
        Engine: 'Engine',
        Interior: 'Interior'
      },
      areaHoverOpacity: {
        FrontLeft: 0,
        FrontRight: 0,
        MiddleLeft: 0,
        MiddleRight: 0,
        BackLeft: 0,
        BackRight: 0,
        Roof: 0,
        Engine: 0,
        Interior: 0
      },
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      popupVisible: false,
      areaSeverity: {},
      areaCategory: [],
      damageSeverityFull: [],
      damageSeverity: [],
      top: 0,
      left: 0,
      selectedArea: '',
      selectedOption: '',
      hoverOpacity: 0,
      lastSyncDate: null,
      states: [],
      quoteRepx: {}
    };
  },
  computed: {
    filteredAreaSeverity: function filteredAreaSeverity() {
      return Object.values(this.areaSeverity).filter(function (i) {
        return i.severity;
      });
    },
    // quoteId() {
    //   const params = this.$route.params
    //   if (params.quoteId) return params.quoteId
    //   return ''
    // },
    title: function title() {
      return 'Vehicle Damange';
    },
    isSync: function isSync() {
      if (this.filteredAreaSeverity.length) {
        return this.filteredAreaSeverity.some(function (i) {
          return !!i.syncDate;
        });
      }
      return false;
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = newVal;
      },
      deep: true
    },
    // areaSeverity: {
    //   handler: function (newVal, oldVal) {
    //     Object.keys(newVal).forEach((key) => {
    //       const area = newVal[key]
    //       const found = this.damageSeverityFull.find((i) => i.name === area.name)
    //       if (found) {
    //         newVal[key].opacity = found.opacity
    //       }
    //     })
    //   },
    //   deep: true
    // }
    'quoteRepx.vehDamageMarketValueRequired': {
      handler: function handler(newVal, oldVal) {
        if (!newVal) {
          this.quoteRepx.vehDamageMarketValue = '';
        }
      }
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.setAreaServerity();
            _this.setAreaCategory();
            _this.loadDamageSeverity();
            _context.n = 1;
            return _this.getSyncDate();
          case 1:
            _context.n = 2;
            return _this.loadStates();
          case 2:
            _context.n = 3;
            return _this.loadQuoteRepx(_this.quoteId);
          case 3:
            _context.n = 4;
            return _this.refresh();
          case 4:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    //document.addEventListener('click', this.closeDropdown)
  },
  beforeDestroy: function beforeDestroy() {
    //document.removeEventListener('click', this.closeDropdown)
  },
  methods: {
    loadQuoteRepx: function loadQuoteRepx(quoteId) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var quoteRepx;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getQuoteRepx(quoteId);
            case 1:
              quoteRepx = _context2.v;
              _this2.quoteRepx = quoteRepx;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    loadStates: function loadStates() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var states;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getStates();
            case 1:
              states = _context3.v;
              _this3.states = states;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getSyncDate: function getSyncDate() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var lastSyncDate;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getSyncDate(_this4.quoteId);
            case 1:
              lastSyncDate = _context4.v;
              _this4.lastSyncDate = lastSyncDate;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    refresh: function refresh() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var item;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _this5.loadQuoteRepx(_this5.quoteId);
            case 1:
              _context5.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getAreaDamage(_this5.quoteId);
            case 2:
              item = _context5.v;
              if (item) {
                Object.keys(item).forEach(function (key) {
                  var areaDamage = item[key];
                  if (areaDamage) {
                    var areaKey = _this5.findAreaKey(areaDamage.name);
                    var found = _this5.areaSeverity[areaKey];
                    if (found) {
                      found.severity = areaDamage.severity;
                      found.syncDate = areaDamage.syncDate;
                      var damageSeverity = _this5.damageSeverityFull.find(function (i) {
                        return i.value == found.severity;
                      });
                      if (damageSeverity) found.opacity = damageSeverity.opacity;
                    }
                  }
                });
              }
            case 3:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    setAreaServerity: function setAreaServerity() {
      var _this6 = this;
      var nameMap = {};
      Object.keys(this.areas).forEach(function (area) {
        nameMap[area] = {
          name: _this6.areas[area],
          severity: '',
          opacity: 0,
          syncDate: null
        };
      });
      this.areaSeverity = nameMap;
    },
    setAreaCategory: function setAreaCategory() {
      this.areaCategory.push({
        area: this.areas.FrontLeft,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.FrontRight,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.MiddleLeft,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.MiddleRight,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.BackLeft,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.BackRight,
        category: this.categories.Exterior
      });
      this.areaCategory.push({
        area: this.areas.Roof,
        category: this.categories.Roof
      });
      this.areaCategory.push({
        area: this.areas.Engine,
        category: this.categories.Interior
      });
      this.areaCategory.push({
        area: this.areas.Interior,
        category: this.categories.Interior
      });
    },
    loadDamageSeverity: function loadDamageSeverity() {
      var categories = this.categories;
      var options = [{
        name: 'None',
        value: '',
        area: '',
        cateogies: [categories.Exterior, categories.Interior, categories.Roof],
        opacity: 0
      }, {
        name: 'Panel Repair',
        value: 'Panel Repair',
        area: '',
        cateogies: [categories.Exterior],
        opacity: 0.2
      }, {
        name: 'Panel Replace',
        value: 'Panel Replace',
        area: '',
        cateogies: [categories.Exterior],
        opacity: 0.4
      }, {
        name: 'Structural Repair',
        value: 'Structural Repair',
        area: '',
        cateogies: [categories.Exterior, categories.Roof],
        opacity: 0.6
      }, {
        name: 'Structural Replace',
        value: 'Structural Replace',
        area: '',
        cateogies: [categories.Exterior, categories.Roof],
        opacity: 0.8
      }, {
        name: 'Minor Damage',
        value: 'Minor Damage',
        area: '',
        cateogies: [categories.Interior],
        opacity: 0.4
      }, {
        name: 'Major Damage',
        value: 'Major Damage',
        area: '',
        cateogies: [categories.Interior],
        opacity: 0.8
      }];
      this.damageSeverityFull = options;
    },
    findAreaKey: function findAreaKey(value) {
      var keys = Object.keys(this.areas);
      for (var _i = 0, _keys = keys; _i < _keys.length; _i++) {
        var key = _keys[_i];
        var val = this.areas[key];
        if (val === value) {
          return key;
        }
      }
      return null;
    },
    filterDamageSeverity: function filterDamageSeverity() {
      var area = this.selectedArea;
      area = area.replace('Vehicle', '').trim();
      var found = this.areaCategory.find(function (i) {
        return i.area == area;
      });
      if (found) {
        var filtered = this.damageSeverityFull.filter(function (i) {
          return i.cateogies.includes(found.category);
        });
        filtered.forEach(function (i) {
          i.area = found.area.replace(/ /gi, '');
        });
        this.damageSeverity = filtered;
      } else {
        this.damageSeverity = [];
      }
    },
    showPopup: function showPopup(event) {
      var offsetX = event.offsetX,
        offsetY = event.offsetY;
      this.top = offsetY;
      this.left = offsetX;
      this.popupVisible = true;
    },
    handleChange: function handleChange(event) {
      if (this.$licenceExpired) return;
      console.log(event);
      var val = event.target.value;
      var area = this.selectedArea;
      area = area.replace('Vehicle', '').trim();
      var key = this.findAreaKey(area);
      var damageSeverity = this.damageSeverityFull.find(function (i) {
        return i.value == val;
      });
      if (key) {
        this.areaSeverity[key].opacity = damageSeverity ? damageSeverity.opacity : 0;
      }
      this.closePopup();
    },
    closePopup: function closePopup() {
      this.selectedArea = '';
      this.popupVisible = false;
    },
    handleBlur: function handleBlur(event) {
      this.closePopup();
    },
    handleClick: function handleClick(event) {
      if (this.$licenceExpired) return;
      // const { offsetX, offsetY } = event
      var elmId = event.target.id;
      var replaced = this.extractAreaName(elmId);
      // if (this.areaSeverity[replaced].syncDate) //no action
      //   return
      this.selectedArea = this.camelCaseToSentence(replaced);
      //console.log(JSON.stringify({ ...event }, null, 2))
      this.filterDamageSeverity();
      this.showPopup(event);
    },
    extractAreaName: function extractAreaName(elmId) {
      var replacements = {
        selection: '',
        tapable: '',
        vehicle: ''
      };
      var regexPattern = new RegExp(Object.keys(replacements).join('|'), 'gi');
      var replaced = elmId.replace(regexPattern, function (match) {
        return replacements[match.toLowerCase()];
      });
      replaced = replaced.replace(/_/gi, '');
      replaced = replaced.trim();
      return replaced;
    },
    camelCaseToSentence: function camelCaseToSentence(camelCaseStr) {
      var sentence = camelCaseStr.replace(/([A-Z])/g, ' $1');
      var newSentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      return newSentence.trim();
    },
    handleMouseOver: function handleMouseOver(event) {
      var elmId = event.target.id;
      var replaced = this.extractAreaName(elmId);
      var hoverArea = this.camelCaseToSentence(replaced);
      var areaKey = this.findAreaKey(hoverArea);
      if (areaKey) {
        this.areaHoverOpacity[areaKey] = 0.2;
      }
    },
    handleMouseLeave: function handleMouseLeave(event) {
      var elmId = event.target.id;
      var replaced = this.extractAreaName(elmId);
      var hoverArea = this.camelCaseToSentence(replaced);
      var areaKey = this.findAreaKey(hoverArea);
      if (areaKey) {
        this.areaHoverOpacity[areaKey] = 0;
      }
    },
    renderSeverity: function renderSeverity(severity) {
      return {
        'opacity-0-2': severity == 0.2,
        'opacity-0-4': severity == 0.4,
        'opacity-0-6': severity == 0.6,
        'opacity-0-8': severity == 0.8
      };
    },
    remove: function remove(item) {
      if (this.$licenceExpired) return;
      var name = item.name;
      var key = this.findAreaKey(name);
      var found = this.areaSeverity[key];
      found.severity = '';
      found.opacity = 0;
    },
    save: function save() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var quoteRepx, isUpdated, datas, response, isSuccess, errors;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              if (!_this7.$licenceExpired) {
                _context6.n = 1;
                break;
              }
              return _context6.a(2);
            case 1:
              _this7.$showSpinner('Saving...');
              quoteRepx = _this7.quoteRepx;
              _context6.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].updateVehicleDamage(quoteRepx);
            case 2:
              isUpdated = _context6.v;
              if (isUpdated) {
                _context6.n = 3;
                break;
              }
              // this.$notification.openNotificationWithType('danger', this.title, 'Save failed.')
              _this7.$toast.open({
                message: 'Save failed.',
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              _this7.$hideSpinner();
              return _context6.a(2);
            case 3:
              datas = _this7.areaSeverity;
              _context6.n = 4;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].insertAreaSeverity(_this7.quoteId, datas);
            case 4:
              response = _context6.v;
              isSuccess = response.isSuccess, errors = response.errors;
              if (errors) {
                _this7.$toast.open({
                  message: "Save failed.\n ".concat(Object(_utils_StringFunctions__WEBPACK_IMPORTED_MODULE_27__["formatBulletString"])(errors)),
                  type: 'is-danger',
                  position: 'is-top',
                  queue: false
                });
                // this.$notification.openNotificationWithType('danger', this.title, `Save failed.\n ${formatBulletString(errors)}`)
              } else if (isSuccess || isUpdated) {
                _this7.$toast.open({
                  message: 'Save successful',
                  type: 'is-success',
                  position: 'is-top',
                  queue: false
                });
                // this.$notification.openNotificationWithType('success', this.title, 'Save successful')
              } else if (isSuccess == false && errors == null) {
                _this7.$toast.open({
                  message: 'No changes. Not saved',
                  type: 'is-warning',
                  position: 'is-top',
                  queue: false
                });
                // this.$notification.openNotificationWithType('warning', this.title, 'No changes. Not saved')
              } else {
                _this7.$toast.open({
                  message: 'Save failed. Try again later',
                  type: 'is-danger',
                  position: 'is-top',
                  queue: false
                });
                // this.$notification.openNotificationWithType('danger', this.title, 'Save failed. Try again later')
              }
              _this7.$hideSpinner();
            case 5:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    syncVehicleDamage: function syncVehicleDamage() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              if (!_this8.$licenceExpired) {
                _context7.n = 1;
                break;
              }
              return _context7.a(2);
            case 1:
              _this8.$showSpinner('Syncing...');
              _context7.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].syncVehicleDamage(_this8.quoteId);
            case 2:
              _context7.n = 3;
              return _this8.refresh();
            case 3:
              _this8.getSyncDate();
              _this8.$hideSpinner();
            case 4:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "vehicle-damage-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-ancestor is-parent pl-0"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_vm._m(0), _c("div", {
    staticClass: "svg-container"
  }, [_c("svg", {
    attrs: {
      "xmlns:dc": "http://purl.org/dc/elements/1.1/",
      "xmlns:cc": "http://creativecommons.org/ns#",
      "xmlns:rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
      "xmlns:svg": "http://www.w3.org/2000/svg",
      xmlns: "http://www.w3.org/2000/svg",
      "xmlns:sodipodi": "http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd",
      "xmlns:inkscape": "http://www.inkscape.org/namespaces/inkscape",
      version: "1.1",
      id: "wovr_vehicle",
      "sodipodi:docname": "svgImgWovrCar.svg",
      "inkscape:version": "0.91 r13725",
      x: "0px",
      y: "0px",
      width: "630px",
      height: "730px",
      viewBox: "284.5 14.5 630 730",
      "enable-background": "new 284.5 14.5 630 730",
      "xml:space": "preserve"
    }
  }, [_c("metadata", {
    attrs: {
      id: "metadata3693"
    }
  }, [_c("rdf:rdf", [_c("cc:work", {
    attrs: {
      "rdf:about": ""
    }
  }, [_c("dc:format", [_vm._v("image/svg+xml")]), _c("dc:type", {
    attrs: {
      "rdf:resource": "http://purl.org/dc/dcmitype/StillImage"
    }
  })], 1)], 1)], 1), _c("defs", {
    attrs: {
      id: "defs3691"
    }
  }), _c("sodipodi:namedview", {
    attrs: {
      pagecolor: "#ffffff",
      bordercolor: "#666666",
      borderopacity: "1",
      objecttolerance: "10",
      gridtolerance: "10",
      guidetolerance: "10",
      "inkscape:pageopacity": "0",
      "inkscape:pageshadow": "2",
      "inkscape:window-width": "1680",
      "inkscape:window-height": "1028",
      id: "namedview3689",
      showgrid: "false",
      "inkscape:zoom": "0.91439562",
      "inkscape:cx": "312.44795",
      "inkscape:cy": "316.33808",
      "inkscape:window-x": "-8",
      "inkscape:window-y": "232",
      "inkscape:window-maximized": "1",
      "inkscape:current-layer": "wovr_vehicle"
    }
  }), _c("path", {
    attrs: {
      id: "vehicle_outline",
      "sodipodi:nodetypes": "ccccccccccccsccccccccccccccccczccccccccccccccccccccccccscccccccccccccccccccccccsccccccccccccccccccccccccccccccccccccccccccccccccsccccccccsscccccccccccccccscccccccccccccccccccccccccccccccccccccccccccccccccccccccsccccccccccccccccccscccccccccccccccccccccccccccccccccccccccccccccccccsccccccccccccccccccccccccccccccscccccccccccccscccccccccccccccccccccccccccccccccccccccsccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccscccscsscccscscsccscsccccccccccsccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#lines",
      d: "  M465.679,34.138c-4.575,9.349-1.052,18.782-4.391,27.447c-1.617,4.886-1.14,10.156-1.541,15.026  c-0.54,5.443,1.849,19.397,3.544,21.006c0.694,0.613,0.77,0.46,0.385-0.69c-0.307-0.843-0.771-2.606-1.001-3.91l-0.386-2.376  c17.417,0.665,37.248-4.486,36.976-16.331l-0.155-3.451c19.746,0,39.492,0,59.236,0l0.463,3.067  c0.924,6.517,5.47,11.577,12.479,13.723c4.622,1.38,13.326,2.76,18.102,2.76c2.775,0,3.312,0.23,2.929,1.303  c-0.926,3.374-1.31,6.67-0.54,5.597c2.384-5.561,4.228-28.165,3.505-33.925c-0.383-2.843-2.584-5.73-2.584-12.247  c-1.214-20.934,0.492-17.414-12.606-17.808c-14.309-1.433-10.295,4.866-11.413,16.26c-26.627,0-54.192,0.188-80.818,0.188v-3.375  c-0.542-3.689-0.716-11.31-2.881-12.991C479.356,32.676,472.112,32.134,465.679,34.138L465.679,34.138z M485.753,49.447l-8.553,0.53  c-5.667,0.375-8.433,0.048-12.445,2.177c1.135-16.663-1.187-18.169,10.708-17.71C487.256,34.013,485.099,33.617,485.753,49.447z   M589.758,50.757c-6.576-1.071-12.542-0.874-19.469-1.056c-0.413-19.346,0.573-14.749,11.206-14.86  C592.127,34.731,591.565,33.057,589.758,50.757z M514.824,58.978c10.016,0.031,20.03-0.025,30.043-0.076c0-2.812,0-5.622,0-8.434  l21.03,0.23c14.56,0.153,24.167,1.203,25.321,1.816c0.204,9.678,3.065,9.479,2.425,13.314l0.061,3.5  c-43.958,0.183-87.917,0.281-131.876,0.383c0.412-5.559,0.812-15.393,4.468-17.174c9.539-3.184,27.021-1.916,48.528-1.993  C514.824,53.478,514.824,55.971,514.824,58.978L514.824,58.978z M543.328,57.444c-9.245,0-18.488,0-27.732,0  c0-2.044,0-4.089,0-6.133c9.244,0,18.487,0,27.732,0C543.328,53.355,543.328,55.4,543.328,57.444z M462.888,88.996  c-0.154-6.261-1.039-10.939-1.193-17.2l19.6-0.523l16.43,0.132C498.802,86.833,473.616,88.4,462.888,88.996z M591.831,88.484  c-13.619,1.307-33.313-5.408-32.327-18.006h15.406l17.537,0.328C592.116,78.268,591.87,79.736,591.831,88.484z M360.001,83.656  c-0.683,5.761-0.337,37.726-0.77,49.067c-2.157,0-8.705,3.833-12.094,7.129c-9.152,7.804-9.181,22.248-5.315,30.283  c2.85,5.444,7.78,10.196,12.787,12.42c4.006,1.84,4.006,1.84,3.39,4.6c-0.771,3.297-0.848,154.252-0.077,157.701  c0.538,2.455,0.461,2.531-3.698,4.601c-5.008,2.455-10.63,8.128-12.788,13.111c-2.234,4.905-2.696,12.571-1.08,17.938  c2.542,8.665,10.399,16.484,18.643,18.402l3.928,0.919l0.541,9.275c1.078,17.788,2.618,29.44,4.389,33.199  c2.312,4.752,6.857,8.893,12.634,11.651c5.314,2.531,6.932,2.838,7.857,1.304c0.309-0.614,2.388-1.458,4.467-2.07  c2.157-0.534,7.703-2.529,12.479-4.447c13.253-6.517,12.754-6.674,15.33-17.863c0.539-0.919,2.619-26.144,2.619-31.739v-5.366  l9.321-11.115c5.084-6.134,10.861-12.958,12.864-15.257c4.852-5.598,5.161-6.135,8.32-12.421c5.624-11.347,5.7-12.037,5.7-58.956  v-41.86c-7.256-23.356-18.018-46.483-28.887-65.012c-3.697-6.287-6.856-12.113-7.01-13.033  c-5.126-27.376-13.618-57.006-19.874-80.346c-1.155-5.137-7.241-9.276-18.565-12.956c-2.927-0.92-5.7-2.146-6.008-2.684  c-0.386-0.69-2.002-1.073-4.39-1.073C368.023,79.925,367.477,83.656,360.001,83.656L360.001,83.656z M376.542,129.098  c-3.672-1.161-9.86-1.477-14.537-1.531c-0.186-13.928-0.284-29.217-0.385-43.144c5.991,0.496,10.435-4.54,16.177-4.6  C376.974,91.347,377.156,117.259,376.542,129.098L376.542,129.098z M404.064,102.132c5.727,23.741,14.839,50.545,17.872,73.14  c0.01,1.956-4.36,16.348-7.164,25.146c-8.122-3.534-36.997-8.769-44.987-1.993c-1.502,51.587-2.07,91.004-1.772,146.354  c-2.954-1.007-5.681-1.438-8.55-2.911c-1.616-54.044-0.925-84.694-0.925-150.726c17.658-2.72,32.062-9.512,36.072-24.057  c3.116-31.137-17.082-32.895-15.735-39.346c0.231-0.844,0.462-11.423,0.462-23.537V82.199l6.625,2.224  C397.837,88.078,401.617,93.875,404.064,102.132L404.064,102.132z M384.266,173.892c-12.135,13.402-28.229,8.442-36.05,0.23  c-8.32-9.276-8.243-22.08,0.231-31.586c5.27-5.5,13.066-7.56,18.179-7.36C392.951,138.678,391.857,163.294,384.266,173.892  L384.266,173.892z M431.256,192.752c6.394,11.27,15.869,30.513,19.567,39.789l2.388,5.827c-1.409,4.043-2.904,8.094-3.851,12.266  c0,0.768-0.462-0.076-1.002-1.762c-5.11-10.93-20.868-32.9-32.037-45.476c9.444,15.299,25.578,30.356,31.344,47.009  c1.771,5.674,2.003,7.436,2.388,24.073c0.308,15.104,0.329,13.298,0.182,17.702c-15.175-6.134-22.598-8.731-29.068-10.803  l-7.935-2.529v-10.044c0-11.576,2.004-60.642,2.696-65.625c0.694-5.214,1.927-9.66,4.545-17.02  C423.322,178.032,422.628,177.648,431.256,192.752L431.256,192.752z M414.926,202.642l-0.386,4.293  c-0.386,4.217-1.695,36.034-2.542,64.323l-0.462,14.029H391.2c-13.019,0-20.337,0.308-20.337,0.768c0,0.459,7.242,0.767,20.26,0.767  h20.336l0.462,41.552c0.254,22.848,0.114,39.45,0.097,41.799c-8.451,2.788-9.022,4.436-18.886-1.71  c-0.153-6.059,0.071-14.482-0.776-15.327c-7.15-3.887-13.79-5.009-21.493-8.432c-0.77-0.46-0.847-15.642-0.461-72.755  c0.308-39.714,0.694-72.756,0.924-73.447C384.814,194.044,402.823,196.619,414.926,202.642L414.926,202.642z M457.216,251.555  c1.541,6.056,1.617,7.436,1.233,46.995c-0.386,45.08-0.155,43.395-5.624,55.2c-2.389,5.061-5.547,9.353-16.331,22.232  c-7.318,8.741-13.634,16.792-14.02,17.863c-2.006,16.628-1.027,32.15-5.38,45.709c-7.292,6.954-18.907,11.03-29.047,14.096  c0.974-11.461-1.12-47.502-1.614-55.301c0.847-0.458,3.457-3.124,4.612-4.273c2.157-2.07,2.157-2.146,2.157-12.574v-10.427  c7.798,5.662,16.007,2.989,19.525,0.415c10.327-5.613,20.792-12.44,29.004-20.27c6.163-6.059,7.319-8.97,8.474-23  c0.924-10.885,1.311-46.844,0.77-66.316c-0.308-11.5-0.231-13.494,1.079-17.25l1.463-4.217  C455.045,244.142,456.276,248.077,457.216,251.555z M450.209,293.413c0.158,1.814-0.079,3.628,0.074,5.442  c-12.414-3.017-25.982-6.293-37.053-8.431v-5.29c0-2.838,0.155-5.215,0.309-5.215C425.697,283.746,439.022,288.868,450.209,293.413  L450.209,293.413z M450.437,300.085l-0.539,13.49c-0.616,16.179-1.771,26.223-3.005,27.371c-1.001,0.922-29.04,6.364-32.969,6.44  c-0.144-18.511-0.091-36.161-0.676-55.392C427.363,294.782,437.773,296.733,450.437,300.085z M446.491,342.552  c-3.264,7.961-26.07,24.471-33.013,26.792c0.023-7.387,0.335-12.718,0.44-20.677C425.13,348.366,434.441,345.229,446.491,342.552z   M376.486,351.987c8.166,4.062,13.019,11.958,13.096,21.082c0.153,21.084-25.575,31.895-40.442,16.866  c-5.701-5.75-8.012-13.493-6.316-21.619c1.618-7.82,5.931-13.11,13.788-16.867C361.851,348.921,371.017,349.15,376.486,351.987z   M386.018,454.523c-24.643-7.498-20.478-37.606-21.703-49.944c8.263-1.528,13.692-2.556,20.144-5.188  C386.77,411.735,386.712,434.899,386.018,454.523L386.018,454.523z M482.879,92.246c-14.483,6.976-19.048,13.116-19.202,29.983  c-0.077,7.207,0.154,9.277,1.31,10.887c1.541,2.453,1.618,5.75,0.54,19.167c-4.622,58.036-6.24,145.741-3.621,203.396  c0.771,16.866,1.541,31.354,1.771,32.274c0.231,0.844,0,9.966-0.462,20.316c-0.461,10.275-0.616,23.308-0.308,28.98  c0.54,9.891,0.617,10.351,2.85,12.804c2.542,2.912,5.701,4.063,18.256,6.438c27.347,5.213,67.866,5.213,93.671,0  c12.557-2.529,15.33-3.526,17.872-6.438c2.081-2.378,2.388-3.374,2.852-9.431c0.385-3.68,0.307-14.489-0.078-23.996  c-0.849-23.152-0.849-24.15,0.463-48.3c1.232-23.306,1.616-124.198,0.538-154.789c-0.538-15.333-2.694-52.898-4.082-70.762  c-0.462-5.827-0.309-6.977,0.925-8.816c1.23-1.84,1.464-3.527,1.386-11.346c-0.078-17.251-2.613-22.89-17.172-29.79  c-16.254-7.743-32.359-11.15-47.072-11.61C516.066,80.77,496.85,85.613,482.879,92.246L482.879,92.246z M541.016,82.746  c18.641,2.765,46.692,9.602,53.417,23.954c1.252,7.431,3.949,18.915,0.505,26.646c-0.807-9.15-0.657-20.963-6.547-27.83  c-33.242-27.001-83.766-23.948-114.932-0.766c-3.234,3.45-5.006,8.816-5.7,17.787c-1.002,12.496-0.925,11.96-2.157,9.736  c-1.464-2.53-1.232-16.023,0.308-21.927C474.805,89.309,519.655,80.218,541.016,82.746L541.016,82.746z M546.331,88.573  c13.019,2.07,36.513,12.19,41.288,17.786c3.775,4.37,4.624,9.123,6.55,37.336c0.461,6.517,1.307,19.167,1.925,28.06  c1.156,16.637,1.744,31.97,0.974,31.97c-0.232,0-3.952-3.367-6.955-5.054c-12.865-7.512-27.234-12.905-41.64-15.896  c-20.952-4.37-44.548-2.896-68.678,8.86c-4.085,1.99-15.442,10.854-14.903,11.391c20.506-18.641,71.914-37.929,132.126,0.699  c-0.155,0.536-4.546,11.5-9.706,24.38l-9.399,23.459l-6.084-1.763c-15.484-4.447-28.732-6.057-46.22-5.443  c-12.94,0.383-24.187,2.224-36.127,5.903c-2.773,0.843-5.084,1.38-5.161,1.303c-6.572-15.625-13.515-32.687-19.952-47.686  l0.077-10.733c0-5.903,0.463-16.407,0.925-23.383c0.539-6.976,1.31-17.863,1.695-24.15c2.08-30.129,3.08-35.572,7.164-39.866  C494.784,91.11,521.443,84.841,546.331,88.573L546.331,88.573z M598.714,249.342l0.078,29.285l-2.467,2.379  c-2.62,2.375-17.101,12.188-18.024,12.188c-0.309,0-0.309-9.199,0-20.545l0.462-20.47c6.339-15.672,12.605-31.374,18.874-47.073  l0.459,7.437C598.406,216.605,598.635,233.165,598.714,249.342L598.714,249.342z M483.629,252.708  c0.562,13.755-0.062,26.981-0.192,40.743c-8.123-5.379-14.416-8.699-21.686-13.673l0.385-19.934  c0.539-33.196,1.232-54.05,1.771-54.05C471.082,222.104,476.591,235.804,483.629,252.708z M576.836,252.331l0.384,46.308  c0.232,25.451,0.232,46.535,0,46.918c-1.54,1.993-22.338,6.363-35.819,7.591c-15.175,1.38-33.355-0.538-50.841-5.292  c-7.396-1.992-7.086-0.766-6.395-23.228c0.309-10.733,0.54-31.203,0.463-45.388c-0.077-14.259,0.078-26.066,0.308-26.295  C517.678,242.323,549.451,244.457,576.836,252.331L576.836,252.331z M483.242,294.881c0.04,2.454-0.138,5.03-0.054,7.646  c-7.575-3.102-13.558-5.925-21.515-9.562c0.064-3.671,0.018-8.049,0.142-11.602C469.351,285.863,475.662,290.003,483.242,294.881z   M598.618,316.696c0.002,9.219-0.038,27.267-0.612,33.407c-6.097-2.274-12.982-4.328-18.962-7.138  c-0.309-0.229-0.291-8.987-0.59-19.564l-0.54-19.167l6.856-3.145c7.551-3.525,13.248-7.042,14.265-7.709  c-0.047-0.71-0.05-0.726-0.087-1.688c-7.788,4.178-15.7,8.178-20.889,10.863l-0.067-7.676c7.35-4.841,14.521-9.412,20.672-14.518  C598.99,293.265,598.567,306.243,598.618,316.696L598.618,316.696z M482.859,303.926c0.494,14.209,0.002,25.512-0.771,39.255  c-6.265,2.495-12.569,4.886-18.873,7.283c-1.18-14.479-1.312-42.912-1.244-55.868C469.358,297.579,475.506,300.524,482.859,303.926  L482.859,303.926z M482.693,344.997c0.083,7.261-14.866,25.866-18.591,27.057c-0.648-7.612-0.729-11.957-1.119-20.287  C466.454,350.704,479.151,345.529,482.693,344.997z M598.25,351.612c-0.194,6.951-0.66,14.188-0.809,20.954  c-9.377-6.706-18.243-16.727-18.423-27.903C586.128,347.254,591.578,349.153,598.25,351.612z M511.36,353.684  c-4.627-0.426-9.038-0.521-13.943-1.229c-3.159-0.688-6.085,3.223-10.554,13.954c-6.085,14.645-7.164,17.863-6.161,18.858  c11.884,5.747,97.785,5.854,102.991-0.459c0.54-1.992-1.81-8.027-2.887-8.027c1.634,5.927,2.518,8.448-2.967,9.255  c-7.693,0.623-88.604,4.923-96.136-2.606c0-2.606,9.783-25.837,11.708-27.981c1.694-1.765,2.002-1.842,9.089-1.384  c8.937,0.616,34.82,0.693,53.383,0.154c12.864-0.382,13.712-0.306,15.099,1.151c2.5,3.394,9.624,23.097,9.808,20.928  c0-2.839-7.729-20.391-9.808-21.927c-2.311-1.686-2.466-1.762-13.404-1.149l-8.473,0.537l6.472-1.226  c3.542-0.689,9.936-2.147,14.172-3.372c8.32-2.301,9.013-2.224,9.013,1.38c0,3.754,6.47,12.803,14.251,19.933  c5.006,4.599,4.777,2.682,3.083,26.526c-2.852,40.172-3.159,42.933-4.854,46.459c-10.011,12.44-44.77,10.351-60.24,10.351  c-14.368,0.067-28.617,0.086-42.752-2.379c-18.951-2.912-19.336-3.447-21.107-29.056c-0.462-6.745-1.387-19.164-2.003-27.601  c-1.617-21.849-2.081-19.471,4.313-25.452c7.378-6.738,10.482-12.456,13.866-20.471c0.77-1.608,1.156-1.762,2.773-1.148  C494.434,350.274,503.574,352.235,511.36,353.684L511.36,353.684z M466.296,426.21c1.232,16.866,2.234,19.702,7.395,22.769  c2.542,1.456,14.173,3.833,26.5,5.291c10.475,1.302,50.763,1.302,61.239,0c11.093-1.305,23.187-3.757,25.807-5.059  c2.849-1.457,5.237-4.526,6.163-7.976c0.384-1.533,1.077-7.819,1.539-13.878c1.774-23.304,2.081-23.536,2.235-1.763l0.077,20.854  l-2.388,2.763c-2.542,2.835-4.236,3.446-15.716,5.749c-7.086,1.456-7.702,1.531-18.872,3.141  c-8.474,1.229-50.686,1.306-58.543,0.077c-3.16-0.459-7.318-1.073-9.244-1.381c-4.005-0.534-16.869-3.065-20.799-4.14  c-1.541-0.381-3.774-1.839-5.006-3.065l-2.311-2.376l-0.078-22.004C464.138,402.442,464.525,402.675,466.296,426.21L466.296,426.21z   M675.049,85.046c-7.935,2.684-13.789,5.979-15.866,9.046c-0.927,1.38-2.931,7.13-4.47,12.803  c-10.168,37.031-11.017,40.48-14.943,59.417l-2.853,13.799l-5.313,8.816c-11.939,19.933-23.11,44.006-28.04,60.26  c-1.616,5.29-1.694,6.287-1.466,50.983l0.234,45.54c4.616,18.327,16.789,28.214,28.192,41.477l5.819,8.18  c2.854,12.956-1.938,27.785,7.362,48.898c9.683,7.816,19.129,8.968,28.802,12.609c1.616,4.141,15.403-3.758,19.949-11.424  c2.083-3.604,3.006-8.74,4.236-23.843c1.696-20.622,1.466-19.626,5.009-20.699c12.865-3.833,21.722-16.482,20.028-28.672  c-2.668-12.017-8.876-19.122-18.488-22.312v-79.502c1.708-27.72,0.079-57.25-0.067-84.818c5.638-0.482,13.703-8.868,16.321-14.54  c4.685-15.65-0.815-30.197-15.561-35.649l-3.775-1.303l0.232-24.38l0.155-24.304c-5.796,1.094-10.429-4.436-14.561-4.599  C681.754,80.999,680.738,83.83,675.049,85.046L675.049,85.046z M699.777,86.962c-0.073,13.648-0.851,29.424-1.004,43.07  c-6.462-0.675-8.383-0.454-14.908,0.833c-0.244-9.856-0.571-42.115-0.198-48.388C688.12,81.063,692.117,86.962,699.777,86.962z   M682.444,131.506c-4.985,3.467-10.343,7.304-13.866,12.189c-12.04,22.947,1.799,43.133,22.492,46.766  c3.761,0.537,7.407,1.332,11.018,2.454l-0.154,75.516l-0.23,75.594c-3.459,1.225-6.129,1.972-9.476,2.836l-0.46-72.68  c-0.309-40.403-0.266-74.73-0.651-75.649c-12.912-5.893-29.202-2.623-44.413,4.504c-2.142-9.381-5.322-16.221-8.319-23.46  l2.541-12.573c4.313-20.623,16.64-67.466,18.875-71.759c6.257-5.931,13.419-9.103,21.823-10.896  C682.072,107.52,682.141,100.851,682.444,131.506L682.444,131.506z M703.32,138.406c9.856,4.422,15.362,13.476,15.254,22.157  c-2.244,15.136-10.7,23.339-23.418,23.383c-7.628-0.077-12.559-2.224-17.64-7.743C660.722,157.956,680.055,129.742,703.32,138.406z   M644.698,203.495c1.002,8.281,2.62,44.006,2.695,59.8l0.157,17.249c-12.59,5.103-25.923,8.812-36.243,13.849  c0.259-12.708,0.037-25.917,1.115-38.612c8.301-24.065,18.9-31.146,31.657-49.679c-12.649,14.452-25.932,30.312-32.353,47.303  c-1.205-3.889-1.796-8.163-3.543-11.806c-1.077-1.074,15.33-38.104,16.946-38.104c0.232,0,0.693-0.689,0.926-1.609  c0.384-1.381,11.323-20.624,11.787-20.624C640.698,188.311,643.843,196.408,644.698,203.495L644.698,203.495z M686.063,198.128  c1.62,0.46,3.16,1.457,3.546,2.147c0.308,0.69,0.694,20.623,0.845,44.237l0.233,42.932c-13.916-0.152-27.832-0.306-41.752-0.459  v-12.804c0-7.053-0.539-24.533-1.155-38.87c-1.463-34.116-1.54-30.896,1.001-32.045  C659.224,198.708,675.127,195.566,686.063,198.128L686.063,198.128z M611.115,255.188c-1.23,6.209-1.621,58.784-0.388,74.038  c1.465,17.558,2.541,19.703,13.864,28.673c6.56,5.475,28.376,23.912,42.356,16.221c0,6.079,0.061,9.933,1.061,19.476  c1.105,2.542,3.01,4.271,5.952,6.49c-2.164,18.917,0.874,34.507-0.83,54.921c-7.938-3.212-23.419-5.328-28.972-12.312  c-5.131-14.112-5.078-28.899-5.236-43.395c0-3.373-0.389-4.984-1.234-5.75c-9.499-12.148-23.662-26.016-29.656-37.871  c-5.239-11.348-5.316-11.883-5.316-57.729l0.343-43.125c1.691-4.459,1.845-8.067,4.357-11.847  C609.668,248.366,608.698,246.662,611.115,255.188L611.115,255.188z M647.78,292.429c-12.456,2.458-24.261,5.246-36.545,8.433  c-0.155,0-0.024-3.83-0.024-5.288c5.09-1.708,30.802-12.527,36.224-13.35C647.938,285.729,647.592,288.898,647.78,292.429  L647.78,292.429z M690.764,300.629c0.923,21.085,0.694,45.31-0.386,46.001c-7.068,3.159-14.443,4.167-22.952,8.769  c-1.807,6.673-0.421,12.18-0.667,17.277c-3.887,1.188-9.271,2.225-18.082-0.729c0-0.923,0.029-20.948,0.104-43.103l0.155-40.251  c13.789,0,27.576,0,41.367,0L690.764,300.629L690.764,300.629z M647.104,348.679c-6.613-1.303-26.977-3.932-33.117-5.661  c-2.048-14.583-2.261-26.27-2.752-40.481c14.354-2.665,23.825-7.397,36.405-8.527C647.516,312.114,648.126,335.444,647.104,348.679  L647.104,348.679z M647.012,350.311c0.151,7.307,0.307,14.617,0.46,21.927c-10.212-7.044-27.972-17.646-32.731-27.234  C625.44,347.006,636.595,349.234,647.012,350.311L647.012,350.311z M705.015,353.759c8.549,3.682,14.557,13.647,13.789,22.77  c-1.543,17.403-19.721,27.602-34.896,19.55c-12.48-6.669-16.485-22.31-8.784-33.962c2.236-3.374,7.551-7.513,11.711-9.2  C691.533,351.077,699.699,351.383,705.015,353.759L705.015,353.759z M696.388,404.455c-1.306,12.822-0.234,28.367-5.469,40.996  c-2.312,3.988-10.657,8.894-15.667,11.194c0.032-12.976,0.353-32.571,0.508-56.339C682.638,402.652,688.953,403.613,696.388,404.455  z M592.34,457.527c-0.034,2.569,0.749,3.759-2.717,3.759h-2.849c-2.641,6.25-5.248,12.517-7.858,18.781l-7.55,0.46  c-4.236,0.308-26.575,0.537-49.685,0.615l-42.136,0.074c-2.753-6.522-5.537-13.035-8.319-19.548l-2.851-0.078  c-3.543-0.075-3.775-0.229-2.926-3.219c0.384-1.381,0.461-2.454,0.077-2.454c-1.695,0-4.313,20.009-3.236,24.072  c0.539,1.764,0.463,2.914,0,3.375c-1.386,1.381-0.925,6.516,0.848,9.89c1.387,2.837,1.618,4.522,1.618,13.186  c0,5.826,0.308,10.121,0.771,10.426c0.462,0.231,0.771,1.995,0.771,3.836c0,5.29,0.924,5.748,11.477,5.748  c6.393,0,9.398-0.306,9.86-0.996c0.462-0.46,1.002-3.604,1.31-6.9c0.231-3.296,0.615-6.362,0.924-6.746  c0.232-0.383,6.394-0.69,13.711-0.69c11.555,0,13.481,0.154,14.405,1.304c1.388,1.609,8.243,4.829,10.4,4.829  c2.234,0,7.01-2.068,9.936-4.291c2.389-1.765,2.851-1.842,16.332-1.842h13.865l0.54,3.528c0.303,1.981,0.462,4.675,0.462,5.979  c0,1.303,0.539,3.219,1.232,4.14c1.079,1.61,1.771,1.686,10.245,1.686c6.395,0,9.476-0.308,10.476-1.073  c1.928-1.379,2.851-7.36,3.159-20.163c0.155-7.898,0.462-10.58,1.542-12.113c1.923-2.989,2.311-8.354,0.691-10.811  c-0.922-1.38-1.154-2.76-0.845-4.521c0.768-3.758-2.157-22.618-3.468-22.618C592.243,455.15,592.336,456.169,592.34,457.527  L592.34,457.527z M593.938,464.888c0.835,5.211,0.616,9.878,0.616,15.18c-4.695-0.051-8.975,0.218-14.251,0.077  c0-0.613,2.695-7.282,5.316-12.957c2.233-4.906,2.465-5.136,5.005-5.136C593.089,462.052,593.938,465.586,593.938,464.888  L593.938,464.888z M477.85,480.604c-5.158,0.95-9.21,0.612-14.867,0.612c0.464-5.88,0.334-11.916,1.387-17.708  c2.07-0.917,3.855-0.69,6.163-0.69C472.932,468.751,475.796,474.554,477.85,480.604L477.85,480.604z M595.247,482.445  c2.311,2.224,2.389,4.981,0.229,9.045c-1.077,2.146-2.155,5.138-2.387,6.67c-0.736,2.907-2.377,4.52-4.467,6.441  c-14.329,0.152-28.657,0.307-42.984,0.46c0-2.838,0-5.674,0-8.512c-10.271,0-20.542,0-30.814,0c0,2.813,0,5.623,0,8.434h-22.106  c-25.344,0-24.881,0.078-26.73-6.516c-0.836-4.19-4.277-9.342-3.082-13.187l0.694-2.146c42.013-1.018,84.109-0.045,126.102-1.765  C592.783,481.293,594.399,481.522,595.247,482.445z M544.098,504.219c-9.244,0-18.488,0-27.732,0c0-2.046,0-4.09,0-6.134  c9.244,0,18.488,0,27.732,0C544.098,500.129,544.098,502.173,544.098,504.219z M470.686,505.827  c6.344,0.929,11.344,0.69,17.949,0.69c0,3.092,0,6.187,0,9.276c-7.576-0.154-15.15-0.309-22.725-0.46  c-0.154-4.6-0.308-9.2-0.461-13.799C466.99,503.179,468.652,504.934,470.686,505.827L470.686,505.827z M593.399,515.794  c-7.832-0.154-15.664-0.307-23.497-0.46c-0.101-3.193-0.204-6.388-0.309-9.584c12.071,0.201,16.532,0.47,20.825-0.41  c1.157-0.995,2.67-3.422,2.826-3.422C593.427,506.731,593.399,510.856,593.399,515.794z M568.747,510.352  c-9.525,0-18.858,0.289-28.384,0.289c0,0-7.221,5.428-11.658,5.272c-4.438-0.154-6.328-0.983-11.489-5.66  c-2.384-0.186-19.786-0.252-27.462-0.224l-0.426-3.512l32.584-0.229c15.615-0.055,31.227-0.198,46.835-0.538  C568.747,507.351,568.747,508.71,568.747,510.352L568.747,510.352z M477.465,524.917c-10.729-0.021-10.4,0.012-10.4-7.667  c6.935,0,13.867,0,20.8,0C488.006,526.384,484.924,524.719,477.465,524.917L477.465,524.917z M591.471,524.535  c-6.675,0-13.352,0-20.028,0c-0.15-2.43-0.306-4.856-0.461-7.285c6.983,0,13.968,0,20.953,0  C591.777,519.679,591.625,522.107,591.471,524.535z"
    }
  }), _c("path", {
    attrs: {
      id: "vehicle_lines",
      "sodipodi:nodetypes": "cccccccccccccssccccssccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path4559",
      fill: "none",
      stroke: "#005AFF",
      "stroke-width": "1.6342",
      "stroke-dasharray": "9.8052,9.8052",
      d: "  M528.732,371.812v-25.191 M528.732,190.973v63.556 M489.64,254.651h83.248v88.897H489.64V254.651z M528.732,373.482v144.365   M529.534,371.812l143.145,0.374c0,0,2.806-11.453,9.986-15.479c8.805-4.939,18.997-2.896,27.898,1.881  c3.755,2.012,7.297,13.177,7.297,13.177h26.383 M317.847,371.766h25.015c0,0,4.847-13.19,8.691-15.568  c7.722-4.773,17.256-6.337,25.295-2.086c8.051,4.257,11.618,17.53,11.618,17.53l140.265,0.171 M316.002,194.35h211.679h213.766   M528.92,48.816l-0.188,145.534"
    }
  }), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleBackRight"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleBackRight",
      x: "528.513",
      y: "372.97",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "156.866"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleBackRight",
      "sodipodi:nodetypes": "ccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#back_right",
      opacity: _vm.areaSeverity.BackRight.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M530.343,460.374c20.075-0.237,40.489-1.454,59.771-7.115c5.648-1.737,8.043-7.517,8.016-12.963   c1.19-19.005-1.461-38.056-0.296-57.089c-0.978-3.126,2.751-10.66-1.917-10.208c-21.859,0-43.717,0-65.574,0   C530.343,402.123,530.343,431.247,530.343,460.374z M618.594,373.646c5.904,7.552,13.201,14.232,18.056,22.448   c1.598,15.241,1.164,30.946,5.223,45.736c5.219,8.167,15.923,9.09,24.169,12.698c2.848,0.326,5.249,1.452,7.244,3.281   c5.46,0.324,10.24-3.916,14.18-7.067c8.353-7.288,7.952-19.073,8.941-29.128c0.46-6.708,0.881-13.434,2.327-20.009   c3.095-0.506,6.226-1.428,4.812-5.345c-10.81,4.72-25.179-0.525-29.959-11.594c-1.704-3.614-2.555-7.644-2.393-11.668   c-17.701,0-35.406,0-53.104,0l0.474,0.604L618.594,373.646L618.594,373.646z M592.257,454.29c-1.146,1.946,1.269,7.395-2.817,5.844   c-4.489-1.027-4.475,5.403-6.137,8.02c-1.974,3.416-2.585,8.764-5.344,11.04c-15.86,0.793-31.74,0.989-47.615,1.044   c0.031,12.151-0.064,24.512,0.049,36.533c5.27-1.862,9.57-6.674,15.67-5.652c7.258-0.267,14.523,0.088,21.785-0.096   c2.048,4.717-0.899,11.568,3.875,14.855c6.351,0.534,13.5,1.549,19.379-0.913c3.56-4.859,2.493-11.459,3.249-17.105   c-0.097-6.289-0.11-12.777,2.817-18.472c1.4-3.847-0.432-7.682-1.398-11.213C595.913,470.187,595.332,461.466,592.257,454.29   L592.257,454.29z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleBackRight",
      "sodipodi:nodetypes": "ccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#back_right",
      opacity: _vm.areaHoverOpacity.BackRight,
      "enable-background": "new    ",
      d: "   M530.524,460.007c20.075-0.236,40.49-1.453,59.771-7.113c5.648-1.738,8.043-7.517,8.016-12.963   c1.19-19.005-1.461-38.057-0.296-57.09c-0.978-3.125,2.75-10.66-1.917-10.208c-21.859,0-43.717,0-65.574,0   C530.524,401.758,530.524,430.882,530.524,460.007z M618.775,373.28c5.905,7.552,13.203,14.231,18.057,22.447   c1.598,15.241,1.163,30.947,5.223,45.736c5.218,8.167,15.923,9.09,24.168,12.697c2.848,0.326,5.251,1.454,7.245,3.283   c5.459,0.322,10.24-3.917,14.18-7.068c8.352-7.288,7.952-19.073,8.941-29.129c0.46-6.707,0.881-13.432,2.326-20.008   c3.096-0.505,6.228-1.428,4.813-5.345c-10.81,4.721-25.179-0.524-29.96-11.595c-1.703-3.613-2.555-7.642-2.392-11.667   c-17.702,0-35.405,0-53.104,0l0.473,0.604L618.775,373.28L618.775,373.28z M592.438,453.924c-1.146,1.946,1.269,7.396-2.817,5.845   c-4.489-1.027-4.475,5.401-6.137,8.019c-1.974,3.417-2.585,8.764-5.344,11.04c-15.859,0.793-31.74,0.989-47.615,1.043   c0.032,12.151-0.064,24.512,0.049,36.534c5.27-1.862,9.571-6.673,15.67-5.652c7.258-0.267,14.524,0.088,21.785-0.096   c2.048,4.717-0.899,11.569,3.875,14.855c6.351,0.533,13.5,1.549,19.379-0.913c3.56-4.859,2.493-11.458,3.249-17.104   c-0.096-6.291-0.11-12.778,2.817-18.473c1.4-3.846-0.432-7.683-1.398-11.214C596.094,469.82,595.513,461.1,592.438,453.924   L592.438,453.924z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleMiddleRight"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleMiddleRight",
      x: "528.331",
      y: "194.906",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "176.53"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleMiddleRight",
      "sodipodi:nodetypes": "scccccccccccscccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#middle_right",
      opacity: _vm.areaSeverity.MiddleRight.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M530.802,253.193c14.283,0,28.567,0,42.85,0c0,29.865,0,59.736,0,89.603c-14.283,0-28.567,0-42.85,0c0,8.851,0,17.697,0,26.544   c22.677,0,45.353,0,68.029,0c1.755-35.68,1.109-71.426,1.418-107.139c-0.061-20.121-0.336-40.245-1.128-60.35l-0.169-3.858   c0.931-5.738-7.334-1.961-10.904-3.042c-19.081,0-38.163,0-57.246,0C530.802,214.365,530.802,233.779,530.802,253.193   L530.802,253.193z M626.157,197.634c-9.632,17.765-19.003,36.183-23.614,55.894c-1.491,26.52,0.064,53.093-0.359,79.638   c0.018,6.366-0.562,13.027,2.909,18.614c2.796,6.23,6.163,12.411,10.833,17.56c18.689,0,37.377,0,56.064,0   c1.872-11.352,13.817-19.644,25.18-18.278c2.352,0.149,4.673,0.705,6.838,1.606c-0.979-12.496-0.348-26.117-0.531-39.149   c0.038-39.521,0.11-79.047-0.409-118.567c-25.13,0-50.264,0-75.396,0C627.169,195.846,626.664,196.74,626.157,197.634z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleMiddleRight",
      "sodipodi:nodetypes": "scccccccccccscccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#middle_right",
      opacity: _vm.areaHoverOpacity.MiddleRight,
      "enable-background": "new    ",
      d: "   M529.887,254.107c14.283,0,28.567,0,42.85,0c0,29.865,0,59.735,0,89.602c-14.282,0-28.567,0-42.85,0c0,8.851,0,17.697,0,26.545   c22.677,0,45.352,0,68.028,0c1.755-35.681,1.109-71.426,1.418-107.139c-0.061-20.121-0.336-40.245-1.128-60.35l-0.17-3.858   c0.932-5.738-7.334-1.961-10.904-3.042c-19.081,0-38.163,0-57.245,0C529.887,215.279,529.887,234.693,529.887,254.107   L529.887,254.107z M625.242,198.548c-9.632,17.765-19.003,36.183-23.614,55.894c-1.491,26.52,0.063,53.093-0.36,79.636   c0.02,6.368-0.562,13.028,2.91,18.614c2.796,6.231,6.163,12.413,10.833,17.562c18.689,0,37.377,0,56.063,0   c1.872-11.352,13.818-19.644,25.181-18.279c2.352,0.15,4.673,0.706,6.838,1.606c-0.979-12.495-0.348-26.116-0.532-39.148   c0.038-39.521,0.11-79.047-0.408-118.567c-25.131,0-50.265,0-75.397,0C626.253,196.759,625.749,197.653,625.242,198.548z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleBackLeft"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleBackLeft",
      x: "313.396",
      y: "370.853",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "156.865"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleBackLeft",
      "sodipodi:nodetypes": "cccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#back_left",
      opacity: _vm.areaSeverity.BackLeft.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M388.98,373.295c0.927,15.626-17.204,27.222-31.414,21.778c-1.463,3.983,1.586,4.8,4.743,4.887   c1.493,14.646,0.352,30.077,5.681,43.892c4.081,6.499,11.3,11.745,18.946,12.337c4.127-3.739,10.098-3.723,14.972-6.037   c7.155-2.781,16.644-5.952,17.669-14.781c2.294-13.845,2.972-28.277,3.731-42.144c5.504-6.8,11.219-13.427,16.851-20.125   C423.165,373.231,405.653,372.849,388.98,373.295z M462.507,377.654c2.212,23.388-2.75,47.134,1.035,70.319   c3.98,7.452,14.172,7.229,21.429,9.056c13.938,2.242,28.065,3.506,42.218,3.664c0-29.115,0-58.233,0-87.351   c-21.649,0-43.298,0-64.947,0C462.329,374.781,462.418,376.219,462.507,377.654z M465.06,455.423   c-3.641,8.456-3.67,18.145-3.251,27.217c-3.474,6.805,3.538,12.967,2.311,19.909c-0.018,5.89-0.167,11.992,1.421,17.515   c-0.552,3.179,1.391,7.283,5.219,6.398c5.346,0.062,11.622,1.371,16.349-1.104c2.214-4.188,0.796-9.199,2.647-13.535   c9.051-0.201,18.483-1.423,27.323,0.551c2.958,2.335,6.327,4.473,10.11,4.936c0-12.243,0-24.485,0-36.728   c-15.968,0.002-31.937-0.074-47.905,0.072c-2.906-6.499-5.497-13.429-8.569-19.67c-2.469,0.812-7.149-0.18-5.512-3.641   C465.65,456.76,465.846,455.672,465.06,455.423L465.06,455.423z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleBackLeft",
      "sodipodi:nodetypes": "cccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#back_left",
      opacity: _vm.areaHoverOpacity.BackLeft,
      "enable-background": "new    ",
      d: "   M388.98,373.295c0.927,15.626-17.204,27.222-31.414,21.778c-1.463,3.983,1.586,4.8,4.743,4.887   c1.493,14.646,0.352,30.077,5.681,43.892c4.081,6.499,11.3,11.745,18.946,12.337c4.127-3.739,10.098-3.723,14.972-6.037   c7.155-2.781,16.644-5.952,17.669-14.781c2.294-13.845,2.972-28.277,3.731-42.144c5.504-6.8,11.219-13.427,16.851-20.125   C423.165,373.231,405.653,372.849,388.98,373.295z M462.507,377.654c2.212,23.388-2.75,47.134,1.035,70.319   c3.98,7.452,14.172,7.229,21.429,9.056c13.938,2.242,28.065,3.506,42.218,3.664c0-29.115,0-58.233,0-87.351   c-21.649,0-43.298,0-64.947,0C462.329,374.781,462.418,376.219,462.507,377.654z M465.06,455.423   c-3.641,8.456-3.67,18.145-3.251,27.217c-3.474,6.805,3.538,12.967,2.311,19.909c-0.018,5.89-0.167,11.992,1.421,17.515   c-0.552,3.179,1.391,7.283,5.219,6.398c5.346,0.062,11.622,1.371,16.349-1.104c2.214-4.188,0.796-9.199,2.647-13.535   c9.051-0.201,18.483-1.423,27.323,0.551c2.958,2.335,6.327,4.473,10.11,4.936c0-12.243,0-24.485,0-36.728   c-15.968,0.002-31.937-0.074-47.905,0.072c-2.906-6.499-5.497-13.429-8.569-19.67c-2.469,0.812-7.149-0.18-5.512-3.641   C465.65,456.76,465.846,455.672,465.06,455.423L465.06,455.423z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleMiddleLeft"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleMiddleLeft",
      x: "313.396",
      y: "194.744",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "176.53"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleMiddleLeft",
      "sodipodi:nodetypes": "ccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#middle_left",
      opacity: _vm.areaSeverity.MiddleLeft.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M357.566,351.108c10.654-3.829,23.301,1.042,28.525,11.069c1.325,2.446,2.266,5.094,2.625,7.861c17.997,0,35.996,0,53.994,0   c10.457-10.724,16.933-25.426,16.184-40.469c0.452-25.629,0.481-51.335,0.009-76.925c-5.458-20.033-14.655-38.853-24.597-56.999   c-25.581,0-51.162,0-76.742,0c0,51.821,0,103.643,0,155.462H357.566z M462.219,199.36c-2.532,56.926-3.107,113.998-0.169,170.916   c21.713,0,43.427,0,65.14,0c0-8.848,0-17.694,0-26.545c-12.654,0-25.308,0-37.962,0c0-29.866,0-59.736,0-89.602   c12.654,0,25.309,0,37.962,0c0-19.415,0-38.828,0-58.242c-21.601,0-43.202,0-64.803,0   C462.329,197.044,462.274,198.202,462.219,199.36L462.219,199.36z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleMiddleLeft",
      "sodipodi:nodetypes": "ccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#middle_left",
      opacity: _vm.areaHoverOpacity.MiddleLeft,
      "enable-background": "new    ",
      d: "   M357.566,351.108c10.654-3.829,23.301,1.042,28.525,11.069c1.325,2.446,2.266,5.094,2.625,7.861c17.997,0,35.996,0,53.994,0   c10.457-10.724,16.933-25.426,16.184-40.469c0.452-25.629,0.481-51.335,0.009-76.925c-5.458-20.033-14.655-38.853-24.597-56.999   c-25.581,0-51.162,0-76.742,0c0,51.821,0,103.643,0,155.462H357.566z M462.219,199.36c-2.532,56.926-3.107,113.998-0.169,170.916   c21.713,0,43.427,0,65.14,0c0-8.848,0-17.694,0-26.545c-12.654,0-25.308,0-37.962,0c0-29.866,0-59.736,0-89.602   c12.654,0,25.309,0,37.962,0c0-19.415,0-38.828,0-58.242c-21.601,0-43.202,0-64.803,0   C462.329,197.044,462.274,198.202,462.219,199.36L462.219,199.36z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleFrontRight"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleFrontRight",
      x: "530.189",
      y: "24.164",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "170.212"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleFrontRight",
      "sodipodi:nodetypes": "ccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#front_right",
      opacity: _vm.areaSeverity.FrontRight.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M576.778,32.969c-3.531-0.04-8.187,0.353-8.499,4.816c-0.684,3.782-0.14,7.704-1.202,11.429c-12.27,0-24.538,0-36.807,0   c0,7.307,0,14.614,0,21.921c9.204,0,18.407,0,27.61,0c-0.407,10.203,8.995,17.447,18.536,18.112   c5.103,1.01,10.256,1.564,15.478,1.461c0.002,2.228-1.595,4.913-0.961,6.875c3.079-4.857,2.736-11.325,3.61-16.915   c0.803-3.849-0.929-8.25,0.265-11.594c2.983-3.728,0.069-8.292-1.324-11.908c-0.956-6.202,1.03-24.093-5.074-24.004   C585.365,32.988,579.832,32.876,576.778,32.969z M684.071,80.312c-3.27,0.444-5.397,3.82-8.856,4.073   c-7.352,2.528-16.803,5.586-18.354,14.382c-6.521,20.013-11.618,40.6-16.264,61.11c-2.153,9.699-3.011,20.176-9.098,28.367   c-4.987,5.361,0.241,4.85,5.056,4.576c21.904-0.145,44.389,0.288,65.933-0.216c-0.525-3.667,0.546-6.14,0.988-9.127   c0.696-3.079-2.94,0.062-4.599-0.288c-12.635,2.501-25.511-6.829-27.563-19.381c-3.5-15.291,12.855-30.368,27.971-26.067   c2.986,1.09,5.379,2.241,4.191-2.372c-2.291-1.54-4.954-2.588-3.556-6.756c0.132-14.519,0.262-29.038,0.354-43.558   c-4.312,0.645-7.9-2.028-11.002-4.335C687.633,80.149,685.811,80.24,684.071,80.312L684.071,80.312z M530.271,192.819   c22.627,0,45.255,0,67.883,0c-0.649-19.129-2.86-38.178-3.272-57.307c4.422-7.575,1.896-16.805,1.638-25.013   c-1.551-9.717-10.636-15.23-19.042-18.615c-14.823-6.831-30.844-11.02-47.206-11.308   C530.271,117.99,530.271,155.405,530.271,192.819L530.271,192.819z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleFrontRight",
      "sodipodi:nodetypes": "cccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#front_right",
      opacity: _vm.areaHoverOpacity.FrontRight,
      "enable-background": "new    ",
      d: "   M576.778,32.969c-12.243-0.436-7.316,7.389-9.701,16.245c-12.27,0-24.538,0-36.807,0c0,7.307,0,14.614,0,21.921   c9.204,0,18.407,0,27.61,0c1.785,17.55,17.526,19.121,34.014,19.574c0.002,2.228-1.595,4.913-0.961,6.875   c5.575-7.743,2.871-21.15,3.875-28.135c2.983-3.727,0.069-8.667-1.324-12.282c-0.956-6.202,0.534-23.597-4.875-24.004   C585.563,32.988,579.832,32.876,576.778,32.969z M684.071,80.312c-3.27,0.444-5.397,3.82-8.856,4.073   c-7.352,2.528-16.803,5.586-18.354,14.382c-6.521,20.013-11.618,40.6-16.264,61.11c-2.153,9.699-3.011,20.176-9.098,28.367   c-4.987,5.361,0.241,4.85,5.056,4.576c21.904-0.145,44.389,0.288,65.933-0.216c-0.525-3.667,0.546-6.14,0.988-9.127   c0.696-3.079-2.94,0.062-4.599-0.288c-12.635,2.501-25.511-6.829-27.563-19.381c-3.5-15.291,12.855-30.368,27.971-26.067   c2.986,1.09,5.379,2.241,4.191-2.372c-2.291-1.54-4.954-2.588-3.556-6.756c0.132-14.519,0.262-29.038,0.354-43.558   c-4.312,0.645-7.9-2.028-11.002-4.335C687.633,80.149,685.811,80.24,684.071,80.312L684.071,80.312z M530.271,192.819   c22.627,0,45.255,0,67.883,0c-0.649-19.129-2.86-38.178-3.272-57.307c4.422-7.575,1.896-16.805,1.638-25.013   c-1.551-9.717-10.636-15.23-19.042-18.615c-14.823-6.831-30.844-11.02-47.206-11.308   C530.271,117.99,530.271,155.405,530.271,192.819L530.271,192.819z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleFrontLeft"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("rect", {
    attrs: {
      id: "tapable_vehicleFrontLeft",
      x: "313.396",
      y: "24.164",
      opacity: "0",
      fill: "#96FF5F",
      width: "215.002",
      height: "170.212"
    }
  }), _c("path", {
    attrs: {
      id: "severity_vehicleFrontLeft",
      "sodipodi:nodetypes": "cccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#front_left",
      opacity: _vm.areaSeverity.FrontLeft.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M474.785,32.322c-3.933,0.209-11.028-0.617-11.268,4.935c-1.027,5.221-2.186,10.401-1.636,15.813   c-0.363,7.871-3.262,15.276-2.721,23.287c0.072,7.296,0.11,14.702,4.394,21.697c-0.542-5.987-0.9-5.135-1.26-7.514   c4.337-0.119,5.462,0.02,9.288-0.407c9.259-1,20.591-2.016,26.143-10.542c1.406-2.576,1.534-5.617,1.01-8.457   c9.485,0,18.969,0,28.454,0c0-7.307,0-14.614,0-21.921c-13.289,0-26.576,0-39.864,0c1.368-4.857-1.73-9.215-1.421-14.041   c-1.234-3.854-6.728-2.377-9.821-2.875C475.651,32.297,475.216,32.32,474.785,32.322L474.785,32.322z M372.178,78.539   c-4.243,1.374-6.859,3.474-12.662,4.624c-0.09,17.063-0.02,36.303-0.049,52.588c11.663-2.653,24.959,3.76,28.406,15.477   c3.993,11.618-2.471,25.793-14.564,29.181c-5.034,1.888-10.767,1.707-15.743-0.24c0.13,4.188-0.008,8.117,0,12.41   c25.012,0,50.022,0,75.034,0c-4.228-8.056-10.036-15.55-10.904-24.879c-5.033-25.214-11.804-50.178-19.163-74.762   c-5.502-8.606-17.076-9.167-25.034-14.16C375.774,78.335,373.942,78.552,372.178,78.539z M524.156,80.576   c-18.165,1.877-36.065,7.784-51.756,17.154c-7.057,4.855-9.311,13.408-9.219,21.514c-0.856,6.18,0.175,12.215,2.36,17.921   c0.581,8.605-1.298,17.2-1.325,25.827c-0.656,9.938-1.176,19.883-1.686,29.828c21.554,0,43.106,0,64.659,0   c0-37.43,0-74.861,0-112.292C526.178,80.534,525.165,80.499,524.156,80.576L524.156,80.576z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleFrontLeft",
      "sodipodi:nodetypes": "cccccccccccccccccccccccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#front_left",
      opacity: _vm.areaHoverOpacity.FrontLeft,
      "enable-background": "new    ",
      d: "   M474.785,32.322c-3.933,0.209-11.028-0.617-11.268,4.935c-1.027,5.221-2.186,10.401-1.636,15.813   c-0.363,7.871-3.262,15.276-2.721,23.287c0.072,7.296-0.122,14.139,4.327,21.598c0.253-11.095-6.51-5.769,8.095-7.822   c10.054-1.199,20.591-2.016,26.143-10.542c1.406-2.576,1.534-5.617,1.01-8.457c9.485,0,18.969,0,28.454,0   c0-7.307,0-14.614,0-21.921c-13.289,0-26.576,0-39.864,0c-0.023-7.176-0.935-11.998-1.221-14.041   c-1.235-3.854-6.927-2.377-10.021-2.875C475.651,32.297,475.216,32.32,474.785,32.322L474.785,32.322z M372.178,78.539   c-4.243,1.374-12.662,4.624-12.662,4.624l-0.048,52.588c0,0,18.597-5.914,28.405,15.477c3.993,11.618-2.471,25.793-14.562,29.181   c-5.036,1.888-10.769,1.707-15.745-0.24c0.13,4.188-0.008,8.117,0,12.41c25.012,0,50.022,0,75.034,0   c-4.228-8.056-10.036-15.55-10.904-24.879c-5.033-25.214-11.804-50.178-19.162-74.762c-5.503-8.606-17.077-9.167-25.035-14.16   C375.774,78.335,373.942,78.552,372.178,78.539L372.178,78.539z M524.156,80.576c-18.165,1.877-36.065,7.784-51.756,17.154   c-7.057,4.855-9.311,13.408-9.219,21.514c-0.856,6.18,0.175,12.215,2.36,17.921c0.581,8.605-1.298,17.2-1.325,25.827   c-0.656,9.938-1.176,19.883-1.686,29.828c21.554,0,43.106,0,64.659,0c0-37.43,0-74.861,0-112.292   C526.178,80.534,525.165,80.499,524.156,80.576L524.156,80.576z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleRoof"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("path", {
    attrs: {
      id: "severity_vehicleRoof",
      "sodipodi:nodetypes": "ccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path4773",
      opacity: _vm.areaSeverity.Roof.opacity,
      fill: "#FF0000",
      "enable-background": "new    ",
      d: "   M490.768,255.665v86.536h80.811v-86.536H490.768z"
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleRoof",
      "sodipodi:nodetypes": "ccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path4773",
      opacity: _vm.areaHoverOpacity.Roof,
      "enable-background": "new    ",
      d: "   M490.768,255.665v86.536h80.811v-86.536H490.768z",
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleEngine",
      transform: "translate(-183.72791,111.54909)"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("path", {
    attrs: {
      id: "vehicle_engine_outline",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path3972",
      d: "m 856.205,445.149 0,-6.797 4.917,0 0,0.802 -4.017,0 0,2.082 3.76,0 0,0.798 -3.76,0 0,2.314 4.174,0 0,0.801 -5.074,0 z m -6.887,0 0,-6.797 0.921,0 3.57,5.337 0,-5.337 0.865,0 0,6.797 -0.925,0 -3.569,-5.34 0,5.34 -0.862,0 z m -2.472,0 0,-6.797 0.899,0 0,6.797 -0.899,0 z m -5.479,0 0,-6.797 0.9,0 0,5.996 3.349,0 0,0.801 -4.249,0 z m -6.286,0 0,-6.797 4.916,0 0,0.802 -4.017,0 0,2.082 3.76,0 0,0.798 -3.76,0 0,2.314 4.173,0 0,0.801 -5.072,0 z m -4.419,0 -2.634,-6.797 0.975,0 1.765,4.938 c 0.145,0.396 0.261,0.768 0.357,1.112 0.105,-0.371 0.229,-0.739 0.366,-1.112 l 1.838,-4.938 0.917,0 -2.66,6.797 -0.924,0 z m -4.423,0 0,-6.797 0.9,0 0,6.797 -0.9,0 z m -7.003,0 0,-6.797 3.016,0 c 0.604,0 1.065,0.061 1.382,0.184 0.314,0.122 0.566,0.336 0.754,0.646 0.19,0.31 0.284,0.65 0.284,1.024 0,0.481 -0.155,0.891 -0.471,1.221 -0.311,0.331 -0.791,0.541 -1.444,0.631 0.239,0.112 0.418,0.225 0.541,0.339 0.265,0.241 0.511,0.541 0.747,0.903 l 1.184,1.849 -1.132,0 -0.898,-1.413 c -0.265,-0.406 -0.48,-0.721 -0.65,-0.935 -0.172,-0.219 -0.321,-0.37 -0.456,-0.456 -0.135,-0.088 -0.272,-0.148 -0.41,-0.182 -0.102,-0.021 -0.271,-0.031 -0.502,-0.031 l -1.043,0 0,3.019 -0.902,-0.002 z m 0.9,-3.795 1.933,0 c 0.413,0 0.733,-0.044 0.964,-0.127 0.232,-0.087 0.409,-0.224 0.529,-0.409 0.123,-0.187 0.182,-0.39 0.182,-0.61 0,-0.32 -0.117,-0.584 -0.351,-0.791 -0.233,-0.21 -0.601,-0.313 -1.106,-0.313 l -2.15,0 0,2.25 z m -7.777,3.795 0,-6.797 2.342,0 c 0.527,0 0.932,0.034 1.212,0.097 0.39,0.089 0.72,0.252 0.994,0.489 0.36,0.302 0.629,0.689 0.808,1.161 0.177,0.471 0.267,1.009 0.267,1.616 0,0.514 -0.062,0.973 -0.182,1.371 -0.12,0.398 -0.275,0.729 -0.464,0.989 -0.188,0.263 -0.394,0.468 -0.619,0.616 -0.224,0.152 -0.495,0.266 -0.81,0.344 -0.318,0.075 -0.684,0.113 -1.095,0.113 l -2.453,0 z m 0.899,-0.8 1.452,0 c 0.448,0 0.801,-0.042 1.055,-0.124 0.257,-0.084 0.459,-0.203 0.61,-0.355 0.212,-0.213 0.381,-0.5 0.498,-0.858 0.12,-0.359 0.18,-0.795 0.18,-1.312 0,-0.708 -0.117,-1.257 -0.35,-1.638 -0.235,-0.382 -0.518,-0.638 -0.85,-0.766 -0.245,-0.095 -0.631,-0.142 -1.167,-0.142 l -1.429,0 0,5.195 z m -6.898,0.918 1.971,-7.028 0.668,0 -1.968,7.028 -0.671,0 z m -8.227,-0.118 0,-6.797 4.917,0 0,0.802 -4.017,0 0,2.082 3.759,0 0,0.798 -3.759,0 0,2.314 4.174,0 0,0.801 -5.074,0 z m -6.891,0 0,-6.797 0.924,0 3.57,5.337 0,-5.337 0.86,0 0,6.797 -0.921,0 -3.571,-5.34 0,5.34 -0.862,0 z m -2.471,0 0,-6.797 0.898,0 0,6.797 -0.898,0 z m -4.353,-2.666 0,-0.796 2.879,-0.004 0,2.521 c -0.442,0.354 -0.897,0.618 -1.368,0.795 -0.471,0.179 -0.953,0.267 -1.448,0.267 -0.668,0 -1.273,-0.144 -1.817,-0.429 -0.547,-0.286 -0.96,-0.701 -1.238,-1.24 -0.277,-0.541 -0.416,-1.146 -0.416,-1.814 0,-0.66 0.139,-1.279 0.414,-1.852 0.277,-0.574 0.676,-0.998 1.193,-1.277 0.521,-0.278 1.118,-0.416 1.797,-0.416 0.491,0 0.934,0.078 1.332,0.238 0.396,0.16 0.707,0.382 0.935,0.665 0.227,0.284 0.397,0.656 0.514,1.113 l -0.811,0.223 c -0.102,-0.346 -0.229,-0.619 -0.381,-0.818 -0.151,-0.195 -0.367,-0.354 -0.647,-0.474 -0.282,-0.118 -0.594,-0.179 -0.937,-0.179 -0.412,0 -0.768,0.063 -1.067,0.187 -0.301,0.127 -0.541,0.291 -0.726,0.495 -0.186,0.205 -0.329,0.429 -0.431,0.672 -0.173,0.419 -0.257,0.878 -0.257,1.37 0,0.604 0.104,1.11 0.312,1.519 0.207,0.409 0.512,0.713 0.911,0.909 0.398,0.199 0.822,0.297 1.271,0.297 0.39,0 0.771,-0.075 1.141,-0.223 0.37,-0.152 0.651,-0.311 0.843,-0.482 l 0,-1.267 -1.998,0 z m -10.054,2.666 0,-6.797 0.924,0 3.569,5.337 0,-5.337 0.863,0 0,6.797 -0.922,0 -3.572,-5.34 0,5.34 -0.862,0 z m -6.316,0 0,-6.797 4.915,0 0,0.802 -4.015,0 0,2.082 3.759,0 0,0.798 -3.759,0 0,2.314 4.174,0 0,0.801 -5.074,0 z m 92.123,5.443 0,0.565 c -11.019,0.224 -17.903,0.469 -17.903,0.676 0,0.105 4.815,2.172 10.725,4.555 l 7.179,2.915 0,0.591 c -1.163,-0.484 -2.406,-1.003 -3.927,-1.627 -3.892,-1.565 -8.842,-3.618 -10.964,-4.543 l -3.894,-1.675 -4.949,0.038 c -2.727,0 -7.576,0.207 -10.796,0.421 -3.22,0.248 -8.243,0.604 -11.146,0.782 -13.904,0.961 -16.417,1.431 -18.397,3.312 -2.337,2.204 -7.044,13.222 -7.929,18.413 -0.423,2.7 -0.46,12.152 0,14.855 0.956,6.006 5.636,16.855 8.219,19.06 2.016,1.741 4.209,2.122 17.229,3.012 3.006,0.214 8.836,0.606 12.938,0.891 7.68,0.534 13.593,0.682 13.593,0.326 0,-0.106 -0.666,-1.312 -1.444,-2.7 -3.469,-5.937 -6.092,-12.833 -7.473,-19.481 -2.016,-9.667 -0.217,-23.823 4.171,-32.711 0.919,-1.885 4.005,-6.177 4.252,-5.928 0.106,0.106 -0.463,1.028 -1.204,2.022 -2.689,3.557 -5.099,9.389 -6.268,15.109 -0.707,3.414 -1.548,12.049 -1.373,14.146 0.53,7.038 1.945,12.755 4.88,19.796 1.7,4.018 5.131,10.033 5.627,9.856 0.248,-0.073 5.31,-2.103 11.254,-4.483 l 7.604,-3.048 0,0.505 -7.364,2.964 -10.854,4.338 3.42,0.218 c 1.691,0.127 8.091,0.222 14.799,0.267 l 0,0.541 c -5.951,-0.047 -11.037,-0.125 -14.327,-0.242 -7.076,-0.247 -24.42,-1.238 -32.664,-1.879 -2.688,-0.212 -3.211,-0.147 -4.06,0.42 -0.848,0.569 -1.632,0.676 -5.24,0.64 -7.961,-0.035 -10.263,-1.412 -13.447,-8.134 -3.572,-7.499 -5.451,-14.714 -5.662,-21.504 -0.071,-2.453 -0.033,-4.914 0.036,-5.519 0.955,-6.364 3.043,-13.115 5.661,-18.517 3.223,-6.684 5.447,-8.04 13.23,-8.108 3.326,-0.038 4.279,0.08 5.024,0.612 1.13,0.712 2.652,0.739 8.842,0.24 12.222,-0.973 27.301,-1.646 42.606,-1.987 l -0.004,0 z m -56.302,1.578 c -2.043,0.03 -4.288,0.234 -5.65,0.59 -3.821,0.994 -5.483,2.92 -8.352,9.639 -2.084,4.906 -3.675,10.381 -4.348,15.072 -0.639,4.443 -0.639,5.545 -0.035,9.953 0.885,6.186 2.544,11.692 5.41,17.809 1.627,3.553 3.536,5.857 5.554,6.747 2.158,0.959 8.138,1.532 10.579,1.036 1.095,-0.215 1.912,-0.534 1.807,-0.713 -0.071,-0.142 -1.877,-0.386 -3.965,-0.493 -4.883,-0.319 -7.216,-1.002 -8.88,-2.53 -2.475,-2.204 -6.609,-11.336 -8.06,-17.771 -1.025,-4.339 -0.93,-14.146 0.132,-18.483 1.45,-5.723 5.563,-14.862 7.578,-16.783 1.593,-1.492 4.066,-2.305 8.205,-2.627 5.767,-0.462 5.521,-0.431 4.495,-1 -0.583,-0.339 -2.427,-0.475 -4.47,-0.446 l 0,0 z m 57.155,51.264 c -0.08,-0.08 -0.292,-0.09 -0.468,-0.021 -0.192,0.079 -0.135,0.137 0.148,0.148 0.256,0.011 0.399,-0.045 0.32,-0.127 l 0,0 z m -45.659,-3.771 c 0.167,-0.17 0.305,-0.446 0.305,-0.614 0,-0.203 0.5,-0.327 1.518,-0.375 l 1.517,-0.073 0.08,-0.847 c 0.09,-0.952 0.361,-1.209 1.28,-1.215 0.639,-0.005 1.435,-0.655 1.435,-1.176 0,-0.476 0.666,-0.318 1.357,0.322 0.379,0.352 0.947,0.607 1.347,0.607 0.381,0 1.321,0.215 2.092,0.477 1.129,0.384 2.229,0.493 5.706,0.566 3.883,0.08 4.372,0.043 4.979,-0.362 0.518,-0.351 0.925,-0.416 1.803,-0.304 1.057,0.139 1.168,0.1 1.684,-0.598 0.336,-0.456 0.771,-0.751 1.104,-0.751 0.854,0 1.79,-0.52 1.79,-0.991 0,-0.831 0.249,-1.125 0.859,-1.01 0.331,0.065 0.876,-0.068 1.229,-0.299 0.634,-0.417 0.676,-0.808 0.217,-1.907 -0.164,-0.392 -0.092,-0.424 0.647,-0.285 0.639,0.118 0.975,0.04 1.429,-0.334 0.589,-0.483 0.593,-0.501 0.171,-1.255 -0.423,-0.756 -0.371,-1.35 0.093,-1.064 0.454,0.28 1.343,-0.13 1.627,-0.754 0.252,-0.552 0.212,-0.691 -0.351,-1.214 -0.748,-0.693 -0.626,-1.331 0.254,-1.331 0.563,0 1.596,-0.814 1.596,-1.261 0,-0.106 -0.573,-0.189 -1.275,-0.177 -0.702,0.011 -1.137,0.075 -0.968,0.143 0.205,0.083 0.064,0.351 -0.426,0.808 -0.888,0.829 -0.897,0.98 -0.125,1.9 0.334,0.396 0.607,0.789 0.607,0.869 0,0.08 -0.439,0.147 -0.977,0.147 -0.803,0 -1.025,0.106 -1.248,0.598 -0.217,0.477 -0.191,0.719 0.127,1.206 0.548,0.837 0.507,0.93 -0.325,0.746 -0.399,-0.087 -0.958,-0.084 -1.243,0.007 -0.466,0.148 -0.503,0.282 -0.359,1.354 0.172,1.311 0.166,1.317 -1.02,0.89 -0.763,-0.277 -0.87,-0.256 -1.283,0.255 -0.349,0.433 -0.399,0.692 -0.219,1.165 0.307,0.81 0.306,0.821 -0.224,0.821 -0.25,0 -0.591,-0.163 -0.758,-0.363 -0.385,-0.466 -1.312,-0.472 -1.693,-0.009 -0.179,0.215 -0.231,0.639 -0.134,1.093 0.21,0.944 -0.365,1.015 -0.954,0.116 -0.32,-0.489 -0.572,-0.605 -1.182,-0.547 -0.628,0.062 -0.821,0.221 -1.026,0.853 -0.375,1.162 -0.529,1.19 -1.105,0.211 -0.689,-1.17 -1.623,-1.146 -2.15,0.052 -0.42,0.953 -0.996,0.942 -1.254,-0.023 -0.403,-1.506 -1.31,-1.799 -2.294,-0.737 l -0.596,0.641 0,-0.588 c 0,-1.378 -1.276,-2.1 -2.319,-1.311 -0.728,0.548 -0.874,0.446 -0.699,-0.481 0.273,-1.464 -0.691,-2.021 -2.009,-1.158 l -0.638,0.419 0.161,-0.638 c 0.087,-0.353 0.221,-0.801 0.294,-0.998 0.075,-0.193 -0.128,-0.665 -0.455,-1.044 -0.48,-0.56 -0.761,-0.679 -1.494,-0.628 l -0.906,0.06 0.511,-0.648 c 0.943,-1.198 0.532,-2.041 -0.994,-2.041 -0.951,0 -1.198,-0.355 -0.638,-0.918 0.219,-0.22 0.19,-0.391 -0.122,-0.735 -0.464,-0.513 -0.261,-0.917 0.25,-0.493 0.249,0.207 0.407,0.209 0.606,0.009 0.437,-0.436 -0.235,-1.02 -1.17,-1.02 -1.02,0 -1.033,-0.195 -0.059,-0.993 0.979,-0.806 0.85,-1.734 -0.297,-2.136 -0.812,-0.28 -0.856,-0.821 -0.08,-0.965 0.594,-0.108 1.318,-0.746 1.557,-1.372 0.252,-0.653 -0.099,-1.246 -0.843,-1.432 -0.933,-0.235 -0.758,-0.827 0.296,-1.017 0.5,-0.091 1.048,-0.273 1.217,-0.405 0.488,-0.392 0.347,-1.27 -0.308,-1.886 -0.768,-0.719 -0.462,-1.097 0.812,-1.004 1.28,0.093 1.674,-0.405 1.332,-1.688 -0.304,-1.133 -0.165,-1.273 0.863,-0.885 1.117,0.422 1.604,0.032 1.632,-1.309 0.036,-1.518 0.029,-1.51 0.804,-0.957 1.299,0.925 2.633,0.367 2.363,-0.986 -0.191,-0.943 0.307,-1.151 0.875,-0.371 0.28,0.384 0.702,0.645 1.043,0.645 0.616,0 1.329,-0.81 1.329,-1.511 0,-0.652 0.654,-0.519 0.828,0.169 0.179,0.718 0.951,1.185 1.613,0.975 0.264,-0.085 0.647,-0.554 0.854,-1.041 0.293,-0.704 0.418,-0.814 0.601,-0.529 0.125,0.198 0.227,0.544 0.229,0.771 0.005,0.481 0.896,1.166 1.52,1.166 0.239,0 0.642,-0.336 0.892,-0.748 0.485,-0.801 0.587,-0.756 0.858,0.383 0.097,0.4 0.29,0.865 0.427,1.031 0.389,0.466 1.523,0.364 2.016,-0.181 0.659,-0.726 0.852,-0.596 0.852,0.579 0,1.422 0.45,1.808 1.612,1.384 1.061,-0.38 1.23,-0.224 0.864,0.793 -0.404,1.114 -0.373,1.31 0.288,1.742 0.471,0.309 0.692,0.325 1.214,0.087 0.872,-0.396 1.039,-0.127 0.521,0.836 -0.352,0.653 -0.38,0.911 -0.151,1.338 0.227,0.423 0.502,0.529 1.368,0.529 0.596,0 1.083,0.081 1.085,0.182 0,0.102 -0.313,0.457 -0.701,0.791 -0.388,0.332 -0.774,0.906 -0.855,1.273 l -0.155,0.668 2.449,0 c 1.723,0 2.399,-0.079 2.281,-0.266 -0.11,-0.181 -0.677,-0.216 -1.714,-0.104 -1.31,0.14 -1.572,0.104 -1.702,-0.232 -0.095,-0.25 0.087,-0.648 0.494,-1.076 0.541,-0.562 0.611,-0.774 0.414,-1.287 -0.261,-0.688 -0.706,-0.922 -1.746,-0.922 -0.822,0 -0.843,-0.056 -0.318,-0.856 0.759,-1.158 0.078,-2.044 -1.573,-2.055 -0.578,-0.003 -0.604,-0.193 -0.175,-1.225 0.265,-0.638 -0.444,-1.277 -1.583,-1.429 -0.906,-0.122 -1.08,-0.233 -1.149,-0.751 -0.136,-0.996 -0.729,-1.457 -1.879,-1.457 -0.845,0 -1.122,-0.119 -1.513,-0.655 -0.388,-0.532 -0.747,-0.691 -1.902,-0.838 -0.786,-0.1 -1.8,-0.257 -2.258,-0.351 -0.725,-0.146 -0.904,-0.078 -1.38,0.519 l -0.549,0.688 -0.158,-0.645 c -0.138,-0.539 -0.338,-0.664 -1.288,-0.808 -1.341,-0.2 -6.581,0.271 -6.935,0.626 -0.138,0.137 -0.582,0.252 -0.991,0.254 -0.876,0.003 -1.097,0.142 -1.662,1.027 -0.355,0.559 -0.596,0.669 -1.457,0.669 -1.393,0 -2.114,0.533 -2.114,1.56 0,0.749 -0.068,0.817 -0.939,0.957 -1.225,0.197 -1.561,0.62 -1.355,1.715 0.143,0.757 0.104,0.867 -0.318,0.867 -0.69,0 -1.759,0.921 -1.759,1.517 0,0.28 0.176,0.704 0.39,0.939 0.5,0.556 0.246,0.946 -0.618,0.946 -0.375,0 -0.787,0.137 -0.918,0.303 -0.572,0.74 -0.525,1.168 0.222,2.021 l 0.76,0.861 -0.89,0.732 c -1.144,0.943 -1.14,1.579 0.021,2.553 l 0.906,0.763 -0.967,0.407 c -0.784,0.329 -1.652,0.395 -4.556,0.346 -3.876,-0.063 -4.148,0.015 -4.197,1.188 -0.026,0.596 -0.136,0.674 -1.103,0.791 -1.289,0.151 -1.643,0.352 -1.919,1.078 -0.28,0.737 -1.047,0.886 -5.569,1.069 -2.67,0.11 -3.774,0.24 -3.847,0.456 -0.075,0.227 0.416,0.308 1.925,0.318 1.113,0.009 2.46,0.09 2.993,0.186 0.89,0.156 0.979,0.241 1.052,1.002 0.045,0.456 0.012,1.193 -0.072,1.636 -0.13,0.696 -0.248,0.806 -0.867,0.806 -0.396,0 -0.718,-0.109 -0.718,-0.243 0,-0.309 -1.043,-0.317 -1.348,-0.012 -0.127,0.127 -0.997,0.264 -1.933,0.304 -1.631,0.068 -1.698,0.097 -1.698,0.68 0,0.547 0.123,0.624 1.212,0.768 0.671,0.09 2.006,0.17 2.976,0.183 1.102,0.016 1.761,0.121 1.761,0.287 0,0.183 -0.864,0.241 -2.731,0.185 -2.293,-0.067 -2.73,-0.022 -2.73,0.28 0,0.298 0.626,0.39 3.506,0.507 3.239,0.134 3.536,0.186 3.855,0.668 0.241,0.365 0.597,0.523 1.17,0.523 0.737,0 0.817,0.068 0.817,0.691 0,0.918 0.688,1.495 1.779,1.495 0.787,0 0.939,0.104 1.316,0.896 0.268,0.562 0.657,0.955 1.044,1.059 0.341,0.088 2.525,0.24 4.86,0.335 3.287,0.137 4.301,0.106 4.537,-0.133 l 0,0 z m -1.357,-1.175 c -0.403,-1.156 -2.118,-1.335 -2.398,-0.25 -0.192,0.741 -0.558,0.576 -0.558,-0.256 0,-0.806 -0.919,-1.932 -1.575,-1.932 -0.21,0 -0.651,0.177 -0.981,0.393 -0.697,0.455 -0.769,0.225 -0.313,-1.03 0.461,-1.271 -0.01,-2.034 -1.253,-2.034 -1.2,0 -1.24,-0.283 -0.127,-0.939 0.679,-0.4 0.853,-0.654 0.853,-1.247 0,-0.597 -0.174,-0.847 -0.866,-1.256 -0.976,-0.573 -0.864,-0.859 0.371,-0.973 0.617,-0.058 0.939,-0.254 1.209,-0.734 0.339,-0.607 0.327,-0.709 -0.175,-1.386 -0.297,-0.403 -0.539,-0.791 -0.539,-0.862 0,-0.269 0.764,-0.12 1.341,0.259 1.179,0.771 2.407,-0.204 2.125,-1.683 -0.163,-0.859 0.197,-0.827 0.864,0.077 0.388,0.522 0.743,0.728 1.256,0.728 0.511,0 0.864,-0.205 1.253,-0.728 0.654,-0.888 0.932,-0.925 0.932,-0.122 0,0.767 0.794,1.579 1.539,1.579 0.314,0 0.769,-0.219 1.014,-0.486 0.637,-0.705 0.836,-0.599 0.68,0.362 -0.194,1.205 0.253,1.671 1.433,1.479 0.774,-0.12 0.921,-0.078 0.921,0.282 0,0.236 -0.328,0.738 -0.727,1.116 -1.063,1.003 -0.917,1.654 0.526,2.337 1.021,0.48 1.06,1.079 0.079,1.179 -1.295,0.138 -1.789,1.504 -0.85,2.354 0.689,0.624 0.61,0.938 -0.184,0.722 -1.567,-0.427 -2.373,0.145 -2.154,1.525 0.139,0.888 0.021,0.964 -0.609,0.396 -0.811,-0.734 -2.397,0.1 -2.397,1.261 -0.002,0.813 -0.39,0.739 -0.69,-0.131 l 0,0 z m 1.78,-2.806 c 1.912,-1.028 2.924,-2.811 2.66,-4.677 -0.254,-1.805 -1.109,-3.062 -2.58,-3.797 -1.488,-0.741 -2.625,-0.79 -3.965,-0.172 -3.315,1.53 -3.774,6.139 -0.816,8.188 1.238,0.857 3.545,1.082 4.701,0.458 l 0,0 z m -3.741,-0.919 c -1.106,-0.39 -1.702,-1.256 -1.876,-2.735 -0.187,-1.561 0.546,-3.319 1.604,-3.866 0.927,-0.479 0.916,-0.484 1.095,0.325 0.102,0.47 0,0.961 -0.32,1.519 -0.261,0.453 -0.438,1.097 -0.398,1.43 0.043,0.334 0.086,0.687 0.097,0.781 0.012,0.097 0.362,0.565 0.782,1.043 0.711,0.811 0.833,0.857 1.796,0.714 1.206,-0.182 1.589,0.169 0.792,0.724 -0.64,0.447 -2.385,0.48 -3.572,0.065 l 0,0 z m -0.509,-3.475 c 0,-0.12 -0.218,-0.358 -0.486,-0.524 -0.266,-0.168 -0.485,-0.267 -0.485,-0.218 0,0.048 0.22,0.283 0.485,0.525 0.269,0.242 0.486,0.341 0.486,0.217 z m 2.004,1.19 c -0.166,-0.223 -0.302,-0.768 -0.302,-1.21 0,-1.113 0.72,-1.775 1.931,-1.775 1.004,0 2.197,0.418 2.197,0.768 0,0.271 -0.572,0.261 -0.861,-0.015 -0.128,-0.119 -0.58,-0.29 -1.004,-0.38 -0.602,-0.127 -0.886,-0.051 -1.277,0.34 -0.867,0.867 -0.606,2.059 0.568,2.606 l 0.754,0.351 -0.853,-0.139 c -0.467,-0.076 -0.985,-0.323 -1.153,-0.546 l 0,0 z m 1.295,-1.369 c 0.085,-0.219 0.334,-0.394 0.554,-0.384 0.252,0.014 0.285,0.065 0.094,0.144 -0.165,0.066 -0.301,0.352 -0.301,0.634 0,0.355 -0.08,0.438 -0.252,0.264 -0.138,-0.137 -0.18,-0.434 -0.095,-0.658 l 0,0 z m -0.299,-2.644 c -0.914,0.104 -1.043,0.064 -0.914,-0.277 0.189,-0.49 1.729,-0.526 2.348,-0.059 0.537,0.407 0.559,0.732 0.03,0.438 -0.219,-0.123 -0.878,-0.168 -1.464,-0.102 z m -5.609,10.105 c -0.632,-0.17 -0.726,-0.699 -0.164,-0.916 0.756,-0.288 1.075,-0.15 1.075,0.461 0,0.648 -0.066,0.681 -0.911,0.455 z m -2.977,-0.332 c 0,-0.137 0.164,-0.245 0.364,-0.245 0.201,0 0.365,0.108 0.365,0.245 0,0.132 -0.164,0.24 -0.365,0.24 -0.2,10e-4 -0.364,-0.108 -0.364,-0.24 z m -3.149,-1.904 c 0.004,-0.09 0.224,-0.42 0.486,-0.735 0.386,-0.461 0.786,-0.601 2.025,-0.699 1.756,-0.143 2.048,0.066 1.525,1.083 -0.342,0.662 -0.39,0.673 -2.197,0.596 -1.016,-0.045 -1.842,-0.156 -1.839,-0.245 z m 22.278,-0.931 c 0.166,-0.067 0.438,-0.067 0.607,0 0.166,0.068 0.028,0.123 -0.306,0.123 -0.331,0 -0.467,-0.054 -0.301,-0.123 z m 2.159,-0.689 c 0.076,-0.2 0.233,-0.364 0.349,-0.364 0.116,0 0.146,0.164 0.068,0.364 -0.076,0.2 -0.231,0.364 -0.349,0.364 -0.113,0 -0.146,-0.164 -0.068,-0.364 z m -5.891,-0.873 c -0.664,-0.55 -0.308,-0.69 1.605,-0.638 1.874,0.052 1.943,0.075 1.943,0.636 0,0.569 -0.031,0.578 -1.605,0.431 -0.884,-0.083 -1.758,-0.276 -1.943,-0.429 l 0,0 z m -18.737,-0.702 c -1.041,-0.003 -1.391,-0.379 -0.604,-0.654 0.232,-0.08 0.826,-0.574 1.319,-1.098 0.811,-0.861 0.999,-0.944 1.941,-0.877 1.334,0.097 1.553,0.732 0.463,1.351 -0.409,0.233 -0.746,0.596 -0.746,0.811 -0.007,0.555 -0.285,0.753 -0.848,0.604 -0.271,-0.074 -0.955,-0.135 -1.525,-0.137 z m -2.65,-3.633 c 0.437,-2.182 0.923,-2.644 2.346,-2.209 0.569,0.173 0.577,0.196 0.124,0.354 -1.441,0.499 -1.702,0.761 -1.674,1.675 0.023,0.741 -0.056,0.896 -0.455,0.896 -0.408,-10e-4 -0.46,-0.118 -0.341,-0.716 z m 1.984,-0.014 c -0.352,-0.132 -0.569,-0.351 -0.487,-0.485 0.164,-0.264 2.515,-0.334 3.14,-0.096 0.627,0.241 0.439,0.543 -0.404,0.648 -1.461,0.181 -1.61,0.177 -2.249,-0.067 l 0,0 z m 3.522,-1.639 c 0,-0.243 0.849,-0.773 1.247,-0.78 0.4,-0.01 0.789,0.612 0.589,0.937 -0.12,0.192 -1.836,0.046 -1.836,-0.157 z m -1.702,-0.546 c 0,-0.31 0.162,-0.486 0.444,-0.486 0.668,0 0.814,0.277 0.344,0.638 -0.594,0.446 -0.788,0.408 -0.788,-0.152 z m 0.032,-1.124 c -1.363,-0.271 -0.8,-0.577 1.062,-0.577 1.674,0 2.085,0.141 1.659,0.568 -0.204,0.201 -1.725,0.207 -2.721,0.009 l 0,0 z m 4.733,-1.338 c -0.305,-0.436 -0.516,-0.497 -1.319,-0.365 -0.818,0.13 -0.979,0.083 -1.082,-0.318 -0.177,-0.673 -0.025,-0.741 1.664,-0.741 2.036,0 2.288,0.125 2.288,1.119 0,0.711 -0.079,0.823 -0.593,0.823 -0.331,-10e-4 -0.754,-0.231 -0.958,-0.518 l 0,0 z m 4.1,-0.818 c 0,-0.132 0.247,-0.279 0.549,-0.322 0.375,-0.052 0.546,0.049 0.546,0.322 0,0.275 -0.171,0.373 -0.546,0.319 -0.302,-0.04 -0.549,-0.185 -0.549,-0.319 z m 3.284,-0.846 c -0.353,-0.189 -0.436,-0.469 -0.372,-1.275 l 0.078,-1.035 1.632,0.042 c 2.064,0.053 2.427,0.364 1.243,1.061 -0.525,0.311 -0.884,0.713 -0.884,0.984 0,0.52 -0.918,0.64 -1.699,0.224 l 0.002,0 z m -1.522,-3.372 c -0.579,-0.045 -0.542,-0.518 0.042,-0.518 0.681,0 1.234,-0.659 1.234,-1.47 0,-0.553 0.133,-0.739 0.607,-0.859 1.193,-0.301 3.277,0.427 3.277,1.143 0,0.107 -0.42,0.309 -0.931,0.447 -0.58,0.155 -1.029,0.461 -1.185,0.805 -0.25,0.551 -0.739,0.623 -3.044,0.452 l 0,0 z m -0.112,-3.826 c -0.057,-0.174 0.541,-0.333 1.65,-0.443 1.737,-0.172 2.399,0.018 2.051,0.582 -0.221,0.359 -3.578,0.234 -3.701,-0.139 l 0,0 z m 2.412,-1.915 c -0.063,-0.442 0.064,-0.484 1.455,-0.468 1.708,0.02 2.38,0.23 2.38,0.748 0,0.278 -0.379,0.334 -1.885,0.276 -1.67,-0.062 -1.887,-0.125 -1.95,-0.556 l 0,0 z m -0.945,-1.239 c -0.234,-0.605 0.391,-0.832 2.107,-0.767 1.944,0.078 2.071,0.504 0.198,0.672 -0.756,0.067 -1.458,0.204 -1.558,0.304 -0.292,0.291 -0.587,0.209 -0.747,-0.209 z m 5.75,-1.797 c -0.307,-0.269 -0.429,-0.485 -0.264,-0.485 0.301,0 0.993,0.58 0.993,0.832 10e-4,0.23 -0.143,0.162 -0.729,-0.347 l 0,0 z m -3.348,-1.258 c 0.111,-0.324 2.547,-0.537 3.104,-0.269 0.211,0.1 -0.298,0.236 -1.214,0.323 -0.866,0.08 -1.669,0.167 -1.779,0.19 -0.114,0.023 -0.161,-0.085 -0.111,-0.244 l 0,0 z m 5.899,-1.171 c -0.084,-0.132 -0.797,-0.242 -1.586,-0.242 -1.203,0 -1.479,-0.08 -1.705,-0.505 -0.15,-0.279 -0.2,-0.577 -0.118,-0.661 0.086,-0.086 0.888,-0.197 1.785,-0.249 l 1.63,-0.09 0.301,0.831 c 0.165,0.456 0.299,0.904 0.299,0.993 0,0.254 -0.438,0.196 -0.606,-0.077 l 0,0 z m 16.15,-1.943 c 0,-0.134 0.165,-0.243 0.365,-0.243 0.2,0 0.363,0.109 0.363,0.243 0,0.134 -0.163,0.245 -0.363,0.245 -0.2,0 -0.365,-0.111 -0.365,-0.245 z m -14.937,-0.972 c -0.09,-0.146 0.24,-0.243 0.836,-0.243 0.541,0 1.068,0 1.17,0 0.099,0 0.216,0.108 0.261,0.243 0.048,0.14 -0.393,0.243 -1.017,0.243 -0.605,0.001 -1.166,-0.109 -1.25,-0.243 z m 11.678,27.573 c 3.757,-0.816 7.352,-3.74 9.007,-7.326 0.45,-0.975 1.056,-1.898 1.34,-2.053 0.479,-0.255 0.487,-0.298 0.102,-0.514 -0.231,-0.127 -0.953,-0.159 -1.62,-0.066 -0.66,0.09 -2.376,0.071 -3.809,-0.039 l -2.607,-0.207 4.491,-0.15 c 2.472,-0.084 6.516,-0.166 8.987,-0.187 4.465,-0.035 5.452,-0.174 4.81,-0.683 -0.491,-0.389 -1.979,-0.542 -5.6,-0.575 -1.835,-0.015 -3.4,-0.127 -3.476,-0.251 -0.073,-0.119 -0.675,-0.22 -1.335,-0.22 -0.659,0 -1.2,-0.11 -1.2,-0.242 0,-0.134 0.157,-0.243 0.351,-0.243 0.192,0 0.415,-0.109 0.499,-0.242 0.097,-0.155 -0.725,-0.242 -2.291,-0.242 -1.669,0 -2.445,0.087 -2.445,0.275 0,0.189 0.409,0.233 1.297,0.145 1.537,-0.158 2.112,0.084 1.711,0.727 -0.219,0.351 -0.534,0.417 -1.699,0.349 -0.787,-0.045 -1.532,-0.182 -1.66,-0.304 -0.364,-0.349 -1.146,-0.259 -1.459,0.17 -0.264,0.36 -0.318,0.36 -0.679,0 -0.266,-0.265 -0.819,-0.392 -1.717,-0.392 -1.586,0 -1.845,-0.36 -1.204,-1.664 0.741,-1.5 1.346,-1.677 6.21,-1.804 2.376,-0.062 4.382,-0.175 4.46,-0.252 0.077,-0.077 -0.318,-1.084 -0.877,-2.239 -1.784,-3.685 -5.113,-6.339 -8.95,-7.133 -1.75,-0.363 -5.008,-0.331 -6.484,0.062 -4.289,1.146 -7.751,4.518 -9.139,8.901 -0.688,2.173 -0.689,5.391 -0.007,7.531 0.823,2.57 2.697,5.14 4.745,6.505 3.633,2.414 6.73,3.128 10.248,2.363 l 0,0 z m -7.122,-1.806 c -1.617,-1.099 -1.853,-1.345 -0.973,-1.02 0.3,0.108 0.874,0.271 1.274,0.36 l 0.731,0.16 -0.731,-0.614 -0.729,-0.61 0.756,0.146 c 0.589,0.113 0.791,0.052 0.923,-0.295 0.109,-0.279 0.033,-0.545 -0.207,-0.718 -0.518,-0.379 -0.475,-0.588 0.125,-0.588 0.636,0 1.258,-0.607 1.153,-1.126 -0.04,-0.221 -0.384,-0.628 -0.755,-0.906 -0.53,-0.397 -0.765,-0.446 -1.093,-0.233 -0.229,0.147 -0.4,0.443 -0.382,0.66 0.02,0.216 -0.126,0.391 -0.322,0.391 -0.397,0 -1.048,0.574 -1.048,0.928 0,0.127 -0.23,0.291 -0.511,0.364 -0.279,0.073 -0.442,0.243 -0.359,0.377 0.082,0.132 0.03,0.313 -0.114,0.405 -0.145,0.089 -0.207,0.306 -0.141,0.482 0.067,0.175 -0.014,0.371 -0.177,0.434 -1.024,0.393 -3.371,-2.518 -4.447,-5.517 -0.534,-1.49 -0.805,-4.667 -0.525,-6.218 0.615,-3.448 3.134,-6.813 6.171,-8.247 1.733,-0.819 2.805,-0.996 2.293,-0.379 -0.245,0.295 -0.206,0.57 0.2,1.434 0.276,0.587 0.572,1.354 0.66,1.701 0.089,0.348 0.259,0.634 0.376,0.634 0.29,0 0.278,-1.112 -0.015,-1.643 -0.129,-0.23 -0.336,-0.943 -0.458,-1.58 -0.278,-1.437 -0.083,-1.579 2.438,-1.783 2.161,-0.173 3.109,0.121 3.109,0.97 0,0.439 0.271,0.75 1.077,1.221 1.08,0.634 1.996,0.841 1.716,0.387 -0.082,-0.134 0.066,-0.243 0.33,-0.243 0.265,0 0.638,-0.059 0.833,-0.134 0.89,-0.341 4.318,3.795 4.691,5.664 l 0.157,0.785 -1.183,-10e-4 c -1.642,0 -2.882,-0.393 -3.804,-1.19 -1.089,-0.946 -1.554,-1.159 -3.547,-1.613 -1.267,-0.287 -1.836,-0.322 -2.064,-0.134 -0.175,0.146 -0.982,0.354 -1.801,0.466 -1.882,0.259 -3.256,1.184 -4.198,2.825 -0.597,1.035 -0.704,1.492 -0.702,2.927 0.005,1.993 0.504,3.286 1.743,4.529 0.832,0.828 2.248,1.422 3.408,1.422 0.333,0 0.88,0.274 1.216,0.61 0.564,0.564 0.621,0.576 0.729,0.157 0.096,-0.358 0.445,-0.492 1.657,-0.629 1.822,-0.205 3.03,-0.669 3.887,-1.493 0.347,-0.329 1.001,-0.705 1.458,-0.838 1.089,-0.311 2.897,-0.303 2.897,0.013 0,0.532 -1.567,3.328 -2.477,4.416 -0.524,0.629 -1.632,1.589 -2.455,2.131 -1.775,1.165 -2.651,1.222 -2.84,0.184 -0.167,-0.908 -1.37,-2.365 -1.952,-2.365 -0.433,0 -0.459,0.123 -0.317,1.518 0.092,0.906 0.292,1.601 0.497,1.719 0.277,0.164 0.282,0.273 0.03,0.574 -0.245,0.301 -0.731,0.351 -2.5,0.264 -2.099,-0.105 -2.254,-0.152 -3.708,-1.141 l 0,0 z m 7.708,-17.869 c 0.167,-0.197 0.24,-0.515 0.17,-0.701 -0.091,-0.24 0.007,-0.304 0.338,-0.217 0.255,0.066 0.468,0 0.468,-0.15 0,-0.149 0.162,-0.271 0.364,-0.271 0.763,0 0.314,-0.697 -0.777,-1.211 -1.305,-0.614 -1.442,-0.534 -2.011,1.191 -0.261,0.791 -0.264,1.044 -0.014,1.348 0.393,0.472 1.075,0.478 1.464,0.011 l -0.002,0 z m -2.108,11.898 c -2.151,-0.64 -3.718,-2.839 -3.717,-5.222 0,-1.087 1.068,-3.401 1.565,-3.401 0.479,0 0.484,-0.039 -0.229,1.495 -0.7,1.502 -0.763,2.528 -0.234,3.793 0.807,1.937 1.922,2.629 4.601,2.874 1.673,0.15 1.847,0.209 1.448,0.499 -0.585,0.429 -1.912,0.415 -3.434,-0.038 l 0,0 z m -2.262,0.121 c 0,-0.132 0.104,-0.243 0.23,-0.243 0.125,0 0.297,0.111 0.377,0.243 0.085,0.134 -0.019,0.242 -0.229,0.242 -0.209,0.001 -0.378,-0.108 -0.378,-0.242 l 0,0 z m 3.645,-2.144 c -0.335,-0.246 -0.862,-0.904 -1.173,-1.46 -0.642,-1.145 -1.013,-1.295 -1.013,-0.403 0,0.751 -0.829,0.846 -1.21,0.138 -0.774,-1.451 0.032,-3.766 1.646,-4.707 0.909,-0.531 1.293,-0.384 0.704,0.266 -0.596,0.659 -1.191,2.244 -1.012,2.693 0.116,0.289 0.312,0.048 0.729,-0.879 0.736,-1.646 1.237,-1.681 0.591,-0.039 -0.398,1.008 -0.441,1.4 -0.241,2.147 0.328,1.219 1.188,2.1 2.398,2.464 0.546,0.163 0.941,0.382 0.875,0.487 -0.161,0.261 -1.565,-0.169 -2.294,-0.707 l 0,0 z m -7.444,-1.422 c -0.723,-2.075 -0.11,-4.275 1.574,-5.67 0.789,-0.652 2.189,-1.262 2.438,-1.06 0.052,0.041 -0.2,0.42 -0.556,0.843 -0.355,0.422 -0.822,1.109 -1.039,1.527 -0.515,0.994 -0.842,4.231 -0.482,4.803 0.207,0.332 0.165,0.535 -0.195,0.934 -0.459,0.504 -0.462,0.506 -0.937,0.028 -0.264,-0.261 -0.627,-0.895 -0.803,-1.405 l 0,0 z m 7.508,-6.696 c 0.118,-0.337 1.375,-0.281 1.743,0.077 0.143,0.142 -0.161,0.227 -0.81,0.227 -0.725,-10e-4 -1.008,-0.09 -0.933,-0.304 z m 23.191,8.016 c -0.077,-0.226 -0.788,-0.283 -2.754,-0.219 -3.718,0.12 -3.818,0.522 -0.128,0.522 2.279,0.001 2.959,-0.07 2.882,-0.303 z m -1.881,-6.255 c 0,-0.145 -0.888,-0.243 -2.173,-0.243 -1.195,0 -2.238,0.11 -2.322,0.243 -0.094,0.155 0.686,0.243 2.172,0.243 1.386,0.001 2.323,-0.098 2.323,-0.243 z"
    }
  }), _c("path", {
    staticStyle: {
      fill: "none",
      stroke: "#005aff",
      "stroke-width": "1.76300001",
      "stroke-dasharray": "10.578, 1.763"
    },
    attrs: {
      id: "vehicle_engine_line",
      "inkscape:connector-curvature": "0",
      d: "m 764.926,435.629 123.2,0 0,88.643 -123.2,0 0,-88.643 z"
    }
  }), _c("path", {
    staticStyle: {
      fill: "#ff0000"
    },
    attrs: {
      id: "severity_vehicleEngine",
      "sodipodi:nodetypes": "cccccccsscccccccccccccccccssccscccssccscccccsssscsssccscc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path4792",
      "enable-background": "new    ",
      d: "m 846.869,513.594 c -2.21,-0.095 -4.075,-0.191 -4.144,-0.216 5.371,-2.315 10.765,-4.411 16.075,-6.547 0,2.343 0,4.684 0,7.025 -4.14,-0.068 -8.354,-0.116 -11.931,-0.262 z m -6.092,-1.086 c -9.739,-18.884 -11.413,-44.694 -2.474,-57.903 0.774,-1.159 1.409,-2.214 1.409,-2.351 0,-0.606 2.48,0.245 10.486,3.604 l 8.603,3.611 0,11.744 c 0.08,18.984 0,5.808 0,23.65 l 0,11.152 -8.774,3.515 -8.776,3.513 -0.474,-0.535 0,0 0,0 z m 2.596,-60.361 c -0.412,-0.237 -0.304,-0.298 0.756,-0.425 5.211,-0.292 9.245,-0.347 14.672,-0.479 0,2.443 0.018,4.909 -0.065,7.338 -5.362,-2.245 -9.706,-3.916 -15.363,-6.434 z m -40.504,60.893 c -3.18,-0.229 -5.551,-0.711 -6.928,-1.409 -1.864,-0.945 -3.713,-3.387 -5.432,-7.182 -2.98,-6.579 -4.558,-12.248 -5.362,-19.296 -0.469,-4.082 0.327,-9.829 2.229,-16.11 1.354,-4.462 3.65,-9.815 5.306,-12.365 3.865,-4.489 8.805,-5.255 14.605,-4.334 0.624,0.116 1.383,0.442 1.383,0.591 0,0.104 -0.416,0.165 -2.2,0.325 -4.096,0.429 -9.419,0.445 -11.814,3.902 -2.151,3.215 -5.044,9.782 -6.419,14.581 -0.903,3.152 -1.198,6.32 -1.118,11.979 0.068,4.614 0.236,6.159 0.979,9.037 1.01,3.9 3.105,9.131 5.088,12.714 3.617,6.83 9.294,5.716 15.454,6.805 0.078,0.08 -0.918,0.436 -1.635,0.583 -0.751,0.155 -3.084,0.256 -4.136,0.179 l 0,0 0,0 z m 30.801,0.091 c -2.556,-0.096 -16.316,-1.01 -24.09,-1.604 -9.297,-0.705 -11.047,-1.047 -13.043,-2.536 -2.076,-1.55 -5.747,-9.145 -7.644,-15.831 -0.836,-2.945 -0.992,-4.189 -1.093,-8.624 -0.061,-2.767 0.07,-7.677 0.241,-9.078 0.443,-3.607 3.808,-12.382 6.396,-16.681 1.521,-2.525 2.601,-3.352 5.188,-3.955 2.748,-0.643 5.304,-0.883 21.637,-2.036 6.13,-0.434 10.1,-0.624 14.165,-0.68 l 3.991,-0.056 -0.246,0.273 c -14.312,20.478 -4.993,46.59 0.666,60.781 -0.119,0.079 -4.332,0.095 -6.168,0.027 l 0,0 0,0 z",
      opacity: _vm.areaSeverity.Engine.opacity
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleEngine",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#rect4040-1",
      "enable-background": "new    ",
      d: "m 766.227,436.838 120.611,0 0,86.193 -120.611,0 0,-86.193 z",
      opacity: _vm.areaHoverOpacity.Engine,
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })]), _c("g", {
    staticClass: "clickable",
    attrs: {
      id: "vehicleInterior",
      transform: "translate(-413.3878,229.65989)"
    },
    on: {
      click: _vm.handleClick
    }
  }, [_c("path", {
    attrs: {
      id: "interior_outline",
      "sodipodi:nodetypes": "cccccscccccccsccsccccscccscccsscccsssscssssssccccsscccccccccccccccccccccsccccssccccccccccccccccccccccccccccccccccccccccccccccccccccsscccccscccccccccccsssscscscccccccccccccccscccccccccccscccccccccsccccccccccccscccccccccccccccsccccccccccccccsccccsssccccscccssscccsscccccccscccccsccccccccccccccccccccscssccccccccccsscscccsssccccscccssccccccccccccccsccccsccccccccccccccccsccccsccccccccccccccsscccccccccccsccccccccccscscssccccccccccccsccccscccccccccscccsccccccccsccccscscccscccscsscccccccsccccccccccccscccccscccsccscccccsccssccccccccscccccccccccccccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path10640",
      d: "m 878.615,327.598 0,-6.66 2.952,0 c 0.593,0 1.047,0.059 1.354,0.179 0.31,0.122 0.556,0.332 0.739,0.634 0.187,0.304 0.277,0.638 0.277,1.004 0,0.474 -0.151,0.871 -0.459,1.194 -0.304,0.324 -0.776,0.531 -1.415,0.621 0.233,0.11 0.41,0.221 0.532,0.33 0.259,0.235 0.501,0.531 0.729,0.883 l 1.159,1.815 -1.109,0 -0.88,-1.387 c -0.26,-0.399 -0.47,-0.705 -0.636,-0.917 -0.167,-0.213 -0.316,-0.361 -0.448,-0.444 -0.133,-0.087 -0.265,-0.146 -0.4,-0.177 -0.103,-0.022 -0.266,-0.033 -0.491,-0.033 l -1.024,0 0,2.958 -0.88,0 z m 0.88,-3.723 1.896,0 c 0.402,0 0.718,-0.04 0.946,-0.123 0.226,-0.084 0.397,-0.218 0.518,-0.399 0.117,-0.185 0.177,-0.382 0.177,-0.599 0,-0.314 -0.115,-0.573 -0.342,-0.776 -0.232,-0.202 -0.591,-0.304 -1.084,-0.304 l -2.11,0 0,2.201 z m -8.395,0.478 c 0,-1.104 0.299,-1.97 0.893,-2.596 0.594,-0.625 1.36,-0.938 2.3,-0.938 0.612,0 1.168,0.146 1.66,0.441 0.495,0.293 0.87,0.702 1.13,1.229 0.261,0.524 0.389,1.119 0.389,1.785 0,0.676 -0.135,1.28 -0.409,1.812 -0.273,0.534 -0.658,0.938 -1.157,1.211 -0.501,0.275 -1.039,0.411 -1.619,0.411 -0.626,0 -1.185,-0.152 -1.681,-0.454 -0.493,-0.304 -0.866,-0.716 -1.121,-1.239 -0.255,-0.523 -0.385,-1.077 -0.385,-1.662 z m 0.909,0.014 c 0,0.803 0.219,1.436 0.649,1.896 0.431,0.463 0.973,0.693 1.623,0.693 0.664,0 1.209,-0.234 1.64,-0.7 0.427,-0.466 0.643,-1.128 0.643,-1.983 0,-0.543 -0.093,-1.015 -0.274,-1.42 -0.185,-0.404 -0.452,-0.718 -0.806,-0.94 -0.354,-0.222 -0.749,-0.333 -1.187,-0.333 -0.624,0 -1.164,0.214 -1.61,0.643 -0.45,0.425 -0.678,1.141 -0.678,2.144 l 0,0 z m -3.067,3.231 0,-6.66 0.878,0 0,6.66 -0.878,0 z m -6.859,0 0,-6.66 2.95,0 c 0.593,0 1.045,0.059 1.354,0.179 0.308,0.122 0.556,0.332 0.741,0.634 0.182,0.304 0.277,0.638 0.277,1.004 0,0.474 -0.154,0.871 -0.459,1.194 -0.308,0.324 -0.776,0.531 -1.419,0.621 0.232,0.11 0.412,0.221 0.531,0.33 0.259,0.235 0.502,0.531 0.732,0.883 l 1.159,1.815 -1.107,0 -0.885,-1.387 c -0.255,-0.399 -0.468,-0.705 -0.636,-0.917 -0.165,-0.211 -0.313,-0.361 -0.445,-0.444 -0.131,-0.087 -0.268,-0.146 -0.402,-0.177 -0.101,-0.022 -0.264,-0.033 -0.491,-0.033 l -1.022,0 0,2.958 -0.878,0 z m 0.878,-3.723 1.896,0 c 0.404,0 0.716,-0.04 0.944,-0.123 0.228,-0.084 0.399,-0.218 0.518,-0.399 0.118,-0.185 0.178,-0.382 0.178,-0.599 0,-0.314 -0.114,-0.573 -0.343,-0.776 -0.229,-0.202 -0.591,-0.304 -1.085,-0.304 l -2.107,0 0,2.201 z m -7.089,3.723 0,-6.66 4.814,0 0,0.786 -3.935,0 0,2.039 3.685,0 0,0.781 -3.685,0 0,2.267 4.088,0 0,0.787 -4.967,0 z m -4.011,0 0,-5.874 -2.193,0 0,-0.786 5.279,0 0,0.786 -2.203,0 0,5.874 -0.883,0 z m -8.426,0 0,-6.66 0.903,0 3.497,5.229 0,-5.229 0.845,0 0,6.66 -0.902,0 -3.498,-5.233 0,5.233 -0.845,0 z m -2.423,0 0,-6.66 0.881,0 0,6.66 -0.881,0 z m -67.506,-0.442 c -9.677,3.376 -0.418,13.618 1.718,18.329 -2.732,1.45 -5.827,2.837 -8.244,4.229 l 0,0.795 c 4.817,-2.831 8.678,-4.552 9.457,-4.012 -0.675,2.238 -6.962,4.096 -9.457,5.456 l 0,0.797 c 4.279,-2.428 8.221,-4.312 9.756,-4.519 1.502,-0.203 1.394,-0.271 4.32,5.276 0.558,1.052 1.862,2.778 2.851,3.83 0.987,1.05 1.769,2.036 1.769,2.208 -1.143,1.225 -4.023,2.651 -3.586,3.391 0.295,0.365 2.646,-1.554 4.19,-2.239 0.694,0 2.941,2.277 2.938,2.967 -0.872,0.885 -3.603,2.283 -2.55,2.64 0.344,-0.016 3.651,-1.924 4.144,-2.422 0.995,-1.002 1.883,-0.576 3.329,1.59 1.206,1.804 1.784,3.179 1.292,3.179 -10.165,1.609 -18.274,3.104 -28.453,4.663 l 0,0.506 c 7.175,-1.11 19.34,-3.064 25.519,-4.154 1.97,-0.349 3.588,-0.495 3.713,-0.325 -6.962,2.279 -20.206,3.99 -29.231,5.563 l 0,0.544 c 19.479,-3.416 29.478,-5.098 29.925,-4.956 0.323,0.104 0.869,1.197 1.25,2.535 0.37,1.305 1.185,3.164 1.812,4.118 0.812,1.234 1.543,3.413 2.551,7.478 0.893,3.595 1.864,6.413 2.592,7.698 2.011,3.55 5.735,5.782 9.801,5.782 1.066,0 32.329,-9.493 50.047,-15.177 9.368,-3.004 11.699,-4.011 14.856,-6.615 2.38,-1.963 2.762,-2.491 3.498,-4.586 1.27,-3.616 0.862,-7.942 -0.998,-11.459 -1.153,-1.954 -1.123,-1.845 -2.839,-3.596 -1.718,-1.75 -3.513,-2.877 -3.551,-3.05 1.938,-1.361 4.165,-2.387 6.438,-2.943 -11.065,-4.065 -22.421,-9.047 -32.044,-11.808 -9.673,-3.654 -9.591,-1.98 -16.67,-3.177 -4.761,-0.232 -7.237,-0.138 -10.359,-0.184 -10.674,0.341 -21.599,2.684 -36.019,6.47 -2.37,0.643 -2.557,0.636 -3.237,-0.037 -2.911,-4.552 -6.032,-15.337 -10.528,-14.785 z m 5.433,6.369 c -1.158,0.567 -2.156,0.395 -3.541,0.395 -0.763,-1.576 -1.663,-3.135 -2.721,-4.481 -0.721,-0.373 -0.535,-1.436 0.303,-1.658 2.752,-0.6 4.95,3.112 5.959,5.744 l 0,0 z m -4.103,1.045 c 1.012,2.093 2.493,5.023 3.324,6.508 1.09,1.949 1.396,2.773 1.084,3.034 -0.708,0.593 -1.389,0.438 -2.509,-0.612 -1.32,-0.856 -2.592,-1.642 -3.452,-2.715 -2.79,-3.521 -3.848,-7.919 -2.422,-10.227 1.77,-2.066 3.367,2.765 3.975,4.012 l 0,0 z m 7.296,5.42 c 1.262,2.535 1.245,2.627 0.52,3.072 -1.457,0.891 -2.215,0.438 -3.884,-2.348 -0.874,-1.455 -1.811,-3.303 -2.119,-4.086 -0.487,-1.241 -0.516,-1.513 0,-1.946 2.758,-1.206 4.793,3.938 5.483,5.308 l 0,0 z m 45.179,-3.435 c 1.005,0.057 -0.594,1.114 -0.742,1.776 -0.262,1.172 -1.539,-0.213 -3.475,-1.248 -0.313,-0.674 2.877,-0.495 4.217,-0.528 l 0,0 z m 11.345,2.246 c -1.823,0.547 -5.874,0.766 -7.921,-0.805 -2.771,-1.685 7.802,-1.121 7.921,0.805 z m -22.105,-1.375 c 0.422,0.007 0.737,0.052 0.951,0.11 1.488,0.411 2.439,1.145 1.857,1.444 -0.206,0.107 -2.476,0.449 -5.055,0.723 -5.088,0.539 -10.111,1.218 -14.771,2.024 -3.232,0.706 -7.272,0.252 -9.969,1.592 -1.789,0.901 -2.594,0.996 -3.458,0.539 9.151,-3.021 18.069,-5.74 30.445,-6.432 z m 22.231,0.036 c 1.721,0.094 2.825,1 3.953,2.158 -3.131,-0.284 -3.12,0.002 -3.953,-2.158 z m 8.34,1.264 c 4.256,1.624 12.936,4.372 25.466,9.21 10.942,3.923 2.463,3.585 0.099,4.384 -1.387,-1.013 -10.703,-5.843 -14.036,-7.266 -1.956,-0.838 -5.517,-2.131 -7.858,-2.855 -2.338,-0.725 -5.195,-1.869 -6.388,-2.533 -5.777,-2.958 0.744,-1.675 2.717,-0.94 l 0,0 z m -23.981,0.805 c 0.464,-0.009 0.91,0.004 1.307,0.054 0.626,0.158 1.269,0.461 1.799,0.726 1.386,0.616 2.849,1.387 3.968,2.14 2.586,0.777 0.06,3.471 -0.465,5.401 -0.251,0.96 -0.551,2.328 -1.04,3.356 -0.39,1.061 -0.706,1.024 -1.708,1.029 1.174,0.466 1.496,2.102 1.512,2.177 -0.144,0 -0.868,-0.368 -1.596,-0.831 -0.732,-0.468 -1.196,-0.993 -1.297,-1.357 -4.255,-0.076 -3.504,-0.617 -5.31,-1.485 -3.625,-3.094 -6.898,-6.239 -11.701,-6.381 -3.851,0.102 -9.33,3.194 -11.448,0.657 -0.661,-0.808 -1.205,-1.629 -1.205,-1.811 0,-0.369 1.438,-0.666 9.281,-1.841 5.87,-0.664 12.201,-1.636 17.903,-1.834 l 0,0 z m 6.241,0.226 c 1.659,-0.045 2.936,0.499 4.355,1.178 -0.728,3.213 -4.959,-0.059 -6.967,-1.093 0.073,-0.112 1.898,-0.032 2.215,-0.063 0.12,-0.014 0.254,-0.019 0.397,-0.022 l 0,0 z m 9.02,0.741 c 1.612,0 1.52,0.552 -0.17,0.975 -3.171,1.314 -6.352,4.992 -7.086,7.955 -1.578,4.545 0.544,9.219 3.112,10.802 3.679,1.557 6.415,0.48 7.856,-1.12 0.261,-0.03 1.137,-1.066 1.941,-2.272 1.332,-1.994 1.368,-2.253 0.951,-3.216 -1.953,-3.271 1.445,10e-4 1.208,-5.641 0.092,-2.797 -5.606,-7.301 -4.324,-7.042 4.572,1.245 5.654,5.844 5.622,8.671 -0.055,4.198 -0.778,6.166 -3.323,8.994 -3.114,3.46 -6.339,4.31 -10.195,2.64 -4.793,-2.075 -6,-11.024 -2.158,-16.265 2.003,-2.735 4.553,-4.481 6.566,-4.481 l 0,0 z m 3.58,3.045 c 4.392,7.361 -2.312,3.157 -4.093,2.148 -1.446,-0.827 -1.611,-1.181 -0.867,-1.883 0.6,-0.564 3.851,-1.603 4.96,-0.265 z m 7.873,-0.841 c 0.02,0 0.038,10e-4 0.075,0.005 0.996,0.042 5.238,1.528 9.067,3.211 3.375,1.48 8.423,4.148 14.899,7.878 2.063,1.188 5.874,4.317 5.874,4.808 0,0.25 -1.048,0.506 -2.679,0.725 -6.188,0.744 -10.695,1.248 -16.104,-0.434 l -0.434,-2.024 c -0.814,-3.771 -3.475,-7.534 -8.117,-11.491 -1.493,-1.271 -2.721,-2.446 -2.721,-2.604 0,-0.028 0.046,-0.059 0.084,-0.068 0.02,-0.008 0.035,-0.008 0.054,-0.008 l 0,0.002 z m -1.436,0.799 c 0.085,-0.007 0.199,0.004 0.306,0.032 0.274,0.077 0.591,0.282 0.992,0.619 18.264,18.045 3.892,15.248 2.386,15.007 -5.132,1.417 -3.882,-11.718 -4.114,-12.948 -0.331,-1.74 -0.166,-2.665 0.43,-2.71 l 0,0 z m -54.843,0.032 c 0.844,0.013 1.488,0.306 2.205,1.013 1.705,1.693 5.238,8.567 4.405,8.567 -1.133,-0.516 -2.241,-0.83 -3.501,-1.015 -1.345,0 -1.582,-0.309 -3.065,-3.541 -0.685,-1.486 -1.587,-3.072 -2.027,-3.541 l -0.821,-0.864 c 0.901,-0.36 1.925,-0.525 2.804,-0.619 l 0,0 z m -9.067,0.294 c 1.034,0.462 0.996,0.634 -0.476,1.151 -3.474,0.705 -1.879,-1.583 0.476,-1.151 z m -3.884,1.265 c 0.218,0.182 0.282,0.474 0.129,0.681 -0.396,0.533 -1.986,0.308 -1.986,-0.287 0.597,-0.729 1.08,-0.634 1.857,-0.394 z m 27.636,-0.184 c 1.218,-0.033 2.317,0.273 3.368,0.721 0.07,0.177 -0.644,0.698 -1.595,1.121 -0.953,0.421 -2.698,1.642 -3.932,2.709 -2.837,2.456 -5.026,2.86 -5.83,1.088 -0.651,-4.019 4.515,-5.495 7.989,-5.639 l 0,0 z m -18.083,0.274 c 0.068,-0.005 0.135,0 0.202,0.015 0.912,0.189 1.907,1.989 3.629,6.001 2.211,5.152 5.474,11.634 7.126,14.095 0.647,0.963 1.077,1.848 0.95,2.021 -0.321,0.438 -1.119,0.424 -1.855,-0.067 -0.342,-0.229 -1.623,-1.693 -2.85,-3.256 -2.903,-3.699 -3.979,-4.551 -5.01,-4.012 -0.915,0.479 -1.236,0.109 -3.194,-3.396 -1.164,-2.088 -1.227,-2.604 -1.253,-5.64 -0.025,-2.795 0.05,-3.475 0.729,-4.444 0.564,-0.805 1.048,-1.287 1.526,-1.317 l 0,0 z m -3.381,0.266 c 1.329,0.985 0.594,1.991 0.474,3.617 -1.859,0.989 -2.972,-0.939 -4.315,-2.674 1.099,-0.989 2.597,-1.116 3.841,-0.943 l 0,0 z m 48.282,0.725 c 0.506,0 4.943,2.066 6.865,3.218 2.298,1.376 2.298,2.051 -0.043,2.671 -2.262,0.6 -3.284,1.911 -3.194,4.158 0.1,2.562 -0.072,2.706 -1.646,1.3 -1.552,-1.196 -3.228,-1.951 -4.704,-3.142 0,-0.146 0.584,-0.968 1.29,-1.809 1.188,-1.411 1.257,-1.712 1.212,-3.975 -0.029,-1.348 0.068,-2.421 0.22,-2.421 z m -22.33,0.287 c 1.211,0 7.307,4.329 7.303,5.172 -0.003,0.304 -8.504,2.675 -9.848,2.746 -1.181,-0.732 -1.9,-1.892 -3.066,-2.566 -0.708,-0.259 -1.257,-0.675 -1.256,-0.869 0.006,-1.067 5.238,-4.483 6.867,-4.483 z m -28.454,2.423 c 2.564,2.612 2.55,2.561 3.237,5.132 0.324,1.208 0.703,2.6 0.822,3.035 0.373,1.357 -0.559,0.489 -2.289,-2.133 -0.893,-1.354 -2.57,-3.607 -3.757,-4.987 -2.334,-2.726 -2.446,-2.964 -1.555,-3.249 1.618,-0.249 2.885,1.537 3.542,2.202 z m -5.271,-1.045 c 0.282,-0.043 1.855,1.482 3.414,3.392 2.687,3.291 4.925,6.787 4.619,7.197 -0.429,0.584 -1.083,0.15 -2.981,-1.92 -1.484,-1.619 -3.359,-4.773 -5.01,-8.381 -0.087,-0.192 -0.108,-0.277 -0.042,-0.288 l 0,0 z m 53.461,3.323 c -1.601,1.001 -0.825,-1.459 -0.601,-2.528 1.571,-2.322 1.305,1.812 0.601,2.528 z m -23.92,5.799 c -0.183,0.346 -2.523,1.318 -3.853,0.082 -1.916,-1.782 -3.019,-3.132 -3.019,-3.929 1.582,-2.15 5.505,2.37 6.872,3.847 l 0,0 z m -12.091,-4.459 c 0.254,-0.011 0.564,0.063 0.991,0.212 1.966,0.681 3.166,2.081 5.224,6.001 1.954,3.729 2.237,4.119 4.492,6.178 1.255,1.148 1.126,1.619 -0.562,1.883 -2.481,0.392 -3.296,0.12 -4.576,-1.482 -1.1,-1.378 -3.353,-5.577 -5.611,-10.408 -0.735,-1.57 -0.723,-2.354 0.042,-2.384 z m 29.967,1.622 -0.133,0.725 c -0.089,0.523 -0.612,0.884 -2.069,1.3 -2.308,0.661 -6.564,0.76 -7.255,0.185 -0.71,-0.599 -0.562,-0.875 0.688,-1.415 1.052,-0.457 1.177,-0.448 1.857,0.181 2.15,1.224 4.832,-0.086 6.912,-0.976 l 0,0 z m 17.098,0.399 c 0.082,-0.004 0.145,-0.002 0.218,0.036 0.624,0.323 0.554,0.898 -0.175,1.773 -0.795,0.946 -1.339,0.927 -1.339,-0.039 0,-0.858 0.723,-1.757 1.296,-1.77 l 0,0 z m -28.629,0.901 c 0.222,2.552 2.142,2.273 4.015,2.966 0,0.522 -0.666,0.65 -2.804,0.65 -2.097,0 -2.381,-0.102 -3.933,-1.375 -0.913,-0.75 -1.587,-1.504 -1.511,-1.696 0.169,-0.421 2.534,-1.161 3.799,-1.195 0.792,-0.174 0.363,0.546 0.434,0.65 l 0,0 z m 13.729,1.088 c -0.267,0.58 -4.188,1.186 -4.188,0.646 1.37,-1.002 3.91,-2.128 4.188,-0.646 z m 7.517,1.263 c 1.527,1.238 1.665,1.854 0.433,2.021 -2.09,0.035 -3.675,-0.961 -3.498,-2.527 1.192,-0.965 2.024,-0.242 3.065,0.506 z m -6.822,0.214 0.905,0.871 c 1.226,1.191 1.175,1.837 -0.172,1.841 -0.596,0 -2.494,0.302 -4.234,0.65 -1.737,0.349 -5.92,1.097 -9.282,1.664 -3.36,0.566 -6.203,1.109 -6.304,1.193 -1.354,0.135 -1.902,-0.763 -2.245,-1.951 -0.159,-0.346 0.477,-0.815 2.245,-1.557 2.055,-0.866 3.098,-1.055 5.743,-1.153 1.767,-0.066 5.496,-0.438 8.29,-0.833 l 5.054,-0.725 z m -21.332,2.68 c -2.769,-0.815 -1.16,-1.984 0.431,-2.241 4.331,-0.683 2.87,2.057 -0.431,2.241 z m -17.486,-0.509 c 1.181,1.565 1.414,2.375 0.646,2.637 -0.903,0.305 -1.099,0.245 -2.51,-1.302 -1.621,-1.775 -1.636,-1.954 -0.603,-2.415 1.258,-0.641 1.815,0.223 2.467,1.08 l 0,0 z m 75.823,0.72 c 1.088,0.121 1.989,0.316 1.989,0.4 0,0.085 -0.388,0.514 -0.823,0.978 -2.888,3.07 3.263,6.325 12.004,6.356 2.261,0.012 3.056,0.139 2.938,0.434 -1.644,0.983 -3.994,0.77 -4.923,1.414 0.13,0.285 0.03,0.873 -0.22,1.265 -0.868,1.358 -4.415,4.209 -6.603,5.312 -1.905,0.961 -46.288,15.164 -53.981,17.273 -3.291,0.904 -4.589,0.972 -6.172,0.287 -1.289,-0.559 -1.237,-1.156 0.129,-1.156 1.233,0 5.622,-1.073 10.535,-2.597 2.318,-0.721 8.021,-2.464 12.696,-3.871 16.327,-4.903 27.439,-8.46 30.057,-9.609 2.988,-1.316 5.308,-3.192 6.992,-5.607 l 1.168,-1.623 c 1.345,0.111 2.839,0.151 4.102,0.032 -2.077,-0.57 -4.261,-0.936 -6.392,-1.659 -2.792,-0.955 -10.834,-5.721 -11.4,-6.758 -0.774,-1.428 -0.418,-2.213 0.909,-2.277 2.559,0.479 4.595,1.127 6.995,1.406 l 0,0 z m -3.971,4.596 c 2.066,1.246 4.77,2.655 6.003,3.177 1.232,0.523 2.357,1.111 2.503,1.304 0.77,1.043 -4.104,5.59 -7.556,7.046 -2.062,0.87 -12.152,4.151 -19.307,6.252 -4.846,1.424 -4.575,1.37 -4.575,1.12 0,-0.1 0.995,-0.589 2.245,-1.05 4.955,-1.83 7.639,-4.736 7.644,-8.382 0.002,-1.173 -0.244,-2.27 -0.735,-3.034 -0.88,-1.377 -4.163,-4.094 -8.247,-6.795 -1.567,-1.04 -2.848,-1.946 -2.848,-2.06 0,-0.116 0.776,-0.402 1.728,-0.614 0.951,-0.213 2.531,-0.914 3.536,-1.559 5.942,-2.687 14.392,1.494 19.609,4.595 l 0,0 z m -55.705,-3.15 c -0.219,0 -0.706,-0.402 -1.036,-0.939 -1.311,-3.02 0.909,0.567 1.036,0.939 z m 74.573,-2.058 c 1.872,2.325 1.846,4.726 1.9,7.516 -3.187,0.608 -5.67,0.186 -7.688,0 -3.88,-0.355 -7.943,-2.483 -7.943,-4.157 1.137,-3.652 9.272,-3.158 13.731,-3.359 l 0,0 z m -87.704,0.651 c 0.348,-0.018 1.528,1.19 3.457,3.617 2.176,2.734 2.373,3.469 0.949,3.469 -0.542,0 -1.277,-0.919 -2.762,-3.364 -1.484,-2.447 -1.988,-3.705 -1.644,-3.722 l 0,0 z m 36.921,3.29 c -1.356,1.027 -2.974,2.518 -3.536,3.324 -1.146,1.635 -1.907,2.125 -3.543,2.134 -0.61,0 -1.959,0.174 -2.94,0.433 -2.31,0.608 -2.037,0.647 -3.576,-0.221 -0.74,-0.415 -1.404,-0.998 -1.474,-1.302 -0.187,-0.808 3.34,-2.186 7.211,-2.816 5.999,-1.414 3.027,-1.021 -0.688,-0.688 2.113,-2.407 5.718,-2.947 8.07,-3.181 3.878,-0.676 2.082,1.09 0.476,2.317 l 0,0 z m -8.849,-1.482 c 0.376,0.007 0.431,0.142 0.431,0.327 0,0.763 -6.887,2.536 -10.146,2.602 -1.246,0.027 -1.684,-0.137 -1.684,-0.507 -0.876,-0.325 4.304,-1.248 5.568,-1.482 3.728,-0.691 5.202,-0.953 5.831,-0.94 z m 12.998,0.289 c 1.637,0 11.185,6.321 11.185,7.41 0,0.246 -1.068,0.59 -2.679,0.83 -1.469,0.221 -4.092,0.872 -5.832,1.478 -3.983,1.39 -4.366,1.435 -4.706,0.295 -0.367,-1.254 -2.058,-2.647 -3.755,-3.109 -2.528,-0.689 -2.404,-1.263 0.908,-4.193 2.098,-1.859 3.617,-2.711 4.879,-2.711 l 0,0 z m -24.659,5.056 c 4.11,1.209 8.65,4.54 11.875,7.553 1.926,1.917 2.723,3.539 2.421,5.064 -0.575,2.905 -2.122,4.238 -4.492,3.935 -0.791,-0.1 -1.657,-0.349 -1.898,-0.507 -0.763,-1.603 -0.733,-3.237 -1.382,-4.948 -0.293,-0.46 -2.802,-2.81 -5.576,-5.238 -2.771,-2.428 -5.008,-4.624 -5.008,-4.845 -0.001,-0.466 2.431,-0.985 4.06,-1.014 l 0,0 z m -6.392,1.05 c 0.222,0.016 0.482,0.053 0.695,0.145 1.322,0.593 10.942,9.188 11.612,10.37 1.084,2.149 1.034,4.123 -0.301,5.17 -0.999,0.778 -1.38,1.377 -1.38,2.058 0,1.291 -0.754,1.232 -1.298,-0.105 -0.597,-1.472 -3.966,-6.824 -7.6,-12.108 -0.885,-1.807 -4.488,-4.694 -1.728,-5.53 l 0,0 z m -3.67,0.652 c 0.266,0.008 0.525,0.067 0.779,0.182 0.716,0.32 3.006,3.417 7.342,10.044 4.271,6.528 3.979,6.968 -1.468,2.278 -3.771,-2.975 -3.958,-5.248 -4.62,-9.181 -1.961,-2.502 -0.536,5.519 -2.204,2.566 -0.717,-2.209 -2.337,-5.042 0.171,-5.892 l 0,0.003 z m 26.087,0.25 c 3.871,0.177 6.39,1.991 5.782,4.699 -0.314,1.403 -3.082,4.195 -4.188,4.195 -2.849,-2.238 -6.033,-5.175 -8.202,-7.807 2.094,-0.81 4.482,-1.087 6.608,-1.087 l 0,0 z m 55.398,0.257 c 1.743,0 1.748,0.073 1.081,1.695 -1.212,2.95 -4.854,5.752 -10.017,7.734 -2.72,1.045 -22.618,7.395 -44.826,14.238 -12.127,3.738 -13.542,3.969 -16.409,2.854 -1.368,-0.53 -4.754,-3.034 -4.101,-3.034 6.249,3.635 11.521,0.635 15.629,-0.615 14.533,-4.444 45.808,-14.331 47.199,-14.924 2.295,-0.979 5.36,-3.202 7.041,-5.057 2.553,-2.816 2.695,-2.891 4.403,-2.891 l 0,0 z m -34.845,1.477 c 0.464,0.388 0.423,0.591 -0.306,1.445 -2.174,2.56 -6.776,5.2 -16.449,9.4 -4.594,1.994 -6.519,2.63 -6.519,2.096 0,-0.099 0.423,-0.939 0.948,-1.808 0.67,-1.107 1.617,-1.92 3.104,-2.748 1.169,-0.648 2.644,-1.705 3.288,-2.385 4.236,-3.326 12.127,-6.162 15.934,-6 l 0,0 z m 1.425,0.945 c 2.056,3.184 -0.547,6.569 -3.025,8.273 -1.37,0.921 -15.79,6.253 -17.025,6.281 -1.156,-0.277 -1.894,-1.126 -2.621,-1.869 0.08,-0.054 2.894,-1.354 6.263,-2.858 6.179,-1.533 13.759,-6.253 16.408,-9.827 l 0,0 z m -44.33,8.589 c 4.572,3.138 8.427,6.512 11.725,10.234 -2.733,1.479 -5.669,1.886 -8.203,0.113 -1.346,-1.284 -4.244,-9.754 -3.543,-10.339 0.005,-0.003 0.015,-0.006 0.021,-0.008 l 0,0 z m 12.441,4.236 c 0.007,-0.004 0.019,0.002 0.02,0.004 -0.102,0.614 -0.696,0.901 -1.034,1.151 0.075,-0.641 0.506,-0.788 1.013,-1.155 l 10e-4,0 z m 8.871,1.518 c 2.326,0.838 1.784,1.446 -2.68,2.823 -2.171,0.671 -4.067,1.212 -4.229,1.229 -1.847,-0.562 -2.357,-3.538 -1.256,-4.664 2.541,-1.154 5.95,-0.168 8.165,0.612 z"
    }
  }), _c("path", {
    staticStyle: {
      fill: "none",
      stroke: "#005aff",
      "stroke-width": "1.76289999",
      "stroke-dasharray": "10.5776, 1.7629"
    },
    attrs: {
      id: "interior_line",
      "inkscape:connector-curvature": "0",
      d: "m 763.938,317.971 123.2,0 0,88.644 -123.2,0 0,-88.644 z"
    }
  }), _c("path", {
    staticStyle: {
      fill: "#ff0000"
    },
    attrs: {
      id: "severity_vehicleInterior",
      "sodipodi:nodetypes": "cssszcccccc",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#path4802",
      "enable-background": "new    ",
      d: "m 787.521,360.935 c -0.565,-1.006 -7.973,-9.496 -8.302,-9.87 -0.529,-0.603 -15.743,-18.683 -7.329,-23.141 5.728,-3.036 11.075,12.465 12.929,14.529 0.804,0.896 27.704,-8.151 45.231,-7.063 17.525,1.086 32.208,5.514 52.125,15.638 -4.697,1.508 -2.828,0.826 -6.388,2.684 11.566,6.741 9.833,19.079 3.97,22.743 -3.922,3.931 -16.516,8.33 -33.271,12.461 -14.72,3.969 -30.722,11.54 -36.418,8.6 -11.45,-8.039 -2.146,-15.274 -22.548,-36.578 l 0,-0.003 z",
      opacity: _vm.areaSeverity.Interior.opacity
    }
  }), _c("path", {
    attrs: {
      id: "selection_vehicleInterior",
      "inkscape:connector-curvature": "0",
      "inkscape:label": "#rect4040",
      "enable-background": "new    ",
      d: "m 765.071,319.067 120.61,0 0,86.193 -120.61,0 0,-86.193 z",
      opacity: _vm.areaHoverOpacity.Interior,
      fill: "",
      iag_selection: "",
      iag_selection_opacity: ""
    },
    on: {
      mouseover: _vm.handleMouseOver,
      mouseleave: _vm.handleMouseLeave
    }
  })])], 1), _vm.popupVisible ? _c("div", {
    ref: "popup",
    staticClass: "popup container",
    style: {
      top: "".concat(_vm.top, "px"),
      left: "".concat(_vm.left, "px")
    }
  }, [_c("div", {
    staticClass: "mb-3 header"
  }, [_c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.selectedArea))]), _c("button", {
    staticClass: "delete ml-5",
    attrs: {
      "aria-label": "close"
    },
    on: {
      click: _vm.closePopup
    }
  })]), _c("div", {
    staticClass: "field"
  }, _vm._l(_vm.damageSeverity, function (damage, index) {
    return _c("div", {
      key: index,
      staticClass: "control"
    }, [_c("label", {
      staticClass: "radio"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.areaSeverity[damage.area].severity,
        expression: "areaSeverity[damage.area].severity"
      }],
      attrs: {
        type: "radio"
      },
      domProps: {
        value: damage.value,
        checked: _vm._q(_vm.areaSeverity[damage.area].severity, damage.value)
      },
      on: {
        change: [function ($event) {
          return _vm.$set(_vm.areaSeverity[damage.area], "severity", damage.value);
        }, _vm.handleChange]
      }
    }), _vm._v(" " + _vm._s(damage.name) + " ")])]);
  }), 0)]) : _vm._e()])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "header"
  }, [_vm._m(1), _c("div", [_vm.lastSyncDate ? _c("div", {
    staticClass: "tags has-addons is-pulled-right"
  }, [_c("span", {
    staticClass: "tag is-dark"
  }, [_vm._v("Last fetched")]), _c("span", {
    staticClass: "tag is-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(_vm.lastSyncDate, _vm.$userInfo.locale)))])]) : _vm._e()])]), _c("article", {
    staticClass: "tile is-child pt-2"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("State")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.quoteRepx.vehDamageState,
      expression: "quoteRepx.vehDamageState"
    }],
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.quoteRepx, "vehDamageState", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.states, function (state, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: state.key
      }
    }, [_vm._v(" " + _vm._s(state.key) + " ")]);
  }), 0)])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-flex is-justify-content-flex-end"
  }, [_c("bulma-checkbox-date", {
    attrs: {
      label: "Market Value required?",
      disabled: _vm.isSync || _vm.$licenceExpired
    },
    model: {
      value: _vm.quoteRepx.vehDamageMarketValueRequired,
      callback: function callback($$v) {
        _vm.$set(_vm.quoteRepx, "vehDamageMarketValueRequired", $$v);
      },
      expression: "quoteRepx.vehDamageMarketValueRequired"
    }
  })], 1)]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Market Value")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      formats: "",
      precision: 2,
      symbol: _vm.$company.currency.symbol,
      disabled: _vm.isSync || !_vm.quoteRepx.vehDamageMarketValueRequired || _vm.$licenceExpired
    },
    model: {
      value: _vm.quoteRepx.vehDamageMarketValue,
      callback: function callback($$v) {
        _vm.$set(_vm.quoteRepx, "vehDamageMarketValue", $$v);
      },
      expression: "quoteRepx.vehDamageMarketValue"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("table", {
    staticClass: "table is-striped is-hoverable table is-fullwidth"
  }, [_vm._m(2), _c("tbody", _vm._l(_vm.filteredAreaSeverity, function (item, key) {
    return _c("tr", {
      key: key
    }, [_c("td", [_vm._v(_vm._s(item.name))]), _c("td", [_c("span", {
      staticClass: "tag severity",
      class: _vm.renderSeverity(item.opacity)
    }, [_vm._v(" " + _vm._s(item.severity) + " ")])]), _c("td", [item.syncDate ? _c("span", {
      staticClass: "tag",
      class: "is-".concat(_vm.$theme.name)
    }, [_vm._v("Synced")]) : _c("button", {
      staticClass: "button is-danger tooltip is-tooltip",
      attrs: {
        "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Remove",
        disabled: _vm.$licenceExpired
      },
      on: {
        click: function click($event) {
          return _vm.remove(item);
        }
      }
    }, [_vm._m(3, true)])])]);
  }), 0)])])]), _vm._m(4)])])])])])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "header"
  }, [_c("div", [_c("span", {
    staticClass: "subtitle is-inline-block"
  }, [_vm._v("Vehicle Damage")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("span", {
    staticClass: "subtitle is-inline-block"
  }, [_vm._v("Selected Area Severity")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", [_vm._v("Area")]), _c("th", [_vm._v("Severity")]), _c("th")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-delete"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".vehicle-damage-licence-expired .svg-container .clickable {\n  cursor: not-allowed;\n}\n.vehicle-damage-licence-expired .svg-container:hover::before,\n.vehicle-damage-licence-expired .control:has(> .select > select:disabled):hover::before,\n.vehicle-damage-licence-expired .control:has(> input:disabled, > .pretty input:disabled):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.vehicle-damage-licence-expired .svg-container:hover::before {\n  top: 0;\n  left: 0;\n}\n.vehicle-damage-licence-expired .control:has(> .select > select:disabled),\n.vehicle-damage-licence-expired .control:has(> input:disabled, > .pretty input:disabled) {\n  position: relative;\n  cursor: not-allowed;\n}\n.vehicle-damage-licence-expired .control:has(> .select > select:disabled):hover::before,\n.vehicle-damage-licence-expired .control:has(> input:disabled, > .pretty input:disabled):hover::before {\n  top: 100%;\n  left: 0;\n  -webkit-transform: translateY(0.5rem);\n          transform: translateY(0.5rem);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".clickable[data-v-2cd8e84c] {\n  cursor: pointer;\n}\n.header[data-v-2cd8e84c] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.svg-container[data-v-2cd8e84c] {\n  position: relative;\n  width: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  /* justify-content: center; */\n  /* align-items: center; */\n}\n.popup[data-v-2cd8e84c] {\n  position: absolute;\n  /* background-color: #fff; */\n  border: 1px solid #b3e5fc;\n  border-radius: 4px;\n  padding: 10px;\n  -webkit-box-shadow: rgba(32, 0, 73, 0.35) 0px 5px 15px;\n          box-shadow: rgba(32, 0, 73, 0.35) 0px 5px 15px;\n  background-color: #e3f2fd;\n  padding: 20px;\n  margin: 20px;\n}\n.popup .header[data-v-2cd8e84c] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.radio[data-v-2cd8e84c] {\n  display: block;\n  margin-bottom: 5px;\n}\n.radio input[type=radio][data-v-2cd8e84c] {\n  margin-right: 5px;\n}\n.severity[data-v-2cd8e84c] {\n  color: #000;\n  padding: 20px;\n  border: 1px solid #ccc;\n  background-color: rgb(255, 0, 0);\n  font-weight: bold;\n}\n.severity.opacity-0-2[data-v-2cd8e84c] {\n  background-color: rgba(255, 0, 0, 0.2);\n}\n.severity.opacity-0-4[data-v-2cd8e84c] {\n  background-color: rgba(255, 0, 0, 0.4);\n}\n.severity.opacity-0-6[data-v-2cd8e84c] {\n  background-color: rgba(255, 0, 0, 0.6);\n}\n.severity.opacity-0-8[data-v-2cd8e84c] {\n  background-color: rgba(255, 0, 0, 0.8);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("178c9f68", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("fda3d514", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteVehicleDamage.vue":
/*!************************************************!*\
  !*** ./src/views/quote/QuoteVehicleDamage.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true */ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true");
/* harmony import */ var _QuoteVehicleDamage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteVehicleDamage.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss */ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss");
/* harmony import */ var _QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true */ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteVehicleDamage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2cd8e84c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteVehicleDamage.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss":
/*!*********************************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=0&id=2cd8e84c&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_0_id_2cd8e84c_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=style&index=1&id=2cd8e84c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_style_index_1_id_2cd8e84c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true":
/*!******************************************************************************************!*\
  !*** ./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteVehicleDamage.vue?vue&type=template&id=2cd8e84c&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicleDamage_vue_vue_type_template_id_2cd8e84c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-vehicle-damage-chunk.js.map