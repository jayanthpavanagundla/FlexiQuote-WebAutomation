(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pnetmessagelist-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PnetMessageListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    value: null
  },
  data: function data() {
    return {};
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _PnetMessageListSideMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./PnetMessageListSideMenu */ "./src/views/pnetmessage/PnetMessageListSideMenu.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./route-types */ "./src/views/pnetmessage/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./PnetMessageService */ "./src/views/pnetmessage/PnetMessageService.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./columns */ "./src/views/pnetmessage/columns.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./storeMixin */ "./src/views/pnetmessage/storeMixin.js");
/* harmony import */ var _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/LoadQuoteSteps */ "./src/components/LoadQuoteSteps/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _PnetMessageValidation__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./PnetMessageValidation */ "./src/views/pnetmessage/PnetMessageValidation.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _components_NavService__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/NavService */ "./src/components/NavService.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");


































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'PnetMessageListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_12__["default"],
    PnetMessageListSideMenu: _PnetMessageListSideMenu__WEBPACK_IMPORTED_MODULE_14__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_16__["default"],
    LoadQuoteModal: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["LoadQuoteModal"],
    LoadQuoteSteps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["LoadQuoteSteps"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_22__["ConfirmModal"]
  },
  mixins: [_PnetMessageValidation__WEBPACK_IMPORTED_MODULE_23__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_19__["DateTimeFiltersMixin"], _storeMixin__WEBPACK_IMPORTED_MODULE_20__["default"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      isTableLoading: false,
      entitySummaries: {},
      countSummaries: null,
      totalRows: 0,
      filter: {
        quoteNo: '',
        rego: '',
        claimNo: '',
        messageTypeId: 0,
        messageStatusId: _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_18__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_18__["Columns"].length - 2].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_18__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_18__["Columns"].length - 2].defaultOrder,
        pageIndex: 1,
        pageSize: 18,
        customerNameOrContactNo: ''
      },
      selectedRow: null,
      isLoadQuoteModalActive: false,
      currentStep: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].CreateAssign.id,
      loadOptions: {
        messageId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        messageTypeId: _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ,
        quoteId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        insurerId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        isCreateQuote: true,
        customerId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        customerOption: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["CustomerOptionTypes"].Create,
        title: '',
        customerName: '',
        firstname: '',
        lastname: '',
        isPerson: false,
        vehicleId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        isOverwriteVehicle: false,
        isOverwriteOrmMessageNo: false,
        quotingMethod: ''
      },
      vehicleExists: false,
      steps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"],
      isConfirmModalActive: false,
      isMessageOperationConfirmModalActive: false,
      messageOperationTypeId: '',
      quoteNo: '',
      quoteId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
      expectedOrmMessageNo: 0,
      selectedMessage: null,
      savedLoadOptions: null,
      unreadOffset: 'has-badge-child-offset2',
      readOffset: 'has-badge-child-offset2',
      toSendOffset: 'has-badge-child-offset2',
      sentOffset: 'has-badge-child-offset2',
      deletedOffset: 'has-badge-child-offset2',
      enableLoadQuoteNext: true
    };
  },
  computed: {
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_18__["Columns"];
    },
    messageStatusTypes: function messageStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"];
    },
    messageTypes: function messageTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"];
    },
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    canEditMessage: function canEditMessage() {
      return this.$user.info.isSupportUser;
    },
    canLoadMessage: function canLoadMessage() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead && !this.$licenceExpired;
    },
    canMarkMessageRead: function canMarkMessageRead() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead;
    },
    canMarkMessageUnread: function canMarkMessageUnread() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read && this.$user.info.isSupportUser;
    },
    canDeleteMessage: function canDeleteMessage() {
      if (this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend) {
        return this.filter.messageStatusId !== _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted;
      } else {
        return this.$userInfo.isSupportUser && this.filter.messageStatusId !== _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted;
      }
    },
    canUndeleteMessage: function canUndeleteMessage() {
      return this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted && this.$user.info.isSupportUser;
    },
    lastStep: function lastStep() {
      if (this.steps.OverwriteVehicle.enabled) {
        return this.steps.OverwriteVehicle;
      } else {
        return this.steps.UpdateCustomer;
      }
    },
    enableContinue: function enableContinue() {
      return this.lastStep.id === this.currentStep;
    }
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].LoadQuoteNextStatus, function (enableLoadQuoteNext) {
      _this.enableLoadQuoteNext = enableLoadQuoteNext;
    });
  },
  created: function created() {
    this.getEntitySummaries();
    this.getCountSummaries();
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getEntitySummaries();
    },
    resetList: function resetList() {
      this.filter.quoteNo = '';
      this.filter.rego = '';
      this.filter.claimNo = '';
      this.filter.messageTypeId = 0;
      this.filter.sortColumn = _columns__WEBPACK_IMPORTED_MODULE_18__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_18__["Columns"].length - 2].name;
      this.filter.sortOrder = _columns__WEBPACK_IMPORTED_MODULE_18__["Columns"][_columns__WEBPACK_IMPORTED_MODULE_18__["Columns"].length - 2].defaultOrder;
      this.filter.pageIndex = 1;
      this.filter.pageSize = 18;
      this.filter.customerNameOrContactNo = '';
      this.persistFilter();
      this.getEntitySummaries();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getEntitySummaries();
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getEntitySummaries();
    },
    tabClicked: function tabClicked(messageSatusId) {
      if (this.filter.messageStatusId !== messageSatusId) {
        this.filter.messageStatusId = messageSatusId;
        this.filter.pageIndex = 1;
        this.selectedRow = null;
        this.persistFilter();
        this.getEntitySummaries();
        this.getCountSummaries();
      }
    },
    getEntitySummaries: function getEntitySummaries() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this2.isTableLoading = true;
              _this2.retrieveFilter();
              _context.n = 1;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].getEntitySummaries(_this2.filter);
            case 1:
              _this2.entitySummaries = _context.v;
              _this2.totalRows = _this2.entitySummaries.length > 0 ? _this2.entitySummaries[0].totalRows : 0;
              _this2.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getCountSummaries: function getCountSummaries() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].getCountSummaries();
            case 1:
              _this3.countSummaries = _context2.v;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getCount: function getCount(messageStatusId) {
      if (this.countSummaries) {
        var count = 0;
        var summary = this.countSummaries.find(function (c) {
          return c.statusId === messageStatusId;
        });
        if (messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend) {
          var failedSummary = this.countSummaries.find(function (c) {
            return c.statusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Failed;
          });
          count = summary.messageCount + failedSummary.messageCount;
        } else {
          count = summary.messageCount;
        }
        this.setBadgeOffset(messageStatusId, count);
        return count;
      }
    },
    setBadgeOffset: function setBadgeOffset(messageStatusId, count) {
      var offset = 'has-badge-child-offset2';
      if (count >= 10 && count <= 99) {
        offset = 'has-badge-child-offset3';
      } else if (count >= 100 && count <= 999) {
        offset = 'has-badge-child-offset4';
      } else if (count >= 1000 && count <= 9999) {
        offset = 'has-badge-child-offset5';
      } else if (count >= 10000) {
        offset = 'has-badge-child-offset6';
      }
      switch (messageStatusId) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead:
          this.unreadOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read:
          this.readOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend:
          this.toSendOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Sent:
          this.sentOffset = offset;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted:
          this.deletedOffset = offset;
          break;
      }
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    canPrintMessage: function canPrintMessage(messageTypeId) {
      var canPrint = messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].AUQT || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].ARES || messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].ADQT;
      return canPrint && this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read;
    },
    canResendMessage: function canResendMessage(messageStatusId) {
      var canResend = this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Sent || this.filter.messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend && messageStatusId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Failed;
      return canResend;
    },
    updateMessageStatus: function updateMessageStatus(messageId, messageStatusId) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              _context3.p = 0;
              _context3.n = 1;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].updateMessageStatus(messageId, messageStatusId);
            case 1:
              _context3.n = 3;
              break;
            case 2:
              _context3.p = 2;
              _t = _context3.v;
              _this4.$notification.openMessageXhrError('PNET Message', _t);
            case 3:
              _this4.getEntitySummaries();
              _this4.getCountSummaries();
            case 4:
              return _context3.a(2);
          }
        }, _callee3, null, [[0, 2]]);
      }))();
    },
    markMessageAsRead: function markMessageAsRead(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read);
    },
    markMessageAsUnread: function markMessageAsUnread(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead);
    },
    markMessageAsToSend: function markMessageAsToSend(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend);
    },
    markMessageAsDeleted: function markMessageAsDeleted(messageId) {
      this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted);
    },
    unDeleteMessage: function unDeleteMessage(messageId, messageDirection) {
      if (messageDirection === 0) {
        // Incoming messages
        this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read);
      } else {
        // Outgoing messages
        this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Sent);
      }
    },
    addNew: function addNew() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this5.addStoreItem();
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    print: function print(messageId, messageTypeId) {
      var reportName = '';
      var messageType = Object.keys(_enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"]).find(function (k) {
        return _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"][k] === messageTypeId;
      });
      switch (messageTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ:
          reportName = 'rptPnetQREQ';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].AUQT:
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].ADQT:
          reportName = 'rptPnetAUQT';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].ARES:
          reportName = 'rptPnetARES';
          break;
      }
      if (reportName) {
        var params = {
          CompanyID: this.$userInfo.companyId,
          MessageID: messageId
        };
        var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_30__["KeyValuePairModel"].convertToKeyValuePairs(params);
        var parameterId = this.$guid.newGuid();
        _store_utils__WEBPACK_IMPORTED_MODULE_28__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
        var emailer = new _classes__WEBPACK_IMPORTED_MODULE_29__["Emailer"]();
        emailer.remark = "PNET ".concat(messageType);
        emailer.remarkTypeId = _enums__WEBPACK_IMPORTED_MODULE_13__["RemarkTypes"].Remark;
        emailer.subject = "PNET ".concat(messageType);
        emailer.reportName = "PNET_".concat(messageType);
        _store_utils__WEBPACK_IMPORTED_MODULE_28__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
        var routeData = this.$router.resolve({
          name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_31__["default"].PrintPreview.name,
          params: {
            reportName: reportName
          },
          query: {
            parameterId: parameterId,
            emailerId: emailer.id,
            isNewTab: true
          }
        });
        window.open(routeData.href, '_blank');
      }
    },
    previous: function previous() {
      this.currentStep--;
      if (this.currentStep === this.steps.CreateAssign.id) {
        this.$v.loadOptions.quoteId.$reset();
      } else if (this.currentStep === this.steps.SelectInsurer.id) {
        this.$v.loadOptions.insurerId.$reset();
      } else if (this.currentStep === this.steps.UpdateCustomer.id) {
        this.$v.loadOptions.customerId.$reset();
      }
    },
    next: function next() {
      switch (this.currentStep) {
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].CreateAssign.id:
          this.$v.loadOptions.quoteId.$touch();
          if (!this.$v.loadOptions.quoteId.$error || this.loadOptions.isCreateQuote) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].SelectInsurer.id:
          this.$v.loadOptions.insurerId.$touch();
          if (!this.$v.loadOptions.insurerId.$error) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].UpdateCustomer.id:
          this.$v.loadOptions.customerId.$touch();
          if (!this.$v.loadOptions.customerId.$error || this.loadOptions.customerOption === _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["CustomerOptionTypes"].Create) {
            this.currentStep++;
          }
          break;
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].OverwriteVehicle.id:
          break;
      }
    },
    closeModal: function closeModal() {
      this.isLoadQuoteModalActive = false;
      this.reset();
    },
    loadMessage: function loadMessage() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var result, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              _this6.$showSpinner('Loading quote');
              _context5.p = 1;
              _this6.isLoadQuoteModalActive = false;
              _context5.n = 2;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].loadMessage(_this6.loadOptions);
            case 2:
              result = _context5.v;
              _this6.quoteId = result.data;
              // console.log(this.quoteId)
              _this6.getEntitySummaries();
              _this6.getCountSummaries();
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].validGuid(_this6.quoteId)) {
                _context5.n = 4;
                break;
              }
              _context5.n = 3;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].getQuoteNo(_this6.quoteId);
            case 3:
              _this6.quoteNo = _context5.v;
              _this6.print(_this6.loadOptions.messageId, _this6.loadOptions.messageTypeId);
              if (_this6.loadOptions.isCreateQuote && _this6.loadOptions.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ) {
                _this6.createAuditTrail(_this6.quoteId, 'insert', '');
              } else {
                // TODO: create update AuditTrail entry
              }
              _this6.savedLoadOptions = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(_this6.loadOptions);
              _this6.isConfirmModalActive = true;
            case 4:
              _context5.n = 6;
              break;
            case 5:
              _context5.p = 5;
              _t2 = _context5.v;
              throw _t2;
            case 6:
              _context5.p = 6;
              _this6.reset();
              _this6.$hideSpinner();
              return _context5.f(6);
            case 7:
              return _context5.a(2);
          }
        }, _callee5, null, [[1, 5, 6, 7]]);
      }))();
    },
    reset: function reset() {
      this.loadOptions.messageId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.loadOptions.messageTypeId = _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ;
      this.loadOptions.quoteId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.loadOptions.isCreateQuote = true;
      this.loadOptions.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.loadOptions.customerOption = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["CustomerOptionTypes"].Create;
      this.loadOptions.isOverwriteVehicle = false;
      this.loadOptions.customerId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.loadOptions.title = '';
      this.loadOptions.customerName = '';
      this.loadOptions.firstname = '';
      this.loadOptions.lastname = '';
      this.loadOptions.isPerson = false;
      this.loadOptions.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty();
      this.loadOptions.isOverwriteOrmMessageNo = false;
      this.loadOptions.quotingMethod = '';
      this.currentStep = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["Steps"].CreateAssign.id;
      this.selectedMessage = null;
      // Reset validation objects
      this.$v.loadOptions.$reset();
    },
    load: function load(index) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var names;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this7.selectedMessage = _this7.entitySummaries[index];
              _this7.loadOptions.messageId = _this7.selectedMessage.messageId;
              _this7.loadOptions.messageTypeId = _this7.selectedMessage.messageTypeId;
              if (!(_this7.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QREQ || _this7.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].MANQ)) {
                _context6.n = 2;
                break;
              }
              if (!(_this7.selectedMessage.messageTypeId === _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].MANQ && !_this7.selectedMessage.customerName)) {
                _context6.n = 1;
                break;
              }
              _this7.$notification.openNotificationWithType('danger', 'PNET', 'Cannot find matching QREQ message. Load cancelled.\nPlease contact FlexiQuote support.');
              return _context6.a(2);
            case 1:
              _this7.assertVehicleExists(_this7.selectedMessage.regoNo);
              _this7.loadOptions.isPerson = _this7.selectedMessage.isPerson;
              _this7.loadOptions.customerName = _this7.selectedMessage.customerName;
              if (_this7.selectedMessage.isPerson) {
                names = _this7.selectedMessage.customerName.split(', ');
                _this7.loadOptions.lastname = names[0];
                _this7.loadOptions.firstname = names.length > 1 ? names[1] : '';
                _this7.loadOptions.title = _this7.selectedMessage.title;
              }
              _this7.isLoadQuoteModalActive = true;
              _context6.n = 3;
              break;
            case 2:
              _this7.loadOptions.quoteNo = _this7.selectedMessage.quoteNo;
              _this7.loadMessage();
            case 3:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    assertVehicleExists: function assertVehicleExists(rego) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _context7.n = 1;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].assertVehicleExists(rego);
            case 1:
              _this8.vehicleExists = _context7.v;
              _this8.steps.OverwriteVehicle.enabled = _this8.vehicleExists;
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    gotoQuote: function gotoQuote(goto) {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        var accessModel, url, routeData;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this9.isConfirmModalActive = false;
              if (!goto) {
                _context8.n = 2;
                break;
              }
              _context8.n = 1;
              return _components_NavService__WEBPACK_IMPORTED_MODULE_26__["default"].getAccess('A077', 'detail');
            case 1:
              accessModel = _context8.v;
              url = '';
              if (accessModel.version === '2') {
                routeData = _this9.$router.resolve({
                  name: _views_quote_route_types__WEBPACK_IMPORTED_MODULE_27__["default"].QuoteDetail.name,
                  params: {
                    quoteId: _this9.quoteId
                  }
                });
                url = routeData.href;
              } else {
                url = "".concat("", "/modules/handlers/QuoteLoading.ashx?quoteId=").concat(_this9.quoteId, "&mode=5");
              }
              window.open(url, '_blank');
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    createAuditTrail: function createAuditTrail(entityId, operationType, deepdiff) {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        var quote, audtiTrailItem;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _context9.n = 1;
              return _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].getQuoteEntity(entityId);
            case 1:
              quote = _context9.v;
              audtiTrailItem = {
                auditTrailId: null,
                performedAt: new Date().toISOString,
                userId: _this0.$userInfo.userId,
                userName: _this0.$userInfo.displayName,
                userRole: _this0.$userInfo.isSupportUser ? 'Support' : 'Normal',
                userAgent: '',
                userHostAddress: '',
                userHostName: '',
                url: '',
                companyId: _this0.$userInfo.companyId,
                entityId: entityId,
                entityType: 'Quote',
                entityReference: "".concat(quote.prefix).concat(quote.quoteNo).concat(quote.suffix),
                operationType: operationType,
                deepdiff: operationType === 'update' ? JSON.stringify(deepdiff) : null,
                entity: operationType === 'insert' ? JSON.stringify(quote) : null
              };
              _PnetMessageService__WEBPACK_IMPORTED_MODULE_17__["default"].postAuditTrailItem(audtiTrailItem);
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    showMessageActionConfirmModal: function showMessageActionConfirmModal(messageId, messageStatusTypeId) {
      this.messageOperationTypeId = messageStatusTypeId;
      this.selectedMessageId = messageId;
      this.isMessageOperationConfirmModalActive = true;
    },
    changeMessageStatus: function changeMessageStatus(messageId, messageStatusTypeId) {
      switch (messageStatusTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Unread:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].UnRead);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted:
          this.updateMessageStatus(messageId, _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted);
          break;
      }
      this.isMessageOperationConfirmModalActive = false;
    },
    getFolderName: function getFolderName(messageStatusTypeId) {
      switch (messageStatusTypeId) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Read:
          return 'Read';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Unread:
          return 'Unread';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].ToSend:
          return 'To Send';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["MessageStatusTypes"].Deleted:
          return 'Deleted';
          break;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    if (to.name === _route_types__WEBPACK_IMPORTED_MODULE_15___default.a.PnetMessageView.name) {
      var messageId = to.params.messageId;
      var message = this.entitySummaries.find(function (m) {
        return m.messageId === messageId;
      });
      this.setMessageSummary(message);
    }
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.rego,
      expression: "value.rego"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Rego"
    },
    domProps: {
      value: _vm.value.rego
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "rego", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.claimNo,
      expression: "value.claimNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Claim No."
    },
    domProps: {
      value: _vm.value.claimNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "claimNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.quoteNo,
      expression: "value.quoteNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Quote No."
    },
    domProps: {
      value: _vm.value.quoteNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "quoteNo", $event.target.value);
      }
    }
  })])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false,
      "show-new": _vm.$userInfo.isSupportUser,
      "show-print": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("pnet-message-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "m-3"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "tabs is-toggle is-toggle-rounded"
  }, [_c("ul", [_c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.UnRead
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.UnRead);
      }
    }
  }, [_vm._m(0), _c("span", [_c("span", {
    class: _vm.unreadOffset
  }, [_vm._v("Unread")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.UnRead ? "has-badge-info" : "has-badge-dark"],
    attrs: {
      "data-badge": _vm.getCount(_vm.messageStatusTypes.UnRead)
    }
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Read
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Read);
      }
    }
  }, [_vm._m(1), _c("span", [_c("span", {
    class: _vm.readOffset
  }, [_vm._v("Read")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Read ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.ToSend
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.ToSend);
      }
    }
  }, [_vm._m(2), _c("span", [_c("span", {
    class: _vm.toSendOffset
  }, [_vm._v("To Send")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.ToSend ? "has-badge-info" : "has-badge-dark"],
    attrs: {
      "data-badge": _vm.getCount(_vm.messageStatusTypes.ToSend)
    }
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Sent
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Sent);
      }
    }
  }, [_vm._m(3), _c("span", [_c("span", {
    class: _vm.sentOffset
  }, [_vm._v("Sent")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Sent ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])]), _c("li", {
    class: {
      "is-active": _vm.filter.messageStatusId == _vm.messageStatusTypes.Deleted
    }
  }, [_c("a", {
    on: {
      click: function click($event) {
        return _vm.tabClicked(_vm.messageStatusTypes.Deleted);
      }
    }
  }, [_vm._m(4), _c("span", [_c("span", {
    class: _vm.deletedOffset
  }, [_vm._v("Deleted")]), _vm.countSummaries ? _c("span", {
    staticClass: "has-badge-rounded has-badge-medium",
    class: [_vm.filter.messageStatusId == _vm.messageStatusTypes.Deleted ? "has-badge-info" : "has-badge-dark"]
  }) : _vm._e()])])])]), _c("div", {
    staticClass: "tags has-addons",
    staticStyle: {
      "margin-left": "auto"
    }
  }, [_c("span", {
    staticClass: "tag is-dark"
  }, [_vm._v("Last fetched")]), !_vm.isTableLoading ? _c("span", {
    staticClass: "tag is-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(new Date(), _vm.$userInfo.locale)))]) : _vm._e()])]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (entity, index) {
    return _c("tr", {
      key: entity.messageId,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm.canEditMessage ? _c("router-link", {
      attrs: {
        to: {
          path: entity.messageId
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(entity.messageType) + " ")]) : _c("span", [_vm._v(_vm._s(entity.messageType))])], 1), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.regoNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.claimNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.customerName) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.quoteRequestNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.uid) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.quoteNo) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(entity.vehicleDescription) + " ")]), _c("td", {
      class: {
        "has-text-danger": entity.statusId === _vm.messageStatusTypes.Failed
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatDateTimeLocale(entity.createdDate, _vm.$userInfo.locale)) + " ")]), _c("td", {
      staticClass: "is-content-width"
    }, [_c("div", {
      staticClass: "has-text-centered"
    }, [_vm.canEditMessage ? _c("router-link", {
      staticClass: "button is-primary is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        to: {
          path: entity.messageId
        },
        "data-tooltip": "View/Edit XML",
        append: ""
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])]) : _vm._e(), _vm.canLoadMessage ? _c("a", {
      staticClass: "button is-success is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Load Message"
      },
      on: {
        click: function click($event) {
          return _vm.load(index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-download mdi-24px"
    })])]) : _vm._e(), _vm.canMarkMessageRead ? _c("a", {
      staticClass: "button is-info is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Mark as Read"
      },
      on: {
        click: function click($event) {
          return _vm.showMessageActionConfirmModal(entity.messageId, _vm.messageStatusTypes.Read);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-email-open mdi-24px"
    })])]) : _vm._e(), _vm.canPrintMessage(entity.messageTypeId) ? _c("a", {
      staticClass: "button is-black is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Print Message"
      },
      on: {
        click: function click($event) {
          return _vm.print(entity.messageId, entity.messageTypeId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-printer mdi-24px"
    })])]) : _vm._e(), _vm.canMarkMessageUnread ? _c("a", {
      staticClass: "button is-info is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Mark as Unread"
      },
      on: {
        click: function click($event) {
          return _vm.markMessageAsUnread(entity.messageId);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-email mdi-24px"
    })])]) : _vm._e(), _vm.canResendMessage(entity.statusId) ? _c("a", {
      staticClass: "button is-link is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Resend Message"
      },
      on: {
        click: function click($event) {
          return _vm.markMessageAsToSend(entity.messageId);
        }
      }
    }, [_vm._v("> "), _c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-send mdi-24px"
    })])]) : _vm._e(), _vm.canDeleteMessage ? _c("a", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Delete Message"
      },
      on: {
        click: function click($event) {
          return _vm.showMessageActionConfirmModal(entity.messageId, _vm.messageStatusTypes.Deleted);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])]) : _vm._e(), _vm.canUndeleteMessage ? _c("a", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": [entity.messageDirection === 0 ? "Restore to Read" : "Restore to Sent"]
      },
      on: {
        click: function click($event) {
          return _vm.unDeleteMessage(entity.messageId, entity.messageDirection);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-delete-restore mdi-24px"
    })])]) : _vm._e()], 1)])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])]), _c("load-quote-modal", {
    attrs: {
      active: _vm.isLoadQuoteModalActive,
      "show-icon": false,
      "previous-disabled": _vm.currentStep === _vm.steps.CreateAssign.id,
      "next-disabled": _vm.currentStep === _vm.lastStep.id || !_vm.enableLoadQuoteNext,
      "continue-disabled": !_vm.enableContinue
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isLoadQuoteModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      previous: function previous($event) {
        return _vm.previous();
      },
      next: function next($event) {
        return _vm.next();
      },
      load: function load($event) {
        return _vm.loadMessage();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("PNET Load Quote")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("load-quote-steps", {
    attrs: {
      "current-step": _vm.currentStep,
      steps: _vm.steps,
      "ecom-type": "pnet"
    },
    model: {
      value: _vm.loadOptions,
      callback: function callback($$v) {
        _vm.loadOptions = $$v;
      },
      expression: "loadOptions"
    }
  })], 1)]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.gotoQuote(true);
      },
      cancel: function cancel($event) {
        return _vm.gotoQuote(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Go to Quote")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.savedLoadOptions && _vm.savedLoadOptions.isCreateQuote && _vm.savedLoadOptions.messageTypeId === _vm.messageTypes.QREQ ? _c("span", [_vm._v("Quote created")]) : _vm.savedLoadOptions && !_vm.savedLoadOptions.isCreateQuote && _vm.savedLoadOptions.messageTypeId === _vm.messageTypes.QREQ ? _c("span", [_vm._v("Quote assigned")]) : _c("span", [_vm._v("Message loaded")]), _vm._v(" successfully. Go to quote "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.quoteNo)))]), _vm._v(" now? ")])]), _c("confirm-modal", {
    attrs: {
      active: _vm.isMessageOperationConfirmModalActive,
      "ok-text": "Yes"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isMessageOperationConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.changeMessageStatus(_vm.selectedMessageId, _vm.messageOperationTypeId);
      },
      cancel: function cancel($event) {
        _vm.isMessageOperationConfirmModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("PNET Message")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", [_vm._v("Message will be moved to")]), _c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v(" " + _vm._s(_vm.getFolderName(_vm.messageOperationTypeId)) + ". ")]), _c("br"), _c("span", [_vm._v("Are you sure?")])])])], 1) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-email mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-email-open mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-send mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-checkbox-marked-circle mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.is-uppercase[data-v-33b6a5af] {\n  text-transform: uppercase;\n}\ninput.is-uppercase[data-v-33b6a5af]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-33b6a5af]::-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-33b6a5af]:-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-33b6a5af]:-ms-input-placeholder {\n  text-transform: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4488c005", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListSideMenu.vue":
/*!***********************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListSideMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true */ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true");
/* harmony import */ var _PnetMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PnetMessageListSideMenu.vue?vue&type=script&lang=js */ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true */ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _PnetMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "33b6a5af",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/pnetmessage/PnetMessageListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=style&index=0&id=33b6a5af&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_style_index_0_id_33b6a5af_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListSideMenu.vue?vue&type=template&id=33b6a5af&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListSideMenu_vue_vue_type_template_id_33b6a5af_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListView.vue":
/*!*******************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListView.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PnetMessageListView.vue?vue&type=template&id=e5d97404 */ "./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404");
/* harmony import */ var _PnetMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PnetMessageListView.vue?vue&type=script&lang=js */ "./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _PnetMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__["render"],
  _PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/pnetmessage/PnetMessageListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404":
/*!*************************************************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404 ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./PnetMessageListView.vue?vue&type=template&id=e5d97404 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/pnetmessage/PnetMessageListView.vue?vue&type=template&id=e5d97404");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PnetMessageListView_vue_vue_type_template_id_e5d97404__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/pnetmessage/PnetMessageValidation.js":
/*!********************************************************!*\
  !*** ./src/views/pnetmessage/PnetMessageValidation.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    loadOptions: {
      quoteId: {
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      },
      insurerId: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      },
      invoiceDate: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
      },
      customerId: {
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_1__["guidValidator"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/pnetmessage/storeMixin.js":
/*!*********************************************!*\
  !*** ./src/views/pnetmessage/storeMixin.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'pnetmessages';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    messageSummary: 'messageSummary'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setMessageSummary', 'clearMessageSummary']))
});

/***/ })

}]);
//# sourceMappingURL=pnetmessagelist-chunk.js.map