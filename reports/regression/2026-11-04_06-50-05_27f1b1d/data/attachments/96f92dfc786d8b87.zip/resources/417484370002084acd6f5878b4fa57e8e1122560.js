(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ormmessageview-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/VueCodemirror */ "./src/components/VueCodemirror/index.js");
/* harmony import */ var codemirror_mode_xml_xml_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! codemirror/mode/xml/xml.js */ "./node_modules/codemirror/mode/xml/xml.js");
/* harmony import */ var codemirror_mode_xml_xml_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(codemirror_mode_xml_xml_js__WEBPACK_IMPORTED_MODULE_1__);

// language js

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageDetail',
  components: {
    codemirror: _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_0__["codemirror"]
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    options: null
  },
  data: function data() {
    return {
      code: '',
      editorWidth: 400
    };
  },
  computed: {},
  watch: {
    code: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {},
  mounted: function mounted() {
    this.code = this.value;
    // this.editorWidth = document.getElementById('container').clientWidth - 40
    // this.$nextTick(function() {
    //   window.addEventListener('resize', this.resizeEditor)
    // })
  },
  methods: {
    onCmReady: function onCmReady(cm) {
      console.log('the editor is readied!', cm);
    },
    onCmFocus: function onCmFocus(cm) {
      console.log('the editor is focus!', cm);
    },
    onCmCodeChange: function onCmCodeChange(newCode) {
      console.log('this is new code', newCode);
      this.code = newCode;
    } // resizeEditor() {
    //   this.editorWidth = document.getElementById('container').clientWidth - 40
    // }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _OrmMessageViewSideMenu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./OrmMessageViewSideMenu */ "./src/views/ormmessage/OrmMessageViewSideMenu.vue");
/* harmony import */ var _OrmMessageDetail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./OrmMessageDetail */ "./src/views/ormmessage/OrmMessageDetail.vue");
/* harmony import */ var _OrmMessageService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./OrmMessageService */ "./src/views/ormmessage/OrmMessageService.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./route-types */ "./src/views/ormmessage/route-types.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_route_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storeMixin */ "./src/views/ormmessage/storeMixin.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__);














/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_4__["default"],
    OrmMessageViewSideMenu: _OrmMessageViewSideMenu__WEBPACK_IMPORTED_MODULE_5__["default"],
    OrmMessageDetail: _OrmMessageDetail__WEBPACK_IMPORTED_MODULE_6__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["UnsavedModal"],
    SaveConflictModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_10__["SaveConflictModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_9__["default"]],
  props: {},
  data: function data() {
    return {
      entity: null,
      showEditor: true,
      options: {
        tabSize: 4,
        styleActiveLine: true,
        lineNumbers: true,
        autoCloseTags: true,
        foldGutter: true,
        gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        highlightSelectionMatches: {
          showToken: /\w/,
          annotateScrollbar: true
        },
        line: true,
        matchBrackets: true,
        showCursorWhenSelecting: true,
        lineSeparator: '\n',
        lineWrapping: true,
        mode: 'application/xml',
        theme: 'default'
      },
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      isConfirmModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null
    };
  },
  computed: {},
  watch: {
    'options.theme': {
      handler: function handler(newVal, oldVal) {
        this.showEditor = false;
        this.$nextTick(function () {
          this.showEditor = true;
        });
      },
      deep: true
    },
    '$theme.isDark': function $themeIsDark(newVal) {
      this.options.theme = newVal ? 'blackboard' : 'default';
    }
  },
  beforeCreate: function beforeCreate() {
    if (this.$route.path == '/ormmessages/new') {
      this.$router.push('/ormmessages');
    }
  },
  created: function created() {
    this.getEntity();
    // if (this.$userInfo.codemirrorTheme) {
    //   this.options.theme = this.$userInfo.codemirrorTheme
    // }
    this.options.theme = this.$theme.isDark ? 'blackboard' : 'default';
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Delete:
          this.isConfirmModalActive = true;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, id;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _this.$showSpinner();
              id = _this.$route.params.messageId;
              if (reset) {
                _this.clearSnapshots(id);
              }
              if (_this.currentSnapshot) {
                _context.n = 1;
                break;
              }
              _context.n = 1;
              return _this.getStoreItem(id);
            case 1:
              _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this.currentSnapshot);
              _this.$hideSpinner();
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        console.log(this.snapshotDiff);
        this.isUnsavedModalActive = true;
      } else {
        if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_8___default.a.OrmMessageListView.name
          });
        }
      }
    },
    save: function save() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var responseStatus, title, response, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              title = 'Orm Message';
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity));
              if (!_this2.snapshotDiff) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _OrmMessageService__WEBPACK_IMPORTED_MODULE_7__["default"].putEntity(_this2.entity, _this2.snapshotDiff);
            case 2:
              response = _context2.v;
              _context2.n = 4;
              break;
            case 3:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 4:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_12__["default"].NO_CONTENT)) {
                _context2.n = 6;
                break;
              }
              _context2.n = 5;
              return _this2.getEntity(true);
            case 5:
              _this2.$notification.openNotificationWithType('success', title, 'Save successful');
            case 6:
              responseStatus = true;
              _context2.n = 8;
              break;
            case 7:
              _context2.p = 7;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('ORM Message', _t);
              responseStatus = false;
            case 8:
              _context2.p = 8;
              _this2.$hideSpinner();
              return _context2.f(8);
            case 9:
              return _context2.a(2, responseStatus);
          }
        }, _callee2, null, [[1, 7, 8, 9]]);
      }))();
    },
    saveContinue: function saveContinue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isUnsavedModalActive = false;
              _this3.isSaveContinue = true;
              _context3.n = 1;
              return _this3.save();
            case 1:
              _this3.isSaveContinue = _context3.v;
              if (_this3.isSaveContinue) {
                _this3.cancel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveConflictModalActive = false;
      this.isSaveContinue = false;
    },
    reloadData: function reloadData() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isSaveConflictModalActive = false;
              _this4.isSaveContinue = false;
              _context4.n = 1;
              return _this4.getEntity(true);
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    }
  },
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5(to, from, next) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
        while (1) switch (_context5.n) {
          case 0:
            if (this.entity) {
              this.clearSnapshots(this.entity.messageId);
            }
            next();
          case 1:
            return _context5.a(2);
        }
      }, _callee5, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/VueCodemirror */ "./src/components/VueCodemirror/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageViewSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    value: null,
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      themes: null,
      innerValue: null
    };
  },
  computed: {},
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    'innerValue.theme': function innerValueTheme(newVal, oldVal) {
      this.$setCodemirrorTheme(newVal);
    }
  },
  created: function created() {
    this.themes = _components_VueCodemirror__WEBPACK_IMPORTED_MODULE_1__["CodemirrorThemes"];
    this.innerValue = this.value;
  },
  mounted: function mounted() {},
  methods: {
    toggleLineWrapping: function toggleLineWrapping() {
      this.innerValue.lineWrapping = !this.innerValue.lineWrapping;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("article", {
    staticClass: "box",
    attrs: {
      id: "container"
    }
  }, [_c("div", {
    staticClass: "orm-codemirror"
  }, [_c("codemirror", {
    attrs: {
      options: _vm.options,
      width: _vm.editorWidth
    },
    model: {
      value: _vm.code,
      callback: function callback($$v) {
        _vm.code = $$v;
      },
      expression: "code"
    }
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": _vm.entity !== null
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.options ? _c("orm-message-view-side-menu", {
    attrs: {
      "entity-name": _vm.messageSummary.regoNo
    },
    model: {
      value: _vm.options,
      callback: function callback($$v) {
        _vm.options = $$v;
      },
      expression: "options"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column m-3"
  }, [_vm.options && _vm.showEditor && _vm.entity ? _c("orm-message-detail", {
    attrs: {
      options: _vm.options
    },
    model: {
      value: _vm.entity.messageData,
      callback: function callback($$v) {
        _vm.$set(_vm.entity, "messageData", $$v);
      },
      expression: "entity.messageData"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("save-conflict-modal", {
    attrs: {
      active: _vm.isSaveConflictModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSaveConflictModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      reload: function reload($event) {
        return _vm.reloadData();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Change conflict")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("The data on the server is newer than the local copy. Please reload local data.")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Rego: " + _vm._s(_vm.entityName) + " ")])]), _vm.innerValue ? _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Theme")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.theme,
      expression: "innerValue.theme"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "theme", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.themes, function (theme, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: theme
      }
    }, [_vm._v(_vm._s(theme))]);
  }), 0)])])]), _c("span", {
    staticClass: "buttons has-addons"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success": _vm.innerValue.lineWrapping
    },
    on: {
      click: _vm.toggleLineWrapping
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-wrap"
  })]), _c("span", [_vm._v("Wrap")])])])])]) : _vm._e()])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".orm-codemirror {\n  height: calc(100vh - 170px);\n  width: 100%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("aed4a746", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageDetail.vue":
/*!***************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageDetail.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmMessageDetail.vue?vue&type=template&id=4d005a56 */ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56");
/* harmony import */ var _OrmMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmMessageDetail.vue?vue&type=script&lang=js */ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss */ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormmessage/OrmMessageDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss":
/*!************************************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=style&index=0&id=4d005a56&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_style_index_0_id_4d005a56_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56":
/*!*********************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageDetail.vue?vue&type=template&id=4d005a56 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageDetail.vue?vue&type=template&id=4d005a56");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageDetail_vue_vue_type_template_id_4d005a56__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormmessage/OrmMessageView.vue":
/*!*************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageView.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmMessageView.vue?vue&type=template&id=b2056c2c */ "./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c");
/* harmony import */ var _OrmMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmMessageView.vue?vue&type=script&lang=js */ "./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormmessage/OrmMessageView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c":
/*!*******************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageView.vue?vue&type=template&id=b2056c2c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageView.vue?vue&type=template&id=b2056c2c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageView_vue_vue_type_template_id_b2056c2c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormmessage/OrmMessageViewSideMenu.vue":
/*!*********************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageViewSideMenu.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740 */ "./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740");
/* harmony import */ var _OrmMessageViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmMessageViewSideMenu.vue?vue&type=script&lang=js */ "./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmMessageViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormmessage/OrmMessageViewSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageViewSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740":
/*!***************************************************************************************!*\
  !*** ./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740 ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormmessage/OrmMessageViewSideMenu.vue?vue&type=template&id=cfa51740");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmMessageViewSideMenu_vue_vue_type_template_id_cfa51740__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormmessage/storeMixin.js":
/*!********************************************!*\
  !*** ./src/views/ormmessage/storeMixin.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'ormmessages';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    messageSummary: 'messageSummary'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setMessageSummary', 'clearMessageSummary']))
});

/***/ })

}]);
//# sourceMappingURL=ormmessageview-chunk.js.map