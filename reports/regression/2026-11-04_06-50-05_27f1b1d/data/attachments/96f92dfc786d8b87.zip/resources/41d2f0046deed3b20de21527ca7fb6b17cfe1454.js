(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vehiclelist-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _components_BulmaRadio__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/BulmaRadio */ "./src/components/BulmaRadio/index.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"],
    BulmaRadioButton: _components_BulmaRadio__WEBPACK_IMPORTED_MODULE_1__["BulmaRadioButton"]
  },
  props: {
    value: Object
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  methods: {
    filter: function filter() {
      this.$emit('filter');
    },
    reset: function reset() {
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _VehicleService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./VehicleService */ "./src/views/vehicle/VehicleService.js");
/* harmony import */ var _VehicleListSideMenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./VehicleListSideMenu */ "./src/views/vehicle/VehicleListSideMenu.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./columns */ "./src/views/vehicle/columns.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./storeMixin */ "./src/views/vehicle/storeMixin.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! lodash/transform */ "./node_modules/lodash/transform.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(lodash_transform__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");


























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VehicleListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_13__["default"],
    VehicleListSideMenu: _VehicleListSideMenu__WEBPACK_IMPORTED_MODULE_15__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_17__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_21__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_19__["NumberFiltersMixin"]],
  data: function data() {
    return {
      entitySummaries: {},
      totalRows: 0,
      filter: {
        rego: '',
        make: '',
        model: '',
        customer: '',
        active: 1,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_18__["default"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_18__["default"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      },
      toggle: true,
      selectedRow: null,
      isTableLoading: false
    };
  },
  computed: {
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_18__["default"];
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _this.getData();
          case 1:
            _this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_16__["EventHubTypes"].ToggleSideMenu, function (data) {
              _this.toggle = false;
              setTimeout(function () {
                _this.toggle = true;
              }, 200);
            });
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_16__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    resetList: function resetList() {
      this.filter = {
        rego: '',
        make: '',
        model: '',
        customer: '',
        active: 1,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_18__["default"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_18__["default"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      };
      this.persistFilter();
      this.getData();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    serialiseFilter: function serialiseFilter() {
      var entityProto = __webpack_require__(/*! ../../assets/proto/vehicle/VehicleFilter.proto */ "./src/assets/proto/vehicle/VehicleFilter.proto");
      var filterMessage = entityProto.VehicleFilter.VehicleFilter;
      var buffer = filterMessage.encode(this.filter).finish();
      var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_20___default.a.util.base64.encode(buffer, 0, buffer.length);
      return b64encoded;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getData();
    },
    getData: function getData() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isTableLoading = true;
              _this2.retrieveFilter();
              _context2.n = 1;
              return _VehicleService__WEBPACK_IMPORTED_MODULE_14__["default"].getEntitySummaries(_this2.serialiseFilter());
            case 1:
              _this2.entitySummaries = _context2.v;
              _this2.totalRows = _this2.entitySummaries.length > 0 ? _this2.entitySummaries[0].totalRows : 0;
              _this2.isTableLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    addNew: function addNew() {
      this.addStoreItem();
    },
    print: function print() {
      var params = Object.assign({
        companyId: this.$userInfo.companyId
      }, this.filter);
      params.sortColumn = this.filter.sortColumn.toUpperCase();
      params.pageIndex = 1;
      params.pageSize = this.totalRows;
      params = lodash_transform__WEBPACK_IMPORTED_MODULE_24___default()(params, function (result, value, key) {
        result[key.toLowerCase().replace('rego', 'regonumber').replace('sortorder', 'sortdirection')] = value;
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_25__["Emailer"]();
      emailer.subject = 'Vehicle List Report';
      emailer.reportName = 'rptTablesCar';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);




var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.rego,
      expression: "value.rego"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Rego"
    },
    domProps: {
      value: _vm.value.rego
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.filter();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "rego", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.make,
      expression: "value.make"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Make"
    },
    domProps: {
      value: _vm.value.make
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.filter();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "make", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.model,
      expression: "value.model"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Model"
    },
    domProps: {
      value: _vm.value.model
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.filter();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "model", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.customer,
      expression: "value.customer"
    }],
    staticClass: "input is-capitalized",
    attrs: {
      type: "text",
      placeholder: "Customer"
    },
    domProps: {
      value: _vm.value.customer
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.filter();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "customer", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("bulma-radio-button", {
    attrs: {
      "native-value": 0
    },
    model: {
      value: _vm.value.active,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "active", $$v);
      },
      expression: "value.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-adjust"
  })]), _vm._v(" Both ")]), _c("bulma-radio-button", {
    attrs: {
      type: "is-success",
      "native-value": 1
    },
    model: {
      value: _vm.value.active,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "active", $$v);
      },
      expression: "value.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]), _vm._v(" Active ")]), _c("bulma-radio-button", {
    attrs: {
      type: "is-danger",
      "native-value": 2
    },
    model: {
      value: _vm.value.active,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "active", $$v);
      },
      expression: "value.active"
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]), _vm._v(" In-Active ")])], 1)])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: function click($event) {
        return _vm.filter();
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        return _vm.reset();
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96 ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("vehicle-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (c, idx) {
    return _c("tr", {
      key: c.id,
      class: {
        "is-selected": _vm.selectedRow === idx
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(idx, $event);
        }
      }
    }, [_c("td", [_c("router-link", {
      attrs: {
        to: {
          path: c.vehicleID
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(c.rego) + " ")])], 1), _c("td", [_vm._v(_vm._s("".concat(c.make.trim(), " ").concat(c.model.trim())))]), _c("td", [_vm._v(_vm._s(c.customerName))]), _c("td", [c.buildMonth && c.buildYear ? _c("span", [_vm._v(_vm._s(_vm.$filters.pad(c.buildMonth, 2)) + "/" + _vm._s(c.buildYear))]) : _vm._e()]), _c("td", [_vm._v(_vm._s(c.bodyStyle))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(c.paintGroup))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(c.transmissionType))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [c.active ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [c.active ? "mdi-check" : "mdi-close"]
    })])]), _c("td", [_c("router-link", {
      staticClass: "button is-primary is-small is-inverted",
      attrs: {
        to: {
          path: c.vehicleID
        },
        append: ""
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])])], 1)]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/transform.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/transform.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayEach = __webpack_require__(/*! ./_arrayEach */ "./node_modules/lodash/_arrayEach.js"),
    baseCreate = __webpack_require__(/*! ./_baseCreate */ "./node_modules/lodash/_baseCreate.js"),
    baseForOwn = __webpack_require__(/*! ./_baseForOwn */ "./node_modules/lodash/_baseForOwn.js"),
    baseIteratee = __webpack_require__(/*! ./_baseIteratee */ "./node_modules/lodash/_baseIteratee.js"),
    getPrototype = __webpack_require__(/*! ./_getPrototype */ "./node_modules/lodash/_getPrototype.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isFunction = __webpack_require__(/*! ./isFunction */ "./node_modules/lodash/isFunction.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/**
 * An alternative to `_.reduce`; this method transforms `object` to a new
 * `accumulator` object which is the result of running each of its own
 * enumerable string keyed properties thru `iteratee`, with each invocation
 * potentially mutating the `accumulator` object. If `accumulator` is not
 * provided, a new object with the same `[[Prototype]]` will be used. The
 * iteratee is invoked with four arguments: (accumulator, value, key, object).
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @static
 * @memberOf _
 * @since 1.3.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @param {*} [accumulator] The custom accumulator value.
 * @returns {*} Returns the accumulated value.
 * @example
 *
 * _.transform([2, 3, 4], function(result, n) {
 *   result.push(n *= n);
 *   return n % 2 == 0;
 * }, []);
 * // => [4, 9]
 *
 * _.transform({ 'a': 1, 'b': 2, 'c': 1 }, function(result, value, key) {
 *   (result[value] || (result[value] = [])).push(key);
 * }, {});
 * // => { '1': ['a', 'c'], '2': ['b'] }
 */
function transform(object, iteratee, accumulator) {
  var isArr = isArray(object),
      isArrLike = isArr || isBuffer(object) || isTypedArray(object);

  iteratee = baseIteratee(iteratee, 4);
  if (accumulator == null) {
    var Ctor = object && object.constructor;
    if (isArrLike) {
      accumulator = isArr ? new Ctor : [];
    }
    else if (isObject(object)) {
      accumulator = isFunction(Ctor) ? baseCreate(getPrototype(object)) : {};
    }
    else {
      accumulator = {};
    }
  }
  (isArrLike ? arrayEach : baseForOwn)(object, function(value, index, object) {
    return iteratee(accumulator, value, index, object);
  });
  return accumulator;
}

module.exports = transform;


/***/ }),

/***/ "./src/assets/proto/vehicle/VehicleFilter.proto":
/*!******************************************************!*\
  !*** ./src/assets/proto/vehicle/VehicleFilter.proto ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*undefined*/


var $protobuf = __webpack_require__(/*! protobufjs/minimal */ "./node_modules/protobufjs/minimal.js");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.VehicleFilter = (function() {

    /**
     * Namespace VehicleFilter.
     * @exports VehicleFilter
     * @namespace
     */
    var VehicleFilter = {};

    VehicleFilter.VehicleFilter = (function() {

        /**
         * Properties of a VehicleFilter.
         * @memberof VehicleFilter
         * @interface IVehicleFilter
         * @property {string|null} [rego] VehicleFilter rego
         * @property {string|null} [make] VehicleFilter make
         * @property {string|null} [model] VehicleFilter model
         * @property {string|null} [customer] VehicleFilter customer
         * @property {number|null} [active] VehicleFilter active
         * @property {string|null} [sortColumn] VehicleFilter sortColumn
         * @property {string|null} [sortOrder] VehicleFilter sortOrder
         * @property {number|null} [pageIndex] VehicleFilter pageIndex
         * @property {number|null} [pageSize] VehicleFilter pageSize
         */

        /**
         * Constructs a new VehicleFilter.
         * @memberof VehicleFilter
         * @classdesc Represents a VehicleFilter.
         * @implements IVehicleFilter
         * @constructor
         * @param {VehicleFilter.IVehicleFilter=} [p] Properties to set
         */
        function VehicleFilter(p) {
            if (p)
                for (var ks = Object.keys(p), i = 0; i < ks.length; ++i)
                    if (p[ks[i]] != null)
                        this[ks[i]] = p[ks[i]];
        }

        /**
         * VehicleFilter rego.
         * @member {string|null|undefined} rego
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.rego = null;

        /**
         * VehicleFilter make.
         * @member {string|null|undefined} make
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.make = null;

        /**
         * VehicleFilter model.
         * @member {string|null|undefined} model
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.model = null;

        /**
         * VehicleFilter customer.
         * @member {string|null|undefined} customer
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.customer = null;

        /**
         * VehicleFilter active.
         * @member {number|null|undefined} active
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.active = null;

        /**
         * VehicleFilter sortColumn.
         * @member {string|null|undefined} sortColumn
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.sortColumn = null;

        /**
         * VehicleFilter sortOrder.
         * @member {string|null|undefined} sortOrder
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.sortOrder = null;

        /**
         * VehicleFilter pageIndex.
         * @member {number|null|undefined} pageIndex
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.pageIndex = null;

        /**
         * VehicleFilter pageSize.
         * @member {number|null|undefined} pageSize
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        VehicleFilter.prototype.pageSize = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * VehicleFilter _rego.
         * @member {"rego"|undefined} _rego
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_rego", {
            get: $util.oneOfGetter($oneOfFields = ["rego"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _make.
         * @member {"make"|undefined} _make
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_make", {
            get: $util.oneOfGetter($oneOfFields = ["make"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _model.
         * @member {"model"|undefined} _model
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_model", {
            get: $util.oneOfGetter($oneOfFields = ["model"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _customer.
         * @member {"customer"|undefined} _customer
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_customer", {
            get: $util.oneOfGetter($oneOfFields = ["customer"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _active.
         * @member {"active"|undefined} _active
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_active", {
            get: $util.oneOfGetter($oneOfFields = ["active"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _sortColumn.
         * @member {"sortColumn"|undefined} _sortColumn
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_sortColumn", {
            get: $util.oneOfGetter($oneOfFields = ["sortColumn"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _sortOrder.
         * @member {"sortOrder"|undefined} _sortOrder
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_sortOrder", {
            get: $util.oneOfGetter($oneOfFields = ["sortOrder"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _pageIndex.
         * @member {"pageIndex"|undefined} _pageIndex
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_pageIndex", {
            get: $util.oneOfGetter($oneOfFields = ["pageIndex"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * VehicleFilter _pageSize.
         * @member {"pageSize"|undefined} _pageSize
         * @memberof VehicleFilter.VehicleFilter
         * @instance
         */
        Object.defineProperty(VehicleFilter.prototype, "_pageSize", {
            get: $util.oneOfGetter($oneOfFields = ["pageSize"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Encodes the specified VehicleFilter message. Does not implicitly {@link VehicleFilter.VehicleFilter.verify|verify} messages.
         * @function encode
         * @memberof VehicleFilter.VehicleFilter
         * @static
         * @param {VehicleFilter.IVehicleFilter} m VehicleFilter message or plain object to encode
         * @param {$protobuf.Writer} [w] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        VehicleFilter.encode = function encode(m, w) {
            if (!w)
                w = $Writer.create();
            if (m.rego != null && Object.hasOwnProperty.call(m, "rego"))
                w.uint32(10).string(m.rego);
            if (m.make != null && Object.hasOwnProperty.call(m, "make"))
                w.uint32(18).string(m.make);
            if (m.model != null && Object.hasOwnProperty.call(m, "model"))
                w.uint32(26).string(m.model);
            if (m.customer != null && Object.hasOwnProperty.call(m, "customer"))
                w.uint32(34).string(m.customer);
            if (m.active != null && Object.hasOwnProperty.call(m, "active"))
                w.uint32(40).int32(m.active);
            if (m.sortColumn != null && Object.hasOwnProperty.call(m, "sortColumn"))
                w.uint32(50).string(m.sortColumn);
            if (m.sortOrder != null && Object.hasOwnProperty.call(m, "sortOrder"))
                w.uint32(58).string(m.sortOrder);
            if (m.pageIndex != null && Object.hasOwnProperty.call(m, "pageIndex"))
                w.uint32(64).int32(m.pageIndex);
            if (m.pageSize != null && Object.hasOwnProperty.call(m, "pageSize"))
                w.uint32(72).int32(m.pageSize);
            return w;
        };

        /**
         * Encodes the specified VehicleFilter message, length delimited. Does not implicitly {@link VehicleFilter.VehicleFilter.verify|verify} messages.
         * @function encodeDelimited
         * @memberof VehicleFilter.VehicleFilter
         * @static
         * @param {VehicleFilter.IVehicleFilter} message VehicleFilter message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        VehicleFilter.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a VehicleFilter message from the specified reader or buffer.
         * @function decode
         * @memberof VehicleFilter.VehicleFilter
         * @static
         * @param {$protobuf.Reader|Uint8Array} r Reader or buffer to decode from
         * @param {number} [l] Message length if known beforehand
         * @returns {VehicleFilter.VehicleFilter} VehicleFilter
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        VehicleFilter.decode = function decode(r, l) {
            if (!(r instanceof $Reader))
                r = $Reader.create(r);
            var c = l === undefined ? r.len : r.pos + l, m = new $root.VehicleFilter.VehicleFilter();
            while (r.pos < c) {
                var t = r.uint32();
                switch (t >>> 3) {
                case 1:
                    m.rego = r.string();
                    break;
                case 2:
                    m.make = r.string();
                    break;
                case 3:
                    m.model = r.string();
                    break;
                case 4:
                    m.customer = r.string();
                    break;
                case 5:
                    m.active = r.int32();
                    break;
                case 6:
                    m.sortColumn = r.string();
                    break;
                case 7:
                    m.sortOrder = r.string();
                    break;
                case 8:
                    m.pageIndex = r.int32();
                    break;
                case 9:
                    m.pageSize = r.int32();
                    break;
                default:
                    r.skipType(t & 7);
                    break;
                }
            }
            return m;
        };

        /**
         * Decodes a VehicleFilter message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof VehicleFilter.VehicleFilter
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {VehicleFilter.VehicleFilter} VehicleFilter
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        VehicleFilter.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        return VehicleFilter;
    })();

    return VehicleFilter;
})();

module.exports = $root;


/***/ }),

/***/ "./src/components/BulmaRadio/index.js":
/*!********************************************!*\
  !*** ./src/components/BulmaRadio/index.js ***!
  \********************************************/
/*! exports provided: BulmaRadio, BulmaRadioButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaRadio", function() { return BulmaRadio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaRadioButton", function() { return BulmaRadioButton; });
// import BulmaRadio from './BulmaRadio'
// import BulmaRadioGroup from './BulmaRadioGroup'
// import BulmaRadioButton from './BulmaRadioButton'

var BulmaRadio = function BulmaRadio(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaRadio.vue */ "./src/components/BulmaRadio/BulmaRadio.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var BulmaRadioButton = function BulmaRadioButton(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaRadioButton.vue */ "./src/components/BulmaRadio/BulmaRadioButton.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/views/vehicle/VehicleListSideMenu.vue":
/*!***************************************************!*\
  !*** ./src/views/vehicle/VehicleListSideMenu.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleListSideMenu.vue?vue&type=template&id=2425659a */ "./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a");
/* harmony import */ var _VehicleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleListSideMenu.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a":
/*!*********************************************************************************!*\
  !*** ./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleListSideMenu.vue?vue&type=template&id=2425659a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListSideMenu.vue?vue&type=template&id=2425659a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListSideMenu_vue_vue_type_template_id_2425659a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/VehicleListing.vue":
/*!**********************************************!*\
  !*** ./src/views/vehicle/VehicleListing.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VehicleListing.vue?vue&type=template&id=4bf8ef96 */ "./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96");
/* harmony import */ var _VehicleListing_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VehicleListing.vue?vue&type=script&lang=js */ "./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _VehicleListing_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/vehicle/VehicleListing.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListing_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleListing.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListing.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListing_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96":
/*!****************************************************************************!*\
  !*** ./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96 ***!
  \****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VehicleListing.vue?vue&type=template&id=4bf8ef96 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/vehicle/VehicleListing.vue?vue&type=template&id=4bf8ef96");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VehicleListing_vue_vue_type_template_id_4bf8ef96__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/vehicle/columns.js":
/*!**************************************!*\
  !*** ./src/views/vehicle/columns.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'rego', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Make & Model', 'make,model', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Customer', 'customerName', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Built', 'buildYear,buildMonth', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Body Style', 'bodyStyle', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Pt Grp', 'paintGroup', true, 'asc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Trans Type', 'transmissionType', true, 'asc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Active', 'active', true, 'asc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
/* harmony default export */ __webpack_exports__["default"] = (Columns);

/***/ }),

/***/ "./src/views/vehicle/storeMixin.js":
/*!*****************************************!*\
  !*** ./src/views/vehicle/storeMixin.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'vehicles';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])('vehicleOptions', {
    storeBodyShapes: 'bodyShapes',
    storeColours: 'colours',
    storePaintGroups: 'paintGroups'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('vehicleOptions', ['refreshColour'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('customers', {
    setCustomerReturnRoute: 'setReturnRoute',
    editStoreCustomer: 'editStoreItem',
    addStoreCustomer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quotes', {
    setQuoteVehicleCustomer: 'setVehicleCustomer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=vehiclelist-chunk.js.map