(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-other-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SubtitleTotals',
  props: {
    labels: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    totals: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    shows: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  data: function data() {
    return {};
  },
  computed: {},
  created: function created() {},
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _components_SubtitleTotals__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/SubtitleTotals */ "./src/components/SubtitleTotals/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");


















// import _orderBy from 'lodash/orderBy'










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteOtherLabour',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__["default"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__["default"],
    TotalsFloatingWidget: _components__WEBPACK_IMPORTED_MODULE_20__["TotalsFloatingWidget"],
    SupplementaryIcon: _components__WEBPACK_IMPORTED_MODULE_20__["SupplementaryIcon"],
    SubtitleTotals: _components_SubtitleTotals__WEBPACK_IMPORTED_MODULE_26__["default"],
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_25___default.a,
    QuoteItemPresentAsModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__["QuoteItemPresentAsModal"]
  },
  mixins: [_mixins__WEBPACK_IMPORTED_MODULE_23__["QuoteItemValidationMixin"], _mixins__WEBPACK_IMPORTED_MODULE_23__["QuoteOtherLabourMixin"], _mixins__WEBPACK_IMPORTED_MODULE_23__["QuoteAssessmentMixin"]],
  props: {
    value: null,
    nextLineNumber: {
      type: Number,
      default: 0
    },
    vehicle: null,
    readOnlyView: {
      type: Boolean,
      default: false
    },
    audanetLock: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: null,
      // items: null,
      selectedRow: null,
      // totalRows: 0,
      isTableLoading: false,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_16__["OtherLabourColumns"][1].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_16__["OtherLabourColumns"][1].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      isFloatingWidgetActive: true,
      isAvailableItemsActive: false,
      isAvailableItemsMainActive: false,
      addBlankDropdownActive: false,
      isPresentAsModalActive: false,
      selectedItem: null
    };
  },
  computed: {
    columns: function columns() {
      var c = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_columns__WEBPACK_IMPORTED_MODULE_16__["OtherLabourColumns"]);
      if (this.value.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_17__["QuotingMethodTypes"].Dollar) {
        c[5].title = 'Amount';
        c.splice(4, 1);
      } else if (this.value.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_17__["QuotingMethodTypes"].Hour) {
        c[5].title = _columns__WEBPACK_IMPORTED_MODULE_16__["OtherLabourColumns"][5].title;
      }
      c[1].isVisible = this.$userInfo.isSupportUser;
      c[c.length - 2].isVisible = this.$userInfo.isSupportUser;
      return c;
    },
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"];
    },
    activeItems: function activeItems() {
      return this.items;
    },
    totalRows: function totalRows() {
      return this.activeItems.length;
    },
    items: function items() {
      if (this.innerValue) {
        return this.innerValue.others.filter(function (i) {
          return i.itemType !== _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].MECH;
        });
      }
    },
    isNtar: function isNtar() {
      return this.innerValue.labourType === _enums__WEBPACK_IMPORTED_MODULE_17__["LabourTimeTypes"].NTAR || this.innerValue.labourType === _enums__WEBPACK_IMPORTED_MODULE_17__["LabourTimeTypes"].LTAR || this.innerValue.labourType === _enums__WEBPACK_IMPORTED_MODULE_17__["LabourTimeTypes"].eMTA;
    },
    quotingMethodTypes: function quotingMethodTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_17__["QuotingMethodTypes"];
    },
    totalColSpan: function totalColSpan() {
      return this.columns.length - (this.$userInfo.isSupportUser ? 6 : 7);
    },
    isRowDraggable: function isRowDraggable() {
      return !this.innerValue.readOnly && !this.$licenceExpired;
    },
    itemsAssessments: function itemsAssessments() {
      return this.getOtherLabourItemsAssessments();
    },
    nextSupplemetryNo: function nextSupplemetryNo() {
      var nextSuppNo = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.value.quoteAssessments.map(function (i) {
        return i.subQuoteNo;
      }))) + 1;
      return nextSuppNo;
    }
  },
  watch: {
    // value: {
    //   handler: function(newVal, oldVal) {
    //     this.innerValue = newVal
    //     this.filter.sortColumn = ''
    //     this.filter.sortOrder = ''
    //     // this.items = _orderBy(this.innerValue.others.filter(i => !i.deleted), [this.filter.sortColumn], [this.filter.sortOrder])
    //   },
    //   deep: true
    // },
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    this.innerValue = this.value;
    // this.items = _orderBy(this.innerValue.others.filter(i => !i.deleted), [this.filter.sortColumn], [this.filter.sortOrder])
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_17__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = _this.value;
    });
    this.$v.entity.others.$touch();
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_17__["EventHubTypes"].EntitySaved);
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      // this.selectedRow = index
    },
    onPageChange: function onPageChange(pageIndex) {},
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      // this.items = _orderBy(this.innerValue.others.filter(i => !i.deleted), [this.filter.sortColumn], [this.filter.sortOrder])
    },
    updateTotal: function updateTotal() {
      this.isFloatingWidgetActive = true;
    },
    deleteItem: function deleteItem(item, index) {
      var _this2 = this;
      if (this.$licenceExpired) return;
      var originalItemStatus = item.itemStatus;
      if (item.isNew) {
        var itemIndex = this.innerValue.others.map(function (obj) {
          return obj.quoteItemId;
        }).indexOf(item.quoteItemId);
        if (itemIndex >= 0) {
          this.innerValue.others.splice(itemIndex, 1);
          // this.items.splice(itemIndex, 1)
        }
      } else {
        item.deleted = true;
        item.isDeleted = true;
        item.itemStatus = _enums__WEBPACK_IMPORTED_MODULE_17__["QuoteItemStatusTypes"].Deleted;
        item.originalItemStatus = originalItemStatus;
      }
      this.updateTotal();
      this.$toast.open({
        message: "Item <span class=\"is-italic\">".concat(item.itemDesc, "</span> deleted"),
        type: 'is-danger',
        position: 'is-top',
        actionText: 'Undo',
        onAction: function onAction() {
          if (item.isNew) {
            _this2.innerValue.others.splice(_this2.innerValue.others.length, 1, item);
            // this.items.splice(this.items.length, 1, item)
          } else {
            item.deleted = false;
            item.isDeleted = false;
            item.itemStatus = originalItemStatus;
          }
          _this2.updateTotal();
        }
      });
    },
    restoreItem: function restoreItem(item, index) {
      item.deleted = false;
      item.isDeleted = false;
      //TODO: must set item status to original item status
      this.updateTotal();
    },
    toggleAvailableItems: function toggleAvailableItems() {
      this.isAvailableItemsMainActive = false;
      this.isAvailableItemsActive = !this.isAvailableItemsActive;
    },
    toggleAvailableItemsMain: function toggleAvailableItemsMain() {
      this.isAvailableItemsActive = false;
      this.isAvailableItemsMainActive = !this.isAvailableItemsMainActive;
    },
    onItemAdded: function onItemAdded(newItems) {
      this.filter.sortColumn = '';
      this.filter.sortOrder = '';
      if (!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_21___default()(newItems)) {
        var vm = this;
        newItems.forEach(function (item) {
          vm.innerValue.others.splice(vm.innerValue.others.length, 1, item);
        });
        this.innerValue.lines = Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(newItems.map(function (i) {
          return i.lineNumber;
        })).concat([0])) + 1;
        // this.items = _orderBy(this.innerValue.others.filter(i => !i.deleted), [this.filter.sortColumn], [this.filter.sortOrder])
        this.$notification.success('', "Item".concat(newItems.length > 1 ? 's' : '', " added"));
        // this.$toast.open({
        //   message: `Item${newItems.length > 1 ? 's' : ''} added`,
        //   type: 'is-success',
        //   position: 'is-bottom',
        //   queue: false
        // })
      }
    },
    toggleAddBlankMenu: function toggleAddBlankMenu() {
      this.addBlankDropdownActive = !this.addBlankDropdownActive;
    },
    generateItem: function generateItem(itemNo, description, hourValue, rate, type) {
      var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_24__["QuoteItemModel"](this.innerValue.quoteId, itemNo, description, type);
      newItem.lineNumber = this.nextLineNumber;
      newItem.itemNo = itemNo ? itemNo : this.$filters.pad(newItem.lineNumber, 4);
      newItem.hourValue = this.innerValue.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_17__["QuotingMethodTypes"].Hour ? hourValue : Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_19__["roundAwayFromZero"])(hourValue * rate);
      newItem.rate = rate;
      newItem.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_19__["roundAwayFromZero"])(hourValue * rate);
      newItem.opgCode = this.vehicle.paintGroup;
      newItem.sortNo = this.innerValue.others.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.innerValue.others.map(function (i) {
        return i.sortNo;
      }))) + 1 : 1;
      return newItem;
    },
    addBlankItem: function addBlankItem(type) {
      var hour = 0;
      var rate = 0;
      switch (type) {
        case _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].FIBER:
          rate = this.isNtar ? this.innerValue.shopRate : this.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].FIBER, this.innerValue.rates, this.innerValue.shopRate, this.innerValue.quoteId).rate;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].CRUSH:
          rate = this.isNtar ? this.innerValue.shopRate : this.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].CRUSH, this.innerValue.rates, this.innerValue.shopRate, this.innerValue.quoteId).rate;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].CD:
          rate = this.isNtar ? this.innerValue.shopRate : this.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].CD, this.innerValue.rates, this.innerValue.shopRate, this.innerValue.quoteId).rate;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].MECH:
          rate = this.isNtar ? this.innerValue.shopRate : this.getLabourRate(_enums__WEBPACK_IMPORTED_MODULE_17__["ItemCategoryTypes"].MECH, this.innerValue.rates, this.innerValue.shopRate, this.innerValue.quoteId).rate;
          break;
      }
      var newItem = this.generateItem('', '', hour, rate, type);
      this.innerValue.others.splice(this.innerValue.others.length, 1, newItem);
      this.innerValue.lines = this.nextLineNumber + 1;
      this.$notification.success('', 'Item added');
      // this.$toast.open({
      //   message: 'Item added',
      //   type: 'is-success',
      //   position: 'is-bottom',
      //   queue: false
      // })
    },
    itemMoved: function itemMoved(event) {
      if (this.$licenceExpired) return;
      // console.log(event.moved)
      var sortNo = Math.min.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.innerValue.others.map(function (i) {
        return i.sortNo;
      })));
      this.innerValue.others.forEach(function (item) {
        item.sortNo = sortNo;
        sortNo++;
      });
    },
    endMove: function endMove(event) {},
    closeModal: function closeModal() {
      this.isPresentAsModalActive = false;
    },
    showPresentAsModal: function showPresentAsModal(item, index) {
      var _this3 = this;
      if (this.$licenceExpired) return;
      this.selectedItem = item;
      this.$nextTick(function () {
        _this3.isPresentAsModalActive = true;
      });
    },
    getOtherLabourItemsAssessments: function getOtherLabourItemsAssessments() {
      return this.getItemsAssessments(this.items, this.innerValue.quoteAssessments);
    },
    getItemAssessments: function getItemAssessments(item) {
      var itemAssessments = this.itemsAssessments.find(function (i) {
        return i.quoteItemId === item.quoteItemId;
      });
      if (itemAssessments) {
        return itemAssessments.assessments;
      }
      return [];
    },
    canMakeReportOnly: function canMakeReportOnly(item) {
      var assessments = this.getItemAssessments(item);
      if (assessments.length > 0) {
        var lastAssessment = assessments[assessments.length - 1];
        var lastValues = lastAssessment[lastAssessment.length - 1];
        if (!lastValues.reportOnly) {
          return false;
        }
      }
      return true;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "subtitle"
  }, _vm._l(_vm.totals, function (value, index) {
    return _c("span", {
      key: index
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.shows[index],
        expression: "shows[index]"
      }]
    }, [_vm._v(" " + _vm._s(_vm.labels[index]) + ": "), _c("span", {
      class: [value >= 0 ? "has-text-success" : "has-text-danger"]
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(value, _vm.$userInfo.locale)))])]), _c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: index < _vm.totals.length - 1 && _vm.shows[index + 1],
        expression: "index < totals.length - 1 && shows[index + 1]"
      }]
    }, [_vm._v(",")])]);
  }), 0);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-other-labour-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Other Labour")]), _c("subtitle-totals", {
    attrs: {
      labels: ["Other Labour Total", "Grand Total"],
      totals: [_vm.otherTotal, _vm.innerValue.totalExGst],
      shows: [true, true]
    }
  })], 1)]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      draggable: true,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_c("draggable", _vm._b({
    attrs: {
      tag: "tbody",
      handle: ".item-drag-handle"
    },
    on: {
      change: _vm.itemMoved,
      end: _vm.endMove
    },
    model: {
      value: _vm.innerValue.others,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "others", $$v);
      },
      expression: "innerValue.others"
    }
  }, "draggable", {
    disabled: !_vm.isRowDraggable,
    chosen: "chosen",
    ghostClass: "draggable-ghost",
    dragClass: "draggable-drag"
  }, false), _vm._l(_vm.activeItems, function (item, index) {
    return _c("tr", {
      key: item.quoteItemId,
      class: [_vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false), _vm.rowDisplayStatus(item, _vm.getItemAssessments(item))],
      attrs: {
        "data-itemid": item.quoteItemId
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.$userInfo.isSupportUser,
        expression: "$userInfo.isSupportUser"
      }],
      staticClass: "has-vertical-middle has-text-right linenumber-input"
    }, [!_vm.innerValue.readOnly && _vm.$userInfo.isSupportUser && !_vm.readOnlyView && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("vue-numeric", {
      staticClass: "input has-text-right",
      class: _vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false),
      attrs: {
        disabled: _vm.$licenceExpired,
        precision: 0,
        separator: ""
      },
      model: {
        value: item.lineNumber,
        callback: function callback($$v) {
          _vm.$set(item, "lineNumber", _vm._n($$v));
        },
        expression: "item.lineNumber"
      }
    }) : _c("span", [_vm._v(_vm._s(item.lineNumber))])], 1), _c("td", {
      staticClass: "has-vertical-middle itemno-input"
    }, [!item.deleteOtherItem && !_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.itemNo,
        expression: "item.itemNo"
      }],
      staticClass: "input",
      class: [_vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false), !_vm.isValidItemNo(item.quoteItemId) ? "is-danger" : ""],
      attrs: {
        placeholder: "Item No.",
        disabled: _vm.$licenceExpired
      },
      domProps: {
        value: item.itemNo
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "itemNo", $event.target.value);
        }
      }
    }) : _c("span", [_vm._v(_vm._s(item.itemNo))])]), _c("td", {
      staticClass: "has-vertical-middle itemdesc-input"
    }, [!item.deleteOtherItem && !_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.itemDesc,
        expression: "item.itemDesc"
      }],
      staticClass: "input",
      class: [_vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false), !_vm.isValidItemDesc(item.quoteItemId) ? "is-danger" : ""],
      attrs: {
        placeholder: "Item Description",
        disabled: _vm.$licenceExpired
      },
      domProps: {
        value: item.itemDesc
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "itemDesc", $event.target.value);
        }
      }
    }) : _c("span", [_vm._v(_vm._s(item.itemDesc))]), item.itemComment ? _c("div", {
      staticClass: "help is-primary"
    }, [_c("span", {
      staticClass: "has-text-weight-bold"
    }, [_vm._v("Comment: ")]), _c("span", [_vm._v(_vm._s(item.itemComment))])]) : _vm._e()]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered"
    }, [!item.deleteOtherItem && !_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.reportOnly,
        expression: "item.reportOnly"
      }],
      attrs: {
        disabled: !_vm.canMakeReportOnly(item) || _vm.$licenceExpired,
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(item.reportOnly) ? _vm._i(item.reportOnly, null) > -1 : item.reportOnly
      },
      on: {
        change: function change($event) {
          var $$a = item.reportOnly,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(item, "reportOnly", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(item, "reportOnly", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(item, "reportOnly", $$c);
          }
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]) : _c("span", {
      staticClass: "icon has-text-info"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [item.reportOnly ? "mdi-check" : ""]
    })])]), _vm.innerValue.quotingMethod === _vm.quotingMethodTypes.Hour ? _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input",
      class: [{
        tooltip: _vm.isItemInvoiced(item) === true
      }],
      attrs: {
        "data-tooltip": "Item rate is already invoiced!"
      }
    }, [!_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) && !_vm.isItemInvoiced(item) ? _c("vue-numeric", {
      staticClass: "input has-text-right",
      class: [_vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false), item.rate !== _vm.findLabourRate(item.itemType, _vm.innerValue.rates, _vm.innerValue.shopRate).rate ? "is-warning" : ""],
      attrs: {
        disabled: _vm.$licenceExpired,
        precision: 2
      },
      on: {
        "value-changed": function valueChanged($event) {
          return _vm.updateValue(index, item);
        }
      },
      model: {
        value: item.rate,
        callback: function callback($$v) {
          _vm.$set(item, "rate", _vm._n($$v));
        },
        expression: "item.rate"
      }
    }) : _c("span", [_vm._v(_vm._s(_vm.$filters.formatNumber(item.rate, _vm.$userInfo.locale)))])], 1) : _vm._e(), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input"
    }, [!_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("vue-numeric", {
      staticClass: "input has-text-right",
      class: _vm.defaultRowColourClass(item, _vm.getItemAssessments(item), false),
      attrs: {
        disabled: _vm.$licenceExpired,
        minus: _vm.innerValue.subQuoteNo !== 0,
        precision: 2
      },
      on: {
        input: function input($event) {
          return _vm.updateValue(index, item);
        }
      },
      model: {
        value: item.hourValue,
        callback: function callback($$v) {
          _vm.$set(item, "hourValue", _vm._n($$v));
        },
        expression: "item.hourValue"
      }
    }) : _c("span", [_vm._v(_vm._s(_vm.$filters.formatNumber(item.hourValue, _vm.$userInfo.locale)))])], 1), _c("td", {
      staticClass: "has-vertical-middle has-text-right"
    }, [_c("div", [_vm._v(_vm._s(_vm.$filters.formatNumber(item.dollarValue, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.itemType))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered"
    }, [item.presentAs ? _c("div", _vm._l(item.presentAs, function (split) {
      return _c("div", {
        key: split.itemType
      }, [_c("div", {
        staticClass: "tags has-addons mb-0 present-as-tags"
      }, [_c("span", {
        class: "tag mb-1 is-".concat(split.itemType.toLowerCase())
      }, [_vm._v(_vm._s(split.itemType))]), _c("span", {
        staticClass: "tag is-dark mb-1"
      }, [_vm._v(_vm._s(split.percent) + "%")])])]);
    }), 0) : _vm._e()]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.$userInfo.isSupportUser,
        expression: "$userInfo.isSupportUser"
      }],
      staticClass: "has-vertical-middle itemstatus-input"
    }, [!_vm.innerValue.readOnly && !_vm.readOnlyView && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.itemStatus,
        expression: "item.itemStatus"
      }],
      staticClass: "input is-capitalized",
      attrs: {
        disabled: _vm.$licenceExpired
      },
      domProps: {
        value: item.itemStatus
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "itemStatus", $event.target.value);
        }
      }
    }) : _c("span", [_vm._v(_vm._s(item.itemStatus))])]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("div", {
      staticClass: "icon-container items-center"
    }, [_vm.innerValue.quoteAssessments.length > 0 ? _c("supplementary-icon", {
      staticClass: "icon",
      attrs: {
        item: item,
        "item-assessments": _vm.getItemAssessments(item),
        "next-assessment-number": _vm.nextSupplemetryNo,
        "quoting-method": _vm.innerValue.quotingMethod,
        "icon-size": 4
      }
    }) : _vm._e(), !_vm.audanetLock && !_vm.isItemRemoved(item, _vm.getItemAssessments(item)) && (item.isDeleted === false || item.deleted === false) ? _c("button", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-left",
      attrs: {
        disabled: _vm.innerValue.readOnly || _vm.readOnlyView || _vm.isItemRemoved(item, _vm.getItemAssessments(item)) || _vm.$licenceExpired,
        "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Delete"
      },
      on: {
        click: function click($event) {
          return _vm.deleteItem(item, index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-small"
    }, [_c("i", {
      staticClass: "mdi mdi-delete mdi-24px"
    })])]) : _vm._e(), _c("button", {
      staticClass: "button has-background-primary-45 is-small is-inverted tooltip",
      attrs: {
        disabled: _vm.isItemRemoved(item, _vm.getItemAssessments(item)) || _vm.$licenceExpired,
        "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Present As"
      },
      on: {
        click: function click($event) {
          return _vm.showPresentAsModal(item, index);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-small"
    }, [_c("i", {
      staticClass: "mdi mdi-format-page-split mdi-24px"
    })])]), _c("button", {
      staticClass: "button is-primary is-small is-inverted item-drag-handle pr-0 pl-1",
      class: {
        "tooltip is-tooltip-left": _vm.$licenceExpired
      },
      attrs: {
        "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : null,
        disabled: _vm.innerValue.readOnly || _vm.readOnlyView || _vm.$licenceExpired
      }
    }, [_c("span", {
      staticClass: "icon is-small"
    }, [_c("i", {
      staticClass: "mdi mdi-drag-vertical mdi-24px"
    })])])], 1)])]);
  }), 0), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])]), _c("template", {
    slot: "footer"
  }, [_c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: _vm.totalColSpan
    }
  }, [_vm._v("Mech")]), _c("th", {
    staticClass: "has-text-right",
    class: {
      "has-text-danger": _vm.mechTotal < 0
    }
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.mechTotal, _vm.$userInfo.locale)))]), _c("th", {
    attrs: {
      colspan: "100%"
    }
  })]), _c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: _vm.totalColSpan
    }
  }, [_vm._v("CD")]), _c("th", {
    staticClass: "has-text-right",
    class: {
      "has-text-danger": _vm.cdTotal < 0
    }
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.cdTotal, _vm.$userInfo.locale)))]), _c("th", {
    attrs: {
      colspan: "100%"
    }
  })]), _c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: _vm.totalColSpan
    }
  }, [_vm._v("Crush")]), _c("th", {
    staticClass: "has-text-right",
    class: {
      "has-text-danger": _vm.crushTotal < 0
    }
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.crushTotal, _vm.$userInfo.locale)))]), _c("th", {
    attrs: {
      colspan: "100%"
    }
  })]), _c("tr", [_c("th", {
    staticClass: "has-text-right",
    attrs: {
      colspan: _vm.totalColSpan
    }
  }, [_vm._v("FG")]), _c("th", {
    staticClass: "has-text-right",
    class: {
      "has-text-danger": _vm.fgTotal < 0
    }
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.fgTotal, _vm.$userInfo.locale)))]), _c("th", {
    attrs: {
      colspan: "100%"
    }
  })]), _c("tr", [_c("th", {
    staticClass: "has-text-right has-text-success",
    attrs: {
      colspan: _vm.totalColSpan
    }
  }, [_vm._v("Totals")]), _c("th", {
    staticClass: "has-text-right has-text-success",
    class: [_vm.otherTotal >= 0 ? "has-text-success" : "has-text-danger"]
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.otherTotal, _vm.$userInfo.locale)))]), _c("th", {
    attrs: {
      colspan: "100%"
    }
  })])])], 2), _c("totals-floating-widget", {
    attrs: {
      active: _vm.isFloatingWidgetActive,
      title: "Other Labour Totals",
      "mech-total": _vm.mechTotal,
      "cd-total": _vm.cdTotal,
      "crush-total": _vm.crushTotal,
      "fg-total": _vm.fgTotal,
      totals: _vm.otherTotal,
      "total-ex-gst": _vm.innerValue.totalExGst
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isFloatingWidgetActive = $event;
      }
    }
  })], 1)])])]), _vm.isPresentAsModalActive ? _c("quote-item-present-as-modal", {
    attrs: {
      active: _vm.isPresentAsModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPresentAsModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.closeModal();
      },
      cancel: function cancel($event) {
        return _vm.closeModal();
      },
      close: function close($event) {
        return _vm.closeModal();
      }
    },
    model: {
      value: _vm.selectedItem.presentAs,
      callback: function callback($$v) {
        _vm.$set(_vm.selectedItem, "presentAs", $$v);
      },
      expression: "selectedItem.presentAs"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Present As")])]) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-other-labour-licence-expired td:has(> input:disabled),\n.quote-other-labour-licence-expired .pretty:has(> input:disabled) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-other-labour-licence-expired td:has(> input:disabled):hover::before,\n.quote-other-labour-licence-expired .pretty:has(> input:disabled):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  left: 0;\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-other-labour-licence-expired td > input:disabled {\n  cursor: not-allowed;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".linenumber-input[data-v-7b5b8ec0] {\n  width: 60px;\n}\n.itemno-input[data-v-7b5b8ec0] {\n  max-width: 2.5em;\n}\n.itemdesc-input[data-v-7b5b8ec0] {\n  min-width: 20em;\n}\n.money-input[data-v-7b5b8ec0] {\n  max-width: 6.5em;\n}\ntfoot tr th[data-v-7b5b8ec0]:not(:last-child) {\n  border-right: none;\n}\ntfoot tr:not(:last-child) th[data-v-7b5b8ec0] {\n  border-top: none;\n  border-bottom: none;\n}\n.itemstatus-input[data-v-7b5b8ec0] {\n  width: 50px;\n}\n.item-type-tag[data-v-7b5b8ec0] {\n  width: 52px;\n}\n.present-as-tags[data-v-7b5b8ec0] {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n}\n.present-as-tags .tag[data-v-7b5b8ec0] {\n  font-size: 0.6rem !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("c27315ee", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("9394719a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue":
/*!**********************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubtitleTotals.vue?vue&type=template&id=25fd27af */ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af");
/* harmony import */ var _SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SubtitleTotals.vue?vue&type=script&lang=js */ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/SubtitleTotals/SubtitleTotals.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js":
/*!**********************************************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SubtitleTotals.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af":
/*!****************************************************************************************!*\
  !*** ./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SubtitleTotals.vue?vue&type=template&id=25fd27af */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/SubtitleTotals/SubtitleTotals.vue?vue&type=template&id=25fd27af");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SubtitleTotals_vue_vue_type_template_id_25fd27af__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/SubtitleTotals/index.js":
/*!************************************************!*\
  !*** ./src/components/SubtitleTotals/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SubtitleTotals__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubtitleTotals */ "./src/components/SubtitleTotals/SubtitleTotals.vue");

/* harmony default export */ __webpack_exports__["default"] = (_SubtitleTotals__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./src/views/quote/QuoteOtherLabour.vue":
/*!**********************************************!*\
  !*** ./src/views/quote/QuoteOtherLabour.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true */ "./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true");
/* harmony import */ var _QuoteOtherLabour_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteOtherLabour.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss */ "./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss");
/* harmony import */ var _QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true */ "./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteOtherLabour_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7b5b8ec0",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteOtherLabour.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss":
/*!*******************************************************************************************!*\
  !*** ./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=0&id=7b5b8ec0&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_0_id_7b5b8ec0_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true":
/*!*******************************************************************************************************!*\
  !*** ./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=style&index=1&id=7b5b8ec0&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_style_index_1_id_7b5b8ec0_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true":
/*!****************************************************************************************!*\
  !*** ./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteOtherLabour.vue?vue&type=template&id=7b5b8ec0&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteOtherLabour_vue_vue_type_template_id_7b5b8ec0_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-other-chunk.js.map