(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["salesanalysislist-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _SalesAnalysisService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./SalesAnalysisService */ "./src/views/salesanalysis/SalesAnalysisService.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SalesAnalysisListSideMenu',
  inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_10__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_15___default.a
  },
  directives: {
    mask: vue_the_mask__WEBPACK_IMPORTED_MODULE_12__["mask"]
  },
  mixins: [],
  props: {
    value: null
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.value),
      selectDateType: 'selectDates',
      stateList: null,
      selectedFromDate: null,
      selectedToDate: null,
      isClientLoading: false,
      selectedClient: null,
      clients: [],
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      clientFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_14__["default"].empty(),
        assetName: '',
        showCustomer: true,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  },
  watch: {
    selectedFromDate: function selectedFromDate(newVal, oldVal) {
      if (newVal) {
        this.selectDateType = 'selectDates';
        this.innerValue.dateFrom = this.selectedFromDate.toISOString();
      } else {
        this.innerValue.dateFrom = '';
      }
    },
    selectedToDate: function selectedToDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.dateTo = this.selectedToDate.toISOString();
      } else {
        this.innerValue.dateTo = '';
      }
    },
    'innerValue.selectDateType': function innerValueSelectDateType(newVal, oldVal) {
      // if (newVal === 'selectDates') {
      //   this.selectedFromDate = new Date ((new Date()).setMonth((new Date().getMonth()-1)))
      //   this.selectedToDate = new Date()
      //   this.innerValue.dateFrom = this.selectedFromDate.toISOString()
      //   this.innerValue.dateTo = this.selectedToDate.toISOString()
      // } else {
      //   this.selectedFromDate = null
      //   this.selectedToDate = null
      //   this.innerValue.dateFrom = ''
      //   this.innerValue.dateTo = ''
      // }
      if (newVal === 'allDates') {
        this.selectedFromDate = null;
        this.selectedToDate = null;
        this.innerValue.dateFrom = '';
        this.innerValue.dateTo = '';
      } else {
        this.innerValue.dateTo = new Date().toISOString();
      }
    },
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
    // value: {
    //   handler: function(newVal, oldVal) {
    //     this.innerValue = this.value
    //   },
    //   deep: true
    // }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.innerValue.dateFrom) {
              _this.selectedFromDate = new Date(_this.innerValue.dateFrom);
            }
            if (_this.innerValue.dateTo) {
              _this.selectedToDate = new Date(_this.innerValue.dateTo);
            }
            console.log(_this.innerValue);
            // if (this.selectDateType === 'selectDates') {
            //   this.selectedFromDate = new Date ((new Date()).setMonth((new Date().getMonth()-1)))
            //   this.selectedToDate = new Date()
            //   this.innerValue.dateFrom = this.selectedFromDate !== null ? this.selectedFromDate.toISOString() : ''
            //   this.innerValue.dateTo = this.selectedToDate !== null ? this.selectedToDate.toISOString() : ''
            // }
            // if (this.selectDateType === 'allDates') {
            //   this.innerValue.dateFrom = ''
            //   this.innerValue.dateTo = ''
            // }
            _this.getClientDropdown();
            _context.n = 1;
            return _this.getClientDropdown();
          case 1:
            _this.clients = _context.v;
            _this.selectedClient = _this.clients[0];
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {
    var elements = document.getElementsByClassName('datepicker');
    Array.from(elements).forEach(function (element, index, array) {
      var parent = element.parentNode;
      if (parent.nodeName === 'BODY') {
        parent.removeChild(element);
      }
    });
  },
  methods: {
    onFilterClick: function onFilterClick() {
      if (this.selectDateType === 'selectDates') {
        this.innerValue.dateFrom = this.selectedFromDate !== null ? this.selectedFromDate.toISOString() : '';
        this.innerValue.dateTo = this.selectedToDate !== null ? this.selectedToDate.toISOString() : '';
      }
      if (this.selectDateType === 'allDates') {
        this.innerValue.dateFrom = '';
        this.innerValue.dateTo = '';
      }
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.selectedFromDate = new Date(new Date().setMonth(new Date().getMonth() - 1));
      this.selectedToDate = new Date();
      this.selectedClient = this.clients[0];
      this.selectDateType = this.innerValue.selectDateType = 'selectDates';
      this.$emit('reset', this.selectedFromDate, this.selectedToDate);
    },
    selectClient: function selectClient(selected) {
      this.innerValue.assetId = selected.assetId;
      this.innerValue.clientName = selected.assetName;
    },
    removeClient: function removeClient() {
      this.innerValue.assetId = '';
      this.innerValue.clientName = '';
    },
    getClientDropdown: function getClientDropdown() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isClientLoading = true;
              _context2.n = 1;
              return _SalesAnalysisService__WEBPACK_IMPORTED_MODULE_16__["default"].getClientDropdownProto(_this2.clientFilter);
            case 1:
              _this2.clients = _context2.v;
              _this2.clients.unshift({
                assetName: 'All Clients',
                assetId: ''
              });
              _this2.selectedClient = _this2.clients.find(function (c) {
                return c.assetId === _this2.clientFilter.assetId;
              });
              _this2.isClientLoading = false;
              return _context2.a(2, _this2.clients);
          }
        }, _callee2);
      }))();
    },
    getClientDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_11___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              this.isClientLoading = true;
              this.clientFilter.assetName = query;
              _context3.n = 1;
              return _SalesAnalysisService__WEBPACK_IMPORTED_MODULE_16__["default"].getClientDropdownProto(this.clientFilter);
            case 1:
              this.clients = _context3.v;
              if (this.clientFilter.assetName === '') {
                this.clients.unshift({
                  assetName: 'All Clients',
                  assetId: ''
                });
              }
              this.isClientLoading = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500)
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _SalesAnalysisListSideMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./SalesAnalysisListSideMenu */ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue");
/* harmony import */ var _SalesAnalysisService__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./SalesAnalysisService */ "./src/views/salesanalysis/SalesAnalysisService.js");
/* harmony import */ var _SalesAnalysisValidation__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./SalesAnalysisValidation */ "./src/views/salesanalysis/SalesAnalysisValidation.js");
/* harmony import */ var _SalesAnalysisPrintModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./SalesAnalysisPrintModal */ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./columns */ "./src/views/salesanalysis/columns.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/printpreview/PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./storeMixin */ "./src/views/salesanalysis/storeMixin.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_26__);





























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SalesAnalysisListView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_12__["default"]
  }, _SalesAnalysisListSideMenu__WEBPACK_IMPORTED_MODULE_14__["default"].name, _SalesAnalysisListSideMenu__WEBPACK_IMPORTED_MODULE_14__["default"]), "SalesAnalysisPrintModal", _SalesAnalysisPrintModal__WEBPACK_IMPORTED_MODULE_17__["default"]), "BulmaTable", _components_BulmaTable__WEBPACK_IMPORTED_MODULE_19__["default"]),
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_18__["DateTimeFiltersMixin"], _SalesAnalysisValidation__WEBPACK_IMPORTED_MODULE_16__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_18__["NumberFiltersMixin"], _storeMixin__WEBPACK_IMPORTED_MODULE_25__["default"]],
  props: {},
  data: function data() {
    return {
      entitySummaries: [],
      totalRows: 0,
      filter: {
        // dateFrom: new Date(new Date().setMonth(new Date().getMonth() - 1)),
        // dateTo: new Date(),
        dateFrom: '',
        dateTo: '',
        selectDateType: 'selectDates',
        clientName: '',
        assetId: '',
        pageSize: 15,
        pageIndex: 1,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_20__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_20__["Columns"][0].defaultOrder
      },
      toggle: true,
      selectedRow: null,
      isTableLoading: false,
      isPrintSalesAnalysisModalActive: false
    };
  },
  computed: {
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_20__["Columns"];
    },
    itemCategoryTypes: function itemCategoryTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_13__["ItemCategoryTypes"];
    }
  },
  watch: {},
  created: function created() {
    var d = new Date(new Date().setMonth(new Date().getMonth() - 1));
    this.filter.dateFrom = d.toUTCString();
    this.filter.dateTo = new Date().toUTCString();
    this.getEntitySummaries();
  },
  mounted: function mounted() {
    this.$v.filter.$touch();
  },
  methods: {
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    filterList: function filterList() {
      if (this.$v.filter.$error) {
        this.$notification.openNotificationWithType('danger', 'Sales Analysis', 'Filter validation errors.');
        return false;
      }
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getEntitySummaries();
    },
    sort: function sort(name, order) {
      //this.filter.sortBy = name
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getEntitySummaries();
    },
    resetList: function resetList(selectedFromDate, selectedToDate) {
      this.filter.dateFrom = selectedFromDate;
      this.filter.dateTo = selectedToDate;
      this.filter.selectDateType = 'selectDates';
      this.filter.assetId = '';
      this.filter.clientName = '';
      this.filter.sortColumn = _columns__WEBPACK_IMPORTED_MODULE_20__["Columns"][0].name;
      this.filter.sortOrder = _columns__WEBPACK_IMPORTED_MODULE_20__["Columns"][0].defaultOrder;
      this.filter.pageIndex = 1;
      this.filter.pageSize = 15;
      this.persistFilter();
      this.getEntitySummaries();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getEntitySummaries();
    },
    getEntitySummaries: function getEntitySummaries() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this.isTableLoading = true;
              _this.retrieveFilter();
              _context.n = 1;
              return _SalesAnalysisService__WEBPACK_IMPORTED_MODULE_15__["default"].getEntitySummaries(_this.filter);
            case 1:
              _this.entitySummaries = _context.v;
              _this.totalRows = _this.entitySummaries.length > 0 ? _this.entitySummaries[0].totalRows : 0;
              _this.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    print: function print() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isPrintSalesAnalysisModalActive = true;
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    closePrint: function closePrint() {
      this.isPrintSalesAnalysisModalActive = false;
    },
    generateReportParams: function generateReportParams(report) {
      var sortBy = this.filter.sortColumn && this.filter.sortOrder ? "".concat(this.filter.sortColumn, " ").concat(this.filter.sortOrder) : '';
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        FromSalesDate: this.filter.dateFrom === '' ? '1754-12-31' : this.filter.dateFrom,
        EndSaleDate: this.filter.dateTo === '' ? '9999-12-31' : this.filter.dateTo,
        Client: this.filter.assetId,
        AllDates: this.filter.dateFrom === '' && this.filter.dateTo === '' ? true : false,
        ClientStringName: this.filter.clientName,
        SortBy: sortBy,
        timezoneoffset: this.$filters.getSiteTimezoneOffset()
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__["KeyValuePairModel"].convertToKeyValuePairs(params);
      return keyValuePairs;
    },
    exportToExcel: function exportToExcel(format) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var keyValuePairs;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              keyValuePairs = _this3.generateReportParams('SalesAnalysisExcel');
              _context3.n = 1;
              return _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_22__["default"].exportReportEx('rptSalesAnalysisExcel', format, keyValuePairs);
            case 1:
              _this3.isPrintSalesAnalysisModalActive = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    printSalesAnalysis: function printSalesAnalysis(report) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var keyValuePairs, reportName, emailSubject, emailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              keyValuePairs = _this4.generateReportParams(report);
              _this4.addReportParameters(keyValuePairs);
              reportName = '';
              emailSubject = '';
              if (report == 'SalesAnalysis') {
                reportName = 'rptSalesList';
                emailSubject = 'Sales Analysis';
              } else if (report == 'SalesAnalysisExcel') {
                reportName = 'rptSalesAnalysisExcel';
                emailSubject = 'Sales Analysis Export to Excel';
              }
              emailer = new _classes__WEBPACK_IMPORTED_MODULE_24__["Emailer"]();
              emailer.subject = emailSubject;
              emailer.reportName = reportName;
              _this4.addEmailer(emailer);
              _this4.$router.push({
                name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].PrintPreview.name,
                params: {
                  reportName: reportName
                },
                query: {
                  parameterId: _this4.$guid.newGuid(),
                  emailerId: emailer.id
                }
              });
              _this4.isPrintSalesAnalysisModalActive = false;
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    print1: function print1() {
      var sortBy = this.filter.sortColumn && this.filter.sortOrder ? "".concat(this.filter.sortColumn, " ").concat(this.filter.sortOrder) : '';
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        FromSalesDate: this.filter.dateFrom === '' ? '1754-12-31' : luxon__WEBPACK_IMPORTED_MODULE_26__["DateTime"].fromISO(this.filter.dateFrom).toISODate(),
        EndSaleDate: this.filter.dateTo === '' ? '9999-12-31' : luxon__WEBPACK_IMPORTED_MODULE_26__["DateTime"].fromISO(this.filter.dateTo).toISODate(),
        Client: this.filter.assetId,
        AllDates: this.filter.dateFrom === '' && this.filter.dateTo === '' ? true : false,
        ClientStringName: this.filter.clientName,
        SortBy: sortBy,
        timezoneoffset: this.$filters.getSiteTimezoneOffset()
      });
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_23__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_24__["Emailer"]();
      emailer.subject = 'Sales Analysis Report';
      emailer.reportName = 'rptSalesList';
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_21__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SalesAnalysisPrintModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_1__["BaseModalEx"]
    // SmsMessage
  },
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'primary'
    },
    iconName: {
      type: String,
      default: 'mdi-printer'
    }
  },
  data: function data() {
    return {
      isActive: false,
      report: ''
    };
  },
  computed: {
    reportFormatTypes: function reportFormatTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_2__["ReportFormatTypes"];
    }
  },
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    print: function print() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('print', this.report);
    },
    exportReport: function exportReport() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('export', this.report);
    },
    close: function close() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('close');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field has-addons"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.selectDateType,
      expression: "innerValue.selectDateType"
    }],
    staticClass: "is-checkradio",
    attrs: {
      checked: "",
      id: "selectDates",
      type: "radio",
      name: "selectDateType",
      value: "selectDates"
    },
    domProps: {
      checked: _vm._q(_vm.innerValue.selectDateType, "selectDates")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerValue, "selectDateType", "selectDates");
      }
    }
  }), _c("label", {
    attrs: {
      for: "selectDates"
    }
  }, [_vm._v("Select Dates")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.selectDateType,
      expression: "innerValue.selectDateType"
    }],
    staticClass: "is-checkradio",
    attrs: {
      id: "allDates",
      type: "radio",
      name: "selectDateType",
      value: "allDates"
    },
    domProps: {
      checked: _vm._q(_vm.innerValue.selectDateType, "allDates")
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerValue, "selectDateType", "allDates");
      }
    }
  }), _c("label", {
    attrs: {
      for: "allDates"
    }
  }, [_vm._v("All Dates")])]), _c("div", {
    staticClass: "field"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": {
        timeAdjust: "00:00:00"
      },
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Sales Date From..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedFromDate,
      callback: function callback($$v) {
        _vm.selectedFromDate = $$v;
      },
      expression: "selectedFromDate"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": {
        timeAdjust: "23:59:59"
      },
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref2) {
        var inputValue = _ref2.inputValue,
          inputEvents = _ref2.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Sales Date To..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedToDate,
      callback: function callback($$v) {
        _vm.selectedToDate = $$v;
      },
      expression: "selectedToDate"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      placeholder: "Select Client",
      "track-by": "assetId",
      label: "assetName",
      options: _vm.clients,
      "options-limit": _vm.clientFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true,
      loading: _vm.isClientLoading,
      "internal-search": false
    },
    on: {
      select: _vm.selectClient,
      remove: _vm.removeClient,
      "search-change": _vm.getClientDropdownFilter
    },
    model: {
      value: _vm.selectedClient,
      callback: function callback($$v) {
        _vm.selectedClient = $$v;
      },
      expression: "selectedClient"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Client not found.")])])], 1)])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false,
      "show-new": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("sales-analysis-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column is-wrapped"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (entity, index) {
    return _c("tr", {
      key: entity.assetId,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(entity.invoiceDate, _vm.$userInfo.locale)))]), _c("td", [_vm._v(_vm._s(entity.debtorName))]), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.RR) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.rrTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.RWA) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.rwaTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.REP) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.repairTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.PAINT) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.paintTotal + entity.opgTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.FIBER) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.fgTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.CRUSH) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.crushTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.CD) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.cdTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.MECH) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.mechTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.PART) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.partTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.MISC) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.miscTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.SUBL) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.subletTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.PDRRR) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.pdrrrTotal, _vm.$userInfo.locale)))]) : _vm._e(), _vm.$company.isCategoryEnabled(_vm.itemCategoryTypes.PDRRE) ? _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.pdrreTotal, _vm.$userInfo.locale)))]) : _vm._e(), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.painM, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.orTotals, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.excessAmount, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.totalExGST, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.gst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(entity.totalIncGst, _vm.$userInfo.locale)))]), _c("td", [_vm._v(_vm._s(entity.invoiceNo))]), _c("td", [_vm._v(_vm._s(entity.quoteNo))]), _c("td", [_vm._v(_vm._s(entity.claimNo))]), _c("td", [_vm._v(_vm._s(entity.rego))]), _c("td", [_vm._v(_vm._s(entity.ownerName))])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])]), _vm.isPrintSalesAnalysisModalActive ? _c("sales-analysis-print-modal", {
    attrs: {
      active: _vm.isPrintSalesAnalysisModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPrintSalesAnalysisModalActive = $event;
      },
      print: _vm.printSalesAnalysis,
      export: _vm.exportToExcel,
      close: _vm.closePrint
    }
  }) : _vm._e()], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.isActive ? _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 30,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("div", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Print Options")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("span", [_vm._v("Select report")])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.report,
      expression: "report"
    }],
    staticClass: "is-checkradio",
    attrs: {
      id: "salesAnalysis",
      type: "radio",
      name: "salesAnalysis"
    },
    domProps: {
      value: "SalesAnalysis",
      checked: _vm._q(_vm.report, "SalesAnalysis")
    },
    on: {
      change: function change($event) {
        _vm.report = "SalesAnalysis";
      }
    }
  }), _c("label", {
    attrs: {
      for: "salesAnalysis"
    }
  }, [_vm._v("Sales Analysis")])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.report,
      expression: "report"
    }],
    staticClass: "is-checkradio",
    attrs: {
      id: _vm.reportFormatTypes.excel,
      type: "radio",
      name: _vm.reportFormatTypes.excel
    },
    domProps: {
      value: _vm.reportFormatTypes.excel,
      checked: _vm._q(_vm.report, _vm.reportFormatTypes.excel)
    },
    on: {
      change: function change($event) {
        _vm.report = _vm.reportFormatTypes.excel;
      }
    }
  }), _c("label", {
    attrs: {
      for: _vm.reportFormatTypes.excel
    }
  }, [_vm._v("Sales Analysis export to Excel")])])])]), _c("footer", {
    staticClass: "modal-card-foot",
    style: "justify-content: flex-".concat(_vm.buttonLocation)
  }, [_c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Export to Excel",
      disabled: _vm.report && _vm.report != "excel"
    },
    on: {
      click: _vm.exportReport
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-export mdi-18px"
  })]), _c("span", [_vm._v("Export")])]), _c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Print report",
      disabled: _vm.report && _vm.report == "excel"
    },
    on: {
      click: _vm.print
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-printer mdi-18px"
  })]), _c("span", [_vm._v("Print")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: function click($event) {
        return _vm.close();
      }
    }
  }, [_vm._v("Close")])])]) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.uppercase[data-v-6f56a9ea] {\n  text-transform: uppercase;\n}\ninput.uppercase[data-v-6f56a9ea]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-6f56a9ea]::-moz-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-6f56a9ea]:-moz-placeholder {\n  text-transform: none;\n}\ninput.uppercase[data-v-6f56a9ea]:-ms-input-placeholder {\n  text-transform: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-wrapped[data-v-5062595a] {\n  overflow-x: auto;\n  width: 100%;\n}\n.table[data-v-5062595a] {\n  font-size: 0.75rem;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-7bb43a92] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4ad89fea", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("0782de4d", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2d6875ea", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/proto/salesanalysis/SalesAnalysisFilter.proto":
/*!******************************************************************!*\
  !*** ./src/assets/proto/salesanalysis/SalesAnalysisFilter.proto ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*undefined*/


var $protobuf = __webpack_require__(/*! protobufjs/minimal */ "./node_modules/protobufjs/minimal.js");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

$root.SalesAnalysisFilter = (function() {

    /**
     * Namespace SalesAnalysisFilter.
     * @exports SalesAnalysisFilter
     * @namespace
     */
    var SalesAnalysisFilter = {};

    SalesAnalysisFilter.SalesAnalysisFilterModel = (function() {

        /**
         * Properties of a SalesAnalysisFilterModel.
         * @memberof SalesAnalysisFilter
         * @interface ISalesAnalysisFilterModel
         * @property {string|null} [dateFrom] SalesAnalysisFilterModel dateFrom
         * @property {string|null} [dateTo] SalesAnalysisFilterModel dateTo
         * @property {string|null} [clientName] SalesAnalysisFilterModel clientName
         * @property {string|null} [assetId] SalesAnalysisFilterModel assetId
         * @property {string|null} [sortColumn] SalesAnalysisFilterModel sortColumn
         * @property {string|null} [sortOrder] SalesAnalysisFilterModel sortOrder
         * @property {number|null} [pageIndex] SalesAnalysisFilterModel pageIndex
         * @property {number|null} [pageSize] SalesAnalysisFilterModel pageSize
         */

        /**
         * Constructs a new SalesAnalysisFilterModel.
         * @memberof SalesAnalysisFilter
         * @classdesc Represents a SalesAnalysisFilterModel.
         * @implements ISalesAnalysisFilterModel
         * @constructor
         * @param {SalesAnalysisFilter.ISalesAnalysisFilterModel=} [p] Properties to set
         */
        function SalesAnalysisFilterModel(p) {
            if (p)
                for (var ks = Object.keys(p), i = 0; i < ks.length; ++i)
                    if (p[ks[i]] != null)
                        this[ks[i]] = p[ks[i]];
        }

        /**
         * SalesAnalysisFilterModel dateFrom.
         * @member {string|null|undefined} dateFrom
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.dateFrom = null;

        /**
         * SalesAnalysisFilterModel dateTo.
         * @member {string|null|undefined} dateTo
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.dateTo = null;

        /**
         * SalesAnalysisFilterModel clientName.
         * @member {string|null|undefined} clientName
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.clientName = null;

        /**
         * SalesAnalysisFilterModel assetId.
         * @member {string|null|undefined} assetId
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.assetId = null;

        /**
         * SalesAnalysisFilterModel sortColumn.
         * @member {string|null|undefined} sortColumn
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.sortColumn = null;

        /**
         * SalesAnalysisFilterModel sortOrder.
         * @member {string|null|undefined} sortOrder
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.sortOrder = null;

        /**
         * SalesAnalysisFilterModel pageIndex.
         * @member {number|null|undefined} pageIndex
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.pageIndex = null;

        /**
         * SalesAnalysisFilterModel pageSize.
         * @member {number|null|undefined} pageSize
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        SalesAnalysisFilterModel.prototype.pageSize = null;

        // OneOf field names bound to virtual getters and setters
        var $oneOfFields;

        /**
         * SalesAnalysisFilterModel _dateFrom.
         * @member {"dateFrom"|undefined} _dateFrom
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_dateFrom", {
            get: $util.oneOfGetter($oneOfFields = ["dateFrom"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _dateTo.
         * @member {"dateTo"|undefined} _dateTo
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_dateTo", {
            get: $util.oneOfGetter($oneOfFields = ["dateTo"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _clientName.
         * @member {"clientName"|undefined} _clientName
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_clientName", {
            get: $util.oneOfGetter($oneOfFields = ["clientName"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _assetId.
         * @member {"assetId"|undefined} _assetId
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_assetId", {
            get: $util.oneOfGetter($oneOfFields = ["assetId"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _sortColumn.
         * @member {"sortColumn"|undefined} _sortColumn
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_sortColumn", {
            get: $util.oneOfGetter($oneOfFields = ["sortColumn"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _sortOrder.
         * @member {"sortOrder"|undefined} _sortOrder
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_sortOrder", {
            get: $util.oneOfGetter($oneOfFields = ["sortOrder"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _pageIndex.
         * @member {"pageIndex"|undefined} _pageIndex
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_pageIndex", {
            get: $util.oneOfGetter($oneOfFields = ["pageIndex"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * SalesAnalysisFilterModel _pageSize.
         * @member {"pageSize"|undefined} _pageSize
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @instance
         */
        Object.defineProperty(SalesAnalysisFilterModel.prototype, "_pageSize", {
            get: $util.oneOfGetter($oneOfFields = ["pageSize"]),
            set: $util.oneOfSetter($oneOfFields)
        });

        /**
         * Encodes the specified SalesAnalysisFilterModel message. Does not implicitly {@link SalesAnalysisFilter.SalesAnalysisFilterModel.verify|verify} messages.
         * @function encode
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @static
         * @param {SalesAnalysisFilter.ISalesAnalysisFilterModel} m SalesAnalysisFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [w] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        SalesAnalysisFilterModel.encode = function encode(m, w) {
            if (!w)
                w = $Writer.create();
            if (m.dateFrom != null && Object.hasOwnProperty.call(m, "dateFrom"))
                w.uint32(10).string(m.dateFrom);
            if (m.dateTo != null && Object.hasOwnProperty.call(m, "dateTo"))
                w.uint32(18).string(m.dateTo);
            if (m.clientName != null && Object.hasOwnProperty.call(m, "clientName"))
                w.uint32(26).string(m.clientName);
            if (m.assetId != null && Object.hasOwnProperty.call(m, "assetId"))
                w.uint32(34).string(m.assetId);
            if (m.sortColumn != null && Object.hasOwnProperty.call(m, "sortColumn"))
                w.uint32(42).string(m.sortColumn);
            if (m.sortOrder != null && Object.hasOwnProperty.call(m, "sortOrder"))
                w.uint32(50).string(m.sortOrder);
            if (m.pageIndex != null && Object.hasOwnProperty.call(m, "pageIndex"))
                w.uint32(56).int32(m.pageIndex);
            if (m.pageSize != null && Object.hasOwnProperty.call(m, "pageSize"))
                w.uint32(64).int32(m.pageSize);
            return w;
        };

        /**
         * Encodes the specified SalesAnalysisFilterModel message, length delimited. Does not implicitly {@link SalesAnalysisFilter.SalesAnalysisFilterModel.verify|verify} messages.
         * @function encodeDelimited
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @static
         * @param {SalesAnalysisFilter.ISalesAnalysisFilterModel} message SalesAnalysisFilterModel message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        SalesAnalysisFilterModel.encodeDelimited = function encodeDelimited(message, writer) {
            return this.encode(message, writer).ldelim();
        };

        /**
         * Decodes a SalesAnalysisFilterModel message from the specified reader or buffer.
         * @function decode
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} r Reader or buffer to decode from
         * @param {number} [l] Message length if known beforehand
         * @returns {SalesAnalysisFilter.SalesAnalysisFilterModel} SalesAnalysisFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        SalesAnalysisFilterModel.decode = function decode(r, l) {
            if (!(r instanceof $Reader))
                r = $Reader.create(r);
            var c = l === undefined ? r.len : r.pos + l, m = new $root.SalesAnalysisFilter.SalesAnalysisFilterModel();
            while (r.pos < c) {
                var t = r.uint32();
                switch (t >>> 3) {
                case 1:
                    m.dateFrom = r.string();
                    break;
                case 2:
                    m.dateTo = r.string();
                    break;
                case 3:
                    m.clientName = r.string();
                    break;
                case 4:
                    m.assetId = r.string();
                    break;
                case 5:
                    m.sortColumn = r.string();
                    break;
                case 6:
                    m.sortOrder = r.string();
                    break;
                case 7:
                    m.pageIndex = r.int32();
                    break;
                case 8:
                    m.pageSize = r.int32();
                    break;
                default:
                    r.skipType(t & 7);
                    break;
                }
            }
            return m;
        };

        /**
         * Decodes a SalesAnalysisFilterModel message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof SalesAnalysisFilter.SalesAnalysisFilterModel
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {SalesAnalysisFilter.SalesAnalysisFilterModel} SalesAnalysisFilterModel
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        SalesAnalysisFilterModel.decodeDelimited = function decodeDelimited(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.uint32());
        };

        return SalesAnalysisFilterModel;
    })();

    return SalesAnalysisFilter;
})();

module.exports = $root;


/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue":
/*!***************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListSideMenu.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true */ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true");
/* harmony import */ var _SalesAnalysisListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SalesAnalysisListSideMenu.vue?vue&type=script&lang=js */ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true */ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SalesAnalysisListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6f56a9ea",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/salesanalysis/SalesAnalysisListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js":
/*!***************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true":
/*!************************************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=style&index=0&id=6f56a9ea&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_style_index_0_id_6f56a9ea_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListSideMenu.vue?vue&type=template&id=6f56a9ea&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListSideMenu_vue_vue_type_template_id_6f56a9ea_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListView.vue":
/*!***********************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListView.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true */ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true");
/* harmony import */ var _SalesAnalysisListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SalesAnalysisListView.vue?vue&type=script&lang=js */ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true */ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SalesAnalysisListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5062595a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/salesanalysis/SalesAnalysisListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=style&index=0&id=5062595a&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_style_index_0_id_5062595a_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisListView.vue?vue&type=template&id=5062595a&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisListView_vue_vue_type_template_id_5062595a_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue":
/*!*************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisPrintModal.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true */ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true");
/* harmony import */ var _SalesAnalysisPrintModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SalesAnalysisPrintModal.vue?vue&type=script&lang=js */ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true */ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SalesAnalysisPrintModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7bb43a92",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/salesanalysis/SalesAnalysisPrintModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisPrintModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true":
/*!**********************************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=style&index=0&id=7bb43a92&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_style_index_0_id_7bb43a92_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true":
/*!*******************************************************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/salesanalysis/SalesAnalysisPrintModal.vue?vue&type=template&id=7bb43a92&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SalesAnalysisPrintModal_vue_vue_type_template_id_7bb43a92_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisService.js":
/*!*********************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisService.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array-buffer.constructor.js */ "./node_modules/core-js/modules/es.array-buffer.constructor.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array-buffer.slice.js */ "./node_modules/core-js/modules/es.array-buffer.slice.js");
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array-buffer.detached.js */ "./node_modules/core-js/modules/es.array-buffer.detached.js");
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer.js */ "./node_modules/core-js/modules/es.array-buffer.transfer.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer-to-fixed-length.js */ "./node_modules/core-js/modules/es.array-buffer.transfer-to-fixed-length.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.typed-array.uint8-array.js */ "./node_modules/core-js/modules/es.typed-array.uint8-array.js");
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.typed-array.at.js */ "./node_modules/core-js/modules/es.typed-array.at.js");
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.typed-array.copy-within.js */ "./node_modules/core-js/modules/es.typed-array.copy-within.js");
/* harmony import */ var core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_copy_within_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.typed-array.every.js */ "./node_modules/core-js/modules/es.typed-array.every.js");
/* harmony import */ var core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_every_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.typed-array.fill.js */ "./node_modules/core-js/modules/es.typed-array.fill.js");
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.typed-array.filter.js */ "./node_modules/core-js/modules/es.typed-array.filter.js");
/* harmony import */ var core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.typed-array.find.js */ "./node_modules/core-js/modules/es.typed-array.find.js");
/* harmony import */ var core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-index.js */ "./node_modules/core-js/modules/es.typed-array.find-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_index_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last.js */ "./node_modules/core-js/modules/es.typed-array.find-last.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.typed-array.find-last-index.js */ "./node_modules/core-js/modules/es.typed-array.find-last-index.js");
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.typed-array.for-each.js */ "./node_modules/core-js/modules/es.typed-array.for-each.js");
/* harmony import */ var core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.typed-array.includes.js */ "./node_modules/core-js/modules/es.typed-array.includes.js");
/* harmony import */ var core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_includes_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.typed-array.index-of.js */ "./node_modules/core-js/modules/es.typed-array.index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_index_of_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.typed-array.iterator.js */ "./node_modules/core-js/modules/es.typed-array.iterator.js");
/* harmony import */ var core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_iterator_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.typed-array.join.js */ "./node_modules/core-js/modules/es.typed-array.join.js");
/* harmony import */ var core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_join_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.typed-array.last-index-of.js */ "./node_modules/core-js/modules/es.typed-array.last-index-of.js");
/* harmony import */ var core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_last_index_of_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.typed-array.map.js */ "./node_modules/core-js/modules/es.typed-array.map.js");
/* harmony import */ var core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_map_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce.js */ "./node_modules/core-js/modules/es.typed-array.reduce.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.typed-array.reduce-right.js */ "./node_modules/core-js/modules/es.typed-array.reduce-right.js");
/* harmony import */ var core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reduce_right_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.typed-array.reverse.js */ "./node_modules/core-js/modules/es.typed-array.reverse.js");
/* harmony import */ var core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_reverse_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.typed-array.set.js */ "./node_modules/core-js/modules/es.typed-array.set.js");
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.typed-array.slice.js */ "./node_modules/core-js/modules/es.typed-array.slice.js");
/* harmony import */ var core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_slice_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.typed-array.some.js */ "./node_modules/core-js/modules/es.typed-array.some.js");
/* harmony import */ var core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_some_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.typed-array.sort.js */ "./node_modules/core-js/modules/es.typed-array.sort.js");
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/es.typed-array.subarray.js */ "./node_modules/core-js/modules/es.typed-array.subarray.js");
/* harmony import */ var core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_subarray_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-locale-string.js */ "./node_modules/core-js/modules/es.typed-array.to-locale-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_locale_string_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-reversed.js */ "./node_modules/core-js/modules/es.typed-array.to-reversed.js");
/* harmony import */ var core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-sorted.js */ "./node_modules/core-js/modules/es.typed-array.to-sorted.js");
/* harmony import */ var core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! core-js/modules/es.typed-array.to-string.js */ "./node_modules/core-js/modules/es.typed-array.to-string.js");
/* harmony import */ var core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_to_string_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! core-js/modules/es.typed-array.with.js */ "./node_modules/core-js/modules/es.typed-array.with.js");
/* harmony import */ var core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_with_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_base64_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.set-from-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.set-from-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_set_from_hex_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-base64.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-base64.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_base64_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! core-js/modules/esnext.uint8-array.to-hex.js */ "./node_modules/core-js/modules/esnext.uint8-array.to-hex.js");
/* harmony import */ var core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_uint8_array_to_hex_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_protobuf_api__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! @/services/protobuf-api */ "./src/services/protobuf-api.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! protobufjs */ "./node_modules/protobufjs/index.js");
/* harmony import */ var protobufjs__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(protobufjs__WEBPACK_IMPORTED_MODULE_44__);













































/* harmony default export */ __webpack_exports__["default"] = ({
  getEntitySummaries: function getEntitySummaries(filter) {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var serialised, url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            serialised = _this.serialiseSalesAnalysisFilter(filter);
            url = "salesanalysis/list/".concat(serialised);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_42__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  getClientDropdownProto: function getClientDropdownProto(filter) {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var serialised, result, proto, message, entity;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            serialised = _this2.serialiseQuickInvoiceAssetDropdownFilter(filter);
            _context2.n = 1;
            return Object(_services_protobuf_api__WEBPACK_IMPORTED_MODULE_43__["default"])("/quickinvoices/protobuf/assets/listcombo/".concat(serialised));
          case 1:
            result = _context2.v;
            proto = __webpack_require__(/*! ../../assets/proto/quickinvoice/QuickInvoiceAssetDropdown.proto */ "./src/assets/proto/quickinvoice/QuickInvoiceAssetDropdown.proto");
            message = proto.QuickInvoiceAssetDropdown.QuickInvoiceAssetDropdownModel;
            entity = message.decode(new Uint8Array(result.data));
            return _context2.a(2, entity.assets);
        }
      }, _callee2);
    }))();
  },
  serialiseSalesAnalysisFilter: function serialiseSalesAnalysisFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/salesanalysis/SalesAnalysisFilter.proto */ "./src/assets/proto/salesanalysis/SalesAnalysisFilter.proto");
    var filterMessage = entityProto.SalesAnalysisFilter.SalesAnalysisFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_44___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  },
  serialiseQuickInvoiceAssetDropdownFilter: function serialiseQuickInvoiceAssetDropdownFilter(filter) {
    var entityProto = __webpack_require__(/*! ../../assets/proto/quickinvoice/QuickInvoiceAssetDropdownFilter.proto */ "./src/assets/proto/quickinvoice/QuickInvoiceAssetDropdownFilter.proto");
    var filterMessage = entityProto.QuickInvoiceAssetDropdownFilter.QuickInvoiceAssetDropdownFilterModel;
    var buffer = filterMessage.encode(filter).finish();
    var b64encoded = protobufjs__WEBPACK_IMPORTED_MODULE_44___default.a.util.base64.encode(buffer, 0, buffer.length);
    return b64encoded;
  }
});

/***/ }),

/***/ "./src/views/salesanalysis/SalesAnalysisValidation.js":
/*!************************************************************!*\
  !*** ./src/views/salesanalysis/SalesAnalysisValidation.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//import { required } from 'vuelidate/lib/validators'
//import { guidValidator } from '@/components/validators'

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    filter: {
      dateFrom: {
        validDate: true // aussieDateValidator
      },
      dateTo: {
        validDate: true // aussieDateValidator
      }
    }
  }
});

/***/ }),

/***/ "./src/views/salesanalysis/columns.js":
/*!********************************************!*\
  !*** ./src/views/salesanalysis/columns.js ***!
  \********************************************/
/*! exports provided: Columns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/store */ "./src/store/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");











var company = _store__WEBPACK_IMPORTED_MODULE_9__["default"].getters['company/company'];
var startColumns = [new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Inv Date', 'invoiceDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Debtor Name', 'debtorName', true, 'desc', 'left')];
var endColumns = [new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('PAINM', 'painM', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Other Work', 'orTotals', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Excess', 'excessAmount', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Total Excl GST', 'totalExGst', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('GST', 'gst', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Total Incl GST', 'totalIncGst', true, 'asc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Inv No', 'invoiceNoFromSp', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Quote No', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Claim No', 'claimNoFromSp', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Rego No', 'regoNoFromSp', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"]('Owner Name', 'ownerName', true, 'desc', 'left')];
var categoryTotalMapping = [{
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].RR,
  total: 'rrTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].RWA,
  total: 'rwaTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].REP,
  total: 'repairTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].PAINT,
  total: 'paintTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].FIBER,
  total: 'fgTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].CRUSH,
  total: 'crushTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].CD,
  total: 'subletTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].MECH,
  total: 'cdTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].PART,
  total: 'partTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].MISC,
  total: 'miscTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].SUBL,
  total: 'subletTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].PDRRR,
  total: 'pdrrrTotal'
}, {
  category: _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].PDRRE,
  total: 'pdrreTotal'
}];
var generatedColumns = [];
var excludedCategories = ['QUICK', _enums__WEBPACK_IMPORTED_MODULE_10__["ItemCategoryTypes"].OPG];
if (company.itemCategories != null) {
  company.itemCategories.forEach(function (category) {
    if (category.enabled && !excludedCategories.includes(category.itemCategoryType)) {
      var totalColumn = categoryTotalMapping.find(function (m) {
        return m.category === category.itemCategoryType;
      });
      generatedColumns.splice(generatedColumns.length, 1, new _classes__WEBPACK_IMPORTED_MODULE_8__["TableColumn"](category.displayName, totalColumn.total, true, 'desc', 'right'));
    }
  });
}
var Columns = [].concat(startColumns, generatedColumns, endColumns);

// let Columns = [
//   new TableColumn('Inv Date', 'invoiceDate', true, 'desc', 'left'),
//   new TableColumn('Debtor Name', 'debtorName', true, 'desc', 'left'),
//   new TableColumn('R&R', 'rrTotal', true, 'asc', 'left'),
//   new TableColumn('RWA', 'rwaTotal', true, 'desc', 'left'),
//   new TableColumn('Repair', 'repairTotal', true, 'asc', 'left'),
//   new TableColumn('Paint', 'paintTotal', true, 'asc', 'centered'),
//   new TableColumn('Parts', 'partTotal', true, 'desc', 'left'),
//   new TableColumn('Misc', 'miscTotal', true, 'desc', 'left'),
//   new TableColumn('Sublet', 'subletTotal', true, 'desc', 'left'),
//   new TableColumn('FG', 'fgTotal', true, 'desc', 'left'),
//   new TableColumn('MECH', 'mechTotal', true, 'desc', 'left'),
//   new TableColumn('CRUSH', 'crushTotal', true, 'asc', 'left'),
//   new TableColumn('CD', 'cdTotal', true, 'desc', 'left'),
//   new TableColumn('Other Work', 'orTotals', true, 'asc', 'left'),
//   new TableColumn('Total', 'totalExGst', true, 'asc', 'centered'),
//   new TableColumn('Inv No', 'invoiceNoFromSp', true, 'desc', 'left'),
//   new TableColumn('Quote No', 'quoteNo', true, 'desc', 'left'),
//   new TableColumn('Claim No', 'claimNoFromSp', true, 'desc', 'left'),
//   new TableColumn('Rego No', 'regoNoFromSp', true, 'desc', 'left'),
//   new TableColumn('Owner Name', 'ownerName', true, 'desc', 'left')
// ]



/***/ }),

/***/ "./src/views/salesanalysis/storeMixin.js":
/*!***********************************************!*\
  !*** ./src/views/salesanalysis/storeMixin.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'salesanalysis';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=salesanalysislist-chunk.js.map