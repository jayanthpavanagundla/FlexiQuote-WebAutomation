(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[23],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_callSuper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/callSuper.js */ "./node_modules/@babel/runtime/helpers/esm/callSuper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_superPropGet_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/superPropGet.js */ "./node_modules/@babel/runtime/helpers/esm/superPropGet.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.match.js */ "./node_modules/core-js/modules/es.string.match.js");
/* harmony import */ var core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_match_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_10__);











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuillEditor',
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      editor: null
    };
  },
  watch: {
    value: function value(val) {
      if (this.editor && this.editor.root.innerHTML !== val) {
        this.editor.root.innerHTML = val;
      }
    }
  },
  mounted: function mounted() {
    this.initializeEditor();
  },
  beforeDestroy: function beforeDestroy() {
    this.removeDropdownEventListeners();
  },
  methods: {
    addDropdownEventListeners: function addDropdownEventListeners() {
      var _this = this;
      var toolbar = this.editor.getModule('toolbar');
      var dropdowns = toolbar.container.querySelectorAll('.ql-picker');
      dropdowns.forEach(function (dropdown) {
        dropdown.addEventListener('mousedown', _this.handleDropdownClick);
      });
    },
    addToolbarHandler: function addToolbarHandler(quill) {
      var toolbar = quill.getModule('toolbar');
      toolbar.addHandler('color', function (color) {
        var _currentFormat$custom, _currentFormat$custom2;
        var currentFormat = this.getFormat();
        var font = ((_currentFormat$custom = currentFormat.custom_font) === null || _currentFormat$custom === void 0 ? void 0 : _currentFormat$custom.face) || 'Arial';
        var size = ((_currentFormat$custom2 = currentFormat.custom_font) === null || _currentFormat$custom2 === void 0 ? void 0 : _currentFormat$custom2.size) || '3';
        if (color) {
          this.format('custom_font', {
            face: font,
            color: color,
            size: size
          });
        } else {
          this.format('custom_font', false);
        }
      }.bind(quill));
      toolbar.addHandler('font', function (font) {
        var _currentFormat$custom3, _currentFormat$custom4;
        var currentFormat = this.getFormat();
        var color = ((_currentFormat$custom3 = currentFormat.custom_font) === null || _currentFormat$custom3 === void 0 ? void 0 : _currentFormat$custom3.color) || 'black';
        var size = ((_currentFormat$custom4 = currentFormat.custom_font) === null || _currentFormat$custom4 === void 0 ? void 0 : _currentFormat$custom4.size) || '3';
        if (font) {
          this.format('custom_font', {
            face: font,
            color: color,
            size: size
          });
        } else {
          this.format('custom_font', false);
        }
      }.bind(quill));
      toolbar.addHandler('size', function (size) {
        var _currentFormat$custom5, _currentFormat$custom6;
        var currentFormat = this.getFormat();
        var font = ((_currentFormat$custom5 = currentFormat.custom_font) === null || _currentFormat$custom5 === void 0 ? void 0 : _currentFormat$custom5.face) || 'Arial';
        var color = ((_currentFormat$custom6 = currentFormat.custom_font) === null || _currentFormat$custom6 === void 0 ? void 0 : _currentFormat$custom6.color) || 'black';
        if (size) {
          this.format('custom_font', {
            face: font,
            color: color,
            size: size
          });
        } else {
          this.format('custom_font', false);
        }
      }.bind(quill));
    },
    addToolbarTooltips: function addToolbarTooltips() {
      var tooltips = {
        clean: 'Remove formatting'
      };
      var toolbar = this.$refs.editorContainer.previousSibling;
      var buttons = toolbar.querySelectorAll('button');
      buttons.forEach(function (button) {
        var _button$className$mat;
        var format = (_button$className$mat = button.className.match(/ql-(\w+)/)) === null || _button$className$mat === void 0 ? void 0 : _button$className$mat[1]; // Extract format name
        if (tooltips[format]) {
          button.setAttribute('title', tooltips[format]); // Add tooltip
        }
      });
    },
    getToolbarOptions: function getToolbarOptions() {
      var toolbarSizes = ['1', '2', '3', '4', '5', '6', '7'];
      var toolbarFonts = ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Narrow', 'Garamond', 'Georgia', 'Impact', 'Sans Serif', 'Serif', 'Tahoma', 'Trebuchet MS', 'Verdana'];
      var toolbarOptions = [[{
        'size': toolbarSizes
      }], [{
        'font': toolbarFonts
      }], ['bold', 'italic', 'underline', 'strike'], [{
        'color': []
      }, {
        'background': []
      }], [{
        'align': []
      }], [{
        'list': 'ordered'
      }, {
        'list': 'bullet'
      }, {
        'list': 'check'
      }], [{
        'indent': '-1'
      }, {
        'indent': '+1'
      }], ['clean']];
      return toolbarOptions;
    },
    initializeEditor: function initializeEditor() {
      var _this2 = this;
      this.registerCustomFontBlot();
      this.registerDivBlot();
      this.registerCustomSizeStyle();
      this.registerCustomFontStyle();
      var toolbarOptions = this.getToolbarOptions();
      this.editor = new Quill(this.$refs.editorContainer, {
        theme: 'snow',
        modules: {
          toolbar: toolbarOptions
        }
      });
      this.addToolbarHandler(this.editor);
      this.addToolbarTooltips();
      var sanitisedHTML = DOMPurify.sanitize(this.value);
      this.editor.clipboard.dangerouslyPasteHTML(sanitisedHTML);
      this.editor.on('text-change', function () {
        _this2.$emit('input', _this2.editor.root.innerHTML);
      });
      this.addDropdownEventListeners();
    },
    handleDropdownClick: function handleDropdownClick(event) {
      var _this3 = this;
      event.preventDefault();
      setTimeout(function () {
        _this3.editor.focus();
      }, 0);
    },
    registerCustomFontBlot: function registerCustomFontBlot() {
      var Inline = Quill.import('blots/inline');
      var FontBlot = /*#__PURE__*/function (_Inline) {
        function FontBlot() {
          Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, FontBlot);
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_callSuper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, FontBlot, arguments);
        }
        Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__["default"])(FontBlot, _Inline);
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(FontBlot, null, [{
          key: "create",
          value: function create(value) {
            var node = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_superPropGet_js__WEBPACK_IMPORTED_MODULE_3__["default"])(FontBlot, "create", this, 2)([]);
            node.setAttribute('face', value.face);
            node.setAttribute('color', value.color);
            node.setAttribute('size', value.size);
            return node;
          }
        }, {
          key: "formats",
          value: function formats(node) {
            return {
              face: node.getAttribute('face'),
              color: node.getAttribute('color'),
              size: node.getAttribute('size')
            };
          }
        }]);
      }(Inline);
      FontBlot.blotName = 'custom_font';
      FontBlot.tagName = 'font';
      Quill.register(FontBlot, true);
    },
    registerCustomFontStyle: function registerCustomFontStyle() {
      var Font = Quill.import('attributors/style/font');
      Font.whitelist = ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Narrow', 'Garamond', 'Georgia', 'Impact', 'Sans Serif', 'Serif', 'Tahoma', 'Trebuchet MS', 'Verdana'];
      Quill.register(Font, true);
    },
    registerCustomSizeStyle: function registerCustomSizeStyle() {
      var Size = Quill.import('attributors/style/size');
      Size.whitelist = ['1', '2', '3', '4', '5', '6', '7'];
      Quill.register(Size, true);
    },
    registerDivBlot: function registerDivBlot() {
      var Block = Quill.import('blots/block');
      Block.tagName = 'DIV';
      Quill.register(Block, true);
    },
    removeDropdownEventListeners: function removeDropdownEventListeners() {
      var _this4 = this;
      var toolbar = this.editor.getModule('toolbar');
      var dropdowns = toolbar.container.querySelectorAll('.ql-picker');
      dropdowns.forEach(function (dropdown) {
        dropdown.removeEventListener('mousedown', _this4.handleDropdownClick);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/common */ "./src/services/common.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_QuillEditor_QuillEdtor_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/QuillEditor/QuillEdtor.vue */ "./src/components/QuillEditor/QuillEdtor.vue");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");
/* harmony import */ var _components_VueDropzone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/VueDropzone */ "./src/components/VueDropzone/index.js");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanySetting',
  components: {
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_7__["ConfirmModal"],
    QuillEditor: _components_QuillEditor_QuillEdtor_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    VueDropzone: _components_VueDropzone__WEBPACK_IMPORTED_MODULE_10__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_9__["default"]],
  data: function data() {
    return {
      activeFooterTabIndex: 0,
      atglAccounts: null,
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      companySetting: null,
      defaultNumbers: null,
      dropzoneOptions: {
        url: "".concat("/UniqApi/v1", "/companysettings/uploadCompanyPageHeaderImage"),
        thumbnailWidth: 128,
        thumbnailHeight: 128,
        addRemoveLinks: true,
        maxFilesize: 5,
        maxFiles: 1,
        acceptedFiles: 'image/*',
        headers: {
          Authorization: ''
        },
        dictDefaultMessage: '<span class="mso mso-36px">cloud_upload</span><br>click or drop your image here',
        dictMaxFilesExceeded: 'You can only upload one file.',
        dictResponseError: 'Failed to upload the image.'
      },
      externalAccoutSetting: [{
        value: 'NONE',
        label: 'None'
      }, {
        value: 'MYOB',
        label: 'MYOB'
      }, {
        value: 'MONEYWORKS',
        label: 'MoneyWorks'
      }],
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['DD/MM/YYYY'],
        data: ['DD/MM/YYYY'],
        dayPopover: null
      },
      glCloseDate: null,
      letterHeaderToPrint: [{
        value: 0,
        label: 'Nothing'
      }, {
        value: 1,
        label: 'Text Header'
      }, {
        value: 2,
        label: 'Graphics Header'
      }],
      isCollectedDropdownActive: false,
      isConfirmModalActive: false
    };
  },
  computed: {
    batchNo: {
      get: function get() {
        var _this$companySetting$, _this$companySetting;
        return (_this$companySetting$ = (_this$companySetting = this.companySetting) === null || _this$companySetting === void 0 ? void 0 : _this$companySetting.batchNo) !== null && _this$companySetting$ !== void 0 ? _this$companySetting$ : null;
      },
      set: function set(newVal) {
        if (!this.companySetting) return;
        this.companySetting.batchNo = newVal == '' || newVal == null ? 0 : newVal;
      }
    },
    canEditNextNumbers: function canEditNextNumbers() {
      return this.$userInfo.isSupportUser === true;
    },
    driveable: {
      get: function get() {
        var _this$companySetting2;
        return (_this$companySetting2 = this.companySetting) === null || _this$companySetting2 === void 0 ? void 0 : _this$companySetting2.driveable;
      },
      set: function set(newVal) {
        if (!newVal) {
          this.companySetting.driveableDefault = false;
        }
        this.companySetting.driveable = newVal;
      }
    },
    gstPeriod: function gstPeriod() {
      if (this.$company.info.countryCode == 'NZ') {
        return [{
          period: 2,
          label: 2
        }, {
          period: 6,
          label: 6
        }];
      }
      return [{
        period: 4,
        label: 4
      }, {
        period: 12,
        label: 12
      }];
    },
    pageHeaderImage: function pageHeaderImage() {
      if (!this.companySetting || !this.companySetting.pageHeaderImage) {
        return '';
      }
      return 'data:image/jpg;base64,' + this.companySetting.pageHeaderImage;
    },
    footers: function footers() {
      if (!this.companySetting) {
        return [];
      }
      return [{
        value: this.companySetting.quoteFooter,
        label: 'Quote Footer',
        type: 'quoteFooter'
      }, {
        value: this.companySetting.invoiceFooter,
        label: 'Invoice Footer',
        type: 'invoiceFooter'
      }, {
        value: this.companySetting.statementFooter,
        label: 'Statement Footer',
        type: 'statementFooter'
      }, {
        value: this.companySetting.jobCostingFooter,
        label: 'Job Card Footer',
        type: 'jobCostingFooter'
      }, {
        value: this.companySetting.jobCoverSheetFooter,
        label: 'Job Cover Footer',
        type: 'jobCoverSheetFooter'
      }, {
        value: this.companySetting.partFooter,
        label: 'Parts Footer',
        type: 'partFooter'
      }, {
        value: this.companySetting.purchaseOrderFooter,
        label: 'Order Footer',
        type: 'purchaseOrderFooter'
      }, {
        value: this.companySetting.creditReturnFooter,
        label: 'CR Footer',
        type: 'creditReturnFooter'
      }];
    },
    activeFooter: {
      get: function get() {
        if (!this.footers) return null;
        return this.footers[this.activeFooterTabIndex].value;
      },
      set: function set(newVal) {
        if (!this.footers) return null;
        this.companySetting[this.footers[this.activeFooterTabIndex].type] = newVal;
      }
    }
  },
  watch: {
    defaultNumbers: {
      deep: true,
      handler: function handler(value) {
        if (!value) return;
        for (var i = 0; i < value.length; i++) {
          for (var j = 0; j < value[i].defaultValue.length; j++) {
            this.companySetting[value[i].prefix + value[i].defaultValue[j].type] = value[i].defaultValue[j].value;
          }
        }
      }
    },
    companySetting: {
      deep: true,
      handler: function handler(val) {
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(val)
        });
        this.autoUpdate(val);
        if (!val) {
          this.defaultNumbers = [];
          return;
        }
        this.defaultNumbers = [{
          defaultValue: [{
            label: 'Prefix',
            value: val.quotePrefix,
            type: 'Prefix'
          }, {
            label: 'Suffix',
            value: val.quoteSuffix,
            type: 'Suffix'
          }, {
            label: 'Next No',
            value: val.quoteValue,
            type: 'Value'
          }],
          title: 'Default Quote Number',
          prefix: 'quote'
        }, {
          defaultValue: [{
            label: 'Prefix',
            value: val.invoicePrefix,
            type: 'Prefix'
          }, {
            label: 'Suffix',
            value: val.invoiceSuffix,
            type: 'Suffix'
          }, {
            label: 'Next No',
            value: val.invoiceValue,
            type: 'Value'
          }],
          title: 'Default Invoice Number',
          prefix: 'invoice'
        }, {
          defaultValue: [{
            label: 'Prefix',
            value: val.orderPrefix,
            type: 'Prefix'
          }, {
            label: 'Suffix',
            value: val.orderSuffix,
            type: 'Suffix'
          }, {
            label: 'Next No',
            value: val.orderValue,
            type: 'Value'
          }],
          title: 'Default Order Number',
          prefix: 'order'
        }];
      }
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var _t, _t2;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.$showSpinner();
            _context.n = 1;
            return _this.getCompanyATGLAccounts();
          case 1:
            _this.initializeAutoUpdate();
            _t = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
            _context.n = 2;
            return _this.getStoreItem({
              serviceFunction: 'getEntity'
            });
          case 2:
            _t2 = _context.v;
            _this.companySetting = _t(_t2);
            _this.dropzoneOptions.headers.Authorization = "Bearer ".concat(_services_common__WEBPACK_IMPORTED_MODULE_5__["default"].getAuthToken());
            _this.getGlCloseDate();
            _this.$hideSpinner();
          case 3:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    deleteImage: function deleteImage(deleteConfirmed) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var tmpCompanySetting;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isConfirmModalActive = false;
              if (deleteConfirmed) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _this2.$showSpinner();
              tmpCompanySetting = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(_this2.companySetting);
              tmpCompanySetting.pageHeaderImage = null;
              _this2.saveSnapshot({
                entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default()(tmpCompanySetting)
              });
              _context2.n = 2;
              return _this2.updateCompanySetting(tmpCompanySetting);
            case 2:
              _this2.$hideSpinner();
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    deletePageHeaderImage: function deletePageHeaderImage() {
      this.isConfirmModalActive = true;
    },
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdate === 'function' && typeof this.autoUpdate.cancel === 'function') {
        this.autoUpdate.cancel();
      }
      this.autoUpdate = function () {};
    },
    dropzoneMounted: function dropzoneMounted() {
      this.$refs.pageHeaderImgDropzone.getAcceptedFiles();
    },
    dropzoneSuccess: function dropzoneSuccess(file, response) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var _t3, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.$notification.success('Company Page Header Image', response);
              _t3 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
              _context3.n = 1;
              return _this3.getStoreItem({
                serviceFunction: 'getEntity'
              });
            case 1:
              _t4 = _context3.v;
              _this3.companySetting = _t3(_t4);
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    dropzoneError: function dropzoneError(file, message, xhr) {
      if (message) {
        this.$notification.error('Company Page Header Image', message);
      }
    },
    getCompanyATGLAccounts: function getCompanyATGLAccounts() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_6__["CompanySettingService"].getCompanyATGLAccounts();
            case 1:
              _this4.atglAccounts = _context4.v;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    glCloseDateInputEvent: function glCloseDateInputEvent(date) {
      var dateTime = new Date(date);
      dateTime.setHours(0, 0, 0, 0);
      this.companySetting.glCloseDate = dateTime.toISOString().split('.')[0] + 'Z';
    },
    getGlCloseDate: function getGlCloseDate() {
      if (this.companySetting && this.companySetting.glCloseDate) {
        this.glCloseDate = new Date(this.companySetting.glCloseDate + 'Z');
      }
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this5 = this;
      this.autoUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_4___default()(/*#__PURE__*/function () {
        var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5(value) {
          var _t5;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
            while (1) switch (_context5.n) {
              case 0:
                _t5 = _this5.snapshotDiff;
                if (!_t5) {
                  _context5.n = 1;
                  break;
                }
                _context5.n = 1;
                return _this5.updateCompanySetting(value);
              case 1:
                return _context5.a(2);
            }
          }, _callee5);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    updateCompanySetting: function updateCompanySetting(companySetting) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var _t6, _t7;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              if (_this6.snapshotDiff) {
                _context6.n = 1;
                break;
              }
              return _context6.a(2);
            case 1:
              companySetting.deepDiff = JSON.stringify(_this6.snapshotDiff);
              _t6 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_3___default.a;
              _context6.n = 2;
              return _this6.editStoreItem({
                serviceFunction: 'updateCompanySetting',
                entity: companySetting
              });
            case 2:
              _t7 = _context6.v;
              _this6.companySetting = _t6(_t7);
              if (_this6.toastNotificationEnabled) {
                _this6.openToastNotification();
              }
            case 3:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this7 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            _this7.disableAutoUpdate();
            _this7.toastNotificationEnabled = true;
            _context7.n = 1;
            return _this7.updateCompanySetting(_this7.companySetting);
          case 1:
            _this7.clearSnapshots();
            _this7.toastNotificationEnabled = false;
            next();
          case 2:
            return _context7.a(2);
        }
      }, _callee7);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", {
    ref: "editorContainer",
    staticClass: "quill-editor"
  })]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_vm.companySetting ? _c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_vm._m(0), !_vm.hasError && _vm.showSavingStatus && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()]), _c("div", {
    staticClass: "field columns tile is-child pt-0"
  }, _vm._l(_vm.defaultNumbers, function (defaultNumber, index) {
    return _c("div", {
      key: index,
      staticClass: "column is-one-third pl-0 py-0",
      class: {
        "pr-0": index == _vm.defaultNumbers.length - 1
      }
    }, [_c("p", {
      staticClass: "label"
    }, [_c("span", {
      staticClass: "title is-6"
    }, [_vm._v(_vm._s(defaultNumber.title))])]), _vm._l(defaultNumber.defaultValue, function (item, itemIndex) {
      return _c("div", {
        key: itemIndex,
        staticClass: "columns mb-0 is-flex is-align-items-center"
      }, [_c("div", {
        staticClass: "column pb-2 is-one-quarter"
      }, [_c("div", {
        staticClass: "label"
      }, [_vm._v(_vm._s(item.label))])]), _c("div", {
        staticClass: "column pb-2 is-three-quarters"
      }, [_c("div", {
        staticClass: "control"
      }, [item.type == "Value" ? _c("input", {
        directives: [{
          name: "model",
          rawName: "v-model.number",
          value: item.value,
          expression: "item.value",
          modifiers: {
            number: true
          }
        }],
        staticClass: "input",
        attrs: {
          type: "number",
          min: "0",
          disabled: !_vm.canEditNextNumbers
        },
        domProps: {
          value: item.value
        },
        on: {
          input: function input($event) {
            if ($event.target.composing) return;
            _vm.$set(item, "value", _vm._n($event.target.value));
          },
          blur: function blur($event) {
            return _vm.$forceUpdate();
          }
        }
      }) : _c("input", {
        directives: [{
          name: "model",
          rawName: "v-model",
          value: item.value,
          expression: "item.value"
        }],
        staticClass: "input",
        attrs: {
          type: "text"
        },
        domProps: {
          value: item.value
        },
        on: {
          input: function input($event) {
            if ($event.target.composing) return;
            _vm.$set(item, "value", $event.target.value);
          }
        }
      })])])]);
    })], 2);
  }), 0), !_vm.canEditNextNumbers ? _c("p", {
    staticClass: "help is-size-7 mb-4"
  }, [_vm._v("Next No can only be changed by PartsCheck support.")]) : _vm._e(), _c("div", {
    staticClass: "field columns tile is-child"
  }, [_c("div", {
    staticClass: "column is-half pl-0 py-0"
  }, [_vm._m(1), _c("div", {
    staticClass: "columns mb-0 is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half pb-2 label"
  }, [_vm._v("Next Cr. Return No")]), _c("div", {
    staticClass: "column is-half pb-2"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: _vm.companySetting.returnValue,
      expression: "companySetting.returnValue",
      modifiers: {
        number: true
      }
    }],
    staticClass: "input",
    attrs: {
      type: "number",
      min: "0"
    },
    domProps: {
      value: _vm.companySetting.returnValue
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "returnValue", _vm._n($event.target.value));
      },
      blur: function blur($event) {
        return _vm.$forceUpdate();
      }
    }
  })])])]), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Next Journal No")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.recurringPrefix,
      expression: "companySetting.recurringPrefix"
    }],
    staticClass: "input",
    attrs: {
      type: "text"
    },
    domProps: {
      value: _vm.companySetting.recurringPrefix
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "recurringPrefix", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "column is-half pr-0 py-0"
  }, [_vm._m(2), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half pb-2 label"
  }, [_vm._v("Next No")]), _c("div", {
    staticClass: "column is-half pb-2"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: _vm.batchNo,
      expression: "batchNo",
      modifiers: {
        number: true
      }
    }],
    staticClass: "input",
    attrs: {
      type: "number",
      min: "0"
    },
    domProps: {
      value: _vm.batchNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.batchNo = _vm._n($event.target.value);
      },
      blur: function blur($event) {
        return _vm.$forceUpdate();
      }
    }
  })])])])])]), _c("div", {
    staticClass: "field tile is-child"
  }, [_vm._m(3), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("G/L Acct-Collected")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.gstCollectedAccount,
      expression: "companySetting.gstCollectedAccount"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "gstCollectedAccount", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.atglAccounts, function (atglAccount, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: atglAccount.account
      }
    }, [_vm._v(" " + _vm._s(atglAccount.account) + " " + _vm._s(atglAccount.name) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("G/L Acct-Spent")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.gstSpentAccount,
      expression: "companySetting.gstSpentAccount"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "gstSpentAccount", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.atglAccounts, function (atglAccount, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: atglAccount.account
      }
    }, [_vm._v(" " + _vm._s(atglAccount.account) + " " + _vm._s(atglAccount.name) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("G/L Acct-With-Hd")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.taxWhAccount,
      expression: "companySetting.taxWhAccount"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "taxWhAccount", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.atglAccounts, function (atglAccount, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: atglAccount.account
      }
    }, [_vm._v(" " + _vm._s(atglAccount.account) + " " + _vm._s(atglAccount.name) + " ")]);
  })], 2)])])])])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Accounting Basis")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.gstBasis,
      expression: "companySetting.gstBasis"
    }],
    staticClass: "input",
    domProps: {
      value: _vm.companySetting.gstBasis
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "gstBasis", $event.target.value);
      }
    }
  })])])]), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Accounting Periods")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.gstPeriod,
      expression: "companySetting.gstPeriod"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "gstPeriod", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "0",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.gstPeriod, function (period, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: period.period
      }
    }, [_vm._v(" " + _vm._s(period.label) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("label", {
    staticClass: "column is-half label"
  }, [_vm._v("Previous Closing Date")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("v-date-picker", {
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.glCloseDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons mb-0"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("span", {
          staticClass: "mso mso-18px"
        }, [_vm._v("calendar_month")])])])])];
      }
    }], null, false, 2877715408),
    model: {
      value: _vm.glCloseDate,
      callback: function callback($$v) {
        _vm.glCloseDate = $$v;
      },
      expression: "glCloseDate"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "field columns tile is-child"
  }, [_c("div", {
    staticClass: "column is-half pl-0 py-0"
  }, [_vm._m(4), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("External account type")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.externalAccounting,
      expression: "companySetting.externalAccounting"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "externalAccounting", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _c("option", {
    attrs: {
      value: "NONE"
    }
  }, [_vm._v("None")]), _c("option", {
    attrs: {
      value: "MYOB"
    }
  }, [_vm._v("MYOB")]), _c("option", {
    attrs: {
      value: "MONEYWORKS"
    }
  }, [_vm._v("MoneyWorks")])])])])])])])]), _c("div", {
    staticClass: "field tile is-child"
  }, [_vm._m(5), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label mb-0"
  }, [_vm._v("Print Ruler Line")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.shadow,
      expression: "companySetting.shadow"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.companySetting.shadow) ? _vm._i(_vm.companySetting.shadow, null) > -1 : _vm.companySetting.shadow
    },
    on: {
      change: function change($event) {
        var $$a = _vm.companySetting.shadow,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.companySetting, "shadow", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.companySetting, "shadow", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.companySetting, "shadow", $$c);
        }
      }
    }
  }), _vm._m(6)])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Allow Invoice Previous Month")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.allowInvoicePreviousMonth,
      expression: "companySetting.allowInvoicePreviousMonth"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.companySetting.allowInvoicePreviousMonth) ? _vm._i(_vm.companySetting.allowInvoicePreviousMonth, null) > -1 : _vm.companySetting.allowInvoicePreviousMonth
    },
    on: {
      change: function change($event) {
        var $$a = _vm.companySetting.allowInvoicePreviousMonth,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.companySetting, "allowInvoicePreviousMonth", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.companySetting, "allowInvoicePreviousMonth", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.companySetting, "allowInvoicePreviousMonth", $$c);
        }
      }
    }
  }), _vm._m(7)])])])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label mb-0"
  }, [_vm._v("Show Driveable")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.driveable,
      expression: "driveable"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.driveable) ? _vm._i(_vm.driveable, null) > -1 : _vm.driveable
    },
    on: {
      change: function change($event) {
        var $$a = _vm.driveable,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.driveable = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.driveable = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.driveable = $$c;
        }
      }
    }
  }), _vm._m(8)])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Default Driveable")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("span", {
    staticClass: "mr-1"
  }, [_vm._v(_vm._s(_vm.companySetting.driveableDefault ? "Yes" : "No"))]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.driveableDefault,
      expression: "companySetting.driveableDefault"
    }],
    staticClass: "switch is-rounded",
    attrs: {
      id: "driveableDefault",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.companySetting.driveableDefault) ? _vm._i(_vm.companySetting.driveableDefault, null) > -1 : _vm.companySetting.driveableDefault
    },
    on: {
      change: function change($event) {
        var $$a = _vm.companySetting.driveableDefault,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.companySetting, "driveableDefault", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.companySetting, "driveableDefault", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.companySetting, "driveableDefault", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "driveableDefault"
    }
  })])])])])]), _c("div", {
    staticClass: "field tile is-child"
  }, [_vm._m(9), _c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.address,
      expression: "companySetting.address"
    }],
    staticClass: "textarea",
    attrs: {
      rows: "6"
    },
    domProps: {
      value: _vm.companySetting.address
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companySetting, "address", $event.target.value);
      }
    }
  })]), _c("div", {
    staticClass: "field tile is-child"
  }, [_vm._m(10), _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Head format")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.paperType,
      expression: "companySetting.paperType"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companySetting, "paperType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.letterHeaderToPrint, function (letterHead, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: parseInt(letterHead.value)
      }
    }, [_vm._v(_vm._s(letterHead.label))]);
  })], 2)])])])])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-half label"
  }, [_vm._v("Print on every page")]), _c("div", {
    staticClass: "column is-half"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger is-two-third"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companySetting.printLhOnEveryPage,
      expression: "companySetting.printLhOnEveryPage"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.companySetting.printLhOnEveryPage) ? _vm._i(_vm.companySetting.printLhOnEveryPage, null) > -1 : _vm.companySetting.printLhOnEveryPage
    },
    on: {
      change: function change($event) {
        var $$a = _vm.companySetting.printLhOnEveryPage,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.companySetting, "printLhOnEveryPage", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.companySetting, "printLhOnEveryPage", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.companySetting, "printLhOnEveryPage", $$c);
        }
      }
    }
  }), _vm._m(11)])])])])]), _vm.companySetting.paperType == "2" ? _c("div", [_vm.companySetting.pageHeaderImage ? _c("div", {
    staticClass: "is-flex is-align-items-center"
  }, [_c("img", {
    staticClass: "pageHeaderImg mr-5",
    attrs: {
      src: _vm.pageHeaderImage,
      alt: "Company Letter Header To Print"
    }
  }), _c("button", {
    staticClass: "button has-text-danger",
    attrs: {
      title: "Delete"
    },
    on: {
      click: _vm.deletePageHeaderImage
    }
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("remove")])])]) : _c("div", [_c("vue-dropzone", {
    ref: "pageHeaderImgDropzone",
    attrs: {
      id: "pageHeaderImgDropzone",
      options: _vm.dropzoneOptions
    },
    on: {
      "vdropzone-mounted": _vm.dropzoneMounted,
      "vdropzone-success": _vm.dropzoneSuccess,
      "vdropzone-error": _vm.dropzoneError
    }
  })], 1)]) : _vm._e(), _vm.companySetting.pageHeaderImage ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteImage(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteImage(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Company Paper Head Image")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Company Paper Head Image will be deleted. Continue? ")])]) : _vm._e(), _vm.companySetting.paperType == "1" ? _c("div", [_c("div", {
    staticClass: "mb-3"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Company name header")]), _c("quill-editor", {
    model: {
      value: _vm.companySetting.companyNameHeader,
      callback: function callback($$v) {
        _vm.$set(_vm.companySetting, "companyNameHeader", $$v);
      },
      expression: "companySetting.companyNameHeader"
    }
  })], 1), _c("div", [_c("label", {
    staticClass: "label"
  }, [_vm._v("Company page header")]), _c("quill-editor", {
    model: {
      value: _vm.companySetting.pageHeader,
      callback: function callback($$v) {
        _vm.$set(_vm.companySetting, "pageHeader", $$v);
      },
      expression: "companySetting.pageHeader"
    }
  })], 1)]) : _vm._e()], 1), _c("div", {
    staticClass: "field tile is-child"
  }, [_vm._m(12), _c("div", {
    staticClass: "field tabs is-boxed"
  }, [_c("ul", _vm._l(_vm.footers, function (footer, index) {
    return _c("li", {
      key: index,
      class: {
        "is-active": _vm.activeFooterTabIndex === index
      }
    }, [_c("a", {
      on: {
        click: function click($event) {
          _vm.activeFooterTabIndex = index;
        }
      }
    }, [_vm._v(_vm._s(footer.label))])]);
  }), 0)]), _c("div", {
    staticClass: "field"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.activeFooter,
      expression: "activeFooter"
    }],
    staticClass: "textarea",
    attrs: {
      rows: "6"
    },
    domProps: {
      value: _vm.activeFooter
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.activeFooter = $event.target.value;
      }
    }
  })])])]) : _vm._e()]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Preferences")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v("Misc")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("Default Batch Number")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("GST")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("External Accounting")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("Other Settings")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso mso-24px"
  }, [_vm._v("check")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso mso-24px"
  }, [_vm._v("check")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso mso-24px"
  }, [_vm._v("check")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("Email Brief Letterhead")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("Letter Head To Print")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso mso-24px"
  }, [_vm._v("check")]), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("p", {
    staticClass: "label"
  }, [_c("label", {
    staticClass: "title is-6"
  }, [_vm._v("Footer")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".ql-snow .ql-font.ql-picker {\n  width: 140px;\n}\n.ql-snow .ql-size.ql-picker {\n  width: 80px;\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Arial]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Arial]::before {\n  content: \"Arial\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=\"Arial Black\"]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=\"Arial Black\"]::before {\n  content: \"Arial Black\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=\"Comic Sans MS\"]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=\"Comic Sans MS\"]::before {\n  content: \"Comic Sans MS\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=\"Courier New\"]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=\"Courier New\"]::before {\n  content: \"Courier New\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Narrow]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Narrow]::before {\n  content: \"Narrow\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Garamond]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Garamond]::before {\n  content: \"Garamond\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Georgia]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Georgia]::before {\n  content: \"Georgia\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Impact]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Impact]::before {\n  content: \"Impact\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=\"Sans Serif\"]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=\"Sans Serif\"]::before {\n  content: \"Sans Serif\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Serif]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Serif]::before {\n  content: \"Serif\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Tahoma]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Tahoma]::before {\n  content: \"Tahoma\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=\"Trebuchet MS\"]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=\"Trebuchet MS\"]::before {\n  content: \"Trebuchet MS\";\n}\n.ql-snow .ql-picker.ql-font .ql-picker-label[data-value=Verdana]::before,\n.ql-snow .ql-picker.ql-font .ql-picker-item[data-value=Verdana]::before {\n  content: \"Verdana\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"1\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"1\"]::before {\n  content: \"Size 1\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"2\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"2\"]::before {\n  content: \"Size 2\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"3\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"3\"]::before {\n  content: \"Size 3\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"4\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"4\"]::before {\n  content: \"Size 4\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"5\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"5\"]::before {\n  content: \"Size 5\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"6\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"6\"]::before {\n  content: \"Size 6\";\n}\n.ql-snow .ql-picker.ql-size .ql-picker-label[data-value=\"7\"]::before,\n.ql-snow .ql-picker.ql-size .ql-picker-item[data-value=\"7\"]::before {\n  content: \"Size 7\";\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "p.label[data-v-07afe933] {\n  margin-bottom: 1em;\n}\n.tabs a[data-v-07afe933] {\n  padding: 0.1rem 0.5rem;\n}\n.tabs ul[data-v-07afe933] {\n  width: 10em;\n}\n.field.tile.is-child[data-v-07afe933] {\n  padding: 1.25rem;\n  border-bottom: 1px solid var(--border-color);\n}\n.field.tile.is-child[data-v-07afe933]:last-child {\n  border: none;\n}\n.pageHeaderImg[data-v-07afe933] {\n  min-height: 200px;\n  max-height: 300px;\n  min-width: 650px;\n  max-width: 720px;\n}\n#pageHeaderImgDropzone[data-v-07afe933] {\n  background: #f8f9fa;\n  border: 2px dashed #3291ef;\n}\n[data-v-07afe933]::-webkit-scrollbar {\n  width: 10px;\n  height: 10px;\n}\n[data-v-07afe933]::-webkit-scrollbar-thumb {\n  background: #71b3ff;\n  border-radius: 10px;\n}\n[data-v-07afe933]::-webkit-scrollbar-thumb:hover {\n  background: #3291ef;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".dropzone .dz-preview .dz-error-message {\n  top: 150px !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("49786d8a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("147a285e", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("60973536", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/QuillEditor/QuillEdtor.vue":
/*!***************************************************!*\
  !*** ./src/components/QuillEditor/QuillEdtor.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuillEdtor.vue?vue&type=template&id=944e7000 */ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000");
/* harmony import */ var _QuillEdtor_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuillEdtor.vue?vue&type=script&lang=js */ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss */ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuillEdtor_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/QuillEditor/QuillEdtor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuillEdtor.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss":
/*!************************************************************************************************!*\
  !*** ./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=style&index=0&id=944e7000&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_style_index_0_id_944e7000_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000":
/*!*********************************************************************************!*\
  !*** ./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuillEdtor.vue?vue&type=template&id=944e7000 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuillEditor/QuillEdtor.vue?vue&type=template&id=944e7000");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuillEdtor_vue_vue_type_template_id_944e7000__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueDropzone/index.js":
/*!*********************************************!*\
  !*** ./src/components/VueDropzone/index.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// import VueDropzone from './VueDropzone'
var VueDropzone = function VueDropzone(r) {
  return __webpack_require__.e(/*! require.ensure | dropzone-components-chunk */ "dropzone-components-chunk").then((function () {
    return r(__webpack_require__(/*! ./VueDropzone.vue */ "./src/components/VueDropzone/VueDropzone.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
/* harmony default export */ __webpack_exports__["default"] = (VueDropzone);

/***/ }),

/***/ "./src/views/companysetting/CompanyPreferencesSetting.vue":
/*!****************************************************************!*\
  !*** ./src/views/companysetting/CompanyPreferencesSetting.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true */ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true");
/* harmony import */ var _CompanyPreferencesSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyPreferencesSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true */ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true");
/* harmony import */ var _CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss */ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _CompanyPreferencesSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "07afe933",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyPreferencesSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true":
/*!*************************************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=0&id=07afe933&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_0_id_07afe933_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss":
/*!*************************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=style&index=1&id=07afe933&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_style_index_1_id_07afe933_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyPreferencesSetting.vue?vue&type=template&id=07afe933&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyPreferencesSetting_vue_vue_type_template_id_07afe933_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=23.js.map