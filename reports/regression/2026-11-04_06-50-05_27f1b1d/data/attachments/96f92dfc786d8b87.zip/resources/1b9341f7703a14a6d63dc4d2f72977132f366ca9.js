(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _regeneratorValues; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ "./node_modules/core-js/modules/es.error.cause.js");
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");








function _regeneratorValues(e) {
  if (null != e) {
    var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"],
      r = 0;
    if (t) return t.call(e);
    if ("function" == typeof e.next) return e;
    if (!isNaN(e.length)) return {
      next: function next() {
        return e && r >= e.length && (e = void 0), {
          value: e && e[r++],
          done: !e
        };
      }
    };
  }
  throw new TypeError(Object(_typeof_js__WEBPACK_IMPORTED_MODULE_7__["default"])(e) + " is not iterable");
}


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js */ "./node_modules/@babel/runtime/helpers/esm/regeneratorValues.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/utils/CalendarFunctions */ "./src/components/utils/CalendarFunctions.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");






























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyMonthlySetting',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_28__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_25__["ConfirmModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_27__["default"]],
  data: function data() {
    return {
      companySetting: {},
      innerCompanySetting: {},
      isConfirmModalActive: false,
      isUnsavedModalActive: false,
      selectedFiscalYear: null,
      avgWorkingDays: 0,
      yearlyTarget: 0,
      months: {
        1: 'January',
        2: 'February',
        3: 'March',
        4: 'April',
        5: 'May',
        6: 'June',
        7: 'July',
        8: 'August',
        9: 'September',
        10: 'October',
        11: 'November',
        12: 'December'
      },
      fiscalYearList: [],
      fiscalYear: null,
      nextFiscalYear: null,
      dailyTarget: 0,
      targetMode: 'Daily',
      entity: null,
      isNew: false
    };
  },
  computed: {
    fiscalStart: function fiscalStart() {
      return this.innerCompanySetting.fiscalStart;
    },
    fiscalDuration: function fiscalDuration() {
      return this.innerCompanySetting.fiscalDuration;
    },
    showDelete: function showDelete() {
      var length = this.fiscalYearList.length;
      if (length === 0) return false;
      var index = this.fiscalYearList.indexOf(this.fiscalYear);
      return index === length - 1;
    },
    showCancel: function showCancel() {
      return this.entity && this.entity.length !== 0;
    },
    disableMonthlyTarget: function disableMonthlyTarget() {
      return this.targetMode === 'Daily';
    }
  },
  watch: {
    companySetting: {
      handler: function handler(val) {
        this.innerCompanySetting = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(val);
      },
      deep: true
    },
    entity: {
      handler: function handler(val) {
        if (val === null) this.yearlyTarget = 0;
        this.updateMonthMonthlyTarget();
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(val)
        });
        this.autoUpdateFiscalSetting(val);
      },
      deep: true
    },
    fiscalStart: function fiscalStart() {
      this.getNextFiscalYear();
    },
    fiscalDuration: function fiscalDuration() {
      this.getNextFiscalYear();
    },
    fiscalYear: function fiscalYear(newVal) {
      if (!this.isNew && newVal === null) {
        this.reset();
      }
      if (this.isNew) {
        this.selectedFiscalYear = null;
      } else {
        this.selectedFiscalYear = newVal;
      }
    },
    isNew: function isNew(newVal) {
      if (newVal) {
        this.reset();
      } else {
        this.selectedFiscalYear = this.fiscalYear;
      }
    },
    selectedFiscalYear: function selectedFiscalYear(newVal) {
      this.fiscalYear = newVal;
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.$showSpinner();
            _this.initializeAutoUpdate();
            _context.n = 1;
            return _services__WEBPACK_IMPORTED_MODULE_24__["CompanySettingService"].getEntity();
          case 1:
            _this.companySetting = _context.v;
            _context.n = 2;
            return _this.getFiscalYearList();
          case 2:
            _context.n = 3;
            return _this.getCurrentFiscalYear();
          case 3:
            _this.$hideSpinner();
          case 4:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdateFiscalSetting === 'function' && typeof this.autoUpdateFiscalSetting.cancel === 'function') {
        this.autoUpdateFiscalSetting.cancel();
      }
      this.autoUpdateFiscalSetting = function () {};
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this2 = this;
      this.autoUpdateFiscalSetting = lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default()(/*#__PURE__*/function () {
        var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee2(value) {
          var _t;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context2) {
            while (1) switch (_context2.n) {
              case 0:
                _t = _this2.snapshotDiff;
                if (!_t) {
                  _context2.n = 1;
                  break;
                }
                _context2.n = 1;
                return _this2.updateFiscalSetting(value);
              case 1:
                return _context2.a(2);
            }
          }, _callee2);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    updateFiscalSetting: function updateFiscalSetting(fiscalSetting) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee3() {
        var _iterator, _step, _loop, _t2, _t3, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              if (_this3.snapshotDiff) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              if (_this3.targetMode === 'Yearly') {
                _this3.entity.forEach(function (i) {
                  return i.dailyTarget = null;
                });
              }
              _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_2__["default"])(fiscalSetting);
              _context4.p = 2;
              _loop = /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _loop() {
                var item, _this3$baseSnapshot$f, _this3$baseSnapshot$f2, baseItem, diff;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context3) {
                  while (1) switch (_context3.n) {
                    case 0:
                      item = _step.value;
                      _this3$baseSnapshot$f = _this3.baseSnapshot.filter(function (i) {
                        return i.companyMonthlySettingId == item.companyMonthlySettingId;
                      }), _this3$baseSnapshot$f2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this3$baseSnapshot$f, 1), baseItem = _this3$baseSnapshot$f2[0];
                      diff = deep_diff__WEBPACK_IMPORTED_MODULE_21__["DeepDiff"].diff(baseItem, item);
                      item.deepDiff = diff ? JSON.stringify(diff) : null;
                    case 1:
                      return _context3.a(2);
                  }
                }, _loop);
              });
              _iterator.s();
            case 3:
              if ((_step = _iterator.n()).done) {
                _context4.n = 5;
                break;
              }
              return _context4.d(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regeneratorValues_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_loop()), 4);
            case 4:
              _context4.n = 3;
              break;
            case 5:
              _context4.n = 7;
              break;
            case 6:
              _context4.p = 6;
              _t2 = _context4.v;
              _iterator.e(_t2);
            case 7:
              _context4.p = 7;
              _iterator.f();
              return _context4.f(7);
            case 8:
              _context4.n = 9;
              return _this3.editStoreItem({
                serviceFunction: 'putMonthlySettingEntity',
                entity: fiscalSetting,
                params: _this3.entity[0].year
              });
            case 9:
              _t3 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context4.n = 10;
              return _this3.getStoreItem({
                serviceFunction: 'getCompanyMonthlySettingByFY',
                params: _this3.fiscalYear
              });
            case 10:
              _t4 = _context4.v;
              _this3.entity = _t3(_t4);
              _this3.getNextFiscalYear();
              if (_this3.toastNotificationEnabled) {
                _this3.openToastNotification();
              }
            case 11:
              return _context4.a(2);
          }
        }, _callee3, null, [[2, 6, 7, 8]]);
      }))();
    },
    updateCompanySetting: function updateCompanySetting() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee4() {
        var companySettingDiff, _t5, _t6;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              companySettingDiff = deep_diff__WEBPACK_IMPORTED_MODULE_21__["DeepDiff"].diff(_this4.innerCompanySetting, _this4.companySetting);
              if (companySettingDiff) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              _this4.companySetting.deepDiff = JSON.stringify(companySettingDiff);
              _t5 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context5.n = 2;
              return _this4.editStoreItem({
                serviceFunction: 'updateCompanySetting',
                entity: _this4.innerCompanySetting
              });
            case 2:
              _t6 = _context5.v;
              _this4.companySetting = _t5(_t6);
            case 3:
              return _context5.a(2);
          }
        }, _callee4);
      }))();
    },
    createFiscalYear: function createFiscalYear() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee5() {
        var dateFrom, dateTo, _yield$_this5$getLast, _yield$_this5$getLast2, lastMonth, lastYear, _yield$getFiscalYearD, _yield$getFiscalYearD2, newEntities, currentDate, month, year, model, _t7, _t8;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this5.$showSpinner();
              if (!(_this5.fiscalYearList.length == 0)) {
                _context6.n = 1;
                break;
              }
              _context6.n = 1;
              return _this5.updateCompanySetting();
            case 1:
              _this5.isNew = true;
              dateFrom = new Date();
              dateTo = new Date();
              if (!(_this5.fiscalYearList.length !== 0)) {
                _context6.n = 3;
                break;
              }
              _context6.n = 2;
              return _this5.getLastFiscalYear();
            case 2:
              _yield$_this5$getLast = _context6.v;
              _yield$_this5$getLast2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_yield$_this5$getLast, 2);
              lastMonth = _yield$_this5$getLast2[0];
              lastYear = _yield$_this5$getLast2[1];
              // javascript month is start with 0
              dateFrom = new Date(lastYear, lastMonth);
              dateTo = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["addMonthsToDate"])(dateFrom, _this5.fiscalDuration - 1);
              _context6.n = 5;
              break;
            case 3:
              ;
              _context6.n = 4;
              return Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["getFiscalYearDates"])(_this5.fiscalStart, _this5.fiscalDuration, true);
            case 4:
              _yield$getFiscalYearD = _context6.v;
              _yield$getFiscalYearD2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_yield$getFiscalYearD, 2);
              dateFrom = _yield$getFiscalYearD2[0];
              dateTo = _yield$getFiscalYearD2[1];
            case 5:
              _this5.fiscalYear = _this5.nextFiscalYear.toString();
              newEntities = [];
              for (currentDate = new Date(dateFrom); currentDate <= dateTo; currentDate.setMonth(currentDate.getMonth() + 1)) {
                // Extract month and year from the current date
                month = currentDate.toLocaleString('default', {
                  month: 'numeric'
                });
                year = currentDate.getFullYear();
                model = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_26__["CompanyMonthlySettingModel"](_this5.$userInfo.companyId, _this5.nextFiscalYear, year, month);
                newEntities.push(model);
              }
              _t7 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context6.n = 6;
              return _this5.editStoreItem({
                serviceFunction: 'postMonthlySettingEntity',
                entity: newEntities
              });
            case 6:
              _t8 = _context6.v;
              _this5.entity = _t7(_t8);
              _this5.fiscalYearList.push(_this5.fiscalYear);
              _this5.$hideSpinner();
            case 7:
              return _context6.a(2);
          }
        }, _callee5);
      }))();
    },
    deleteFiscalYearSetting: function deleteFiscalYearSetting() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee6() {
        var index;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this6.entity.forEach(function (item) {
                var baseItem = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(item);
                item.isDeleted = true;
                var diff = deep_diff__WEBPACK_IMPORTED_MODULE_21__["DeepDiff"].diff(baseItem, item);
                item.deepDiff = diff ? JSON.stringify(diff) : null;
              });
              _context7.n = 1;
              return _this6.editStoreItem({
                serviceFunction: 'putMonthlySettingEntity',
                entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default()(_this6.entity),
                params: _this6.entity[0].year
              });
            case 1:
              index = _this6.fiscalYearList.indexOf(_this6.fiscalYear);
              if (index !== -1) {
                _this6.fiscalYearList.splice(index, 1);
              }
              _this6.entity = null;
              _this6.targetMode = 'Daily';
              _this6.fiscalYear = null;
              _this6.isConfirmModalActive = false;
              _this6.getNextFiscalYear();
              _this6.isNew = false;
            case 2:
              return _context7.a(2);
          }
        }, _callee6);
      }))();
    },
    getMonthlyEntity: function getMonthlyEntity(fiscalYear) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this7.avgWorkingDays = 0;
              _this7.fiscalYear = fiscalYear;
              _this7.getFiscalSetting();
            case 1:
              return _context8.a(2);
          }
        }, _callee7);
      }))();
    },
    deleteFiscalYear: function deleteFiscalYear() {
      this.isConfirmModalActive = true;
    },
    cancel: function cancel() {
      this.isNew = false;
      this.entity = null;
      this.targetMode = 'Daily';
      this.fiscalYear = null;
      this.action = null;
      this.dailyTarget = 0;
    },
    cancelModel: function cancelModel() {
      this.closeModal();
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        this.toRoute = null;
      }
    },
    closeModal: function closeModal() {
      if (!this.isSkipSave && !this.isSaveContinue && this.action !== 'routeLeave') {
        this.fiscalYear = this.entity ? this.entity[0].fiscalYearName.toString() : null;
      }
      this.isConfirmModalActive = false;
      this.isUnsavedModalActive = false;
      this.isSaveContinue = false;
      this.isSkipSave = false;
    },
    reset: function reset() {
      this.selectedFiscalYear = null;
      this.avgWorkingDays = 0;
      this.yearlyTarget = 0;
      this.dailyTarget = 0;
    },
    changeTargetMode: function changeTargetMode() {
      if (this.targetMode === 'Daily') {
        var totalWorkingDays = this.entity.reduce(function (sum, month) {
          sum += month.workingDays || 0;
          return sum;
        }, 0);
        if (totalWorkingDays !== 0) {
          var dailyTarget = this.yearlyTarget / totalWorkingDays;
          this.dailyTarget = dailyTarget;
          this.entity.forEach(function (month) {
            month.dailyTarget = dailyTarget;
          });
        }
      }
    },
    updateDailyTarget: function updateDailyTarget(dailyTarget) {
      this.entity.forEach(function (month) {
        month.dailyTarget = dailyTarget;
        month.monthlyTarget = month.workingDays * dailyTarget;
      });
      this.dailyTarget = dailyTarget;
    },
    updateYearlyTarget: function updateYearlyTarget() {
      var totalWorkingDays = this.entity.reduce(function (sum, month) {
        sum += month.workingDays || 0;
        return sum;
      }, 0);
      if (totalWorkingDays !== 0) {
        var dailyTarget = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_22__["roundAwayFromZero"])(this.yearlyTarget / totalWorkingDays, 0);
        this.dailyTarget = 0;
        this.entity.forEach(function (month) {
          month.dailyTarget = null;
          month.monthlyTarget = month.workingDays * dailyTarget;
        });
      }
    },
    updateAvgWorkingDays: function updateAvgWorkingDays(avgWorkingDays) {
      var _this8 = this;
      if (this.targetMode === 'Daily') {
        this.entity.forEach(function (i) {
          i.workingDays = avgWorkingDays;
          i.monthlyTarget = avgWorkingDays * _this8.dailyTarget;
        });
      } else {
        this.entity.forEach(function (i) {
          i.workingDays = avgWorkingDays;
        });
        this.updateYearlyTarget();
      }
    },
    updateMonthWorkingDays: function updateMonthWorkingDays(item) {
      if (this.targetMode === 'Daily') {
        item.monthlyTarget = item.workingDays * this.dailyTarget;
      }
    },
    updateMonthMonthlyTarget: function updateMonthMonthlyTarget() {
      if (this.entity) {
        this.yearlyTarget = this.entity.reduce(function (sum, month) {
          sum += month.monthlyTarget || 0;
          return sum;
        }, 0);
      }
    },
    getMonthAbbr: function getMonthAbbr(number) {
      return Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["getMonthAbbr"])(number);
    },
    getFiscalYearList: function getFiscalYearList() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _context9.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_24__["CompanySettingService"].getFiscalYearList();
            case 1:
              _this9.fiscalYearList = _context9.v;
              _this9.getNextFiscalYear();
            case 2:
              return _context9.a(2);
          }
        }, _callee8);
      }))();
    },
    getNextFiscalYear: function getNextFiscalYear() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee9() {
        var _yield$_this0$getLast, _yield$_this0$getLast2, lastMonth, lastYear, lastFY, fiscalDateStart, _yield$getFiscalYearD3, _yield$getFiscalYearD4, _fiscalDateStart;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              if (!(_this0.fiscalYearList.length !== 0)) {
                _context0.n = 2;
                break;
              }
              _context0.n = 1;
              return _this0.getLastFiscalYear();
            case 1:
              _yield$_this0$getLast = _context0.v;
              _yield$_this0$getLast2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_yield$_this0$getLast, 2);
              lastMonth = _yield$_this0$getLast2[0];
              lastYear = _yield$_this0$getLast2[1];
              lastFY = new Date(lastYear, lastMonth - 1); // zero indexed for month
              fiscalDateStart = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["addMonthsToDate"])(lastFY, 1);
              _this0.nextFiscalYear = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["getFiscalYearName"])(fiscalDateStart, _this0.fiscalDuration);
              _context0.n = 4;
              break;
            case 2:
              _context0.n = 3;
              return Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["getFiscalYearDates"])(_this0.fiscalStart, _this0.fiscalDuration, true);
            case 3:
              _yield$getFiscalYearD3 = _context0.v;
              _yield$getFiscalYearD4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_yield$getFiscalYearD3, 1);
              _fiscalDateStart = _yield$getFiscalYearD4[0];
              _this0.nextFiscalYear = Object(_components_utils_CalendarFunctions__WEBPACK_IMPORTED_MODULE_23__["getFiscalYearName"])(_fiscalDateStart, _this0.fiscalDuration);
            case 4:
              return _context0.a(2);
          }
        }, _callee9);
      }))();
    },
    getCurrentFiscalYear: function getCurrentFiscalYear() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee0() {
        var currentMonth, currentYear;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              currentMonth = new Date().getMonth() + 1; // JavaScript months are zero-indexed
              currentYear = new Date().getFullYear();
              _context1.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_24__["CompanySettingService"].checkExists(currentYear, currentMonth);
            case 1:
              _this1.fiscalYear = _context1.v;
              if (!(_this1.fiscalYear !== null)) {
                _context1.n = 2;
                break;
              }
              _context1.n = 2;
              return _this1.getFiscalSetting();
            case 2:
              return _context1.a(2);
          }
        }, _callee0);
      }))();
    },
    getLastFiscalYear: function getLastFiscalYear() {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee1() {
        var lastFY, lastFYEntity, lastRecord, lastYear, lastMonth, _t9, _t0;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              lastFY = _this10.fiscalYearList[_this10.fiscalYearList.length - 1];
              _t9 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context10.n = 1;
              return _this10.getStoreItem({
                serviceFunction: 'getCompanyMonthlySettingByFY',
                params: lastFY
              });
            case 1:
              _t0 = _context10.v;
              lastFYEntity = _t9(_t0);
              lastRecord = lastFYEntity[lastFYEntity.length - 1];
              lastYear = lastRecord.year;
              lastMonth = lastRecord.month;
              return _context10.a(2, [lastMonth, lastYear]);
          }
        }, _callee1);
      }))();
    },
    getFiscalSetting: function getFiscalSetting() {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee10() {
        var _t1, _t10;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              _this11.$showSpinner('Loading...');
              _t1 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_19___default.a;
              _context11.n = 1;
              return _this11.getStoreItem({
                serviceFunction: 'getCompanyMonthlySettingByFY',
                params: _this11.fiscalYear
              });
            case 1:
              _t10 = _context11.v;
              _this11.entity = _t1(_t10);
              if (_this11.entity && _this11.entity.length > 0) {
                if (_this11.entity[0].dailyTarget === null) {
                  _this11.targetMode = 'Yearly';
                  _this11.dailyTarget = 0;
                } else {
                  _this11.targetMode = 'Daily';
                  _this11.dailyTarget = _this11.entity[0].dailyTarget;
                }
              }
              _this11.isNew = false;
              _this11.$hideSpinner();
            case 2:
              return _context11.a(2);
          }
        }, _callee10);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this12 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee11() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context12) {
        while (1) switch (_context12.n) {
          case 0:
            _this12.disableAutoUpdate();
            _this12.toastNotificationEnabled = true;
            _context12.n = 1;
            return _this12.updateFiscalSetting(_this12.entity);
          case 1:
            _this12.clearSnapshots();
            _this12.toastNotificationEnabled = false;
            next();
          case 2:
            return _context12.a(2);
        }
      }, _callee11);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "is-flex is-align-items-end"
  }, [_vm._m(0), _vm.showSavingStatus && !_vm.hasError && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "control is-flex is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-right"
  }, [_c("button", {
    staticClass: "button is-primary",
    attrs: {
      disabled: _vm.isNew || !_vm.isNew && _vm.entity && _vm.entity.length !== 0
    },
    on: {
      click: _vm.createFiscalYear
    }
  }, [_vm._v("Create FY" + _vm._s(_vm.nextFiscalYear))])])])]), _c("div", {
    staticClass: "columns pb-3"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Fiscal Start Month")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerCompanySetting.fiscalStart,
      expression: "innerCompanySetting.fiscalStart"
    }],
    attrs: {
      disabled: _vm.isNew || _vm.fiscalYearList.length !== 0
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerCompanySetting, "fiscalStart", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("MM")]), _vm._l(_vm.months, function (month, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: key
      }
    }, [_vm._v(_vm._s(month))]);
  })], 2)])])])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Fiscal Duration")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      placeholder: "Fiscal Duration",
      min: 12,
      precision: 0,
      disabled: _vm.isNew || _vm.fiscalYearList.length !== 0
    },
    model: {
      value: _vm.innerCompanySetting.fiscalDuration,
      callback: function callback($$v) {
        _vm.$set(_vm.innerCompanySetting, "fiscalDuration", $$v);
      },
      expression: "innerCompanySetting.fiscalDuration"
    }
  })], 1)])])])])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow pr-5 mr-5"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Fiscal Year")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedFiscalYear,
      expression: "selectedFiscalYear"
    }],
    attrs: {
      disabled: _vm.isNew
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedFiscalYear = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }, function ($event) {
        return _vm.getMonthlyEntity($event.target.value);
      }]
    }
  }, [_c("option", {
    attrs: {
      disabled: ""
    },
    domProps: {
      value: null
    }
  }, [_vm._v("Select")]), _vm._l(_vm.fiscalYearList, function (val, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: val
      }
    }, [_vm._v(_vm._s(val))]);
  })], 2)])])])])]), _c("div", {
    staticClass: "column is-2"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth is-flex is-align-items-top mb-3"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.targetMode,
      expression: "targetMode"
    }],
    attrs: {
      id: "dailyMode",
      type: "radio",
      name: "rd-targetMode",
      disabled: !_vm.isNew && _vm.selectedFiscalYear === null
    },
    domProps: {
      value: "Daily",
      checked: _vm._q(_vm.targetMode, "Daily")
    },
    on: {
      change: [function ($event) {
        _vm.targetMode = "Daily";
      }, _vm.changeTargetMode]
    }
  }), _vm._m(1)]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      placeholder: "Daily Target",
      min: 0,
      precision: 0,
      disabled: !_vm.isNew && _vm.selectedFiscalYear === null || _vm.targetMode === "Yearly",
      symbol: _vm.$company.currency.symbol
    },
    nativeOn: {
      input: function input($event) {
        return _vm.updateDailyTarget(_vm.dailyTarget);
      }
    },
    model: {
      value: _vm.dailyTarget,
      callback: function callback($$v) {
        _vm.dailyTarget = $$v;
      },
      expression: "dailyTarget"
    }
  })], 1)])])]), _c("div", {
    staticClass: "column is-2"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth is-flex is-align-items-top mb-3"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.targetMode,
      expression: "targetMode"
    }],
    attrs: {
      id: "yearlyMode",
      type: "radio",
      name: "rd-targetMode",
      disabled: !_vm.isNew && _vm.selectedFiscalYear === null
    },
    domProps: {
      value: "Yearly",
      checked: _vm._q(_vm.targetMode, "Yearly")
    },
    on: {
      change: [function ($event) {
        _vm.targetMode = "Yearly";
      }, _vm.changeTargetMode]
    }
  }), _vm._m(2)]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      placeholder: "Yearly Target",
      min: 0,
      precision: 0,
      disabled: !_vm.isNew && _vm.selectedFiscalYear === null || _vm.targetMode === "Daily",
      symbol: _vm.$company.currency.symbol
    },
    nativeOn: {
      input: function input($event) {
        return _vm.updateYearlyTarget();
      }
    },
    model: {
      value: _vm.yearlyTarget,
      callback: function callback($$v) {
        _vm.yearlyTarget = $$v;
      },
      expression: "yearlyTarget"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Initial Monthly Working Days")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      placeholder: "Monthly Working Days",
      min: 0,
      precision: 0,
      disabled: !_vm.isNew && _vm.selectedFiscalYear === null
    },
    nativeOn: {
      input: function input($event) {
        return _vm.updateAvgWorkingDays(_vm.avgWorkingDays);
      }
    },
    model: {
      value: _vm.avgWorkingDays,
      callback: function callback($$v) {
        _vm.avgWorkingDays = $$v;
      },
      expression: "avgWorkingDays"
    }
  })], 1)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", [_c("button", {
    staticClass: "button is-danger mr-5",
    attrs: {
      disabled: !_vm.showDelete
    },
    on: {
      click: _vm.deleteFiscalYear
    }
  }, [_vm._v("Delete")]), _c("button", {
    staticClass: "button is-primary",
    attrs: {
      disabled: !_vm.showCancel
    },
    on: {
      click: _vm.cancel
    }
  }, [_vm._v("Cancel")])])]), _vm.entity && _vm.entity.length !== 0 ? _c("div", [_c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.entity && _vm.entity.length !== 0,
      expression: "entity && entity.length !== 0"
    }],
    staticClass: "title is-5"
  }, [_vm._v("FY " + _vm._s(_vm.entity[0].fiscalYearName))]), _c("table", {
    staticClass: "table is-striped is-narrow"
  }, [_vm._m(3), _c("tbody", _vm._l(_vm.entity, function (item, index) {
    return _c("tr", {
      key: index
    }, [_c("td", {
      staticClass: "has-text-weight-bold has-vertical-middle column-min-width no-border"
    }, [_vm._v(" " + _vm._s(_vm.getMonthAbbr(item.month)) + " " + _vm._s(item.year) + " ")]), _c("td", {
      staticClass: "has-vertical-middle has-text-right no-border"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        placeholder: "Working Days",
        min: 0,
        precision: 0
      },
      nativeOn: {
        input: function input($event) {
          return _vm.updateMonthWorkingDays(item);
        }
      },
      model: {
        value: item.workingDays,
        callback: function callback($$v) {
          _vm.$set(item, "workingDays", $$v);
        },
        expression: "item.workingDays"
      }
    })], 1), _c("td", {
      staticClass: "has-vertical-middle has-text-right money-input no-border"
    }, [_c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        placeholder: "Monthly Target",
        min: 0,
        precision: 0,
        symbol: _vm.$company.currency.symbol,
        disabled: _vm.disableMonthlyTarget
      },
      nativeOn: {
        input: function input($event) {
          return _vm.updateMonthMonthlyTarget(item.monthlyTarget);
        }
      },
      model: {
        value: item.monthlyTarget,
        callback: function callback($$v) {
          _vm.$set(item, "monthlyTarget", $$v);
        },
        expression: "item.monthlyTarget"
      }
    })], 1)]);
  }), 0), _c("template", {
    slot: "empty"
  }, [_vm._m(4)])], 2)]) : _vm._e()])]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: _vm.deleteFiscalYearSetting,
      cancel: _vm.cancelModel
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete FY" + _vm._s(_vm.fiscalYear))]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v("FY" + _vm._s(_vm.fiscalYear))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "control mr-2"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Shop Targets")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", {
    staticClass: "label has-text-weight-bold"
  }, [_vm._v("Daily Target")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", {
    staticStyle: {
      "font-size": "14px",
      "font-weight": "bold"
    }
  }, [_vm._v("Yearly Target")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("thead", [_c("tr", [_c("th", {
    staticClass: "no-border"
  }, [_vm._v(" ")]), _c("th", {
    staticClass: "has-text-centered no-border"
  }, [_vm._v("Working Days")]), _c("th", {
    staticClass: "has-text-centered no-border"
  }, [_vm._v("Monthly Target")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("span", {
    staticClass: "mso mso-fill mso-40px"
  }, [_vm._v("sentiment_dissatisfied")])]), _c("p", [_vm._v("Nothing")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".no-border[data-v-f3c97b02] {\n  border: none;\n}\n.column-min-width[data-v-f3c97b02] {\n  min-width: 8em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5ca9a959", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/utils/CalendarFunctions.js":
/*!***************************************************!*\
  !*** ./src/components/utils/CalendarFunctions.js ***!
  \***************************************************/
/*! exports provided: getFiscalYearName, addMonthsToDate, getThisMonthDates, getMonthName, getMonthAbbr, getFiscalYearDates, getFiscalYearDates_UpToToday */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearName", function() { return getFiscalYearName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addMonthsToDate", function() { return addMonthsToDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getThisMonthDates", function() { return getThisMonthDates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMonthName", function() { return getMonthName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMonthAbbr", function() { return getMonthAbbr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearDates", function() { return getFiscalYearDates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFiscalYearDates_UpToToday", function() { return getFiscalYearDates_UpToToday; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_4__);





function getFiscalYearName(fiscalStartDate, fiscalDuration) {
  // Extract month and year from currentDate
  var currentMonth = fiscalStartDate.getMonth(); // JavaScript months are zero-indexed
  var currentYear = fiscalStartDate.getFullYear();
  fiscalStartDate = new Date(currentYear, currentMonth);
  var dateTo = addMonthsToDate(fiscalStartDate, fiscalDuration - 1);
  var fiscalStartYear, fiscalEndYear;
  fiscalStartYear = fiscalStartDate.getFullYear();
  fiscalEndYear = dateTo.getFullYear();

  // Format fiscal year as needed
  var fiscalYear;
  if (fiscalStartYear === fiscalEndYear) {
    fiscalYear = fiscalStartYear.toString(); // Output single year
  } else {
    fiscalYear = "".concat(fiscalStartYear, "-").concat(fiscalEndYear.toString().slice(2));
  }
  return fiscalYear;
}
function addMonthsToDate(date, monthsToAdd) {
  // Clone the original date to avoid modifying it directly
  var newDate = new Date(date);

  // Add the specified number of months
  newDate.setMonth(newDate.getMonth() + monthsToAdd);
  return newDate;
}
function getThisMonthDates() {
  var today = new Date();
  var firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  var lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  firstDayOfMonth = new Date(firstDayOfMonth.setHours(0, 0, 0, 0));
  lastDayOfMonth = new Date(lastDayOfMonth.setHours(0, 0, 0, 0));
  return [firstDayOfMonth, lastDayOfMonth];
}
function getMonthName(monthNumber) {
  return luxon__WEBPACK_IMPORTED_MODULE_4__["DateTime"].local().set({
    month: monthNumber
  }).monthLong;
}
function getMonthAbbr(monthNumber) {
  return luxon__WEBPACK_IMPORTED_MODULE_4__["DateTime"].local().set({
    month: monthNumber
  }).monthShort;
}

// get Fiscal Year Dates, passing isLastDayOfFY to indicate get up to today's date or last day of FY
function getFiscalYearDates(fiscalStart, fiscalDuration) {
  var isLastDayOfFY = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  var fiscalStartMonth = fiscalStart - 1;
  var fiscalYearStartDate = new Date(new Date().getFullYear(), fiscalStartMonth, 1);
  var today = new Date(); // Initialize current date
  var dateTo = today;
  var todayYear = today.getFullYear();
  var yearStartYear = fiscalYearStartDate.getFullYear();
  if (today < fiscalYearStartDate || todayYear !== yearStartYear) fiscalYearStartDate.setFullYear(fiscalYearStartDate.getFullYear() - 1);

  // add duration to start date to get date to
  if (isLastDayOfFY) {
    dateTo = new Date(fiscalYearStartDate);
    dateTo = new Date(dateTo.setMonth(dateTo.getMonth() + fiscalDuration));

    // Set the date to the last day
    dateTo.setDate(0);
  }
  fiscalYearStartDate = new Date(fiscalYearStartDate.setHours(0, 0, 0, 0));
  dateTo = new Date(dateTo.setHours(0, 0, 0, 0));
  return [fiscalYearStartDate, dateTo];
}

// get fiscal year dates up to today's date
function getFiscalYearDates_UpToToday(fiscalStart) {
  var fiscalStartMonth = fiscalStart - 1;
  var fiscalYearStartDate = new Date(new Date().getFullYear(), fiscalStartMonth, 1);
  var today = new Date(); // Initialize current date

  // Check if today is before the fiscal year start date
  if (today < fiscalYearStartDate) {
    fiscalYearStartDate.setFullYear(today.getFullYear() - 1); // If so, adjust fiscal year start date to previous year
  }

  // Set time part of dates to 00:00:00
  fiscalYearStartDate = new Date(fiscalYearStartDate.setHours(0, 0, 0, 0));
  today = new Date(today.setHours(0, 0, 0, 0));
  return [fiscalYearStartDate, today];
}

// function getLastDayOfFiscalYear(fiscalStartMonth, fiscalDuration) {
//   const currentDate = new Date() // Assuming this is the current date

//   // Determine the fiscal year start date
//   let fiscalYearStartDate
//   if (fiscalStartMonth === 1) {
//     fiscalYearStartDate = new Date(currentDate.getFullYear(), 0, 1)
//   } else {
//     fiscalYearStartDate = new Date(currentDate.getFullYear(), fiscalStartMonth - 1, 1)
//   }

//   // Add the fiscal duration to find the fiscal year end date
//   let fiscalYearEndDate = new Date(fiscalYearStartDate.getFullYear(), fiscalYearStartDate.getMonth() + fiscalDuration, 0)
//   return fiscalYearEndDate
// }

/***/ }),

/***/ "./src/views/companysetting/CompanyShopTargetsSetting.vue":
/*!****************************************************************!*\
  !*** ./src/views/companysetting/CompanyShopTargetsSetting.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true */ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true");
/* harmony import */ var _CompanyShopTargetsSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyShopTargetsSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true */ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _CompanyShopTargetsSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "f3c97b02",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyShopTargetsSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js":
/*!****************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyShopTargetsSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true":
/*!*************************************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=style&index=0&id=f3c97b02&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_style_index_0_id_f3c97b02_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyShopTargetsSetting.vue?vue&type=template&id=f3c97b02&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyShopTargetsSetting_vue_vue_type_template_id_f3c97b02_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=33.js.map