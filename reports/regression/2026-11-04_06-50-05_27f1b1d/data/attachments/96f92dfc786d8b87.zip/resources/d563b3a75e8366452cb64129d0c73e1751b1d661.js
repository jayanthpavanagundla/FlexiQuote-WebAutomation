(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["client-tool-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _ClientToolService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ClientToolService */ "./src/views/clienttool/ClientToolService.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ClientTool',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_10__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_15__["ConfirmModal"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_11__["DateTimeFiltersMixin"]],
  data: function data() {
    return {
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      devices: [],
      isConfirmModalActive: false,
      device: null,
      isLoading: false
    };
  },
  computed: {
    canManage: function canManage() {
      return this.$userInfo.isSupportUser;
    },
    activeDevices: function activeDevices() {
      return this.devices.filter(function (d) {
        return d.active;
      });
    }
  },
  created: function created() {
    this.getClientToolDevices();
  },
  validations: {
    devices: {
      $each: {
        deviceId: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__["required"]
        },
        deviceName: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__["required"]
        },
        deviceInformation: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__["required"]
        },
        registeredDate: {
          required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_13__["required"]
        }
      }
    }
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_12__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_12__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_12__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_12__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_12__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    getClientToolDevices: function getClientToolDevices() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              // this.devices.splice(this.devices.length, 1, {
              //   deviceName: 'TONY-PC',
              //   deviceId: 'EJPPG-VMDOZ-BAQYU-NKLGA-HKBSA-UFXCA-PRVUT-LJTGK-JIWVJ-OBQAT-QMNFN-SXTWA',
              //   deviceInformation: 'Windows 10 Pro',
              //   registeredDate: '2019-09-17T14:00:00Z',
              //   selectedDate: new Date('2019-09-17T14:00:00Z'),
              //   isEdit: false
              // })
              // this.devices.splice(this.devices.length, 1, {
              //   deviceName: 'TANYA-PC',
              //   deviceId: 'EJPPG-VMDOZ-BAQYU-NKLGA-HKBSA-UFXCA-PRVUT-LJTGK-JIWVJ-OBQAT-QMNFN-SXTWB',
              //   deviceInformation: 'Windows 10 Pro',
              //   registeredDate: '2019-09-19T14:00:00Z',
              //   selectedDate: new Date('2019-09-19T14:00:00Z'),
              //   isEdit: false
              // })
              // this.devices.splice(this.devices.length, 1, {
              //   deviceName: 'HAROLD-PC',
              //   deviceId: 'EJPPG-VMDOZ-BAQYU-NKLGA-HKBSA-UFXCA-PRVUT-LJTGK-JIWVJ-OBQAT-QMNFN-SXTWC',
              //   deviceInformation: 'Windows 10 Pro',
              //   registeredDate: '2019-09-18T14:00:00Z',
              //   selectedDate: new Date('2019-09-18T14:00:00Z'),
              //   isEdit: false
              // })
              _this.isLoading = true;
              _context.n = 1;
              return _ClientToolService__WEBPACK_IMPORTED_MODULE_14__["default"].getDevices(_this.$userInfo.companyId);
            case 1:
              _this.devices = _context.v;
              console.log(_this.devices);
              _this.devices.forEach(function (d) {
                return d.selectedDate = new Date(d.registeredDate);
              });
              _this.isLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    toggleEdit: function toggleEdit(index, device) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var response, _response;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              device.isEdit = !device.isEdit;
              if (device.isEdit) {
                _context2.n = 5;
                break;
              }
              // Save device changes
              _this2.$v.devices.$touch();
              console.log('Saving', device);
              if (!(!device.deviceName || !device.deviceId || !device.deviceInformation)) {
                _context2.n = 1;
                break;
              }
              _this2.$notification.openNotificationWithType('danger', 'Client Tool', 'Validation errors. Please fix before saving');
              device.isEdit = true;
              _context2.n = 5;
              break;
            case 1:
              device.deviceId = device.deviceId.toUpperCase();
              device.deviceName = device.deviceName.toUpperCase();
              device.registeredDate = device.selectedDate.toISOString().split('.')[0] + 'Z';
              if (!device.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _ClientToolService__WEBPACK_IMPORTED_MODULE_14__["default"].insertDevice(device);
            case 2:
              response = _context2.v;
              response.data.selectedDate = new Date(response.data.registeredDate);
              _this2.devices.splice(index, 1, response.data);
              console.log('insert', response);
              _this2.$notification.openNotificationWithType('success', 'Client Tool', 'New device registration added');
              _context2.n = 5;
              break;
            case 3:
              _context2.n = 4;
              return _ClientToolService__WEBPACK_IMPORTED_MODULE_14__["default"].saveDevice(device);
            case 4:
              _response = _context2.v;
              _this2.$notification.openNotificationWithType('success', 'Client Tool', 'Device registration saved');
              // this.devices.splice(index, 1, response.data)
              console.log('insert', _response);
            case 5:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    addNew: function addNew() {
      var utcDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).toISOString();
      var newDevice = {
        id: this.$guid.newGuid(),
        companyId: this.$userInfo.companyId,
        deviceId: '',
        deviceName: '',
        deviceInformation: '',
        registeredDate: utcDate.split('.')[0] + 'Z',
        active: true,
        selectedDate: new Date(utcDate),
        isEdit: true,
        isNew: true
      };
      this.devices.splice(this.devices.length, 1, newDevice);
    },
    deleteDevice: function deleteDevice(index, device) {
      this.device = device;
      if (device.isNew) {
        this.devices.splice(index, 1);
      } else {
        this.isConfirmModalActive = true;
      }
    },
    deleteEntity: function deleteEntity(confirmDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var response, index;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!confirmDelete) {
                _context3.n = 2;
                break;
              }
              _this3.device.active = false;
              _context3.n = 1;
              return _ClientToolService__WEBPACK_IMPORTED_MODULE_14__["default"].saveDevice(_this3.device);
            case 1:
              response = _context3.v;
              console.log('delete', response);
              index = _this3.devices.findIndex(function (d) {
                return d.id === _this3.device.id;
              });
              _this3.devices.splice(index, 1);
              _this3.device = null;
              _this3.$notification.openNotificationWithType('success', 'Client Tool', 'Device has been de-registered');
            case 2:
              _this3.device = null;
            case 3:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": false,
      "show-new": _vm.canManage,
      "show-print": false,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_vm.activeDevices.length === 0 && !_vm.isLoading ? _c("div", {
    staticClass: "tile is-parent"
  }, [_vm._m(0)]) : _c("div", {
    staticClass: "tile is-parent"
  }, [_c("div", {
    staticClass: "columns is-multiline"
  }, _vm._l(_vm.activeDevices, function (device, index) {
    return _c("div", {
      key: index,
      staticClass: "column is-narrow"
    }, [device ? _c("div", {
      staticClass: "card"
    }, [_c("header", {
      staticClass: "card-header"
    }, [_c("p", {
      staticClass: "card-header-title"
    }, [!device.isEdit ? _c("span", {
      staticClass: "is-uppercase"
    }, [_vm._v(_vm._s(device.deviceName))]) : _c("span", {
      staticStyle: {
        width: "100%"
      }
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: device.deviceName,
        expression: "device.deviceName"
      }],
      staticClass: "input is-uppercase",
      class: {
        "is-static": !device.isEdit,
        "is-danger": _vm.$v.devices.$each[index].deviceName.$error
      },
      attrs: {
        readonly: !device.isEdit,
        placeholder: "Device Name"
      },
      domProps: {
        value: device.deviceName
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(device, "deviceName", $event.target.value);
        }
      }
    }), _vm.$v.devices.$each[index].deviceName.$dirty && !_vm.$v.devices.$each[index].deviceName.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Device Name is required.")]) : _vm._e()])]), _vm.canManage ? _c("div", {
      staticClass: "buttons",
      staticStyle: {
        "margin-right": "5px",
        "margin-top": "-5px"
      }
    }, [_c("a", {
      staticClass: "has-text-primary is-outlined",
      on: {
        click: function click($event) {
          return _vm.toggleEdit(index, device);
        }
      }
    }, [_c("span", {
      staticClass: "icon"
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [device.isEdit ? "mdi-content-save" : "mdi-lead-pencil"],
      attrs: {
        "aria-hidden": "true"
      }
    })])]), _c("a", {
      staticClass: "has-text-danger is-outlined",
      on: {
        click: function click($event) {
          return _vm.deleteDevice(index, device);
        }
      }
    }, [_vm._m(1, true)])]) : _vm._e()]), _c("div", {
      staticClass: "card-content"
    }, [_c("div", {
      staticClass: "content"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label is-small"
    }, [_vm._v("Device ID")]), _c("div", {
      staticClass: "control"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: device.deviceId,
        expression: "device.deviceId"
      }],
      staticClass: "input is-small deviceid-input-small is-uppercase",
      class: {
        "is-static": !device.isEdit,
        "is-danger": _vm.$v.devices.$each[index].deviceId.$error
      },
      attrs: {
        readonly: !device.isEdit,
        placeholder: "Device ID"
      },
      domProps: {
        value: device.deviceId
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(device, "deviceId", $event.target.value);
        }
      }
    }), _vm.$v.devices.$each[index].deviceId.$dirty && !_vm.$v.devices.$each[index].deviceId.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Device ID is required.")]) : _vm._e()])]), _c("div", {
      staticClass: "field"
    }, [_c("div", {
      staticClass: "field-body"
    }, [_c("div", {
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label is-small"
    }, [_vm._v("Device Information")]), _c("div", {
      staticClass: "control"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: device.deviceInformation,
        expression: "device.deviceInformation"
      }],
      staticClass: "input is-small",
      class: {
        "is-static": !device.isEdit,
        "is-danger": _vm.$v.devices.$each[index].deviceInformation.$error
      },
      attrs: {
        readonly: !device.isEdit,
        placeholder: "Device ID"
      },
      domProps: {
        value: device.deviceInformation
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(device, "deviceInformation", $event.target.value);
        }
      }
    }), _vm.$v.devices.$each[index].deviceInformation.$dirty && !_vm.$v.devices.$each[index].deviceInformation.required ? _c("span", {
      staticClass: "help is-danger"
    }, [_vm._v("Device Information is required.")]) : _vm._e()])]), !device.isEdit ? _c("div", {
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label is-small"
    }, [_vm._v("Registered Date")]), _c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "is-size-7"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(device.registeredDate, _vm.$userInfo.locale)))])])]) : _c("div", {
      staticClass: "field"
    }, [_c("label", {
      staticClass: "label is-small"
    }, [_vm._v("Registered Date")]), _c("v-date-picker", {
      attrs: {
        "is-dark": _vm.$theme.isDark,
        masks: _vm.formats,
        attributes: _vm.attrs,
        locale: _vm.$userInfo.locale,
        disabled: !device.isEdit
      },
      scopedSlots: _vm._u([{
        key: "default",
        fn: function fn(_ref) {
          var inputValue = _ref.inputValue,
            inputEvents = _ref.inputEvents;
          return [_c("div", {
            staticClass: "field"
          }, [_c("div", {
            staticClass: "control has-icons-left"
          }, [_c("input", _vm._g({
            staticClass: "input is-small",
            attrs: {
              type: "text",
              placeholder: "Registered Date"
            },
            domProps: {
              value: inputValue
            }
          }, inputEvents)), _c("span", {
            staticClass: "icon is-small is-left"
          }, [_c("i", {
            staticClass: "mdi mdi-calendar mdi-18px"
          })])])])];
        }
      }], null, true),
      model: {
        value: device.selectedDate,
        callback: function callback($$v) {
          _vm.$set(device, "selectedDate", $$v);
        },
        expression: "device.selectedDate"
      }
    })], 1)])])])])]) : _vm._e()]);
  }), 0)])]), _vm.device ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.deleteEntity(true);
      },
      cancel: function cancel($event) {
        return _vm.deleteEntity(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Device Registration")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Device "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.device.deviceName)))]), _vm._v(" will be de-registered. Continue? ")])]) : _vm._e()], 1) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-vertical is-12"
  }, [_c("div", {
    staticClass: "box"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("No devices registered")])])])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px",
    attrs: {
      "aria-hidden": "true"
    }
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".deviceid-input {\n  width: 45em;\n}\n.deviceid-input-small {\n  width: 45em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("50e747e6", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/clienttool/ClientToolService.js":
/*!***************************************************!*\
  !*** ./src/views/clienttool/ClientToolService.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  getDevices: function getDevices(companyId) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            url = "/clienttools/devices/".concat(companyId);
            _context.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get(url);
          case 1:
            result = _context.v;
            return _context.a(2, result.data);
        }
      }, _callee);
    }))();
  },
  saveDevice: function saveDevice(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/clienttools/".concat(entity.id);
            _context2.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].put(url, entity);
          case 1:
            result = _context2.v;
            return _context2.a(2, result.data);
        }
      }, _callee2);
    }))();
  },
  insertDevice: function insertDevice(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            url = '/clienttools/';
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].post(url, entity);
          case 1:
            result = _context3.v;
            return _context3.a(2, result);
        }
      }, _callee3);
    }))();
  }
});

/***/ }),

/***/ "./src/views/clienttool/ClientToolView.vue":
/*!*************************************************!*\
  !*** ./src/views/clienttool/ClientToolView.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ClientToolView.vue?vue&type=template&id=9eb5732c */ "./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c");
/* harmony import */ var _ClientToolView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ClientToolView.vue?vue&type=script&lang=js */ "./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss */ "./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ClientToolView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/clienttool/ClientToolView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ClientToolView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss":
/*!**********************************************************************************************!*\
  !*** ./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=style&index=0&id=9eb5732c&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_style_index_0_id_9eb5732c_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c":
/*!*******************************************************************************!*\
  !*** ./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ClientToolView.vue?vue&type=template&id=9eb5732c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/clienttool/ClientToolView.vue?vue&type=template&id=9eb5732c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ClientToolView_vue_vue_type_template_id_9eb5732c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=client-tool-chunk.js.map