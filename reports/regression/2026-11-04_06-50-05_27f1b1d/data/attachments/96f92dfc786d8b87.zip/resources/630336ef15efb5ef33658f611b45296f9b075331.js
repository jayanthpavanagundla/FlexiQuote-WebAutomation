(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-pnetaudanet-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/web.url.js */ "./node_modules/core-js/modules/web.url.js");
/* harmony import */ var core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.url.to-json.js */ "./node_modules/core-js/modules/web.url.to-json.js");
/* harmony import */ var core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_to_json_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.url-search-params.js */ "./node_modules/core-js/modules/web.url-search-params.js");
/* harmony import */ var core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/web.url-search-params.delete.js */ "./node_modules/core-js/modules/web.url-search-params.delete.js");
/* harmony import */ var core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_delete_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.url-search-params.has.js */ "./node_modules/core-js/modules/web.url-search-params.has.js");
/* harmony import */ var core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_has_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/web.url-search-params.size.js */ "./node_modules/core-js/modules/web.url-search-params.size.js");
/* harmony import */ var core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_url_search_params_size_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./services */ "./src/views/quote/services/index.js");
/* harmony import */ var _views_audanettask_AudanetTaskService__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/views/audanettask/AudanetTaskService */ "./src/views/audanettask/AudanetTaskService.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! vue-the-mask */ "./node_modules/vue-the-mask/dist/vue-the-mask.js");
/* harmony import */ var vue_the_mask__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(vue_the_mask__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _components_XmlViewer__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/XmlViewer */ "./src/components/XmlViewer/index.js");
/* harmony import */ var _mixins__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./mixins */ "./src/views/quote/mixins/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./mixins/QuoteStoreMixin */ "./src/views/quote/mixins/QuoteStoreMixin.js");
/* harmony import */ var _components_OrmPnetUtilitiesModal__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./components/OrmPnetUtilitiesModal */ "./src/views/quote/components/OrmPnetUtilitiesModal.vue");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! lodash/orderBy */ "./node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_38__);








































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuotePnetAudanet',
  inject: ['$vv'],
  components: {
    AudanetDownloadQuoteModal: _components__WEBPACK_IMPORTED_MODULE_22__["AudanetDownloadQuoteModal"],
    AudanetSubmitItemsModal: _components__WEBPACK_IMPORTED_MODULE_22__["AudanetSubmitItemsModal"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_26__["default"],
    TheMask: vue_the_mask__WEBPACK_IMPORTED_MODULE_28__["TheMask"],
    XmlViewerModal: _components_XmlViewer__WEBPACK_IMPORTED_MODULE_31__["XmlViewerModal"],
    PnetSubmitQuoteModal: _components__WEBPACK_IMPORTED_MODULE_22__["PnetSubmitQuoteModal"],
    PnetSubmitQuoteUpdateModal: _components__WEBPACK_IMPORTED_MODULE_22__["PnetSubmitQuoteUpdateModal"],
    AudabridgeSubmitImagesModal: _components__WEBPACK_IMPORTED_MODULE_22__["AudabridgeSubmitImagesModal"],
    AudabridgeSubmitDocumentsModal: _components__WEBPACK_IMPORTED_MODULE_22__["AudabridgeSubmitDocumentsModal"],
    OrmPnetUtilitiesModal: _components_OrmPnetUtilitiesModal__WEBPACK_IMPORTED_MODULE_36__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_27__["ConfirmModal"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_30__["DateTimeFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_30__["NumberFiltersMixin"], _mixins__WEBPACK_IMPORTED_MODULE_32__["QuoteNotificationMixin"], _mixins_QuoteStoreMixin__WEBPACK_IMPORTED_MODULE_35__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_34__["default"]],
  props: {
    value: null,
    vehicle: null,
    customer: null
  },
  data: function data() {
    return {
      innerValue: null,
      isDownloadQuoteModalActive: false,
      isSubmitItemsModalActive: false,
      isXmlViewerModalActive: false,
      isPnetSubmitQuoteModalActive: false,
      isPnetSubmitQuoteUpdateModalActive: false,
      isAudabridgeSubmitImagesModalActive: false,
      isAudabridgeSubmitDocumentsModalActive: false,
      isCreateSubQuoteModalActive: false,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_29__["RemarkColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_29__["RemarkColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 8
      },
      isTableLoading: false,
      messageType: '',
      error: false,
      selectedImages: [],
      quoteStatusTypes: [],
      isPnetUtilitiesModalActive: false,
      subQuoteSummary: null,
      disableSumbitItems: false,
      audaNetTask: null,
      currentQuoteStatus: '',
      audatexServerName: ''
    };
  },
  errorCaptured: function errorCaptured(err, vm, info) {
    this.error = true;
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    isAudaNetDocumentUploadEnabled: function isAudaNetDocumentUploadEnabled() {
      var _this$$company;
      // Document upload is rolled out per shop; image submit is not gated
      return ((_this$$company = this.$company) === null || _this$$company === void 0 || (_this$$company = _this$$company.setting) === null || _this$$company === void 0 ? void 0 : _this$$company.audaNetDocumentUploadEnabled) === true;
    },
    canUploadDocuments: function canUploadDocuments() {
      // AudaNet follows the same task-status gate as Submit Items; AudaBridge follows Submit Images (not status-gated)
      if (!this.isAudaNetDocumentUploadEnabled) return false;
      return this.value.isAudaNet && !this.disableSumbitItems || this.value.isAudaBridge;
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_29__["RemarkColumns"];
    },
    remarkTotalRows: function remarkTotalRows() {
      return this.activeRemarks.length;
    },
    activeRemarks: function activeRemarks() {
      var activeRemarks = this.value.otherRemarks.filter(function (r) {
        return !r.isDeleted;
      });
      return lodash_orderBy__WEBPACK_IMPORTED_MODULE_38___default()(activeRemarks, 'remarkDateTime', 'desc');
    },
    pagedRemarks: function pagedRemarks() {
      return this.activeRemarks.slice((this.filter.pageIndex - 1) * this.filter.pageSize, this.filter.pageIndex * this.filter.pageSize);
    },
    pnetAudanetMenuText: function pnetAudanetMenuText() {
      var _this$value$audatex;
      if (!this.value.isAudaNet) return '';
      var taskType = (_this$value$audatex = this.value.audatex) === null || _this$value$audatex === void 0 ? void 0 : _this$value$audatex.taskType;
      if (taskType) {
        return this.value.isAudaBridge ? "".concat(taskType) : "/".concat(taskType);
      }
      return '/AudaNet';
    },
    dropdownMenuText: function dropdownMenuText() {
      if (this.value.isPnet || this.value.isAudaNet || this.value.isAudaBridge) {
        return this.value.audatex && this.value.audatex.taskType ? "".concat(this.value.audatex.taskType) : 'AudaNet';
      } else {
        return '';
      }
    },
    isSubmitQuoteEnabled: function isSubmitQuoteEnabled() {
      return !this.value.readOnly && this.value.pnet.quoteStatusId === _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].QuoteRequestActive;
    },
    isSubmitQuoteUpdateEnabled: function isSubmitQuoteUpdateEnabled() {
      return this.value.pnet && this.value.pnet.authorityNo && this.value.pnet.authorisedQuoteNo;
    },
    isSubmitSupplementaryEnabled: function isSubmitSupplementaryEnabled() {
      return this.value.subQuoteNo > 0 && (this.value.pnet.quoteStatusId !== _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].SupplementaryActive || this.value.pnet.quoteStatusId !== _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].SupplementaryRejected || this.value.pnet.quoteStatusId !== _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].QuoteAuthorised || this.value.pnet.quoteStatusId !== _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].QuoteInvoiceSubmitted);
    },
    isSubmitTaxInvoiceEnabled: function isSubmitTaxInvoiceEnabled() {
      // console.log(this.value.invoices.some((i) => i.invoiceType === InvoiceTypes.Quote && !i.deleted))
      return this.value.invoices.some(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_25__["InvoiceTypes"].Quote && !i.deleted;
      }) && this.value.pnet.quoteStatusId !== _enums__WEBPACK_IMPORTED_MODULE_25__["PnetQuoteStatusTypes"].QuoteInvoiceSubmitted && this.value.pnet.authorityNo;
    },
    tileTitle: function tileTitle() {
      if (this.value.isAudaNet) {
        return 'AudaNet';
      } else if (this.value.isAudaBridge) {
        return 'AudaBridge';
      }
    },
    audaBridgeUrl: function audaBridgeUrl() {
      var taskId = this.value.audatex && this.value.audatex.taskId;
      if (!this.audatexServerName || !taskId) return '';
      try {
        var origin = new URL(this.audatexServerName).origin; // e.g. https://audanet.audatex.com.au
        return "".concat(origin, "/breclient/ui?taskId=").concat(taskId);
      } catch (e) {
        return '';
      }
    },
    displayDownloadQuoteMessage: function displayDownloadQuoteMessage() {
      var authStatus = [_enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].QuoteAuthorised, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].SuppAuthorised, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].PendingAuth, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].SuppPendingAuth];
      if (authStatus.includes(this.currentQuoteStatus) && !authStatus.includes(this.value.audatex.businessStatusText)) return true;else return false;
    }
  },
  watch: {
    // 'innerValue.orm.outOfScope': function(newVal, oldVal) {
    //   this.$emit('input', newVal)
    // }
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(this.value);
    this.$route.meta.title = this.value.isAudaBridge ? this.pnetAudanetMenuText : "PNET".concat(this.pnetAudanetMenuText);
    this.getPnetQuoteStatusTypes();
    this.getAudaNetTask();
    this.getAudatexServerName();
    // this.$eventHub.$on(EventHubTypes.EntityReload, () => {
    //   this.value = this.value
    //   console.log('reload')
    // })
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_37___default()(_this.value);
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved);
  },
  methods: {
    // The support-only fields on this tab bind straight to `value.*`, so an edit is
    // already on QuoteView.entity by the time this fires. QuoteView maps the event onto
    // queueHeaderAutosave(), which short-circuits when nothing actually changed — so no
    // snapshot comparison is needed here.
    queueAutoSave: function queueAutoSave() {
      this.$emit('pnet-component-blur');
    },
    // The utilities modal bulk-writes line-item statuses. Those item arrays are only
    // watched for autosave on the QuoteBuilder route, so the save has to be queued here.
    onUtilitiesInput: function onUtilitiesInput(updated) {
      this.innerValue = updated;
      this.queueAutoSave();
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
    },
    sort: function sort(name, order) {},
    getPnetQuoteStatusTypes: function getPnetQuoteStatusTypes() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_33__["PnetService"].getPnetQuoteStatusTypes();
            case 1:
              _this2.quoteStatusTypes = _context.v;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    downloadQuote: function downloadQuote(overwrite) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this3.isDownloadQuoteModalActive = false;
              _this3.$showSpinner('Downloading quote');
              _context2.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].loadQuote(_this3.value.quoteId, overwrite);
            case 1:
              result = _context2.v;
              console.log(result);
              _this3.$hideSpinner();
              // this.$router.go(this.$route.fullPath)
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    updateClaimInfo: function updateClaimInfo() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (!_this4.$licenceExpired) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              _context4.n = 2;
              return _this4.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
                var result;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
                  while (1) switch (_context3.n) {
                    case 0:
                      _this4.$showSpinner('Updating Claim Info');
                      _context3.n = 1;
                      return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].updateClaimInfo(_this4.value.quoteId);
                    case 1:
                      result = _context3.v;
                      console.log(result);
                      _this4.$hideSpinner();
                      _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
                    case 2:
                      return _context3.a(2);
                  }
                }, _callee3);
              })));
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    downloadVehicle: function downloadVehicle() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              if (!_this5.$licenceExpired) {
                _context6.n = 1;
                break;
              }
              return _context6.a(2);
            case 1:
              _context6.n = 2;
              return _this5.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
                var result;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
                  while (1) switch (_context5.n) {
                    case 0:
                      _this5.$showSpinner('Updating Vehicle');
                      _context5.n = 1;
                      return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].loadVehicle(_this5.value.quoteId);
                    case 1:
                      result = _context5.v;
                      console.log(result);
                      _this5.$hideSpinner();
                      _this5.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
                    case 2:
                      return _context5.a(2);
                  }
                }, _callee5);
              })));
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    downloadImages: function downloadImages() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              if (!_this6.$licenceExpired) {
                _context8.n = 1;
                break;
              }
              return _context8.a(2);
            case 1:
              _context8.n = 2;
              return _this6.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
                var result;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
                  while (1) switch (_context7.n) {
                    case 0:
                      _this6.$showSpinner('Downloading Files');
                      _context7.n = 1;
                      return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].loadImages(_this6.value.quoteId);
                    case 1:
                      result = _context7.v;
                      console.log(result);
                      _this6.$hideSpinner();
                      _this6.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
                      if (result.data.hasFiles) _this6.$notification.openNotificationWithType('success', 'AudaNet', result.data.message);else _this6.$notification.openNotificationWithType('danger', 'AudaNet', result.data.message);
                    case 2:
                      return _context7.a(2);
                  }
                }, _callee7);
              })));
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    submitImages: function submitImages() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              if (!_this7.$licenceExpired) {
                _context9.n = 1;
                break;
              }
              return _context9.a(2);
            case 1:
              _this7.isAudabridgeSubmitImagesModalActive = true;
              // this.$showSpinner('Submitting images')
              // const result = await AudaNetService.submitImages(this.value.quoteId)
              // console.log(result)
              // this.$hideSpinner()
              // this.$eventHub.$emit(EventHubTypes.EntityReload)
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    uploadDocuments: function uploadDocuments() {
      if (this.$licenceExpired) return;
      if (!this.canUploadDocuments) return;
      this.isAudabridgeSubmitDocumentsModalActive = true;
    },
    submitSublets: function submitSublets() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee0() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              _this8.$showSpinner('Submitting sublets');
              _context0.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitSublets(_this8.value.quoteId);
            case 1:
              result = _context0.v;
              console.log(result);
              _this8.$hideSpinner();
              _this8.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    submitParts: function submitParts() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee1() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              _this9.$showSpinner('Submitting parts');
              _context1.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitParts(_this9.value.quoteId);
            case 1:
              result = _context1.v;
              console.log(result);
              _this9.$hideSpinner();
              _this9.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    submitLabours: function submitLabours() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee10() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              _this0.$showSpinner('Submitting labours');
              _context10.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitLabours(_this0.value.quoteId);
            case 1:
              result = _context10.v;
              console.log(result);
              _this0.$hideSpinner();
              _this0.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    submitPaints: function submitPaints() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee11() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              _this1.$showSpinner('Submitting paints');
              _context11.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitPaints(_this1.value.quoteId);
            case 1:
              result = _context11.v;
              console.log(result);
              _this1.$hideSpinner();
              _this1.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
            case 2:
              return _context11.a(2);
          }
        }, _callee11);
      }))();
    },
    submitItems: function submitItems(isSubmitLabours, isSubmitPaints, isSubmitParts, isSubmitSublets) {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee12() {
        var submit, result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              _this10.isSubmitItemsModalActive = false;
              _this10.$v.audaNetHeaderGroup.$touch();
              if (!_this10.$v.audaNetHeaderGroup.$error) {
                _context12.n = 1;
                break;
              }
              _this10.$notification.openNotificationWithType('danger', 'AudaNet', 'Send cancelled. Required fields are missing or invalid');
              return _context12.a(2);
            case 1:
              _this10.$showSpinner('Submitting items');
              submit = [];
              if (!isSubmitParts) {
                _context12.n = 3;
                break;
              }
              _context12.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitParts(_this10.value.quoteId);
            case 2:
              result = _context12.v;
              console.log(result);
              _context12.n = 3;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].sleep(2000);
            case 3:
              if (isSubmitSublets) {
                // await AudaNetService.sleep(submit.length * 2000)
                // submit.splice(submit.length, 1, submit.length)
                // await AudaNetService.submitSublets(this.value.quoteId)
                submit.splice(submit.length, 1, _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitSublets(_this10.value.quoteId, submit.length));
              }
              if (isSubmitPaints) {
                // await AudaNetService.sleep(submit.length * 2000)
                // submit.splice(submit.length, 1, submit.length)
                // await AudaNetService.submitPaints(this.value.quoteId)
                submit.splice(submit.length, 1, _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitPaints(_this10.value.quoteId, submit.length));
              }
              if (isSubmitLabours) {
                // await AudaNetService.sleep(submit.length * 2000)
                // submit.splice(submit.length, 1, submit.length)
                // await AudaNetService.submitLabours(this.value.quoteId)
                submit.splice(submit.length, 1, _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].submitLabours(_this10.value.quoteId, submit.length));
              }
              _context12.n = 4;
              return Promise.all(submit);
            case 4:
              _this10.$hideSpinner();
              _this10.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
              _this10.$notification.openNotificationWithType('success', _this10.tileTitle, 'Items submitted');
            case 5:
              return _context12.a(2);
          }
        }, _callee12);
      }))();
    },
    viewMessages: function viewMessages(type) {
      this.messageType = type;
      this.isXmlViewerModalActive = true;
    },
    submitTaxInvoice: function submitTaxInvoice() {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee14() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context14) {
          while (1) switch (_context14.n) {
            case 0:
              if (!_this11.$licenceExpired) {
                _context14.n = 1;
                break;
              }
              return _context14.a(2);
            case 1:
              _context14.n = 2;
              return _this11.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee13() {
                var result;
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context13) {
                  while (1) switch (_context13.n) {
                    case 0:
                      _this11.$showSpinner('Submitting tax invoice');
                      _context13.n = 1;
                      return _services__WEBPACK_IMPORTED_MODULE_23__["PnetMessageService"].submitTaxInvoice(_this11.value.quoteId);
                    case 1:
                      result = _context13.v;
                      console.log(result);
                      _this11.$hideSpinner();
                      _this11.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntityReload);
                      _this11.showSuccessToast('Tax invoice is being submitted');
                    case 2:
                      return _context13.a(2);
                  }
                }, _callee13);
              })));
            case 2:
              return _context14.a(2);
          }
        }, _callee14);
      }))();
    },
    submitPnetQuote: function submitPnetQuote() {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee16() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context16) {
          while (1) switch (_context16.n) {
            case 0:
              if (!_this12.$licenceExpired) {
                _context16.n = 1;
                break;
              }
              return _context16.a(2);
            case 1:
              _context16.n = 2;
              return _this12.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee15() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context15) {
                  while (1) switch (_context15.n) {
                    case 0:
                      _this12.isPnetSubmitQuoteModalActive = true;
                    case 1:
                      return _context15.a(2);
                  }
                }, _callee15);
              })));
            case 2:
              return _context16.a(2);
          }
        }, _callee16);
      }))();
    },
    submitPnetQuoteUpdate: function submitPnetQuoteUpdate() {
      var _this13 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee18() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context18) {
          while (1) switch (_context18.n) {
            case 0:
              if (!_this13.$licenceExpired) {
                _context18.n = 1;
                break;
              }
              return _context18.a(2);
            case 1:
              _context18.n = 2;
              return _this13.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee17() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context17) {
                  while (1) switch (_context17.n) {
                    case 0:
                      _this13.isPnetSubmitQuoteUpdateModalActive = true;
                    case 1:
                      return _context17.a(2);
                  }
                }, _callee17);
              })));
            case 2:
              return _context18.a(2);
          }
        }, _callee18);
      }))();
    },
    showSubmitAudaNetItems: function showSubmitAudaNetItems() {
      var _this14 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee20() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context20) {
          while (1) switch (_context20.n) {
            case 0:
              if (!_this14.$licenceExpired) {
                _context20.n = 1;
                break;
              }
              return _context20.a(2);
            case 1:
              _context20.n = 2;
              return _this14.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee19() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context19) {
                  while (1) switch (_context19.n) {
                    case 0:
                      _this14.isSubmitItemsModalActive = true;
                    case 1:
                      return _context19.a(2);
                  }
                }, _callee19);
              })));
            case 2:
              return _context20.a(2);
          }
        }, _callee20);
      }))();
    },
    showDownloadAudaNetQuote: function showDownloadAudaNetQuote() {
      var _this15 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee22() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context22) {
          while (1) switch (_context22.n) {
            case 0:
              if (!_this15.$licenceExpired) {
                _context22.n = 1;
                break;
              }
              return _context22.a(2);
            case 1:
              _context22.n = 2;
              return _this15.saveAndContinue(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee21() {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context21) {
                  while (1) switch (_context21.n) {
                    case 0:
                      // check if subQuoteCreated
                      _this15.$showSpinner('Checking quote...');
                      _context21.n = 1;
                      return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].checkSubQuoteAdded(_this15.value.quoteId);
                    case 1:
                      _this15.subQuoteSummary = _context21.v;
                      _this15.$hideSpinner();
                      if (_this15.subQuoteSummary != null && _this15.subQuoteSummary.isCreateQuote) {
                        _this15.isCreateSubQuoteModalActive = true;
                      } else {
                        _this15.isDownloadQuoteModalActive = true;
                      }
                    case 2:
                      return _context21.a(2);
                  }
                }, _callee21);
              })));
            case 2:
              return _context22.a(2);
          }
        }, _callee22);
      }))();
    },
    createSubQuote: function createSubQuote(create) {
      var _this16 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee23() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context23) {
          while (1) switch (_context23.n) {
            case 0:
              if (!create) {
                _context23.n = 3;
                break;
              }
              _this16.isCreateSubQuoteModalActive = false;
              _this16.$showSpinner('Creating supplementry');
              _context23.n = 1;
              return _views_audanettask_AudanetTaskService__WEBPACK_IMPORTED_MODULE_24__["default"].createSubQuote(_this16.value.quoteId);
            case 1:
              result = _context23.v;
              _this16.$hideSpinner();
              _this16.$showSpinner('Loading supplementary');
              _context23.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].loadQuote(result.data, true);
            case 2:
              result = _context23.v;
              _this16.$hideSpinner();
              _this16.$router.push({
                name: _this16.$route.name,
                params: {
                  quoteId: result.data
                }
              });
              _context23.n = 4;
              break;
            case 3:
              _this16.isCreateSubQuoteModalActive = false;
            case 4:
              return _context23.a(2);
          }
        }, _callee23);
      }))();
    },
    showUtilities: function showUtilities() {
      this.isPnetUtilitiesModalActive = true;
    },
    getAudatexServerName: function getAudatexServerName() {
      var _this17 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee24() {
        var setting, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context24) {
          while (1) switch (_context24.p = _context24.n) {
            case 0:
              if (!(!_this17.value.isAudaBridge || _this17.value.isPnet)) {
                _context24.n = 1;
                break;
              }
              return _context24.a(2);
            case 1:
              _context24.p = 1;
              _context24.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_23__["CompanyService"].getExternalSetting('Audatex');
            case 2:
              setting = _context24.v;
              _this17.audatexServerName = setting && setting.serverName ? setting.serverName : '';
              _context24.n = 4;
              break;
            case 3:
              _context24.p = 3;
              _t = _context24.v;
              _this17.audatexServerName = '';
            case 4:
              return _context24.a(2);
          }
        }, _callee24, null, [[1, 3]]);
      }))();
    },
    openAudaBridge: function openAudaBridge() {
      if (this.audaBridgeUrl) {
        window.open(this.audaBridgeUrl, '_blank');
      }
    },
    getAudaNetTask: function getAudaNetTask() {
      var _this18 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee25() {
        var _this18$value$audatex;
        var allowedStatuses, submitQuoteStatus, _this18$audaNetTask, _this18$audaNetTask2, taskStatus;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context25) {
          while (1) switch (_context25.n) {
            case 0:
              allowedStatuses = [_enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].Created, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].ReopenedSuppAdded, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].RFQReceived, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].SupplementaryAdded, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].RFQReviseQuote, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].RequestforRevisedSupp];
              submitQuoteStatus = [_enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].PendingAuth, _enums__WEBPACK_IMPORTED_MODULE_25__["AudaNetJobStatus"].SuppPendingAuth];
              _this18.currentQuoteStatus = (_this18$value$audatex = _this18.value.audatex) === null || _this18$value$audatex === void 0 ? void 0 : _this18$value$audatex.businessStatusText;
              _this18.disableSumbitItems = !allowedStatuses.includes(_this18.currentQuoteStatus);
              if (!(allowedStatuses.includes(_this18.currentQuoteStatus) || submitQuoteStatus.includes(_this18.currentQuoteStatus))) {
                _context25.n = 2;
                break;
              }
              _context25.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["AudaNetService"].getAudaNetTask(_this18.value.quoteId);
            case 1:
              _this18.audaNetTask = _context25.v;
              taskStatus = (_this18$audaNetTask = _this18.audaNetTask) === null || _this18$audaNetTask === void 0 ? void 0 : _this18$audaNetTask.businessStatusText;
              _this18.disableSumbitItems = !allowedStatuses.includes(taskStatus);
              _this18.currentQuoteStatus = (_this18$audaNetTask2 = _this18.audaNetTask) === null || _this18$audaNetTask2 === void 0 ? void 0 : _this18$audaNetTask2.businessStatusText;
            case 2:
              return _context25.a(2);
          }
        }, _callee25);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);












var render = function render() {
  var _vm$quoteStatusTypes;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "quote-pnet-licence-expired": _vm.$licenceExpired
    }
  }, [_c("div", [_c("div", [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v(" " + _vm._s(_vm.value.isAudaBridge ? _vm.pnetAudanetMenuText : "PNET" + _vm.pnetAudanetMenuText) + " ")])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_vm.value.isPnet && !_vm.value.isAudaBridge ? _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.value.isNew,
      expression: "!value.isNew"
    }],
    staticClass: "dropdown is-right is-hoverable"
  }, [_vm._m(0), _c("div", {
    staticClass: "dropdown-menu",
    attrs: {
      id: "dropdown-menu-pnet",
      role: "menu"
    }
  }, [_c("div", {
    staticClass: "dropdown-content"
  }, [!_vm.value.isAudaNet && _vm.isSubmitQuoteEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.submitPnetQuote();
      }
    }
  }, [_vm._m(1), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Quote")])]) : _vm._e(), !_vm.value.isAudaNet && _vm.isSubmitSupplementaryEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.submitPnetQuote();
      }
    }
  }, [_vm._m(2), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Supplementary Quote")])]) : _vm._e(), _vm.isSubmitQuoteUpdateEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.submitPnetQuoteUpdate();
      }
    }
  }, [_vm._m(3), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Repair Status")])]) : _vm._e(), _vm.isSubmitTaxInvoiceEnabled ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.submitTaxInvoice();
      }
    }
  }, [_vm._m(4), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Tax Invoice")])]) : _vm._e(), !_vm.value.isAudaNet && (_vm.isSubmitQuoteEnabled || _vm.isSubmitSupplementaryEnabled) || _vm.isSubmitQuoteUpdateEnabled || _vm.isSubmitTaxInvoiceEnabled ? _c("hr", {
    staticClass: "dropdown-divider"
  }) : _vm._e(), _vm.$userInfo.isSupportUser ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.showUtilities();
      }
    }
  }, [_vm._m(5), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Utilities")])]) : _vm._e(), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.viewMessages("PNET");
      }
    }
  }, [_vm._m(6), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("View Messages")])])])])]) : _vm._e()]), _c("div", {
    staticClass: "column is-narrow"
  }, [_vm.value.isAudaBridge && !_vm.value.isPnet && _vm.audaBridgeUrl ? _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.value.isNew,
      expression: "!value.isNew"
    }],
    staticClass: "button audabridge-button",
    on: {
      click: _vm.openAudaBridge
    }
  }, [_c("span", [_vm._v("Open in AudaBridge")]), _vm._m(7)]) : _vm._e()]), _c("div", {
    staticClass: "column is-narrow"
  }, [_vm.value.isAudaNet || _vm.value.isAudaBridge ? _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.value.isNew,
      expression: "!value.isNew"
    }],
    staticClass: "dropdown is-right is-hoverable"
  }, [_c("div", {
    staticClass: "dropdown-trigger"
  }, [_c("button", {
    staticClass: "button",
    attrs: {
      "aria-haspopup": "true",
      "aria-controls": "dropdown-menu-audanet"
    }
  }, [_c("span", [_vm._v(_vm._s(_vm.dropdownMenuText))]), _vm._m(8)])]), _c("div", {
    staticClass: "dropdown-menu",
    attrs: {
      id: "dropdown-menu-audanet",
      role: "menu"
    }
  }, [_c("div", {
    staticClass: "dropdown-content"
  }, [_vm.value.isAudaNet ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showDownloadAudaNetQuote();
      }
    }
  }, [_vm._m(9), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Download Quote")])]) : _vm._e(), _vm.value.isAudaNet ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.downloadImages();
      }
    }
  }, [_vm._m(10), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Download Files")])]) : _vm._e(), _vm.value.isAudaNet ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.updateClaimInfo();
      }
    }
  }, [_vm._m(11), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Update Claim Info")])]) : _vm._e(), _vm.value.isAudaNet ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.downloadVehicle();
      }
    }
  }, [_vm._m(12), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Update Vehicle")])]) : _vm._e(), _vm.value.isAudaNet && !_vm.disableSumbitItems ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.showSubmitAudaNetItems();
      }
    }
  }, [_vm._m(13), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Items")])]) : _vm._e(), _vm.value.isAudaBridge ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.submitImages();
      }
    }
  }, [_vm._m(14), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Submit Images")])]) : _vm._e(), _vm.canUploadDocuments ? _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    class: {
      "is-licence-disabled": _vm.$licenceExpired
    },
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.uploadDocuments();
      }
    }
  }, [_vm._m(15), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("Upload Documents")])]) : _vm._e(), _vm.value.isAudaNet ? _c("hr", {
    staticClass: "dropdown-divider"
  }) : _vm._e(), _c("a", {
    staticClass: "dropdown-item dropdown-item-has-icon",
    attrs: {
      href: "#"
    },
    on: {
      click: function click($event) {
        return _vm.viewMessages("audanet");
      }
    }
  }, [_vm._m(16), _c("span", {
    staticClass: "dropdown-item-text"
  }, [_vm._v("View Messages")])])])])]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns"
  }, [_vm.value.pnet ? _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("PNET")]), _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("table", {
    staticClass: "table is-bordered is-striped table-max-width"
  }, [_c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Quote Status")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.quoteStatusId,
      expression: "value.pnet.quoteStatusId"
    }],
    attrs: {
      disabled: _vm.$licenceExpired
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value.pnet, "quoteStatusId", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, _vm.queueAutoSave]
    }
  }, _vm._l(_vm.quoteStatusTypes, function (type) {
    return _c("option", {
      key: type.value,
      domProps: {
        value: type.value
      }
    }, [_vm._v(" " + _vm._s(type.name) + " ")]);
  }), 0)]) : _c("div", [_vm._v(_vm._s((_vm$quoteStatusTypes = _vm.quoteStatusTypes) === null || _vm$quoteStatusTypes === void 0 || (_vm$quoteStatusTypes = _vm$quoteStatusTypes.find(function (s) {
    return s.value === _vm.value.pnet.quoteStatusId;
  })) === null || _vm$quoteStatusTypes === void 0 ? void 0 : _vm$quoteStatusTypes.name))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Quote Request No.")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.quoteRequestNo,
      expression: "value.pnet.quoteRequestNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      disabled: _vm.$licenceExpired,
      type: "text",
      placeholder: "Quote Request No."
    },
    domProps: {
      value: _vm.value.pnet.quoteRequestNo
    },
    on: {
      blur: _vm.queueAutoSave,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.pnet, "quoteRequestNo", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.pnet.quoteRequestNo))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Quote Request Version")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.quoteRequestVersion,
      expression: "value.pnet.quoteRequestVersion"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      disabled: _vm.$licenceExpired,
      type: "text",
      placeholder: "Quote Request Version"
    },
    domProps: {
      value: _vm.value.pnet.quoteRequestVersion
    },
    on: {
      blur: _vm.queueAutoSave,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.pnet, "quoteRequestVersion", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.pnet.quoteRequestVersion))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("PNET Quote No.")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.pnetQuoteNo,
      expression: "value.pnet.pnetQuoteNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      disabled: _vm.$licenceExpired,
      type: "text",
      placeholder: "PNET Quote No."
    },
    domProps: {
      value: _vm.value.pnet.pnetQuoteNo
    },
    on: {
      blur: _vm.queueAutoSave,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.pnet, "pnetQuoteNo", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.pnet.pnetQuoteNo))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Authorised Quote No.")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.authorisedQuoteNo,
      expression: "value.pnet.authorisedQuoteNo"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      disabled: _vm.$licenceExpired,
      type: "text",
      placeholder: "Authorised Quote No."
    },
    domProps: {
      value: _vm.value.pnet.authorisedQuoteNo
    },
    on: {
      blur: _vm.queueAutoSave,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.pnet, "authorisedQuoteNo", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.pnet.authorisedQuoteNo))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Authority No.")]), _c("td", {
    staticClass: "has-vertical-middle"
  }, [_vm.$userInfo.isSupportUser ? _c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "Authority No.",
      disabled: _vm.$licenceExpired,
      mask: ["####################"]
    },
    nativeOn: {
      blur: function blur($event) {
        return _vm.queueAutoSave.apply(null, arguments);
      }
    },
    model: {
      value: _vm.value.pnet.authorityNo,
      callback: function callback($$v) {
        _vm.$set(_vm.value.pnet, "authorityNo", $$v);
      },
      expression: "value.pnet.authorityNo"
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.pnet.authorityNo))])], 1)]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Payment Response")]), _c("td", [_c("span", [_vm._v(_vm._s(_vm.value.pnet.paymentResponse))])])])])]), _vm.value.pnet && _vm.$userInfo.isSupportUser ? _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field has-checkradio"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.pnet.extraVehicleInfo,
      expression: "value.pnet.extraVehicleInfo"
    }],
    staticClass: "is-checkradio is-primary",
    class: {
      "has-background-color": _vm.value.pnet.extraVehicleInfo
    },
    attrs: {
      type: "checkbox",
      disabled: _vm.$licenceExpired,
      id: "extraVehicleInfo"
    },
    domProps: {
      checked: Array.isArray(_vm.value.pnet.extraVehicleInfo) ? _vm._i(_vm.value.pnet.extraVehicleInfo, null) > -1 : _vm.value.pnet.extraVehicleInfo
    },
    on: {
      change: [function ($event) {
        var $$a = _vm.value.pnet.extraVehicleInfo,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.value.pnet, "extraVehicleInfo", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.value.pnet, "extraVehicleInfo", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.value.pnet, "extraVehicleInfo", $$c);
        }
      }, _vm.queueAutoSave]
    }
  }), _c("label", {
    attrs: {
      for: "extraVehicleInfo"
    }
  }, [_vm._v("Extra Vehicle Info")])])])]) : _vm._e()])]) : _vm._e(), _vm.value.audatex ? _c("div", {
    staticClass: "column"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v(_vm._s(_vm.dropdownMenuText))]), _c("table", {
    staticClass: "table is-bordered is-striped table-max-width"
  }, [_c("tr", [_c("td", {
    staticClass: "has-text-weight-bold has-vertical-middle",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Display Name")]), _c("td", [_vm.$userInfo.isSupportUser ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.audatex.displayName,
      expression: "value.audatex.displayName"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      disabled: _vm.$licenceExpired,
      type: "text",
      placeholder: "Display Name"
    },
    domProps: {
      value: _vm.value.audatex.displayName
    },
    on: {
      blur: _vm.queueAutoSave,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value.audatex, "displayName", $event.target.value);
      }
    }
  }) : _c("span", [_vm._v(_vm._s(_vm.value.audatex.displayName))])])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Calculation ID")]), _c("td", [_vm._v(_vm._s(_vm.value.audatex.calculationId))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Calculation Status")]), _c("td", [_vm._v(_vm._s(_vm.value.audatex.calculationStatus))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Business Status")]), _c("td", [_vm._v(_vm._s(_vm.value.audatex.businessStatusText))])]), _c("tr", [_c("td", {
    staticClass: "has-text-weight-bold",
    attrs: {
      nowrap: ""
    }
  }, [_vm._v("Quote Stage")]), _c("td", [_vm._v(_vm._s(_vm.value.audatex.quoteStage))])])])]) : _vm._e()]), _vm.value.audatex && _vm.disableSumbitItems ? _c("div", {
    staticClass: "unread-messages-section"
  }, [_c("div", {
    staticClass: "is-flex flex-start"
  }, [_c("span", {
    staticClass: "material-symbols-outlined has-text-warning mr-2"
  }, [_vm._v(" warning ")]), _c("div", [_c("p", {
    staticClass: "mb-3"
  }, [_c("strong", [_vm._v("Note:")]), _vm._v(" The "), _c("strong", [_vm._v("Submit Items")]), _vm.value.isAudaNet && _vm.isAudaNetDocumentUploadEnabled ? [_vm._v(" and "), _c("strong", [_vm._v("Upload Documents")]), _vm._v(" buttons are")] : [_vm._v(" button is")], _vm._v(" currently disabled because the quote status is "), _c("strong", [_vm._v(_vm._s(_vm.currentQuoteStatus))]), _vm._v(". If you intend to submit supplementary items, please create the Supp in AudaNet first. ")], 2)])]), _vm.displayDownloadQuoteMessage ? _c("div", {
    staticClass: "is-flex flex-start"
  }, [_c("span", {
    staticClass: "material-symbols-outlined has-text-warning mr-2"
  }, [_vm._v(" warning ")]), _c("div", [_c("p", {
    staticClass: "mb-3"
  }, [_c("strong", [_vm._v("Download Required:")]), _vm._v(" This quote is "), _c("strong", [_vm._v(_vm._s(_vm.currentQuoteStatus))]), _vm._v(". Please download the quote from AudaNet to sync all updates. ")])])]) : _vm._e()]) : _vm._e()])]), _c("article", {
    staticClass: "box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Remarks")]), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.remarkTotalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-header": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.pagedRemarks, function (remark, index) {
    return _c("tr", {
      key: remark.remarkId,
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", {
      staticClass: "is-content-width"
    }, [_c("span", {
      staticClass: "tag is-info"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(remark.remarkDateTime, _vm.$userInfo.locale)))])]), _c("td", {
      staticClass: "is-remark"
    }, [_c("div", [_vm._v(_vm._s(remark.remarks))])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), _vm.isDownloadQuoteModalActive ? _c("audanet-download-quote-modal", {
    attrs: {
      active: _vm.isDownloadQuoteModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isDownloadQuoteModalActive = $event;
      },
      cancel: function cancel($event) {
        _vm.isDownloadQuoteModalActive = false;
      },
      download: _vm.downloadQuote
    }
  }) : _vm._e(), _vm.isSubmitItemsModalActive ? _c("audanet-submit-items-modal", {
    attrs: {
      active: _vm.isSubmitItemsModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isSubmitItemsModalActive = $event;
      },
      cancel: function cancel($event) {
        _vm.isSubmitItemsModalActive = false;
      },
      submit: _vm.submitItems
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }) : _vm._e(), _vm.isXmlViewerModalActive ? _c("xml-viewer-modal", {
    attrs: {
      active: _vm.isXmlViewerModalActive,
      "quote-id": _vm.value.quoteId,
      "message-type": _vm.messageType
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isXmlViewerModalActive = $event;
      },
      close: function close($event) {
        _vm.isXmlViewerModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("View " + _vm._s(_vm.messageType) + " Messages")])]) : _vm._e(), _vm.isPnetSubmitQuoteModalActive ? _c("pnet-submit-quote-modal", {
    attrs: {
      active: _vm.isPnetSubmitQuoteModalActive,
      vehicle: _vm.vehicle,
      customer: _vm.customer
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPnetSubmitQuoteModalActive = $event;
      },
      close: function close($event) {
        _vm.isPnetSubmitQuoteModalActive = false;
      }
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Submit PNET Quote")])]) : _vm._e(), _vm.isPnetSubmitQuoteUpdateModalActive ? _c("pnet-submit-quote-update-modal", {
    attrs: {
      active: _vm.isPnetSubmitQuoteUpdateModalActive,
      vehicle: _vm.vehicle,
      customer: _vm.customer
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPnetSubmitQuoteUpdateModalActive = $event;
      },
      close: function close($event) {
        _vm.isPnetSubmitQuoteUpdateModalActive = false;
      }
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Submit PNET Quote Update")])]) : _vm._e(), _vm.isAudabridgeSubmitImagesModalActive ? _c("audabridge-submit-images-modal", {
    attrs: {
      active: _vm.isAudabridgeSubmitImagesModalActive,
      "quote-id": _vm.value.quoteId
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isAudabridgeSubmitImagesModalActive = $event;
      },
      cancel: function cancel($event) {
        _vm.isAudabridgeSubmitImagesModalActive = false;
      }
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }) : _vm._e(), _vm.isAudabridgeSubmitDocumentsModalActive ? _c("audabridge-submit-documents-modal", {
    attrs: {
      active: _vm.isAudabridgeSubmitDocumentsModalActive,
      "quote-id": _vm.value.quoteId
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isAudabridgeSubmitDocumentsModalActive = $event;
      },
      cancel: function cancel($event) {
        _vm.isAudabridgeSubmitDocumentsModalActive = false;
      }
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }) : _vm._e(), _vm.isPnetUtilitiesModalActive ? _c("orm-pnet-utilities-modal", {
    attrs: {
      value: _vm.innerValue,
      active: _vm.isPnetUtilitiesModalActive
    },
    on: {
      input: _vm.onUtilitiesInput,
      "update:active": function updateActive($event) {
        _vm.isPnetUtilitiesModalActive = $event;
      }
    }
  }) : _vm._e(), _c("confirm-modal", {
    attrs: {
      active: _vm.isCreateSubQuoteModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isCreateSubQuoteModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.createSubQuote(true);
      },
      cancel: function cancel($event) {
        return _vm.createSubQuote(false);
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Create Supplementary Quote")]), _c("section", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm.isCreateSubQuoteModalActive ? _c("div", [_c("p", [_vm._v("Found new supplementary quote added in " + _vm._s(_vm.dropdownMenuText))]), _c("br"), _c("p", {
    staticStyle: {
      "margin-left": "2em"
    }
  }, [_vm._v(" Quote No.: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.subQuoteSummary.quoteNoRef))]), _c("br"), _vm._v("Current Supp: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.subQuoteSummary.subQuoteNo))]), _c("br"), _vm._v("New supp: "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.subQuoteSummary.createSubQuoteNo))])]), _c("br"), _vm._v(" Create new supplementary quote? ")]) : _vm._e()])])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "dropdown-trigger"
  }, [_c("button", {
    staticClass: "button",
    attrs: {
      "aria-haspopup": "true",
      "aria-controls": "dropdown-menu-pnet"
    }
  }, [_c("span", [_vm._v("PNET")]), _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-chevron-down",
    attrs: {
      "aria-hidden": "true"
    }
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-upload mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-upload-outline mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-update mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-currency-usd mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-tools mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-file-code mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-open-in-new",
    attrs: {
      "aria-hidden": "true"
    }
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-chevron-down",
    attrs: {
      "aria-hidden": "true"
    }
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-download mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-image-plus mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-shield-car mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-car mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-upload-multiple mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-image-move mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-file-upload mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small is-left has-text-primary",
    staticStyle: {
      "self-align": "center"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-file-code mdi-18px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-pnet-licence-expired .dropdown-item.is-licence-disabled,\n.quote-pnet-licence-expired td:has(> input:disabled),\n.quote-pnet-licence-expired td:has(> .select > select:disabled),\n.quote-pnet-licence-expired .control:has(> input:disabled) {\n  position: relative;\n  cursor: not-allowed;\n}\n.quote-pnet-licence-expired .dropdown-item.is-licence-disabled:hover::before,\n.quote-pnet-licence-expired td:has(> input:disabled):hover::before,\n.quote-pnet-licence-expired td:has(> .select > select:disabled):hover::before,\n.quote-pnet-licence-expired .control:has(> input:disabled):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: normal;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-pnet-licence-expired .dropdown-item.is-licence-disabled > .icon,\n.quote-pnet-licence-expired .dropdown-item.is-licence-disabled > .dropdown-item-text {\n  opacity: 0.5;\n}\n.quote-pnet-licence-expired .dropdown-item.is-licence-disabled:hover::before {\n  top: 50%;\n  right: 100%;\n  -webkit-transform: translate(-0.5rem, -50%);\n          transform: translate(-0.5rem, -50%);\n}\n.quote-pnet-licence-expired td:has(> input:disabled):hover::before,\n.quote-pnet-licence-expired td:has(> .select > select:disabled):hover::before,\n.quote-pnet-licence-expired .control:has(> input:disabled):hover::before {\n  top: 100%;\n  left: 0;\n}\n.quote-pnet-licence-expired td > input:disabled,\n.quote-pnet-licence-expired td > .select > select:disabled,\n.quote-pnet-licence-expired .control > input:disabled + label {\n  cursor: not-allowed;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "a.dropdown-item-has-icon[data-v-1dabf730] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\nspan.dropdown-item-text[data-v-1dabf730] {\n  padding-left: 5px;\n}\n.table-max-width[data-v-1dabf730] {\n  max-width: 30rem;\n}\n.unread-messages-section[data-v-1dabf730] {\n  border: 1px solid var(--border-color);\n  padding: 20px;\n}\n.audabridge-button[data-v-1dabf730] {\n  background-color: #ffffff;\n  border-color: #4c92eb;\n  color: #4c92eb;\n}\n.audabridge-button[data-v-1dabf730]:hover,\n.audabridge-button[data-v-1dabf730]:focus {\n  background-color: #4c92eb;\n  border-color: #4c92eb;\n  color: #ffffff;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("009a84f9", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("173ac723", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuotePnetAudanet.vue":
/*!**********************************************!*\
  !*** ./src/views/quote/QuotePnetAudanet.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true */ "./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true");
/* harmony import */ var _QuotePnetAudanet_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuotePnetAudanet.vue?vue&type=script&lang=js */ "./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss */ "./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss");
/* harmony import */ var _QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true */ "./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuotePnetAudanet_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1dabf730",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuotePnetAudanet.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss":
/*!*******************************************************************************************!*\
  !*** ./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=0&id=1dabf730&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_0_id_1dabf730_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true":
/*!*******************************************************************************************************!*\
  !*** ./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=style&index=1&id=1dabf730&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_style_index_1_id_1dabf730_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true":
/*!****************************************************************************************!*\
  !*** ./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuotePnetAudanet.vue?vue&type=template&id=1dabf730&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuotePnetAudanet_vue_vue_type_template_id_1dabf730_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=quote-pnetaudanet-chunk.js.map