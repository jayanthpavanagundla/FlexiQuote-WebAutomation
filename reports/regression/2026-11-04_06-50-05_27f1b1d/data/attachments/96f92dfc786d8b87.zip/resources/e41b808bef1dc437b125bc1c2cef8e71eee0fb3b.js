(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-list-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _QuoteFiltersMixins__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./QuoteFiltersMixins */ "./src/views/quote/QuoteFiltersMixins.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/services */ "./src/services/index.js");





















// import MaskedInput from 'vue-masked-input'








/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_19__["default"],
    // MaskedInput,
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_21___default.a
  },
  mixins: [_QuoteFiltersMixins__WEBPACK_IMPORTED_MODULE_25__["default"]],
  props: {
    value: null,
    jobStages: null,
    resetValues: null,
    includeClaimsType: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: this.getDataObj(this.value, this.jobStages),
      insurers: [],
      selectedInsurer: null,
      isInsurerLoading: false,
      insurerFilter: {
        assetId: this.value && this.value !== _components_Guid__WEBPACK_IMPORTED_MODULE_22__["default"].empty() ? this.value.insurerId : _components_Guid__WEBPACK_IMPORTED_MODULE_22__["default"].empty(),
        assetName: '',
        showCustomer: false,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      selectedFromDate: null,
      selectedToDate: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      claimsTypes: [],
      timeout: null,
      innerPageSize: 12
    };
  },
  computed: {
    jobStageTypes: function jobStageTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_20__["JobStageTypes"];
    },
    selectedClaimsType: function selectedClaimsType() {
      var _this = this;
      return this.claimsTypes.find(function (i) {
        return i.key === _this.innerValue.claimsTypeKey;
      });
    },
    jobStagesObj: function jobStagesObj() {
      var _this$jobStages;
      if (!((_this$jobStages = this.jobStages) !== null && _this$jobStages !== void 0 && _this$jobStages.length)) {
        return [];
      }

      // Group stages by JobStage
      var grouped = {};
      this.jobStages.forEach(function (stage) {
        var jobStageName = stage.jobStageName;
        if (!grouped[jobStageName]) {
          grouped[jobStageName] = {
            groupLabel: jobStageName,
            jobStageId: stage.jobStageId,
            jobStage: stage.jobStageName,
            key: "".concat(stage.jobStageId, "|"),
            options: [],
            hasSubJobStages: false,
            isDefault: stage.isDefault
          };
        }

        // Create option object for each stage
        var option = {
          key: stage.compositeKey,
          description: stage.subJobStageName ? stage.subJobStageName : jobStageName,
          jobStage: stage.jobStageName,
          jobStageId: stage.jobStageId,
          subJobStage: stage.subJobStageName,
          subJobStageId: stage.subJobStageId,
          isDefault: stage.isDefault
        };
        grouped[jobStageName].options.push(option);

        // Track if this JobStage has any SubJobStages
        if (stage.subJobStageName) {
          grouped[jobStageName].hasSubJobStages = true;
        }
      });

      // Create flat structure with visual grouping
      var result = [];
      Object.values(grouped).forEach(function (group) {
        if (group.hasSubJobStages) {
          //JobStages with SubJobStages
          result.push({
            key: group.key,
            description: group.groupLabel,
            jobStage: group.jobStage,
            jobStageId: group.jobStageId,
            subJobStage: '',
            subJobStageId: '',
            isGroupHeader: true,
            isDefault: group.isDefault,
            hasParentGroup: false
            // groupOptions: group.options // Store reference to group options
          });

          // Add SubJobStages
          group.options.forEach(function (option) {
            result.push(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, option), {}, {
              hasParentGroup: true,
              isGroupHeader: false,
              isDefault: option.isDefault
            }));
          });
        } else {
          // Add as standalone jobStages
          group.options.forEach(function (option) {
            result.push({
              key: option.key,
              description: option.jobStage,
              jobStage: option.jobStage,
              jobStageId: option.jobStageId,
              subJobStage: option.subJobStage,
              subJobStageId: option.subJobStageId,
              hasParentGroup: false,
              isGroupHeader: false,
              isDefault: option.isDefault
            });
          });
        }
      });
      return result;
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_26__["Columns"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    selectedFromDate: function selectedFromDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.dateFrom = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.dateFrom = null;
      }
      // this.innerValue.dateFrom = this.selectedFromDate !== null ? this.selectedFromDate.toISOString() : ''
    },
    selectedToDate: function selectedToDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.dateTo = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.dateTo = null;
      }
      // this.innerValue.dateTo = this.selectedToDate !== null ? this.selectedToDate.toISOString() : ''
    }
  },
  beforeDestroy: function beforeDestroy() {},
  created: function created() {
    this.getListComboInsurers('');
    if (this.value.dateFrom) {
      this.selectedFromDate = new Date(this.value.dateFrom);
    }
    if (this.value.dateTo) {
      this.selectedToDate = new Date(this.value.dateTo);
    }
    if (this.value.pageSize) {
      this.innerPageSize = this.value.pageSize;
    }
    if (!!this.includeClaimsType) {
      this.getClaimTypes();
    }
    this.createSubNewJobStage();
  },
  mounted: function mounted() {},
  methods: {
    handleBlur: function handleBlur() {
      console.log('Date picker blurred!');
    },
    getDataObj: function getDataObj(value, jobStages) {
      var _value$jobStage;
      // jobstages need to be converted from flat array of stageIds
      // to array of objects with stageId and description, etc

      if (!((_value$jobStage = value.jobStage) !== null && _value$jobStage !== void 0 && _value$jobStage.length) || !(jobStages !== null && jobStages !== void 0 && jobStages.length)) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, value);
      }

      // Create a flat mapping from the original jobStages for lookup
      var stageMapping = {};
      jobStages.forEach(function (stage) {
        stageMapping[stage.compositeKey] = stage;
        if (stage.stage) {
          stageMapping[stage.stage] = stage;
        }
      });

      // Filter and map the selected job stages
      var selectedStages = [];
      value.jobStage.forEach(function (stageId) {
        var foundStage = stageMapping[stageId];
        if (foundStage) {
          // Create the object structure expected by the multiselect
          selectedStages.push({
            key: foundStage.compositeKey,
            description: foundStage.subJobStageName ? foundStage.subJobStageName : foundStage.jobStageName,
            jobStage: foundStage.jobStageName,
            subJobStage: foundStage.subJobStageName,
            stage: foundStage.stage || foundStage.compositeKey
          });
        }
      });
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, value);
    },
    onJobStageSelect: function onJobStageSelect(selectedOption) {
      var _this2 = this;
      if (selectedOption.isGroupHeader) {
        // If a group header is selected, toggle all options in that group
        var groupOptions = this.jobStagesObj.filter(function (option) {
          return option.jobStageId === selectedOption.jobStageId && !option.isGroupHeader;
        }); // Check if all group options are already selected
        var selectedKeys = this.innerValue.jobNSubStage.map(function (item) {
          return item.key;
        });

        // select all missing ones
        groupOptions.forEach(function (option) {
          var isAlreadySelected = selectedKeys.includes(option.key);
          if (!isAlreadySelected) {
            _this2.innerValue.jobNSubStage.push(option);
          }
        });
      }

      // Call the filter function
      this.onFilterClick();
    },
    onFilterClick: function onFilterClick() {
      var _this3 = this;
      clearTimeout(this.timeout);
      this.timeout = setTimeout(function () {
        _this3.$emit('filter');
      }, 500);
      // this.innerValue.dateFrom = this.selectedFromDate !== null ? this.selectedFromDate.toISOString() : ''
      // this.innerValue.dateTo = this.selectedToDate !== null ? this.selectedToDate.toISOString() : ''
    },
    onResetClick: function onResetClick() {
      this.selectedInsurer = null;
      this.selectedFromDate = null;
      this.selectedToDate = null;
      this.$emit('reset');
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_27___default()(this.resetValues);
    },
    changeActive: function changeActive(value) {
      this.innerValue.active = value;
      this.onFilterClick();
    },
    selectInsurer: function selectInsurer(selected) {
      this.innerValue.insurerId = selected.assetId;
      this.insurerFilter.assetId = selected.assetId;
      this.innerValue.insurerName = selected.assetName;
      this.onFilterClick();
    },
    removeInsurer: function removeInsurer() {
      this.innerValue.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_22__["default"].empty();
      this.insurerFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_22__["default"].empty();
      this.innerValue.insurerName = '';
      this.onFilterClick();
    },
    getListComboInsurers: function getListComboInsurers(query) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this4.isInsurerLoading = true;
              _this4.insurerFilter.assetName = query;
              _context.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_23__["default"].getInsurerDropdownProto(_this4.insurerFilter);
            case 1:
              _this4.insurers = _context.v;
              _this4.selectedInsurer = _this4.insurers.find(function (i) {
                return i.assetId === _this4.insurerFilter.assetId;
              });
              _this4.isInsurerLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getListComboInsurersFiltered: lodash_debounce__WEBPACK_IMPORTED_MODULE_24___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.getListComboInsurers(query);
            case 1:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    gotoV1: function gotoV1() {
      window.open("".concat("", "/modules/quotesview/quotes.aspx"), '_blank');
    },
    getClaimTypes: function getClaimTypes() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_28__["CompanyService"].getClaimsTypes();
            case 1:
              _this5.claimsTypes = _context3.v;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    onClaimsTypeChange: function onClaimsTypeChange(val) {
      this.innerValue.claimsTypeKey = val.key;
      this.onFilterClick();
    },
    createSubNewJobStage: function createSubNewJobStage() {
      var _this$innerValue$jobN,
        _this$jobStages2,
        _this6 = this;
      if ((_this$innerValue$jobN = this.innerValue.jobNSubStage) !== null && _this$innerValue$jobN !== void 0 && _this$innerValue$jobN.length && (_this$jobStages2 = this.jobStages) !== null && _this$jobStages2 !== void 0 && _this$jobStages2.length) {
        console.log('jobNSubStage before mapping:', this.innerValue.jobNSubStage);
        this.innerValue.jobNSubStage = this.innerValue.jobNSubStage.map(function (filterStage) {
          var matchingStage = _this6.jobStages.find(function (stage) {
            return stage.jobStageId === filterStage.jobStageId && stage.subJobStageId === filterStage.subJobStageId;
          });
          if (matchingStage) {
            matchingStage.description = matchingStage.subJobStageName ? matchingStage.subJobStageName : matchingStage.jobStageName;
          }
          return matchingStage || filterStage;
        });
        console.log('jobNSubStage after mapping:', this.innerValue.jobNSubStage);
      }
    } // handlePageSizeChange(pageSize) {
    //   this.innerPageSize = pageSize
    //   this.value.pageSize = this.innerPageSize
    //   this.onFilterClick()
    // }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _QuoteListSideMenu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./QuoteListSideMenu */ "./src/views/quote/QuoteListSideMenu.vue");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./columns */ "./src/views/quote/columns.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/printpreview/PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! lodash/transform */ "./node_modules/lodash/transform.js");
/* harmony import */ var lodash_transform__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(lodash_transform__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34__);




































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_19__["default"],
    QuoteListSideMenu: _QuoteListSideMenu__WEBPACK_IMPORTED_MODULE_20__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__["default"],
    QuoteListPrintModal: _components__WEBPACK_IMPORTED_MODULE_31__["QuoteListPrintModal"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_22__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_27__["DateTimeFiltersMixin"]],
  props: {},
  data: function data() {
    return {
      entitySummaries: null,
      totalRows: 0,
      filter: {
        search: '',
        dateFrom: '',
        dateTo: '',
        insurerId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        insurerName: '',
        jobNSubStage: [],
        active: 1,
        invoiceStatus: 'A',
        authorisedStatus: 'B',
        quoteType: 'Q',
        claimsTypeKey: '',
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 50
      },
      resetValuesObj: {
        search: '',
        dateFrom: '',
        dateTo: '',
        insurerId: _components_Guid__WEBPACK_IMPORTED_MODULE_24__["default"].empty(),
        insurerName: '',
        jobNSubStage: [],
        active: 1,
        invoiceStatus: 'A',
        authorisedStatus: 'B',
        quoteType: 'Q',
        claimsTypeKey: '',
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 50
      },
      selectedRow: null,
      isTableLoading: false,
      pdfFrameData: '',
      isPrintQuoteListModalActive: false,
      // imagePath: ''

      maxHeight: '',
      isVerticalScrollbarActive: false
    };
  },
  computed: {
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    columns: function columns() {
      if (this.includeClaimsType) {
        var clonedColumns = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34___default()(_columns__WEBPACK_IMPORTED_MODULE_21__["Columns"]);
        /// add claims type columm after claim no
        clonedColumns.splice(5, 0, new _classes__WEBPACK_IMPORTED_MODULE_28__["TableColumn"]('Claims Type.', 'claimsTypeKey', true, 'desc', 'left'));
        return clonedColumns;
      }
      return _columns__WEBPACK_IMPORTED_MODULE_21__["Columns"];
    },
    includeClaimsType: function includeClaimsType() {
      //TODO: change to my afer devlopment
      return this.$company && this.$company.info && this.$company.info.countryCode === 'MY';
    },
    currentPage: function currentPage() {
      return this.filter.pageIndex;
    },
    totalPages: function totalPages() {
      return Math.floor(this.totalRows / this.filter.pageSize);
    }
  },
  created: function created() {
    console.log('created');
    this.resetPageIndex();
    this.getData();
  },
  mounted: function mounted() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            console.log('mounted');
            _this.$refs.quoteListing.addEventListener('scroll', _this.onScroll);
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  beforeDestroy: function beforeDestroy() {
    this.$refs.quoteListing.removeEventListener('scroll', this.onScroll);
  },
  methods: {
    resetPageIndex: function resetPageIndex() {
      this.filter.pageIndex = 1;
    },
    onAppContentScroll: function onAppContentScroll() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var appContent, scrollPosition, bottomPosition;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              appContent = document.querySelector('.app-content');
              scrollPosition = appContent.scrollTop + appContent.clientHeight;
              bottomPosition = appContent.scrollHeight - 10; // Trigger slightly before bottom
              if (!(scrollPosition >= bottomPosition && !_this2.isTableLoading)) {
                _context2.n = 1;
                break;
              }
              _context2.n = 1;
              return _this2.fetchMoreRows();
            case 1:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    onScroll: function onScroll() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var container, scrollPosition, bottomPosition;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              container = _this3.$refs.quoteListing;
              scrollPosition = container.scrollTop + container.clientHeight;
              bottomPosition = container.scrollHeight - 50; // Trigger slightly before reaching the bottom
              if (!(scrollPosition >= bottomPosition && !_this3.isTableLoading)) {
                _context3.n = 1;
                break;
              }
              _context3.n = 1;
              return _this3.fetchMoreRows();
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    fetchMoreRows: function fetchMoreRows() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var apifilters, entities, _this4$entitySummarie;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (!(_this4.isTableLoading || _this4.currentPage > _this4.totalPages)) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              _this4.isTableLoading = true;
              _this4.filter.pageIndex++;
              _this4.persistFilter();
              apifilters = _this4.getApiFilter();
              _context4.n = 2;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getEntitySummaries(apifilters);
            case 2:
              entities = _context4.v;
              if (_this4.entitySummaries && entities) {
                (_this4$entitySummarie = _this4.entitySummaries).push.apply(_this4$entitySummarie, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(entities));
              }
              _this4.isTableLoading = false;
            case 3:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].AddNew:
          this.addNew();
          // this.testConnection('ormtrans0227', 'ttMaMvziikiaJCb')
          // this.testConnection('ormtrans0547', 'TxwKH6Tx7YPGkfr')
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Print:
          this.print();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Save:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_25__["AppHeaderButtonTypes"].Cancel:
          break;
      }
    },
    highlightSelected: function highlightSelected(index, event) {
      this.selectedRow = index;
    },
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getData();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getData();
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getData();
    },
    resetList: function resetList() {
      // have to use this method to reset the filter becaause the
      // reset object was mutating the filter object
      this.filter = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34___default()(this.resetValuesObj);
      this.persistFilter();
      this.getData();
    },
    getApiFilter: function getApiFilter() {
      var _apifilters$jobNSubSt;
      this.retrieveFilter();
      // covert array of jobstages object to array of stage ids for api
      var apifilters = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_34___default()(this.filter);
      if (!!((_apifilters$jobNSubSt = apifilters.jobNSubStage) !== null && _apifilters$jobNSubSt !== void 0 && _apifilters$jobNSubSt.length)) {
        apifilters.jobStage = this.filter.jobNSubStage.map(function (stage) {
          return stage.jobStageId;
        });
        apifilters.subJobStage = apifilters.jobNSubStage.map(function (stage) {
          return stage.subJobStageId;
        });
      }
      return apifilters;
    },
    getData: function getData() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        var apifilters;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.isTableLoading = true;
              apifilters = _this5.getApiFilter();
              _context5.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].getEntitySummaries(apifilters);
            case 1:
              _this5.entitySummaries = _context5.v;
              _this5.totalRows = _this5.entitySummaries.length > 0 ? _this5.entitySummaries[0].totalRows : 0;
              _this5.isTableLoading = false;
              _this5.$refs.quoteListing.scrollTop = 0;
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    print: function print() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.isPrintQuoteListModalActive = true;
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    closePrint: function closePrint() {
      this.isPrintQuoteListModalActive = false;
    },
    generateReportParams: function generateReportParams(report) {
      var isAuthorised = 'BOTH';
      var isInvoiced = 'BOTH';
      var isActive = 'BOTH';
      var allDate = 'NN';
      if (this.filter.dateFrom == '') {
        allDate = 'Y';
      } else {
        allDate = 'N';
      }
      if (this.filter.dateTo == '') {
        allDate = allDate + 'Y';
      } else {
        allDate = allDate + 'N';
      }
      switch (this.filter.authorisedStatus) {
        case 'B':
          isAuthorised = 'BOTH';
          break;
        case 'A':
          isAuthorised = 'YES';
          break;
        case 'U':
          isAuthorised = 'NO';
          break;
      }
      switch (this.filter.invoiceStatus) {
        case 'A':
          isInvoiced = null;
          break;
        case 'I':
          isInvoiced = 'YES';
          break;
        case 'U':
          isInvoiced = 'NO';
          break;
        case 'P':
          isInvoiced = 'Partially';
          break;
        default:
          isInvoiced = null;
      }
      switch (this.filter.active) {
        case 0:
          isActive = 'BOTH';
          break;
        case 1:
          isActive = 'YES';
          break;
        case 2:
          isActive = 'NO';
          break;
      }
      var params = Object.assign({
        fromquotesdate: this.filter.dateFrom,
        endquotesdate: this.filter.dateTo,
        insurerId: this.filter.insurerId != '00000000-0000-0000-0000-000000000000' ? this.filter.insurerId : 0,
        insurerName: this.filter.insurerName,
        jobStageId: this.filter.jobNSubStage.map(function (stage) {
          return stage.jobStageId ? stage.jobStageId : '';
        }).join(','),
        subJobStageIds: this.filter.jobNSubStage.map(function (stage) {
          return stage.subJobStageId;
        }).filter(function (id) {
          return id != null && String(id).trim() !== '';
        }).map(function (id) {
          return String(id).trim();
        }).join(','),
        isAuthorised: isAuthorised,
        isInvoiced: isInvoiced,
        companyId: this.$userInfo.companyId,
        quoteType: this.filter.quoteType,
        timezoneoffset: this.$filters.getSiteTimezoneOffset(),
        sortColumn: this.filter.sortColumn,
        sortDirection: this.filter.sortOrder,
        allDate: allDate,
        search: this.filter.search,
        claimsType: this.filter.claimsTypeKey
      });
      if (report == 'QuoteAnalysis' || report == 'QuoteAnalysisExcel') {
        params.isActive = isActive;
      }
      params = lodash_transform__WEBPACK_IMPORTED_MODULE_32___default()(params, function (result, value, key) {
        result[key.toLowerCase()] = value;
      });
      console.log('report params', params);
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_33__["KeyValuePairModel"].convertToKeyValuePairs(params);
      return keyValuePairs;
    },
    exportToExcel: function exportToExcel(format) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        var keyValuePairs;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              keyValuePairs = _this7.generateReportParams('QuoteAnalysisExcel');
              _context7.n = 1;
              return _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_30__["default"].exportReportEx('rptQuoteAnalysisExcel', format, keyValuePairs);
            case 1:
              _this7.isPrintQuoteListModalActive = false;
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    printQuoteList: function printQuoteList(report) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var keyValuePairs, reportName, emailSubject, emailer;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              keyValuePairs = _this8.generateReportParams(report);
              _this8.addReportParameters(keyValuePairs);
              reportName = '';
              emailSubject = '';
              if (report == 'QuoteAnalysis') {
                reportName = 'rptQuoteAnalysis';
                emailSubject = 'Quote Analysis';
              } else if (report == 'QuoteAnalysisExcel') {
                reportName = 'rptQuoteAnalysisExcel';
                emailSubject = 'Quote Analysis Additional Columns';
              } else {
                reportName = 'rptStrikeRate';
                emailSubject = ' Strike Rate';
              }
              emailer = new _classes__WEBPACK_IMPORTED_MODULE_28__["Emailer"]();
              emailer.subject = emailSubject;
              emailer.reportName = reportName;
              _this8.addEmailer(emailer);
              _this8.$router.push({
                name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_29__["default"].PrintPreview.name,
                params: {
                  reportName: reportName
                },
                query: {
                  parameterId: _this8.$guid.newGuid(),
                  emailerId: emailer.id
                }
              });
              _this8.isPrintQuoteListModalActive = false;
            case 1:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    testConnection: function testConnection(username, password) {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee9() {
        var id;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              _context9.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_26__["default"].testConnection(username, password);
            case 1:
              id = _context9.v;
              console.log(username, id);
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    addNew: function addNew() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee0() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              // this.getNewVehicle()
              // this.getNewCustomer()
              // this.getNewInsurer()
              _this9.addStoreItem(0, false);
            case 1:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_8__);









var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")]), false ? undefined : _vm._e()]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.search,
      expression: "innerValue.search"
    }],
    staticClass: "input is-uppercase",
    attrs: {
      type: "text",
      placeholder: "Search..."
    },
    domProps: {
      value: _vm.innerValue.search
    },
    on: {
      keyup: function keyup($event) {
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "search", $event.target.value);
      }
    }
  })]), _c("div", {
    staticClass: "help"
  }, [_vm._v(" Search by "), _c("ul", [_c("li", [_vm._v("Quote No.")]), _c("li", [_vm._v("Rego No.")]), _c("li", [_vm._v("Customer Name/Phone")]), _c("li", [_vm._v("Claim No.")]), _c("li", [_vm._v("Car Make/Model.")]), _c("li", [_vm._v("Key No.")])])])]), _c("div", {
    staticClass: "field",
    on: {
      focusout: function focusout($event) {
        return _vm.onFilterClick();
      }
    }
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      "popover.visibility": "focus",
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": {
        timeAdjust: "00:00:00"
      },
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Date From..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedFromDate,
      callback: function callback($$v) {
        _vm.selectedFromDate = $$v;
      },
      expression: "selectedFromDate"
    }
  })], 1), _c("div", {
    staticClass: "field",
    on: {
      focusout: function focusout($event) {
        return _vm.onFilterClick();
      }
    }
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      "popover-visibility": "focus",
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": {
        timeAdjust: "23:59:59"
      },
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref2) {
        var inputValue = _ref2.inputValue,
          inputEvents = _ref2.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Date To..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedToDate,
      callback: function callback($$v) {
        _vm.selectedToDate = $$v;
      },
      expression: "selectedToDate"
    }
  })], 1), _vm.insurers ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Select an insurer",
      options: _vm.insurers,
      loading: _vm.isInsurerLoading,
      "internal-search": false,
      "options-limit": _vm.insurerFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectInsurer,
      remove: _vm.removeInsurer,
      "search-change": _vm.getListComboInsurersFiltered
    },
    model: {
      value: _vm.selectedInsurer,
      callback: function callback($$v) {
        _vm.selectedInsurer = $$v;
      },
      expression: "selectedInsurer"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Insurer not found.")])])], 1)]) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.authorisedStatus,
      expression: "innerValue.authorisedStatus"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "authorisedStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.onFilterClick();
      }]
    }
  }, [_c("option", {
    attrs: {
      value: "B"
    }
  }, [_vm._v("-- Auth Status --")]), _c("option", {
    attrs: {
      value: "A"
    }
  }, [_vm._v("Authorised")]), _c("option", {
    attrs: {
      value: "U"
    }
  }, [_vm._v("Not Authorised")])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.invoiceStatus,
      expression: "innerValue.invoiceStatus"
    }],
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "invoiceStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.onFilterClick();
      }]
    }
  }, [_c("option", {
    attrs: {
      value: "A"
    }
  }, [_vm._v("-- Inv. Status --")]), _c("option", {
    attrs: {
      value: "I"
    }
  }, [_vm._v("Invoiced")]), _c("option", {
    attrs: {
      value: "U"
    }
  }, [_vm._v("Not Invoiced")]), _c("option", {
    attrs: {
      value: "P"
    }
  }, [_vm._v("Partially Invoiced")])])])])]), _vm.jobStagesObj ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field multi-job-stage-select"
  }, [_c("multiselect", {
    attrs: {
      options: _vm.jobStagesObj,
      "hide-selected": true,
      multiple: true,
      "close-on-select": false,
      "show-labels": false,
      "clear-on-select": true,
      "preserve-search": true,
      placeholder: "Select Job Stages",
      label: "description",
      "track-by": "key",
      taggable: true
    },
    on: {
      select: _vm.onJobStageSelect,
      remove: function remove($event) {
        return _vm.onFilterClick();
      }
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [props.option.isGroupHeader ? _c("div", {
          staticClass: "job-stage-group-header"
        }, [_vm._v(" " + _vm._s(props.option.description) + " ")]) : _c("div", {
          class: {
            "job-stage-sub-option": props.option.hasParentGroup
          }
        }, [_vm._v(" " + _vm._s(props.option.description) + " ")])];
      }
    }], null, false, 1836707056),
    model: {
      value: _vm.innerValue.jobNSubStage,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "jobNSubStage", $$v);
      },
      expression: "innerValue.jobNSubStage"
    }
  })], 1)]) : _vm._e(), !!_vm.includeClaimsType ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      options: _vm.claimsTypes,
      "preserve-search": true,
      "track-by": "key",
      "internal-search": true,
      searchable: true,
      "show-labels": false,
      placeholder: "Select Claims type",
      label: "description",
      "allow-empty": true
    },
    on: {
      select: _vm.onClaimsTypeChange
    },
    model: {
      value: _vm.selectedClaimsType,
      callback: function callback($$v) {
        _vm.selectedClaimsType = $$v;
      },
      expression: "selectedClaimsType"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Claims type not found.")])])], 1)]) : _vm._e(), _c("div", {
    staticClass: "buttons has-addons"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-primary is-selected": _vm.innerValue.active === 0
    },
    on: {
      click: function click($event) {
        return _vm.changeActive(0);
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-adjust"
  })]), _c("span", [_vm._v("Both")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": _vm.innerValue.active === 1
    },
    on: {
      click: function click($event) {
        return _vm.changeActive(1);
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": _vm.innerValue.active === 2
    },
    on: {
      click: function click($event) {
        return _vm.changeActive(2);
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]), _c("span", [_vm._v("In-Active")])])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm$jobNSubJobStages;
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless quote-list-view"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [!!((_vm$jobNSubJobStages = _vm.jobNSubJobStages) !== null && _vm$jobNSubJobStages !== void 0 && _vm$jobNSubJobStages.length) ? _c("quote-list-side-menu", {
    attrs: {
      "job-stages": _vm.jobNSubJobStages,
      "reset-values": _vm.resetValuesObj,
      "include-claims-type": _vm.includeClaimsType
    },
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "m-3"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    ref: "quoteListing",
    staticClass: "table-container quotes is-scrollable is-fullwidth entity-summaries-container"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      "show-pagination": false,
      "has-sticky-header": true,
      "sticky-header-top": "0"
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entitySummaries, function (entity, index) {
    return _c("tr", {
      key: entity.quoteId,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("router-link", {
      attrs: {
        to: {
          path: entity.quoteId
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(entity.quoteNoRef) + " ")])], 1), _c("td", [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(entity.quoteDate, _vm.$userInfo.locale)))]), _c("td", [_vm._v(_vm._s(entity.regoNo))]), _c("td", [_vm._v(_vm._s(entity.makeModel))]), _c("td", [_vm._v(_vm._s(entity.keyNo))]), _c("td", [_vm._v(_vm._s(entity.claimNo))]), _vm.includeClaimsType ? _c("td", [_vm._v(_vm._s(entity.claimsTypeKey))]) : _vm._e(), _c("td", [_vm._v(_vm._s(entity.customerName))]), _c("td", [_vm._v(_vm._s(entity.insurerName))]), _c("td", [_vm._v(_vm._s(_vm.$filters.formatDateTimezone(entity.authorisedDate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "is-email"
    }, [_c("div", [_vm._v(_vm._s(entity.quoteStatus))])]), _c("td", [_vm._v(" " + _vm._s(entity.jobStageText) + " "), entity.subJobStageText ? _c("span", [_vm._v(" - " + _vm._s(entity.subJobStageText))]) : _vm._e()]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "tag",
      class: [entity.quotingMethod === "D" ? "is-success" : "is-info"]
    }, [_vm._v(_vm._s(entity.quotingMethod))])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [entity.invoiceStatus === 1 ? "has-text-warning" : "has-text-success"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [entity.invoiceStatus > 0 ? "mdi-check" : ""]
    })])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [entity.excessInvoiced ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [entity.excessInvoiced ? "mdi-check" : ""]
    })])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [entity.active ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [entity.active ? "mdi-check" : "mdi-close"]
    })])]), _c("td", {
      staticClass: "has-text-centered"
    }, [_c("router-link", {
      attrs: {
        to: {
          path: entity.quoteId
        },
        append: ""
      }
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted tooltip is-tooltip-left",
      attrs: {
        "data-tooltip": "Click to edit"
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])])])], 1)]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])])]), _vm.isPrintQuoteListModalActive ? _c("quote-list-print-modal", {
    attrs: {
      active: _vm.isPrintQuoteListModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isPrintQuoteListModalActive = $event;
      },
      print: _vm.printQuoteList,
      export: _vm.exportToExcel,
      close: _vm.closePrint
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.is-uppercase {\n  text-transform: uppercase;\n}\ninput.is-uppercase::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase::-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase:-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase:-ms-input-placeholder {\n  text-transform: none;\n}\nselect.select-width {\n  min-width: 15em;\n}\n.multiselect__tag {\n  margin: 2px;\n}\n.multi-job-stage-select {\n  max-width: 18vw;\n}\n.multi-job-stage-select .job-stage-group-header {\n  font-weight: bold;\n}\n.multi-job-stage-select .job-stage-sub-option {\n  padding-left: 24px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".entity-summaries-container[data-v-ce66673c] {\n  max-height: calc(100vh - 6.5rem - 2rem - 2rem);\n  overflow-y: auto;\n  border: 1px solid var(--border-color);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/transform.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/transform.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayEach = __webpack_require__(/*! ./_arrayEach */ "./node_modules/lodash/_arrayEach.js"),
    baseCreate = __webpack_require__(/*! ./_baseCreate */ "./node_modules/lodash/_baseCreate.js"),
    baseForOwn = __webpack_require__(/*! ./_baseForOwn */ "./node_modules/lodash/_baseForOwn.js"),
    baseIteratee = __webpack_require__(/*! ./_baseIteratee */ "./node_modules/lodash/_baseIteratee.js"),
    getPrototype = __webpack_require__(/*! ./_getPrototype */ "./node_modules/lodash/_getPrototype.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isFunction = __webpack_require__(/*! ./isFunction */ "./node_modules/lodash/isFunction.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/**
 * An alternative to `_.reduce`; this method transforms `object` to a new
 * `accumulator` object which is the result of running each of its own
 * enumerable string keyed properties thru `iteratee`, with each invocation
 * potentially mutating the `accumulator` object. If `accumulator` is not
 * provided, a new object with the same `[[Prototype]]` will be used. The
 * iteratee is invoked with four arguments: (accumulator, value, key, object).
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @static
 * @memberOf _
 * @since 1.3.0
 * @category Object
 * @param {Object} object The object to iterate over.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @param {*} [accumulator] The custom accumulator value.
 * @returns {*} Returns the accumulated value.
 * @example
 *
 * _.transform([2, 3, 4], function(result, n) {
 *   result.push(n *= n);
 *   return n % 2 == 0;
 * }, []);
 * // => [4, 9]
 *
 * _.transform({ 'a': 1, 'b': 2, 'c': 1 }, function(result, value, key) {
 *   (result[value] || (result[value] = [])).push(key);
 * }, {});
 * // => { '1': ['a', 'c'], '2': ['b'] }
 */
function transform(object, iteratee, accumulator) {
  var isArr = isArray(object),
      isArrLike = isArr || isBuffer(object) || isTypedArray(object);

  iteratee = baseIteratee(iteratee, 4);
  if (accumulator == null) {
    var Ctor = object && object.constructor;
    if (isArrLike) {
      accumulator = isArr ? new Ctor : [];
    }
    else if (isObject(object)) {
      accumulator = isFunction(Ctor) ? baseCreate(getPrototype(object)) : {};
    }
    else {
      accumulator = {};
    }
  }
  (isArrLike ? arrayEach : baseForOwn)(object, function(value, index, object) {
    return iteratee(accumulator, value, index, object);
  });
  return accumulator;
}

module.exports = transform;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2a7bba55", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4c0d288d", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteFiltersMixins.js":
/*!***********************************************!*\
  !*** ./src/views/quote/QuoteFiltersMixins.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["default"] = ({
  filters: {
    formatJobStage: function formatJobStage(value) {
      if (value.toLowerCase() === 'none') {
        return '-- Job Stage --';
      } else {
        return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
          return str.toUpperCase();
        });
      }
    },
    formatPartCondition: function formatPartCondition(value) {
      return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
        return str.toUpperCase();
      });
    }
  }
});

/***/ }),

/***/ "./src/views/quote/QuoteListSideMenu.vue":
/*!***********************************************!*\
  !*** ./src/views/quote/QuoteListSideMenu.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteListSideMenu.vue?vue&type=template&id=20be5a13 */ "./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13");
/* harmony import */ var _QuoteListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteListSideMenu.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss */ "./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss":
/*!********************************************************************************************!*\
  !*** ./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=style&index=1&id=20be5a13&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_style_index_1_id_20be5a13_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13":
/*!*****************************************************************************!*\
  !*** ./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13 ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListSideMenu.vue?vue&type=template&id=20be5a13 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListSideMenu.vue?vue&type=template&id=20be5a13");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListSideMenu_vue_vue_type_template_id_20be5a13__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteListView.vue":
/*!*******************************************!*\
  !*** ./src/views/quote/QuoteListView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true */ "./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true");
/* harmony import */ var _QuoteListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteListView.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true */ "./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "ce66673c",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteListView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/quote/QuoteListView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true":
/*!****************************************************************************************************!*\
  !*** ./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=style&index=0&id=ce66673c&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_style_index_0_id_ce66673c_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true":
/*!*************************************************************************************!*\
  !*** ./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteListView.vue?vue&type=template&id=ce66673c&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteListView_vue_vue_type_template_id_ce66673c_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/storeMixin.js":
/*!***************************************!*\
  !*** ./src/views/quote/storeMixin.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");













var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  created: function created() {
    this.getCompanyItemTypes();
    this.getJobStages(); // Store job stages in vuex
    // this.getExternalSetting('partscheck')
    //this.getSubJobStages() // Store job stages in vuex
    this.getJobNSubJobStages();
    this.getExternalSetting('partscheck');
    // if (this.$route.name !== QuoteRoutes.QuoteListView.name && this.value) {
    //   console.log('get vvvv')
    //   this.getQuoteVehicle(this.value.vehicleId)
    // }
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    companyItemTypes: 'companyItemTypes',
    currentVehicleSnapshot: 'currentVehicleSnapshot',
    currentCustomerSnapshot: 'currentCustomerSnapshot',
    currentInsurerSnapshot: 'currentInsurerSnapshot',
    quoteVehicle: 'quoteVehicle',
    quoteCustomer: 'quoteCustomer',
    quoteInsurer: 'quoteInsurer',
    emtaVehicleStore: 'emtaVehicle',
    standardLabourItems: 'standardLabourItems',
    ntarLoadingItems: 'ntarLoadingItems',
    ntarOtherLoadingItems: 'ntarOtherLoadingItems',
    ntarLoadingValues: 'ntarLoadingValues',
    jobStages: 'jobStages',
    subJobStages: 'subJobStages',
    jobNSubJobStages: 'jobNSubJobStages',
    repairDelayReasons: 'repairDelayReasons',
    partsCheckSettingExists: 'partsCheckSettingExists',
    readOnlyView: 'readOnlyView',
    previousQuoteId: 'previousQuoteId',
    audanetLock: 'audanetLock',
    snapshotDiffVehicle: 'snapshotDiffVehicle',
    snapshotDiffCustomer: 'snapshotDiffCustomer',
    snapshotDiffInsurer: 'snapshotDiffInsurer',
    partsCheckSetting: 'partsCheckSetting'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])(moduleName, ['load', 'getStoreItem', 'getLiteStoreItem', 'addStoreItem', 'addStoreSupplementaryItem', 'saveSnapshot', 'setBaseSnapshot', 'setBaseSnapshotFields', 'clearSnapshots', 'clearHeaders', 'setReturnRoute', 'getCompanyItemTypes', 'getQuoteVehicle', 'getNewVehicle', 'removeQuoteVehicle', 'getQuoteCustomer', 'getNewCustomer', 'removeQuoteCustomer', 'getEmtaVehicle', 'setEmtaVehicle', 'resetEmtaVehicle', 'clearInvoiceState', 'copyStoreQuote', 'getQuoteInsurer', 'getNewInsurer', 'setQuoteInsurer', 'removeQuoteInsurer', 'getStandardLabourItems', 'getNtarLoadingItems', 'getNtarOtherLoadingItems', 'removeLabourItems', 'getNtarLoadingValues', 'getJobStages', 'getSubJobStages', 'getJobNSubJobStages', 'removeJobStages', 'getExternalSetting', 'setReadOnlyView', 'setPreviousQuoteId', 'setAudaNetLock', 'setQuoteVehicle', 'saveVehicleSnapshot', 'saveCustomerSnapshot', 'saveInsurerSnapshot', 'resetJobNSubJobStages'])), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('insurers', {
    setInsurerReturnRoute: 'setReturnRoute',
    editStoreInsurer: 'editStoreItem',
    addStoreInsurer: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('vehicles', {
    setVehicleReturnRoute: 'setReturnRoute',
    editStoreVehicle: 'editStoreItem',
    addStoreVehicle: 'addStoreItem'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_11__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  })),
  beforeRouteLeave: function () {
    var _beforeRouteLeave = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(to, from, next) {
      var isQuoteRoutes;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            // remove quote vehicle, customer & insurer vuex objects when leaving quote pages
            isQuoteRoutes = Object.values(_route_types__WEBPACK_IMPORTED_MODULE_12__["default"]).filter(function (r) {
              return r.name !== _route_types__WEBPACK_IMPORTED_MODULE_12__["default"].QuoteListView.name;
            }).find(function (r) {
              return r.name === to.name;
            });
            if (!isQuoteRoutes) {
              this.resetEmtaVehicle();
              this.removeLabourItems();
            }
            next();
          case 1:
            return _context.a(2);
        }
      }, _callee, this);
    }));
    function beforeRouteLeave(_x, _x2, _x3) {
      return _beforeRouteLeave.apply(this, arguments);
    }
    return beforeRouteLeave;
  }()
});

/***/ })

}]);
//# sourceMappingURL=quote-list-chunk.js.map