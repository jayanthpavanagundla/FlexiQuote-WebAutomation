(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["email-components-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array-buffer.constructor.js */ "./node_modules/core-js/modules/es.array-buffer.constructor.js");
/* harmony import */ var core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array-buffer.slice.js */ "./node_modules/core-js/modules/es.array-buffer.slice.js");
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array-buffer.detached.js */ "./node_modules/core-js/modules/es.array-buffer.detached.js");
/* harmony import */ var core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_detached_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer.js */ "./node_modules/core-js/modules/es.array-buffer.transfer.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.array-buffer.transfer-to-fixed-length.js */ "./node_modules/core-js/modules/es.array-buffer.transfer-to-fixed-length.js");
/* harmony import */ var core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_transfer_to_fixed_length_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.regexp.dot-all.js */ "./node_modules/core-js/modules/es.regexp.dot-all.js");
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.regexp.sticky.js */ "./node_modules/core-js/modules/es.regexp.sticky.js");
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.string.search.js */ "./node_modules/core-js/modules/es.string.search.js");
/* harmony import */ var core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_search_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_VueInputTag__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/VueInputTag */ "./src/components/VueInputTag/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _EmailService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./EmailService */ "./src/components/VueEmail/EmailService.js");
/* harmony import */ var _recentRecipients__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./recentRecipients */ "./src/components/VueEmail/recentRecipients.js");
/* harmony import */ var _utils_DateFunctions__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/utils/DateFunctions */ "./src/utils/DateFunctions.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _services_emailLimits__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @/services/emailLimits */ "./src/services/emailLimits.js");
/* harmony import */ var _attachmentSizes__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./attachmentSizes */ "./src/components/VueEmail/attachmentSizes.js");






































// import _isEmpty from 'lodash/isEmpty'




var SENDING_MESSAGE = 'Sending...';

/* eslint-disable */
var emailValidator = new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
/* eslint-enable */

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VueEmail',
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_29__["FocusInserted"]
  },
  components: {
    VueInputTag: _components_VueInputTag__WEBPACK_IMPORTED_MODULE_30__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_35___default.a,
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_31__["ConfirmModal"]
  },
  props: {
    value: null,
    disabled: {
      type: Boolean,
      default: false
    },
    toEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    ccEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    bccEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    subject: {
      type: String,
      default: ''
    },
    message: {
      type: String,
      default: ''
    },
    attachments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    reportBytes: {
      type: ArrayBuffer,
      default: null
    },
    reportName: {
      type: String,
      default: ''
    },
    reportContentType: {
      type: String,
      default: ''
    },
    quoteImageAttachments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    quoteAttachments: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    assetId: {
      type: String,
      default: ''
    },
    assetType: {
      type: String,
      default: ''
    },
    replyToMessageId: {
      type: String,
      default: ''
    },
    isShowCc: {
      type: Boolean,
      default: false
    },
    isShowBcc: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      // In flight, including any 429 backoff.
      isSending: false,
      sendingMessage: SENDING_MESSAGE,
      isRateLimitModalActive: false,
      rateLimitMessage: '',
      innerEmailer: null,
      showCc: false,
      showBcc: false,
      isValidToEmail: true,
      showToHint: false,
      isValidCcEmail: true,
      showCcHint: false,
      isValidBccEmail: true,
      showBccHint: false,
      innerAttachments: [],
      selectedToEmails: [],
      selectedCcEmails: [],
      selectedBccEmails: [],
      emailFilter: {
        assetId: this.assetId,
        search: '',
        assetTypes: [_enums__WEBPACK_IMPORTED_MODULE_37__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_37__["AssetTypes"].Insurer],
        pageIndex: 1,
        pageSize: 20
      },
      availableToEmails: [],
      availableCcEmails: [],
      availableBccEmails: [],
      // recent previously-sent addresses (whole shop), fetched once on open.
      recentRecipients: [],
      //attachmentsTag: []
      errors: [],
      // PCK-213 - replaced by the API value in created(). Seeded with the fallback so the meter
      // and the Send gate have a sane limit during the fetch rather than 0 or undefined.
      maxTotalAttachmentBytes: _services_emailLimits__WEBPACK_IMPORTED_MODULE_40__["FALLBACK_MAX_TOTAL_BYTES"]
    };
  },
  computed: {
    attachmentList: function attachmentList() {
      return Object(_attachmentSizes__WEBPACK_IMPORTED_MODULE_41__["buildAttachmentList"])(this.innerEmailer, {
        reportName: this.reportName,
        reportBytes: this.reportBytes
      });
    },
    totalAttachmentSize: function totalAttachmentSize() {
      return Object(_attachmentSizes__WEBPACK_IMPORTED_MODULE_41__["sumAttachmentSize"])(this.attachmentList);
    },
    isAttachmentSizeExceeded: function isAttachmentSizeExceeded() {
      return this.totalAttachmentSize > this.maxTotalAttachmentBytes;
    },
    maxAttachmentSizeText: function maxAttachmentSizeText() {
      return this.formatFileSize(this.maxTotalAttachmentBytes);
    },
    attachmentSizePercent: function attachmentSizePercent() {
      if (!this.maxTotalAttachmentBytes) {
        return 0;
      }
      return Math.round(this.totalAttachmentSize / this.maxTotalAttachmentBytes * 100);
    },
    attachmentSizeMessage: function attachmentSizeMessage() {
      if (this.isAttachmentSizeExceeded) {
        return "Total attachment size (".concat(this.formatFileSize(this.totalAttachmentSize), ") exceeds the ").concat(this.maxAttachmentSizeText, " limit. Please remove some attachments to send the email.");
      }
      return "Total attachment size: ".concat(this.formatFileSize(this.totalAttachmentSize));
    },
    canSendEmail: function canSendEmail() {
      var hasToEmails = this.selectedToEmails && this.selectedToEmails.length > 0;
      var withinSizeLimit = !this.isAttachmentSizeExceeded;
      return hasToEmails && withinSizeLimit;
    },
    /**
     * PCK-213 - the quote attachments/images to post IDs for.
     *
     * innerEmailer is the store of record: handleRemovedTag splices removals out of it, and the
     * chips and the running total both read it. The quoteAttachments/quoteImageAttachments props
     * are the parent's scratch copy for the attachment picker - rebuilt from the emailer in
     * attachDocs()/closeDocModal(), committed back in confirmDocSelection(). Nothing refreshes
     * that copy when a chip is removed, so posting IDs from it sent files the user had already
     * deleted: remove 2 of 5 and Send, and the server still fetched all 5 (12MB shown, 20MB sent).
     * Opening the picker appeared to fix it only because attachDocs() re-derives the copy.
     *
     * Fall back to the prop when the emailer does not carry the list at all. Emailer
     * (classes/emails.js) does not define these keys, so QuoteAttachmentCategory - whose selection
     * is a computed over category isSelected flags, never written to the emailer - leaves them
     * undefined, and there the prop is the only selection there is. Callers that do use the
     * emailer always $set an array first, so an emptied list still reads as an array and correctly
     * sends nothing.
     */
    selectedQuoteAttachments: function selectedQuoteAttachments() {
      var _this$innerEmailer;
      return Array.isArray((_this$innerEmailer = this.innerEmailer) === null || _this$innerEmailer === void 0 ? void 0 : _this$innerEmailer.quoteAttachments) ? this.innerEmailer.quoteAttachments : this.quoteAttachments;
    },
    selectedQuoteImageAttachments: function selectedQuoteImageAttachments() {
      var _this$innerEmailer2;
      return Array.isArray((_this$innerEmailer2 = this.innerEmailer) === null || _this$innerEmailer2 === void 0 ? void 0 : _this$innerEmailer2.quoteImageAttachments) ? this.innerEmailer.quoteImageAttachments : this.quoteImageAttachments;
    },
    combinedAttachments: function combinedAttachments() {
      return this.attachmentList;
    }
  },
  watch: {
    innerEmailer: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
        // Show Cc if there are any ccEmails
        if (newVal && Array.isArray(newVal.ccEmails)) {
          this.showCc = newVal.ccEmails.length > 0;
        }
        // Show Bcc if there are any bccEmails
        if (newVal && Array.isArray(newVal.bccEmails)) {
          this.showBcc = newVal.bccEmails.length > 0;
        }
      },
      deep: true
    },
    selectedToEmails: {
      handler: function handler(newVal, oldVal) {
        if (this.stripHeaderMarkers(this.selectedToEmails)) return;
        this.innerEmailer.toEmails.splice(0, this.innerEmailer.toEmails.length);
        this.innerEmailer.toEmails = this.selectedToEmails.map(function (e) {
          return e.email;
        });
      },
      deep: true
    },
    selectedCcEmails: {
      handler: function handler(newVal, oldVal) {
        if (this.stripHeaderMarkers(this.selectedCcEmails)) return;
        this.innerEmailer.ccEmails.splice(0, this.innerEmailer.ccEmails.length);
        this.innerEmailer.ccEmails = this.selectedCcEmails.map(function (e) {
          return e.email;
        });
      },
      deep: true
    },
    selectedBccEmails: {
      handler: function handler(newVal, oldVal) {
        if (this.stripHeaderMarkers(this.selectedBccEmails)) return;
        this.innerEmailer.bccEmails.splice(0, this.innerEmailer.bccEmails.length);
        this.innerEmailer.bccEmails = this.selectedBccEmails.map(function (e) {
          return e.email;
        });
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerEmailer = newVal;
      }
    },
    toEmails: {
      handler: function handler(newVal, oldVal) {
        var _this = this;
        if (oldVal && oldVal.length) {
          oldVal.forEach(function (email) {
            var index = _this.selectedToEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index !== -1) _this.selectedToEmails.splice(index, 1);
          });
        }
        if (newVal && newVal.length) {
          newVal.forEach(function (email) {
            var index = _this.selectedToEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index === -1) _this.selectedToEmails.push({
              name: email,
              email: email
            });
          });
        }
      }
    },
    ccEmails: {
      handler: function handler(newVal, oldVal) {
        var _this2 = this;
        if (oldVal && oldVal.length) {
          oldVal.forEach(function (email) {
            var index = _this2.selectedCcEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index !== -1) _this2.selectedCcEmails.splice(index, 1);
          });
        }
        if (newVal && newVal.length) {
          newVal.forEach(function (email) {
            var index = _this2.selectedCcEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index === -1) _this2.selectedCcEmails.push({
              name: email,
              email: email
            });
          });
        }
      }
    },
    bccEmails: {
      handler: function handler(newVal, oldVal) {
        var _this3 = this;
        if (oldVal && oldVal.length) {
          oldVal.forEach(function (email) {
            var index = _this3.selectedBccEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index !== -1) _this3.selectedBccEmails.splice(index, 1);
          });
        }
        if (newVal && newVal.length) {
          newVal.forEach(function (email) {
            var index = _this3.selectedBccEmails.findIndex(function (i) {
              return i.email === email;
            });
            if (index === -1) _this3.selectedBccEmails.push({
              name: email,
              email: email
            });
          });
        }
      }
    },
    message: {
      handler: function handler(newVal, oldVal) {
        this.innerEmailer.message = newVal;
      }
    },
    subject: {
      handler: function handler(newVal, oldVal) {
        this.innerEmailer.subject = newVal;
      }
    },
    isShowCc: {
      handler: function handler(newVal) {
        this.showCc = newVal;
      }
    },
    isShowBcc: {
      handler: function handler(newVal) {
        this.showBcc = newVal;
      }
    },
    canSendEmail: {
      handler: function handler(newVal) {
        this.$emit('validation-changed', {
          canSend: newVal,
          isAttachmentSizeExceeded: this.isAttachmentSizeExceeded,
          totalSize: this.totalAttachmentSize,
          errors: this.getValidationErrors()
        });
      },
      immediate: true
    }
  },
  created: function created() {
    this.loadMaxAttachmentSize();
    this.innerEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_38___default()(this.value);
    this.populateEmails();
    this.emailFilter.assetTypes = this.innerEmailer.assetTypes;
    this.refreshAttachmentList();
    this.loadRecentRecipients();
    this.getAssetsEmailAddresses();
    this.showCc = this.isShowCc;
    this.showBcc = this.isShowBcc;
  },
  mounted: function mounted() {},
  methods: {
    loadMaxAttachmentSize: function loadMaxAttachmentSize() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return Object(_services_emailLimits__WEBPACK_IMPORTED_MODULE_40__["getMaxTotalAttachmentBytes"])();
            case 1:
              _this4.maxTotalAttachmentBytes = _context.v;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    populateEmails: function populateEmails() {
      var _this5 = this;
      if (this.innerEmailer.toEmails) {
        this.innerEmailer.toEmails.forEach(function (email) {
          return _this5.selectedToEmails.splice(_this5.selectedToEmails.length, 1, {
            name: email,
            email: email
          });
        });
      }
      if (this.innerEmailer.ccEmails) {
        this.innerEmailer.ccEmails.forEach(function (email) {
          return _this5.selectedCcEmails.splice(_this5.selectedCcEmails.length, 1, {
            name: email,
            email: email
          });
        });
      }
      if (this.innerEmailer.bccEmails) {
        this.innerEmailer.bccEmails.forEach(function (email) {
          return _this5.selectedBccEmails.splice(_this5.selectedBccEmails.length, 1, {
            name: email,
            email: email
          });
        });
      }
    },
    toggleCc: function toggleCc() {
      this.showCc = !this.showCc;
    },
    toggleBcc: function toggleBcc() {
      this.showBcc = !this.showBcc;
    },
    // toggleCcBcc() {
    //   this.showCcBcc = !this.showCcBcc
    // },
    getValidationErrors: function getValidationErrors() {
      var errors = [];
      if (!this.selectedToEmails || !this.selectedToEmails.length) {
        errors.push('Email address "To" is not provided.');
      }
      if (this.isAttachmentSizeExceeded) {
        errors.push("Total attachment size (".concat(this.formatFileSize(this.totalAttachmentSize), ") exceeds the ").concat(this.maxAttachmentSizeText, " limit."));
      }
      return errors;
    },
    isValid: function isValid() {
      this.errors = this.getValidationErrors();
      return this.errors.length === 0;
    },
    setSending: function setSending(value) {
      this.isSending = value;
      if (value) {
        this.sendingMessage = SENDING_MESSAGE;
      }
      this.$emit('sending-changed', value);
    },
    // The spinner is reference counted and changing its message means showing it again, so
    // reset first - otherwise each retry leaks a count and strands the overlay.
    onSendRetry: function onSendRetry(_ref) {
      var attempt = _ref.attempt,
        of = _ref.of,
        waitMs = _ref.waitMs;
      this.sendingMessage = "".concat(SENDING_MESSAGE, " retrying in ").concat(Math.round(waitMs / 1000), "s (").concat(attempt, " of ").concat(of, ")");
      this.$resetSpinner();
      this.$showSpinner(this.sendingMessage);
    },
    // A modal rather than a toast: the send has been running a minute by now, so the user may
    // be on another tab and would miss something that dismisses itself.
    notifySendError: function notifySendError(e) {
      if (e && e.isRateLimited) {
        this.rateLimitMessage = e.message;
        this.isRateLimitModalActive = true;
        return;
      }
      this.$notification.openMessageXhrError('Send Email', e);
    },
    send: function send() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var isValid, formData, blob, _iterator, _step, att, fileBlob, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!_this6.isSending) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              isValid = _this6.isValid();
              if (isValid) {
                _context2.n = 2;
                break;
              }
              _this6.$notification.error('Email', _this6.errors.join(' '));
              return _context2.a(2);
            case 2:
              _this6.setSending(true);
              _this6.$showSpinner(SENDING_MESSAGE);
              _context2.p = 3;
              formData = new FormData();
              blob = new Blob([_this6.reportBytes], {
                type: _this6.reportContentType
              });
              if (_this6.innerEmailer.attachments.indexOf(_this6.reportName) > -1) {
                formData.append('report', blob, _this6.reportName);
              }
              // Add custom attachments as files
              if (Array.isArray(_this6.innerEmailer.customAttachments)) {
                _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_this6.innerEmailer.customAttachments);
                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    att = _step.value;
                    if (att && att.fileBytes && att.fileName) {
                      fileBlob = new Blob([att.fileBytes], {
                        type: att.fileType || 'application/octet-stream'
                      });
                      formData.append('customAttachment', fileBlob, att.fileName);
                    }
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
              }
              _this6.innerEmailer.replyToMessageId = _this6.replyToMessageId;
              formData.append('emailer', JSON.stringify(_this6.innerEmailer));
              formData.append('imageIds', JSON.stringify(_this6.selectedQuoteImageAttachments.map(function (i) {
                return i.quoteImageId;
              })));
              formData.append('quoteAttachmentIds', JSON.stringify(_this6.selectedQuoteAttachments.map(function (i) {
                return i.quoteAttachmentId;
              })));
              _context2.n = 4;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].send(formData, function (progress) {
                return _this6.onSendRetry(progress);
              });
            case 4:
              _this6.$notification.openNotificationWithType('success', 'Send Email', 'Email sent successfully');
              _this6.$emit('sent');
              _this6.reset();
              _context2.n = 6;
              break;
            case 5:
              _context2.p = 5;
              _t = _context2.v;
              _this6.notifySendError(_t);
            case 6:
              _context2.p = 6;
              _this6.$hideSpinner();
              _this6.setSending(false);
              return _context2.f(6);
            case 7:
              return _context2.a(2);
          }
        }, _callee2, null, [[3, 5, 6, 7]]);
      }))();
    },
    sendExport: function sendExport(exportOptions, reportOptions) {
      var _arguments = arguments,
        _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        var assessment, formData, blob, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              assessment = _arguments.length > 2 && _arguments[2] !== undefined ? _arguments[2] : null;
              if (!_this7.isSending) {
                _context3.n = 1;
                break;
              }
              return _context3.a(2);
            case 1:
              _this7.setSending(true);
              _this7.$showSpinner(SENDING_MESSAGE);
              _context3.p = 2;
              formData = new FormData();
              blob = new Blob([_this7.reportBytes], {
                type: _this7.reportContentType
              });
              if (_this7.innerEmailer.attachments.indexOf(_this7.reportName) > -1) {
                formData.append('report', blob, _this7.reportName);
              }
              formData.append('emailer', JSON.stringify(_this7.innerEmailer));
              // formData.append('images', JSON.stringify(this.quoteImageAttachments))
              formData.append('imageIds', JSON.stringify(_this7.selectedQuoteImageAttachments.map(function (i) {
                return i.quoteImageId;
              })));
              if (!assessment) {
                _context3.n = 3;
                break;
              }
              _context3.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_39__["default"].requestAuthorityAssessment(_this7.innerEmailer.assetId, assessment);
            case 3:
              _context3.n = 4;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].sendExport(_this7.innerEmailer.assetId, exportOptions, reportOptions, formData, function (progress) {
                return _this7.onSendRetry(progress);
              });
            case 4:
              _this7.$notification.openNotificationWithType('success', 'Send Email', 'Email sent successfully');
              _this7.$emit('sent');
              _context3.n = 6;
              break;
            case 5:
              _context3.p = 5;
              _t2 = _context3.v;
              _this7.notifySendError(_t2);
            case 6:
              _context3.p = 6;
              _this7.$hideSpinner();
              _this7.setSending(false);
              return _context3.f(6);
            case 7:
              return _context3.a(2);
          }
        }, _callee3, null, [[2, 5, 6, 7]]);
      }))();
    },
    newEmailInput: function newEmailInput(newEmail) {
      this.isValidToEmail = newEmail === '' || emailValidator.test(newEmail);
      this.showToHint = this.isValidToEmail && newEmail !== '';
      this.$emit('new-email', newEmail !== '');
    },
    newCcEmailInput: function newCcEmailInput(newEmail) {
      this.isValidCcEmail = newEmail === '' || emailValidator.test(newEmail);
      this.showCcHint = this.isValidCcEmail && newEmail !== '';
      this.$emit('new-email', newEmail !== '');
    },
    newBccEmailInput: function newBccEmailInput(newEmail) {
      this.isValidBccEmail = newEmail === '' || emailValidator.test(newEmail);
      this.showBccHint = this.isValidBccEmail && newEmail !== '';
      this.$emit('new-email', newEmail !== '');
    },
    refreshAttachmentList: function refreshAttachmentList(images) {
      // this.innerEmailer.attachments.splice(0, this.innerEmailer.attachments.length)
      // this.innerEmailer.attachments.splice(this.innerEmailer.attachments.length, 1, this.reportName)
      // // console.log(images)
      // if (!_isEmpty(images)) {
      //   for (var i = 0; i < images.length; i++) {
      //     this.innerEmailer.attachments.splice(this.innerEmailer.attachments.length, 1, images[i].fileName)
      //   }
      // }
    },
    addEmailTag: function addEmailTag(newEmail, id) {
      var isValidEmail = emailValidator.test(newEmail);
      // console.log('newTag', this.isValidToEmail, newEmail)
      if (isValidEmail) {
        var tag = {
          name: newEmail,
          email: newEmail,
          assetTypeName: 'None',
          assetType: 0
        };
        if (id === 'toemails-multiselect') {
          this.isValidToEmail = isValidEmail;
          this.availableToEmails.push(tag);
          this.selectedToEmails.push(tag);
        } else if (id === 'ccemails-multiselect') {
          this.isValidCcEmail = isValidEmail;
          this.availableCcEmails.push(tag);
          this.selectedCcEmails.push(tag);
        } else if (id === 'bccemails-multiselect') {
          this.isValidBccEmail = isValidEmail;
          this.availableBccEmails.push(tag);
          this.selectedBccEmails.push(tag);
        }
      }
    },
    // load the recent-recipients pool once; re-merge the To options if
    // contacts were already fetched before this resolved.
    loadRecentRecipients: function loadRecentRecipients() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        var _t3, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              _context4.p = 0;
              _context4.n = 1;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].getRecentRecipients();
            case 1:
              _t3 = _context4.v;
              if (_t3) {
                _context4.n = 2;
                break;
              }
              _t3 = [];
            case 2:
              _this8.recentRecipients = _t3;
              _context4.n = 4;
              break;
            case 3:
              _context4.p = 3;
              _t4 = _context4.v;
              _this8.recentRecipients = [];
            case 4:
              if (_this8.recentRecipients.length) {
                _this8.getAssetsEmailAddresses();
              }
            case 5:
              return _context4.a(2);
          }
        }, _callee4, null, [[0, 3]]);
      }))();
    },
    stripHeaderMarkers: function stripHeaderMarkers(selected) {
      var index = selected.findIndex(function (e) {
        return e && e.$isLabel;
      });
      if (index !== -1) {
        selected.splice(index, 1);
        return true;
      }
      return false;
    },
    quoteContactSubtitle: function quoteContactSubtitle(option) {
      if (!option) return '';
      if (option.assetTypeName === 'Customer') return 'this quote\'s customer';
      if (option.assetTypeName === 'Insurer') return 'matched work provider';
      return '';
    },
    recentSentLabel: function recentSentLabel(option) {
      if (!option) return '';
      var when = Object(_utils_DateFunctions__WEBPACK_IMPORTED_MODULE_34__["timeAgo"])(option.lastSentOn);
      var times = option.count > 0 ? " \xB7 ".concat(option.count, " ").concat(option.count === 1 ? 'time' : 'times') : '';
      return when ? "Sent ".concat(when).concat(times) : '';
    },
    getAssetsEmailAddresses: lodash_debounce__WEBPACK_IMPORTED_MODULE_36___default()(/*#__PURE__*/function () {
      var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5(query, id) {
        var contacts, _contacts, _contacts2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              // console.log('getAssetsEmailAddresses', query, id)
              if (!this.$guid.validGuid(this.emailFilter.assetId)) {
                this.emailFilter.assetId = this.$guid.empty();
              }
              this.emailFilter.search = query || '';
              if (!(id === 'toemails-multiselect' || !id)) {
                _context5.n = 2;
                break;
              }
              _context5.n = 1;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].getAssetsEmailAddresses(this.emailFilter);
            case 1:
              contacts = _context5.v;
              this.availableToEmails = Object(_recentRecipients__WEBPACK_IMPORTED_MODULE_33__["buildRecipientOptions"])(contacts, this.recentRecipients, this.emailFilter.search);
              _context5.n = 6;
              break;
            case 2:
              if (!(id === 'ccemails-multiselect')) {
                _context5.n = 4;
                break;
              }
              _context5.n = 3;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].getAssetsEmailAddresses(this.emailFilter);
            case 3:
              _contacts = _context5.v;
              this.availableCcEmails = Object(_recentRecipients__WEBPACK_IMPORTED_MODULE_33__["buildRecipientOptions"])(_contacts, this.recentRecipients, this.emailFilter.search);
              _context5.n = 6;
              break;
            case 4:
              if (!(id === 'bccemails-multiselect')) {
                _context5.n = 6;
                break;
              }
              _context5.n = 5;
              return _EmailService__WEBPACK_IMPORTED_MODULE_32__["default"].getAssetsEmailAddresses(this.emailFilter);
            case 5:
              _contacts2 = _context5.v;
              this.availableBccEmails = Object(_recentRecipients__WEBPACK_IMPORTED_MODULE_33__["buildRecipientOptions"])(_contacts2, this.recentRecipients, this.emailFilter.search);
            case 6:
              return _context5.a(2);
          }
        }, _callee5, this);
      }));
      return function (_x, _x2) {
        return _ref2.apply(this, arguments);
      };
    }(), 300),
    reset: function reset() {
      this.selectedToEmails.splice(0, this.selectedToEmails.length);
      this.selectedCcEmails.splice(0, this.selectedCcEmails.length);
      this.selectedBccEmails.splice(0, this.selectedBccEmails.length);
    },
    handleRemovedTag: function handleRemovedTag(_ref3) {
      var tag = _ref3.tag;
      // Clone the current emailer to avoid direct mutations
      var updatedEmailer = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_38___default()(this.innerEmailer);

      // Extract the filename from the tag object
      var tagName = tag.fileName || tag;

      // Remove from customAttachments if present
      if (updatedEmailer.customAttachments) {
        var customIndex = updatedEmailer.customAttachments.findIndex(function (att) {
          return att && att.fileName && att.fileName.toLowerCase() === tagName.toLowerCase();
        });
        if (customIndex !== -1) {
          updatedEmailer.customAttachments.splice(customIndex, 1);
        }
      }

      // Enhanced removal from quoteAttachments
      if (updatedEmailer.quoteAttachments) {
        // Find by multiple possible filename properties and case-insensitive comparison
        var quoteIndex = updatedEmailer.quoteAttachments.findIndex(function (att) {
          if (!att) return false;
          var attName = att.fileName || att.filename || att.name;
          return attName && attName.toLowerCase() === tagName.toLowerCase();
        });
        if (quoteIndex !== -1) {
          // // Store the removed attachment details for potential undo
          // const removedAttachment = updatedEmailer.quoteAttachments[quoteIndex]
          // Remove the attachment
          updatedEmailer.quoteAttachments.splice(quoteIndex, 1);

          // Also remove from attachments array if present
          if (updatedEmailer.attachments) {
            var attachIndex = updatedEmailer.attachments.findIndex(function (att) {
              if (typeof att === 'string') {
                return att.toLowerCase() === tagName.toLowerCase();
              }
              return att && att.fileName && att.fileName.toLowerCase() === tagName.toLowerCase();
            });
            if (attachIndex !== -1) {
              updatedEmailer.attachments.splice(attachIndex, 1);
            }
          }
        }
      }

      // Remove from regular attachments if present
      if (updatedEmailer.attachments) {
        var _attachIndex = updatedEmailer.attachments.findIndex(function (att) {
          if (typeof att === 'string') {
            return att.toLowerCase() === tagName.toLowerCase();
          }
          return att && att.fileName && att.fileName.toLowerCase() === tagName.toLowerCase();
        });
        if (_attachIndex !== -1) {
          updatedEmailer.attachments.splice(_attachIndex, 1);
        }
      }

      //Remove from quoteImageAttachments if present
      if (updatedEmailer.quoteImageAttachments) {
        var imageIndex = updatedEmailer.quoteImageAttachments.findIndex(function (img) {
          if (!img) return false;
          var imgName = img.fileName || img.filename || img.name;
          return imgName && imgName.toLowerCase() === tagName.toLowerCase();
        });
        if (imageIndex !== -1) {
          updatedEmailer.quoteImageAttachments.splice(imageIndex, 1);
        }
      }

      // Update the emailer and emit change event
      this.innerEmailer = updatedEmailer;
      //this.$emit('attachments-updated')
    },
    formatFileSize: function formatFileSize(sizeInBytes) {
      if (!sizeInBytes || sizeInBytes === 0) {
        return '0 KB';
      }
      var units = ['Bytes', 'KB', 'MB', 'GB'];
      var size = sizeInBytes;
      var unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
      }
      return "".concat(size.toFixed(unitIndex === 0 ? 0 : 1), " ").concat(units[unitIndex]);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VueEmailModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_2__["BaseModalEx"]
  },
  props: {
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    },
    buttonLocation: {
      type: String,
      default: 'end' // valid values 'start' & 'end'
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    iconType: {
      type: String,
      default: 'warning'
    },
    iconName: {
      type: String,
      default: 'mdi-alert-decagram'
    },
    toEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    ccEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    bccEmails: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    enableSend: {
      type: Boolean,
      default: false
    },
    // In flight, including any 429 backoff.
    isSending: {
      type: Boolean,
      default: false
    },
    enableAttach: {
      type: Boolean,
      default: true
    },
    toggleAttachButton: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      isActive: false,
      allowedImageExtensions: ['.jpg', '.jpeg', '.png'],
      allowedDocumentExtensions: ['.pdf'],
      showAttachDropdown: false
    };
  },
  computed: {},
  watch: {
    active: function active(value) {
      this.isActive = value;
    }
  },
  mounted: function mounted() {
    this.isActive = this.active || false;
  },
  methods: {
    send: function send() {
      this.$emit('send');
    },
    attach: function attach() {
      this.$emit('show-attach');
    },
    discard: function discard() {
      this.isActive = false;
      this.$emit('update:active', false);
      this.$emit('discard');
    },
    toggleAttachDropdown: function toggleAttachDropdown() {
      // If the toggleAttachButton is true, it means "Done" button is showing
      if (this.toggleAttachButton) {
        // Emit event to close both image and document selectors
        this.$emit('done-attach');
        this.showAttachDropdown = false;
        return;
      }
      this.showAttachDropdown = !this.showAttachDropdown;
    },
    attachImages: function attachImages() {
      this.$emit('show-attach');
      this.showAttachDropdown = false;
    },
    attachDocs: function attachDocs() {
      // this.$emit('show-attach')
      this.$emit('attach-docs');
      this.showAttachDropdown = false;
    },
    attachFiles: function attachFiles() {
      // Trigger the hidden file input
      this.$refs.fileInput.click();
      this.$refs.fileInput.accept = this.allowedImageExtensions.join(',') + ',' + this.allowedDocumentExtensions.join(',');
      // Do NOT close the dropdown here; let onFileChange handle it
    },
    onFileChange: function onFileChange(event) {
      var files = event.target.files;
      //this.$emit('show-attach')
      this.$emit('attach-files', files);
      this.showAttachDropdown = false; // Close dropdown after file selection
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.constructor.js */ "./node_modules/core-js/modules/es.regexp.constructor.js");
/* harmony import */ var core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.dot-all.js */ "./node_modules/core-js/modules/es.regexp.dot-all.js");
/* harmony import */ var core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_dot_all_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.regexp.sticky.js */ "./node_modules/core-js/modules/es.regexp.sticky.js");
/* harmony import */ var core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_sticky_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");














/* eslint-disable */
var validators = {
  email: new RegExp(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/),
  url: new RegExp(/^(https?|ftp|rmtp|mms):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(:(\d+))?\/?/i),
  text: new RegExp(/^[a-zA-Z]+$/),
  digits: new RegExp(/^[\d() \.\:\-\+#]+$/),
  isodate: new RegExp(/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/)
};
/* eslint-enable */

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'VueInputTag',
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_12__["FocusInserted"]
  },
  props: {
    tags: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    placeholder: {
      type: String,
      default: ''
    },
    readOnly: {
      type: Boolean,
      default: false
    },
    validate: {
      type: String | Object,
      default: ''
    },
    addTagOnKeys: {
      type: Array,
      default: function _default() {
        return [13,
        // Return
        188 // Comma ','
        // 9 // Tab
        ];
      }
    },
    addTagOnBlur: {
      type: Boolean,
      default: false
    },
    limit: {
      type: Number,
      default: -1
    },
    tagColour: {
      type: String,
      default: 'is-primary'
    },
    allowInput: {
      type: Boolean,
      default: true
    }
  },
  data: function data() {
    return {
      newTag: '',
      innerTags: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.tags)
    };
  },
  computed: {
    isLimit: function isLimit() {
      return this.limit > 0 && Number(this.limit) === this.innerTags.length;
    }
  },
  watch: {
    tags: function tags() {
      this.innerTags = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.tags);
    },
    newTag: function newTag(newVal, oldVal) {
      this.$emit('new-tag', newVal);
    }
  },
  methods: {
    focusNewTag: function focusNewTag() {
      if (this.readOnly || !this.$el.querySelector('.new-tag')) {
        return;
      }
      this.$el.querySelector('.new-tag').focus();
    },
    addNew: function addNew(e) {
      // Do nothing if the current key code is
      // not within those defined within the addTagOnKeys prop array.
      if (e && this.addTagOnKeys.indexOf(e.keyCode) === -1 && (e.type !== 'blur' || !this.addTagOnBlur) || this.isLimit) {
        return;
      }
      if (e) {
        e.stopPropagation();
        e.preventDefault();
      }
      if (this.newTag && this.innerTags.indexOf(this.newTag) === -1 && this.validateIfNeeded(this.newTag)) {
        this.innerTags.push(this.newTag);
        this.newTag = '';
        this.tagChange();
      }
    },
    validateIfNeeded: function validateIfNeeded(tagValue) {
      if (this.validate === '' || this.validate === undefined) {
        return true;
      } else if (typeof this.validate === 'string' && Object.keys(validators).indexOf(this.validate) > -1) {
        return validators[this.validate].test(tagValue);
      } else if (Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.validate) === 'object' && this.validate.test !== undefined) {
        return this.validate.test(tagValue);
      }
      return true;
    },
    remove: function remove(index) {
      var removedTag = this.innerTags[index];
      this.innerTags.splice(index, 1);
      this.tagChange();
      this.$emit('remove-tag', {
        tag: removedTag,
        index: index
      });
    },
    removeLastTag: function removeLastTag() {
      if (this.newTag) {
        return;
      }
      this.innerTags.pop();
      this.tagChange();
    },
    tagChange: function tagChange() {
      this.$emit('update:tags', this.innerTags);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    class: {
      "is-loading-image-popup": _vm.isSending
    },
    attrs: {
      inert: _vm.isSending
    }
  }, [_vm.isSending ? _c("div", {
    staticClass: "sending-message"
  }, [_vm._v(_vm._s(_vm.sendingMessage))]) : _vm._e(), _c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      id: "toemails-multiselect",
      disabled: _vm.disabled,
      options: _vm.availableToEmails,
      multiple: true,
      "close-on-select": false,
      "clear-on-select": true,
      "preserve-search": true,
      taggable: true,
      placeholder: "Enter email address or search",
      "tag-placeholder": "Press enter to add email",
      label: "email",
      "track-by": "email",
      "show-labels": false,
      searchable: true,
      "internal-search": false
    },
    on: {
      tag: _vm.addEmailTag,
      "search-change": _vm.getAssetsEmailAddresses
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [props.option.$isLabel ? _c("div", {
          staticClass: "recipient-group-header"
        }, [_vm._v(" " + _vm._s(props.option.groupLabel) + " ")]) : _c("div", [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetTypeName === "Customer",
            "is-info": props.option.assetTypeName === "Insurer",
            "recipient-recent-tag": props.option.assetTypeName === "Recent"
          }
        }, [_vm._v(" " + _vm._s(props.option.assetTypeName) + " ")]), props.option.name && props.option.name !== props.option.email ? _c("div", [_vm._v(_vm._s(props.option.name) + " <" + _vm._s(props.option.email) + ">")]) : _c("div", [_vm._v(_vm._s(props.option.email))]), props.option.assetTypeName === "Recent" ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.recentSentLabel(props.option)))]) : props.option.sort === 0 && _vm.quoteContactSubtitle(props.option) ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.quoteContactSubtitle(props.option)))]) : _vm._e()])];
      }
    }, {
      key: "tag",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-primary multiselect-email-tag"
        }, [_vm._v(" " + _vm._s(props.option.email) + " "), _c("button", {
          staticClass: "delete is-small",
          on: {
            click: function click($event) {
              return props.remove(props.option);
            }
          }
        })])];
      }
    }]),
    model: {
      value: _vm.selectedToEmails,
      callback: function callback($$v) {
        _vm.selectedToEmails = $$v;
      },
      expression: "selectedToEmails"
    }
  }), !_vm.isValidToEmail ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Invalid email address")]) : _vm._e(), _vm.showToHint ? _c("span", {
    staticClass: "help is-info"
  }, [_vm._v("Press <Enter> key to add email address")]) : _vm._e()], 1)]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    attrs: {
      tabindex: "-1"
    },
    on: {
      click: _vm.toggleCc
    }
  }, [_c("span", {
    staticClass: "icon is-small is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: [_vm.showCc ? "mdi-chevron-up" : "mdi-chevron-down"]
  })]), _c("span", [_vm._v("Cc")])]), _c("button", {
    staticClass: "button",
    staticStyle: {
      "margin-left": "0.5em"
    },
    attrs: {
      tabindex: "-1"
    },
    on: {
      click: _vm.toggleBcc
    }
  }, [_c("span", {
    staticClass: "icon is-small is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-24px",
    class: [_vm.showBcc ? "mdi-chevron-up" : "mdi-chevron-down"]
  })]), _c("span", [_vm._v("Bcc")])])])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showCc,
      expression: "showCc"
    }],
    staticClass: "field is-horizontal"
  }, [_vm._m(1), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      id: "ccemails-multiselect",
      disabled: _vm.disabled,
      options: _vm.availableCcEmails,
      multiple: true,
      "close-on-select": false,
      "clear-on-select": true,
      "preserve-search": true,
      taggable: true,
      placeholder: "Enter email address or search",
      "tag-placeholder": "Press enter to add email",
      label: "email",
      "track-by": "email",
      "show-labels": false,
      searchable: true,
      "internal-search": false
    },
    on: {
      tag: _vm.addEmailTag,
      "search-change": _vm.getAssetsEmailAddresses
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [props.option.$isLabel ? _c("div", {
          staticClass: "recipient-group-header"
        }, [_vm._v(" " + _vm._s(props.option.groupLabel) + " ")]) : _c("div", [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetTypeName === "Customer",
            "is-info": props.option.assetTypeName === "Insurer",
            "recipient-recent-tag": props.option.assetTypeName === "Recent"
          }
        }, [_vm._v(" " + _vm._s(props.option.assetTypeName) + " ")]), props.option.name && props.option.name !== props.option.email ? _c("div", [_vm._v(_vm._s(props.option.name) + " <" + _vm._s(props.option.email) + ">")]) : _c("div", [_vm._v(_vm._s(props.option.email))]), props.option.assetTypeName === "Recent" ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.recentSentLabel(props.option)))]) : props.option.sort === 0 && _vm.quoteContactSubtitle(props.option) ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.quoteContactSubtitle(props.option)))]) : _vm._e()])];
      }
    }, {
      key: "tag",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-primary multiselect-email-tag"
        }, [_vm._v(" " + _vm._s(props.option.email) + " "), _c("button", {
          staticClass: "delete is-small",
          on: {
            click: function click($event) {
              return props.remove(props.option);
            }
          }
        })])];
      }
    }]),
    model: {
      value: _vm.selectedCcEmails,
      callback: function callback($$v) {
        _vm.selectedCcEmails = $$v;
      },
      expression: "selectedCcEmails"
    }
  })], 1)])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showBcc,
      expression: "showBcc"
    }],
    staticClass: "field is-horizontal"
  }, [_vm._m(2), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      id: "bccemails-multiselect",
      disabled: _vm.disabled,
      options: _vm.availableBccEmails,
      multiple: true,
      "close-on-select": false,
      "clear-on-select": true,
      "preserve-search": true,
      taggable: true,
      placeholder: "Enter email address or search",
      "tag-placeholder": "Press enter to add email",
      label: "email",
      "track-by": "email",
      "show-labels": false,
      searchable: true,
      "internal-search": false
    },
    on: {
      tag: _vm.addEmailTag,
      "search-change": _vm.getAssetsEmailAddresses
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [props.option.$isLabel ? _c("div", {
          staticClass: "recipient-group-header"
        }, [_vm._v(" " + _vm._s(props.option.groupLabel) + " ")]) : _c("div", [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetTypeName === "Customer",
            "is-info": props.option.assetTypeName === "Insurer",
            "recipient-recent-tag": props.option.assetTypeName === "Recent"
          }
        }, [_vm._v(" " + _vm._s(props.option.assetTypeName) + " ")]), props.option.name && props.option.name !== props.option.email ? _c("div", [_vm._v(_vm._s(props.option.name) + " <" + _vm._s(props.option.email) + ">")]) : _c("div", [_vm._v(_vm._s(props.option.email))]), props.option.assetTypeName === "Recent" ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.recentSentLabel(props.option)))]) : props.option.sort === 0 && _vm.quoteContactSubtitle(props.option) ? _c("div", {
          staticClass: "recipient-subtitle"
        }, [_vm._v(_vm._s(_vm.quoteContactSubtitle(props.option)))]) : _vm._e()])];
      }
    }, {
      key: "tag",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-primary multiselect-email-tag"
        }, [_vm._v(" " + _vm._s(props.option.email) + " "), _c("button", {
          staticClass: "delete is-small",
          on: {
            click: function click($event) {
              return props.remove(props.option);
            }
          }
        })])];
      }
    }]),
    model: {
      value: _vm.selectedBccEmails,
      callback: function callback($$v) {
        _vm.selectedBccEmails = $$v;
      },
      expression: "selectedBccEmails"
    }
  }), !_vm.isValidBccEmail ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Invalid email address")]) : _vm._e(), _vm.showBccHint ? _c("span", {
    staticClass: "help is-info"
  }, [_vm._v("Press <Enter> key to add email address")]) : _vm._e()], 1)])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showCc || _vm.showBcc,
      expression: "showCc || showBcc"
    }],
    staticClass: "is-divider"
  }), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: false,
      expression: "false"
    }],
    staticClass: "field is-horizontal"
  }, [_vm._m(3), _vm._m(4)]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(5), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEmailer.subject,
      expression: "innerEmailer.subject"
    }],
    staticClass: "input",
    attrs: {
      disabled: _vm.disabled,
      type: "text",
      placeholder: "Subject"
    },
    domProps: {
      value: _vm.innerEmailer.subject
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEmailer, "subject", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(6), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerEmailer.message,
      expression: "innerEmailer.message"
    }],
    staticClass: "textarea",
    attrs: {
      disabled: _vm.disabled,
      rows: "10",
      placeholder: ""
    },
    domProps: {
      value: _vm.innerEmailer.message
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerEmailer, "message", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(7), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("vue-input-tag", {
    attrs: {
      tags: _vm.combinedAttachments,
      "read-only": _vm.disabled,
      "tag-colour": "is-turquoise",
      "allow-input": false
    },
    on: {
      "remove-tag": _vm.handleRemovedTag
    },
    scopedSlots: _vm._u([{
      key: "tag",
      fn: function fn(_ref) {
        var tag = _ref.tag;
        return [_c("span", [_vm._v(_vm._s(tag.fileName))]), tag.fileSize > 0 ? _c("span", {
          staticClass: "ml-1 is-size-7 has-text-grey"
        }, [_vm._v(" (" + _vm._s(_vm.formatFileSize(tag.fileSize)) + ") ")]) : _vm._e()];
      }
    }])
  }), _vm.combinedAttachments.length > 0 ? _c("div", {
    staticClass: "mt-2"
  }, [_c("div", {
    staticClass: "level is-mobile mb-1"
  }, [_c("div", {
    staticClass: "level-left"
  }, [_c("div", {
    staticClass: "level-item"
  }, [_c("span", {
    staticClass: "has-text-grey is-size-7"
  }, [_vm._v(" " + _vm._s(_vm.combinedAttachments.length) + " files - " + _vm._s(_vm.formatFileSize(_vm.totalAttachmentSize)) + " total ")])])]), _c("div", {
    staticClass: "level-right"
  }, [_c("div", {
    staticClass: "level-item"
  }, [_c("span", {
    staticClass: "has-text-grey is-size-7"
  }, [_vm._v(" " + _vm._s(_vm.formatFileSize(_vm.totalAttachmentSize)) + " / " + _vm._s(_vm.maxAttachmentSizeText) + " ")])])])]), _c("div", {
    staticClass: "progress-container mb-2"
  }, [_c("progress", {
    staticClass: "progress is-small",
    class: {
      "is-danger": _vm.isAttachmentSizeExceeded,
      "": !_vm.isAttachmentSizeExceeded
    },
    attrs: {
      max: _vm.maxTotalAttachmentBytes
    },
    domProps: {
      value: _vm.totalAttachmentSize
    }
  }, [_vm._v(" " + _vm._s(_vm.attachmentSizePercent) + "% ")])]), _vm.isAttachmentSizeExceeded ? _c("div", {
    staticClass: "attachment-warning"
  }, [_vm._m(8), _c("span", [_vm._v("Total attachment size (" + _vm._s(_vm.formatFileSize(_vm.totalAttachmentSize)) + ") exceeds the " + _vm._s(_vm.maxAttachmentSizeText) + " limit."), _c("br"), _vm._v(" Please remove some files.")])]) : _vm._e()]) : _vm._e()], 1)])])]), _vm.isRateLimitModalActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isRateLimitModalActive,
      "show-cancel": false,
      "ok-text": "Ok",
      "icon-type": "danger",
      "icon-name": "error"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRateLimitModalActive = $event;
      },
      ok: function ok($event) {
        _vm.isRateLimitModalActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Email Not Sent")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(_vm._s(_vm.rateLimitMessage))])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("To")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Cc")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Bcc")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("From")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("input", {
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: ""
    }
  })])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Subject")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Message")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Attachments")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-large mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-alert mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 60,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title",
    class: {
      "is-flex-items-center": _vm.showIcon
    }
  }, [_vm.showIcon ? _c("span", {
    staticClass: "icon is-medium",
    class: "has-text-".concat(_vm.iconType),
    staticStyle: {
      "margin-right": "0.5rem"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: "".concat(_vm.iconName)
  })]) : _vm._e(), _c("span", [_vm._v("Send Email")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_vm._t("text-content")], 2), _c("footer", {
    staticClass: "modal-card-foot"
  }, [_c("div", {
    style: "width: 100%; display: flex; justify-content: space-between;"
  }, [_c("div", {
    staticStyle: {
      "align-self": "flex-start"
    }
  }, [false ? undefined : _vm._e()]), _c("div", {
    staticStyle: {
      "align-self": "flex-end"
    }
  }, [_c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.toggleAttachButton,
      expression: "!toggleAttachButton"
    }],
    staticClass: "button is-primary tooltip is-tooltip-topright",
    attrs: {
      "data-tooltip": "Send Email",
      disabled: !_vm.enableSend || _vm.isSending
    },
    on: {
      click: function click($event) {
        return _vm.send();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.isSending ? "mdi-loading mdi-spin" : "mdi-send"
  })]), _c("span", [_vm._v("Send")])]), _c("div", {
    staticClass: "dropdown",
    class: {
      "is-active": _vm.showAttachDropdown
    },
    staticStyle: {
      display: "inline-block"
    }
  }, [_c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.enableAttach,
      expression: "enableAttach"
    }],
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": [!_vm.toggleAttachButton ? "Attach" : "Done"],
      disabled: !_vm.enableAttach || _vm.isSending
    },
    on: {
      click: _vm.toggleAttachDropdown
    }
  }, [!_vm.toggleAttachButton ? _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-paperclip"
  })]) : _c("span", [_vm._v("Done")])]), _c("div", {
    staticClass: "dropdown-menu",
    staticStyle: {
      left: "-120px",
      right: "auto",
      top: "auto",
      bottom: "100%",
      transform: "translateY(-8px)"
    },
    attrs: {
      role: "menu"
    }
  }, [_c("div", {
    staticStyle: {
      position: "absolute",
      left: "130px",
      bottom: "-8px",
      width: "0",
      height: "0",
      "border-left": "8px solid transparent",
      "border-right": "8px solid transparent",
      "border-top": "8px solid #fff",
      "z-index": "2"
    }
  }), _c("div", {
    staticClass: "dropdown-content"
  }, [_c("a", {
    staticClass: "dropdown-item",
    on: {
      click: _vm.attachImages
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-image-multiple"
  })]), _vm._v(" Images ")]), _c("a", {
    staticClass: "dropdown-item",
    on: {
      click: _vm.attachDocs
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-file-document-outline"
  })]), _vm._v(" Documents ")])])])]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: !_vm.toggleAttachButton,
      expression: "!toggleAttachButton"
    }],
    staticClass: "button tooltip is-tooltip-topright",
    attrs: {
      disabled: _vm.isSending,
      "data-tooltip": "Discard Email"
    },
    on: {
      click: function click($event) {
        return _vm.discard();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-18px"
  })])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "vue-input-tag-wrapper",
    class: {
      "read-only": _vm.readOnly
    },
    on: {
      click: function click($event) {
        return _vm.focusNewTag();
      }
    }
  }, [_c("div", {
    staticClass: "field is-grouped is-grouped-multiline"
  }, [_vm._l(_vm.innerTags, function (tag, index) {
    return _c("div", {
      key: index,
      staticClass: "control adjust-margin"
    }, [_c("div", {
      staticClass: "tags has-addons"
    }, [_c("span", {
      staticClass: "tag",
      class: _vm.tagColour
    }, [_vm._t("tag", function () {
      return [_vm._v(" " + _vm._s(tag) + " ")];
    }, {
      tag: tag,
      index: index
    })], 2), !_vm.readOnly ? _c("a", {
      staticClass: "tag is-delete",
      on: {
        click: function click($event) {
          $event.preventDefault();
          $event.stopPropagation();
          return _vm.remove(index);
        }
      }
    }) : _vm._e()])]);
  }), _c("div", {
    staticClass: "control"
  }, [!_vm.readOnly && !_vm.isLimit ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newTag,
      expression: "newTag"
    }],
    ref: "inputtag",
    staticClass: "new-tag",
    attrs: {
      placeholder: _vm.placeholder,
      type: "text",
      disabled: !_vm.allowInput
    },
    domProps: {
      value: _vm.newTag
    },
    on: {
      keydown: [function ($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "delete", [8, 46], $event.key, ["Backspace", "Delete", "Del"])) return null;
        $event.stopPropagation();
        return _vm.removeLastTag.apply(null, arguments);
      }, _vm.addNew],
      blur: _vm.addNew,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.newTag = $event.target.value;
      }
    }
  }) : _vm._e()])], 2)]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-0da37ae2] {\n  margin: 1.2em 0;\n}\n.multiselect-email-tag[data-v-0da37ae2] {\n  margin-right: 0.5rem;\n  text-transform: lowercase !important;\n}\n.recipient-group-header[data-v-0da37ae2] {\n  text-transform: uppercase;\n  font-weight: 700;\n  font-size: 0.7rem;\n  letter-spacing: 0.04em;\n  color: #7a7a7a;\n  cursor: default;\n}\n.recipient-subtitle[data-v-0da37ae2] {\n  font-size: 0.75rem;\n  color: #7a7a7a;\n  text-transform: none;\n}\n.tag.recipient-recent-tag[data-v-0da37ae2] {\n  background-color: #f9bf00;\n  color: rgba(0, 0, 0, 0.7);\n}\n.progress-container .progress[data-v-0da37ae2] {\n  height: 8px;\n  border-radius: 4px;\n}\n.progress-container .progress.is-danger[data-v-0da37ae2]::-webkit-progress-bar {\n  background-color: #f5f5f5;\n}\n.progress-container .progress.is-danger[data-v-0da37ae2]::-webkit-progress-value {\n  background-color: #ff3860;\n}\n.progress-container .progress.is-danger[data-v-0da37ae2]::-moz-progress-bar {\n  background-color: #ff3860;\n}\n.progress-container .progress.is-primary[data-v-0da37ae2]::-webkit-progress-value {\n  background-color: #00d1b2;\n}\n.progress-container .progress.is-primary[data-v-0da37ae2]::-moz-progress-bar {\n  background-color: #00d1b2;\n}\n.is-loading-image-popup[data-v-0da37ae2]::after {\n  position: absolute;\n  top: calc(50% - 2.25em);\n  left: calc(50% - 2.25em);\n}\n.sending-message[data-v-0da37ae2] {\n  position: absolute;\n  top: calc(50% + 2.75em);\n  left: 0;\n  right: 0;\n  text-align: center;\n  font-weight: 600;\n  z-index: 1;\n}\n.attachment-warning[data-v-0da37ae2] {\n  border: 1px solid #e8e8e8;\n  border-radius: 4px;\n  padding: 8px 12px;\n  color: #ff3860;\n  font-size: 0.75rem;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "#toemails-multiselect,\n#ccemails-multiselect,\n#bccemails-multiselect {\n  text-transform: lowercase !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-flex-items-center[data-v-7f06fde4] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".remove-margin[data-v-00d27606] {\n  margin-bottom: 0 !important;\n}\n.adjust-margin[data-v-00d27606] {\n  margin-bottom: 0.25rem !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5ba6dafb", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("458852e2", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("4c8d8c30", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("eef243ee", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VueEmail/EmailService.js":
/*!*************************************************!*\
  !*** ./src/components/VueEmail/EmailService.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/services/emailSendRetry */ "./src/services/emailSendRetry.js");





var baseUrl = '/emails';
/* harmony default export */ __webpack_exports__["default"] = ({
  send: function send(formData, onRetry) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return Object(_services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__["sendWithRetry"])(function () {
              return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post('/emails/send', formData);
            }, {
              onRetry: onRetry
            });
          case 1:
            return _context.a(2, _context.v);
        }
      }, _callee);
    }))();
  },
  sendExport: function sendExport(quoteId, exportOptions, reportOptions, formData, onRetry) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      var url;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            url = "/emails/sendtext/".concat(quoteId, "?exportOptions=").concat(exportOptions, "&reportOptions=").concat(reportOptions);
            _context2.n = 1;
            return Object(_services_emailSendRetry__WEBPACK_IMPORTED_MODULE_4__["sendWithRetry"])(function () {
              return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post(url, formData);
            }, {
              onRetry: onRetry
            });
          case 1:
            return _context2.a(2, _context2.v);
        }
      }, _callee2);
    }))();
  },
  getAssetsEmailAddresses: function getAssetsEmailAddresses(filter) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
        while (1) switch (_context3.n) {
          case 0:
            url = 'emails/assetsemails';
            _context3.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post(url, filter);
          case 1:
            result = _context3.v;
            return _context3.a(2, result.data);
        }
      }, _callee3);
    }))();
  },
  // recent previously-sent recipients for the whole shop (last 3 months).
  getRecentRecipients: function getRecentRecipients() {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
      var url, result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            url = 'emails/recentrecipients';
            _context4.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].get(url);
          case 1:
            result = _context4.v;
            return _context4.a(2, result.data);
        }
      }, _callee4);
    }))();
  },
  getEntitySummaries: function getEntitySummaries(filter) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
        while (1) switch (_context5.n) {
          case 0:
            _context5.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(baseUrl, "/template/list"), filter);
          case 1:
            result = _context5.v;
            return _context5.a(2, result.data);
        }
      }, _callee5);
    }))();
  },
  postEntity: function postEntity(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
        while (1) switch (_context6.n) {
          case 0:
            _context6.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].post("".concat(baseUrl, "/new"), entity);
          case 1:
            result = _context6.v;
            return _context6.a(2, result.data);
        }
      }, _callee6);
    }))();
  },
  putEntity: function putEntity(entity) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
        while (1) switch (_context7.n) {
          case 0:
            _context7.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].put("".concat(baseUrl, "/").concat(entity.id), entity);
          case 1:
            result = _context7.v;
            return _context7.a(2, result.data);
        }
      }, _callee7);
    }))();
  },
  deleteEntity: function deleteEntity(id) {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
      var result;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
        while (1) switch (_context8.n) {
          case 0:
            _context8.n = 1;
            return _services_fq_api__WEBPACK_IMPORTED_MODULE_3__["default"].delete("".concat(baseUrl, "/").concat(id));
          case 1:
            result = _context8.v;
            return _context8.a(2, result.data);
        }
      }, _callee8);
    }))();
  }
});

/***/ }),

/***/ "./src/components/VueEmail/VueEmail.vue":
/*!**********************************************!*\
  !*** ./src/components/VueEmail/VueEmail.vue ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true */ "./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true");
/* harmony import */ var _VueEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VueEmail.vue?vue&type=script&lang=js */ "./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true */ "./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true");
/* harmony import */ var _VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss */ "./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _VueEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "0da37ae2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VueEmail/VueEmail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js":
/*!**********************************************************************!*\
  !*** ./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true":
/*!*******************************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=0&id=0da37ae2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_0_id_0da37ae2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss":
/*!*******************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=style&index=1&id=0da37ae2&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_style_index_1_id_0da37ae2_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true":
/*!****************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmail.vue?vue&type=template&id=0da37ae2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmail_vue_vue_type_template_id_0da37ae2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueEmail/VueEmailModal.vue":
/*!***************************************************!*\
  !*** ./src/components/VueEmail/VueEmailModal.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true */ "./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true");
/* harmony import */ var _VueEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VueEmailModal.vue?vue&type=script&lang=js */ "./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true */ "./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VueEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "7f06fde4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VueEmail/VueEmailModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=style&index=0&id=7f06fde4&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_style_index_0_id_7f06fde4_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true":
/*!*********************************************************************************************!*\
  !*** ./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueEmail/VueEmailModal.vue?vue&type=template&id=7f06fde4&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueEmailModal_vue_vue_type_template_id_7f06fde4_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueEmail/attachmentSizes.js":
/*!****************************************************!*\
  !*** ./src/components/VueEmail/attachmentSizes.js ***!
  \****************************************************/
/*! exports provided: buildAttachmentList, sumAttachmentSize, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buildAttachmentList", function() { return buildAttachmentList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sumAttachmentSize", function() { return sumAttachmentSize; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








/**
 * PCK-213 - one attachment size calculation for every sender.
 *
 * VueEmail and PrintPreview each had their own pair of totalAttachmentSize/combinedAttachments
 * computeds over the same emailer, with rules that had drifted: one deduped by filename and the
 * other did not, one counted the report from reportBytes unconditionally while the other matched
 * it by name, and the customAttachments chains differed. They could disagree about the same email.
 *
 * sizeOf returns null when a size cannot be established, rather than 0. Counting an unknown as
 * zero is what let an oversized send show a green meter.
 */

var nameOf = function nameOf(item) {
  return item && (item.fileName || item.filename || item.name) || null;
};
var sizeOf = function sizeOf(item) {
  if (!item) return null;
  if (item.fileBytes && typeof item.fileBytes.byteLength === 'number') return item.fileBytes.byteLength;
  if (typeof item.originalFileSize === 'number') return item.originalFileSize;
  if (typeof item.fileSize === 'number') return item.fileSize;
  return null;
};
function buildAttachmentList(emailer) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$reportName = _ref.reportName,
    reportName = _ref$reportName === void 0 ? null : _ref$reportName,
    _ref$reportBytes = _ref.reportBytes,
    reportBytes = _ref$reportBytes === void 0 ? null : _ref$reportBytes;
  var list = [];
  var seen = [];
  var add = function add(fileName, fileSize) {
    if (!fileName || seen.includes(fileName)) return;
    seen.push(fileName);
    list.push({
      fileName: fileName,
      fileSize: fileSize
    });
  };
  if (!emailer) return list;
  var reportSize = reportBytes ? reportBytes.byteLength || reportBytes.length || null : null;

  // `attachments` holds bare filename strings for senders that attach a generated report.
  // send()/sendExport() identify it with attachments.indexOf(reportName), so the same match
  // gives us its size. Other strings carry no size and stay null.
  if (Array.isArray(emailer.attachments)) {
    var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(emailer.attachments),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var att = _step.value;
        if (typeof att === 'string') add(att, att === reportName ? reportSize : null);else add(nameOf(att), sizeOf(att));
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  for (var _i = 0, _arr = ['customAttachments', 'quoteAttachments', 'quoteImageAttachments']; _i < _arr.length; _i++) {
    var key = _arr[_i];
    if (Array.isArray(emailer[key])) {
      var _iterator2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(emailer[key]),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var item = _step2.value;
          add(nameOf(item), sizeOf(item));
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }
  return list;
}
function sumAttachmentSize(list) {
  return (list || []).reduce(function (total, item) {
    return total + (item.fileSize || 0);
  }, 0);
}
/* harmony default export */ __webpack_exports__["default"] = ({
  buildAttachmentList: buildAttachmentList,
  sumAttachmentSize: sumAttachmentSize
});

/***/ }),

/***/ "./src/components/VueEmail/recentRecipients.js":
/*!*****************************************************!*\
  !*** ./src/components/VueEmail/recentRecipients.js ***!
  \*****************************************************/
/*! exports provided: buildRecipientOptions, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "buildRecipientOptions", function() { return buildRecipientOptions; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ "./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24__);

























// Build the grouped recipient dropdown options for VueEmail.
//
// vue-multiselect 2.1.9 can't use native grouping (`group-values`) together with
// `taggable` (the "press enter to add email" behaviour we must keep), so sections
// are rendered as non-selectable HEADER MARKER rows injected into a flat option
// list. The option slot branches on `$isLabel` to render a header vs a normal row,
// and the selection watchers strip any `$isLabel` marker so it never becomes a chip.
//
// Sections, in order (each omitted when empty):
//   QUOTE CONTACTS  — this quote's own customer/insurer (contact.sort === 0)
//   RECENT          — previously-sent addresses (deduped vs contacts, capped)
//   ALL CONTACTS    — the rest of the company directory (contact.sort !== 0)

function header(groupLabel, key) {
  return {
    $isLabel: true,
    groupLabel: groupLabel,
    email: "__hdr_".concat(key, "__"),
    name: groupLabel
  };
}

// Recent items matching the query, excluding any address already present as a
// saved contact (contact takes precedence), de-duped and capped.
function filterRecent(recents, contactEmails, query, limit) {
  var q = (query || '').trim().toLowerCase();
  var seen = new Set();
  var matches = [];
  var _iterator = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_1__["default"])(recents),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var r = _step.value;
      if (!r || !r.email) continue;
      var email = r.email.toLowerCase();
      if (contactEmails.has(email) || seen.has(email)) continue;
      if (q) {
        var name = (r.name || '').toLowerCase();
        if (!email.includes(q) && !name.includes(q)) continue;
      }
      seen.add(email);
      matches.push(r);
      if (matches.length >= limit) break;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return matches;
}
function buildRecipientOptions(contacts, recent, query) {
  var recentLimit = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 3;
  var list = Array.isArray(contacts) ? contacts : [];
  var recents = Array.isArray(recent) ? recent : [];
  var quoteContacts = list.filter(function (c) {
    return c && c.sort === 0;
  });
  var allContacts = list.filter(function (c) {
    return c && c.sort !== 0;
  });
  var contactEmails = new Set(list.map(function (c) {
    return c && c.email ? c.email.toLowerCase() : null;
  }).filter(Boolean));
  var recentMatches = filterRecent(recents, contactEmails, query, recentLimit);
  var options = [];
  if (quoteContacts.length) {
    options.push.apply(options, [header('QUOTE CONTACTS', 'quote')].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(quoteContacts)));
  }
  if (recentMatches.length) {
    options.push.apply(options, [header('RECENT', 'recent')].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(recentMatches)));
  }
  if (allContacts.length) {
    options.push.apply(options, [header('ALL CONTACTS', 'all')].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(allContacts)));
  }
  return options;
}
/* harmony default export */ __webpack_exports__["default"] = (buildRecipientOptions);

/***/ }),

/***/ "./src/components/VueInputTag/VueInputTag.vue":
/*!****************************************************!*\
  !*** ./src/components/VueInputTag/VueInputTag.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueInputTag.vue?vue&type=template&id=00d27606&scoped=true */ "./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true");
/* harmony import */ var _VueInputTag_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./VueInputTag.vue?vue&type=script&lang=js */ "./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true */ "./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _VueInputTag_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "00d27606",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/VueInputTag/VueInputTag.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueInputTag.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true":
/*!*************************************************************************************************************!*\
  !*** ./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=style&index=0&id=00d27606&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_style_index_0_id_00d27606_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true":
/*!**********************************************************************************************!*\
  !*** ./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./VueInputTag.vue?vue&type=template&id=00d27606&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/VueInputTag/VueInputTag.vue?vue&type=template&id=00d27606&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_VueInputTag_vue_vue_type_template_id_00d27606_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/components/VueInputTag/index.js":
/*!*********************************************!*\
  !*** ./src/components/VueInputTag/index.js ***!
  \*********************************************/
/*! exports provided: VueInputTag, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _VueInputTag_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./VueInputTag.vue */ "./src/components/VueInputTag/VueInputTag.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "VueInputTag", function() { return _VueInputTag_vue__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/* harmony default export */ __webpack_exports__["default"] = (_VueInputTag_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./src/services/byteUnits.js":
/*!***********************************!*\
  !*** ./src/services/byteUnits.js ***!
  \***********************************/
/*! exports provided: BYTES_PER_MB, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BYTES_PER_MB", function() { return BYTES_PER_MB; });
/**
 * PCK-213 - bytes in a megabyte. Size limits are stored and shown in MB but compared in bytes,
 * so this conversion appeared across the limit services and the uploaders.
 *
 * apps/pwa has its own copy: the two apps are separate builds with no module in common.
 */
var BYTES_PER_MB = 1024 * 1024;
/* harmony default export */ __webpack_exports__["default"] = ({
  BYTES_PER_MB: BYTES_PER_MB
});

/***/ }),

/***/ "./src/services/emailLimits.js":
/*!*************************************!*\
  !*** ./src/services/emailLimits.js ***!
  \*************************************/
/*! exports provided: FALLBACK_MAX_TOTAL_BYTES, getMaxTotalAttachmentBytes, resetEmailLimitsCache, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALLBACK_MAX_TOTAL_BYTES", function() { return FALLBACK_MAX_TOTAL_BYTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMaxTotalAttachmentBytes", function() { return getMaxTotalAttachmentBytes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetEmailLimitsCache", function() { return resetEmailLimitsCache; });
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.is-finite.js */ "./node_modules/core-js/modules/es.number.is-finite.js");
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_fq_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/services/fq-api */ "./src/services/fq-api.js");
/* harmony import */ var _services_byteUnits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/services/byteUnits */ "./src/services/byteUnits.js");





/**
 * PCK-213 - the total email attachment cap, read from the API instead of hardcoded.
 *
 * The cap used to be written into VueEmail and PrintPreview as `25 * 1024 * 1024`, which
 * disagreed with what the server actually enforced, so the composer would happily accept an
 * email the send path then rejected. It now comes from a single Setting row that both ends read.
 *
 * Memoised because two components ask for it and the composer can be opened repeatedly; the cap
 * does not change within a page load.
 *
 * The fallback is deliberately a real limit rather than 0 or Infinity - one would block every
 * email, the other would block none. It matches MailgunService.DEFAULT_ATTACHMENT_TOTAL_SIZE_MB,
 * so an unreachable API degrades to the same number the server falls back to. The server is the
 * authority either way: it names the true limit in its rejection message.
 */

var FALLBACK_MAX_TOTAL_BYTES = 15 * _services_byteUnits__WEBPACK_IMPORTED_MODULE_3__["BYTES_PER_MB"];
var cached = null;
function getMaxTotalAttachmentBytes() {
  if (!cached) {
    cached = _services_fq_api__WEBPACK_IMPORTED_MODULE_2__["default"].get('/settings/emailattachmentlimit').then(function (response) {
      var bytes = response && response.data ? Number(response.data.maxTotalBytes) : NaN;
      return Number.isFinite(bytes) && bytes > 0 ? bytes : FALLBACK_MAX_TOTAL_BYTES;
    }).catch(function () {
      return FALLBACK_MAX_TOTAL_BYTES;
    });
  }
  return cached;
}

/** Test seam - drops the memoised result so each spec starts clean. */
function resetEmailLimitsCache() {
  cached = null;
}
/* harmony default export */ __webpack_exports__["default"] = ({
  getMaxTotalAttachmentBytes: getMaxTotalAttachmentBytes,
  resetEmailLimitsCache: resetEmailLimitsCache,
  FALLBACK_MAX_TOTAL_BYTES: FALLBACK_MAX_TOTAL_BYTES
});

/***/ })

}]);
//# sourceMappingURL=email-components-chunk.js.map