(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quickitem-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quickitem/storeMixin.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
// import QuickItemService from './QuickItemService'



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickitemDetail',
  inject: ['$vv'],
  components: {
    // QuickItemService,
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_2__["FocusInserted"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_0__["default"]],
  props: {
    value: null,
    isNew: Boolean
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    //   this.$eventHub.$on(EventHubTypes.EntitySaved, data => {
    //     this.onEntitySaved(data)
    //   })
    //  this.$eventHub.$on(EventHubTypes.EntityReload, () => {
    //   this.onReload()
    //  })
  },
  mounted: function mounted() {
    this.$v.detailGroup.$touch();
  },
  methods: {
    toggleActive: function toggleActive(deleted) {
      this.value.deleted = deleted;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/quickitem/route-types.js");


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickitemSideMenu',
  inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  mixins: [],
  props: {
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_1__["default"];
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.pad-start.js */ "./node_modules/core-js/modules/es.string.pad-start.js");
/* harmony import */ var core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _QuickItemSideMenu__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./QuickItemSideMenu */ "./src/views/quickitem/QuickItemSideMenu.vue");
/* harmony import */ var _QuickItemValidation__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./QuickItemValidation */ "./src/views/quickitem/QuickItemValidation.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./route-types */ "./src/views/quickitem/route-types.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quickitem/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _QuickItemService__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./QuickItemService */ "./src/views/quickitem/QuickItemService.js");






















// import HttpStatus from '@/components/http-status'










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuickItemView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_20__["default"]
  }, _QuickItemSideMenu__WEBPACK_IMPORTED_MODULE_17__["default"].name, _QuickItemSideMenu__WEBPACK_IMPORTED_MODULE_17__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_21__["UnsavedModal"]),
  mixins: [_QuickItemValidation__WEBPACK_IMPORTED_MODULE_18__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_24__["default"]],
  props: {
    isNew: Boolean,
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      // isSaveConflictModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null // stores "to" route of beforeRouteLeave
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error;
    }
  },
  watch: {
    entity: {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_26___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(this.entity));
        }
      }, 500),
      deep: true
    }
  },
  beforeDestroy: function beforeDestroy() {
    // this.clearSessionStorage()
    // this.clearSnapshots(this.entity.itemQuickId)
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.returnUrl) {
              _this.persistQueries();
              _this.replaceRoute(_this.$route.params.itemQuickId);
            }
            _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_23__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_23__["AppHeaderButtonTypes"].Print:
          this.print1();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_23__["AppHeaderButtonTypes"].Delete:
          this.entity.deleted = true;
          this.save(true);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_23__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_23__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.itemQuickId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.itemQuickId);
            case 2:
              _this2.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(_this2.currentSnapshot);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('', _t);
            case 4:
              _this2.$hideSpinner();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var title, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              title = 'Quick Item';
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context3.a(2, false);
            case 1:
              _context3.p = 1;
              _this3.$showSpinner('Saving...');
              _this3.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(_this3.entity));
              if (!_this3.entity.isNew) {
                _context3.n = 3;
                break;
              }
              _context3.n = 2;
              return _QuickItemService__WEBPACK_IMPORTED_MODULE_31__["default"].postQuickItem(_this3.entity);
            case 2:
              _context3.n = 6;
              break;
            case 3:
              if (!_this3.snapshotDiff) {
                _context3.n = 5;
                break;
              }
              _context3.n = 4;
              return _QuickItemService__WEBPACK_IMPORTED_MODULE_31__["default"].putQuickItem(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(_this3.entity), _this3.snapshotDiff);
            case 4:
              _context3.n = 6;
              break;
            case 5:
              _this3.$notification.openNotificationWithType('warning', title, 'No changes detected. Not saved');
              return _context3.a(2, false);
            case 6:
              // await this.removeStoreItem(this.entity.id)
              _this3.$notification.success('Quick Item', isDelete ? 'Quick Item set to In-Active' : 'Save successful');
              if (_this3.isSaveContinue) {
                _context3.n = 7;
                break;
              }
              _context3.n = 7;
              return _this3.getEntity(true);
            case 7:
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_23__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 8:
              _context3.p = 8;
              _t2 = _context3.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_22__["default"].$emit('serviceError', _t2.response.status);
              // if (e.response.request.status === HttpStatus.CONFLICT) {
              //   this.isSaveConflictModalActive = true
              // } else {
              _this3.$notification.openMessageXhrError('Quick Item', _t2);
              return _context3.a(2, false);
            case 9:
              _context3.p = 9;
              _this3.$hideSpinner();
              return _context3.f(9);
            case 10:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 8, 9, 10]]);
      }))();
    },
    deleteEntity: function deleteEntity(saveEntity) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.entity.deleted = true;
              if (saveEntity) {
                _this4.save(true);
              }
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(this.entity));
      if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_27___default()(this.returnRoute)) {
        this.$router.push({
          path: this.returnRoute.path,
          query: this.returnRoute.query
        });
      } else if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        // const returnUrl = sessionStorage.getItem(this.returnUrlKey)
        // if it comes from url => redirect after save
        if (this.returnUrl) {
          if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
            this.isUnsavedModalActive = true;
          } else {
            this.clearSessionStorage();
            this.clearSnapshots(this.entity.id);
            this.$showSpinner('Returning...');
            this.redirectToQueryUrl(this.returnUrl);
          }
        } else {
          if (this.entity.isNew && this.isSkipSave) {
            // cleanup vuex store
            this.clearSnapshots(this.entity.id);
          }
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_19__["default"].QuickItemListView.name,
            filter: this.filter,
            query: {
              filter: this.encodedFilter
            }
          });
        }
      }
    },
    print: function print() {
      var params = {
        reportname: 'rptTableItemsQuick',
        RecordID: this.entity.itemQuickId,
        CompanyID: this.$userInfo.companyId
      };
      var url = "".concat("", "/modules/reports/printpreview.aspx?") + Object.keys(params).map(function (e) {
        return "".concat(e, "=").concat(params[e]);
      }).join('&');
      window.open(url, '_blank');
    },
    saveContinue: function saveContinue() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _this5.isUnsavedModalActive = false;
              _this5.isSaveContinue = true;
              _context5.n = 1;
              return _this5.save();
            case 1:
              _this5.isSaveContinue = _context5.v;
              if (_this5.isSaveContinue) {
                _this5.cancel();
              }
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    print1: function print1() {
      var params = Object.assign({
        CompanyID: this.$userInfo.companyId,
        RecordID: this.entity.itemQuickId
      });
      // const query = this.$lzstring.compressToEncodedURIComponent(
      //   Object.keys(params)
      //     .map(e => `${e}=${params[e]}`)
      //     .join('&')
      // )
      var keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_30__["KeyValuePairModel"].convertToKeyValuePairs(params);
      this.addReportParameters(keyValuePairs);
      var emailer = new _classes__WEBPACK_IMPORTED_MODULE_29__["Emailer"]();
      var itemno = 'Q' + ("".concat(this.entity.lineNumber) + '').padStart(3, '0');
      // var itemno = ('000' + `${this.entity.lineNumber}`).slice(-3)
      emailer.assetId = this.entity.itemQuickId;
      emailer.subject = 'Quick Item Details - ' + itemno;
      emailer.reportName = 'QuickItemDetail-' + itemno;
      this.addEmailer(emailer);
      this.$router.push({
        name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_28__["default"].PrintPreview.name,
        params: {
          reportName: this.$route.meta.report
        },
        query: {
          parameterId: this.$guid.newGuid(),
          emailerId: emailer.id
        }
      });
      // window.open(printPreviewRoute.href, '_blank')
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      // this.isSaveConflictModalActive = false
      this.isSaveContinue = false;
      this.toRoute = null;
    },
    reloadData: function reloadData() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              // this.isSaveConflictModalActive = false
              _this6.isSaveContinue = false;
              _context6.n = 1;
              return _this6.getEntity(true);
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickitem|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|quickitem|type"), this.type);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quickitem|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quickitem|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_19__["default"].QuickItemDetail.name,
        params: {
          itemQuickId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_25___default()(this.entity));
    if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entity.itemQuickId);
      this.clearSessionStorage();
      this.clearRouteMeta();
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-ancestor is-parent"
  }, [_c("div", {
    staticClass: "tile"
  }, [_c("div", {
    staticClass: "tile is-parent is-half"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(0), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Item No.")]), _c("span", [_vm._v("Q" + _vm._s(_vm.$filters.pad(_vm.value.lineNumber, 3)))])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Description")]), _c("div", {
    staticClass: "control desc-width"
  }, [_c("textarea", {
    directives: [{
      name: "focus-inserted",
      rawName: "v-focus-inserted"
    }, {
      name: "model",
      rawName: "v-model",
      value: _vm.value.itemDesc,
      expression: "value.itemDesc"
    }],
    staticClass: "textarea",
    class: {
      "is-danger": _vm.$v.entity.itemDesc.$error
    },
    attrs: {
      placeholder: "Item Description",
      rows: "3",
      cols: "10"
    },
    domProps: {
      value: _vm.value.itemDesc
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "itemDesc", $event.target.value);
      }
    }
  }), _vm._v(" "), _vm.$v.entity && !_vm.$v.entity.itemDesc.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Description is required")]) : _vm._e()])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Quantity")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 1,
      precision: 0
    },
    model: {
      value: _vm.value.quantity,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "quantity", _vm._n($$v));
      },
      expression: "value.quantity"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Price")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0.0,
      precision: 2
    },
    model: {
      value: _vm.value.price,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "price", _vm._n($$v));
      },
      expression: "value.price"
    }
  })], 1)])])]), _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _vm.$user.hasDelete(_vm.$route.meta.id) ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "buttons has-addons is-centered"
  }, [_c("span", {
    staticClass: "button",
    class: {
      "is-success is-selected": !_vm.value.deleted
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(false);
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Active")])]), _c("span", {
    staticClass: "button",
    class: {
      "is-danger is-selected": _vm.value.deleted
    },
    on: {
      click: function click($event) {
        return _vm.toggleActive(true);
      }
    }
  }, [_vm._m(2), _c("span", [_vm._v("In-Active")])])])]) : _vm._e()])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-check"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Item No: Q" + _vm._s(_vm.$filters.pad(_vm.entityName, 3)) + " ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.QuickItemDetail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", {
    class: {
      "has-badge-danger has-badge-small has-badge-rounded has-badge-offset2": _vm.$v.detailGroup.$error
    },
    attrs: {
      "data-badge": _vm.$v.detailGroup.$error ? "" : null
    }
  }, [_vm._v(" Detail Info ")])])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.entity && !_vm.entity.isNew,
      "show-delete": _vm.entity && !_vm.entity.deleted && !_vm.entity.isNew
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("quickitem-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": "".concat(_vm.entity.lineNumber)
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-381113b8] {\n  margin: 1.2em 0;\n}\n.desc-width[data-v-381113b8] {\n  width: 50%;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("144819db", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quickitem/QuickItemDetail.vue":
/*!*************************************************!*\
  !*** ./src/views/quickitem/QuickItemDetail.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true */ "./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true");
/* harmony import */ var _QuickItemDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickItemDetail.vue?vue&type=script&lang=js */ "./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true */ "./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuickItemDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "381113b8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickitem/QuickItemDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js":
/*!*************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true":
/*!**********************************************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=style&index=0&id=381113b8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_style_index_0_id_381113b8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true":
/*!*******************************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemDetail.vue?vue&type=template&id=381113b8&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemDetail_vue_vue_type_template_id_381113b8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickitem/QuickItemSideMenu.vue":
/*!***************************************************!*\
  !*** ./src/views/quickitem/QuickItemSideMenu.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickItemSideMenu.vue?vue&type=template&id=2ca68706 */ "./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706");
/* harmony import */ var _QuickItemSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickItemSideMenu.vue?vue&type=script&lang=js */ "./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuickItemSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickitem/QuickItemSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706":
/*!*********************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemSideMenu.vue?vue&type=template&id=2ca68706 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemSideMenu.vue?vue&type=template&id=2ca68706");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemSideMenu_vue_vue_type_template_id_2ca68706__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickitem/QuickItemValidation.js":
/*!****************************************************!*\
  !*** ./src/views/quickitem/QuickItemValidation.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    detailGroup: ['entity.itemDesc'],
    entity: {
      itemDesc: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"],
        maxLength: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["maxLength"])(300)
      }
    },
    filter: {}
  }
});

/***/ }),

/***/ "./src/views/quickitem/QuickItemView.vue":
/*!***********************************************!*\
  !*** ./src/views/quickitem/QuickItemView.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuickItemView.vue?vue&type=template&id=cf5e1868 */ "./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868");
/* harmony import */ var _QuickItemView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuickItemView.vue?vue&type=script&lang=js */ "./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _QuickItemView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quickitem/QuickItemView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868":
/*!*****************************************************************************!*\
  !*** ./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868 ***!
  \*****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuickItemView.vue?vue&type=template&id=cf5e1868 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quickitem/QuickItemView.vue?vue&type=template&id=cf5e1868");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuickItemView_vue_vue_type_template_id_cf5e1868__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quickitem/storeMixin.js":
/*!*******************************************!*\
  !*** ./src/views/quickitem/storeMixin.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'quickitems';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=quickitem-chunk.js.map