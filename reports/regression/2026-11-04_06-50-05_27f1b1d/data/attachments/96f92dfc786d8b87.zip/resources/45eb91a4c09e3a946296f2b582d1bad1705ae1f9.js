(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-builder-chunk~quote-detail-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: MENU_MODES, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_MODES", function() { return _MENU_MODES; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.object.freeze.js */ "./node_modules/core-js/modules/es.object.freeze.js");
/* harmony import */ var core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_freeze_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/views/quote/components/repairAreaGroupingData.js */ "./src/views/quote/components/repairAreaGroupingData.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/utils */ "./src/utils.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_37__);






































var _MENU_MODES = Object.freeze({
  MANUAL: 'manual',
  TEMPLATES: 'templates',
  VEHICLE: 'vehicle'
});

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteBuilderSidebar',
  props: {
    value: null,
    //quote object
    selectedMenu: {
      type: String,
      default: _MENU_MODES.MANUAL
    },
    selectedSubSections: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    selectedArea: {
      type: String,
      default: null
    },
    availableItemsType: {
      type: String,
      default: 'PARTS'
    },
    isQuoteEditable: {
      type: Boolean,
      default: true
    }
  },
  data: function data() {
    return {
      mainQuote: null,
      supplementaryQuotes: null,
      innerSelectedSubSections: [],
      innerSelectedArea: null
    };
  },
  computed: {
    MENU_MODES: function MENU_MODES() {
      return _MENU_MODES;
    },
    isShowVehicleSectionContent: function isShowVehicleSectionContent() {
      return this.availableItemsType === 'PARTS' || this.availableItemsType === 'LABOUR';
    },
    computedAreasWithParts: function computedAreasWithParts() {
      // Import repair area data
      var allAreas = _views_quote_components_repairAreaGroupingData_js__WEBPACK_IMPORTED_MODULE_34__["repairAreaGroupingData"];
      var predefinedAreas = ['Front', 'Centre', 'Rear', 'Trim/Glass'];
      var areaGroups = {};
      predefinedAreas.forEach(function (areaName, index) {
        areaGroups[areaName] = {
          parts: []
        };
      });
      if (this.innerSelectedSubSections && this.innerSelectedSubSections.length > 0) {
        this.innerSelectedSubSections.forEach(function (item) {
          if (item.selected !== true) return;
          var areaName = item.area || item.section || 'Other';
          if (predefinedAreas.includes(areaName)) {
            var _partDetails, _partDetails2;
            var areaKey = _utils__WEBPACK_IMPORTED_MODULE_35__["default"].toCamelCase(areaName);
            var areaData = allAreas[areaKey];
            var partDetails = null;
            if (areaData) {
              partDetails = areaData.items.find(function (p) {
                return p.partId === item.partId;
              });
            }
            var part = {
              partId: item.partId,
              partName: ((_partDetails = partDetails) === null || _partDetails === void 0 ? void 0 : _partDetails.partName) || item.partName || item.partId,
              area: item.area,
              selected: item.selected === true,
              sortOrder: item.sortOrder || ((_partDetails2 = partDetails) === null || _partDetails2 === void 0 ? void 0 : _partDetails2.sortOrder) || 999,
              originalItem: item,
              isFilter: item.isFilter || false
            };
            areaGroups[areaName].parts.push(part);
          }
        });
        predefinedAreas.forEach(function (areaName) {
          areaGroups[areaName].parts.sort(function (a, b) {
            return a.sortOrder - b.sortOrder;
          });
        });
      }
      var result = predefinedAreas.map(function (areaName) {
        var areaData = areaGroups[areaName];
        return {
          name: areaName,
          parts: areaData.parts
        };
      });
      return result;
    },
    itemTypes: function itemTypes() {
      var categories = new Set(['RR', 'REP', 'PAINT', 'MECH', 'PART', 'MISC', 'SUBL']);
      var itemCategories = this.$company.itemCategories ? this.$company.itemCategories.filter(function (i) {
        return i.enabled && categories.has(i.itemCategoryType);
      }) : [];
      return itemCategories;
    },
    mainSuppQuotePercentages: function mainSuppQuotePercentages() {
      var totals = this.mainSuppQuoteTotals;
      var totalExGst = this.totalExGst;
      if (totalExGst == 0) {
        return Object.keys(totals).reduce(function (acc, key) {
          acc[key] = 0;
          return acc;
        }, {});
      }
      return Object.keys(totals).reduce(function (acc, key) {
        acc[key] = totals[key] / totalExGst * 100;
        return acc;
      }, {});
    },
    totalExGst: function totalExGst() {
      return Object.values(this.mainSuppQuoteTotals).reduce(function (sum, val) {
        return sum + val;
      }, 0);
    },
    totalIncGst: function totalIncGst() {
      if (!this.totalExGst) return 0;
      return this.totalExGst + this.totalExGst * (this.value.gstRate / 100);
    },
    isSuppQuote: function isSuppQuote() {
      return this.value && this.value.subQuoteNo ? this.value.subQuoteNo > 0 : false;
    },
    mainSuppQuoteTotals: function mainSuppQuoteTotals() {
      var _this = this;
      var suppQuotes = this.supplementaryQuotes || []; // ensure it's an array
      var mainQuote = this.mainQuote || null;
      if (!this.value) {
        return {
          RR: 0,
          REP: 0,
          PAINT: 0,
          MECH: 0,
          PART: 0,
          MISC: 0,
          SUBL: 0
        };
      }
      if (!this.isSuppQuote) {
        // load a main quote
        return {
          RR: this.calculateGrandTotal(this.value.rrTotal || 0, suppQuotes.map(function (q) {
            return q.rrTotal || 0;
          })),
          REP: this.calculateGrandTotal(this.value.repairTotal || 0, suppQuotes.map(function (q) {
            return q.repairTotal || 0;
          })),
          PAINT: this.calculateGrandTotal(this.value.paintTotal || 0, suppQuotes.map(function (q) {
            return q.paintTotal || 0;
          })),
          MECH: this.calculateGrandTotal(this.value.mechTotal || 0, suppQuotes.map(function (q) {
            return q.mechTotal || 0;
          })),
          PART: this.calculateGrandTotal(this.value.partTotal || 0, suppQuotes.map(function (q) {
            return q.partTotal || 0;
          })),
          MISC: this.calculateGrandTotal(this.value.miscTotal || 0, suppQuotes.map(function (q) {
            return q.miscTotal || 0;
          })),
          SUBL: this.calculateGrandTotal(this.value.sublTotal || 0, suppQuotes.map(function (q) {
            return q.sublTotal || 0;
          }))
        };
      } else {
        // load a supp quote
        if (!mainQuote) {
          // Return a default object while loading
          return {
            RR: 0,
            REP: 0,
            PAINT: 0,
            MECH: 0,
            PART: 0,
            MISC: 0,
            SUBL: 0
          };
        }
        var suppQuotesExcludingCurrent = suppQuotes.filter(function (quote) {
          return quote.quoteId !== _this.value.quoteId;
        });
        return {
          RR: this.calculateGrandTotal(mainQuote.rrTotal + this.value.rrTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.rrTotal || 0;
          })),
          REP: this.calculateGrandTotal(mainQuote.repairTotal + this.value.repairTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.repairTotal || 0;
          })),
          PAINT: this.calculateGrandTotal(mainQuote.paintTotal + this.value.paintTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.paintTotal || 0;
          })),
          MECH: this.calculateGrandTotal(mainQuote.mechTotal + this.value.mechTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.mechTotal || 0;
          })),
          PART: this.calculateGrandTotal(mainQuote.partTotal + this.value.partTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.partTotal || 0;
          })),
          MISC: this.calculateGrandTotal(mainQuote.miscTotal + this.value.miscTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.miscTotal || 0;
          })),
          SUBL: this.calculateGrandTotal(mainQuote.sublTotal + this.value.sublTotal, suppQuotesExcludingCurrent.map(function (q) {
            return q.sublTotal || 0;
          }))
        };
      }
    }
  },
  watch: {
    selectedMenu: {
      handler: function handler(newVal) {
        if (newVal === _MENU_MODES.VEHICLE && !this.computedAreasWithParts.length) {
          this.$emit('modify');
        }
      }
    },
    selectedSubSections: {
      handler: function handler(newVal) {
        this.reset();
        this.innerSelectedSubSections = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_37___default()(newVal);
      },
      deep: true,
      immediate: false
    },
    isQuoteEditable: {
      handler: function handler(newVal) {
        if (newVal == false) {
          this.$emit('update:selectedMenu', _MENU_MODES.MANUAL);
        }
      },
      immediate: true
    }
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this2.innerSelectedSubSections = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_37___default()(_this2.selectedSubSections);
            _context.n = 1;
            return _this2.getMainQuote();
          case 1:
            _context.n = 2;
            return _this2.getSupplementaryQuoteTotals();
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    this.$emit('update:selectedMenu', _MENU_MODES.MANUAL);
  },
  methods: {
    filterByArea: function filterByArea(area) {
      if (!area || !area.name) return;
      if (this.innerSelectedArea === area.name) {
        this.innerSelectedArea = null;
        this.$emit('update:selectedArea', this.innerSelectedArea);
        return;
      }
      this.innerSelectedSubSections = this.innerSelectedSubSections.map(function (subSection) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, subSection), {}, {
          isFilter: false
        });
      });
      this.innerSelectedArea = area.name;
      this.$emit('update:selectedArea', this.innerSelectedArea);
      // this.$emit('update:selectedSubSections', this.innerSelectedSubSections)
    },
    togglePartSelection: function togglePartSelection(part, area) {
      if (this.innerSelectedSubSections) {
        this.innerSelectedSubSections = this.innerSelectedSubSections.map(function (section) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, section), {}, {
            isFilter: section.partId === part.partId && section.area === part.area
          });
        });
      }
      this.innerSelectedArea = null;
      this.$emit('update:selectedArea', this.innerSelectedArea);
      this.$emit('update:selectedSubSections', this.innerSelectedSubSections);
    },
    removePartSelection: function removePartSelection(part) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var item, data;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              if (!_this3.innerSelectedSubSections) {
                _context2.n = 2;
                break;
              }
              _this3.innerSelectedSubSections = _this3.innerSelectedSubSections.map(function (section) {
                if (section.partId === part.partId && section.area === part.area) {
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, section), {}, {
                    selected: false,
                    isFilter: false
                  });
                }
                return section;
              });
              item = _this3.innerSelectedSubSections.find(function (section) {
                return section.partId === part.partId && section.area === part.area;
              });
              if (!item) {
                _context2.n = 2;
                break;
              }
              data = {
                area: item.area,
                butterflyCode: item.partId,
                butterflyDesc: item.partName,
                isSelected: item.selected,
                sortOrder: item.sortOrder
              };
              _context2.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_36__["default"].updateQuoteButterflyIsSelected(_this3.value.quoteId, data);
            case 1:
              _this3.ensureFilterItemExists();
            case 2:
              _this3.innerSelectedArea = null;
              _this3.$emit('update:selectedArea', _this3.innerSelectedArea);
              _this3.$emit('update:selectedSubSections', _this3.innerSelectedSubSections);
            case 3:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    ensureFilterItemExists: function ensureFilterItemExists() {
      var hasFilterItem = this.innerSelectedSubSections.some(function (item) {
        return item.isFilter === true;
      });
      if (!hasFilterItem) {
        var firstSelectedItem = this.innerSelectedSubSections.find(function (item) {
          return item.selected === true;
        });
        if (firstSelectedItem) {
          this.$set(firstSelectedItem, 'isFilter', true);
        }
      }
    },
    calculateGrandTotal: function calculateGrandTotal(mainCategorytotal, supplementaryCategoryTotalsArray) {
      var suppCategoryTotal = supplementaryCategoryTotalsArray.reduce(function (total, suppTotal) {
        return total + suppTotal;
      }, 0);
      return mainCategorytotal + suppCategoryTotal;
    },
    getSupplementaryQuoteTotals: function getSupplementaryQuoteTotals() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!(_this4.isSuppQuote && _this4.value.subQuoteNos.length > 1 && _this4.value.isNew)) {
                _context3.n = 2;
                break;
              }
              _context3.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_36__["default"].getSupplementaryQuoteTotals(_this4.value.subQuoteNos[0].value);
            case 1:
              _this4.supplementaryQuotes = _context3.v;
              return _context3.a(2);
            case 2:
              if (!(_this4.value && _this4.value.quoteId)) {
                _context3.n = 4;
                break;
              }
              _context3.n = 3;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_36__["default"].getSupplementaryQuoteTotals(_this4.value.quoteId);
            case 3:
              _this4.supplementaryQuotes = _context3.v;
              _context3.n = 5;
              break;
            case 4:
              _this4.supplementaryQuotes = [];
            case 5:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getMainQuote: function getMainQuote() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (_this5.isSuppQuote) {
                _context4.n = 1;
                break;
              }
              return _context4.a(2);
            case 1:
              _context4.n = 2;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_36__["default"].getMainQuoteEntity("".concat(_this5.value.prefix).concat(_this5.value.quoteNo).concat(_this5.value.suffix));
            case 2:
              _this5.mainQuote = _context4.v;
            case 3:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    reset: function reset() {
      this.innerSelectedSubSections = [];
      this.innerSelectedArea = null;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.number.to-fixed.js */ "./node_modules/core-js/modules/es.number.to-fixed.js");
/* harmony import */ var core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_to_fixed_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "quote-builder-sidebar box"
  }, [_c("nav", {
    staticClass: "main-nav"
  }, [_c("ul", [_c("li", {
    class: {
      active: _vm.selectedMenu === _vm.MENU_MODES.MANUAL,
      disabled: !_vm.isQuoteEditable,
      "tooltip is-tooltip-right": _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired"
    },
    on: {
      click: function click($event) {
        _vm.isQuoteEditable && _vm.$emit("update:selectedMenu", _vm.MENU_MODES.MANUAL);
      }
    }
  }, [_c("span", {
    staticClass: "mso mso-24px mr-2"
  }, [_vm._v("docs")]), _c("span", [_vm._v("Manual Quote")])]), _c("li", {
    class: {
      active: _vm.selectedMenu === _vm.MENU_MODES.TEMPLATES,
      disabled: !_vm.isQuoteEditable,
      "tooltip is-tooltip-right": _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired"
    },
    on: {
      click: function click($event) {
        _vm.isQuoteEditable && _vm.$emit("update:selectedMenu", _vm.MENU_MODES.TEMPLATES);
      }
    }
  }, [_c("span", {
    staticClass: "mso mso-24px mr-2"
  }, [_vm._v("file_copy")]), _c("span", [_vm._v("Templates")])]), _c("li", {
    class: {
      active: _vm.selectedMenu === _vm.MENU_MODES.VEHICLE,
      disabled: !_vm.isQuoteEditable,
      "tooltip is-tooltip-right": _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired"
    },
    on: {
      click: function click($event) {
        _vm.isQuoteEditable && _vm.$emit("update:selectedMenu", _vm.MENU_MODES.VEHICLE);
      }
    }
  }, [_c("span", {
    staticClass: "mso mso-24px mr-2"
  }, [_vm._v("no_crash")]), _c("span", [_vm._v("Vehicle Sections")])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.selectedMenu === _vm.MENU_MODES.VEHICLE,
      expression: "selectedMenu === MENU_MODES.VEHICLE"
    }],
    staticClass: "vehicle-sections"
  }, [_c("hr", {
    staticClass: "divider my-2"
  }), _vm.isShowVehicleSectionContent ? _c("div", {
    staticClass: "is-flex is-justify-content-space-between is-align-items-center mb-4"
  }, [_c("span", {
    staticClass: "has-text-weight-bold"
  }, [_vm._v("Sections")]), _c("div", {
    staticClass: "is-flex",
    staticStyle: {
      gap: "0.25rem"
    }
  }, [_c("button", {
    staticClass: "button is-small",
    staticStyle: {
      padding: "0.25em 0.25em",
      "min-width": "0"
    },
    on: {
      click: function click($event) {
        return _vm.$emit("modify");
      }
    }
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("car_gear")]), _c("span", [_vm._v("Butterfly")])]), _c("button", {
    staticClass: "button is-small",
    class: {
      tooltip: _vm.innerSelectedSubSections.length
    },
    staticStyle: {
      padding: "0.25em",
      "min-width": "0"
    },
    attrs: {
      "data-tooltip": "Reset",
      disabled: !_vm.innerSelectedSubSections.length
    },
    on: {
      click: function click($event) {
        return _vm.$emit("reset");
      }
    }
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v("refresh")])])])]) : _vm._e(), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isShowVehicleSectionContent,
      expression: "isShowVehicleSectionContent"
    }],
    staticClass: "vehicle-group-section"
  }, [_c("div", _vm._l(_vm.computedAreasWithParts, function (area) {
    return _c("div", {
      key: area.name,
      staticClass: "area-group"
    }, [_c("div", {
      class: ["area-header", {
        "is-area-selected": _vm.innerSelectedArea === area.name
      }]
    }, [_c("div", {
      staticClass: "area-content",
      on: {
        click: function click($event) {
          return _vm.filterByArea(area);
        }
      }
    }, [_c("div", {
      staticClass: "area-name"
    }, [_c("span", {
      staticClass: "area-name-text"
    }, [_vm._v(_vm._s(area.name))])]), _c("div", {
      staticClass: "area-info"
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.innerSelectedArea === area.name,
        expression: "innerSelectedArea === area.name"
      }],
      staticClass: "mso is-size-6 is-white"
    }, [_vm._v("keyboard_arrow_right")])])])]), _c("div", {
      staticClass: "parts-list"
    }, _vm._l(area.parts, function (part) {
      return _c("div", {
        key: part.partId,
        class: ["part-item", {
          "is-selected": part.isFilter
        }]
      }, [_c("div", {
        staticClass: "part-remove"
      }, [_c("span", {
        staticClass: "mso mso-16px remove-icon",
        attrs: {
          title: "Remove part"
        },
        on: {
          click: function click($event) {
            $event.stopPropagation();
            return _vm.removePartSelection(part);
          }
        }
      }, [_vm._v("close")])]), _c("div", {
        staticClass: "part-content",
        on: {
          click: function click($event) {
            return _vm.togglePartSelection(part, area);
          }
        }
      }, [_c("div", {
        staticClass: "part-name"
      }, [_vm._v(_vm._s(part.partName))]), _c("div", {
        staticClass: "part-info"
      }, [_c("span", {
        directives: [{
          name: "show",
          rawName: "v-show",
          value: part.isFilter,
          expression: "part.isFilter"
        }],
        staticClass: "mso is-size-6"
      }, [_vm._v("keyboard_arrow_right")])])])]);
    }), 0)]);
  }), 0)])]), _c("div", {
    staticClass: "job-value-section"
  }, [_c("hr", {
    staticClass: "divider"
  }), _c("div", {
    staticClass: "has-text-centered small-menu-text"
  }, [_vm._v("Total Job Value")]), _c("table", {
    staticClass: "table is-striped is-extra-narrow is-fullwidth small-menu-text"
  }, [_c("tbody", {
    staticClass: "no-border"
  }, _vm._l(_vm.itemTypes, function (itemType) {
    return _c("tr", {
      key: itemType.itemCategoryType
    }, [_c("td", [_vm._v(_vm._s(itemType.displayName))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(_vm.mainSuppQuotePercentages[itemType.itemCategoryType].toFixed(0))), _c("span", {
      staticStyle: {
        "font-size": "0.7em",
        "vertical-align": "super"
      }
    }, [_vm._v("%")])]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.mainSuppQuoteTotals[itemType.itemCategoryType], _vm.$userInfo.locale)))])]);
  }), 0), _c("tfoot", {
    staticClass: "no-border"
  }, [_c("tr", [_vm._m(0), _c("td", {
    staticClass: "has-text-right has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalExGst, _vm.$userInfo.locale)))])]), _c("tr", [_vm._m(1), _c("td", {
    staticClass: "has-text-right has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalIncGst, _vm.$userInfo.locale)))])])])])])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("td", {
    attrs: {
      colspan: "2"
    }
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("td", {
    attrs: {
      colspan: "2"
    }
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.quote-builder-sidebar[data-v-5392bf46] {\n  width: 250px;\n  min-height: 78vh;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.main-nav[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n.main-nav ul[data-v-5392bf46] {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n.main-nav li[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.5rem 1rem;\n  border-radius: 6px;\n  cursor: pointer;\n  margin-bottom: 0.25rem;\n  font-weight: 500;\n  /* color: #222; */\n}\n.main-nav li.active[data-v-5392bf46], .main-nav li[data-v-5392bf46]:hover {\n  background: #1976d2;\n  color: #fff;\n}\n.main-nav li.disabled[data-v-5392bf46] {\n  opacity: 0.5;\n  cursor: not-allowed;\n  pointer-events: none;\n}\n.main-nav li.disabled[data-v-5392bf46]:hover {\n  background: transparent;\n  color: inherit;\n}\n.main-nav li.disabled.tooltip[data-v-5392bf46] {\n  pointer-events: auto;\n  opacity: 1;\n}\n.main-nav li.disabled.tooltip > span[data-v-5392bf46] {\n  opacity: 0.5;\n}\n.main-nav li.disabled.tooltip.active[data-v-5392bf46] {\n  background: rgba(25, 118, 210, 0.5);\n}\n.main-nav .icon[data-v-5392bf46] {\n  margin-right: 0.75rem;\n  font-size: 1.2em;\n}\n.vehicle-group[data-v-5392bf46] {\n  margin-bottom: 1.25rem;\n}\n.group-title[data-v-5392bf46] {\n  font-weight: 600;\n  color: #888;\n  font-size: 0.95em;\n  margin-bottom: 0.25rem;\n}\n.vehicle-group ul[data-v-5392bf46] {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n.vehicle-group li[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.25rem 0.5rem;\n  border-radius: 4px;\n  font-size: 0.9em;\n  background: #f7fafd;\n  margin-bottom: 0.15rem;\n  cursor: pointer;\n}\n.vehicle-group li[data-v-5392bf46]:hover {\n  background: #e8f4fd;\n}\n.vehicle-group li.is-selected[data-v-5392bf46] {\n  background: #e3f0ff;\n  border-left: 3px solid #1976d2;\n}\n.vehicle-group .remove-x[data-v-5392bf46] {\n  color: #888;\n  margin-right: 0.5em;\n  cursor: pointer;\n  font-weight: bold;\n  width: 16px;\n  text-align: center;\n}\n.vehicle-group .add-plus[data-v-5392bf46] {\n  color: #4caf50;\n  margin-right: 0.5em;\n  cursor: pointer;\n  font-weight: bold;\n  width: 16px;\n  text-align: center;\n}\n.vehicle-group .arrow[data-v-5392bf46] {\n  margin-left: auto;\n  color: #bbb;\n  font-size: 1.1em;\n}\n.vehicle-group-section[data-v-5392bf46] {\n  max-height: calc(100vh - 600px);\n  overflow-y: auto;\n  overflow-x: hidden;\n  padding-right: 4px;\n}\n.area-content[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  width: 100%;\n}\n.area-name[data-v-5392bf46] {\n  font-weight: 600;\n  font-size: 0.95em;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.area-name-text[data-v-5392bf46] {\n  cursor: pointer;\n  padding: 0.25rem 0.5rem;\n  border-radius: 4px;\n}\n.no-border tr[data-v-5392bf46],\n.no-border td[data-v-5392bf46],\n.no-border th[data-v-5392bf46] {\n  border: none;\n}\n.is-extra-narrow td[data-v-5392bf46],\n.is-extra-narrow th[data-v-5392bf46] {\n  padding: 0.1em 0.5em;\n}\n.subtext[data-v-5392bf46] {\n  font-size: 10px;\n}\n.small-menu-text[data-v-5392bf46] {\n  font-size: 14px;\n}\n.divider[data-v-5392bf46] {\n  background-color: hsl(0, 0%, 90%) !important;\n}\n.job-value-section[data-v-5392bf46] {\n  margin-top: auto;\n}\n\n/* Area group styles for part mode */\n.area-group[data-v-5392bf46] {\n  margin-bottom: 0.75rem;\n}\n.area-header[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  padding: 0.25rem 0.5rem;\n  border-radius: 6px;\n  cursor: pointer;\n  font-weight: 600;\n  background: var(--background-color);\n  border: 1px solid var(--border-color);\n}\n.area-header[data-v-5392bf46]:hover {\n  background: var(--background-hover-color);\n  border: 1px solid var(--border-hover-color);\n}\n.area-header.is-area-selected[data-v-5392bf46] {\n  background: #1976d2;\n  border-color: #1976d2;\n}\n.area-header.is-area-selected .area-name-text[data-v-5392bf46] {\n  color: #fff;\n  font-weight: 700;\n}\n/* Parts list styles */\n.parts-list[data-v-5392bf46] {\n  margin-top: 0.25rem;\n  margin-left: 0.25rem;\n  border-left: 2px solid #e3eefa;\n  padding-left: 0.5rem;\n}\n.part-item[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 0.375rem;\n  border-radius: 4px;\n  margin-bottom: 0.25rem;\n  font-size: 0.85em;\n  /* color: #555; */\n  /* background: #fafbfc; */\n  background: var(--background-color);\n  border: 1px solid var(--border-color);\n  /* border: 1px solid #e8eef5; */\n}\n.part-item[data-v-5392bf46]:hover {\n  /* color: #1976d2; */\n  /* background: #f0f5fa; */\n  /* border-color: #1976d2; */\n  background: var(--background-hover-color);\n  border: 1px solid var(--border-hover-color);\n}\n.part-item.is-selected[data-v-5392bf46] {\n  background: #1976d2;\n  color: #fff;\n  border-color: #1976d2;\n  font-weight: 500;\n}\n.part-content[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  cursor: pointer;\n}\n.part-name[data-v-5392bf46] {\n  font-weight: 500;\n}\n.part-info[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.area-info[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #fff;\n}\n.part-remove[data-v-5392bf46] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-right: 0.5rem;\n}\n.remove-icon[data-v-5392bf46] {\n  font-size: 1rem;\n  color: #999;\n  cursor: pointer;\n  padding: 0.25rem;\n  border-radius: 50%;\n  -webkit-transition: all 0.2s ease;\n  transition: all 0.2s ease;\n}\n.remove-icon[data-v-5392bf46]:hover {\n  color: #e74c3c;\n  background: rgba(231, 76, 60, 0.1);\n}\n.part-item.is-selected .remove-icon[data-v-5392bf46] {\n  color: rgba(255, 255, 255, 0.8);\n}\n.part-item.is-selected .remove-icon[data-v-5392bf46]:hover {\n  color: #fff;\n  background: rgba(255, 255, 255, 0.2);\n}\n\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("e0a6bfb0", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/BulmaAutocomplete/index.js":
/*!***************************************************!*\
  !*** ./src/components/BulmaAutocomplete/index.js ***!
  \***************************************************/
/*! exports provided: BulmaAutocomplete */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BulmaAutocomplete", function() { return BulmaAutocomplete; });
var BulmaAutocomplete = function BulmaAutocomplete(r) {
  return Promise.all(/*! require.ensure | shared */[__webpack_require__.e(2), __webpack_require__.e("quote-imagesbreakout-chunk~shared"), __webpack_require__.e("quote-partscontrol-chunk~shared"), __webpack_require__.e("shared")]).then((function () {
    return r(__webpack_require__(/*! ./BulmaAutocomplete.vue */ "./src/components/BulmaAutocomplete/BulmaAutocomplete.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/components/QuoteBuilderSidebar.vue":
/*!************************************************!*\
  !*** ./src/components/QuoteBuilderSidebar.vue ***!
  \************************************************/
/*! exports provided: MENU_MODES, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true */ "./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true");
/* harmony import */ var _QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteBuilderSidebar.vue?vue&type=script&lang=js */ "./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MENU_MODES", function() { return _QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["MENU_MODES"]; });

/* harmony import */ var _QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css */ "./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "5392bf46",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/QuoteBuilderSidebar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js":
/*!************************************************************************!*\
  !*** ./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js ***!
  \************************************************************************/
/*! exports provided: default, MENU_MODES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBuilderSidebar.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=script&lang=js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MENU_MODES", function() { return _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["MENU_MODES"]; });

 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css":
/*!********************************************************************************************************!*\
  !*** ./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=style&index=0&id=5392bf46&scoped=true&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_style_index_0_id_5392bf46_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true":
/*!******************************************************************************************!*\
  !*** ./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/QuoteBuilderSidebar.vue?vue&type=template&id=5392bf46&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBuilderSidebar_vue_vue_type_template_id_5392bf46_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteFiltersMixins.js":
/*!***********************************************!*\
  !*** ./src/views/quote/QuoteFiltersMixins.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["default"] = ({
  filters: {
    formatJobStage: function formatJobStage(value) {
      if (value.toLowerCase() === 'none') {
        return '-- Job Stage --';
      } else {
        return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
          return str.toUpperCase();
        });
      }
    },
    formatPartCondition: function formatPartCondition(value) {
      return value.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b([A-Z]+)([A-Z])([a-z])/, '$1 $2$3').replace(/^./, function (str) {
        return str.toUpperCase();
      });
    }
  }
});

/***/ })

}]);
//# sourceMappingURL=quote-builder-chunk~quote-detail-chunk.js.map