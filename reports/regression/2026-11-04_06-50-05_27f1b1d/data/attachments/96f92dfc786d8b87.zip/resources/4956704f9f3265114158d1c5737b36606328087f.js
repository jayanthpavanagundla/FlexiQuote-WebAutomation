(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-header-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_QuoteHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/QuoteHeader */ "./src/views/quote/components/QuoteHeader/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_6__);







/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteHeader',
  inject: ['$vv'],
  components: {
    QuoteVehicle: _components_QuoteHeader__WEBPACK_IMPORTED_MODULE_3__["QuoteVehicle"],
    QuoteCustomer: _components_QuoteHeader__WEBPACK_IMPORTED_MODULE_3__["QuoteCustomer"],
    QuoteInsurer: _components_QuoteHeader__WEBPACK_IMPORTED_MODULE_3__["QuoteInsurer"],
    QuoteBooking: _components_QuoteHeader__WEBPACK_IMPORTED_MODULE_3__["QuoteBooking"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_4__["default"]],
  props: {
    value: null,
    vehicle: null,
    customer: null,
    insurer: null,
    quoteCycleTime: null,
    nextLineNumber: null,
    isNewCustomerPrompt: false,
    headerSavingPanels: {
      type: Object,
      default: function _default() {
        return {
          vehicle: false,
          customer: false,
          insurer: false,
          booking: false
        };
      }
    }
  },
  data: function data() {
    return {
      innerValue: null,
      innerVehicle: null,
      innerCustomer: null,
      innerInsurer: null,
      innerQuoteCycleTime: null,
      isPauseWatch: false,
      prevInnerValue: null,
      prevInnerVehicle: null,
      prevInnerCustomer: null,
      prevInnerInsurer: null,
      prevInnerQuoteCycleTime: null
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        var _this = this;
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_6___default.a.diff(this.prevInnerValue, newVal);
        if (!this.isPauseWatch && diff) {
          this.prevInnerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
          this.$emit('input', newVal);
          this.$nextTick(function () {
            _this.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].EntitySaved, "-").concat(_this.$options.name));
          });
        }
      },
      deep: true
    },
    innerVehicle: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_6___default.a.diff(this.prevInnerVehicle, newVal);
        if (!this.isPauseWatch && diff) {
          this.prevInnerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
          this.$emit('update:vehicle', newVal);
        }
      },
      deep: true
    },
    innerCustomer: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_6___default.a.diff(this.prevInnerCustomer, newVal);
        if (!this.isPauseWatch && diff) {
          this.prevInnerCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
          this.$emit('update:customer', newVal);
        }
      },
      deep: true
    },
    innerInsurer: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_6___default.a.diff(this.prevInnerInsurer, newVal);
        if (!this.isPauseWatch && diff) {
          this.prevInnerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
          this.$emit('update:insurer', newVal);
        }
      },
      deep: true
    },
    innerQuoteCycleTime: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_6___default.a.diff(this.prevInnerQuoteCycleTime, newVal);
        if (!this.isPauseWatch && diff) {
          this.prevInnerQuoteCycleTime = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
          this.$emit('update:quoteCycleTime', newVal);
        }
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        if (!this.isPauseWatch) {
          this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(newVal);
        }
      },
      deep: true
    }
  },
  created: function created() {
    this.isPauseWatch = true;
    this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value);
    this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.vehicle);
    this.innerCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.customer);
    this.innerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.insurer);
    this.innerQuoteCycleTime = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value.quoteCycleTime);
    this.isPauseWatch = false;
  },
  mounted: function mounted() {
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].EntitySaved, this.updateInnerObjects);
    // this.$vv.quoteHeaderGroup.$touch()
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].EntitySaved);
  },
  methods: {
    updateInnerObjects: function updateInnerObjects() {
      var _this2 = this;
      this.isPauseWatch = true;
      this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value);
      this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.vehicle);
      this.innerCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.customer);
      this.innerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.insurer);
      this.innerQuoteCycleTime = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_2___default()(this.value.quoteCycleTime);
      this.isPauseWatch = false;
      this.$nextTick(function () {
        _this2.$eventHub.$emit("".concat(_enums__WEBPACK_IMPORTED_MODULE_5__["EventHubTypes"].EntitySaved, "-").concat(_this2.$options.name));
      });
    },
    selectVehicle: function selectVehicle(vehicleId, customerId) {
      this.$emit('select-vehicle', vehicleId, customerId);
    },
    selectInsurer: function selectInsurer(id) {
      this.$emit('select-insurer', id);
    },
    selectCustomer: function selectCustomer(id) {
      this.$emit('select-customer', id);
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
/* harmony import */ var core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.set.difference.v2.js */ "./node_modules/core-js/modules/es.set.difference.v2.js");
/* harmony import */ var core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.set.intersection.v2.js */ "./node_modules/core-js/modules/es.set.intersection.v2.js");
/* harmony import */ var core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.set.is-disjoint-from.v2.js */ "./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js");
/* harmony import */ var core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.set.is-subset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-subset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.set.is-superset-of.v2.js */ "./node_modules/core-js/modules/es.set.is-superset-of.v2.js");
/* harmony import */ var core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.set.symmetric-difference.v2.js */ "./node_modules/core-js/modules/es.set.symmetric-difference.v2.js");
/* harmony import */ var core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.set.union.v2.js */ "./node_modules/core-js/modules/es.set.union.v2.js");
/* harmony import */ var core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_set_union_v2_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_27__);




























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AssessorAutocomplete',
  components: {
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_25__["BulmaAutocomplete"]
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    quoteId: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: 'Assessor'
    }
  },
  data: function data() {
    return {
      items: [],
      innerValue: ''
    };
  },
  watch: {
    innerValue: function innerValue(newVal, oldVal) {
      this.$emit('input', newVal);
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = newVal || '';
      },
      immediate: true
    }
  },
  methods: {
    getAssessorList: lodash_debounce__WEBPACK_IMPORTED_MODULE_27___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(query) {
        var search, _yield$Promise$all, _yield$Promise$all2, contacts, assessors, contactItems, assessorItems;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              search = query ? query.replace(/[^a-zA-Z\s]/g, '') : '';
              if (search) {
                _context.n = 1;
                break;
              }
              this.items = [];
              return _context.a(2);
            case 1:
              _context.n = 2;
              return Promise.all([_services__WEBPACK_IMPORTED_MODULE_26__["CustomerService"].getQuoteInsurerCustomerContacts(this.quoteId, search).catch(function () {
                return [];
              }), _services__WEBPACK_IMPORTED_MODULE_26__["QuoteService"].getQuoteAssessorList(search).catch(function () {
                return [];
              })]);
            case 2:
              _yield$Promise$all = _context.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_yield$Promise$all, 2);
              contacts = _yield$Promise$all2[0];
              assessors = _yield$Promise$all2[1];
              contactItems = contacts.map(function (c) {
                return {
                  assessorName: c.fullName,
                  assessorPhoneNo: c.phoneNo,
                  source: c.groupName
                };
              });
              assessorItems = assessors.map(function (a) {
                return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, a), {}, {
                  source: 'Assessor'
                });
              });
              this.items = this.dedupe([].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(contactItems), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(assessorItems)));
            case 3:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 100),
    dedupe: function dedupe(items) {
      var _this = this;
      var seen = new Set();
      return items.filter(function (item) {
        var key = "".concat((item.assessorName || '').toLowerCase().trim(), "|").concat(_this.keepOnlyDigits(item.assessorPhoneNo || ''));
        if (seen.has(key)) {
          return false;
        }
        seen.add(key);
        return true;
      });
    },
    keepOnlyDigits: function keepOnlyDigits(str) {
      return str.replace(/\D/g, '');
    },
    select: function select(selectedItem) {
      if (selectedItem) {
        selectedItem.assessorPhoneNo = this.keepOnlyDigits(selectedItem.assessorPhoneNo || '');
      }
      this.$emit('select', selectedItem);
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _assets_json_neighbours_json__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/assets/json/neighbours.json */ "./src/assets/json/neighbours.json");
var _assets_json_neighbours_json__WEBPACK_IMPORTED_MODULE_12___namespace = /*#__PURE__*/__webpack_require__.t(/*! @/assets/json/neighbours.json */ "./src/assets/json/neighbours.json", 1);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");














/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CustomerAddressInput',
  components: {
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_11__["BulmaAutocomplete"]
  },
  mixins: [],
  props: {
    value: null,
    id: {
      type: String,
      default: ''
    },
    v: null,
    bounds: {
      type: Object,
      default: null
    }
  },
  data: function data() {
    return {
      address: null,
      googleApi: {
        mapUrl: 'https://maps.googleapis.com/maps/api/js',
        mapKey: "AIzaSyCK26bFvsJ1lo1dZ10WBFXA74yU-pc7CuI",
        mapLibraries: 'places',
        mapCallback: 'initMap',
        mapStatus: null,
        bounds: null
      },
      addresses: {
        data: [],
        loading: false
      },
      suburbs: {
        data: [],
        loading: false
      },
      isPauseWatch: false
    };
  },
  computed: {
    countryCodes: function countryCodes() {
      var _this = this;
      var neighbours = _assets_json_neighbours_json__WEBPACK_IMPORTED_MODULE_12__.find(function (n) {
        return n.countryCode === _this.$company.info.countryCode;
      }) || [];
      return [this.$company.info.countryCode].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(neighbours.neighbours));
    },
    addressTypes: function addressTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_13__["AddressTypes"];
    }
  },
  watch: {
    address: {
      handler: function handler(newVal, oldVal) {
        if (!this.isPauseWatch) {
          this.$emit('input', newVal);
        }
      },
      deep: true
    },
    value: {
      handler: function handler(newVal) {
        if (newVal != this.address) {
          // Only refresh if value has changed
          this.refreshAddress();
        }
      },
      deep: true
    }
  },
  created: function created() {
    this.address = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default()(this.value);
    var vm = this;
    window.initMap = function () {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
          var geolocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          var circle = new window.google.maps.Circle({
            center: geolocation,
            radius: position.coords.accuracy
          });
          vm.googleApi.bounds = circle.getBounds();
        });
      }
      vm.googleApi.mapStatus = 'AddressDetail';
    };
    if (!window.google) {
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = "".concat(this.googleApi.mapUrl, "?key=").concat(this.googleApi.mapKey, "&libraries=").concat(this.googleApi.mapLibraries, "&callback=").concat(this.googleApi.mapCallback);
      document.body.appendChild(script);
    } else {
      window.initMap();
    }
  },
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    searchAddress: lodash_debounce__WEBPACK_IMPORTED_MODULE_9___default()(function (address, key) {
      var _this2 = this;
      this.addresses.loading = true;
      if (key.length > 0) {
        var searchOptions = {
          input: key,
          types: ['geocode'],
          componentRestrictions: {
            country: this.countryCodes
          }
        };
        if (this.bounds) {
          searchOptions.bounds = this.googleApi.bounds;
        }
        var service = new window.google.maps.places.AutocompleteService();
        service.getPlacePredictions(searchOptions, function (predictions, status) {
          if (status !== window.google.maps.places.PlacesServiceStatus.OK) {
            // alert(status)
            return;
          }
          var addresses = [];
          predictions.forEach(function (prediction) {
            // console.log(prediction)
            addresses.push({
              id: prediction.place_id,
              street: "".concat(prediction.structured_formatting.main_text),
              secondary_text: prediction.structured_formatting.secondary_text
            });
          });
          _this2.addresses.data = addresses;
        });
      }
      this.addresses.loading = false;
    }, 500),
    pickAddress: function pickAddress(address, e) {
      if (!e) {
        return;
      }
      var service = new window.google.maps.Geocoder();
      service.geocode({
        placeId: e.id
      }, function (results, status) {
        if (status === 'OK') {
          var place = results[0];
          if (place.address_components !== undefined) {
            // reset address1, otherwise street only search will double up
            address.address1 = '';
            for (var i = 0; i < place.address_components.length; i++) {
              var addressType = place.address_components[i].types[0];
              switch (addressType) {
                case 'street_number':
                  address.address1 = place.address_components[i]['short_name'];
                  break;
                case 'route':
                  address.address1 += ' ' + place.address_components[i]['long_name'];
                  break;
                case 'locality':
                  address.suburbText = place.address_components[i]['long_name'];
                  break;
                case 'postal_code':
                  address.suburbPostcode = place.address_components[i]['short_name'];
                  break;
                case 'administrative_area_level_1':
                  address.stateText = place.address_components[i]['long_name'];
                  address.stateCode = place.address_components[i]['short_name'];
                  break;
                case 'country':
                  address.countryText = place.address_components[i]['long_name'];
                  address.countryCode = place.address_components[i]['short_name'];
                  break;
              }
            }
          }
        }
      });
    },
    refreshAddress: function refreshAddress() {
      this.isPauseWatch = true;
      this.address = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default()(this.value);
      this.isPauseWatch = false;
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _views_quote_storeMixin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/views/quote/storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PanelBlurMixin */ "./src/views/quote/components/QuoteHeader/PanelBlurMixin.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/views/quote/QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _LateReasonModal_vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../LateReasonModal.vue */ "./src/views/quote/components/LateReasonModal.vue");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! luxon */ "./node_modules/luxon/build/cjs-browser/luxon.js");
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_13__);














/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteBooking',
  inject: ['$vv'],
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_8__["FocusInserted"]
  },
  components: {
    LateReasonModal: _LateReasonModal_vue__WEBPACK_IMPORTED_MODULE_12__["default"]
  },
  mixins: [_views_quote_storeMixin__WEBPACK_IMPORTED_MODULE_6__["default"], _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_7__["default"]],
  props: {
    value: null,
    quote: null,
    insurer: null,
    isSaving: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: null,
      //QuoteCycleTime
      innerQuote: null,
      innerQuoteDate: null,
      innerInspectionBookingDate: null,
      innerJobStartDate: null,
      innerJobEndDate: null,
      oriJobStartDate: null,
      oriJobEndDate: null,
      innerSentForAuthorizationDate: null,
      innerAuthorityDate: null,
      innerRepairBookedDate: null,
      innerArrivedForRepairDate: null,
      innerVehicleDepartedDate: null,
      innerActualJobStart: null,
      innerActualJobEnd: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      jobStartDateTime: null,
      jobCompletionDateTime: null,
      modelConfig: {
        start: {
          timeAdjust: '08:00:00'
        },
        end: {
          timeAdjust: '08:00:00'
        }
      },
      isArrived: false,
      isDeparted: false,
      // inspectionStartDate: null

      prevInnerValue: null,
      prevInnerQuote: null,
      isRepairLateReasonActive: false,
      bookedInSortKey: null,
      selectedJobStage: null,
      sortKey: null
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    ormEstimateStartEndValidationText: function ormEstimateStartEndValidationText() {
      if (!this.$v.entity.jobStart.required || !this.$v.entity.jobEnd.required) {
        return 'Required by ORM';
      } else if (!this.$v.entity.jobStart.validJobStart || !this.$v.entity.jobEnd.validJobEnd) {
        return 'Invalid date range';
      }
    },
    isRepairBooked: function isRepairBooked() {
      return this.innerQuote.isRepairBooked;
    },
    isRepx: function isRepx() {
      return this.innerQuote.repx != null;
    },
    isRepairStartDateSynced: function isRepairStartDateSynced() {
      return this.quoteRepx ? this.quoteRepx.isRepairStartDateSynced : false;
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_11___default.a.diff(this.prevInnerValue, newVal);
        if (diff) {
          this.prevInnerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(newVal);
          this.$emit('input', newVal);
        }
      },
      deep: true
    },
    innerQuote: {
      handler: function handler(newVal, oldVal) {
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_11___default.a.diff(this.prevInnerQuote, newVal);
        if (diff) {
          this.prevInnerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(newVal);
          this.$emit('update:quote', newVal);
        }
      },
      deep: true
    },
    innerQuoteDate: function innerQuoteDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.quoteDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerQuote.quoteDate = null;
      }
    },
    innerInspectionBookingDate: function innerInspectionBookingDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.inspectionBookingDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.inspectionBookingDate = null;
      }
    },
    innerSentForAuthorizationDate: function innerSentForAuthorizationDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.sentForAuthorizationDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.sentForAuthorizationDate = null;
      }
    },
    innerAuthorityDate: function innerAuthorityDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.authorisedDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerQuote.authorisedDate = null;
      }
    },
    innerRepairBookedDate: function innerRepairBookedDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.repairBookedDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.repairBookedDate = null;
      }
    },
    innerArrivedForRepairDate: function innerArrivedForRepairDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.arrivedForRepairDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.arrivedForRepairDate = null;
      }
      this.isArrived = !!this.innerArrivedForRepairDate;
    },
    innerActualJobStart: function innerActualJobStart(newVal, oldVal) {
      if (newVal) {
        this.innerValue.actualJobStart = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.actualJobStart = null;
      }
    },
    innerActualJobEnd: function innerActualJobEnd(newVal, oldVal) {
      if (newVal) {
        this.innerValue.actualJobEnd = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.actualJobEnd = null;
      }
    },
    innerJobStartDate: function innerJobStartDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.jobStart = newVal.toISOString().split('.')[0] + 'Z';
        if (this.innerQuote.jobEnd && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn;
          this.innerQuote.jobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn;
        }
      } else {
        this.innerQuote.jobStart = null;
      }
    },
    innerJobEndDate: function innerJobEndDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.jobEnd = newVal.toISOString().split('.')[0] + 'Z';
        //to prompt late reason
        this.isRepairLateReasonActive = this.compare1DateTo2(newVal, this.oriJobEndDate);
        if (this.innerQuote.jobStart && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn;
          this.innerQuote.jobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn;
        }
      } else {
        this.innerQuote.jobEnd = null;
      }
    },
    innerVehicleDepartedDate: function innerVehicleDepartedDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.vehicleDepartedDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.vehicleDepartedDate = null;
      }
      this.isDeparted = !!this.innerVehicleDepartedDate;
    },
    'innerQuote.isRepairBooked': function innerQuoteIsRepairBooked(newVal, oldVal) {
      if (newVal === false) {
        this.clearRepairBookedDate();
      }
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(_this.value);
            _this.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(_this.quote);
            _this.selectedJobStage = _this.innerQuote.jobStage;
            _this.sortKey = _this.getJobStageSortKey(_this.innerQuote.jobStage);
            _this.bookedInSortKey = _this.getJobStageSortKey(_enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn);
            _this.innerInspectionBookingDate = _this.innerValue.inspectionBookingDate ? new Date("".concat(_this.innerValue.inspectionBookingDate)) : null;
            _this.innerSentForAuthorizationDate = _this.innerValue.sentForAuthorizationDate ? new Date("".concat(_this.innerValue.sentForAuthorizationDate)) : null;
            _this.innerRepairBookedDate = _this.innerValue.repairBookedDate ? new Date("".concat(_this.innerValue.repairBookedDate)) : null;
            _this.innerArrivedForRepairDate = _this.innerValue.arrivedForRepairDate ? new Date("".concat(_this.innerValue.arrivedForRepairDate)) : null;
            _this.innerVehicleDepartedDate = _this.innerValue.vehicleDepartedDate ? new Date("".concat(_this.innerValue.vehicleDepartedDate)) : null;
            _this.innerActualJobStart = _this.innerValue.actualJobStart ? new Date("".concat(_this.innerValue.actualJobStart)) : null;
            _this.innerActualJobEnd = _this.innerValue.actualJobEnd ? new Date("".concat(_this.innerValue.actualJobEnd)) : null;
            _this.innerQuoteDate = _this.innerToJsDate(_this.innerQuote.quoteDate);
            _this.innerAuthorityDate = _this.innerToJsDate(_this.innerQuote.authorisedDate);
            if (_this.innerQuote.jobStart) {
              _this.innerJobStartDate = _this.innerToJsDate(_this.innerQuote.jobStart);
              _this.oriJobStartDate = _this.innerJobStartDate;
            }
            if (_this.innerQuote.jobEnd) {
              _this.innerJobEndDate = _this.innerToJsDate(_this.innerQuote.jobEnd);
              _this.oriJobEndDate = _this.innerJobEndDate;
            }
            _context.n = 1;
            return _this.loadQuoteRepxIfExist();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    this.$eventHub.$on("".concat(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name), this.updateInnerValue);
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off("".concat(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name));
  },
  methods: {
    innerToJsDate: function innerToJsDate(date) {
      if (this.$filters.isIsoDate(date)) {
        return this.$filters.fromISOToJsDate(date, this.$userInfo.locale);
      } else if (!isNaN(Date.parse(date))) {
        return new Date(date);
      } else {
        return null;
      }
    },
    loadQuoteRepxIfExist: function loadQuoteRepxIfExist() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var quoteRepx;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _views_quote_QuoteService__WEBPACK_IMPORTED_MODULE_10__["default"].getQuoteRepx(_this2.innerQuote.quoteId);
            case 1:
              quoteRepx = _context2.v;
              if (quoteRepx) {
                _this2.quoteRepx = quoteRepx;
              }
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    isISODate: function isISODate(input) {
      var dt = luxon__WEBPACK_IMPORTED_MODULE_13__["DateTime"].fromISO(input, {
        setZone: true
      });
      return dt.isValid;
    },
    compare1DateTo2: function compare1DateTo2(dateStr1, dateStr2) {
      if (dateStr1 && dateStr2) {
        var date1 = new Date(dateStr1);
        var date2 = new Date(dateStr2);
        if (date1 > date2) {
          return true;
        }
      }
      return false;
    },
    getJobStageSortKey: function getJobStageSortKey(stageId) {
      var index = this.jobStages.findIndex(function (i) {
        return i.stage === stageId;
      });
      var sortKey = this.jobStages[index].sortKey;
      return sortKey;
    },
    resetActualJobStartAndEnd: function resetActualJobStartAndEnd() {
      if (this.innerValue.actualJobStart !== null) {
        this.innerValue.actualJobStart = null;
      }
      if (this.innerValue.actualJobEnd !== null) {
        this.innerValue.actualJobEnd = null;
      }
      this.innerActualJobStart = null;
      this.innerActualJobEnd = null;
    },
    resetJobStartEnd: function resetJobStartEnd() {
      if (!this.isRepx || !this.isRepairStartDateSynced) {
        if (this.innerJobStartDate !== null) {
          this.innerJobStartDate = null;
        }
      }
      if (this.innerJobEndDate !== null) {
        this.innerJobEndDate = null;
      }
      if (this.selectedJobStage == _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].BookedIn && this.insurer.autoBookedInForDueInOut) {
        this.selectedJobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].FollowUpRequired;
        this.innerQuote.jobStage = _enums__WEBPACK_IMPORTED_MODULE_9__["JobStageTypes"].FollowUpRequired;
      }
      // Reset validation objects
      this.$v.entity.jobStart.$reset();
      this.$v.entity.jobEnd.$reset();
    },
    isArrivedOnChange: function isArrivedOnChange(event) {
      this.isArrived = !!event.target.checked;
      if (!this.isArrived) {
        this.clearArrivedForRepairDate();
      } else {
        this.innerArrivedForRepairDate = new Date();
      }
    },
    isDepartedOnChange: function isDepartedOnChange(event) {
      this.isDeparted = !!event.target.checked;
      if (!this.isDeparted) {
        this.clearVehicleDepartedDate();
      } else {
        this.innerVehicleDepartedDate = new Date();
      }
    },
    clearArrivedForRepairDate: function clearArrivedForRepairDate() {
      if (this.innerArrivedForRepairDate !== null) {
        this.innerArrivedForRepairDate = null;
        this.isArrived = false;
      }
    },
    clearVehicleDepartedDate: function clearVehicleDepartedDate() {
      if (this.innerVehicleDepartedDate !== null) {
        this.innerVehicleDepartedDate = null;
        this.isDeparted = false;
      }
    },
    clearRepairBookedDate: function clearRepairBookedDate() {
      if (this.innerRepairBookedDate !== null) {
        this.innerRepairBookedDate = null;
      }
    },
    handleRepairLateReasonClose: function handleRepairLateReasonClose() {
      this.isRepairLateReasonActive = false;
    },
    updateInnerValue: function updateInnerValue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _this3.$nextTick();
            case 1:
              _this3.innerValue = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(_this3.value);
              _this3.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_5___default()(_this3.quote);
              _this3.innerInspectionBookingDate = _this3.innerValue.inspectionBookingDate ? new Date("".concat(_this3.innerValue.inspectionBookingDate)) : null;
              _this3.innerSentForAuthorizationDate = _this3.innerValue.sentForAuthorizationDate ? new Date("".concat(_this3.innerValue.sentForAuthorizationDate)) : null;
              _this3.innerRepairBookedDate = _this3.innerValue.repairBookedDate ? new Date("".concat(_this3.innerValue.repairBookedDate)) : null;
              _this3.innerArrivedForRepairDate = _this3.innerValue.arrivedForRepairDate ? new Date("".concat(_this3.innerValue.arrivedForRepairDate)) : null;
              _this3.innerVehicleDepartedDate = _this3.innerValue.vehicleDepartedDate ? new Date("".concat(_this3.innerValue.vehicleDepartedDate)) : null;
              _this3.innerActualJobStart = _this3.innerValue.actualJobStart ? new Date("".concat(_this3.innerValue.actualJobStart)) : null;
              _this3.innerActualJobEnd = _this3.innerValue.actualJobEnd ? new Date("".concat(_this3.innerValue.actualJobEnd)) : null;
              _this3.innerQuoteDate = _this3.innerToJsDate(_this3.innerQuote.quoteDate);
              _this3.innerAuthorityDate = _this3.innerToJsDate(_this3.innerQuote.authorisedDate);
              _this3.innerJobStartDate = _this3.innerQuote.jobStart ? _this3.innerToJsDate(_this3.innerQuote.jobStart) : null;
              _this3.innerJobEndDate = _this3.innerQuote.jobEnd ? _this3.innerToJsDate(_this3.innerQuote.jobEnd) : null;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../QuoteOrmValidation */ "./src/views/quote/QuoteOrmValidation.js");
/* harmony import */ var _CustomerAddressInput_vue__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./CustomerAddressInput.vue */ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _views_contact_ContactService__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/views/contact/ContactService */ "./src/views/contact/ContactService.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./PanelBlurMixin */ "./src/views/quote/components/QuoteHeader/PanelBlurMixin.js");





























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteCustomer',
  inject: ['$vv'],
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_22__["FocusInserted"]
  },
  components: {
    CustomerAddressInput: _CustomerAddressInput_vue__WEBPACK_IMPORTED_MODULE_21__["default"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_24__["BulmaAutocomplete"]
  },
  mixins: [_PanelBlurMixin__WEBPACK_IMPORTED_MODULE_28__["default"]],
  props: {
    value: null,
    quote: null,
    isNewCustomerPrompt: false,
    isSaving: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerCustomer: null,
      innerQuote: null,
      defaultAddress: null,
      phones: [],
      phoneNoTokens: {
        P: {
          pattern: /[0-9, ()\-+]/
        }
      },
      phoneNoMask: Array(31).join('P'),
      // length of phoneNo field in database
      filteredCustomers: null,
      isSearchingCustomer: false,
      filter: {
        name: '',
        pageIndex: 1,
        pageSize: 50
      },
      maxEmails: 2,
      maxPhones: 3,
      prevInnerQuote: null,
      isWatchPaused: false
    };
  },
  computed: {
    innerCustomerAltContact: function innerCustomerAltContact() {
      return this.innerCustomer.contacts.find(function (c) {
        return c.isDefault && c.isDeleted === false;
      });
    },
    ormMessages: function ormMessages() {
      return _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_20__["ormValidationMessages"];
    },
    $v: function $v() {
      return this.$vv || this.$v;
    },
    emailTypes: function emailTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_19__["EmailTypes"];
    },
    phoneTypes: function phoneTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_19__["PhoneTypes"];
    },
    activePhones: function activePhones() {
      if (typeof this.innerCustomer.phones !== 'undefined') {
        return this.innerCustomer.phones.filter(function (x) {
          return !x.isDeleted;
        }).slice(0, this.maxPhones);
      }
      return [];
    },
    activeEmails: function activeEmails() {
      if (typeof this.innerCustomer.emails !== 'undefined') {
        return this.innerCustomer.emails.filter(function (x) {
          return !x.isDeleted;
        }).slice(0, this.maxEmails);
      }
      return [];
    },
    tempGemCan: function tempGemCan() {
      return this.$userInfo.isCustomerAdministrator && this.$company.info.companyId === 'a5ffbdc0-41d2-4e7f-8ecf-e51beac57e6b';
    },
    assessmentHistoryToggleDisable: function assessmentHistoryToggleDisable() {
      if (this.innerQuote.quoteAssessments && this.innerQuote.quoteAssessments.length > 0) {
        return true;
      }
      if (this.innerQuote.invoices && this.innerQuote.invoices.length > 0) {
        return true;
      }
      if (this.innerQuote.orm && this.innerQuote.orm.messageNo != '0') {
        return true;
      }
      if (this.innerQuote.subQuoteNos.length > 1) {
        return true;
      }
      return false;
    }
  },
  watch: {
    innerCustomer: {
      handler: function handler(newVal, oldVal) {
        if (this.innerCustomer) {
          this.innerCustomer.fullname = this.innerCustomer.isPerson ? "".concat(this.innerCustomer.lastname, ", ").concat(this.innerCustomer.firstname) : this.innerCustomer.companyName;
        }
        this.$emit('input', newVal);
      },
      deep: true
    },
    innerQuote: {
      handler: function handler(newVal, oldVal) {
        if (this.isWatchPaused) return;
        var diff = deep_diff__WEBPACK_IMPORTED_MODULE_27___default.a.diff(this.prevInnerQuote, newVal);
        if (diff) {
          this.prevInnerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default()(newVal);
          this.$emit('update:quote', newVal);
        }
      },
      deep: true
    },
    defaultAddress: {
      handler: function handler(newVal, oldVal) {
        if (newVal.isNew && this.innerCustomer.addresses.length === 0 && (newVal.address1 || newVal.suburbText || newVal.suburbPostcode || newVal.countryCode || newVal.countryCode)) {
          this.innerCustomer.addresses.splice(this.innerCustomer.addresses.length, 1, newVal);
        } else if (!newVal.isNew && this.innerCustomer.addresses.length > 0) {
          var defaultAddressIndex = this.innerCustomer.addresses.findIndex(function (a) {
            return a.isDefault;
          });
          this.innerCustomer.addresses.splice(defaultAddressIndex, 1, newVal);
        }
      },
      deep: true
    }
  },
  created: function created() {
    this.innerCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default()(this.value);
    this.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default()(this.quote);
    if (this.innerQuote && this.innerQuote.isNew) {
      this.$vv.customer.$reset();
    }
    this.getDefaultAddress();
    this.getCustomerDropdownProto();
    // assign alternative contact if there is one
    // this.innerCustomerAltContact = this.innerCustomer.contacts.find((c) => c.isDefault && c.isDeleted === false)
  },
  mounted: function mounted() {
    var _this = this;
    console.log('QuoteCustomer - mounted');
    this.$eventHub.$on("".concat(_enums__WEBPACK_IMPORTED_MODULE_19__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name), this.updateInnerCustomer);
    this.$nextTick(function () {
      if (_this.innerQuote && !_this.innerQuote.isNew && _this.innerQuote.orm && _this.$vv && _this.$vv.customer) {
        if (_this.$vv.customer.companyName) _this.$vv.customer.companyName.$touch();
        if (_this.$vv.customer.firstname) _this.$vv.customer.firstname.$touch();
        if (_this.$vv.customer.lastname) _this.$vv.customer.lastname.$touch();
      }
    });
  },
  beforeDestroy: function beforeDestroy() {
    console.log('QuoteCustomer - beforeDestroy');
    this.$eventHub.$off("".concat(_enums__WEBPACK_IMPORTED_MODULE_19__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name));
  },
  methods: {
    addAltContact: function addAltContact() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var assetId, response, data;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              assetId = _this2.innerCustomer.id;
              _context.n = 1;
              return _views_contact_ContactService__WEBPACK_IMPORTED_MODULE_26__["default"].getNewAssetContact('1', assetId);
            case 1:
              response = _context.v;
              data = response.data;
              data.isDefault = true;
              data.contact.phones.push({
                id: null,
                isDefault: true,
                isDeleted: false,
                isDirty: false,
                isNew: true,
                mergeOnConflict: false,
                no: '',
                overwriteOnConflict: false,
                type: '0'
              });
              _this2.innerCustomer.contacts.push(data);
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    removeAltContact: function removeAltContact() {
      var _this3 = this;
      if (this.innerCustomerAltContact) {
        if (this.innerCustomerAltContact.isNew) {
          // If it was just added, remove it completely from the array
          var index = this.innerCustomer.contacts.findIndex(function (c) {
            return c === _this3.innerCustomerAltContact;
          });
          if (index !== -1) {
            this.innerCustomer.contacts.splice(index, 1);
          }
        } else {
          // If it's an existing contact, mark it as deleted
          this.innerCustomerAltContact.isDeleted = true;
        }
      }
    },
    addEmail: function addEmail() {
      if (this.activeEmails.length < 2) {
        var newEmail = {
          id: null,
          type: 0,
          isDefault: this.activeEmails.filter(function (x) {
            return x.isDefault;
          }).length === 0,
          isNew: true,
          isDeleted: false,
          address: ''
        };
        this.innerCustomer.emails.splice(this.innerCustomer.emails.length, 1, newEmail);
      }
    },
    deleteEmail: function deleteEmail(email, index) {
      if (email.isNew) {
        this.innerCustomer.emails.splice(index, 1);
      } else {
        email.isDeleted = true;
        email.address = 'deleted@deleted.com';
      }
      if (email.isDefault && this.activeEmails.length > 0) {
        this.activeEmails[0].isDefault = true;
      }
    },
    setDefaultEmail: function setDefaultEmail(index) {
      this.innerCustomer.emails.forEach(function (p, i) {
        p.isDefault = index === i;
      });
    },
    addPhone: function addPhone() {
      if (this.activePhones.length < 3) {
        var newPhone = {
          id: null,
          type: this.activePhones.length == 0 ? _enums__WEBPACK_IMPORTED_MODULE_19__["PhoneTypes"].Mobile : _enums__WEBPACK_IMPORTED_MODULE_19__["PhoneTypes"].Home,
          no: '',
          isDefault: this.activePhones.filter(function (x) {
            return x.isDefault;
          }).length === 0,
          isNew: true,
          isDeleted: false
        };
        this.innerCustomer.phones.splice(this.innerCustomer.phones.length, 1, newPhone);
      }
    },
    deletePhone: function deletePhone(phone, index) {
      if (phone.isNew) {
        this.innerCustomer.phones.splice(index, 1);
      } else {
        phone.isDeleted = true;
        phone.no = 'deleted';
      }
      if (phone.isDefault && this.activePhones.length > 0) {
        this.activePhones[0].isDefault = true;
        this.activePhones[0].isDirty = true;
      }
    },
    setDefaultPhone: function setDefaultPhone(index) {
      this.innerCustomer.phones.forEach(function (p, i) {
        p.isDefault = index === i;
      });
    },
    getDefaultAddress: function getDefaultAddress() {
      this.defaultAddress = {
        id: null,
        type: 0,
        addressType: 1,
        address1: '',
        address2: '',
        address3: '',
        suburbText: '',
        suburbPostcode: '',
        stateCode: '',
        stateText: '',
        countryCode: '',
        countryText: '',
        assetID: this.innerCustomer.id,
        isDefault: true,
        isDeleted: false,
        isNew: true
      };
      if (this.innerCustomer.addresses.length > 0 && this.innerCustomer.addresses.some(function (a) {
        return a.isDefault;
      })) {
        this.defaultAddress = this.innerCustomer.addresses.find(function (a) {
          return a.isDefault;
        });
      }
    },
    updateInnerCustomer: function updateInnerCustomer() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              console.log("".concat(_this4.$options.name, " - ").concat(_this4.value.modifiedDate));
              console.log("".concat(_this4.$options.name, " - ").concat(_this4.quote.modifiedDate));
              _context2.n = 1;
              return _this4.$nextTick();
            case 1:
              _this4.innerCustomer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default()(_this4.value);
              _this4.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_18___default()(_this4.quote);
              _this4.getDefaultAddress();
              //this.$refs.addressInput.refreshAddress()
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getCustomerDropdownProto: function getCustomerDropdownProto() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this5.isSearchingCustomer = true;
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_23__["CustomerService"].getCustomerDropdownProto(_this5.filter);
            case 1:
              _this5.filteredCustomers = _context3.v;
              _this5.isSearchingCustomer = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    searchCustomer: lodash_debounce__WEBPACK_IMPORTED_MODULE_25___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(type) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (type === 'firstname') {
                this.filter.name = this.innerCustomer.firstname;
              } else if (type === 'lastname') {
                this.filter.name = this.innerCustomer.lastname;
              } else if (type === 'companyName') {
                this.filter.name = this.innerCustomer.companyName;
              }
              this.getCustomerDropdownProto();
            case 1:
              return _context4.a(2);
          }
        }, _callee4, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 300),
    selectCustomer: function selectCustomer(selected) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (selected) {
                _this6.$emit('select-customer', selected.key);
              }
            case 1:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    assessmentHistoryChange: function assessmentHistoryChange(event) {
      this.innerQuote.isAssessmentEnabled = !!event.target.checked;
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../storeMixin */ "./src/views/quote/storeMixin.js");
/* harmony import */ var _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./PanelBlurMixin */ "./src/views/quote/components/QuoteHeader/PanelBlurMixin.js");
/* harmony import */ var _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/enums/JobStageTypes */ "./src/enums/JobStageTypes.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _components_BulmaAutocomplete_BulmaAutocomplete_vue__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../../../../components/BulmaAutocomplete/BulmaAutocomplete.vue */ "./src/components/BulmaAutocomplete/BulmaAutocomplete.vue");
/* harmony import */ var _AssessorAutocomplete_vue__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./AssessorAutocomplete.vue */ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../../QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../../QuoteOrmValidation */ "./src/views/quote/QuoteOrmValidation.js");





































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteInsurer',
  inject: ['$vv'],
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_24__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_25___default.a,
    BulmaAutocomplete: _components_BulmaAutocomplete_BulmaAutocomplete_vue__WEBPACK_IMPORTED_MODULE_33__["default"],
    AssessorAutocomplete: _AssessorAutocomplete_vue__WEBPACK_IMPORTED_MODULE_34__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_29__["default"], _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_30__["default"]],
  props: {
    value: null,
    quote: null,
    vehicle: null,
    nextLineNumber: null,
    isSaving: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      innerInsurer: null,
      innerQuote: null,
      quoters: [],
      selectedAuthorisedDate: null,
      isInsurerLoading: false,
      selectedInsurer: null,
      insurerFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_21__["default"].empty(),
        assetName: '',
        showCustomer: false,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      insurers: [],
      arnieBrands: null,
      isQuoteWatchPaused: false,
      isInsurerWatchPaused: false,
      excess: 0,
      claimsTypes: [],
      jobStartDate: null,
      jobEndDate: null,
      modelConfig: {
        start: {
          timeAdjust: '08:00:00'
        },
        end: {
          timeAdjust: '08:00:00'
        }
      },
      quoteRepx: null,
      phoneNoTokens: {
        P: {
          pattern: /[0-9, ()\-+]/
        }
      },
      phoneNoMask: Array(31).join('P')
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    labourTimesTypeEnum: function labourTimesTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_23__["LabourTimeTypes"];
    },
    damageSeverityTypes: function damageSeverityTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_23__["DamageSeverityTypes"];
    },
    ecomType: {
      get: function get() {
        if (this.innerInsurer.pnet) {
          return this.ecomTypeEnum.PNET;
        } else if (this.innerInsurer.orm) {
          return this.ecomTypeEnum.ORM;
        } else {
          return this.ecomTypeEnum.None;
        }
      },
      set: function set(newValue) {
        if (newValue === this.ecomTypeEnum.None) {
          this.innerInsurer.pnet = false;
          this.innerInsurer.orm = false;
        } else if (newValue === this.ecomTypeEnum.PNET) {
          this.innerInsurer.pnet = true;
          this.innerInsurer.orm = false;
          this.innerQuote.excessGST = true;
          this.innerQuote.quotingMethod = 'D';
        } else if (newValue === this.ecomTypeEnum.ORM) {
          this.innerInsurer.pnet = false;
          this.innerInsurer.orm = true;
          this.innerQuote.excessGST = false;
          this.innerQuote.quotingMethod = 'H';
        }
      }
    },
    ecomTypeEnum: function ecomTypeEnum() {
      return _enums__WEBPACK_IMPORTED_MODULE_23__["EcomTypes"];
    },
    quotingMethodTypes: function quotingMethodTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_23__["QuotingMethodTypes"];
    },
    includeClaimsType: function includeClaimsType() {
      return this.$company && this.$company.info.countryCode === 'MY';
    },
    selectedClaimsType: function selectedClaimsType() {
      var _this = this;
      return this.claimsTypes.length ? this.claimsTypes.find(function (i) {
        return i.key === _this.quote.claimsTypeKey;
      }) : {};
    },
    isAdditionalQuote: function isAdditionalQuote() {
      var _this$quote;
      return !!((_this$quote = this.quote) !== null && _this$quote !== void 0 && _this$quote.subQuoteNo);
    },
    claimNoValidationText: function claimNoValidationText() {
      if (!this.$v.entity.claimNo.ormMaxLength) return _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_36__["ormValidationMessages"].claimNo.ormMaxLength;
      if (!this.$v.entity.claimNo.ormRequired) return _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_36__["ormValidationMessages"].claimNo.ormRequired;
      if (!this.$v.entity.claimNo.required) return 'Claim Number is required';
      return '';
    },
    ormJobEndJobEndValidationText: function ormJobEndJobEndValidationText() {
      if (!this.$v.entity.jobStart.required || !this.$v.entity.jobEnd.required) {
        return 'Required by ORM';
      } else if (!this.$v.entity.jobStart.validJobStart || !this.$v.entity.jobEnd.validJobEnd) {
        return 'Invalid date range';
      }
    },
    hasInvoice: function hasInvoice() {
      return this.quote.invoices && this.quote.invoices.length > 0;
    },
    isOrm: function isOrm() {
      return this.innerQuote.orm !== null && this.innerQuote.orm !== undefined;
    },
    disableOwnerContribution: function disableOwnerContribution() {
      return this.innerQuote.readOnly || this.audanetLock || this.innerQuote.subQuoteNo > 0 || this.hasInvoice || (this.innerQuote.isAudaNet || this.isOrm) && !this.$user.info.isSupportUser;
    },
    disableExcessIncludesGST: function disableExcessIncludesGST() {
      return this.innerQuote.readOnly || this.readOnlyView || this.audanetLock || this.innerQuote.subQuoteNo > 0 || this.hasInvoice || !this.$user.info.isSupportUser;
    },
    isRepx: function isRepx() {
      return this.innerQuote.repx != null;
    },
    isRepairStartDateSynced: function isRepairStartDateSynced() {
      return this.quoteRepx ? this.quoteRepx.isRepairStartDateSynced : false;
    },
    isInsurerDropdownDisabled: function isInsurerDropdownDisabled() {
      return this.innerQuote.readOnly || this.audanetLock || this.isAdditionalQuote || this.hasInvoice || this.$licenceExpired;
    },
    filteredQuoters: function filteredQuoters() {
      var _this2 = this;
      return this.quoters.filter(function (option) {
        return option.toString().toLowerCase().indexOf(_this2.innerQuote.quoter.toLowerCase()) >= 0;
      });
    }
  },
  watch: {
    selectedAuthorisedDate: function selectedAuthorisedDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.authorisedDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerQuote.authorisedDate = null;
      }
    },
    innerInsurer: {
      handler: function handler(newVal, oldVal) {
        if (deep_diff__WEBPACK_IMPORTED_MODULE_32___default()(newVal, oldVal)) {
          this.$emit('input', newVal);
        }
      },
      deep: true
    },
    innerQuote: {
      handler: function handler(newVal, oldVal) {
        if (!this.isQuoteWatchPaused) {
          this.$emit('update:quote', newVal);
        }
      },
      deep: true
    },
    'innerQuote.quotingMethod': function innerQuoteQuotingMethod(newVal, oldVal) {
      if (oldVal) {
        var vm = this;
        // Recalculates labours
        this.innerQuote.labours.forEach(function (item, index) {
          if (vm.innerQuote.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_23__["QuotingMethodTypes"].Hour) {
            if (item.rev !== '1') {
              var rate = vm.getRate(item.itemType);
              item.rate = rate;
            }
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
            // item.rate = 1
          }
        });
        // Recalculates other labours
        this.innerQuote.others.forEach(function (item, index) {
          if (vm.innerQuote.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_23__["QuotingMethodTypes"].Hour) {
            if (item.rev !== '1') {
              var rate = vm.getRate(item.itemType);
              item.rate = rate;
            }
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
          }
        });
        // Recalculates OPG
        this.innerQuote.opgs.forEach(function (item, index) {
          if (item.rev !== '1') {
            var rate = vm.getRate(item.opgCode);
            item.rate = rate;
          }
          if (vm.innerQuote.quotingMethod === _enums__WEBPACK_IMPORTED_MODULE_23__["QuotingMethodTypes"].Hour) {
            item.hourValue = item.rate !== 0 ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.dollarValue / item.rate) : 0;
            item.dollarValue = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(item.hourValue * item.rate);
          } else {
            item.hourValue = item.dollarValue;
          }
        });
      }
    },
    jobStartDate: function jobStartDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.jobStart = newVal.toISOString().split('.')[0] + 'Z';
        if (this.innerQuote.jobEnd && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].BookedIn;
          this.innerQuote.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].BookedIn;
        }
      } else {
        this.innerQuote.jobStart = null;
      }
    },
    jobEndDate: function jobEndDate(newVal, oldVal) {
      if (newVal) {
        this.innerQuote.jobEnd = newVal.toISOString().split('.')[0] + 'Z';
        if (this.innerQuote.jobStart && this.sortKey < this.bookedInSortKey && this.insurer.autoBookedInForDueInOut) {
          this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].BookedIn;
          this.innerQuote.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].BookedIn;
        }
      } else {
        this.innerQuote.jobEnd = null;
      }
    }
  },
  created: function created() {
    var _this3 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (!!_this3.includeClaimsType) {
              _this3.getClaimsTypes();
            }
            _this3.isQuoteWatchPaused = true;
            _this3.isInsurerWatchPaused = true;
            _this3.innerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19___default()(_this3.value);
            _this3.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19___default()(_this3.quote);
            _this3.excess = _this3.innerQuote.excess;
            if (!_this3.innerInsurer.isNew) {
              _this3.insurerFilter.assetId = _this3.innerInsurer.insurerId;
            }
            _this3.getInsurerDropdown();
            _this3.getArnieBrands();
            if (_this3.innerQuote.authorisedDate) {
              _this3.selectedAuthorisedDate = new Date("".concat(_this3.innerQuote.authorisedDate));
            }
            _this3.isQuoteWatchPaused = false;
            _this3.isInsurerWatchPaused = false;
            if (_this3.innerQuote.jobStart) {
              _this3.jobStart = new Date("".concat(_this3.innerQuote.jobStart));
              _this3.selectedJobStart = new Date("".concat(_this3.innerQuote.jobStart));
              _this3.jobStartDate = new Date("".concat(_this3.innerQuote.jobStart));
            }
            if (_this3.innerQuote.jobEnd) {
              _this3.jobEnd = new Date("".concat(_this3.innerQuote.jobEnd));
              _this3.selectedJobEnd = new Date("".concat(_this3.innerQuote.jobEnd));
              _this3.jobEndDate = new Date("".concat(_this3.innerQuote.jobEnd));
            }
            _context.n = 1;
            return _this3.loadQuoteRepxIfExist();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    this.$eventHub.$on("".concat(_enums__WEBPACK_IMPORTED_MODULE_23__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name), this.updateInnerInsurer);
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off("".concat(_enums__WEBPACK_IMPORTED_MODULE_23__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name));
  },
  methods: {
    handleSelectedAssessor: function handleSelectedAssessor(assessor) {
      if (assessor) {
        this.innerQuote.assessorName = assessor.assessorName;
        this.innerQuote.assessorPhoneNo = assessor.assessorPhoneNo;
      } else {
        this.innerQuote.assessorName = '';
        this.innerQuote.assessorPhoneNo = '';
      }
    },
    getArnieBrands: function getArnieBrands() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_22__["InsurerService"].getArnieBrand();
            case 1:
              _this4.arnieBrands = _context2.v;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    onChangeInsurerBrand: function onChangeInsurerBrand(event) {
      this.innerInsurer.arnie = this.innerInsurer.insurerBrand !== '' && this.innerInsurer.insurerBrand !== '0';
    },
    authorisedDateInputEvent: function authorisedDateInputEvent(event) {
      this.selectedAuthorisedDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    getInsurerDropdown: function getInsurerDropdown() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this5.isInsurerLoading = true;
              _context3.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_22__["QuoteService"].getInsurerDropdownProto(_this5.insurerFilter);
            case 1:
              _this5.insurers = _context3.v;
              if (_this5.insurerFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_21__["default"].empty()) {
                _this5.selectedInsurer = _this5.insurers.find(function (c) {
                  return c.assetId === _this5.innerInsurer.insurerId;
                });
              }
              _this5.isInsurerLoading = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getInsurerDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_20___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              this.isInsurerLoading = true;
              this.insurerFilter.assetName = query;
              _context4.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_22__["QuoteService"].getInsurerDropdownProto(this.insurerFilter);
            case 1:
              this.insurers = _context4.v;
              this.isInsurerLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectInsurer: function selectInsurer(selected) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee5() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              if (selected) {
                _context5.n = 1;
                break;
              }
              return _context5.a(2);
            case 1:
              // Update quote
              // this.innerQuote.insurerId = selected.assetId
              _this6.$emit('select-insurer', selected.assetId);
              // const isItemsEmpty =
              //   this.innerQuote.labours.length === 0 &&
              //   this.innerQuote.parts.length === 0 &&
              //   this.innerQuote.others.length === 0 &&
              //   this.innerQuote.opgs.length === 0 &&
              //   this.innerQuote.miscs.length === 0 &&
              //   this.innerQuote.sublets.length === 0
              // if (this.innerInsurer.isNew) {
              //   this.innerInsurer.miscs.splice(0, this.innerInsurer.miscs.length)
              // }
              // if (isItemsEmpty || this.innerInsurer.isNew) {
              // Update insurer related values when there are no items
              // this.$showSpinner()
              // Propagate to parent QuoteView to reload customer and vehicle
              // await this.getQuoteInsurer({ id: selected.assetId, refresh: true })
              // this.$hideSpinner()

              // Update quote
              // this.innerQuote.insurerId = selected.assetId
              // this.$emit('select-insurer', selected.assetId)

              // this.innerQuote.newMarkup = this.quoteInsurer.newMarkup
              // this.innerQuote.usedMarkup = this.quoteInsurer.usedMarkup
              // this.innerQuote.recoreMarkup = this.quoteInsurer.recoreMarkup
              // this.innerQuote.afterMarketMarkup = this.quoteInsurer.afterMarketMarkup
              // this.innerQuote.exchangeMarkup = this.quoteInsurer.exchangeMarkup
              // this.innerQuote.reconditionedMarkup = this.quoteInsurer.reconditionedMarkup
              // this.innerQuote.shopRate = this.quoteInsurer.shopRate
              // this.innerQuote.labourType = this.quoteInsurer.labourType
              // this.innerQuote.verRtrm = Math.max.apply(
              //   Math,
              //   this.quoteInsurer.insurerConsumables.map(function (c) {
              //     return c.versionNo
              //   })
              // )
              // // Update quote rates
              // this.addInsurerLabourRates(this.quoteInsurer)
              // // Add or update automatic items to quote
              // this.addInsurerAutoItems(this.quoteInsurer)
              // // Add or update template items to quote
              // this.addInsurerTemplateItems(this.quoteInsurer)
              // }
              _this6.innerInsurer.insurerId = selected.assetId;
              _this6.insurerFilter.assetId = selected.assetId;
              _this6.insurerFilter.assetName = '';
              _context5.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_22__["QuoteService"].getInsurerDropdownProto(_this6.insurerFilter);
            case 2:
              _this6.insurers = _context5.v;
            case 3:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    removeInsurer: function removeInsurer() {
      this.insurerFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_21__["default"].empty();
      this.innerInsurer.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_21__["default"].empty();
      this.getInsurerDropdown();
    },
    addInsurerLabourRates: function addInsurerLabourRates(insurer) {
      var vm = this;
      var isInsurerNtar = insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_23__["LabourTimeTypes"].NTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_23__["LabourTimeTypes"].LTAR || insurer.labourType === _enums__WEBPACK_IMPORTED_MODULE_23__["LabourTimeTypes"].eMTA;
      insurer.insurerLabourRates.forEach(function (ir) {
        var index = vm.innerQuote.rates.findIndex(function (qr) {
          return qr.labourCodeId === ir.labourCode;
        });
        if (index > -1) {
          vm.innerQuote.rates[index].rate = isInsurerNtar ? insurer.shopRate : ir.rate;
        } else {
          var labourType = vm.$labourTypes.find(function (t) {
            return t.labourTypeCode === ir.labourType;
          });
          var newRate = {
            rate: isInsurerNtar ? insurer.shopRate : ir.rate,
            quoteVersion: 0,
            quoteId: vm.innerQuote.quoteId,
            labourCodeId: ir.labourCode,
            labourTypeId: labourType.labourTypeId,
            deleted: false,
            createdBy: '',
            createdDate: '',
            modifiedBy: '',
            modifiedDate: '',
            isNew: true,
            isDeleted: false
          };
          vm.innerQuote.rates.splice(vm.innerQuote.rates.length, 1, newRate);
        }
      });
    },
    addInsurerAutoItems: function addInsurerAutoItems(insurer) {
      if (insurer.insurerAutoItems && insurer.insurerAutoItems.length > 0) {
        var vm = this;
        var lineNumber = this.nextLineNumber;
        insurer.insurerAutoItems.forEach(function (autoItem) {
          var currentItem = vm.innerQuote.miscs.find(function (i) {
            return i.itemDesc === autoItem.itemDesc && i.itemNo === autoItem.itemNo;
          });
          if (!currentItem) {
            var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_26__["QuoteItemModel"](vm.innerQuote.quoteId, autoItem.itemNo, autoItem.itemDesc, _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].MISC);
            newItem.value = autoItem.price;
            newItem.reportOnly = autoItem.reportOnly;
            newItem.sortNo = vm.innerQuote.miscs.length ? Math.max.apply(Math, Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(vm.innerQuote.miscs.map(function (i) {
              return i.sortNo;
            }))) + 1 : 1;
            newItem.lineNumber = lineNumber;
            vm.innerQuote.miscs.splice(vm.innerQuote.miscs.length, 1, newItem);
            lineNumber++;
            vm.innerQuote.lines++;
          } else {
            currentItem.value = autoItem.price;
            currentItem.reportOnly = autoItem.reportOnly;
          }
        });
      }
    },
    addInsurerTemplateItems: function addInsurerTemplateItems(insurer) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee6() {
        var templateItems, vm;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              if (!_components_Guid__WEBPACK_IMPORTED_MODULE_21__["default"].validGuid(insurer.templateId)) {
                _context6.n = 2;
                break;
              }
              _context6.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_22__["QuoteTemplateService"].getQuoteTemplateItems(insurer.templateId);
            case 1:
              templateItems = _context6.v;
              if (templateItems && templateItems.length > 0) {
                vm = _this7;
                templateItems.forEach(function (templateItem) {
                  var currentItem = vm.innerQuote.miscs.find(function (i) {
                    return i.itemDesc === templateItem.itemDesc && i.itemNo === templateItem.itemNo && i.itemType === templateItem.itemType;
                  });
                  if (!currentItem) {
                    var newItem = new _classes_viewmodels__WEBPACK_IMPORTED_MODULE_26__["QuoteItemModel"](vm.innerQuote.quoteId, templateItem.itemNo, templateItem.itemDesc, templateItem.itemType);
                    newItem.value = templateItem.value;
                    newItem.reportOnly = templateItem.reportOnly;
                    newItem.sortNo = templateItem.sortNo;
                    // let sortNo
                    switch (templateItem.itemType) {
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].RR:
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].REP:
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].RWA:
                        newItem.rate = vm.getLabourRate(templateItem.itemType);
                        vm.innerQuote.labours.splice(vm.innerQuote.labours.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].PAINT:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerQuote.labours.splice(vm.innerQuote.labours.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].OPG:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerQuote.opgs.splice(vm.innerQuote.opgs.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].MECH:
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].CD:
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].CRUSH:
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].FIBER:
                        newItem.rate = vm.getLabourRate(vm.quoteVehicle.paintGroup);
                        vm.innerQuote.others.splice(vm.innerQuote.others.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].PART:
                        vm.innerQuote.parts.splice(vm.innerQuote.parts.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].MISC:
                        vm.innerQuote.miscs.splice(vm.innerQuote.miscs.length, 1, newItem);
                        break;
                      case _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].SUBL:
                        vm.innerQuote.sublets.splice(vm.innerQuote.sublets.length, 1, newItem);
                        break;
                    }
                    // newItem.sortNo = templateItem.sortNo // || sortNo
                  } else {
                    currentItem.value = templateItem.value;
                    currentItem.itemType = templateItem.itemType;
                    currentItem.reportOnly = templateItem.reportOnly;
                    currentItem.sortNo = templateItem.sortNo;
                  }
                });
              }
            case 2:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    getLabourRate: function getLabourRate(code) {
      if (!this.innerQuote.rates) {
        return {};
      }
      var rate = this.isNtar ? this.innerQuote.rates[0] : this.innerQuote.rates.find(function (i) {
        return i.labourCodeId === code;
      });
      return !rate ? 0 : rate.rate;
    },
    updateInnerInsurer: function updateInnerInsurer() {
      var _this$insurers$find,
        _this$insurers,
        _this8 = this;
      this.isQuoteWatchPaused = true;
      this.isInsurerWatchPaused = true;
      this.innerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19___default()(this.value);
      this.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_19___default()(this.quote);
      this.selectedInsurer = (_this$insurers$find = (_this$insurers = this.insurers) === null || _this$insurers === void 0 ? void 0 : _this$insurers.find(function (c) {
        return c.assetId === _this8.innerInsurer.insurerId;
      })) !== null && _this$insurers$find !== void 0 ? _this$insurers$find : null;
      this.$nextTick(function () {
        _this8.isQuoteWatchPaused = false;
        _this8.isInsurerWatchPaused = false;
      });
    },
    updateQuote: function updateQuote() {
      console.log('QuoteInsurer.updateQuote');
      var isItemsEmpty = this.innerQuote.labours.length === 0 && this.innerQuote.parts.length === 0 && this.innerQuote.others.length === 0 && this.innerQuote.opgs.length === 0 && this.innerQuote.miscs.length === 0 && this.innerQuote.sublets.length === 0;
      if (isItemsEmpty || this.innerInsurer.isNew) {
        this.innerQuote.newMarkup = this.innerInsurer.newMarkup;
        this.innerQuote.usedMarkup = this.innerInsurer.usedMarkup;
        this.innerQuote.recoreMarkup = this.innerInsurer.recoreMarkup;
        this.innerQuote.afterMarketMarkup = this.innerInsurer.afterMarketMarkup;
        this.innerQuote.exchangeMarkup = this.innerInsurer.exchangeMarkup;
        this.innerQuote.reconditionedMarkup = this.innerInsurer.reconditionedMarkup;
        this.innerQuote.parallelMarkup = this.innerInsurer.parallelMarkup;
        this.innerQuote.shopRate = this.innerInsurer.shopRate;
        this.innerQuote.labourType = this.innerInsurer.labourType;
        this.innerQuote.verRtrm = Math.max.apply(Math, this.innerInsurer.insurerConsumables.map(function (c) {
          return c.versionNo;
        }));
        // Update quote rates
        this.addInsurerLabourRates(this.innerInsurer);
        // Add or update automatic items to quote
        this.addInsurerAutoItems(this.innerInsurer);
        // Add or update template items to quote
        this.addInsurerTemplateItems(this.innerInsurer);
      }
    },
    calculateExcess: function calculateExcess() {
      if (this.innerQuote.excessWithGst && this.excess !== this.innerQuote.excess) {
        var gstModel = new _classes__WEBPACK_IMPORTED_MODULE_27__["GstModel"](this.innerQuote.gstRate);
        this.excess = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(this.excess / gstModel.multiplier);
        this.innerQuote.excess = this.excess;
        console.log(this.innerQuote.excess);
      } else if (this.excess !== this.innerQuote.excess) {
        this.innerQuote.excess = this.excess;
      }
    },
    getRate: function getRate(code) {
      var _this9 = this;
      var rateObject = null;
      if (code === _enums__WEBPACK_IMPORTED_MODULE_23__["ItemCategoryTypes"].PAINT) {
        rateObject = this.innerQuote.rates.find(function (i) {
          return i.labourCodeId === _this9.vehicle.paintGroup;
        });
      } else {
        rateObject = this.innerQuote.rates.find(function (i) {
          return i.labourCodeId === code;
        });
      }
      var rate = !this.isNtar && rateObject ? rateObject.rate : this.innerQuote.shopRate;
      return rate;
    },
    getDamageSeverityDescription: function getDamageSeverityDescription(value) {
      var desc = this.$filters.formatPascalToDescription(value);
      if (desc.toLowerCase() === 'none') {
        desc = '';
      }
      return desc;
    },
    getClaimsTypes: function getClaimsTypes() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _context7.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_22__["CompanyService"].getClaimsTypes();
            case 1:
              _this0.claimsTypes = _context7.v;
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    onClaimsTypeChange: function onClaimsTypeChange(selected) {
      this.innerQuote.claimsTypeKey = selected.key;
    },
    jobStartDateInputEvent: function jobStartDateInputEvent(event) {},
    jobEndDateInputEvent: function jobEndDateInputEvent(event) {},
    resetJobStartEnd: function resetJobStartEnd() {
      if (this.jobStartDate !== null) {
        this.jobStartDate = null;
      }
      if (this.jobEndDate !== null) {
        this.jobEndDate = null;
      }
      if (this.selectedJobStage == _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].BookedIn && this.insurer.autoBookedInForDueInOut) {
        this.selectedJobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].FollowUpRequired;
        this.innerQuote.jobStage = _enums_JobStageTypes__WEBPACK_IMPORTED_MODULE_31__["default"].FollowUpRequired;
      }

      // Reset validation objects
      this.$v.entity.jobStart.$reset();
      this.$v.entity.jobEnd.$reset();
    },
    loadQuoteRepxIfExist: function loadQuoteRepxIfExist() {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee8() {
        var quoteRepx;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _context8.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_35__["default"].getQuoteRepx(_this1.innerQuote.quoteId);
            case 1:
              quoteRepx = _context8.v;
              if (quoteRepx) {
                _this1.quoteRepx = quoteRepx;
              }
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    driveableOnChange: function driveableOnChange(event) {
      this.innerQuote.driveable = !!event.target.checked;
    },
    inScopeOnChange: function inScopeOnChange(event) {
      this.innerQuote.inScope = !!event.target.checked;
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_VehicleLookupModal__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/VehicleLookupModal */ "./src/components/VehicleLookupModal/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaAutocomplete */ "./src/components/BulmaAutocomplete/index.js");
/* harmony import */ var _components_carmodel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/components/carmodel */ "./src/components/carmodel/index.js");
/* harmony import */ var _components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/carmodel/UnscheduledModelModal */ "./src/components/carmodel/UnscheduledModelModal.vue");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./PanelBlurMixin */ "./src/views/quote/components/QuoteHeader/PanelBlurMixin.js");
/* harmony import */ var _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../../QuoteOrmValidation */ "./src/views/quote/QuoteOrmValidation.js");



























// import storeMixin from '../../storeMixin'




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteVehicle',
  inject: ['$vv'],
  components: {
    VehicleLookupModal: _components_VehicleLookupModal__WEBPACK_IMPORTED_MODULE_19__["VehicleLookupModal"],
    BulmaAutocomplete: _components_BulmaAutocomplete__WEBPACK_IMPORTED_MODULE_21__["BulmaAutocomplete"],
    CarModelSearchModal: _components_carmodel__WEBPACK_IMPORTED_MODULE_22__["CarModelSearchModal"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_28___default.a
  },
  mixins: [_components_directives__WEBPACK_IMPORTED_MODULE_27__["InputValidationDirective"], _PanelBlurMixin__WEBPACK_IMPORTED_MODULE_29__["default"]],
  props: {
    value: null,
    quote: null,
    insurer: null,
    isSaving: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerVehicle: null,
      innerQuote: null,
      isVehicleLookupModalActive: false,
      selectedMakeModel: null,
      filteredMakeModels: [],
      makeModelText: '',
      isSearchingMakeModel: false,
      isCarModelSearchModalActive: false,
      months: {
        1: '01',
        2: '02',
        3: '03',
        4: '04',
        5: '05',
        6: '06',
        7: '07',
        8: '08',
        9: '09',
        10: '10',
        11: '11',
        12: '12'
      },
      vinTokens: {
        '#': {
          pattern: /[0-9a-zA-Z]/
        }
      },
      vinMask: Array(18).join('#'),
      // length of vin field
      engineSizeTokens: {
        P: {
          pattern: /[0-9, .]/
        }
      },
      engineSizeMask: Array(5).join('P'),
      vehicles: [],
      vehicleFilter: {
        vehicleId: _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty(),
        rego: '',
        pageIndex: 1,
        pageSize: 50
      },
      isSearchingVehicle: false,
      ntarLtarStatus: '',
      selectedVehicle: null,
      innerInsurer: null,
      regoMaxLength: 10
    };
  },
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    $v: function $v() {
      return this.$vv || this.$v;
    },
    ormMessages: function ormMessages() {
      return _QuoteOrmValidation__WEBPACK_IMPORTED_MODULE_30__["ormValidationMessages"];
    },
    transmissionTypes: function transmissionTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_25__["TransmissionTypes"];
    },
    stateRegoTypes: function stateRegoTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_25__["StateRegoTypes"];
    },
    paintGroupTypes: function paintGroupTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_25__["PaintGroupTypes"];
    }
  }, Object(vuex__WEBPACK_IMPORTED_MODULE_24__["mapGetters"])('vehicleOptions', {
    storeBodyShapes: 'bodyShapes',
    storeColours: 'colours',
    storePaintGroups: 'paintGroups'
  })), {}, {
    paintGroups: function paintGroups() {
      // return this.$store.getters['vehicleOptions/paintGroups']
      return this.storePaintGroups;
    },
    modelId: function modelId() {
      if (this.innerVehicle && this.innerVehicle.model && this.innerVehicle.model.id) {
        return this.innerVehicle.model.id;
      }
      return '';
    },
    bodyStyles: function bodyStyles() {
      // return this.$store.getters['vehicleOptions/bodyShapes']
      return this.storeBodyShapes;
    },
    bodyStyles2: function bodyStyles2() {
      var _this = this;
      var bodyShape = this.bodyStyles.find(function (d) {
        return d.id === _this.innerVehicle.bodyId;
      });
      if (bodyShape) {
        return bodyShape.shapes;
      }
      return [];
    },
    colours: function colours() {
      var input = this.innerVehicle && this.innerVehicle.colour ? this.innerVehicle.colour.toLowerCase() : '';
      return this.storeColours.filter(function (d) {
        return d.toLowerCase().indexOf(input) > -1;
      });
    },
    isOrm: function isOrm() {
      return this.innerQuote.orm !== null && this.innerQuote.orm !== undefined;
    },
    isNtar: function isNtar() {
      return this.innerQuote.labourType === _enums__WEBPACK_IMPORTED_MODULE_25__["LabourTimeTypes"].NTAR || this.innerQuote.labourType === _enums__WEBPACK_IMPORTED_MODULE_25__["LabourTimeTypes"].LTAR || this.innerQuote.labourType === _enums__WEBPACK_IMPORTED_MODULE_25__["LabourTimeTypes"].eMTA;
    },
    readyOnlyForSubQuote: function readyOnlyForSubQuote() {
      return this.innerQuote.subQuoteNo > 0;
    }
  }),
  watch: {
    'innerQuote.keyNo': function innerQuoteKeyNo(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.$emit('update:quote', this.innerQuote);
      }
    },
    'innerQuote.odometer': function innerQuoteOdometer(newVal, oldVal) {
      this.$emit('update:quote', this.innerQuote);
    },
    'innerQuote.driveable': function innerQuoteDriveable(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.$emit('update:quote', this.innerQuote);
      }
    },
    'innerQuote.inScope': function innerQuoteInScope(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.$emit('update:quote', this.innerQuote);
      }
    },
    'innerQuote.isTowed': function innerQuoteIsTowed(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.$emit('update:quote', this.innerQuote);
      }
    },
    'innerQuote.vehicleId': function innerQuoteVehicleId(newVal, oldVal) {
      if (oldVal !== newVal) {
        this.getNtarLtarStatus();
      }
    },
    'innerVehicle.model': {
      handler: function handler(newVal, oldVal) {
        if (this.innerVehicle.model) {
          this.makeModelText = this.innerVehicle.model.name;
        }
      },
      deep: true
    },
    'innerVehicle.model.scheduleId': {
      handler: function () {
        var _handler = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
            while (1) switch (_context.n) {
              case 0:
                this.getNtarLtarStatusByScheduleBody();
              case 1:
                return _context.a(2);
            }
          }, _callee, this);
        }));
        function handler(_x, _x2) {
          return _handler.apply(this, arguments);
        }
        return handler;
      }()
    },
    'innerVehicle.bodyId': {
      handler: function () {
        var _handler2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
            while (1) switch (_context2.n) {
              case 0:
                this.getNtarLtarStatusByScheduleBody();
              case 1:
                return _context2.a(2);
            }
          }, _callee2, this);
        }));
        function handler(_x3, _x4) {
          return _handler2.apply(this, arguments);
        }
        return handler;
      }()
    },
    'innerVehicle.bodyId2': {
      handler: function () {
        var _handler3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3(newVal, oldVal) {
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
            while (1) switch (_context3.n) {
              case 0:
                this.getNtarLtarStatusByScheduleBody();
              case 1:
                return _context3.a(2);
            }
          }, _callee3, this);
        }));
        function handler(_x5, _x6) {
          return _handler3.apply(this, arguments);
        }
        return handler;
      }()
    },
    innerVehicle: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    'value.paintGroup': {
      handler: function handler(newVal, oldVal) {
        if (newVal === oldVal) return;
        // change paint group of all the quote items in paint
        this.$emit('updateQuoteItemsDefaultPaintGroup', newVal, oldVal);
      }
    }
  },
  created: function created() {
    this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default()(this.value);
    this.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default()(this.quote);
    this.innerInsurer = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default()(this.insurer);
    this.vehicleFilter.vehicleId = this.innerQuote.vehicleId;
    if (this.innerVehicle && this.innerVehicle.model && this.innerVehicle.model.name) {
      this.makeModelText = this.innerVehicle.model.name;
    }
    this.getNtarLtarStatus();
    this.getVehicleDropdown();
  },
  mounted: function mounted() {
    this.$eventHub.$on("".concat(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name), this.updateInnerVehicle);
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off("".concat(_enums__WEBPACK_IMPORTED_MODULE_25__["EventHubTypes"].EntitySaved, "-").concat(this.$parent.$options.name));
  },
  methods: {
    selectVehicleMakeModel: function selectVehicleMakeModel(model, vehicle) {
      console.log(model, vehicle);
      this.innerVehicle.model = model;
      this.innerVehicle.vin = vehicle.vin;
      this.innerVehicle.colour = vehicle.colour;
      this.innerVehicle.engineNo = vehicle.engine_number;
      this.innerVehicle.buildYear = vehicle.year_of_manufacture;
      this.innerVehicle.stateRego = vehicle.stateRego;
      this.translateBodyType(vehicle.factory ? vehicle.factory.body : vehicle.body_type, this.innerVehicle);
      if (vehicle.factory) {
        this.innerVehicle.cylinders = vehicle.factory.cylinders;
        this.innerVehicle.engineSize = vehicle.factory.litres;
        this.innerVehicle.buildYear = vehicle.factory.buildYear;
      }
      // this.selectedVehicle.rego = vehicle.plate.number
      // this.selectedVehicle.model = model.name
    },
    translateBodyType: function translateBodyType(bodyType, model) {
      if (bodyType.toLowerCase().includes('sedan')) {
        model.bodyId = '4';
        model.bodyId2 = '4S';
      } else if (bodyType.toLowerCase().includes('wagon')) {
        model.bodyId = 'W';
        model.bodyId2 = 'WG';
      }
    },
    searchMakeModel: lodash_debounce__WEBPACK_IMPORTED_MODULE_18___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4(query) {
        var filtered;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              this.isSearchingMakeModel = true;
              this.makeModelText = (query === null || query === void 0 ? void 0 : query.trim()) || '';
              this.filteredMakeModels = [];
              if (!query) {
                _context4.n = 2;
                break;
              }
              _context4.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].searchModelByName(query);
            case 1:
              filtered = _context4.v;
              this.filteredMakeModels = filtered.data.list;
            case 2:
              this.isSearchingMakeModel = false;
            case 3:
              return _context4.a(2);
          }
        }, _callee4, this);
      }));
      return function (_x7) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectMakeModel: function selectMakeModel(val) {
      console.log("".concat(val, " - ").concat(this.makeModelText));
      if (val) {
        this.innerVehicle.model = val;
        if (this.innerVehicle.model.bodies && this.innerVehicle.model.bodies.length > 0) {
          this.innerVehicle.bodyId = this.innerVehicle.model.bodies.find(function (b) {
            return b && b !== ' ';
          });
        }
        if (this.bodyStyles2 && this.bodyStyles2.length > 0) {
          var bodyStyle2 = this.bodyStyles2[0];
          this.innerVehicle.bodyId2 = bodyStyle2.id;
        }
        if (this.innerVehicle.model.startYear) {
          this.innerVehicle.buildYear = this.innerVehicle.model.startYear;
        }
        if (this.innerVehicle.model.startMonth) {
          this.innerVehicle.buildMonth = this.innerVehicle.model.startMonth;
        }
      } else if (!val && this.makeModelText === '') {
        this.innerVehicle.model = null;
      }
    },
    selectMakeModelModal: function selectMakeModelModal(model) {
      if (model) {
        this.makeModelText = model.name;
        this.innerVehicle.model = model;
        if (this.innerVehicle.model.bodies && this.innerVehicle.model.bodies.length > 0) {
          this.innerVehicle.bodyId = this.innerVehicle.model.bodies.find(function (b) {
            return b && b !== ' ';
          });
        }
        if (this.bodyStyles2 && this.bodyStyles2.length > 0) {
          var bodyStyle2 = this.bodyStyles2[0];
          this.innerVehicle.bodyId2 = bodyStyle2.id;
        }
        if (this.innerVehicle.model.startYear) {
          this.innerVehicle.buildYear = this.innerVehicle.model.startYear;
        }
        if (this.innerVehicle.model.startMonth) {
          this.innerVehicle.buildMonth = this.innerVehicle.model.startMonth;
        }
      }
      this.isCarModelSearchModalActive = false;
    },
    checkMultipleModelCustomExists: function checkMultipleModelCustomExists() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var exists;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].checkMultipleModelCustomExists(_this2.innerVehicle.id, _this2.innerVehicle.model.id);
            case 1:
              exists = _context5.v;
              if (exists) {
                console.log('exists copymodel');
                _this2.copyModel();
              } else {
                console.log('not exists editmodel');
                _this2.editModel();
              }
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    addModel: function addModel() {
      var _this3 = this;
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_16__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_23__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          name: this.makeModelText,
          bodyStyles: this.storeBodyShapes // this.$store.getters['vehicleOptions/bodyShapes']
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this3.makeModelText = res.name;
        _this3.innerVehicle.model = res;
        _this3.innerVehicle.model.isNew = false;
      });
    },
    copyModel: function copyModel() {
      var _this4 = this;
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_16__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_23__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          bodyStyles: this.storeBodyShapes,
          // this.$store.getters['vehicleOptions/bodyShapes'],
          copyModelId: this.innerVehicle.model.id
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this4.makeModelText = res.name;
        _this4.innerVehicle.model = res;
        _this4.innerVehicle.model.isNew = false; // ??
      });
    },
    editModel: function editModel() {
      var _this5 = this;
      if (!this.innerVehicle.model.isUnscheduled) {
        return;
      }
      var UnscheduledSearchModalComponent = vue__WEBPACK_IMPORTED_MODULE_16__["default"].extend(_components_carmodel_UnscheduledModelModal__WEBPACK_IMPORTED_MODULE_23__["default"]);
      var props = {
        el: document.createElement('div'),
        propsData: {
          visible: true,
          bodyStyles: this.storeBodyShapes,
          // this.$store.getters['vehicleOptions/bodyShapes'],
          modelId: this.innerVehicle.model.id
        }
      };
      new UnscheduledSearchModalComponent(props).$on('ok', function (res) {
        _this5.makeModelText = res.name;
        _this5.innerVehicle.model = res;
      });
    },
    checkYear: function checkYear(e) {
      var year = e.target.value;
      if (year && year.length === 2) {
        var strYear = "01/01/".concat(year);
        var newDate = new Date(strYear);
        this.innerVehicle.buildYear = newDate.getFullYear().toString();
      } else if (year.length !== 4) {
        this.innerVehicle.buildYear = '';
      }
    },
    selectPaintGroup: function selectPaintGroup(event) {
      if (event.target.value !== _enums__WEBPACK_IMPORTED_MODULE_25__["PaintGroupTypes"].M3) {
        this.innerVehicle.paintGroupPlus = false;
      }
    },
    searchVehicle: lodash_debounce__WEBPACK_IMPORTED_MODULE_18___default()(/*#__PURE__*/function () {
      var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              this.isSearchingVehicle = true;
              this.vehicleFilter.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
              this.vehicleFilter.rego = query;
              this.innerVehicle.rego = query;
              _context6.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getVehicleDropdownProto(this.vehicleFilter);
            case 1:
              this.vehicles = _context6.v;
              this.isSearchingVehicle = false;
            case 2:
              return _context6.a(2);
          }
        }, _callee6, this);
      }));
      return function (_x8) {
        return _ref2.apply(this, arguments);
      };
    }(), 500),
    selectVehicle: function selectVehicle(selected) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              if (!(selected && selected.vehicleId)) {
                _context7.n = 2;
                break;
              }
              _this6.innerQuote.vehicleId = selected.vehicleId;
              _this6.innerQuote.customerId = selected.customerId;
              // Propagate to parent QuoteView to reload customer and vehicle
              // this.getQuoteCustomer({ id: selected.customerId, refresh: true })
              // this.getQuoteVehicle({ id: selected.vehicleId, refresh: true })
              _this6.vehicleFilter.vehicleId = selected.vehicleId;
              _this6.vehicleFilter.rego = '';
              _context7.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getVehicleDropdownProto(_this6.vehicleFilter);
            case 1:
              _this6.vehicles = _context7.v;
              console.log(_this6.innerQuote.vehicleId);
              _this6.$emit('update:quote', _this6.innerQuote);
              _this6.$nextTick(function () {
                _this6.$emit('select-vehicle', selected.vehicleId, selected.customerId);
              });
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    handleVehiclePickerEnter: function handleVehiclePickerEnter() {
      if (this.$licenceExpired) return;
      if (this.$company.info.locale === 'en-AU') {
        // get element with clas dropdown-item that also has class is-hovered
        var el = this.$refs.vehicleAutocomplete.$el;
        var selected = el.querySelector('.dropdown-item.is-hovered');
        if (!selected) this.isVehicleLookupModalActive = true;
      }
    },
    updateInnerVehicle: function updateInnerVehicle() {
      var _this$vehicles$find,
        _this$vehicles,
        _this7 = this;
      this.innerVehicle = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default()(this.value);
      this.innerQuote = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_17___default()(this.quote);
      this.makeModelText = this.innerVehicle.model ? this.innerVehicle.model.name : '';
      this.selectedVehicle = (_this$vehicles$find = (_this$vehicles = this.vehicles) === null || _this$vehicles === void 0 ? void 0 : _this$vehicles.find(function (c) {
        return c.vehicleId === _this7.innerQuote.vehicleId;
      })) !== null && _this$vehicles$find !== void 0 ? _this$vehicles$find : null;
    },
    getNtarLtarStatus: function getNtarLtarStatus() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _context8.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getNtarLtarStatusById(_this8.innerQuote.vehicleId);
            case 1:
              _this8.ntarLtarStatus = _context8.v;
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    getNtarLtarStatusByScheduleBody: function getNtarLtarStatusByScheduleBody() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              if (!(_this9.innerVehicle.model && _this9.innerVehicle.model.scheduleId && _this9.innerVehicle.model.scheduleId.trim() && _this9.innerVehicle.bodyId && _this9.innerVehicle.bodyId.trim())) {
                _context9.n = 2;
                break;
              }
              _context9.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getNtarLtarStatusByScheduleBody(_this9.innerVehicle.model.scheduleId, _this9.innerVehicle.bodyId);
            case 1:
              _this9.ntarLtarStatus = _context9.v;
              _context9.n = 3;
              break;
            case 2:
              _this9.ntarLtarStatus = '';
            case 3:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    getVehicleDropdown: function getVehicleDropdown() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee0() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              _this0.isSearchingVehicle = true;
              _context0.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getVehicleDropdownProto(_this0.vehicleFilter);
            case 1:
              _this0.vehicles = _context0.v;
              if (_this0.vehicleFilter.vehicleId !== _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty()) {
                _this0.selectedVehicle = _this0.vehicles.find(function (c) {
                  return c.vehicleId === _this0.innerQuote.vehicleId;
                });
              }
              _this0.isSearchingVehicle = false;
            case 2:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    getVehicleDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_18___default()(/*#__PURE__*/function () {
      var _ref3 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee1(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              this.isSearchingVehicle = true;
              this.vehicleFilter.rego = query;
              _context1.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getVehicleDropdownProto(this.vehicleFilter);
            case 1:
              this.vehicles = _context1.v;
              this.isSearchingVehicle = false;
            case 2:
              return _context1.a(2);
          }
        }, _callee1, this);
      }));
      return function (_x9) {
        return _ref3.apply(this, arguments);
      };
    }(), 500),
    removeVehicle: function removeVehicle() {
      this.vehicleFilter.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.innerQuote.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].empty();
      this.getVehicleDropdown();
    },
    selectVehicle1: function selectVehicle1(selected) {
      var _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee10() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              console.log('selectVehicle1', selected.vehicleId, selected.customerId);
              _this1.innerQuote.vehicleId = selected.vehicleId;
              _this1.innerQuote.customerId = selected.customerId;
              // this.removeQuoteCustomer()
              // this.removeQuoteVehicle()
              // this.getQuoteCustomer({ id: selected.customerId, refresh: false })
              // this.getQuoteVehicle({ id: selected.vehicleId, refresh: true })
              _this1.vehicleFilter.vehicleId = selected.vehicleId;
              _this1.vehicleFilter.rego = '';
              _context10.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_20__["VehicleService"].getVehicleDropdownProto(_this1.vehicleFilter);
            case 1:
              _this1.vehicles = _context10.v;
              _this1.$emit('update:quote', _this1.innerQuote);
              _this1.$nextTick(function () {
                _this1.$emit('select-vehicle', selected.vehicleId, selected.customerId);
              });
            case 2:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    onChangeBodyStyle: function onChangeBodyStyle() {
      var bodyStyle2 = this.bodyStyles2[0];
      this.innerVehicle.bodyId2 = bodyStyle2.id;
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next();
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("fieldset", {
    staticClass: "quote-header-fieldset",
    attrs: {
      disabled: _vm.$licenceExpired
    }
  }, [_c("div", {
    staticClass: "quote-header fixed-grid has-4-cols-desktop has-1-cols-mobile"
  }, [_c("div", {
    staticClass: "grid"
  }, [_vm.innerVehicle ? _c("quote-vehicle", {
    attrs: {
      quote: _vm.innerValue,
      "is-saving": _vm.headerSavingPanels.vehicle,
      insurer: _vm.innerInsurer
    },
    on: {
      "update:quote": function updateQuote($event) {
        _vm.innerValue = $event;
      },
      updateQuoteItemsDefaultPaintGroup: function updateQuoteItemsDefaultPaintGroup(newVal, oldVal) {
        return _vm.$emit("updateQuoteItemsDefaultPaintGroup", newVal, oldVal);
      },
      "select-vehicle": _vm.selectVehicle,
      "component-blur": function componentBlur($event) {
        return _vm.$emit("vehicle-component-blur");
      }
    },
    model: {
      value: _vm.innerVehicle,
      callback: function callback($$v) {
        _vm.innerVehicle = $$v;
      },
      expression: "innerVehicle"
    }
  }) : _vm._e(), _vm.innerCustomer ? _c("quote-customer", {
    attrs: {
      quote: _vm.innerValue,
      "is-saving": _vm.headerSavingPanels.customer,
      "is-new-customer-prompt": _vm.isNewCustomerPrompt
    },
    on: {
      "update:quote": function updateQuote($event) {
        _vm.innerValue = $event;
      },
      "select-customer": _vm.selectCustomer,
      "component-blur": function componentBlur($event) {
        return _vm.$emit("customer-component-blur");
      }
    },
    model: {
      value: _vm.innerCustomer,
      callback: function callback($$v) {
        _vm.innerCustomer = $$v;
      },
      expression: "innerCustomer"
    }
  }) : _vm._e(), _vm.innerInsurer ? _c("quote-insurer", {
    attrs: {
      quote: _vm.innerValue,
      "is-saving": _vm.headerSavingPanels.insurer,
      vehicle: _vm.innerVehicle,
      "next-line-number": _vm.nextLineNumber
    },
    on: {
      "update:quote": function updateQuote($event) {
        _vm.innerValue = $event;
      },
      "select-insurer": _vm.selectInsurer,
      "component-blur": function componentBlur($event) {
        return _vm.$emit("insurer-component-blur");
      }
    },
    model: {
      value: _vm.innerInsurer,
      callback: function callback($$v) {
        _vm.innerInsurer = $$v;
      },
      expression: "innerInsurer"
    }
  }) : _vm._e(), _c("quote-booking", {
    attrs: {
      "is-saving": _vm.headerSavingPanels.booking,
      quote: _vm.innerValue,
      insurer: _vm.innerInsurer
    },
    on: {
      "update:quote": function updateQuote($event) {
        _vm.innerValue = $event;
      },
      "component-blur": function componentBlur($event) {
        return _vm.$emit("booking-component-blur");
      }
    },
    model: {
      value: _vm.innerQuoteCycleTime,
      callback: function callback($$v) {
        _vm.innerQuoteCycleTime = $$v;
      },
      expression: "innerQuoteCycleTime"
    }
  })], 1)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("bulma-autocomplete", {
    attrs: {
      placeholder: _vm.placeholder,
      data: _vm.items,
      loading: false,
      field: "assessorName",
      disabled: _vm.disabled
    },
    on: {
      input: _vm.getAssessorList,
      search: _vm.getAssessorList,
      select: _vm.select
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        var _props$option;
        return [_c("div", {
          staticClass: "is-flex is-justify-content-space-between is-align-items-center"
        }, [_c("div", [_c("div", {
          staticClass: "is-flex is-align-items-center"
        }, [_c("span", {
          staticClass: "icon is-small"
        }, [_c("i", {
          staticClass: "mdi mdi-account mdi-18px"
        })]), _c("span", {
          staticClass: "pl-1"
        }, [_vm._v(_vm._s(props.option.assessorName || "no name"))])]), _c("div", {
          staticClass: "is-flex is-align-items-center"
        }, [_c("span", {
          staticClass: "icon is-small"
        }, [_c("i", {
          staticClass: "mdi mdi-phone mdi-14px"
        })]), _c("span", {
          staticClass: "is-size-7 has-text-grey-light pl-1"
        }, [_vm._v(_vm._s((props === null || props === void 0 || (_props$option = props.option) === null || _props$option === void 0 ? void 0 : _props$option.assessorPhoneNo) || "-"))])])]), _c("div", {
          staticClass: "is-pulled-right"
        }, [props.option.source ? _c("span", {
          staticClass: "tag",
          class: {
            "is-success": props.option.source === "Customer",
            "is-info": props.option.source === "Insurer",
            "is-light": props.option.source === "Assessor"
          }
        }, [_vm._v(" " + _vm._s(props.option.source) + " ")]) : _vm._e()])])];
      }
    }]),
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  });
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Address")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("span", {
    staticClass: "select custom-select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.address.type,
      expression: "address.type"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.address, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.addressTypes, function (a, addressType) {
    return _c("option", {
      key: a,
      attrs: {
        title: a
      },
      domProps: {
        value: addressType
      }
    }, [_vm._v(" " + _vm._s(Array.from(a)[0]) + " ")]);
  }), 0)])]), _c("div", {
    staticClass: "control is-expanded"
  }, [_c("bulma-autocomplete", {
    attrs: {
      id: _vm.id + "_address",
      placeholder: "Start typing address",
      data: _vm.addresses.data,
      field: "street",
      loading: _vm.addresses.loading
    },
    on: {
      input: function input($event) {
        return _vm.searchAddress(_vm.address, $event);
      },
      select: function select($event) {
        return _vm.pickAddress(_vm.address, $event);
      }
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_c("span", {
          staticClass: "icon is-small"
        }, [_c("i", {
          staticClass: "mdi mdi-map-marker"
        })]), _vm._v(" " + _vm._s("".concat(props.option.street, ", ").concat(props.option.secondary_text)) + " ")])];
      }
    }]),
    model: {
      value: _vm.address.address1,
      callback: function callback($$v) {
        _vm.$set(_vm.address, "address1", $$v);
      },
      expression: "address.address1"
    }
  })], 1)])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Suburb")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.address.suburbText,
      expression: "address.suburbText"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Suburb"
    },
    domProps: {
      value: _vm.address.suburbText
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.address, "suburbText", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("State")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.address.stateCode,
      expression: "address.stateCode"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "State"
    },
    domProps: {
      value: _vm.address.stateCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.address, "stateCode", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Postal code")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.address.suburbPostcode,
      expression: "address.suburbPostcode"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Postal code"
    },
    domProps: {
      value: _vm.address.suburbPostcode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.address, "suburbPostcode", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Country")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.address.countryText,
      expression: "address.countryText"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Country"
    },
    domProps: {
      value: _vm.address.countryText
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.address, "countryText", $event.target.value);
      }
    }
  })])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "cell is-col-span-1 is-flex",
    staticStyle: {
      position: "relative"
    },
    attrs: {
      inert: _vm.isSaving
    },
    on: {
      focusout: _vm.onComponentFocusOut
    }
  }, [_vm.isSaving ? _c("div", {
    staticClass: "quote-item-saving-overlay"
  }) : _vm._e(), _c("article", {
    staticClass: "box is-flex-grow-1 main-container"
  }, [_vm._m(0), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Request for Quote Date")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerQuote.quoteDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Quote Date"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerQuoteDate,
      callback: function callback($$v) {
        _vm.innerQuoteDate = $$v;
      },
      expression: "innerQuoteDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Inspection Booking")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.inspectionBookingDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    ref: "datepicker",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerInspectionBookingDate ? {} : _vm.modelConfig,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref2) {
        var inputValue = _ref2.inputValue,
          inputEvents = _ref2.inputEvents;
        return [_c("div", {
          staticClass: "field is-fullwidth"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Inspection Start Date",
            disabled: _vm.isRepx || _vm.innerQuote.isArriveForInspection
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerInspectionBookingDate,
      callback: function callback($$v) {
        _vm.innerInspectionBookingDate = $$v;
      },
      expression: "innerInspectionBookingDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Booking Attended")]), _c("div", {
    staticClass: "control"
  }, [_c("label", [_vm._v(_vm._s(_vm.innerQuote.isArriveForInspection ? "Yes" : "No"))])])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Sent for Authority")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.sentForAuthorizationDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerSentForAuthorizationDate ? {} : _vm.modelConfig,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref3) {
        var inputValue = _ref3.inputValue,
          inputEvents = _ref3.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Sent for Assessment"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerSentForAuthorizationDate,
      callback: function callback($$v) {
        _vm.innerSentForAuthorizationDate = $$v;
      },
      expression: "innerSentForAuthorizationDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Authority Date")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerQuote.authorisedDate, _vm.$userInfo.locale)
    }
  }) : _vm._e(), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref4) {
        var inputValue = _ref4.inputValue,
          inputEvents = _ref4.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Authority Date"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerAuthorityDate,
      callback: function callback($$v) {
        _vm.innerAuthorityDate = $$v;
      },
      expression: "innerAuthorityDate"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_vm.innerQuote.isRepairBooked == null || _vm.innerQuote.isRepairBooked != null && _vm.innerQuote.isRepairBooked ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label",
    class: {
      "is-disabled": _vm.innerQuote.isRepairBooked == null
    }
  }, [_vm._v(" Repair Booked Date ")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.repairBookedDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    ref: "datepicker",
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerRepairBookedDate ? {} : _vm.modelConfig,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref5) {
        var inputValue = _ref5.inputValue,
          inputEvents = _ref5.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Repair Booked Date",
            disabled: _vm.innerQuote.isRepairBooked == null
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates",
            disabled: _vm.innerQuote.isRepairBooked == null
          },
          on: {
            click: function click($event) {
              return _vm.clearRepairBookedDate();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])];
      }
    }], null, false, 2965345974),
    model: {
      value: _vm.innerRepairBookedDate,
      callback: function callback($$v) {
        _vm.innerRepairBookedDate = $$v;
      },
      expression: "innerRepairBookedDate"
    }
  })], 1) : _vm._e(), _vm.innerQuote.isRepairBooked != null && !_vm.innerQuote.isRepairBooked ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Refuse Book Repair Reason")]), _c("div", {
    staticClass: "control is-expanded"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.refuseBookRepairReason,
      expression: "innerQuote.refuseBookRepairReason"
    }],
    staticClass: "input is-fullwidth",
    class: {
      "is-invalid": _vm.$v.entity.refuseBookRepairReason.$error
    },
    domProps: {
      value: _vm.innerQuote.refuseBookRepairReason
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerQuote, "refuseBookRepairReason", $event.target.value);
      }
    }
  }), _vm.$v.entity && !_vm.$v.entity.refuseBookRepairReason.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Refuse Book Repair Reason is required")]) : _vm._e()])]) : _vm._e()]), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Is Repair Booked")]), _c("div", [_c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.isRepairBooked,
      expression: "innerQuote.isRepairBooked"
    }],
    attrs: {
      id: "chk-pretty-is-repair-booked-yes",
      name: "chk-pretty-is-repair-booked",
      type: "radio"
    },
    domProps: {
      value: true,
      checked: _vm._q(_vm.innerQuote.isRepairBooked, true)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerQuote, "isRepairBooked", true);
      }
    }
  }), _vm._m(1)]), _c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.isRepairBooked,
      expression: "innerQuote.isRepairBooked"
    }],
    attrs: {
      id: "chk-pretty-is-repair-booked-no",
      name: "chk-pretty-is-repair-booked",
      type: "radio"
    },
    domProps: {
      value: false,
      checked: _vm._q(_vm.innerQuote.isRepairBooked, false)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerQuote, "isRepairBooked", false);
      }
    }
  }), _vm._m(2)])])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Estimated Start Date")]), _vm.readOnlyView || _vm.isRepairStartDateSynced ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateTimeLocale(_vm.innerQuote.jobStart, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerJobStartDate ? {} : _vm.modelConfig,
      "max-date": _vm.innerJobEndDate,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref6) {
        var inputValue = _ref6.inputValue,
          inputEvents = _ref6.inputEvents;
        return [_c("div", {
          staticClass: "field is-fullwidth"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          directives: [{
            name: "tippy",
            rawName: "v-tippy",
            value: {
              theme: "danger",
              enabled: _vm.$v.entity.jobStart.$error
            },
            expression: "{ theme: 'danger', enabled: $v.entity.jobStart.$error }"
          }],
          staticClass: "input",
          class: {
            "is-invalid": _vm.$v.entity.jobStart.$error
          },
          attrs: {
            type: "text",
            placeholder: "Job Start Date",
            content: _vm.ormEstimateStartEndValidationText
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerJobStartDate,
      callback: function callback($$v) {
        _vm.innerJobStartDate = $$v;
      },
      expression: "innerJobStartDate"
    }
  }), _vm.isRepx ? _c("span", {
    staticClass: "help is-info"
  }, [_vm._v("Once the Start Date is synced, it cannot be updated.")]) : _vm._e()], 1)]), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Estimated End Date")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerQuote.jobEnd, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerJobEndDate ? {} : _vm.modelConfig,
      "min-date": _vm.innerJobStartDate,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref7) {
        var inputValue = _ref7.inputValue,
          inputEvents = _ref7.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          directives: [{
            name: "tippy",
            rawName: "v-tippy",
            value: {
              theme: "danger",
              enabled: _vm.$v.entity.jobEnd.$error
            },
            expression: "{ theme: 'danger', enabled: $v.entity.jobEnd.$error }"
          }],
          staticClass: "input",
          class: {
            "is-invalid": _vm.$v.entity.jobEnd.$error
          },
          attrs: {
            type: "text",
            placeholder: "Job End Date",
            content: _vm.ormEstimateStartEndValidationText
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates"
          },
          on: {
            click: function click($event) {
              return _vm.resetJobStartEnd();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])];
      }
    }]),
    model: {
      value: _vm.innerJobEndDate,
      callback: function callback($$v) {
        _vm.innerJobEndDate = $$v;
      },
      expression: "innerJobEndDate"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vehicle Arrived")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.arrivedForRepairDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    ref: "datepicker",
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerArrivedForRepairDate ? {} : _vm.modelConfig,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref8) {
        var inputValue = _ref8.inputValue,
          inputEvents = _ref8.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Arrive for Repair Date"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates"
          },
          on: {
            click: function click($event) {
              return _vm.clearArrivedForRepairDate();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])];
      }
    }]),
    model: {
      value: _vm.innerArrivedForRepairDate,
      callback: function callback($$v) {
        _vm.innerArrivedForRepairDate = $$v;
      },
      expression: "innerArrivedForRepairDate"
    }
  })], 1), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vehicle On Site")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: !!_vm.isArrived
    },
    on: {
      change: _vm.isArrivedOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.isArrived ? "Yes" : "No"))])])])])])])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Job Start Date")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.actualJobStart, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerActualJobStart ? {} : _vm.modelConfig,
      "max-date": _vm.jobCompletionDateTime,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref9) {
        var inputValue = _ref9.inputValue,
          inputEvents = _ref9.inputEvents;
        return [_c("div", {
          staticClass: "field is-fullwidth"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Job Start",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.innerActualJobStart,
      callback: function callback($$v) {
        _vm.innerActualJobStart = $$v;
      },
      expression: "innerActualJobStart"
    }
  })], 1), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Job Completed Date")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.actualJobEnd, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerActualJobEnd ? {} : _vm.modelConfig,
      "min-date": _vm.innerActualJobStart,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref0) {
        var inputValue = _ref0.inputValue,
          inputEvents = _ref0.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Job Completion"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates"
          },
          on: {
            click: function click($event) {
              return _vm.resetActualJobStartAndEnd();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])];
      }
    }]),
    model: {
      value: _vm.innerActualJobEnd,
      callback: function callback($$v) {
        _vm.innerActualJobEnd = $$v;
      },
      expression: "innerActualJobEnd"
    }
  })], 1)])]), _c("div", {
    staticClass: "field is-horizontal"
  }, [_c("div", {
    staticClass: "field-body columns"
  }, [_c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vehicle Picked Up")]), _vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateLocale(_vm.innerValue.vehicleDepartedDate, _vm.$userInfo.locale)
    }
  }) : _c("v-date-picker", {
    ref: "datepickerVehicleDeparted",
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      mode: "dateTime",
      "minute-increment": 5,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "model-config": _vm.innerVehicleDepartedDate ? {} : _vm.modelConfig,
      "min-date": _vm.innerValue.arrivedForRepairDate,
      timezone: _vm.$filters.getIanaTimezone()
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref1) {
        var inputValue = _ref1.inputValue,
          inputEvents = _ref1.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Vehicle Departed Date"
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])]), _c("div", {
          staticClass: "control"
        }, [_c("a", {
          staticClass: "button tooltip",
          attrs: {
            "data-tooltip": "Reset dates"
          },
          on: {
            click: function click($event) {
              return _vm.clearVehicleDepartedDate();
            }
          }
        }, [_c("span", {
          staticClass: "icon"
        }, [_c("i", {
          staticClass: "mdi mdi-close mdi-24px"
        })])])])])];
      }
    }]),
    model: {
      value: _vm.innerVehicleDepartedDate,
      callback: function callback($$v) {
        _vm.innerVehicleDepartedDate = $$v;
      },
      expression: "innerVehicleDepartedDate"
    }
  })], 1), _c("div", {
    staticClass: "field column mr-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Vehicle Departed")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: !!_vm.isDeparted
    },
    on: {
      change: _vm.isDepartedOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.isDeparted ? "Yes" : "No"))])])])])])])])]), _vm.isRepairLateReasonActive ? _c("late-reason-modal", {
    attrs: {
      active: _vm.isRepairLateReasonActive,
      "show-icon": true,
      "cancel-disabled": false
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isRepairLateReasonActive = $event;
      },
      saveContinue: function saveContinue($event) {
        return _vm.handleRepairLateReasonClose();
      },
      close: function close($event) {
        return _vm.handleRepairLateReasonClose();
      }
    },
    model: {
      value: _vm.innerValue,
      callback: function callback($$v) {
        _vm.innerValue = $$v;
      },
      expression: "innerValue"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Late Reason")])]) : _vm._e()], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns mb-0"
  }, [_c("div", {
    staticClass: "column is-flex is-align-items-center"
  }, [_c("span", {
    staticClass: "mso mso-24px mr-2"
  }, [_vm._v("calendar_clock")]), _c("p", {
    staticClass: "title pl-1"
  }, [_vm._v("Key Dates")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Yes")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("No")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_8__);









var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.value ? _c("div", {
    staticClass: "cell is-col-span-1 is-flex",
    staticStyle: {
      position: "relative"
    },
    attrs: {
      inert: _vm.isSaving
    },
    on: {
      focusout: _vm.onComponentFocusOut
    }
  }, [_vm.isSaving ? _c("div", {
    staticClass: "quote-item-saving-overlay"
  }) : _vm._e(), _c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns mb-0"
  }, [_c("div", {
    staticClass: "column is-flex is-align-items-center",
    staticStyle: {
      position: "relative"
    }
  }, [_c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isNewCustomerPrompt,
      expression: "isNewCustomerPrompt"
    }],
    staticClass: "icon is-synced-icon",
    class: ["has-text-warning"]
  }, [_c("i", {
    staticClass: "mdi mdi-circle-medium"
  })]), _c("i", {
    staticClass: "icon mdi mdi-account-outline mdi-24px"
  }), _c("p", {
    staticClass: "title pl-1"
  }, [_vm._v("Customer "), _vm.innerCustomer.isNew ? _c("span", {
    staticClass: "has-badge-rounded has-badge-small has-badge-info",
    attrs: {
      "data-badge": "New"
    }
  }) : _vm._e()])]), _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end"
  }, [_c("div", [_c("div", {
    staticClass: "pretty p-default p-round p-smooth is-size-7"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerCustomer.isPerson,
      expression: "innerCustomer.isPerson"
    }],
    attrs: {
      id: "chk-pretty-customer-type",
      name: "chk-pretty-customer-type",
      type: "radio"
    },
    domProps: {
      value: false,
      checked: _vm._q(_vm.innerCustomer.isPerson, false)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerCustomer, "isPerson", false);
      }
    }
  }), _vm._m(0)]), _c("div", {
    staticClass: "pretty p-default p-round p-smooth is-size-7"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerCustomer.isPerson,
      expression: "innerCustomer.isPerson"
    }],
    attrs: {
      id: "chk-pretty-customer-type",
      name: "chk-pretty-customer-type",
      type: "radio"
    },
    domProps: {
      value: true,
      checked: _vm._q(_vm.innerCustomer.isPerson, true)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.innerCustomer, "isPerson", true);
      }
    }
  }), _vm._m(1)])])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [!_vm.innerCustomer.isPerson ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Company Name")]), _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      data: _vm.filteredCustomers,
      field: "companyName",
      loading: _vm.isSearchingCustomer,
      expanded: true,
      "open-on-focus": _vm.innerCustomer.isNew,
      "class-prop": !_vm.$v.customer.companyName.$error ? "is-required-field" : "is-invalid",
      placeholder: "Company Name"
    },
    on: {
      input: function input($event) {
        return _vm.searchCustomer("companyName");
      },
      select: _vm.selectCustomer
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_vm._v(_vm._s(props.option.value))]), _c("div", {
          staticClass: "help is-primary"
        }, [_c("span", {
          staticClass: "pr-1"
        }, [_c("i", {
          staticClass: "mdi mdi-phone mdi-12px"
        })]), _c("span", [_vm._v(_vm._s(props.option.phoneNo))])])];
      }
    }], null, false, 2724649755),
    model: {
      value: _vm.innerCustomer.companyName,
      callback: function callback($$v) {
        _vm.$set(_vm.innerCustomer, "companyName", $$v);
      },
      expression: "innerCustomer.companyName"
    }
  }), _vm.$v.customer.companyName.$error && !_vm.$v.customer.companyName.ormMaxLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v(_vm._s(_vm.ormMessages.companyName.ormMaxLength))]) : _vm.$v.customer.companyName.$error && (!_vm.$v.customer.companyName.required || !_vm.$v.customer.companyName.isNotWhitespaceOnly) ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Company Name is required")]) : _vm._e()], 1)]) : _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("First Name")]), _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      data: _vm.filteredCustomers,
      field: "firstname",
      loading: _vm.isSearchingCustomer,
      expanded: true,
      "open-on-focus": _vm.innerCustomer.isNew,
      maxlength: 120,
      "class-prop": !_vm.$v.customer.firstname.$error ? "is-required-field" : "is-invalid",
      placeholder: "First Name"
    },
    on: {
      input: function input($event) {
        return _vm.searchCustomer("firstname");
      },
      select: _vm.selectCustomer
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_vm._v(_vm._s(props.option.value))]), _c("div", {
          staticClass: "help is-primary"
        }, [_c("span", {
          staticClass: "pr-1"
        }, [_c("i", {
          staticClass: "mdi mdi-phone mdi-12px"
        })]), _c("span", [_vm._v(_vm._s(props.option.phoneNo))])])];
      }
    }], null, false, 2724649755),
    model: {
      value: _vm.innerCustomer.firstname,
      callback: function callback($$v) {
        _vm.$set(_vm.innerCustomer, "firstname", $$v);
      },
      expression: "innerCustomer.firstname"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Last Name")]), _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      data: _vm.filteredCustomers,
      field: "lastname",
      loading: _vm.isSearchingCustomer,
      expanded: true,
      "open-on-focus": _vm.innerCustomer.isNew,
      maxlength: 120,
      "class-prop": !_vm.$v.customer.lastname.$error ? "is-required-field" : "is-invalid",
      placeholder: "Last Name"
    },
    on: {
      input: function input($event) {
        return _vm.searchCustomer("lastname");
      },
      select: _vm.selectCustomer
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_vm._v(_vm._s(props.option.value))]), _c("div", {
          staticClass: "help is-primary"
        }, [_c("span", {
          staticClass: "pr-1"
        }, [_c("i", {
          staticClass: "mdi mdi-phone mdi-12px"
        })]), _c("span", [_vm._v(_vm._s(props.option.phoneNo))])])];
      }
    }], null, false, 2724649755),
    model: {
      value: _vm.innerCustomer.lastname,
      callback: function callback($$v) {
        _vm.$set(_vm.innerCustomer, "lastname", $$v);
      },
      expression: "innerCustomer.lastname"
    }
  })], 1)])])]), _c("transition", {
    attrs: {
      name: "custom-classes-transition",
      "enter-active-class": "animate__animated animate__fadeIn animate__faster",
      "leave-active-class": "animate__animated animate__fadeOut animate__faster"
    }
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$showMoreCustomer,
      expression: "$showMoreCustomer"
    }]
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Emails")]), _c("div", [_c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.activeEmails.length < 2,
      expression: "activeEmails.length < 2"
    }],
    staticClass: "button is-small is-primary is-light tooltip p-0",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      "data-tooltip": "Add Email"
    },
    on: {
      click: _vm.addEmail
    }
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("add")])])])]), _vm._l(_vm.activeEmails, function (email, index) {
    return _c("div", {
      key: index,
      staticClass: "field"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select custom-select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: email.type,
        expression: "email.type"
      }],
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(email, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.emailTypes, function (emailType, p) {
      return _c("option", {
        key: p,
        attrs: {
          title: p
        },
        domProps: {
          value: emailType
        }
      }, [_vm._v(" " + _vm._s(Array.from(p)[0]) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded has-icons-right"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: email.address,
        expression: "email.address"
      }, {
        name: "focus-inserted",
        rawName: "v-focus-inserted",
        value: {
          focus: email.isNew
        },
        expression: "{ focus: email.isNew }"
      }],
      staticClass: "input",
      class: [!_vm.$v.customer.emails.$each[index].address.email ? "is-invalid" : ""],
      attrs: {
        type: "email",
        placeholder: "Email"
      },
      domProps: {
        value: email.address
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(email, "address", $event.target.value);
        }
      }
    }), _c("span", {
      staticClass: "icon is-right cursor-pointer",
      class: [email.isDefault ? "has-text-gold" : "has-text-grey-light"],
      on: {
        click: function click($event) {
          return _vm.setDefaultEmail(index);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-star mdi-24px"
    })])]), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      on: {
        click: function click($event) {
          return _vm.deleteEmail(email, index);
        }
      }
    }, [_c("i", {
      staticClass: "icon mdi mdi-minus mdi-24px"
    })])])])]);
  })], 2), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Phones")]), _c("div", [_c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.activePhones.length < 3,
      expression: "activePhones.length < 3"
    }],
    staticClass: "button is-small is-primary is-light p-0",
    class: "is-light-btn-".concat(_vm.$theme.name),
    on: {
      click: _vm.addPhone
    }
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("add")])])])]), _vm._l(_vm.activePhones, function (phone, index) {
    return _c("div", {
      key: index,
      staticClass: "field"
    }, [_c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select custom-select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: phone.type,
        expression: "phone.type"
      }],
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(phone, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.phoneTypes, function (phoneType, p) {
      return _c("option", {
        key: p,
        attrs: {
          title: p
        },
        domProps: {
          value: phoneType
        }
      }, [_vm._v(" " + _vm._s(Array.from(p)[0]) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded has-icons-right"
    }, [_c("the-mask", {
      directives: [{
        name: "focus-inserted",
        rawName: "v-focus-inserted",
        value: {
          focus: phone.isNew
        },
        expression: "{ focus: phone.isNew}"
      }],
      staticClass: "input",
      attrs: {
        mask: _vm.phoneNoMask,
        tokens: _vm.phoneNoTokens,
        placeholder: "Phone"
      },
      model: {
        value: phone.no,
        callback: function callback($$v) {
          _vm.$set(phone, "no", $$v);
        },
        expression: "phone.no"
      }
    }), _c("span", {
      staticClass: "icon is-right cursor-pointer",
      class: [phone.isDefault ? "has-text-gold" : "has-text-grey-light"],
      on: {
        click: function click($event) {
          return _vm.setDefaultPhone(index);
        }
      }
    }, [_c("i", {
      staticClass: "mdi mdi-star mdi-24px"
    })])], 1), _c("div", {
      staticClass: "control"
    }, [_c("button", {
      staticClass: "button has-text-danger",
      on: {
        click: function click($event) {
          return _vm.deletePhone(phone, index);
        }
      }
    }, [_c("i", {
      staticClass: "icon mdi mdi-minus mdi-24px"
    })])])])]);
  })], 2), _c("div", {
    staticClass: "field alt-contact-section"
  }, [!_vm.innerCustomerAltContact ? [_c("div", {
    staticClass: "is-flex is-justify-content-space-between is-align-items-center"
  }, [_c("label", {
    staticClass: "label mb-0"
  }, [_vm._v("Alternative Customer Contact")]), _c("button", {
    staticClass: "button is-small is-primary is-light tooltip p-0",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      "data-tooltip": "Add Alternative Contact"
    },
    on: {
      click: _vm.addAltContact
    }
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("add")])])])] : [_c("div", {
    staticClass: "is-flex is-justify-content-space-between is-align-items-center"
  }, [_c("label", {
    staticClass: "label mb-0"
  }, [_vm._v("Alternative Customer Contact")]), _c("button", {
    staticClass: "button is-small is-danger is-light tooltip p-0",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      "data-tooltip": "Remove Alternative Contact"
    },
    on: {
      click: _vm.removeAltContact
    }
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("remove")])])]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("First Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerCustomerAltContact.contact.firstName,
      expression: "innerCustomerAltContact.contact.firstName"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.customer.contacts.$invalid && !_vm.innerCustomerAltContact.contact.firstName
    },
    attrs: {
      type: "text",
      maxlength: 120,
      placeholder: "First Name"
    },
    domProps: {
      value: _vm.innerCustomerAltContact.contact.firstName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerCustomerAltContact.contact, "firstName", $event.target.value);
      }, function ($event) {
        _vm.innerCustomerAltContact.contact.firstName = $event.target.value.trim();
      }]
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Last Name")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerCustomerAltContact.contact.lastName,
      expression: "innerCustomerAltContact.contact.lastName"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.customer.contacts.$invalid && !_vm.innerCustomerAltContact.contact.lastName
    },
    attrs: {
      type: "text",
      maxlength: 120,
      placeholder: "Last Name"
    },
    domProps: {
      value: _vm.innerCustomerAltContact.contact.lastName
    },
    on: {
      input: [function ($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerCustomerAltContact.contact, "lastName", $event.target.value);
      }, function ($event) {
        _vm.innerCustomerAltContact.contact.lastName = $event.target.value.trim();
      }]
    }
  })])])]), _vm._l(_vm.innerCustomerAltContact.contact.phones, function (phone, index) {
    return _c("div", {
      key: index,
      staticClass: "field mt-2"
    }, [phone.isDefault && !phone.isDeleted ? _c("div", {
      staticClass: "field has-addons"
    }, [_c("div", {
      staticClass: "control"
    }, [_c("span", {
      staticClass: "select custom-select"
    }, [_c("select", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: phone.type,
        expression: "phone.type"
      }],
      on: {
        change: function change($event) {
          var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
            return o.selected;
          }).map(function (o) {
            var val = "_value" in o ? o._value : o.value;
            return val;
          });
          _vm.$set(phone, "type", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
        }
      }
    }, _vm._l(_vm.phoneTypes, function (phoneType, p) {
      return _c("option", {
        key: p,
        attrs: {
          title: p
        },
        domProps: {
          value: phoneType
        }
      }, [_vm._v(" " + _vm._s(Array.from(p)[0]) + " ")]);
    }), 0)])]), _c("div", {
      staticClass: "control is-expanded has-icons-right"
    }, [_c("the-mask", {
      directives: [{
        name: "focus-inserted",
        rawName: "v-focus-inserted",
        value: {
          focus: phone.isNew
        },
        expression: "{ focus: phone.isNew}"
      }],
      staticClass: "input",
      attrs: {
        mask: _vm.phoneNoMask,
        tokens: _vm.phoneNoTokens,
        placeholder: "Phone"
      },
      model: {
        value: phone.no,
        callback: function callback($$v) {
          _vm.$set(phone, "no", $$v);
        },
        expression: "phone.no"
      }
    })], 1)]) : _vm._e()]);
  })]], 2), _c("customer-address-input", {
    ref: "addressInput",
    model: {
      value: _vm.defaultAddress,
      callback: function callback($$v) {
        _vm.defaultAddress = $$v;
      },
      expression: "defaultAddress"
    }
  })], 1)])], 1)]) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", {
    staticClass: "is-size-7"
  }, [_vm._v("Company")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", {
    staticClass: "is-size-7"
  }, [_vm._v("Person")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);









var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.value ? _c("div", {
    staticClass: "quote-insurer is-flex cell is-col-span-1",
    staticStyle: {
      position: "relative"
    },
    attrs: {
      inert: _vm.isSaving
    },
    on: {
      focusout: _vm.onComponentFocusOut
    }
  }, [_vm.isSaving ? _c("div", {
    staticClass: "quote-item-saving-overlay"
  }) : _vm._e(), _c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_vm._m(0), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Insurer")]), _c("div", {
    staticClass: "control",
    attrs: {
      title: _vm.isAdditionalQuote ? "Insurer can only be changed on the main quote" : ""
    }
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.quoteInsurer ? _vm.quoteInsurer.name : ""
    }
  }) : !_vm.readOnlyView && _vm.insurers ? _c("multiselect", {
    class: [_vm.$v.insurer.insurerId.$error || _vm.$v.insurer.name.$error ? "is-invalid" : "is-required-field"],
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Search By Name...",
      options: _vm.insurers,
      loading: _vm.isInsurerLoading,
      "internal-search": false,
      "options-limit": _vm.insurerFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": false,
      disabled: _vm.isInsurerDropdownDisabled
    },
    on: {
      select: _vm.selectInsurer,
      remove: _vm.removeInsurer,
      "search-change": _vm.getInsurerDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", [_vm._v(_vm._s(props.option.assetName))])];
      }
    }], null, false, 2645691248),
    model: {
      value: _vm.selectedInsurer,
      callback: function callback($$v) {
        _vm.selectedInsurer = $$v;
      },
      expression: "selectedInsurer"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Insurer not found.")])]) : _vm._e()], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ABN")]), _c("div", {
    staticClass: "control has-icons-right"
  }, [_c("the-mask", {
    staticClass: "input",
    class: {
      "is-danger": _vm.$v.insurer.abn.$error
    },
    attrs: {
      type: "text",
      placeholder: "ABN",
      mask: ["## ### ### ###"],
      disabled: ""
    },
    nativeOn: {
      input: function input($event) {
        return _vm.$v.insurer.abn.$touch();
      }
    },
    model: {
      value: _vm.innerInsurer.abn,
      callback: function callback($$v) {
        _vm.$set(_vm.innerInsurer, "abn", $$v);
      },
      expression: "innerInsurer.abn"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Claim Number")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.claimNo,
      expression: "innerQuote.claimNo"
    }, {
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.entity.claimNo.$error
      },
      expression: "{ theme: 'danger', enabled: $v.entity.claimNo.$error }"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.entity.claimNo.$error
    },
    attrs: {
      content: _vm.claimNoValidationText,
      type: "text",
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock || _vm.isAdditionalQuote,
      placeholder: "Claim Number"
    },
    domProps: {
      value: _vm.innerQuote.claimNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerQuote, "claimNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Policy Number")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.policyNo,
      expression: "innerQuote.policyNo"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Policy No."
    },
    domProps: {
      value: _vm.innerQuote.policyNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerQuote, "policyNo", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-expanded"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Labour Times")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.innerQuote.labourType
    }
  }) : _c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.labourType,
      expression: "innerQuote.labourType"
    }],
    attrs: {
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerQuote, "labourType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.labourTimesTypeEnum, function (labourType, propertyName, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: propertyName
      }
    }, [_vm._v(" " + _vm._s(labourType) + " ")]);
  }), 0)])])]), _c("div", {
    staticClass: "field is-expanded"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Method")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "buttons has-addons is-fullwidth"
  }, [_c("button", {
    staticClass: "button",
    class: {
      "has-text-weight-semibold has-text-primary is-selected": _vm.innerQuote.quotingMethod === _vm.quotingMethodTypes.Hour
    },
    attrs: {
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock || _vm.quote.quoteAssessments && _vm.quote.quoteAssessments.length > 0
    },
    on: {
      click: function click($event) {
        _vm.innerQuote.quotingMethod = _vm.quotingMethodTypes.Hour;
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "icon mdi mdi-clock-outline mdi-20px",
    class: {
      "has-text-weight-bold has-text-primary": _vm.innerQuote.quotingMethod === _vm.quotingMethodTypes.Hour
    }
  })]), _c("span", [_vm._v("Hours")])]), _c("button", {
    staticClass: "button",
    class: {
      "has-text-weight-semibold has-text-primary is-selected": _vm.innerQuote.quotingMethod === _vm.quotingMethodTypes.Dollar
    },
    attrs: {
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock || _vm.quote.quoteAssessments && _vm.quote.quoteAssessments.length > 0
    },
    on: {
      click: function click($event) {
        _vm.innerQuote.quotingMethod = _vm.quotingMethodTypes.Dollar;
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "icon mdi mdi-cash-multiple mdi-20px",
    class: {
      "has-text-weight-bold has-text-primary": _vm.innerQuote.quotingMethod === _vm.quotingMethodTypes.Dollar
    }
  })]), _c("span", [_vm._v("Dollars")])])])])])])]), false ? undefined : _vm._e(), false ? undefined : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess")]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pr-1 is-size-7",
    class: {
      "pretty-checkbox-label": !_vm.disableExcessIncludesGST
    }
  }, [_vm._v("Includes GST")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0 is-size-7"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.excessWithGst,
      expression: "innerQuote.excessWithGst"
    }],
    attrs: {
      id: "chk-excessWithGst",
      type: "checkbox",
      disabled: _vm.disableExcessIncludesGST
    },
    domProps: {
      checked: Array.isArray(_vm.innerQuote.excessWithGst) ? _vm._i(_vm.innerQuote.excessWithGst, null) > -1 : _vm.innerQuote.excessWithGst
    },
    on: {
      change: function change($event) {
        var $$a = _vm.innerQuote.excessWithGst,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.innerQuote, "excessWithGst", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.innerQuote, "excessWithGst", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.innerQuote, "excessWithGst", $$c);
        }
      }
    }
  }), _vm._m(1)])])]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.excess, _vm.$userInfo.locale)
    }
  }) : _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Excess",
      precision: 2,
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock || _vm.innerQuote.subQuoteNo > 0 || _vm.hasInvoice
    },
    on: {
      blur: function blur($event) {
        return _vm.calculateExcess();
      }
    },
    model: {
      value: _vm.excess,
      callback: function callback($$v) {
        _vm.excess = $$v;
      },
      expression: "excess"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Owners Contribution")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.innerQuote.ownersContribution, _vm.$userInfo.locale)
    }
  }) : _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Owner's Contribution",
      precision: 2,
      disabled: _vm.disableOwnerContribution
    },
    model: {
      value: _vm.innerQuote.ownersContribution,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "ownersContribution", $$v);
      },
      expression: "innerQuote.ownersContribution"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Discount On Invoice")]), _c("div", {
    staticClass: "control"
  }, [_vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatNumber(_vm.innerQuote.discount, _vm.$userInfo.locale)
    }
  })]) : _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      formats: "",
      placeholder: "Discount applied on invoice",
      precision: 2,
      symbol: _vm.$company.currency.symbol,
      disabled: _vm.innerQuote.readOnly || _vm.audanetLock || _vm.innerQuote.subQuoteNo > 0 || _vm.hasInvoice
    },
    model: {
      value: _vm.innerQuote.discount,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "discount", $$v);
      },
      expression: "innerQuote.discount"
    }
  })], 1)])])]), _c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.innerInsurer.damageSeverity,
      expression: "innerInsurer.damageSeverity"
    }],
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Damage Severity")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    class: {
      "is-invalid": _vm.$v.entity.damageSeverity.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.damageSeverity,
      expression: "innerQuote.damageSeverity"
    }],
    staticClass: "select-width",
    attrs: {
      disabled: _vm.innerQuote.readOnly
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerQuote, "damageSeverity", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.damageSeverityTypes, function (damageSeverityType, propertyName, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: damageSeverityType
      }
    }, [_vm._v(" " + _vm._s(_vm.getDamageSeverityDescription(propertyName)) + " ")]);
  }), 0)])])]), _c("div", {
    staticClass: "columns field"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Assessor")]), _c("div", {
    staticClass: "control"
  }, [_c("assessor-autocomplete", {
    attrs: {
      "quote-id": _vm.innerQuote.quoteId,
      disabled: _vm.readOnlyView
    },
    on: {
      select: _vm.handleSelectedAssessor
    },
    model: {
      value: _vm.innerQuote.assessorName,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "assessorName", $$v);
      },
      expression: "innerQuote.assessorName"
    }
  })], 1)])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Phone Number")]), _c("div", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    class: {
      "is-static": _vm.readOnlyView
    },
    attrs: {
      mask: _vm.phoneNoMask,
      tokens: _vm.phoneNoTokens,
      type: "text",
      placeholder: !_vm.readOnlyView ? "xxxxxxxxx" : "",
      disabled: _vm.readOnlyView
    },
    model: {
      value: _vm.innerQuote.assessorPhoneNo,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "assessorPhoneNo", $$v);
      },
      expression: "innerQuote.assessorPhoneNo"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Estimator")]), _vm.readOnlyView ? _c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static is-capitalized",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.innerQuote.quoter
    }
  })]) : _c("div", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    attrs: {
      placeholder: "Quoter",
      data: _vm.filteredQuoters,
      "keep-first": true,
      loading: false,
      "class-prop": _vm.$v.entity.quoter.$error ? "is-capitalized is-invalid" : "is-capitalized"
    },
    model: {
      value: _vm.innerQuote.quoter,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "quoter", $$v);
      },
      expression: "innerQuote.quoter"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_vm.includeClaimsType ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("multiselect", {
    attrs: {
      options: _vm.claimsTypes,
      "preserve-search": true,
      "track-by": "key",
      "internal-search": true,
      searchable: true,
      "show-labels": false,
      placeholder: "Select Claims type",
      label: "description",
      "allow-empty": true,
      disabled: _vm.$licenceExpired
    },
    on: {
      select: _vm.onClaimsTypeChange
    },
    model: {
      value: _vm.selectedClaimsType,
      callback: function callback($$v) {
        _vm.selectedClaimsType = $$v;
      },
      expression: "selectedClaimsType"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Claims type not found.")])])], 1)]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex mt-5",
    class: {
      "is-justify-content-space-between": _vm.innerInsurer.inScope,
      "is-justify-content-start": !_vm.innerInsurer.inScope
    }
  }, [_c("div", {
    staticClass: "mr-6"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Is Towed")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.isTowed,
      expression: "innerQuote.isTowed"
    }],
    attrs: {
      type: "checkbox"
    },
    domProps: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({
      checked: !!_vm.innerQuote.isTowed
    }, "checked", Array.isArray(_vm.innerQuote.isTowed) ? _vm._i(_vm.innerQuote.isTowed, null) > -1 : _vm.innerQuote.isTowed),
    on: {
      change: function change($event) {
        var $$a = _vm.innerQuote.isTowed,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.innerQuote, "isTowed", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.innerQuote, "isTowed", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.innerQuote, "isTowed", $$c);
        }
      }
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.innerQuote.isTowed ? "Yes" : "No"))])])])])]), _vm.$company.setting.driveable ? _c("div", {
    staticClass: "mr-6"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Driveable")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: !!_vm.innerQuote.driveable
    },
    on: {
      change: _vm.driveableOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.innerQuote.driveable ? "Yes" : "No"))])])])])]) : _vm._e(), _vm.innerInsurer.inScope ? _c("div", [_c("label", {
    staticClass: "label"
  }, [_vm._v("In Scope")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-switch p-fill"
  }, [_c("input", {
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: !!_vm.innerQuote.inScope
    },
    on: {
      change: _vm.inScopeOnChange
    }
  }), _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v(_vm._s(_vm.innerQuote.inScope ? "Yes" : "No"))])])])])]) : _vm._e()])])])]) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns mb-0"
  }, [_c("div", {
    staticClass: "column is-flex is-align-items-center"
  }, [_c("i", {
    staticClass: "icon mdi mdi-shield-outline mdi-24px"
  }), _c("p", {
    staticClass: "title pl-1"
  }, [_vm._v("Insurer/Debtor")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.value ? _c("div", {
    staticClass: "cell is-col-span-1 is-flex",
    staticStyle: {
      position: "relative"
    },
    attrs: {
      inert: _vm.isSaving
    },
    on: {
      focusout: _vm.onComponentFocusOut
    }
  }, [_vm.isSaving ? _c("div", {
    staticClass: "quote-item-saving-overlay"
  }) : _vm._e(), _c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns mb-0"
  }, [_vm._m(0), _vm.innerVehicle.model && (_vm.isOrm || _vm.isNtar) ? _c("div", [_c("div", {
    staticClass: "column is-flex is-justify-content-flex-end"
  }, [_vm.ntarLtarStatus ? _c("div", [_c("span", {
    staticClass: "tag is-success animate__animated animate__pulse animate__repeat-3 tooltip",
    attrs: {
      "data-tooltip": "".concat(_vm.ntarLtarStatus, " schedule and times found")
    }
  }, [_vm._v(_vm._s(_vm.ntarLtarStatus) + " Hours On - " + _vm._s(_vm.innerVehicle.model.scheduleId))])]) : _c("div", [_c("span", {
    staticClass: "tag is-danger animate__animated animate__pulse animate__repeat-3 tooltip",
    attrs: {
      "data-tooltip": "NTAR/LTAR  times not found"
    }
  }, [_vm._v("NTAR/LTAR Hours OFF")])])])]) : _vm._e(), _c("div", {
    staticClass: "is-flex is-justify-content-flex-end is-align-items-center pr-3"
  }, [_c("p", {
    staticClass: "mb-0 mr-1 label has-text-weight-normal"
  }, [_vm._v("Key No.")]), _c("span", [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerQuote.keyNo,
      expression: "innerQuote.keyNo"
    }],
    staticClass: "input input-box-keyno",
    attrs: {
      type: "text",
      maxlength: "4",
      disabled: _vm.readyOnlyForSubQuote,
      placeholder: "0000"
    },
    domProps: {
      value: _vm.innerQuote.keyNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerQuote, "keyNo", $event.target.value);
      }
    }
  })])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label",
    staticStyle: {
      "white-space": "nowrap"
    }
  }, [_vm._v("Registration No.")]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.vehicle.rego.$error && !_vm.$v.vehicle.rego.ormMaxLength
      },
      expression: "{ theme: 'danger', enabled: $v.vehicle.rego.$error && !$v.vehicle.rego.ormMaxLength }"
    }],
    staticClass: "control",
    attrs: {
      content: _vm.ormMessages.rego.ormMaxLength
    }
  }, [_c("bulma-autocomplete", {
    ref: "vehicleAutocomplete",
    attrs: {
      "class-prop": !_vm.$v.vehicle.rego.$error ? "is-uppercase is-required-field" : "is-uppercase is-invalid",
      value: _vm.innerVehicle.rego,
      data: _vm.vehicles,
      field: "rego",
      maxlength: _vm.regoMaxLength,
      loading: _vm.isSearchingVehicle,
      expanded: true,
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      input: _vm.searchVehicle,
      select: _vm.selectVehicle,
      onEnter: _vm.handleVehiclePickerEnter
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_vm._v(_vm._s(props.option.rego))]), _c("div", {
          staticClass: "help is-primary"
        }, [_vm._v(_vm._s(props.option.model))]), _c("div", {
          staticClass: "help is-primary"
        }, [_vm._v(_vm._s(props.option.ownersName))])];
      }
    }], null, false, 4206719517)
  })], 1)])]), _vm.$company.info.countryCode === "AU" ? _c("div", {
    staticClass: "field is-align-self-flex-end"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("State")]), _c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    staticStyle: {
      width: "100px"
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.stateRego,
      expression: "innerVehicle.stateRego"
    }],
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "stateRego", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.stateRegoTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: b
      }
    }, [_vm._v(_vm._s(a))]);
  })], 2)])])]) : _vm._e(), _vm.$company.info.countryCode === "AU" ? _c("div", {
    staticClass: "field is-flex-grow-0 is-align-self-flex-end"
  }, [_c("button", {
    staticClass: "button is-primary is-rounded",
    class: {
      tooltip: _vm.$licenceExpired
    },
    attrs: {
      disabled: _vm.readyOnlyForSubQuote || _vm.$licenceExpired,
      "data-tooltip": "Disabled, as your licence has expired"
    },
    on: {
      click: function click($event) {
        _vm.isVehicleLookupModalActive = true;
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Rego Lookup")])])]) : _vm._e()])]), false ? undefined : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Make / Model")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("bulma-autocomplete", {
    attrs: {
      "class-prop": !_vm.$v.vehicle.model.$error ? "is-required-field" : "is-invalid",
      value: _vm.makeModelText,
      data: _vm.filteredMakeModels,
      field: "name",
      disabled: _vm.readyOnlyForSubQuote,
      loading: _vm.isSearchingMakeModel,
      expanded: true
    },
    on: {
      input: _vm.searchMakeModel,
      select: _vm.selectMakeModel
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(props) {
        return [_c("div", [_vm._v(_vm._s(props.option.name))]), _c("div", {
          staticClass: "help is-primary"
        }, [_vm._v(_vm._s(props.option.cylinders) + " Cylinders")]), _c("div", {
          staticClass: "help is-primary"
        }, [_vm._v(_vm._s(props.option.production))])];
      }
    }], null, false, 2875817655)
  })], 1), _c("div", {
    staticClass: "control"
  }, [_vm.modelId === "" ? _c("button", {
    staticClass: "button has-text-success tooltip",
    attrs: {
      "data-tooltip": "Add unscheduled model",
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      click: _vm.addModel
    }
  }, [_vm._m(3)]) : _vm._e(), _vm.modelId !== "" && _vm.innerVehicle.model.isUnscheduled ? _c("button", {
    staticClass: "button has-text-primary tooltip",
    attrs: {
      "data-tooltip": "Edit unscheduled model",
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      click: _vm.checkMultipleModelCustomExists
    }
  }, [_vm._m(4)]) : _vm._e(), _vm.modelId !== "" && !_vm.innerVehicle.model.isUnscheduled ? _c("button", {
    staticClass: "button has-text-success tooltip",
    attrs: {
      "data-tooltip": "Create unscheduled model",
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      click: _vm.copyModel
    }
  }, [_vm._m(5)]) : _vm._e()])])]), _c("div", {
    staticClass: "field is-flex-grow-0 is-align-self-flex-end"
  }, [_c("div", [_c("button", {
    staticClass: "button is-primary is-light is-rounded",
    class: "is-light-btn-".concat(_vm.$theme.name),
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      click: function click($event) {
        _vm.isCarModelSearchModalActive = true;
      }
    }
  }, [_vm._m(6), _c("span", [_vm._v("Schedules")])])])])])]), _c("div", {
    staticClass: "columns field"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Body Style")]), _c("div", {
    staticClass: "control is-expanded"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    class: !_vm.$v.vehicle.bodyId.$error ? "is-required-field" : "is-invalid"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.bodyId,
      expression: "innerVehicle.bodyId"
    }],
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "bodyId", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, _vm.onChangeBodyStyle]
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.bodyStyles, function (s, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: s.id
      }
    }, [_vm._v(" " + _vm._s(s.name) + " ")]);
  })], 2)])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Body Style 2")]), _c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.vehicle.bodyId2.$error
      },
      expression: "{ theme: 'danger', enabled: $v.vehicle.bodyId2.$error}"
    }],
    staticClass: "select is-fullwidth",
    class: {
      "is-invalid": _vm.$v.vehicle.bodyId2.$error
    },
    attrs: {
      content: "Required by ORM."
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.bodyId2,
      expression: "innerVehicle.bodyId2"
    }],
    ref: "bodyId2",
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "bodyId2", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.bodyStyles2, function (s, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: s.id
      }
    }, [_vm._v(" " + _vm._s(s.name) + " ")]);
  })], 2)])])])])]), _c("div", {
    staticClass: "columns field"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Paint Group")]), _c("div", {
    class: {
      "is-flex": _vm.innerVehicle.paintGroup === _vm.paintGroupTypes.M3
    }
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    class: !_vm.$v.vehicle.paintGroup.$error ? "is-required-field" : "is-invalid"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.paintGroup,
      expression: "innerVehicle.paintGroup"
    }],
    ref: "paintGroup",
    staticClass: "control-min-width",
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: [function ($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "paintGroup", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }, function ($event) {
        return _vm.selectPaintGroup($event);
      }]
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.paintGroups, function (p, index) {
    return _c("option", {
      key: index,
      domProps: {
        value: p.key
      }
    }, [_vm._v(" " + _vm._s(p.value) + " ")]);
  })], 2)])]), _vm.innerVehicle.paintGroup === _vm.paintGroupTypes.M3 ? _c("div", {
    staticClass: "control is-flex is-align-items-center pl-4"
  }, [_c("div", {
    staticClass: "pretty p-icon p-curve p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.paintGroupPlus,
      expression: "innerVehicle.paintGroupPlus"
    }],
    attrs: {
      disabled: _vm.readyOnlyForSubQuote,
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.innerVehicle.paintGroupPlus) ? _vm._i(_vm.innerVehicle.paintGroupPlus, null) > -1 : _vm.innerVehicle.paintGroupPlus
    },
    on: {
      change: function change($event) {
        var $$a = _vm.innerVehicle.paintGroupPlus,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.innerVehicle, "paintGroupPlus", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.innerVehicle, "paintGroupPlus", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.innerVehicle, "paintGroupPlus", $$c);
        }
      }
    }
  }), _vm._m(7)])]) : _vm._e()])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Build Date")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.vehicle.buildMonth.$error
      },
      expression: "{ theme: 'danger', enabled: $v.vehicle.buildMonth.$error }"
    }],
    staticClass: "select",
    class: {
      "is-invalid": _vm.$v.vehicle.buildMonth.$error
    },
    attrs: {
      content: "Required by ORM."
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.buildMonth,
      expression: "innerVehicle.buildMonth"
    }],
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "buildMonth", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("MM")]), _vm._l(_vm.months, function (month, key) {
    return _c("option", {
      key: key,
      domProps: {
        value: key
      }
    }, [_vm._v(_vm._s(month))]);
  })], 2)])]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.vehicle.buildYear.$error
      },
      expression: "{ theme: 'danger', enabled: $v.vehicle.buildYear.$error }"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.vehicle.buildYear.$error
    },
    attrs: {
      placeholder: "Year",
      mask: ["####"],
      disabled: _vm.readyOnlyForSubQuote,
      content: "Required by ORM."
    },
    nativeOn: {
      blur: function blur($event) {
        return _vm.checkYear.apply(null, arguments);
      }
    },
    model: {
      value: _vm.innerVehicle.buildYear,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "buildYear", $$v);
      },
      expression: "innerVehicle.buildYear"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "columns field"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Transmission")]), _c("div", {
    staticClass: "control is-extended"
  }, [_c("div", {
    staticClass: "select is-fullwidth",
    class: {
      "is-invalid": _vm.$v.vehicle.transmissionType.$error
    }
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.transmissionType,
      expression: "innerVehicle.transmissionType"
    }],
    attrs: {
      disabled: _vm.readyOnlyForSubQuote
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerVehicle, "transmissionType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, [_c("option", {
    attrs: {
      value: "null",
      disabled: ""
    }
  }, [_vm._v("Select")]), _vm._l(_vm.transmissionTypes, function (a, b) {
    return _c("option", {
      key: b,
      domProps: {
        value: b
      }
    }, [_vm._v(_vm._s(a))]);
  })], 2)])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Colour")]), _c("p", {
    staticClass: "control"
  }, [_c("bulma-autocomplete", {
    staticClass: "is-capitalized control-min-width",
    attrs: {
      data: _vm.colours,
      expanded: true,
      disabled: _vm.readyOnlyForSubQuote,
      "class-prop": _vm.$v.vehicle.colour.$error ? "is-invalid" : "",
      maxlength: "20"
    },
    model: {
      value: _vm.innerVehicle.colour,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "colour", $$v);
      },
      expression: "innerVehicle.colour"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("VIN")]), _c("p", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input is-uppercase",
    attrs: {
      name: "vin",
      mask: _vm.vinMask,
      tokens: _vm.vinTokens,
      disabled: _vm.readyOnlyForSubQuote
    },
    model: {
      value: _vm.innerVehicle.vin,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "vin", $$v);
      },
      expression: "innerVehicle.vin"
    }
  })], 1), !_vm.$v.vehicle.vin.customMinLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Vin should have at least 7 characters")]) : _vm._e(), !_vm.$v.vehicle.vin.maxLength ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Vin max 17 characters")]) : _vm._e()]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Engine No.")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.engineNo,
      expression: "innerVehicle.engineNo"
    }],
    staticClass: "input",
    attrs: {
      disabled: _vm.readyOnlyForSubQuote,
      maxlength: "30",
      type: "text"
    },
    domProps: {
      value: _vm.innerVehicle.engineNo
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerVehicle, "engineNo", $event.target.value);
      }
    }
  })])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Odometer")]), _c("div", {
    staticClass: "control"
  }, [_c("the-mask", {
    directives: [{
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.entity.odometer.$error
      },
      expression: "{ theme: 'danger', enabled: $v.entity.odometer.$error }"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.entity.odometer.$error
    },
    attrs: {
      placeholder: "e.g. 6",
      disabled: _vm.readyOnlyForSubQuote,
      mask: ["##########"],
      content: "Required by ORM. Must be greater than 0 and less than 10,000,000."
    },
    model: {
      value: _vm.innerQuote.odometer,
      callback: function callback($$v) {
        _vm.$set(_vm.innerQuote, "odometer", $$v);
      },
      expression: "innerQuote.odometer"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Cylinders")]), _c("div", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 6",
      disabled: _vm.readyOnlyForSubQuote,
      mask: ["##"]
    },
    model: {
      value: _vm.innerVehicle.cylinders,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "cylinders", $$v);
      },
      expression: "innerVehicle.cylinders"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Engine Size")]), _c("div", {
    staticClass: "control"
  }, [_c("the-mask", {
    staticClass: "input",
    attrs: {
      placeholder: "e.g. 1300",
      mask: _vm.engineSizeMask,
      disabled: _vm.readyOnlyForSubQuote,
      tokens: _vm.engineSizeTokens
    },
    model: {
      value: _vm.innerVehicle.engineSize,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "engineSize", $$v);
      },
      expression: "innerVehicle.engineSize"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Trim Code")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.trimCode,
      expression: "innerVehicle.trimCode"
    }],
    staticClass: "input",
    attrs: {
      disabled: _vm.readyOnlyForSubQuote,
      maxlength: "10",
      type: "text"
    },
    domProps: {
      value: _vm.innerVehicle.trimCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerVehicle, "trimCode", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Paint Code")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerVehicle.paintCode,
      expression: "innerVehicle.paintCode"
    }, {
      name: "tippy",
      rawName: "v-tippy",
      value: {
        theme: "danger",
        enabled: _vm.$v.vehicle.paintCode.$error
      },
      expression: "{ theme: 'danger', enabled: $v.vehicle.paintCode.$error }"
    }],
    staticClass: "input",
    class: {
      "is-invalid": _vm.$v.vehicle.paintCode.$error
    },
    attrs: {
      content: _vm.ormMessages.paintCode.ormMaxLength,
      disabled: _vm.readyOnlyForSubQuote,
      maxlength: "100",
      type: "text"
    },
    domProps: {
      value: _vm.innerVehicle.paintCode
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerVehicle, "paintCode", $event.target.value);
      }
    }
  })])])])])]), _vm.isVehicleLookupModalActive ? _c("vehicle-lookup-modal", {
    attrs: {
      active: _vm.isVehicleLookupModalActive,
      "state-rego": _vm.innerVehicle.stateRego
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isVehicleLookupModalActive = $event;
      },
      close: function close($event) {
        _vm.isVehicleLookupModalActive = false;
      },
      select: _vm.selectVehicleMakeModel
    },
    model: {
      value: _vm.innerVehicle.rego,
      callback: function callback($$v) {
        _vm.$set(_vm.innerVehicle, "rego", $$v);
      },
      expression: "innerVehicle.rego"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Make/Model Lookup")])]) : _vm._e(), _c("car-model-search-modal", {
    attrs: {
      visible: _vm.isCarModelSearchModalActive,
      make: _vm.innerVehicle.model ? _vm.innerVehicle.model.make : "",
      model: _vm.innerVehicle.model ? _vm.innerVehicle.model.model : "",
      series: _vm.innerVehicle.model ? _vm.innerVehicle.model.series : "",
      "is-ntar": _vm.isOrm || _vm.isNtar
    },
    on: {
      ok: _vm.selectMakeModelModal,
      cancel: function cancel($event) {
        _vm.isCarModelSearchModalActive = false;
      }
    }
  })], 1) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column is-flex is-align-items-center"
  }, [_c("i", {
    staticClass: "icon mdi mdi-car mdi-24px"
  }), _c("p", {
    staticClass: "title pl-1"
  }, [_vm._v("Vehicle")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-small"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label", [_vm._v("M3+")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-header-fieldset[data-v-34979168],\n.quote-header.fixed-grid[data-v-34979168],\n.quote-header.fixed-grid > .grid[data-v-34979168] {\n  height: 100%;\n}\n.quote-header-fieldset[data-v-34979168] {\n  border: 0;\n  min-width: 0;\n}\n.quote-header-fieldset[data-v-34979168]:disabled a.button,\n.quote-header-fieldset[data-v-34979168]:disabled .cursor-pointer {\n  pointer-events: none !important;\n}\n.quote-header-fieldset[data-v-34979168]:disabled .control:not(:has(.control)):hover::before {\n  content: \"Disabled, as your licence has expired\";\n  position: absolute;\n  top: 100%;\n  left: 50%;\n  -webkit-transform: translate(-50%, 0.5rem);\n          transform: translate(-50%, 0.5rem);\n  z-index: 30;\n  padding: 0.4rem 0.8rem;\n  border-radius: 4px;\n  background: rgba(74, 74, 74, 0.9);\n  color: #fff;\n  font-size: 0.75rem;\n  white-space: nowrap;\n  pointer-events: none;\n}\n.quote-header-fieldset[data-v-34979168]:disabled .grid > :first-child .control:not(:has(.control)):hover::before {\n  left: 0;\n  -webkit-transform: translate(0, 0.5rem);\n          transform: translate(0, 0.5rem);\n}\n.quote-header-fieldset[data-v-34979168]:disabled .grid > :last-child .control:not(:has(.control)):hover::before {\n  left: auto;\n  right: 0;\n  -webkit-transform: translate(0, 0.5rem);\n          transform: translate(0, 0.5rem);\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-item-saving-overlay {\n  position: absolute;\n  inset: 0;\n  z-index: 20;\n  pointer-events: all;\n  overflow: hidden;\n  border-radius: var(--bulma-radius-small, 4px);\n  background: color-mix(in srgb, var(--bulma-scheme-main) 40%, transparent);\n}\n.quote-item-saving-overlay::before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 2px;\n  background: var(--bulma-primary);\n  opacity: 0.7;\n}\n.quote-item-saving-overlay::after {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: -webkit-gradient(linear, left top, right top, from(transparent), color-stop(50%, color-mix(in srgb, var(--bulma-primary) 14%, transparent)), to(transparent));\n  background: linear-gradient(90deg, transparent 0%, color-mix(in srgb, var(--bulma-primary) 14%, transparent) 50%, transparent 100%);\n  -webkit-transform: translateX(-100%);\n          transform: translateX(-100%);\n  -webkit-animation: item-saving-shimmer 1.6s ease-in-out infinite;\n          animation: item-saving-shimmer 1.6s ease-in-out infinite;\n}\n@-webkit-keyframes item-saving-shimmer {\n0% {\n    -webkit-transform: translateX(-100%);\n            transform: translateX(-100%);\n}\n100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n}\n}\n@keyframes item-saving-shimmer {\n0% {\n    -webkit-transform: translateX(-100%);\n            transform: translateX(-100%);\n}\n100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n}\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-ece6f782] {\n  margin: 0 0 1.2rem 0;\n}\ndiv.tile.is-parent[data-v-ece6f782] {\n  min-height: calc(100vh - 8rem);\n}\n.main-container > .field[data-v-ece6f782] {\n  margin-bottom: 1.5rem;\n}\n.is-disabled[data-v-ece6f782] {\n  pointer-events: none;\n  opacity: 0.6;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".cursor-pointer[data-v-6f342f68] {\n  cursor: pointer !important;\n}\n.cursor-pointer.icon[data-v-6f342f68] {\n  pointer-events: auto !important;\n}\n.is-divider[data-v-6f342f68] {\n  margin: 0 0 1.2rem 0;\n}\ndiv.tile.is-parent[data-v-6f342f68] {\n  min-height: calc(100vh - 8rem);\n}\n.alt-contact-section[data-v-6f342f68] {\n  border-left: 3px solid var(--bulma-primary-70);\n  padding-left: 1rem;\n  margin-left: 0.25rem;\n}\n.is-synced-icon[data-v-6f342f68] {\n  position: absolute;\n  margin-top: -1em;\n  margin-left: -0.5em;\n  font-size: 1.5rem;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".quote-insurer[data-v-568e2544] {\n  min-height: calc(100vh - 8rem);\n}\n.columns.field[data-v-568e2544] {\n  margin-bottom: 0.75rem;\n}\n.columns.field .column[data-v-568e2544] {\n  padding-bottom: 0 !important;\n}\n.columns.field .column[data-v-568e2544]:first-child {\n  padding-right: 0.375rem;\n}\n.columns.field .column[data-v-568e2544]:last-child {\n  padding-left: 0.375rem;\n}\n.columns.field .column[data-v-568e2544] :not(:first-child):not(:last-child) {\n  padding-left: 0.375rem;\n  padding-right: 0.375rem;\n}\n.is-divider[data-v-568e2544] {\n  margin: 0 0 1.2rem 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "div.tile.is-parent[data-v-fc012cdc] {\n  min-height: calc(100vh - 8rem);\n}\n.columns.field[data-v-fc012cdc] {\n  margin-bottom: 0;\n}\n.columns.field .column[data-v-fc012cdc]:first-child {\n  padding-right: 0.375rem;\n}\n.columns.field .column[data-v-fc012cdc]:last-child {\n  padding-left: 0.375rem;\n}\n.columns.field .column[data-v-fc012cdc] :not(:first-child):not(:last-child) {\n  padding-left: 0.375rem;\n  padding-right: 0.375rem;\n}\n.is-divider[data-v-fc012cdc] {\n  margin: 0 0 1.2rem 0;\n}\n.input-box-keyno[data-v-fc012cdc] {\n  border: none;\n  border-bottom: 1px solid #dbdbdb;\n  border-radius: 0;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  width: 5ch;\n  padding: 0;\n  -webkit-transition: border-color 0.3s ease;\n  transition: border-color 0.3s ease;\n  height: auto;\n  text-align: center;\n}\n.input-box-keyno[data-v-fc012cdc]:focus {\n  border-bottom: 2px solid #3291ef;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("24878ff3", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("698cac5f", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("32c72169", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("1ecf97c4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("ae817380", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("8f32e846", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/json/neighbours.json":
/*!*****************************************!*\
  !*** ./src/assets/json/neighbours.json ***!
  \*****************************************/
/*! exports provided: 0, 1, 2, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"countryCode\":\"AU\",\"neighbours\":[\"NZ\"]},{\"countryCode\":\"NZ\",\"neighbours\":[\"AU\"]},{\"countryCode\":\"MY\",\"neighbours\":[\"SG\",\"TH\"]}]");

/***/ }),

/***/ "./src/views/quote/QuoteHeader.vue":
/*!*****************************************!*\
  !*** ./src/views/quote/QuoteHeader.vue ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteHeader.vue?vue&type=template&id=34979168&scoped=true */ "./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true");
/* harmony import */ var _QuoteHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteHeader.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true */ "./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true");
/* harmony import */ var _QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss */ "./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _QuoteHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "34979168",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteHeader.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js":
/*!*****************************************************************!*\
  !*** ./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true":
/*!**************************************************************************************************!*\
  !*** ./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=0&id=34979168&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_0_id_34979168_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss":
/*!**************************************************************************************!*\
  !*** ./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=style&index=1&id=34979168&lang=scss");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_style_index_1_id_34979168_lang_scss__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true":
/*!***********************************************************************************!*\
  !*** ./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteHeader.vue?vue&type=template&id=34979168&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteHeader.vue?vue&type=template&id=34979168&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteHeader_vue_vue_type_template_id_34979168_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/QuoteOrmValidation.js":
/*!***********************************************!*\
  !*** ./src/views/quote/QuoteOrmValidation.js ***!
  \***********************************************/
/*! exports provided: ormValidationMessages, ormValidationRules, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ormValidationMessages", function() { return ormValidationMessages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ormValidationRules", function() { return ormValidationRules; });
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);

var isOrm = function isOrm() {
  return this.entity != null && this.entity.orm != null;
};

// ORM-specific validation must fire ONLY while the user is submitting the quote
// at the ORM page (Send Quote / Send Tax Invoice). `isOrmValidation` is set
// true by validateJobStartEndForOrm() during those flows and reset afterwards
// (and intentionally left true on a FAILED submit so the user keeps seeing the
// errors). Gating every ORM rule behind this keeps ORM errors — and their
// inline messages — out of normal Save / autosave on an ORM quote.
var isOrmSubmit = function isOrmSubmit() {
  return isOrm.call(this) && this.isOrmValidation === true;
};
var ormValidationMessages = {
  claimNo: {
    ormRequired: 'Claim Number is required by ORM',
    ormMaxLength: 'Claim Number cannot exceed 15 characters'
  },
  companyName: {
    ormMaxLength: 'Company Name cannot exceed 45 characters'
  },
  paintCode: {
    ormMaxLength: 'Paint Code cannot exceed 10 characters'
  },
  rego: {
    ormMaxLength: 'Registration No. cannot exceed 9 characters'
  }
};
var ormValidationRules = {
  ormHeaderGroup: ['vehicle.bodyId2', 'vehicle.buildMonth', 'vehicle.buildYear', 'vehicle.transmissionType', 'vehicle.paintCode', 'vehicle.rego', 'customer.lastname', 'customer.firstname', 'customer.companyName', 'entity.claimNo', 'entity.damageSeverity'],
  ormSummaryGroup: ['entity.jobStart', 'entity.jobEnd', 'entity.quoter', 'entity.odometer', 'vehicle.colour', 'entity.refuseBookRepairReason'],
  repairLateGroup: ['entity.repairLateReason'],
  estimateJobStartEnd: ['entity.jobStart', 'entity.jobEnd'],
  entity: {
    odometer: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      validOdometer: function validOdometer(value) {
        if (!isOrmSubmit.call(this)) return true;
        return value > 0 && value <= 9999999;
      }
    },
    claimNo: {
      ormRequired: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 15;
      }
    },
    jobStart: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      bothRequired: function bothRequired() {
        if (!isOrmSubmit.call(this)) return true;
        return !!(this.entity.jobStart && this.entity.jobEnd);
      },
      validJobStart: function validJobStart(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (value && this.entity.jobEnd) {
          return value <= this.entity.jobEnd;
        }
        return true;
      }
    },
    jobEnd: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit),
      bothRequired: function bothRequired() {
        if (!isOrmSubmit.call(this)) return true;
        return !!(this.entity.jobStart && this.entity.jobEnd);
      },
      validJobEnd: function validJobEnd(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (value && this.entity.jobStart) {
          return value >= this.entity.jobStart;
        }
        return true;
      }
    },
    damageSeverity: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        return isOrmSubmit.call(this) && this.insurer && this.insurer.damageSeverity;
      }),
      validDamageSeverity: function validDamageSeverity(value) {
        if (!isOrmSubmit.call(this)) return true;
        return value > 0 || !(this.insurer && this.insurer.damageSeverity);
      }
    },
    refuseBookRepairReason: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        if (!isOrmSubmit.call(this)) return false;
        if (this.entity.isRepairBooked == null || this.entity.isRepairBooked == undefined) return false;
        return !this.entity.isRepairBooked && this.entity.repx != null;
      })
    },
    repairLateReason: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function () {
        if (!isOrmSubmit.call(this)) return false;
        return this.entity.repx != null && this.entity.isArriveForInspection != null && this.entity.isArriveForInspection == false;
      })
    }
  },
  customer: {
    companyName: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 45;
      }
    }
  },
  vehicle: {
    bodyId2: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    buildMonth: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    buildYear: {
      required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(isOrmSubmit)
    },
    paintCode: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 10;
      }
    },
    rego: {
      ormMaxLength: function ormMaxLength(value) {
        if (!isOrmSubmit.call(this)) return true;
        if (!value) return true;
        return String(value).length <= 9;
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      isOrmValidation: false
    };
  },
  methods: {
    validateJobStartEndForOrm: function validateJobStartEndForOrm() {
      this.isOrmValidation = true;
      this.$v.entity.jobStart.$reset();
      this.$v.entity.jobEnd.$reset();
      this.$v.entity.jobStart.$touch();
      this.$v.entity.jobEnd.$touch();
    },
    touchOrmHeaderValidators: function touchOrmHeaderValidators() {
      this.$v.ormHeaderGroup.$touch();
      this.$v.entity.claimNo.$touch();
      this.$v.entity.damageSeverity.$touch();
      this.$v.vehicle.bodyId2.$touch();
      this.$v.vehicle.buildMonth.$touch();
      this.$v.vehicle.buildYear.$touch();
      this.$v.vehicle.transmissionType.$touch();
      this.$v.vehicle.paintCode.$touch();
      this.$v.vehicle.rego.$touch();
      this.$v.customer.companyName.$touch();
      this.$v.customer.firstname.$touch();
      this.$v.customer.lastname.$touch();
    },
    touchOrmSummaryValidators: function touchOrmSummaryValidators() {
      this.$v.ormSummaryGroup.$touch();
      this.$v.entity.quoter.$touch();
      this.$v.entity.odometer.$touch();
      this.$v.entity.refuseBookRepairReason.$touch();
      this.$v.vehicle.colour.$touch();
      this.$v.vehicle.paintCode.$touch();
      this.$v.customer.companyName.$touch();
      this.$v.customer.firstname.$touch();
      this.$v.customer.lastname.$touch();
    },
    resetOrmValidation: function resetOrmValidation() {
      this.isOrmValidation = false;
    }
  }
});

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue":
/*!*************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AssessorAutocomplete.vue?vue&type=template&id=8c14665e */ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e");
/* harmony import */ var _AssessorAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AssessorAutocomplete.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AssessorAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js":
/*!*************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssessorAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AssessorAutocomplete.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssessorAutocomplete_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e":
/*!*******************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./AssessorAutocomplete.vue?vue&type=template&id=8c14665e */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/AssessorAutocomplete.vue?vue&type=template&id=8c14665e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssessorAutocomplete_vue_vue_type_template_id_8c14665e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue":
/*!*************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true */ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true");
/* harmony import */ var _CustomerAddressInput_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CustomerAddressInput.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CustomerAddressInput_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "39a563b6",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/CustomerAddressInput.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js":
/*!*************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CustomerAddressInput_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./CustomerAddressInput.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CustomerAddressInput_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true":
/*!*******************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true ***!
  \*******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/CustomerAddressInput.vue?vue&type=template&id=39a563b6&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CustomerAddressInput_vue_vue_type_template_id_39a563b6_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/PanelBlurMixin.js":
/*!******************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/PanelBlurMixin.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  mounted: function mounted() {
    var _this = this;
    this._trackMouseDown = function (e) {
      _this._lastMouseDownTarget = e.target;
    };
    document.addEventListener('mousedown', this._trackMouseDown, true);
  },
  beforeDestroy: function beforeDestroy() {
    clearTimeout(this._blurCheckTimeout);
    document.removeEventListener('mousedown', this._trackMouseDown, true);
    if (this._focusLeaveHandler) document.removeEventListener('focusin', this._focusLeaveHandler);
    if (this._mouseDownOutsideHandler) document.removeEventListener('mousedown', this._mouseDownOutsideHandler);
  },
  methods: {
    _watchForFocusLeave: function _watchForFocusLeave() {
      var _this2 = this;
      if (this._focusLeaveHandler) document.removeEventListener('focusin', this._focusLeaveHandler);
      if (this._mouseDownOutsideHandler) document.removeEventListener('mousedown', this._mouseDownOutsideHandler);
      var cleanup = function cleanup() {
        document.removeEventListener('focusin', _this2._focusLeaveHandler);
        document.removeEventListener('mousedown', _this2._mouseDownOutsideHandler);
        _this2._focusLeaveHandler = null;
        _this2._mouseDownOutsideHandler = null;
      };
      this._focusLeaveHandler = function (e) {
        if (!_this2.$el) {
          cleanup();
          return;
        }
        if (_this2.$el.contains(e.target)) {
          cleanup();
          return;
        }
        cleanup();
        _this2.$emit('component-blur');
      };
      this._mouseDownOutsideHandler = function (e) {
        if (!_this2.$el) {
          cleanup();
          return;
        }
        if (_this2.$el.contains(e.target)) return;
        cleanup();
        _this2.$emit('component-blur');
      };
      document.addEventListener('focusin', this._focusLeaveHandler);
      document.addEventListener('mousedown', this._mouseDownOutsideHandler);
    },
    onComponentFocusOut: function onComponentFocusOut() {
      var _this3 = this;
      clearTimeout(this._blurCheckTimeout);
      this._blurCheckTimeout = setTimeout(function () {
        var active = document.activeElement;
        if (!active || active === document.body) {
          // Last mousedown was on a live element outside this panel — genuine click away.
          // Skip if element was removed from DOM (e.g. datepicker popup close).
          if (_this3._lastMouseDownTarget && document.documentElement.contains(_this3._lastMouseDownTarget) && !_this3.$el.contains(_this3._lastMouseDownTarget)) {
            _this3.$emit('component-blur');
            return;
          }
          // Focus settling after datepicker/popup interaction — wait for next deliberate action.
          _this3._watchForFocusLeave();
          return;
        }
        if (_this3.$el && !_this3.$el.contains(active)) {
          _this3.$emit('component-blur');
        }
      }, 0);
    }
  }
});

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue":
/*!*****************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteBooking.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true");
/* harmony import */ var _QuoteBooking_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteBooking.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteBooking_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "ece6f782",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/QuoteBooking.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBooking.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true":
/*!**************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=style&index=0&id=ece6f782&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_style_index_0_id_ece6f782_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true":
/*!***********************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteBooking.vue?vue&type=template&id=ece6f782&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteBooking_vue_vue_type_template_id_ece6f782_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue":
/*!******************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteCustomer.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true");
/* harmony import */ var _QuoteCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteCustomer.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6f342f68",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/QuoteCustomer.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCustomer.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true":
/*!***************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=style&index=0&id=6f342f68&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_style_index_0_id_6f342f68_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteCustomer.vue?vue&type=template&id=6f342f68&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteCustomer_vue_vue_type_template_id_6f342f68_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue":
/*!*****************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteInsurer.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true");
/* harmony import */ var _QuoteInsurer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteInsurer.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteInsurer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "568e2544",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/QuoteInsurer.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInsurer.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true":
/*!**************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=style&index=0&id=568e2544&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_style_index_0_id_568e2544_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true":
/*!***********************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteInsurer.vue?vue&type=template&id=568e2544&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInsurer_vue_vue_type_template_id_568e2544_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue":
/*!*****************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteVehicle.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true");
/* harmony import */ var _QuoteVehicle_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteVehicle.vue?vue&type=script&lang=js */ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true */ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteVehicle_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "fc012cdc",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/components/QuoteHeader/QuoteVehicle.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicle.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true":
/*!**************************************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=style&index=0&id=fc012cdc&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_style_index_0_id_fc012cdc_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true":
/*!***********************************************************************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../../node_modules/babel-loader/lib!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/components/QuoteHeader/QuoteVehicle.vue?vue&type=template&id=fc012cdc&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteVehicle_vue_vue_type_template_id_fc012cdc_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/components/QuoteHeader/index.js":
/*!*********************************************************!*\
  !*** ./src/views/quote/components/QuoteHeader/index.js ***!
  \*********************************************************/
/*! exports provided: QuoteCustomer, QuoteInsurer, QuoteVehicle, QuoteBooking */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteCustomer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteCustomer */ "./src/views/quote/components/QuoteHeader/QuoteCustomer.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "QuoteCustomer", function() { return _QuoteCustomer__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _QuoteInsurer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteInsurer */ "./src/views/quote/components/QuoteHeader/QuoteInsurer.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "QuoteInsurer", function() { return _QuoteInsurer__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _QuoteVehicle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteVehicle */ "./src/views/quote/components/QuoteHeader/QuoteVehicle.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "QuoteVehicle", function() { return _QuoteVehicle__WEBPACK_IMPORTED_MODULE_2__["default"]; });

/* harmony import */ var _QuoteBooking__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./QuoteBooking */ "./src/views/quote/components/QuoteHeader/QuoteBooking.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "QuoteBooking", function() { return _QuoteBooking__WEBPACK_IMPORTED_MODULE_3__["default"]; });







/***/ })

}]);
//# sourceMappingURL=quote-header-chunk.js.map