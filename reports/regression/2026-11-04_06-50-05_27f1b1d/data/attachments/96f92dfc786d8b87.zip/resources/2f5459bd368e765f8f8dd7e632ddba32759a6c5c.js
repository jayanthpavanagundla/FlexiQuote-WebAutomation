(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[26],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'NotificationBox',
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      notificationClass: 'noti-primary',
      textclass: 'has-text-primary',
      icon: 'mdi-check-circle-outline'
    };
  },
  created: function created() {
    this.getClass(this.type);
  },
  methods: {
    getClass: function getClass(type) {
      switch (type) {
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Success:
          this.notificationClass = 'noti-primary';
          this.icon = 'mdi-check-circle-outline';
          this.textclass = 'has-text-primary';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Warning:
          this.notificationClass = 'noti-warning';
          this.icon = 'mdi-bell-ring-outline';
          this.textclass = 'has-text-warning';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Error:
          this.notificationClass = 'noti-danger';
          this.icon = 'mdi-alert-circle-outline';
          this.textclass = 'has-text-danger';
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_0__["NotificationBoxType"].Default:
          this.notificationClass = 'noti-default';
          this.icon = 'mdi-information-outline';
          this.textclass = 'has-text-current';
          break;
        default:
          break;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ResetPassword.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
/* harmony import */ var core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_test_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ErrorMessage */ "./src/views/auth/ErrorMessage.js");
/* harmony import */ var _loginNavigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./loginNavigation */ "./src/views/auth/loginNavigation.js");
/* harmony import */ var _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/Notification/NotificationBox.vue */ "./src/components/Notification/NotificationBox.vue");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_9__);










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ResetPasword',
  components: {
    NotificationBox: _components_Notification_NotificationBox_vue__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  data: function data() {
    return {
      confirmedPasswordVisible: false,
      confirmedPassword: '',
      isResetComplete: false,
      isValidationComplete: false,
      hasResetError: false,
      hasValidationError: false,
      message: '',
      newPassword: '',
      newPasswordVisible: false,
      notificationType: '',
      passwordValidationMessage: '',
      refToken: '',
      token: ''
    };
  },
  computed: {
    logoImgPath: function logoImgPath() {
      return this.$theme.isDark ? __webpack_require__(/*! @/assets/images/flexiquote-logo-dark.svg */ "./src/assets/images/flexiquote-logo-dark.svg") : __webpack_require__(/*! @/assets/images/flexiquote-logo-light.svg */ "./src/assets/images/flexiquote-logo-light.svg");
    }
  },
  created: function created() {
    this.token = this.$route.query.token;
    this.refToken = this.$route.query.refToken;
    this.isPasswordResetAllowed();
  },
  methods: {
    cancel: function cancel() {
      return Object(_loginNavigation__WEBPACK_IMPORTED_MODULE_6__["goToLogin"])();
    },
    forgotPasswordReset: function forgotPasswordReset() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.$v.$touch();
              if (!_this.$v.$error) {
                _context.n = 1;
                break;
              }
              return _context.a(2);
            case 1:
              _context.p = 1;
              _context.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_4__["AuthService"].forgotPasswordReset(_this.token, _this.refToken, _this.confirmedPassword);
            case 2:
              _this.message = 'Your password has been successfully reset. Please try logging again.';
              _this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_8__["NotificationBoxType"].Success;
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.hasResetError = true;
              _this.notificationType = _enums__WEBPACK_IMPORTED_MODULE_8__["NotificationBoxType"].Error;
              _this.message = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_5__["getErrorMessage"])(_t.response.data.message).message;
            case 4:
              _context.p = 4;
              _this.isResetComplete = true;
              return _context.f(4);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    },
    isPasswordResetAllowed: function isPasswordResetAllowed() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              _context2.p = 0;
              _context2.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_4__["AuthService"].CheckPasswordResetEligibility(_this2.token);
            case 1:
              _context2.n = 3;
              break;
            case 2:
              _context2.p = 2;
              _t2 = _context2.v;
              _this2.hasValidationError = true;
              _this2.notificationType = _enums__WEBPACK_IMPORTED_MODULE_8__["NotificationBoxType"].Error;
              _this2.message = Object(_ErrorMessage__WEBPACK_IMPORTED_MODULE_5__["getErrorMessage"])(_t2.response.data.message).message;
            case 3:
              _context2.p = 3;
              _this2.isValidationComplete = true;
              return _context2.f(3);
            case 4:
              return _context2.a(2);
          }
        }, _callee2, null, [[0, 2, 3, 4]]);
      }))();
    },
    validateConfirmedPassword: function validateConfirmedPassword() {
      this.$v.confirmedPassword.$touch();
    },
    validateNewPassword: function validateNewPassword() {
      this.$v.newPassword.$touch();
    }
  },
  validations: {
    newPassword: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_9__["required"],
      validatedNewPassword: function validatedNewPassword(value) {
        if (value.length < 8) {
          this.passwordValidationMessage = 'Password must be at least 8 characters long';
          return false;
        } else if (!/\d/.test(value)) {
          this.passwordValidationMessage = 'Password must have at least one number';
          return false;
        } else if (!/[A-Z]/.test(value)) {
          this.passwordValidationMessage = 'Password must have at least one uppercase character';
          return false;
        } else if (!/[a-z]/.test(value)) {
          this.passwordValidationMessage = 'Password must have at least one lowercase character';
          return false;
        } else if (!/[!@#$%^&*()_+=\[\]{};:<>|./?,-]/.test(value)) {
          this.passwordValidationMessage = 'Password must have at least one special character';
          return false;
        }
        return true;
      }
    },
    confirmedPassword: {
      required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_9__["required"],
      matchNewPassword: function matchNewPassword(value) {
        return value == this.newPassword;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("div", [_c("div", {
    staticClass: "control is-flex is-align-items-center",
    class: [_vm.notificationClass, _vm.textclass, _vm.$theme.isDark ? "is-dark" : "is-light"]
  }, [_c("div", {
    staticClass: "mr-4"
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-36px",
    class: _vm.icon
  })])]), _vm._t("text-content")], 2)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.isValidationComplete ? _c("div", {
    staticClass: "reset-password-container is-flex is-align-items-center is-justify-content-center"
  }, [_c("div", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "control mb-5 is-flex is-justify-content-center"
  }, [_c("img", {
    staticStyle: {
      "max-height": "2.25rem"
    },
    attrs: {
      src: _vm.logoImgPath,
      alt: "Flexiquote Logo",
      title: "Flexiquote Logo"
    }
  })]), _vm._m(0), !_vm.isResetComplete && !_vm.hasValidationError ? _c("div", [_c("div", {
    staticClass: "control mb-6"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("New Password")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [(_vm.newPasswordVisible ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newPassword,
      expression: "newPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "New Password",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.newPassword) ? _vm._i(_vm.newPassword, null) > -1 : _vm.newPassword
    },
    on: {
      blur: _vm.validateNewPassword,
      change: function change($event) {
        var $$a = _vm.newPassword,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.newPassword = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.newPassword = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.newPassword = $$c;
        }
      }
    }
  }) : (_vm.newPasswordVisible ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newPassword,
      expression: "newPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "New Password",
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.newPassword, null)
    },
    on: {
      blur: _vm.validateNewPassword,
      change: function change($event) {
        _vm.newPassword = null;
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.newPassword,
      expression: "newPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "New Password",
      type: _vm.newPasswordVisible ? "text" : "password"
    },
    domProps: {
      value: _vm.newPassword
    },
    on: {
      blur: _vm.validateNewPassword,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.newPassword = $event.target.value;
      }
    }
  }), _vm.$v.newPassword.$dirty && !_vm.$v.newPassword.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e(), _vm.$v.newPassword.$dirty && !_vm.$v.newPassword.validatedNewPassword && _vm.$v.newPassword.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v(" " + _vm._s(_vm.passwordValidationMessage) + " ")]) : _vm._e()]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        _vm.newPasswordVisible = !_vm.newPasswordVisible;
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small is-right"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.newPasswordVisible ? "mdi-eye-outline" : "mdi-eye-off-outline"
  })])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label is-required-label"
  }, [_vm._v("Confirm New Password")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [(_vm.confirmedPasswordVisible ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.confirmedPassword,
      expression: "confirmedPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "Confirm New Password",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.confirmedPassword) ? _vm._i(_vm.confirmedPassword, null) > -1 : _vm.confirmedPassword
    },
    on: {
      blur: _vm.validateConfirmedPassword,
      change: function change($event) {
        var $$a = _vm.confirmedPassword,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.confirmedPassword = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.confirmedPassword = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.confirmedPassword = $$c;
        }
      }
    }
  }) : (_vm.confirmedPasswordVisible ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.confirmedPassword,
      expression: "confirmedPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "Confirm New Password",
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.confirmedPassword, null)
    },
    on: {
      blur: _vm.validateConfirmedPassword,
      change: function change($event) {
        _vm.confirmedPassword = null;
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.confirmedPassword,
      expression: "confirmedPassword"
    }],
    staticClass: "input",
    attrs: {
      placeholder: "Confirm New Password",
      type: _vm.confirmedPasswordVisible ? "text" : "password"
    },
    domProps: {
      value: _vm.confirmedPassword
    },
    on: {
      blur: _vm.validateConfirmedPassword,
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.confirmedPassword = $event.target.value;
      }
    }
  }), _vm.$v.confirmedPassword.$dirty && !_vm.$v.confirmedPassword.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Required")]) : _vm._e(), _vm.$v.confirmedPassword.$dirty && !_vm.$v.confirmedPassword.matchNewPassword && _vm.$v.confirmedPassword.required ? _c("span", {
    staticClass: "help is-danger ml-1"
  }, [_vm._v("Please make sure your passwords match.")]) : _vm._e()]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        _vm.confirmedPasswordVisible = !_vm.confirmedPasswordVisible;
      }
    }
  }, [_c("span", {
    staticClass: "icon is-small is-right"
  }, [_c("i", {
    staticClass: "mdi mdi-18px",
    class: _vm.confirmedPasswordVisible ? "mdi-eye-outline" : "mdi-eye-off-outline"
  })])])])])])]), _c("div", {
    staticClass: "control mb-2 is-flex is-justify-content-end"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.forgotPasswordReset
    }
  }, [_vm._v("Confirm")])])]) : _vm._e(), _vm.isResetComplete || _vm.isValidationComplete && _vm.hasValidationError ? _c("div", [_c("notification-box", {
    staticClass: "mb-6",
    attrs: {
      type: _vm.notificationType
    }
  }, [_c("p", {
    staticClass: "is-size-7",
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(_vm._s(_vm.message))])]), _c("div", {
    staticClass: "control is-flex is-justify-content-end"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.cancel
    }
  }, [_vm._m(1), _vm._v(" Back to login ")])])], 1) : _vm._e()])]) : _vm._e();
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "control mb-6"
  }, [_c("h4", {
    staticClass: "has-text-weight-medium is-size-5"
  }, [_vm._v("Set new password")]), _c("p", {
    staticClass: "has-text-grey is-size-7"
  }, [_vm._v(" Must be at least 8 characters, have at least one symbol, one number, one uppercase and one lowercase letter. ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon mr-1"
  }, [_c("i", {
    staticClass: "mdi mdi-18px mdi-arrow-left"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.noti-warning {\n  border: 1px solid #f9bf00;\n  border-radius: 4px;\n  /* background-color: #fffcf2; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-danger {\n  border: 2px solid #d73654;\n  border-radius: 4px;\n  /* background-color: #fff6f8; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-primary {\n  border: 2px solid #3291ef;\n  border-radius: 4px;\n  /* background-color: #f0f8ff; */\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default {\n  border: 1px solid #dbdbdb;\n  border-radius: 4px;\n  background-color: #f5f5f5;\n  padding: 1.25rem 2.5rem 1.25rem 1.5rem;\n}\n.noti-default.is-dark {\n  border-color: #4a4a4a;\n  background-color: #363636;\n}\n\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(/*! ../../assets/images/flexiquoteloginbackground.jpg */ "./src/assets/images/flexiquoteloginbackground.jpg");
exports = ___CSS_LOADER_API_IMPORT___(false);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
// Module
exports.push([module.i, ".reset-password-container[data-v-6f3fb2dd] {\n  width: 100%;\n  height: 100vh;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") top center no-repeat !important;\n  background-size: cover !important;\n}\n.box[data-v-6f3fb2dd] {\n  width: 400px;\n}\n.label[data-v-6f3fb2dd] {\n  font-weight: 500;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--7-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("7386d66a", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("26bb8806", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/assets/images/flexiquoteloginbackground.jpg":
/*!*********************************************************!*\
  !*** ./src/assets/images/flexiquoteloginbackground.jpg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/flexiquoteloginbackground.a7bed929.jpg";

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue":
/*!*********************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=template&id=dc876468 */ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony import */ var _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=script&lang=js */ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"],
  _NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/components/Notification/NotificationBox.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css":
/*!*****************************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--7-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--7-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--7-oneOf-1-2!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=style&index=0&id=dc876468&lang=css");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_style_index_0_id_dc876468_lang_css__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468":
/*!***************************************************************************************!*\
  !*** ./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468 ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./NotificationBox.vue?vue&type=template&id=dc876468 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/Notification/NotificationBox.vue?vue&type=template&id=dc876468");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NotificationBox_vue_vue_type_template_id_dc876468__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/auth/ErrorMessage.js":
/*!****************************************!*\
  !*** ./src/views/auth/ErrorMessage.js ***!
  \****************************************/
/*! exports provided: getErrorMessage, getApiErrorMessage, isSignInTicketExpired */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessage", function() { return getErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApiErrorMessage", function() { return getApiErrorMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSignInTicketExpired", function() { return isSignInTicketExpired; });
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_0__);

var errorMessages = {
  'default': {
    title: 'Something wrong',
    message: 'Something wrong. Please get in touch with support.'
  },
  'password_not_meet_criteria': {
    title: 'Password not meet criteria',
    message: 'The password you provided does not meet criteria.'
  },
  'forget_password_request_not_found': {
    title: 'Forget Password Request not found',
    message: 'Forget password request not found. Please send a new request.'
  },
  'no_valid_user_found': {
    title: 'No valid user found',
    message: 'We could not locate a user matching information you provided. Please get in touch with support.'
  },
  'failed_send_email_with_mailgun': {
    title: 'Failed to send an email',
    message: 'Failed to send an email. Please get in touch with support.'
  },
  'failed_create_password_entry': {
    title: 'Failed to create password entry',
    message: 'Failed to create password entry. Please get in touch with support.'
  },
  'failed_insert_emailoutgoing': {
    title: 'Failed to insert email outgoing record',
    message: 'Failed to insert email outgoing record. Please get in touch with support.'
  },
  'password_reset_link_expired': {
    title: 'Expired password reset link',
    message: 'The password reset link has expired. Please send a new request.'
  },
  'password_reset_link_used': {
    title: 'Used password reset link',
    message: 'The password reset link has already been used. Please send a new request.'
  },
  'not_valid_user_token': {
    title: 'Invalid user token',
    message: 'Not valid user. Please contact support.'
  }
};
var getErrorMessage = function getErrorMessage(errorCode) {
  return errorMessages[errorCode] || errorMessages['default'];
};

/**
 * Text to show for a failed sign-in call.
 *
 * Distinct from getErrorMessage above, which maps known error *codes* to friendly copy. The
 * sign-in endpoints instead return literal user-facing strings ("Invalid credentials, you have
 * 3 remaining attempts", "You have been locked out. Try again in ...") deliberately matched to
 * the wording of the legacy login page, so the server's message is the message to display.
 *
 * ASP.NET Web API serialises Request.CreateErrorResponse as {"Message": "..."}, but the shape
 * varies across the endpoints and proxies involved, so each known form is checked in turn.
 *
 * A few of these endpoints do return a bare code rather than prose - the password-change path
 * surfaces 'password_not_meet_criteria' straight from UpdateUserPassword - so anything matching
 * a known code is translated rather than shown to the user verbatim.
 */
var getApiErrorMessage = function getApiErrorMessage(error, fallback) {
  var data = error && error.response ? error.response.data : null;
  var raw = null;
  if (typeof data === 'string' && data.trim()) {
    raw = data;
  } else if (data) {
    if (typeof data.Message === 'string' && data.Message.trim()) raw = data.Message;else if (typeof data.message === 'string' && data.message.trim()) raw = data.message;else if (typeof data.ExceptionMessage === 'string' && data.ExceptionMessage.trim()) raw = data.ExceptionMessage;
  }
  if (!raw) return fallback || 'Something went wrong. Please try again.';
  var trimmed = raw.trim();
  return errorMessages[trimmed] ? errorMessages[trimmed].message : trimmed;
};

/**
 * True when a sign-in step failed because its server-side ticket is gone. The only way on from
 * there is to enter the password again for a fresh ticket.
 */
var isSignInTicketExpired = function isSignInTicketExpired(error) {
  var data = error && error.response ? error.response.data : null;
  return !!data && data.code === 'signin_ticket_expired';
};

/***/ }),

/***/ "./src/views/auth/ResetPassword.vue":
/*!******************************************!*\
  !*** ./src/views/auth/ResetPassword.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true */ "./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true");
/* harmony import */ var _ResetPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ResetPassword.vue?vue&type=script&lang=js */ "./src/views/auth/ResetPassword.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true */ "./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ResetPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "6f3fb2dd",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/auth/ResetPassword.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/auth/ResetPassword.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/auth/ResetPassword.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=style&index=0&id=6f3fb2dd&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_style_index_0_id_6f3fb2dd_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true":
/*!************************************************************************************!*\
  !*** ./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/auth/ResetPassword.vue?vue&type=template&id=6f3fb2dd&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ResetPassword_vue_vue_type_template_id_6f3fb2dd_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=26.js.map