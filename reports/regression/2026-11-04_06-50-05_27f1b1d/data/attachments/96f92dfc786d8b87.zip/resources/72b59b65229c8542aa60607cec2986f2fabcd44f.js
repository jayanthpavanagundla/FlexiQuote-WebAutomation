(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["booking-detail-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/LoadQuoteSteps */ "./src/views/booking/components/LoadQuoteSteps/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _BookingService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./BookingService */ "./src/views/booking/BookingService.js");
/* harmony import */ var _BookingConvertToQuoteValidationSimple__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./BookingConvertToQuoteValidationSimple */ "./src/views/booking/BookingConvertToQuoteValidationSimple.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/components/LoadQuoteSteps */ "./src/components/LoadQuoteSteps/index.js");













/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BookingConvertToQuoteSimple',
  inject: ['$vv'],
  components: {
    LoadQuoteModal: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["LoadQuoteModal"],
    LoadQuoteSteps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["LoadQuoteSteps"]
  },
  mixins: [_BookingConvertToQuoteValidationSimple__WEBPACK_IMPORTED_MODULE_9__["default"]],
  props: {
    value: null,
    quoteBookingId: null,
    entity: null,
    active: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerEntity: this.entity,
      isActive: this.active || false,
      selectedRow: null,
      isLoadQuoteModalActive: false,
      steps: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["Steps"],
      currentStep: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["Steps"].CreateAssign.id,
      loadOptions: this.value
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    lastStep: function lastStep() {
      return this.steps.CreateAssign;
    },
    enableContinue: function enableContinue() {
      return this.lastStep.id === this.currentStep;
    },
    eComType: function eComType() {
      if (this.entity.isRepx) return 'ORM';
      // return 'all'
      return 'ORM'; //suppose pass from booking detail page
    },
    enabledComTypeSelection: function enabledComTypeSelection() {
      if (!this.entity.isRepx) return true;
      return false;
    }
  },
  watch: {
    active: function active(value) {
      this.isActive = value;
    },
    loadOptions: {
      handler: function handler(newVal, oldVal) {
        console.log(newVal);
        //console.log(this.$v)
        this.$emit('input', newVal);
      },
      deep: true
    },
    entity: {
      handler: function handler(newVal, oldVal) {
        this.innerEntity = newVal;
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    //console.log(this.value)
    // console.log(this.$v)
  },
  mounted: function mounted() {},
  methods: {
    previous: function previous() {
      this.currentStep--;
      if (this.currentStep === this.steps.CreateAssign.id) {
        this.$v.loadOptions.quoteId.$reset();
      } else if (this.currentStep === this.steps.SelectInsurer.id) {
        this.$v.loadOptions.insurerId.$reset();
      } else if (this.currentStep === this.steps.UpdateCustomer.id) {
        this.$v.loadOptions.customerId.$reset();
      }
    },
    next: function next() {
      switch (this.currentStep) {
        case _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["Steps"].CreateAssign.id:
          this.$v.loadOptions.quoteId.$touch();
          if (!this.$v.loadOptions.quoteId.$error || this.loadOptions.isCreateQuote) {
            this.currentStep++;
          }
          break;
      }
    },
    reset: function reset() {
      this.loadOptions.messageId = _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty();
      this.loadOptions.messageTypeId = _enums__WEBPACK_IMPORTED_MODULE_6__["MessageTypes"].QML_RequestForQuote;
      this.loadOptions.quoteId = _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty();
      this.loadOptions.isCreateQuote = true;
      this.loadOptions.insurerId = _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty();
      this.loadOptions.customerOption = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_12__["CustomerOptionTypes"].Create;
      this.loadOptions.isOverwriteVehicle = false;
      this.loadOptions.customerId = _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty();
      this.loadOptions.title = '';
      this.loadOptions.customerName = '';
      this.loadOptions.firstname = '';
      this.loadOptions.lastname = '';
      this.loadOptions.isPerson = false;
      this.loadOptions.regoNo = '';
      this.loadOptions.vehicleId = _components_Guid__WEBPACK_IMPORTED_MODULE_7__["default"].empty();
      this.loadOptions.isOverwriteOrmMessageNo = false;
      this.currentStep = _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_5__["Steps"].CreateAssign.id;
      this.selectedMessage = null;
      this.isRepx = null;
      // Reset validation objects
      this.$v.loadOptions.$reset();
    },
    closeModal: function closeModal() {
      this.$emit('close');
      this.reset();
    },
    loadMessage: function loadMessage() {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _entity, quote, route, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _this.isActive = false;
              _this.$emit('close');
              _this.$showSpinner('Loading quote');
              _context.p = 1;
              _this.$showSpinner('Converting...');
              console.log(_this.innerEntity);
              _entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default()(_this.entity);
              _entity.loadOptions = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_10___default()(_this.loadOptions);
              _context.n = 2;
              return _BookingService__WEBPACK_IMPORTED_MODULE_8__["default"].putConvertBookingToQuote(_entity);
            case 2:
              quote = _context.v;
              route = _views_quote_route_types__WEBPACK_IMPORTED_MODULE_11__["default"].QuoteView.path.replace(':quoteId', quote.data.quoteId);
              _this.$router.push("".concat(route));
              // this.$router.push({
              //   name: 'VehicleListView',
              //   params: { id: quoteId }
              // })
              _this.$hideSpinner();
              _this.$emit('close');
              // this.isLoadQuoteModalActive = false
              // this.isOrmMessageNoModalActive = false
              // const result = await OrmMessageService.loadMessage(this.loadOptions)
              // this.quoteId = result.data
              // if (Guid.validGuid(this.quoteId)) {
              //   this.quoteNo = await OrmMessageService.getQuoteNo(this.quoteId)
              //   this.print(this.loadOptions.messageId, this.loadOptions.messageTypeId)
              //   if (this.loadOptions.isCreateQuote && this.loadOptions.messageTypeId === MessageTypes.QML_RequestForQuote) {
              //     this.createAuditTrail(this.quoteId, 'insert', '')
              //   } else {
              //     // TODO: create update AuditTrail entry
              //   }
              //   this.savedLoadOptions = _cloneDeep(this.loadOptions)
              //   this.isConfirmModalActive = true
              //}
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              throw _t;
            case 4:
              _context.p = 4;
              _this.reset();
              _this.$hideSpinner();
              return _context.f(4);
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3, 4, 5]]);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_AppBookingSideMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/AppBookingSideMenu */ "./src/views/booking/components/AppBookingSideMenu.vue");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./route-types */ "./src/views/booking/route-types.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");







/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BookingSideMenu',
  inject: ['$vv'],
  components: {
    AppBookingSideMenu: _components_AppBookingSideMenu__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    value: null,
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      imageCount: 0,
      documentCount: 0,
      unreadInterval: null,
      unreadCount: 0
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_4__["default"];
    },
    enableItemRoutes: function enableItemRoutes() {
      return _components_Guid__WEBPACK_IMPORTED_MODULE_5__["default"].validGuid(this.value.insurerId) && _components_Guid__WEBPACK_IMPORTED_MODULE_5__["default"].validGuid(this.value.vehicleId) && !this.$v.quoteHeaderGroup.$error;
    },
    quoteNo: function quoteNo() {
      if (this.value && this.value.quoteNo) return this.value.quoteNo;
      return null;
    },
    quoteId: function quoteId() {
      if (this.value && this.value.quoteId) return this.value.quoteId;
      return null;
    }
  },
  created: function created() {},
  mounted: function mounted() {},
  beforeDestroy: function beforeDestroy() {},
  methods: {
    selectBooking: function selectBooking(bookingNo) {
      this.$emit('select-booking', bookingNo);
    },
    goToRoute: function goToRoute(route) {
      if (this.enableItemRoutes) {
        this.$router.push(route);
      }
    },
    handleQuoteClick: function handleQuoteClick() {
      if (this.quoteId) {
        var route = _views_quote_route_types__WEBPACK_IMPORTED_MODULE_6__["default"].QuoteView.path.replace(':quoteId', this.quoteId);
        this.$router.push("".concat(route));
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _BookingSideMenu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./BookingSideMenu */ "./src/views/booking/BookingSideMenu.vue");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./route-types */ "./src/views/booking/route-types.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./storeMixin */ "./src/views/booking/storeMixin.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! lodash.clonedeep */ "./node_modules/lodash.clonedeep/index.js");
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _BookingService__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./BookingService */ "./src/views/booking/BookingService.js");
/* harmony import */ var _BookingValidation__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./BookingValidation */ "./src/views/booking/BookingValidation.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/LoadQuoteSteps */ "./src/components/LoadQuoteSteps/index.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _BookingConvertToQuoteSimple_vue__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./BookingConvertToQuoteSimple.vue */ "./src/views/booking/BookingConvertToQuoteSimple.vue");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");





















// import _debounce from 'lodash.debounce'






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BookingView',
  components: {
    BookingSideMenu: _BookingSideMenu__WEBPACK_IMPORTED_MODULE_10__["default"],
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_11__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__["ConfirmModal"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_17__["UnsavedModal"],
    BookingConvertToQuoteSimple: _BookingConvertToQuoteSimple_vue__WEBPACK_IMPORTED_MODULE_23__["default"]
  },
  mixins: [_BookingValidation__WEBPACK_IMPORTED_MODULE_19__["default"], _storeMixin__WEBPACK_IMPORTED_MODULE_14__["default"]],
  props: {
    returnUrl: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      entity: null,
      entityMainQuote: null,
      isSkipSave: false,
      isSaveContinue: false,
      isUnsavedModalActive: false,
      isSaveConflictModalActive: false,
      toRoute: null,
      isConfirmModalActive: false,
      isBookingConvertQuoteActive: false,
      innerBookingId: '',
      loadOptions: {
        messageId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        messageTypeId: _enums__WEBPACK_IMPORTED_MODULE_13__["MessageTypes"].QML_RequestForQuote,
        quoteId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        insurerId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        isCreateQuote: true,
        customerId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        originalCustomerId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        customerOption: _components_LoadQuoteSteps__WEBPACK_IMPORTED_MODULE_21__["CustomerOptionTypes"].Create,
        title: '',
        customerName: '',
        firstname: '',
        lastname: '',
        isPerson: false,
        regoNo: '',
        claimNo: '',
        vehicleId: _components_Guid__WEBPACK_IMPORTED_MODULE_20__["default"].empty(),
        isOverwriteVehicle: true,
        isOverwriteOrmMessageNo: false,
        isRepx: false
      }
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.detailGroup.$error;
    },
    canConvert: function canConvert() {
      return !this.entity.quoteId;
    }
  },
  watch: {
    value: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
    // entity: {
    //   handler: _debounce(function(newVal) {
    //     if (newVal) {
    //       this.$forceUpdate()
    //       this.saveSnapshot(_cloneDeep(this.entity))
    //     }
    //   }, 500),
    //   deep: true
    // }
  },
  created: function created() {
    this.getEntity();
    this.innerBookingId = this.$route.params.bookingId;
    if (this.returnUrl) {
      this.persistQueries();
      this.replaceRoute(this.$route.params.bookingId);
    }
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntityReload, /*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _context.n = 1;
            return _this.getEntity(true);
          case 1:
            _this.innerBookingId = _this.entity.quoteBookingId;
            _this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntityReloaded);
          case 2:
            return _context.a(2);
        }
      }, _callee);
    })));
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntityReload);
  },
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Delete:
          this.isConfirmModalActive = true;
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_13__["AppHeaderButtonTypes"].Convert:
          this.handleConvert();
          break;
      }
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|quote|returnUrl"));
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.bookingId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.bookingId);
            case 2:
              _this2.entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this2.currentSnapshot);
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$toast.open({
                message: _t,
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              // this.$notification.openMessageXhrError('', e)
            case 4:
              _this2.$hideSpinner();
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    save: function save(isDelete) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$toast.open({
                message: 'Validation errors. Please fix before saving',
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              //const title = 'Booking Item'
              // this.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving')
              return _context3.a(2, false);
            case 1:
              _context3.p = 1;
              _this3.$showSpinner('Saving...');
              _this3.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this3.entity));
              if (!_this3.entity.isNew) {
                _context3.n = 3;
                break;
              }
              _context3.n = 2;
              return _BookingService__WEBPACK_IMPORTED_MODULE_18__["default"].postBookingItem(_this3.entity);
            case 2:
              _context3.n = 6;
              break;
            case 3:
              if (!_this3.snapshotDiff) {
                _context3.n = 5;
                break;
              }
              _context3.n = 4;
              return _BookingService__WEBPACK_IMPORTED_MODULE_18__["default"].putBookingItem(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this3.entity), _this3.snapshotDiff);
            case 4:
              _context3.n = 6;
              break;
            case 5:
              _this3.$toast.open({
                message: 'No changes detected. Not saved',
                type: 'is-success',
                position: 'is-top',
                queue: false
              });
              // this.$notification.openNotificationWithType('warning', title, 'No changes detected. Not saved')
              return _context3.a(2, null);
            case 6:
              //await this.removeStoreItem(this.entity.QuoteBookingID)
              _this3.$toast.open({
                message: isDelete ? 'Booking set to In-Active' : 'Save successful',
                type: 'is-success',
                position: 'is-top',
                queue: false
              });
              // this.$notification.success('Booking Item', isDelete ? 'Booking Item set to In-Active' : 'Save successful')
              if (_this3.isSaveContinue) {
                _context3.n = 7;
                break;
              }
              _context3.n = 7;
              return _this3.getEntity(true);
            case 7:
              _this3.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntitySaved);
              return _context3.a(2, true);
            case 8:
              _context3.p = 8;
              _t2 = _context3.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_24__["default"].$emit('serviceError', _t2.response.status);
              // if (e.response.request.status === HttpStatus.CONFLICT) {
              //   this.isSaveConflictModalActive = true
              // } else {
              _this3.$toast.open({
                message: _t2,
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              // this.$notification.openMessageXhrError('Booking Item', e)
              return _context3.a(2, false);
            case 9:
              _context3.p = 9;
              _this3.$hideSpinner();
              return _context3.f(9);
            case 10:
              return _context3.a(2);
          }
        }, _callee3, null, [[1, 8, 9, 10]]);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(this.entity));
      if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_16___default()(this.returnRoute)) {
        this.$router.push({
          path: this.returnRoute.path,
          query: this.returnRoute.query
        });
      } else if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else {
        // const returnUrl = sessionStorage.getItem(this.returnUrlKey)
        // if it comes from url => redirect after save
        if (this.returnUrl) {
          if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
            this.isUnsavedModalActive = true;
          } else {
            this.clearSessionStorage();
            this.clearSnapshots(this.entity.id);
            this.$showSpinner('Returning...');
            this.redirectToQueryUrl(this.returnUrl);
          }
        } else {
          if (this.entity.isNew && this.isSkipSave) {
            // cleanup vuex store
            this.clearSnapshots(this.entity.QuoteBookingID);
          }
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_12__["default"].DashboardView.name,
            filter: this.filter,
            query: {
              filter: this.encodedFilter
            }
          });
        }
      }
    },
    changeBooking: function changeBooking(booking) {
      // console.log(subQuote.key)
      this.$router.push({
        name: this.$route.name,
        params: {
          bookingId: booking.value
        }
      });
    },
    handleDelete: function handleDelete() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var _t3;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.p = _context4.n) {
            case 0:
              _context4.p = 0;
              _this4.$showSpinner('Saving...');
              _this4.saveSnapshot(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this4.entity));
              _context4.n = 1;
              return _BookingService__WEBPACK_IMPORTED_MODULE_18__["default"].deleteBooking(_this4.entity);
            case 1:
              _this4.isConfirmModalActive = false;
              _this4.$toast.open({
                message: 'Booking set to In-Active',
                type: 'is-success',
                position: 'is-top',
                queue: false
              });
              // this.$notification.success('Booking Item', 'Booking Item set to In-Active')
              if (_this4.isSaveContinue) {
                _context4.n = 2;
                break;
              }
              _context4.n = 2;
              return _this4.getEntity(true);
            case 2:
              _this4.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_13__["EventHubTypes"].EntitySaved);
              return _context4.a(2, true);
            case 3:
              _context4.p = 3;
              _t3 = _context4.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_24__["default"].$emit('serviceError', _t3.response.status);
              // this.$notification.openMessageXhrError('Booking Item', e)
              _this4.$toast.open({
                message: _t3,
                type: 'is-danger',
                position: 'is-top',
                queue: false
              });
              return _context4.a(2, false);
            case 4:
              _context4.p = 4;
              _this4.$hideSpinner();
              return _context4.f(4);
            case 5:
              return _context4.a(2);
          }
        }, _callee4, null, [[0, 3, 4, 5]]);
      }))();
    },
    handleConvert: function handleConvert() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var isSaved;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _this5.save(false);
            case 1:
              isSaved = _context5.v;
              if (!(isSaved == false)) {
                _context5.n = 2;
                break;
              }
              return _context5.a(2);
            case 2:
              _this5.isBookingConvertQuoteActive = true;
              _this5.loadOptions.regoNo = _this5.entity.vehicleRegistrationNo;
              _this5.loadOptions.claimNo = _this5.entity.claimNo;
              _this5.loadOptions.customerName = _this5.entity.customerName;
              // this.loadOptions.isRepx = this.isRepx
              _this5.loadOptions.isPerson = _this5.entity.isCompany;
              _this5.loadOptions.insurerId = _this5.entity.insurerId;
              _this5.loadOptions.firstname = _this5.entity.firstname;
              _this5.loadOptions.lastname = _this5.entity.lastname;
              // this.loadOptions.isRepx = this.entity.isRepx
              _this5.loadOptions.isRepx = true;
            case 3:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    },
    handleConvertQuote: function handleConvertQuote() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        var _entity, quote, route, _t4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.p = _context6.n) {
            case 0:
              _context6.p = 0;
              _this6.$showSpinner('Converting...');
              // console.log(this.innerEntity)
              _entity = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this6.entity);
              _entity.loadOptions = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_15___default()(_this6.loadOptions);
              _context6.n = 1;
              return _BookingService__WEBPACK_IMPORTED_MODULE_18__["default"].putConvertBookingToQuote(_entity);
            case 1:
              quote = _context6.v;
              route = _views_quote_route_types__WEBPACK_IMPORTED_MODULE_22__["default"].QuoteView.path.replace(':quoteId', quote.data.quoteId);
              _this6.$router.push("".concat(route));
              _this6.$hideSpinner();
              _context6.n = 3;
              break;
            case 2:
              _context6.p = 2;
              _t4 = _context6.v;
              throw _t4;
            case 3:
              _context6.p = 3;
              _this6.$$hideSpinner();
              return _context6.f(3);
            case 4:
              return _context6.a(2);
          }
        }, _callee6, null, [[0, 2, 3, 4]]);
      }))();
    },
    closeBookingConvertQuote: function closeBookingConvertQuote() {
      this.isBookingConvertQuoteActive = false;
      this.triggerConvert = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/services */ "./src/services/index.js");











/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AppBookingSideMenu',
  props: {
    minWidth: {
      type: Number,
      default: 18
    },
    visibleWidth: {
      type: Number,
      default: 1008
    },
    fixedMenu: {
      type: Boolean,
      default: false
    },
    bookings: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    currentBooking: {
      type: Number,
      default: 0
    },
    currentRouteName: {
      type: String,
      default: ''
    },
    isNew: {
      type: Boolean,
      default: false
    },
    isSynced: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      inlineStyle: '',
      windowWidth: 0,
      windowHeigth: 0,
      toggleSideMenu: true,
      isTouchDevice: false,
      bookingNo: 0,
      planningSetting: null
    };
  },
  computed: {
    hasFlexiShopIntegration: function hasFlexiShopIntegration() {
      return this.planningSetting && this.planningSetting.password;
    }
  },
  watch: {
    minWidth: function minWidth(newVal, oldVal) {
      this.inlineStyle = this.minWidth.toString() + 'vw';
    }
  },
  created: function created() {
    var _this = this;
    this.bookingNo = this.bookings.find(function (s) {
      return s.key === _this.currentBooking;
    });
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].ToggleSideMenu, function (data) {
      _this.handleSideMenuEvent(data);
    });
  },
  mounted: function mounted() {
    this.inlineStyle = this.minWidth.toString() + 'vw';
    this.$nextTick(function () {
      window.addEventListener('resize', this.getWindowWidth);
      window.addEventListener('resize', this.getWindowHeight);
      this.getWindowWidth();
      this.getWindowHeight();
    });
    this.getCompanyExternalSetting();
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener('resize', this.getWindowWidth);
    window.removeEventListener('resize', this.getWindowHeight);
  },
  methods: {
    getWindowWidth: function getWindowWidth(event) {
      this.windowWidth = window.innerWidth; // document.documentElement.clientWidth
      if (this.toggleSideMenu && this.windowWidth <= this.visibleWidth) {
        this.toggleSideMenu = false;
        this.isTouchDevice = true;
        this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AutoHideSideMenu, true);
      } else if (!this.toggleSideMenu && this.windowWidth > this.visibleWidth) {
        this.toggleSideMenu = true;
        this.isTouchDevice = false;
        this.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_9__["EventHubTypes"].AutoHideSideMenu, false);
      }
    },
    getWindowHeight: function getWindowHeight(event) {
      this.windowHeight = window.innerHeight; // document.documentElement.clientHeight
    },
    handleSideMenuEvent: function handleSideMenuEvent(data) {
      this.toggleSideMenu = data || this.fixedMenu && !this.isTouchDevice;
    },
    selectBooking: function selectBooking(bookingNo) {
      this.bookingNo = bookingNo;
      this.$emit('select-booking', bookingNo);
    },
    goToRoute: function goToRoute(route) {
      if (!this.isNew) {
        this.$router.push(route);
      }
    },
    getCompanyExternalSetting: function getCompanyExternalSetting() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_10__["CompanyService"].getCompanyExternalSetting('Planning Plus');
            case 1:
              _this2.planningSetting = _context.v;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("load-quote-modal", {
    attrs: {
      active: _vm.isActive,
      "show-icon": false,
      "previous-disabled": _vm.currentStep === _vm.steps.CreateAssign.id,
      "next-disabled": _vm.currentStep === _vm.lastStep.id,
      "continue-disabled": !_vm.enableContinue
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      previous: function previous($event) {
        return _vm.previous();
      },
      next: function next($event) {
        return _vm.next();
      },
      load: function load($event) {
        return _vm.loadMessage();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Convert to Quote")]), _c("div", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("load-quote-steps", {
    attrs: {
      "current-step": _vm.currentStep,
      steps: _vm.steps,
      "ecom-type": _vm.eComType,
      "enable-ecom-type-selection": _vm.enabledComTypeSelection
    },
    model: {
      value: _vm.loadOptions,
      callback: function callback($$v) {
        _vm.loadOptions = $$v;
      },
      expression: "loadOptions"
    }
  })], 1)]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-booking-side-menu", {
    attrs: {
      "min-width": 15,
      "fixed-menu": false,
      "booking-nos": _vm.value.bookingNos,
      "current-booking-no": _vm.value.bookingNo,
      "current-route-name": _vm.$route.name,
      "is-new": _vm.value.isNew,
      "is-synced": _vm.value.isSynced
    },
    on: {
      "select-booking": _vm.selectBooking
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("div", {
    staticClass: "menu-label"
  }, [_c("div", {
    staticClass: "columns is-gapless mb-2"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("span", {
    staticClass: "title is-6",
    staticStyle: {
      "white-space": "nowrap"
    }
  }, [_vm._v(" Claim No.: " + _vm._s(_vm.entityName) + " ")])])]), _vm.quoteId ? _c("div", {
    staticClass: "columns is-gapless mb-1"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("span", {
    staticClass: "title is-6 is-link",
    staticStyle: {
      "white-space": "nowrap"
    }
  }, [_vm._v(" Quote No.: "), _c("a", {
    on: {
      click: function click($event) {
        return _vm.handleQuoteClick();
      }
    }
  }, [_vm._v(" " + _vm._s(_vm.quoteNo) + " ")])])])]) : _vm._e()]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.BookingHeader.name,
        params: {
          quoteId: _vm.$route.params.quoteId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset2"
  }, [_vm._v("Details")])])])], 1), _vm.value.isRepx ? _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.BookingRepx.name,
        params: {
          quoteId: _vm.$route.params.quoteId
        },
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_vm._v(" RepX Log ")])])], 1) : _vm._e()])])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.entity ? _c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      entity: _vm.entity,
      "show-new": false,
      "show-print": false,
      "show-delete": !!_vm.entity && !_vm.entity.deleted && _vm.canConvert && !_vm.entity.isNew,
      "show-save": !!_vm.entity && !_vm.entity.deleted && !_vm.entity.quoteId,
      "show-lock": false,
      "show-convert": !_vm.entity.deleted && _vm.canConvert
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }) : _vm._e(), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("booking-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": "".concat(_vm.entity.claimNo)
    },
    on: {
      "select-booking": _vm.changeBooking
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "is-tiled": false,
      "route-name": _vm.$route.name
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _vm.entity ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Yes",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.handleDelete();
      },
      cancel: function cancel($event) {
        _vm.isConfirmModalActive = !_vm.isConfirmModalActive;
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Delete Booking")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" Booking "), _c("span", {
    staticClass: "has-text-primary has-text-weight-bold"
  }, [_vm._v(_vm._s("".concat(_vm.entity.vehicleRegistrationNo)))]), _vm._v(" will be deleted. Continue? ")])]) : _vm._e(), _vm.isBookingConvertQuoteActive ? _c("booking-convert-to-quote-simple", {
    attrs: {
      active: _vm.isBookingConvertQuoteActive,
      "quote-booking-id": _vm.innerBookingId,
      entity: _vm.entity
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isBookingConvertQuoteActive = $event;
      },
      close: _vm.closeBookingConvertQuote
    },
    model: {
      value: _vm.loadOptions,
      callback: function callback($$v) {
        _vm.loadOptions = $$v;
      },
      expression: "loadOptions"
    }
  }) : _vm._e()], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("transition-group", {
    attrs: {
      name: "custom-classes-transition",
      "enter-active-class": "animated slideInLeft",
      "leave-active-class": "animated slideOutLeft"
    }
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.toggleSideMenu,
      expression: "toggleSideMenu"
    }],
    key: "tile-parent",
    staticClass: "tile is-parent",
    style: {
      "min-width": _vm.inlineStyle
    }
  }, [_c("article", {
    key: "tile-child",
    staticClass: "tile is-child box",
    style: {
      "min-width": _vm.inlineStyle
    }
  }, [_c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.info.isSupportUser && _vm.hasFlexiShopIntegration,
      expression: "$user.info.isSupportUser && hasFlexiShopIntegration"
    }],
    staticClass: "icon is-synced-icon",
    class: [_vm.isSynced ? "has-text-success" : "has-text-warning"]
  }, [_c("i", {
    staticClass: "mdi mdi-circle-medium mdi-36px"
  })]), _vm.bookings && _vm.bookings.length > 0 ? _c("div", {
    staticClass: "tabs"
  }, [_c("ul", _vm._l(_vm.bookings, function (booking) {
    return _c("li", {
      key: booking.key,
      class: {
        "is-active": booking.key === _vm.currentBooking
      }
    }, [_c("router-link", {
      class: {
        "is-disabled": _vm.isNew && booking.key !== _vm.currentBooking
      },
      attrs: {
        to: {
          name: _vm.currentRouteName,
          params: {
            bookingId: booking.value
          },
          query: _vm.$route.query
        },
        "active-class": "is-active",
        exact: ""
      },
      nativeOn: {
        click: function click($event) {
          $event.preventDefault();
          return _vm.goToRoute({
            name: _vm.currentRouteName,
            params: {
              bookingId: booking.value
            },
            query: _vm.$route.query
          });
        }
      }
    }, [_c("span", {
      class: {
        "has-badge-warning has-badge-small has-badge-rounded has-badge-offset2": _vm.isNew && booking.key === _vm.currentBooking
      },
      attrs: {
        "data-badge": _vm.isNew && booking.key === _vm.currentBooking ? "" : null
      }
    }, [_vm._v(" " + _vm._s(booking.key === 0 ? "Main" : "Add-".concat(booking.key)) + " ")])])], 1);
  }), 0)]) : _vm._e(), _vm._t("side-menu")], 2)])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-disabled[data-v-58204162] {\n  cursor: not-allowed;\n  opacity: 0.5;\n  text-decoration: none;\n}\n.is-disabled a[data-v-58204162] {\n  display: inline-block;\n  text-decoration: none;\n}\nspan.superscript[data-v-58204162] {\n  vertical-align: super;\n  font-size: smaller;\n}\nspan.has-badge-child[data-v-58204162] {\n  margin-right: 1em;\n}\n.has-badge-icon[data-v-58204162]::after {\n  font-family: \"Material Design Icons\";\n  content: \"\\f12c\";\n}\n.has-badge-icon-check[data-v-58204162]::after {\n  font-family: \"Material Design Icons\";\n  content: \"\\f012c\";\n}\n.has-badge-icon-exclamation[data-v-58204162]::after {\n  font-family: \"Material Design Icons\";\n  content: \"\\f0205\";\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".side-menu[data-v-1456a672] {\n  min-height: 100%;\n  max-width: 40vw;\n}\n.slideInLeft[data-v-1456a672] {\n  -webkit-animation: slideInLeft 0.5s;\n  /* Safari 4+ */\n  /* Fx 5+ */\n  /* Opera 12+ */\n  animation: slideInLeft 0.5s;\n  /* IE 10+, Fx 29+ */\n}\n.slideOutLeft[data-v-1456a672] {\n  -webkit-animation: slideOutLeft 0.5s;\n  /* Safari 4+ */\n  /* Fx 5+ */\n  /* Opera 12+ */\n  animation: slideOutLeft 0.5s;\n  /* IE 10+, Fx 29+ */\n}\n.is-disabled[data-v-1456a672] {\n  cursor: not-allowed;\n  opacity: 0.5;\n  text-decoration: none;\n}\n.is-disabled a[data-v-1456a672] {\n  display: inline-block;\n  text-decoration: none;\n}\n.is-synced-icon[data-v-1456a672] {\n  position: absolute;\n  margin-top: -1em;\n  margin-left: -1em;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("70bb7c11", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("3560bef4", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/booking/BookingConvertToQuoteSimple.vue":
/*!***********************************************************!*\
  !*** ./src/views/booking/BookingConvertToQuoteSimple.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e */ "./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e");
/* harmony import */ var _BookingConvertToQuoteSimple_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BookingConvertToQuoteSimple.vue?vue&type=script&lang=js */ "./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BookingConvertToQuoteSimple_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/booking/BookingConvertToQuoteSimple.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingConvertToQuoteSimple_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingConvertToQuoteSimple.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingConvertToQuoteSimple_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e":
/*!*****************************************************************************************!*\
  !*** ./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingConvertToQuoteSimple.vue?vue&type=template&id=e82aaf4e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingConvertToQuoteSimple_vue_vue_type_template_id_e82aaf4e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/booking/BookingConvertToQuoteValidationSimple.js":
/*!********************************************************************!*\
  !*** ./src/views/booking/BookingConvertToQuoteValidationSimple.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/validators */ "./src/components/validators/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    loadOptions: {
      quoteId: {
        validGuid: _components_validators__WEBPACK_IMPORTED_MODULE_0__["guidValidator"]
      }
    }
  }
});

/***/ }),

/***/ "./src/views/booking/BookingSideMenu.vue":
/*!***********************************************!*\
  !*** ./src/views/booking/BookingSideMenu.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true */ "./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true");
/* harmony import */ var _BookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BookingSideMenu.vue?vue&type=script&lang=js */ "./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true */ "./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _BookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "58204162",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/booking/BookingSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************!*\
  !*** ./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true":
/*!********************************************************************************************************!*\
  !*** ./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=style&index=0&id=58204162&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_style_index_0_id_58204162_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true":
/*!*****************************************************************************************!*\
  !*** ./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingSideMenu.vue?vue&type=template&id=58204162&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingSideMenu_vue_vue_type_template_id_58204162_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/booking/BookingView.vue":
/*!*******************************************!*\
  !*** ./src/views/booking/BookingView.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BookingView.vue?vue&type=template&id=edab60c4 */ "./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4");
/* harmony import */ var _BookingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BookingView.vue?vue&type=script&lang=js */ "./src/views/booking/BookingView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _BookingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__["render"],
  _BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/booking/BookingView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/booking/BookingView.vue?vue&type=script&lang=js":
/*!*******************************************************************!*\
  !*** ./src/views/booking/BookingView.vue?vue&type=script&lang=js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4":
/*!*************************************************************************!*\
  !*** ./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4 ***!
  \*************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./BookingView.vue?vue&type=template&id=edab60c4 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/BookingView.vue?vue&type=template&id=edab60c4");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_BookingView_vue_vue_type_template_id_edab60c4__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/booking/components/AppBookingSideMenu.vue":
/*!*************************************************************!*\
  !*** ./src/views/booking/components/AppBookingSideMenu.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true */ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true");
/* harmony import */ var _AppBookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AppBookingSideMenu.vue?vue&type=script&lang=js */ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true */ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AppBookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1456a672",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/booking/components/AppBookingSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AppBookingSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true":
/*!**********************************************************************************************************************!*\
  !*** ./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=style&index=0&id=1456a672&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_style_index_0_id_1456a672_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true":
/*!*******************************************************************************************************!*\
  !*** ./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/booking/components/AppBookingSideMenu.vue?vue&type=template&id=1456a672&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AppBookingSideMenu_vue_vue_type_template_id_1456a672_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/booking/components/LoadQuoteSteps/index.js":
/*!**************************************************************!*\
  !*** ./src/views/booking/components/LoadQuoteSteps/index.js ***!
  \**************************************************************/
/*! exports provided: LoadQuoteModal, LoadQuoteSteps, Steps */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadQuoteModal", function() { return LoadQuoteModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadQuoteSteps", function() { return LoadQuoteSteps; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Steps", function() { return Steps; });
var LoadQuoteModal = function LoadQuoteModal(r) {
  return __webpack_require__.e(/*! require.ensure | loadquotesteps */ "loadquotesteps").then((function () {
    return r(__webpack_require__(/*! ./LoadQuoteModal.vue */ "./src/views/booking/components/LoadQuoteSteps/LoadQuoteModal.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var LoadQuoteSteps = function LoadQuoteSteps(r) {
  return __webpack_require__.e(/*! require.ensure | loadquotesteps */ "loadquotesteps").then((function () {
    return r(__webpack_require__(/*! ./LoadQuoteSteps.vue */ "./src/views/booking/components/LoadQuoteSteps/LoadQuoteSteps.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};
var Steps = {
  CreateAssign: {
    id: 1,
    enabled: true
  },
  GotoQuote: {
    id: 2,
    enabled: true
  }
};


/***/ })

}]);
//# sourceMappingURL=booking-detail-chunk.js.map