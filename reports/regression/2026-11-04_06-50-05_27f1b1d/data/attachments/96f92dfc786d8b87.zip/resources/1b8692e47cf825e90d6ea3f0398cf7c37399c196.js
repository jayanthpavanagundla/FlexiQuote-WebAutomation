(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ormbatching-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js":
/*!*****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! lodash/orderBy */ "./node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./components/OrmBatchStatistics */ "./src/views/ormbatching/components/OrmBatchStatistics.vue");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__);






























/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingAvailableQuotes',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__["default"],
    OrmBatchStatistics: _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_27__["default"]
  },
  props: {
    value: null,
    quotes: null,
    removedQuotes: null
  },
  data: function data() {
    return {
      innerValue: null,
      availableQuotes: null,
      availableQuoteQuery: '',
      availableQuoteTotalRows: 0,
      isAvailableQuoteTableLoading: false,
      isAvailableQuoteRowDraggable: true,
      availableQuoteDrag: false,
      availableQuoteFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      activeBatchIds: null,
      selectedAvailableBatchId: _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty(),
      availableBatch: null,
      isOutOfScopQuoteTableLoading: false,
      outOfScopeQuoteFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      }
    };
  },
  computed: {
    guid: function guid() {
      return _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"];
    },
    availableQuoteColumns: function availableQuoteColumns() {
      return _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"];
    },
    alr: function alr() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var batchTotalLabourHour = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var batchNonLabourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      var batchAgreedTotal = this.quotes.length * this.innerValue.agreedArc;
      // console.log(this.quotes.length, batchTotalLabourHour, batchNonLabourTotal, batchAgreedTotal)
      var batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal;
      return batchTotalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1) : 0;
    },
    adjustedTotal: function adjustedTotal() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var labourHourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.alr);
    },
    averageLabourUnits: function averageLabourUnits() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageLabourValues: function averageLabourValues() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageNonLabourValues: function averageNonLabourValues() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageTotalExGst: function averageTotalExGst() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.quotes.length);
    },
    labourUnitTotal: function labourUnitTotal() {
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    availableAlr: function availableAlr() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var batchTotalLabourHour = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var batchNonLabourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      var batchAgreedTotal = this.availableQuotes.length * this.availableBatch.agreedArc;
      var batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal;
      return batchTotalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1) : 0;
    },
    availableAdjustedTotal: function availableAdjustedTotal() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var labourHourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.availableAlr);
    },
    availableAverageLabourUnits: function availableAverageLabourUnits() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    availableAverageLabourValues: function availableAverageLabourValues() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    availableAverageNonLabourValues: function availableAverageNonLabourValues() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    availableAverageTotalExGst: function availableAverageTotalExGst() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    availableLabourUnitTotal: function availableLabourUnitTotal() {
      if (!this.availableQuotes) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_28__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    filteredAvailableQuotes: function filteredAvailableQuotes() {
      if (!this.availableQuotes) {
        return null;
      }
      this.toggleTableLoading(true);
      var query = this.availableQuoteQuery.toLowerCase();
      var results = this.availableQuotes;
      if (this.availableQuoteQuery) {
        results = this.availableQuotes.filter(function (q) {
          return q.quoteNo.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      // if (this.totalLowerLimit) {
      //   results = results.filter(q => q.totalExGst >= this.totalLowerLimit)
      // }
      // if (this.totalUpperLimit) {
      //   results = results.filter(q => q.totalExGst <= this.totalUpperLimit)
      // }
      this.toggleTableLoading(false);
      return results.filter(function (q) {
        return q.quoteInScope;
      });
    },
    outOfScopeQuoteTotalRows: function outOfScopeQuoteTotalRows() {
      return this.outOfScopeQuotes ? this.outOfScopeQuotes.length : 0;
    },
    outOfScopeQuotes: function outOfScopeQuotes() {
      if (!this.availableQuotes) {
        return null;
      }
      return this.availableQuotes.filter(function (q) {
        return !q.quoteInScope;
      });
    },
    ormQuoteStatusTypes: function ormQuoteStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_24__["OrmQuoteStatusTypes"];
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_24__["OrmBatchStatusType"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    selectedAvailableBatchId: function selectedAvailableBatchId(newVal, oldVal) {
      this.getBatchQuoteAvailableSummaries();
      if (newVal !== _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty()) {
        console.log(newVal);
        this.getAvailableBatch(newVal);
      } else {
        this.availableBatch = null;
        this.updateDestinationBatch(_components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty());
      }
    }
  },
  created: function created() {
    var _this = this;
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(this.value);
    this.getActiveBatchIds();
    this.getBatchQuoteAvailableSummaries();
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_24__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_this.value);
    });
  },
  mounted: function mounted() {},
  methods: {
    highlightSelectedAvailableQuote: function highlightSelectedAvailableQuote() {},
    onAvailableQuotePageChange: function onAvailableQuotePageChange() {},
    onAvailableQuoteSort: function onAvailableQuoteSort(name, order) {
      this.availableQuoteFilter.sortColumn = name;
      this.availableQuoteFilter.sortOrder = order;
      this.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_26___default()(this.availableQuotes, this.availableQuoteFilter.sortColumn, this.availableQuoteFilter.sortOrder);
    },
    getBatchQuoteAvailableSummaries: function getBatchQuoteAvailableSummaries() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var results, newQuoteIds;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this2.isAvailableQuoteTableLoading = true;
              _this2.availableQuotes = null;
              _context.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getBatchQuoteAvailableSummaries(_this2.selectedAvailableBatchId);
            case 1:
              results = _context.v;
              newQuoteIds = _this2.innerValue.quoteIds.filter(function (q) {
                return q.isNew;
              });
              newQuoteIds.forEach(function (q) {
                var index = results.findIndex(function (r) {
                  return r.quoteId === q.quoteId;
                });
                if (index !== -1) {
                  results.splice(index, 1);
                }
              });
              _this2.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_26___default()([].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(results), Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this2.removedQuotes)), _this2.availableQuoteFilter.sortColumn, _this2.availableQuoteFilter.sortOrder);
              _this2.availableQuoteTotalRows = _this2.availableQuotes.length;
              _this2.isAvailableQuoteTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getActiveBatchIds: function getActiveBatchIds() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getActiveBatchIds(_this3.innerValue.batchId);
            case 1:
              _this3.activeBatchIds = _context2.v;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    getAvailableBatch: function getAvailableBatch(batchId) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getEntity(batchId);
            case 1:
              _this4.availableBatch = _context3.v;
              _this4.updateDestinationBatch(_this4.availableBatch.batchId);
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    updateDestinationBatch: function updateDestinationBatch(id) {
      var vm = this;
      this.removedQuotes.forEach(function (q) {
        var quoteId = vm.innerValue.quoteIds.find(function (q) {
          return q.quoteId === q.quoteId;
        });
        quoteId.destinationBatchId = id;
      });
    },
    viewQuote: function viewQuote(quoteId) {
      this.$emit('view-quote', quoteId);
    },
    addToBatch: function addToBatch(index, quote) {
      var existingIndex = this.innerValue.quoteIds.map(function (q) {
        return q.quoteId;
      }).indexOf(quote.quoteId);
      // console.log(existingIndex)
      if (existingIndex === -1) {
        this.innerValue.quoteIds.splice(this.innerValue.quoteIds.length, 1, {
          isDeleted: false,
          isDirty: false,
          isNew: true,
          quoteId: quote.quoteId,
          sourceBatchId: this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty()
        });
        quote.isNew = true;
        if (this.availableBatch) {
          quote.sourceBatchId = this.availableBatch.batchId;
        } else {
          quote.sourceBatchId = _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty();
        }
      } else {
        var quoteId = this.innerValue.quoteIds[existingIndex];
        quoteId.destinationBatchId = _components_Guid__WEBPACK_IMPORTED_MODULE_25__["default"].empty();
        quoteId.isDeleted = false;
      }
      var availableQuoteIndex = this.availableQuotes.map(function (q) {
        return q.quoteId;
      }).indexOf(quote.quoteId);
      this.availableQuotes.splice(availableQuoteIndex, 1);
      this.availableQuoteTotalRows = this.availableQuotes.length;
      this.$emit('quote-added', quote);
    },
    toggleTableLoading: function toggleTableLoading(value) {
      this.isAvailableQuoteTableLoading = value;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.number.is-finite.js */ "./node_modules/core-js/modules/es.number.is-finite.js");
/* harmony import */ var core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_is_finite_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! lodash/orderBy */ "./node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _components_OrmBatchStatistics2__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./components/OrmBatchStatistics2 */ "./src/views/ormbatching/components/OrmBatchStatistics2.vue");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _services_RemarkService__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/services/RemarkService */ "./src/services/RemarkService.js");
/* harmony import */ var _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/components/printpreview/PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_UserProfileIcon_UserProfileIcon__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/components/UserProfileIcon/UserProfileIcon */ "./src/components/UserProfileIcon/UserProfileIcon.vue");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");






































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingAvailableQuotes2',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_25__["default"],
    OrmBatchStatistics: _components_OrmBatchStatistics2__WEBPACK_IMPORTED_MODULE_29__["default"],
    UserProfileIcon: _components_UserProfileIcon_UserProfileIcon__WEBPACK_IMPORTED_MODULE_35__["default"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_36__["default"]
  },
  props: {
    value: null,
    quotes: null,
    removedQuotes: null
  },
  data: function data() {
    return {
      innerValue: null,
      batchedQuotesQuery: '',
      inScopeQuotesQuery: '',
      inProgressQuotesQuery: '',
      outScopeQuotesQuery: '',
      isBatchedQuotesTableLoading: false,
      isInScopeQuotesTableLoading: false,
      isInProgressQuotesTableLoading: false,
      isOutScopeQuotesTableLoading: false,
      batchedQuotesFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      inScopeQuotesFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      inProgressQuotesFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      outScopeQuotesFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      inRangeQuotes: [],
      batchedQuotes: [],
      inScopeQuotes: [],
      inProgressQuotes: [],
      outScopeQuotes: [],
      isNoteModalActive: false,
      notesContent: '',
      showNoteContent: false,
      notes: [],
      maxNotesShow: 3,
      remarkType: _enums__WEBPACK_IMPORTED_MODULE_26__["RemarkTypes"].JcniNote,
      remarkDesc: 'Note',
      tableType: {
        INBATCH: 'In Batch',
        INSCOPE: 'In Scope',
        INPROGRESS: 'In Progress',
        OUTSCOPE: 'Out Scope'
      }
    };
  },
  computed: {
    permission: function permission() {
      var _this$$user$permissio;
      return ((_this$$user$permissio = this.$user.permissions) === null || _this$$user$permissio === void 0 ? void 0 : _this$$user$permissio.find(function (p) {
        return p.codeName === 'A130';
      })) || {}; //ORM Batching
    },
    isCanRead: function isCanRead() {
      return this.permission && this.permission.hasRead;
    },
    isCanAdd: function isCanAdd() {
      return this.permission && this.permission.hasAdd;
    },
    isCanEdit: function isCanEdit() {
      return this.permission && this.permission.hasEdit;
    },
    isCanPrint: function isCanPrint() {
      return this.permission && this.permission.hasPrint;
    },
    isBatchCompleted: function isBatchCompleted() {
      var list = [this.ormBatchStatusType.Completed, this.ormBatchStatusType.Closed];
      return this.value && list.includes(this.value.batchStatus);
    },
    isBatchCanEdit: function isBatchCanEdit() {
      return this.isCanEdit && !this.isBatchCompleted;
    },
    guid: function guid() {
      return _components_Guid__WEBPACK_IMPORTED_MODULE_27__["default"];
    },
    batchingQuoteColumns: function batchingQuoteColumns() {
      return _columns__WEBPACK_IMPORTED_MODULE_23__["BatchingQuoteColumns"];
    },
    alr: function alr() {
      if (this.combinedBatchedQuotes.length === 0) return 0;
      // const batchAgreedTotal = this.batchedQuotes.length * this.innerValue.agreedArc
      // const batchNonLabourTotal = this.batchedQuotes.reduce(function (total, quote) {
      //   return roundAwayFromZero(total + quote.nonLabourTotal)
      // }, 0)
      var batchTotalLabourValue = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      // const batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal
      var batchTotalLabourHour = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      if (!batchTotalLabourHour) return 0;
      var avgLabourRate = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1);
      return avgLabourRate;
    },
    adjustedCombinedAlr: function adjustedCombinedAlr() {
      if (this.combinedBatchedQuotes.length === 0) return 0;
      var batchQuoteCount = this.combinedBatchedQuotes.length;
      var agreedArc = this.innerValue.agreedArc;
      // const batchAgreedTotal = batchQuoteCount * agreedArc
      var batchTotal = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.totalExGST);
      }, 0);
      var batchAvgJobCost = batchTotal / batchQuoteCount;
      var batchAvgDiff = agreedArc - batchAvgJobCost;
      var batchAvgAmountDiff = batchAvgDiff * batchQuoteCount;
      var batchTotalLabourCost = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      // const batchLabourTotal = batchAgreedTotal - batchNonLabourTotal
      var targetAdjustedLaboutCost = batchTotalLabourCost + batchAvgAmountDiff;
      var batchTotalLabourHours = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      if (!batchTotalLabourHours) return 0;
      var adjustedLabourRate = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundUp"])(targetAdjustedLaboutCost / batchTotalLabourHours, 1);
      return adjustedLabourRate;
    },
    adjustedAlr: function adjustedAlr() {
      if (this.batchedQuotes.length === 0) return 0;
      var batchQuoteCount = this.batchedQuotes.length;
      var agreedArc = this.innerValue.agreedArc;
      // const batchAgreedTotal = batchQuoteCount * agreedArc
      var batchTotal = this.batchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.totalExGST);
      }, 0);
      var batchAvgJobCost = batchTotal / batchQuoteCount;
      var batchAvgDiff = agreedArc - batchAvgJobCost;
      var batchAvgAmountDiff = batchAvgDiff * batchQuoteCount;
      var batchTotalLabourCost = this.batchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      // const batchLabourTotal = batchAgreedTotal - batchNonLabourTotal
      var targetAdjustedLaboutCost = batchTotalLabourCost + batchAvgAmountDiff;
      var batchTotalLabourHours = this.batchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      if (!batchTotalLabourHours) return 0;
      var adjustedLabourRate = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundUp"])(targetAdjustedLaboutCost / batchTotalLabourHours, 1);
      return adjustedLabourRate;
    },
    adjustedTotal: function adjustedTotal() {
      if (this.combinedBatchedQuotes.length === 0) {
        return 0;
      }
      var labourHourTotal = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.combinedBatchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.alr);
    },
    // averageLabourUnits() {
    //   if (this.batchedQuotes.length === 0) {
    //     return 0
    //   }
    //   const total = this.batchedQuotes.reduce(function (total, quote) {
    //     return roundAwayFromZero(total + quote.labourHour)
    //   }, 0)
    //   return roundAwayFromZero(total / this.batchedQuotes.length)
    // },
    // averageLabourValues() {
    //   if (this.batchedQuotes.length === 0) {
    //     return 0
    //   }
    //   const total = this.batchedQuotes.reduce(function (total, quote) {
    //     return roundAwayFromZero(total + quote.labourTotal)
    //   }, 0)
    //   return roundAwayFromZero(total / this.batchedQuotes.length)
    // },
    // averageNonLabourValues() {
    //   if (this.batchedQuotes.length === 0) {
    //     return 0
    //   }
    //   const total = this.batchedQuotes.reduce(function (total, quote) {
    //     return roundAwayFromZero(total + quote.nonLabourTotal)
    //   }, 0)
    //   return roundAwayFromZero(total / this.batchedQuotes.length)
    // },
    averageTotalExGst: function averageTotalExGst() {
      if (this.batchedQuotes.length === 0) {
        return 0;
      }
      var total = this.batchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total / this.batchedQuotes.length);
    },
    labourUnitTotal: function labourUnitTotal() {
      var total = this.batchedQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    filteredBatchedQuotes: function filteredBatchedQuotes() {
      var batchedQuotes = this.batchedQuotes;
      if (!batchedQuotes) {
        return null;
      }
      this.toggleBatchedQuotesTableLoading(true);
      var query = this.batchedQuotesQuery.toLowerCase();
      var results = batchedQuotes;
      if (this.batchedQuotesQuery) {
        results = batchedQuotes.filter(function (q) {
          return q.quoteNoRef.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      this.toggleBatchedQuotesTableLoading(false);
      return results;
    },
    filteredInScopeQuotes: function filteredInScopeQuotes() {
      var inScopeQuotes = this.inScopeQuotes;
      if (!inScopeQuotes) {
        return null;
      }
      this.toggleInScopeQuotesTableLoading(true);
      var query = this.inScopeQuotesQuery.toLowerCase();
      var results = inScopeQuotes;
      if (this.inScopeQuotesQuery) {
        results = inScopeQuotes.filter(function (q) {
          return q.quoteNoRef.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      this.toggleInScopeQuotesTableLoading(false);
      return results;
    },
    filteredInProgressQuotes: function filteredInProgressQuotes() {
      var inProgressQuotes = this.inProgressQuotes;
      if (!inProgressQuotes) {
        return null;
      }
      this.toggleInProgressQuotesTableLoading(true);
      var query = this.inProgressQuotesQuery.toLowerCase();
      var results = inProgressQuotes;
      if (this.inProgressQuotesQuery) {
        results = inProgressQuotes.filter(function (q) {
          return q.quoteNoRef.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      this.toggleInProgressQuotesTableLoading(false);
      return results;
    },
    filteredOutScopeQuotes: function filteredOutScopeQuotes() {
      var outScopeQuotes = this.outScopeQuotes;
      if (!outScopeQuotes) {
        return null;
      }
      this.toggleOutScopeQuotesTableLoading(true);
      var query = this.outScopeQuotesQuery.toLowerCase();
      var results = outScopeQuotes;
      if (this.outScopeQuotesQuery) {
        results = outScopeQuotes.filter(function (q) {
          return q.quoteNoRef.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      this.toggleOutScopeQuotesTableLoading(false);
      return results;
    },
    inProgressQuotesAvgCost: function inProgressQuotesAvgCost() {
      var total = this.filteredInProgressQuotes.reduce(function (acc, curr) {
        return acc + (curr.totalExGST || 0);
      }, 0);
      var count = this.filteredBatchedQuotes.length;
      if (count === 0) {
        return 0;
      }
      var avg = total / count;
      return Number.isFinite(avg) ? avg : 0;
    },
    ormQuoteStatusTypes: function ormQuoteStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["OrmQuoteStatusTypes"];
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_26__["OrmBatchStatusType"];
    },
    // innerPerQuoteTotalMin() {
    //   return (this.value.perQuoteTotalMin ?? 0.0).toLocaleString()
    // },
    // innerPerQuoteTotalMax() {
    //   return (this.value.perQuoteTotalMax ?? 0.0).toLocaleString()
    // },
    innerAlrLowerThreshold: function innerAlrLowerThreshold() {
      var _this$value$alrLowerT;
      return ((_this$value$alrLowerT = this.value.alrLowerThreshold) !== null && _this$value$alrLowerT !== void 0 ? _this$value$alrLowerT : 0.0).toLocaleString();
    },
    innerAlrUpperThreshold: function innerAlrUpperThreshold() {
      var _this$value$alrUpperT;
      return ((_this$value$alrUpperT = this.value.alrUpperThreshold) !== null && _this$value$alrUpperT !== void 0 ? _this$value$alrUpperT : 0.0).toLocaleString();
    },
    innerBatchId: function innerBatchId() {
      return this.value.batchId;
    },
    batchedQuotesTotalRows: function batchedQuotesTotalRows() {
      return this.batchedQuotes.length;
    },
    combinedBatchedQuotesTotalRows: function combinedBatchedQuotesTotalRows() {
      return this.combinedBatchedQuotes.length;
    },
    combinedBatchedQuotes: function combinedBatchedQuotes() {
      //combine this.batchedQuotes and this.inScopeQuotes with isChecked == true
      var combined = this.batchedQuotes.concat(this.inScopeQuotes.filter(function (q) {
        return q.isChecked;
      }));
      return combined;
    },
    inScopeQuotesTotalRows: function inScopeQuotesTotalRows() {
      return this.inScopeQuotes.length;
    },
    inProgressQuotesTotalRows: function inProgressQuotesTotalRows() {
      return this.inProgressQuotes.length;
    },
    outScopeQuotesTotalRows: function outScopeQuotesTotalRows() {
      return this.outScopeQuotes.length;
    },
    minBatchSize: function minBatchSize() {
      return this.value.minBatchSize || 0;
    } // batchedQuotes() {
    //   return this.inRangeQuotes.filter((i) => i.batchId == this.innerBatchId)
    // },
    // inScopeQuotes() {
    //   return this.inRangeQuotes.filter((i) => !i.batchId && i.inScope)
    // },
    // outScopeQuotes() {
    //   return this.inRangeQuotes.filter((i) => !i.batchId && !i.inScope)
    // },
    // formatDateLocale(value, locale) {
    //   return this.$filter.customFormatDateLocale(value, locale, { year: 'numeric', month: '2-digit', day: '2-digit' })
    // }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default()(this.value);
    // this.getActiveBatchIds()
    // this.getBatchQuoteAvailableSummaries()
    this.getQuotesInRange();
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_26__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default()(_this.value);
      _this.getQuotesInRange();
    });
  },
  mounted: function mounted() {},
  methods: {
    isRowHighlighted: function isRowHighlighted(quote) {
      var quoteAlr = this.calcAlr(quote);
      var isOutRange = quoteAlr < this.innerAlrLowerThreshold || quoteAlr > this.innerAlrUpperThreshold;
      return isOutRange;
    },
    calcAlr: function calcAlr(quote) {
      var totalLabourHour = quote.labourHour;
      var totalLabourValue = quote.labourTotal;
      // const nonLabourTotal = quote.nonLabourTotal
      // const agreedTotal = this.innerValue.agreedArc
      // const totalLabourValue = agreedTotal - nonLabourTotal
      return totalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundUp"])(totalLabourValue / totalLabourHour, 1) : 0;
    },
    calcAdjustedAlr: function calcAdjustedAlr() {
      // const agreedTotal = this.innerValue.agreedArc
    },
    exportToExcel: function exportToExcel(tableType) {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee() {
        var quotes, totalLabourCost, totalNonLabourCost, totalExGST, totalLabourHour, jobCount, avgLabourRate, avgLabourCost, avgNonLabourCost, avgTotal, adjustedTotal, params, keyValuePairs;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              quotes = [];
              if (tableType == _this2.tableType.INBATCH) {
                quotes = _this2.batchedQuotes;
              }
              if (tableType == _this2.tableType.INSCOPE) {
                quotes = _this2.inScopeQuotes;
              }
              if (tableType == _this2.tableType.INPROGRESS) {
                quotes = _this2.inProgressQuotes;
              }
              if (tableType == _this2.tableType.OUTSCOPE) {
                quotes = _this2.outScopeQuotes;
              }
              totalLabourCost = quotes.reduce(function (sum, quote) {
                return sum + quote.labourTotal;
              }, 0.0);
              totalNonLabourCost = quotes.reduce(function (sum, quote) {
                return sum + quote.nonLabourTotal;
              }, 0.0);
              totalExGST = quotes.reduce(function (sum, quote) {
                return sum + quote.totalExGST;
              }, 0.0);
              totalLabourHour = quotes.reduce(function (sum, quote) {
                return sum + quote.labourHour;
              }, 0.0); // const totalLabourRate = quotes.reduce((sum, quote) => sum + quote.rate, 0.0)
              jobCount = quotes.length; // const avgLabourHours = totalLabourHour / jobCount
              avgLabourRate = totalLabourCost / totalLabourHour;
              avgLabourCost = totalLabourCost / jobCount;
              avgNonLabourCost = totalNonLabourCost / jobCount;
              avgTotal = totalExGST / jobCount;
              adjustedTotal = totalExGST - totalLabourCost + totalLabourHour * _this2.adjustedAlr;
              params = Object.assign({
                CompanyID: _this2.$userInfo.companyId,
                BatchID: _this2.innerValue.batchId,
                QuoteIds: quotes.map(function (q) {
                  return q.quoteId;
                }).join(','),
                BatchNo: _this2.innerValue.batchNo,
                JobCount: jobCount,
                // AvgLabourHours: avgLabourHours.toFixed(2),
                TargetARC: _this2.$filters.formatNumber(_this2.innerValue.agreedArc, _this2.$userInfo.locale),
                AvgLabourRate: _this2.$filters.formatNumberWithRoundUp(avgLabourRate, _this2.$userInfo.locale, 1),
                EstimatedAdjustedLabourRate: _this2.$filters.formatNumber(_this2.adjustedAlr, _this2.$userInfo.locale),
                AvgLabourCost: _this2.$filters.formatNumber(avgLabourCost, _this2.$userInfo.locale),
                AvgNonLabourCost: _this2.$filters.formatNumber(avgNonLabourCost, _this2.$userInfo.locale),
                ActualARC: _this2.$filters.formatNumber(avgTotal, _this2.$userInfo.locale),
                AdjustedTotal: _this2.$filters.formatNumber(adjustedTotal, _this2.$userInfo.locale)
              });
              keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_34__["KeyValuePairModel"].convertToKeyValuePairs(params);
              _context.n = 1;
              return _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_33__["default"].exportReportEx('rptOrmBatchQuotes', 'excel', keyValuePairs);
            case 1:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    handleBatchedCheckboxChange: function handleBatchedCheckboxChange(event) {
      var isChecked = event.target.checked;
      if (!isChecked && this.$refs.batchedQuotesTable.isChecked) {
        this.$refs.batchedQuotesTable.uncheckWithoutReactive();
      }
    },
    handleInScopeCheckboxChange: function handleInScopeCheckboxChange(event) {
      var isChecked = event.target.checked;
      if (!isChecked && this.$refs.inScopeQuotesTable.isChecked) {
        this.$refs.inScopeQuotesTable.uncheckWithoutReactive();
      }
    },
    // handleInProgressCheckboxChange(event) {
    //   const isChecked = event.target.checked
    //   if (!isChecked && this.$refs.inProgressQuotesTable.isChecked) {
    //     this.$refs.inProgressQuotesTable.uncheckWithoutReactive()
    //   }
    // },
    batchedCheckboxChanged: function batchedCheckboxChanged(value) {
      this.batchedQuotes = this.batchedQuotes.map(function (i) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, i), {}, {
          isChecked: !!value
        });
      });
    },
    inScopeCheckboxChanged: function inScopeCheckboxChanged(value) {
      this.inScopeQuotes = this.inScopeQuotes.map(function (i) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, i), {}, {
          isChecked: !!value
        });
      });
    },
    inProgressCheckboxChanged: function inProgressCheckboxChanged(value) {
      this.inProgressQuotes = this.inProgressQuotes.map(function (i) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, i), {}, {
          isChecked: !!value
        });
      });
    },
    outScopeCheckboxChanged: function outScopeCheckboxChanged(value) {
      this.outScopeQuotes = this.outScopeQuotes.map(function (i) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, i), {}, {
          isChecked: !!value
        });
      });
    },
    getQuotesInRange: function getQuotesInRange() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee2() {
        var quotes;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__["default"].getOrmBatchingQuotesInRange(_this3.innerBatchId);
            case 1:
              quotes = _context2.v;
              _this3.inRangeQuotes = quotes;
              _this3.reassignQuotes();
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    highlightSelectedAvailableQuote: function highlightSelectedAvailableQuote() {},
    onBatchedQuotesSort: function onBatchedQuotesSort(name, order) {
      this.batchedQuotesFilter.sortColumn = name;
      this.batchedQuotesFilter.sortOrder = order;
      this.batchedQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default()(this.batchedQuotes, this.batchedQuotesFilter.sortColumn, this.batchedQuotesFilter.sortOrder);
    },
    onInProgressQuotesSort: function onInProgressQuotesSort(name, order) {
      this.inProgressQuotesFilter.sortColumn = name;
      this.inProgressQuotesFilter.sortOrder = order;
      this.inProgressQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default()(this.inProgressQuotes, this.inProgressQuotesFilter.sortColumn, this.inProgressQuotesFilter.sortOrder);
    },
    onInScopeQuotesSort: function onInScopeQuotesSort(name, order) {
      this.inScopeQuotesFilter.sortColumn = name;
      this.inScopeQuotesFilter.sortOrder = order;
      this.inScopeQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default()(this.inScopeQuotes, this.inScopeQuotesFilter.sortColumn, this.inScopeQuotesFilter.sortOrder);
    },
    onOutScopeQuotesSort: function onOutScopeQuotesSort(name, order) {
      this.outScopeQuotesFilter.sortColumn = name;
      this.outScopeQuotesFilter.sortOrder = order;
      this.outScopeQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default()(this.outScopeQuotes, this.outScopeQuotesFilter.sortColumn, this.outScopeQuotesFilter.sortOrder);
    },
    viewQuote: function viewQuote(quoteId) {
      this.$emit('view-quote', quoteId);
    },
    // addToBatch(index, quote) {
    //   const existingIndex = this.innerValue.quoteIds
    //     .map((q) => {
    //       return q.quoteId
    //     })
    //     .indexOf(quote.quoteId)
    //   // console.log(existingIndex)
    //   if (existingIndex === -1) {
    //     this.innerValue.quoteIds.splice(this.innerValue.quoteIds.length, 1, {
    //       isDeleted: false,
    //       isDirty: false,
    //       isNew: true,
    //       quoteId: quote.quoteId,
    //       sourceBatchId: this.availableBatch ? this.availableBatch.batchId : Guid.empty()
    //     })
    //     quote.isNew = true
    //     if (this.availableBatch) {
    //       quote.sourceBatchId = this.availableBatch.batchId
    //     } else {
    //       quote.sourceBatchId = Guid.empty()
    //     }
    //   } else {
    //     const quoteId = this.innerValue.quoteIds[existingIndex]
    //     quoteId.destinationBatchId = Guid.empty()
    //     quoteId.isDeleted = false
    //   }
    //   const availableQuoteIndex = this.availableQuotes
    //     .map((q) => {
    //       return q.quoteId
    //     })
    //     .indexOf(quote.quoteId)
    //   this.availableQuotes.splice(availableQuoteIndex, 1)
    //   this.availableQuoteTotalRows = this.availableQuotes.length
    //   this.$emit('quote-added', quote)
    // },
    removeRangeToBatch: function removeRangeToBatch() {
      var checkedBatchedQuotes = this.batchedQuotes.filter(function (i) {
        return i.isChecked;
      });
      this.removeFromBatch(0, checkedBatchedQuotes);
    },
    addRangeToBatch: function addRangeToBatch(tableType) {
      if (tableType == this.tableType.INSCOPE) {
        var checkedInScopeQuotes = this.inScopeQuotes.filter(function (i) {
          return i.isChecked;
        });
        this.addToBatch(0, checkedInScopeQuotes);
      }
      if (tableType == this.tableType.INPROGRESS) {
        var checkedInProgressQuotes = this.inProgressQuotes.filter(function (i) {
          return i.isChecked;
        });
        this.addToBatch(0, checkedInProgressQuotes);
      }
    },
    addToBatch: function addToBatch(index, quotes) {
      var _this4 = this;
      var cnt = 0;
      quotes.forEach(function (quote) {
        var selectedQuote = _this4.inRangeQuotes.find(function (i) {
          return i.quoteId == quote.quoteId;
        });
        if (selectedQuote) {
          selectedQuote.batchId = _this4.innerValue.batchId;
          selectedQuote.batchNo = _this4.innerValue.batchNo;
          selectedQuote.isChecked = false;
          var existingIndex = _this4.innerValue.quoteIds.map(function (q) {
            return q.quoteId;
          }).indexOf(quote.quoteId);
          // console.log(existingIndex)
          if (existingIndex === -1) {
            _this4.innerValue.quoteIds.splice(_this4.innerValue.quoteIds.length, 1, {
              isDeleted: false,
              isDirty: false,
              isNew: true,
              quoteId: quote.quoteId,
              sourceBatchId: _components_Guid__WEBPACK_IMPORTED_MODULE_27__["default"].empty()
            });
          } else {
            var quoteId = _this4.innerValue.quoteIds[existingIndex];
            quoteId.destinationBatchId = _components_Guid__WEBPACK_IMPORTED_MODULE_27__["default"].empty();
            quoteId.isDeleted = false;
          }
          cnt++;
        }
      });
      if (cnt > 0) {
        this.$notification.success('Add To Batch', "Added ".concat(cnt, " quotes to batch successfully."));
        this.reassignQuotes();
      }
      // this.$emit('quote-added', quotes[0])
    },
    removeFromBatch: function removeFromBatch(index, quotes) {
      var _this5 = this;
      var cnt = 0;
      quotes.forEach(function (quote) {
        var selectedQuote = _this5.inRangeQuotes.find(function (i) {
          return i.quoteId == quote.quoteId;
        });
        if (selectedQuote) {
          selectedQuote.batchId = null;
          selectedQuote.batchNo = null;
          selectedQuote.isChecked = false;
          var existingIndex = _this5.innerValue.quoteIds.findIndex(function (q) {
            return q.quoteId === quote.quoteId;
          });
          if (existingIndex !== -1) {
            // Remove the quote from the array
            _this5.innerValue.quoteIds.splice(existingIndex, 1);
          }
          cnt++;
        }
      });
      if (cnt > 0) {
        this.$notification.success('Remove From Batch', "Remove ".concat(cnt, " quotes from batch successfully."));
        this.reassignQuotes();
      }
      // this.$emit('quote-removed', quotes[0])
    },
    reassignQuotes: function reassignQuotes() {
      var _this6 = this;
      this.batchedQuotes = this.inRangeQuotes.filter(function (i) {
        return i.batchId == _this6.innerBatchId;
      });
      this.inScopeQuotes = this.inRangeQuotes.filter(function (i) {
        return !i.batchId && i.inScope && i.quoteStatus == 'Completed';
      });
      this.inProgressQuotes = this.inRangeQuotes.filter(function (i) {
        return !i.batchId && i.inScope && i.quoteStatus == 'In Progress';
      });
      this.outScopeQuotes = this.inRangeQuotes.filter(function (i) {
        return !i.batchId && !i.inScope;
      });
      if (!this.batchedQuotes.length) {
        if (this.$refs.batchedQuotesTable) {
          this.$refs.batchedQuotesTable.uncheckWithoutReactive();
        }
      }
      if (!this.inScopeQuotes.length) {
        if (this.$refs.inScopeQuotesTable) {
          this.$refs.inScopeQuotesTable.uncheckWithoutReactive();
        }
      }
      // if (!this.inProgressQuotes.length) {
      //   if (this.$refs.inProgressQuotesTable) {
      //     this.$refs.inProgressQuotesTable.uncheckWithoutReactive()
      //   }
      // }
    },
    toggleBatchedQuotesTableLoading: function toggleBatchedQuotesTableLoading(value) {
      this.isBatchedQuotesTableLoading = value;
    },
    toggleInScopeQuotesTableLoading: function toggleInScopeQuotesTableLoading(value) {
      this.isInScopeQuotesTableLoading = value;
    },
    toggleInProgressQuotesTableLoading: function toggleInProgressQuotesTableLoading(value) {
      this.isInProgressQuotesTableLoading = value;
    },
    toggleOutScopeQuotesTableLoading: function toggleOutScopeQuotesTableLoading(value) {
      this.isOutScopeQuotesTableLoading = value;
    },
    resetNotesContent: function resetNotesContent() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this7.showNoteContent = false;
              _this7.notesContent = '';
              _this7.notes = [];
            case 1:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getNotesContent: function getNotesContent(isNoteExists, quoteId) {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_2__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (!isNoteExists) {
                _context4.n = 2;
                break;
              }
              _this8.notesContent = '';
              _this8.showNoteContent = true;
              _context4.n = 1;
              return _services_RemarkService__WEBPACK_IMPORTED_MODULE_32__["default"].getRemarkEntities(quoteId, _enums__WEBPACK_IMPORTED_MODULE_26__["RemarkTypes"].JcniNote);
            case 1:
              _this8.notes = _context4.v;
              _this8.notes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_28___default()(_this8.notes, 'createdDate', 'desc');
              _this8.notes = _this8.notes.splice(0, _this8.maxNotesShow);
              _this8.$nextTick(function () {
                _this8.notesContent = _this8.$refs['notesList'].innerHTML;
              });
              _context4.n = 3;
              break;
            case 2:
              _this8.resetNotesContent();
            case 3:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    notesClick: function notesClick(quoteId, jobNo) {
      this.selectedQuoteId = quoteId;
      this.selectedJobNo = jobNo;
      this.isNoteModalActive = true;
    },
    closeNoteModal: function closeNoteModal(entity) {
      var _this9 = this;
      if (entity.length !== 0) {
        var index = this.jcniRecords.findIndex(function (i) {
          return i.quoteId === _this9.selectedQuoteId;
        });
        if (index !== -1) {
          this.jcniRecords[index].isNoteExists = true;
          // this.jcniRecords[index].notes = entity
        }
      }
      this.isNoteModalActive = false;
    },
    delta: function delta(quote) {
      return this.innerValue.agreedArc - quote.totalExGST;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! vuedraggable */ "./node_modules/vuedraggable/dist/vuedraggable.umd.js");
/* harmony import */ var vuedraggable__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(vuedraggable__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/orderBy */ "./node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./OrmBatchingMixin */ "./src/views/ormbatching/OrmBatchingMixin.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./components/OrmBatchStatistics */ "./src/views/ormbatching/components/OrmBatchStatistics.vue");

































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingDetail',
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_23__["default"],
    draggable: vuedraggable__WEBPACK_IMPORTED_MODULE_24___default.a,
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_25__["default"],
    OrmBatchStatistics: _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_32__["default"]
  },
  mixins: [_OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_30__["default"]],
  props: {
    value: null,
    isAddQuoteActive: false
  },
  data: function data() {
    return {
      innerValue: null,
      entities: null,
      animationDuration: 200,
      // quotes: null,
      totalRows: 0,
      isTableLoading: false,
      isRowDraggable: true,
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["BatchQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["BatchQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      availableQuotes: null,
      availableQuoteQuery: '',
      availableQuoteTotalRows: 0,
      isAvailableQuoteTableLoading: false,
      isAvailableQuoteRowDraggable: true,
      availableQuoteDrag: false,
      availableQuoteFilter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      // isAddQuote: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      batchDate: new Date(),
      totalLowerLimit: 0,
      totalUpperLimit: 0,
      activeBatchIds: null,
      selectedAvailableBatchId: _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty(),
      availableBatch: null
    };
  },
  computed: {
    guid: function guid() {
      return _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"];
    },
    batchQuoteColumns: function batchQuoteColumns() {
      var columns = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_columns__WEBPACK_IMPORTED_MODULE_21__["BatchQuoteColumns"]);
      columns[12].isVisible = this.isInvoiceColumnVisible;
      if (!this.isAddQuoteActive) {
        return columns;
      } else {
        columns[1].isVisible = false; // ClaimNo
        columns[3].isVisible = false; // Customer Name
        columns[4].isVisible = false; // Excess
        columns[13].isVisible = false; // QuoteStatus
        columns[14].isVisible = false; // QDEStatus
        return columns;
      }
    },
    isInvoiceColumnVisible: function isInvoiceColumnVisible() {
      return this.innerValue.batchStatus === _enums__WEBPACK_IMPORTED_MODULE_28__["OrmBatchStatusType"].Completed || this.innerValue.batchStatus === _enums__WEBPACK_IMPORTED_MODULE_28__["OrmBatchStatusType"].Closed;
    },
    isSubmitQuoteButtonActive: function isSubmitQuoteButtonActive() {
      var active = this.innerValue.batchStatus !== _enums__WEBPACK_IMPORTED_MODULE_28__["OrmBatchStatusType"].Completed && this.innerValue.batchStatus !== _enums__WEBPACK_IMPORTED_MODULE_28__["OrmBatchStatusType"].Closed;
      return active && !this.snapshotDiff && !this.isAddQuoteActive;
    },
    availableQuoteColumns: function availableQuoteColumns() {
      return _columns__WEBPACK_IMPORTED_MODULE_21__["AvailableQuoteColumns"];
    },
    availableQuoteDragOptions: function availableQuoteDragOptions() {
      return {
        animation: 200,
        group: 'quotes',
        disabled: false,
        ghostClass: 'ghost'
      };
    },
    alr: function alr() {
      if (this.entities.length === 0) {
        return 0;
      }
      var batchTotalLabourHour = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var batchNonLabourTotal = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      var batchAgreedTotal = this.entities.length * this.innerValue.agreedArc;
      // console.log(this.entities.length, batchTotalLabourHour, batchNonLabourTotal, batchAgreedTotal)
      var batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal;
      return batchTotalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1) : 0;
    },
    availableAlr: function availableAlr() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var batchTotalLabourHour = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var batchNonLabourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      var batchAgreedTotal = this.availableQuotes.length * this.availableBatch.agreedArc;
      var batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal;
      return batchTotalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1) : 0;
    },
    adjustedTotal: function adjustedTotal() {
      if (this.entities.length === 0) {
        return 0;
      }
      var labourHourTotal = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.alr);
    },
    availableAdjustedTotal: function availableAdjustedTotal() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var labourHourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.availableAlr);
    },
    averageLabourUnits: function averageLabourUnits() {
      if (this.entities.length === 0) {
        return 0;
      }
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.entities.length);
    },
    availableAverageLabourUnits: function availableAverageLabourUnits() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    averageLabourValues: function averageLabourValues() {
      if (this.entities.length === 0) {
        return 0;
      }
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.entities.length);
    },
    availableAverageLabourValues: function availableAverageLabourValues() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    averageNonLabourValues: function averageNonLabourValues() {
      if (this.entities.length === 0) {
        return 0;
      }
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.entities.length);
    },
    availableAverageNonLabourValues: function availableAverageNonLabourValues() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    averageTotalExGst: function averageTotalExGst() {
      if (this.entities.length === 0) {
        return 0;
      }
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.entities.length);
    },
    availableAverageTotalExGst: function availableAverageTotalExGst() {
      if (!this.availableQuotes || this.availableQuotes.length === 0) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total / this.availableQuotes.length);
    },
    labourUnitTotal: function labourUnitTotal() {
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    availableLabourUnitTotal: function availableLabourUnitTotal() {
      if (!this.availableQuotes) {
        return 0;
      }
      var total = this.availableQuotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    labourValueTotal: function labourValueTotal() {
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.labourValue);
      }, 0);
      return total;
    },
    batchTotal: function batchTotal() {
      var total = this.entities.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_26__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return total;
    },
    filteredAvailableQuotes: function filteredAvailableQuotes() {
      var _this = this;
      if (!this.isAddQuoteActive || !this.availableQuotes) {
        return null;
      }
      var query = this.availableQuoteQuery.toLowerCase();
      var results = this.availableQuotes;
      if (this.availableQuoteQuery) {
        results = this.availableQuotes.filter(function (q) {
          return q.quoteNo.toLowerCase().includes(query) || q.rego.toLowerCase().includes(query);
        });
      }
      if (this.totalLowerLimit) {
        results = results.filter(function (q) {
          return q.totalExGst >= _this.totalLowerLimit;
        });
      }
      if (this.totalUpperLimit) {
        results = results.filter(function (q) {
          return q.totalExGst <= _this.totalUpperLimit;
        });
      }
      return results;
    },
    ormQuoteStatusTypes: function ormQuoteStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_28__["OrmQuoteStatusTypes"];
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_28__["OrmBatchStatusType"];
    }
  },
  watch: {
    isAddQuoteActive: function isAddQuoteActive(newVal, oldVal) {
      if (newVal) {
        this.availableQuoteQuery = '';
        this.getActiveBatchIds();
        // console.log(this.selectedAvailableBatchId)
        this.getBatchQuoteAvailableSummaries();
      } else {
        this.availableQuoteQuery = '';
        this.availableQuotes = null;
        this.availableQuoteTotalRows = 0;
      }
    },
    batchDate: function batchDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.batchDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.batchDate = null;
      }
    },
    selectedAvailableBatchId: function selectedAvailableBatchId(newVal, oldVal) {
      this.getBatchQuoteAvailableSummaries();
      if (newVal !== _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty()) {
        console.log(newVal);
        this.getAvailableBatch(newVal);
      } else {
        this.availableBatch = null;
      }
    }
  },
  created: function created() {
    this.innerValue = this.value;
    this.batchDate = new Date("".concat(this.innerValue.batchDate));
    this.getBatchQuoteSummaries();
  },
  mounted: function mounted() {
    var _this2 = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_28__["EventHubTypes"].EntitySaved, function () {
      console.log('EventHubTypes.EntitySaved');
      _this2.innerValue = _this2.value;
      _this2.getBatchQuoteSummaries();
    });
  },
  methods: {
    highlightSelected: function highlightSelected() {},
    onPageChange: function onPageChange() {},
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.entities, this.filter.sortColumn, this.filter.sortOrder);
    },
    itemMoved: function itemMoved(event) {
      console.log(event);
      if (event.added) {
        var quote = event.added.element;
        var existingIndex = this.innerValue.quoteIds.map(function (q) {
          return q.quoteId;
        }).indexOf(quote.quoteId);
        // console.log(existingIndex, quote.quoteId)
        if (existingIndex === -1) {
          this.innerValue.quoteIds.splice(this.innerValue.quoteIds.length, 1, {
            isDeleted: false,
            isDirty: false,
            isNew: true,
            quoteId: quote.quoteId,
            sourceBatchId: this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty()
          });
          quote.isNew = true;
          if (this.availableBatch) {
            quote.sourceBatchId = this.availableBatch.batchId;
          } else {
            quote.sourceBatchId = _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty();
          }
        } else {
          var quoteId = this.innerValue.quoteIds[existingIndex];
          quoteId.isDeleted = false;
          quoteId.destinationBatchId = this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty();
          this.innerValue.quoteIds.splice(existingIndex, 1, quoteId);
        }
      } else if (event.removed) {
        var _quote = event.removed.element;
        var _existingIndex = this.innerValue.quoteIds.map(function (q) {
          return q.quoteId;
        }).indexOf(_quote.quoteId);
        console.log(_existingIndex, _quote.quoteId);
        if (_existingIndex === -1) {} else {
          var _quoteId = this.innerValue.quoteIds[_existingIndex];
          if (_quoteId.isNew) {
            this.innerValue.quoteIds.splice(_existingIndex, 1);
          } else {
            _quoteId.isDeleted = true;
          }
        }
      }
    },
    endMove: function endMove() {
      // console.log('endMove')
      this.totalRows = this.entities.length;
      this.availableQuoteTotalRows = this.availableQuotes.length;
      this.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.availableQuotes, this.availableQuoteFilter.sortColumn, this.availableQuoteFilter.sortOrder);
      this.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.entities, this.filter.sortColumn, this.filter.sortOrder);
      // this.availableQuoteFilter.sortColumn = ''
      // this.availableQuoteFilter.sortOrder = ''
    },
    highlightSelectedAvailableQuote: function highlightSelectedAvailableQuote() {},
    onAvailableQuotePageChange: function onAvailableQuotePageChange() {},
    onAvailableQuoteSort: function onAvailableQuoteSort(name, order) {
      this.availableQuoteFilter.sortColumn = name;
      this.availableQuoteFilter.sortOrder = order;
      this.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.availableQuotes, this.availableQuoteFilter.sortColumn, this.availableQuoteFilter.sortOrder);
    },
    onAvailableQuoteMoved: function onAvailableQuoteMoved() {},
    onAvailableQuoteStartMove: function onAvailableQuoteStartMove() {
      this.availableQuoteDrag = true;
    },
    onAvailableQuoteEndMove: function onAvailableQuoteEndMove(event) {
      // console.log('onAvailableQuoteEndMove', this.entities.length)
      this.totalRows = this.entities.length;
      this.availableQuoteTotalRows = this.availableQuotes.length;
      this.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.availableQuotes, this.availableQuoteFilter.sortColumn, this.availableQuoteFilter.sortOrder);
      this.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.entities, this.filter.sortColumn, this.filter.sortOrder);
      // this.filter.sortColumn = ''
      // this.filter.sortOrder = ''
      // this.entities = _orderBy(this.entities, this.filter.sortColumn, this.filter.sortOrder)
    },
    addToBatch: function addToBatch(index, quote) {
      var existingIndex = this.innerValue.quoteIds.map(function (q) {
        return q.quoteId;
      }).indexOf(quote.quoteId);
      // console.log(existingIndex)
      if (existingIndex === -1) {
        this.innerValue.quoteIds.splice(this.innerValue.quoteIds.length, 1, {
          isDeleted: false,
          isDirty: false,
          isNew: true,
          quoteId: quote.quoteId,
          sourceBatchId: this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty()
        });
        quote.isNew = true;
        if (this.availableBatch) {
          quote.sourceBatchId = this.availableBatch.batchId;
        } else {
          quote.sourceBatchId = _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty();
        }
      } else {
        var quoteId = this.innerValue.quoteIds[existingIndex];
        quoteId.isDeleted = false;
      }
      this.entities.splice(this.entities.length, 1, quote);
      this.availableQuotes.splice(index, 1);
      this.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.entities, this.filter.sortColumn, this.filter.sortOrder);
      this.totalRows = this.entities.length;
      this.availableQuoteTotalRows = this.availableQuotes.length;
    },
    removeFromBatch: function removeFromBatch(index, quote) {
      var existingIndex = this.innerValue.quoteIds.map(function (q) {
        return q.quoteId;
      }).indexOf(quote.quoteId);
      if (existingIndex >= 0) {
        var quoteId = this.innerValue.quoteIds[existingIndex];
        if (quoteId.isNew) {
          this.innerValue.quoteIds.splice(existingIndex, 1);
        } else {
          quoteId.isDeleted = true;
          quoteId.destinationBatchId = this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_31__["default"].empty();
        }
      } else {}
      this.availableQuotes.splice(this.availableQuotes.length, 1, quote);
      this.entities.splice(index, 1);
      this.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.availableQuotes, this.availableQuoteFilter.sortColumn, this.availableQuoteFilter.sortOrder);
      this.totalRows = this.entities.length;
      this.availableQuoteTotalRows = this.availableQuotes.length;
    },
    getBatchQuoteSummaries: function getBatchQuoteSummaries() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var results, vm;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this3.isTableLoading = true;
              // const results = await OrmBatchingService.getBatchQuoteSummaries(this.innerValue.batchId)
              _context.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getBatchQuoteSummariesByIds(_this3.innerValue.batchId, _this3.innerValue.quoteIds.map(function (q) {
                return q.quoteId;
              }));
            case 1:
              results = _context.v;
              _this3.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(results, _this3.filter.sortColumn, _this3.filter.sortOrder);
              vm = _this3;
              _this3.innerValue.quoteIds.forEach(function (q) {
                if (q.isNew) {
                  var entity = vm.entities.find(function (e) {
                    return e.quoteId === q.quoteId;
                  });
                  if (entity) {
                    entity.isNew = q.isNew;
                  }
                }
              });
              _this3.totalRows = _this3.entities.length;
              _this3.isTableLoading = false;
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    getActiveBatchIds: function getActiveBatchIds() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _context2.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getActiveBatchIds(_this4.innerValue.batchId);
            case 1:
              _this4.activeBatchIds = _context2.v;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    closeAvailableQuotes: function closeAvailableQuotes() {
      // this.$emit('add-quote', false)
      this.$emit('update:isAddQuoteActive', false);
      // this.isAddQuote = false
      this.availableQuoteQuery = '';
      this.availableQuotes = null;
      this.availableQuoteTotalRows = 0;
    },
    getBatchQuoteAvailableSummaries: function getBatchQuoteAvailableSummaries() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var results, newQuoteIds;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this5.isAvailableQuoteTableLoading = true;
              _this5.availableQuotes = null;
              _context3.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getBatchQuoteAvailableSummaries(_this5.selectedAvailableBatchId);
            case 1:
              results = _context3.v;
              newQuoteIds = _this5.innerValue.quoteIds.filter(function (q) {
                return q.isNew;
              });
              newQuoteIds.forEach(function (q) {
                var index = results.findIndex(function (r) {
                  return r.quoteId === q.quoteId;
                });
                if (index !== -1) {
                  results.splice(index, 1);
                }
              });
              _this5.availableQuotes = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(results, _this5.availableQuoteFilter.sortColumn, _this5.availableQuoteFilter.sortOrder);
              _this5.availableQuoteTotalRows = _this5.availableQuotes.length;
              _this5.isAvailableQuoteTableLoading = false;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    delta: function delta(quote) {
      return quote.totalExGst - this.innerValue.agreedArc;
    },
    viewQuote: function viewQuote(quoteId) {
      this.$emit('view-quote', quoteId);
    },
    getPropertyNameByValue: function getPropertyNameByValue(object, value) {
      return Object.keys(object)[Object.values(object).findIndex(function (i) {
        return i === value;
      })];
    },
    getAvailableBatch: function getAvailableBatch(batchId) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _context4.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_22__["default"].getEntity(batchId);
            case 1:
              _this6.availableBatch = _context4.v;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmBatchingMixin */ "./src/views/ormbatching/OrmBatchingMixin.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmMessageListSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  mixins: [_OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_2__["default"]],
  props: {
    value: null
  },
  data: function data() {
    return {
      innerValue: this.value,
      selectedBatchDate: null,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_1__["OrmBatchStatusType"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    value: {
      handler: function handler(newVal, oldVal) {
        this.innerValue = this.value;
      },
      deep: true
    },
    selectedBatchDate: function selectedBatchDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.batchDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.batchDate = null;
      }
    }
  },
  created: function created() {
    if (this.value.batchDate) {
      this.selectedBatchDate = new Date(this.value.batchDate);
    }
  },
  mounted: function mounted() {},
  methods: {
    onFilterClick: function onFilterClick() {
      this.$emit('filter');
    },
    onResetClick: function onResetClick() {
      this.selectedBatchDate = null;
      this.$emit('reset');
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _OrmBatchingListSideMenu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./OrmBatchingListSideMenu */ "./src/views/ormbatching/OrmBatchingListSideMenu.vue");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./storeMixin */ "./src/views/ormbatching/storeMixin.js");
/* harmony import */ var _OrmBatchingNewModal_vue__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./OrmBatchingNewModal.vue */ "./src/views/ormbatching/OrmBatchingNewModal.vue");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/printpreview/PrintPreviewService */ "./src/components/printpreview/PrintPreviewService.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./route-types */ "./src/views/ormbatching/route-types.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31__);





























// import InsurerRoutes from '@/views/insurer/route-types'




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingListView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_19__["default"],
    OrmBatchingListSideMenu: _OrmBatchingListSideMenu__WEBPACK_IMPORTED_MODULE_20__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_21__["default"],
    OrmBatchingNewModal: _OrmBatchingNewModal_vue__WEBPACK_IMPORTED_MODULE_27__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_26__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_23__["DateTimeFiltersMixin"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_23__["NumberFiltersMixin"]],
  props: {},
  data: function data() {
    return {
      isTableLoading: false,
      totalRows: 0,
      selectedRow: null,
      filter: {
        batchNo: null,
        batchDate: '',
        batchStatus: 0,
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 18
      },
      entities: null,
      isNewBatchModalActive: false,
      entity: null
    };
  },
  computed: {
    permission: function permission() {
      var _this$$user$permissio;
      return ((_this$$user$permissio = this.$user.permissions) === null || _this$$user$permissio === void 0 ? void 0 : _this$$user$permissio.find(function (p) {
        return p.codeName === 'A130';
      })) || {}; //ORM Batching
    },
    isCanRead: function isCanRead() {
      return this.permission && this.permission.hasRead;
    },
    isCanAdd: function isCanAdd() {
      return this.permission && this.permission.hasAdd;
    },
    isCanEdit: function isCanEdit() {
      return this.permission && this.permission.hasEdit;
    },
    isCanPrint: function isCanPrint() {
      return this.permission && this.permission.hasPrint;
    },
    columns: function columns() {
      var columns = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_31___default()(_columns__WEBPACK_IMPORTED_MODULE_22__["Columns"]);
      var actionColumn = columns.find(function (col) {
        return col.name === 'action';
      });
      actionColumn.isVisible = this.isCanRead;
      return columns;
    },
    filterKey: function filterKey() {
      if (this.$userInfo) {
        return "".concat(this.$userInfo.sessionId, "|").concat(this.$route.meta.fkey);
      } else {
        return '';
      }
    },
    completedStatus: function completedStatus() {
      var status = [_enums__WEBPACK_IMPORTED_MODULE_24__["OrmBatchStatusType"].Completed, _enums__WEBPACK_IMPORTED_MODULE_24__["OrmBatchStatusType"].Closed];
      return Object.values(status);
    }
  },
  watch: {},
  created: function created() {
    this.getEntitySummaries();
    if (this.entity === null) {
      this.entity = {
        minBatchSize: 0,
        perQuoteTotalMin: 0,
        perQuoteTotalMax: 0,
        alrLowerThreshold: 0,
        alrUpperThreshold: 0,
        agreedArc: 0
      };
    }
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      var _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _t = action;
              _context.n = _t === _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].AddNew ? 1 : _t === _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Print ? 3 : _t === _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Delete ? 4 : _t === _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Save ? 5 : _t === _enums__WEBPACK_IMPORTED_MODULE_24__["AppHeaderButtonTypes"].Cancel ? 6 : 7;
              break;
            case 1:
              _context.n = 2;
              return _this.addNewClick();
            case 2:
              return _context.a(3, 7);
            case 3:
              return _context.a(3, 7);
            case 4:
              return _context.a(3, 7);
            case 5:
              return _context.a(3, 7);
            case 6:
              return _context.a(3, 7);
            case 7:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    highlightSelected: function highlightSelected(index, event) {},
    onPageChange: function onPageChange(pageIndex) {
      this.filter.pageIndex = pageIndex;
      this.persistFilter();
      this.getEntitySummaries();
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.persistFilter();
      this.getEntitySummaries();
    },
    filterList: function filterList() {
      this.filter.pageIndex = 1;
      this.persistFilter();
      this.getEntitySummaries();
    },
    resetList: function resetList() {
      this.filter.batchNo = null;
      this.filter.batchStatus = 0;
      this.filter.batchDate = '';
      this.filter.messageTypeId = 0;
      this.filter.sortColumn = _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][0].name;
      this.filter.sortOrder = _columns__WEBPACK_IMPORTED_MODULE_22__["Columns"][0].defaultOrder;
      this.filter.pageIndex = 1;
      this.filter.pageSize = 18;
      this.persistFilter();
      this.getEntitySummaries();
    },
    persistFilter: function persistFilter() {
      sessionStorage.setItem(this.filterKey, JSON.stringify(this.filter));
    },
    retrieveFilter: function retrieveFilter() {
      var filter = JSON.parse(sessionStorage.getItem(this.filterKey));
      if (filter) {
        this.filter = filter;
      }
    },
    getEntitySummaries: function getEntitySummaries() {
      var _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              _this2.isTableLoading = true;
              _this2.retrieveFilter();
              _context2.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_25__["default"].getEntitySummaries(_this2.filter);
            case 1:
              _this2.entities = _context2.v;
              _this2.totalRows = _this2.entities.length > 0 ? _this2.entities[0].totalRows : 0;
              _this2.isTableLoading = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    delta: function delta(batch) {
      return batch.averageRepairCost - batch.agreedArc;
    },
    addNewClick: function addNewClick() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _context3.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_25__["default"].getNewEntity();
            case 1:
              _this3.entity = _context3.v;
              // this.addStoreItem()
              // const entity = this.get

              _this3.isNewBatchModalActive = true;
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    // async addNew() {
    //   this.addStoreItem()
    // },
    closeNewBatchModal: function closeNewBatchModal() {
      this.isNewBatchModalActive = false;
    },
    handleAddNewBatch: function handleAddNewBatch() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var utcDate, result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              if (!_this4.entity) {
                _context4.n = 2;
                break;
              }
              utcDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).toISOString();
              _this4.entity.batchDate = utcDate.split('.')[0] + 'Z';
              _context4.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_25__["default"].postEntity(_this4.entity);
            case 1:
              result = _context4.v;
              _this4.$router.push({
                path: _route_types__WEBPACK_IMPORTED_MODULE_30__["default"].OrmBatchingView2.path.replace(':batchId', result.batchId)
              });
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    // handleInsurerClick(insurerId) {
    //   var route = InsurerRoutes.InsurerView.path.replace(':insurerId', insurerId)
    //   this.$router.push(`${route}`)
    // },
    exportToExcel: function exportToExcel(batchId) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var batchQuotes, params, keyValuePairs;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              _context5.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_25__["default"].getEntity(batchId);
            case 1:
              batchQuotes = _context5.v;
              params = Object.assign({
                CompanyID: _this5.$userInfo.companyId,
                BatchID: batchId,
                QuoteIds: batchQuotes.quoteIds.map(function (q) {
                  return q.quoteId;
                }).join(',')
              });
              keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_28__["KeyValuePairModel"].convertToKeyValuePairs(params);
              _context5.n = 2;
              return _components_printpreview_PrintPreviewService__WEBPACK_IMPORTED_MODULE_29__["default"].exportReportEx('rptOrmBatchQuotes', 'excel', keyValuePairs);
            case 2:
              return _context5.a(2);
          }
        }, _callee5);
      }))();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");




// import Multiselect from 'vue-multiselect'
// import OrmBatchingService from './OrmBatchingService'
// import _debounce from 'lodash.debounce'

// import _cloneDeep from 'lodash/cloneDeep'

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingNewModal',
  components: {
    BaseModalEx: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_3__["BaseModalEx"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  props: {
    value: null,
    active: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'zoomIn'
    },
    animationOut: {
      type: String,
      default: 'zoomOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    return {
      // innerValue: {},
      isActive: false
      // insurers: [],
      // isInsurerLoading: false,
      // selectedInsurer: null,
      // selectedBatchType: null
    };
  },
  computed: {},
  watch: {
    // value: {
    //   handler: function (newVal, oldVal) {
    //     this.innerValue = _cloneDeep(newVal)
    //   }
    // },
    active: {
      handler: function handler(newVal, oldVal) {
        this.isActive = newVal;
        if (this.isActive) {
          // this.setBatchType()
          // if (this.value && this.value.quoteSystemType) {
          //   this.value.quoteSystemType = CompanyQuoteSystemTypes.ORM
          // }
        }
      },
      deep: true
    }
  },
  created: function created() {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
        while (1) switch (_context2.n) {
          case 0:
            return _context2.a(2);
        }
      }, _callee2);
    }))();
  },
  methods: {
    // setBatchType() {
    //   this.selectedBatchType = this.batchTypes.find((i) => i.key === this.innerValue.batchType)
    // },
    close: function close() {
      this.$emit('update:active', false);
      this.$emit('close');
    },
    add: function add() {
      this.$emit('update:active', false);
      // if (!this.value.quoteSystemType) {
      //   this.$notification.error('Batch Setting', 'Batch Type is not selected')
      //   return
      // }
      this.$emit('add');
    } // async getInsurerDropdown(name) {
    //   this.isInsurerLoading = true
    //   this.insurers = await OrmBatchingService.getInsurerDropdown(name)
    //   if (this.insurers && !this.selectedInsurer && this.lastBatchInsurerId) {
    //     const match = this.insurers.find(i => i.insurerId == this.lastBatchInsurerId)
    //     if (match) {
    //       this.selectedInsurer = match
    //     }
    //   }
    //   this.isInsurerLoading = false
    // },
    // getListComboInsurersFiltered: _debounce(async function (name) {
    //   this.getInsurerDropdown(name)
    // }, 500)
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.object.values.js */ "./node_modules/core-js/modules/es.object.values.js");
/* harmony import */ var core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_values_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/OrmBatchStatistics */ "./src/views/ormbatching/components/OrmBatchStatistics.vue");
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");
/* harmony import */ var _OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./OrmBatchingMixin */ "./src/views/ormbatching/OrmBatchingMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");















// import _orderBy from 'lodash/orderBy'




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingQuotes',
  components: {
    OrmBatchStatistics: _components_OrmBatchStatistics__WEBPACK_IMPORTED_MODULE_11__["default"],
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_15__["default"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_18__["default"]
  },
  mixins: [_OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_13__["default"]],
  props: {
    value: null,
    quotes: null,
    filter: null
  },
  data: function data() {
    return {
      innerValue: null,
      batchDate: null,
      isTableLoading: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    batchQuoteColumns: function batchQuoteColumns() {
      var columns = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default()(_columns__WEBPACK_IMPORTED_MODULE_12__["BatchQuoteColumns"]);
      columns[12].isVisible = this.isInvoiceColumnVisible;
      return columns;
    },
    totalRows: function totalRows() {
      return this.quotes ? this.quotes.length : 0;
    },
    isInvoiceColumnVisible: function isInvoiceColumnVisible() {
      return this.innerValue.batchStatus === _enums__WEBPACK_IMPORTED_MODULE_16__["OrmBatchStatusType"].Completed || this.innerValue.batchStatus === _enums__WEBPACK_IMPORTED_MODULE_16__["OrmBatchStatusType"].Closed;
    },
    alr: function alr() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var batchTotalLabourHour = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var batchNonLabourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      var batchAgreedTotal = this.quotes.length * this.innerValue.agreedArc;
      // console.log(this.quotes.length, batchTotalLabourHour, batchNonLabourTotal, batchAgreedTotal)
      var batchTotalLabourValue = batchAgreedTotal - batchNonLabourTotal;
      return batchTotalLabourHour ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundUp"])(batchTotalLabourValue / batchTotalLabourHour, 1) : 0;
    },
    adjustedTotal: function adjustedTotal() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var labourHourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      var nonLabourTotal = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(nonLabourTotal + labourHourTotal * this.alr);
    },
    averageLabourUnits: function averageLabourUnits() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.labourHour);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageLabourValues: function averageLabourValues() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.labourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageNonLabourValues: function averageNonLabourValues() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.nonLabourTotal);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total / this.quotes.length);
    },
    averageTotalExGst: function averageTotalExGst() {
      if (this.quotes.length === 0) {
        return 0;
      }
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.totalExGst);
      }, 0);
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total / this.quotes.length);
    },
    labourUnitTotal: function labourUnitTotal() {
      var total = this.quotes.reduce(function (total, quote) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_10__["roundAwayFromZero"])(total + quote.labourUnit);
      }, 0);
      return total;
    },
    ormQuoteStatusTypes: function ormQuoteStatusTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_16__["OrmQuoteStatusTypes"];
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_16__["OrmBatchStatusType"];
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    },
    batchDate: function batchDate(newVal, oldVal) {
      if (newVal) {
        this.innerValue.batchDate = newVal.toISOString().split('.')[0] + 'Z';
      } else {
        this.innerValue.batchDate = null;
      }
    }
  },
  created: function created() {
    var _this = this;
    this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default()(this.value);
    this.batchDate = new Date("".concat(this.innerValue.batchDate));
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_16__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_14___default()(_this.value);
    });
  },
  mounted: function mounted() {},
  methods: {
    highlightSelected: function highlightSelected() {},
    onPageChange: function onPageChange() {},
    sort: function sort(name, order) {
      this.$emit('sort', name, order);
      // this.filter.sortColumn = name
      // this.filter.sortOrder = order
      // this.quotes = _orderBy(this.quotes, this.filter.sortColumn, this.filter.sortOrder)
    },
    getPropertyNameByValue: function getPropertyNameByValue(object, value) {
      return Object.keys(object)[Object.values(object).findIndex(function (i) {
        return i === value;
      })];
    },
    delta: function delta(quote) {
      return quote.totalExGst - this.innerValue.agreedArc;
    },
    viewQuote: function viewQuote(quoteId) {
      this.$emit('view-quote', quoteId);
    },
    removeFromBatch: function removeFromBatch(index, quote) {
      var existingIndex = this.innerValue.quoteIds.map(function (q) {
        return q.quoteId;
      }).indexOf(quote.quoteId);
      if (existingIndex >= 0) {
        var quoteId = this.innerValue.quoteIds[existingIndex];
        if (quoteId.isNew) {
          this.innerValue.quoteIds.splice(existingIndex, 1);
        } else {
          quoteId.isDeleted = true;
          quoteId.destinationBatchId = this.availableBatch ? this.availableBatch.batchId : _components_Guid__WEBPACK_IMPORTED_MODULE_17__["default"].empty();
        }
      } else {}
      this.$emit('quote-removed', index, quote);
      // this.entities.splice(index, 1)
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./route-types */ "./src/views/ormbatching/route-types.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./storeMixin */ "./src/views/ormbatching/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var _components_VueFab__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/VueFab */ "./src/components/VueFab/index.js");
/* harmony import */ var _OrmBatchingViewSideMenu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./OrmBatchingViewSideMenu */ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue");




















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingView',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_9__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_14__["UnsavedModal"],
    VueFab: _components_VueFab__WEBPACK_IMPORTED_MODULE_18__["VueFab"],
    OrmBatchingViewSideMenu: _OrmBatchingViewSideMenu__WEBPACK_IMPORTED_MODULE_19__["default"]
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_12__["default"]],
  props: {},
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      isSaveContinue: false,
      isSkipSave: false,
      isAddQuote: false,
      isAddQuoteActive: false,
      fabActions: []
    };
  },
  computed: {
    isSubmitQuoteButtonActive: function isSubmitQuoteButtonActive() {
      var active = this.entity && this.entity.batchStatus !== _enums__WEBPACK_IMPORTED_MODULE_11__["OrmBatchStatusType"].Completed && this.entity.batchStatus !== _enums__WEBPACK_IMPORTED_MODULE_11__["OrmBatchStatusType"].Closed;
      return active && !this.snapshotDiff && !this.isAddQuoteActive;
    }
  },
  watch: {
    entity: {
      handler: function handler(newVal) {
        if (newVal) {
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.entity));
        }
      },
      deep: true
    },
    isSubmitQuoteButtonActive: function isSubmitQuoteButtonActive(newVal, oldVal) {
      this.setupFabButtons();
    },
    isAddQuoteActive: function isAddQuoteActive(newVal, oldVal) {
      this.setupFabButtons();
    }
  },
  created: function created() {
    this.setupFabButtons();
    this.getEntity();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_11__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context.p = 1;
              _this.$showSpinner();
              if (reset) {
                _this.clearSessionStorage();
                _this.clearSnapshots(_this.$route.params.batchId);
              }
              if (_this.currentSnapshot) {
                _context.n = 2;
                break;
              }
              _context.n = 2;
              return _this.getStoreItem(_this.$route.params.batchId);
            case 2:
              _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this.currentSnapshot);
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('', _t);
            case 4:
              _this.$hideSpinner();
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    clearSessionStorage: function clearSessionStorage() {},
    save: function save() {
      var _arguments2 = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var isDelete, title, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              isDelete = _arguments2.length > 0 && _arguments2[0] !== undefined ? _arguments2[0] : false;
              title = 'Orm Batching';
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity));
              if (!_this2.entity.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_15__["default"].postEntity(_this2.entity);
            case 2:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 3:
              if (!_this2.snapshotDiff) {
                _context2.n = 5;
                break;
              }
              _context2.n = 4;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_15__["default"].putEntity(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this2.entity), _this2.snapshotDiff);
            case 4:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 5:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 6:
              _this2.$hideSpinner();
              if (!_this2.isSaveContinue) {
                _context2.n = 7;
                break;
              }
              _this2.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " deleted") : 'Save successful');
              _context2.n = 11;
              break;
            case 7:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_16__["default"].NO_CONTENT)) {
                _context2.n = 9;
                break;
              }
              _context2.n = 8;
              return _this2.getEntity(true);
            case 8:
              _this2.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " deleted") : 'Save successful');
              _context2.n = 11;
              break;
            case 9:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_16__["default"].CREATED)) {
                _context2.n = 11;
                break;
              }
              _context2.n = 10;
              return _this2.getEntity(true);
            case 10:
              _this2.$notification.openNotificationWithType('success', title, "New ".concat(title, " added"));
            case 11:
              _this2.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_11__["EventHubTypes"].EntitySaved);
              return _context2.a(2, true);
            case 12:
              _context2.p = 12;
              _t2 = _context2.v;
              _this2.$hideSpinner();
              if (_t2.response && _t2.response.request && _t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_16__["default"].CONFLICT) {
                _this2.isSaveConflictModalActive = true;
              } else if (_t2.response) {
                _this2.$notification.openMessageXhrError('Orm Batching', _t2);
              } else {
                _this2.$notification.openNotificationWithType('danger', 'ORM Batching', _t2.toString());
              }
              return _context2.a(2, false);
          }
        }, _callee2, null, [[1, 12]]);
      }))();
    },
    cancel: function cancel() {
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        console.log(this.snapshotDiff);
        this.isUnsavedModalActive = true;
      } else {
        if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_10__["default"].OrmBatchingListView.name
          });
        }
      }
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isUnsavedModalActive = false;
              _this3.isSaveContinue = true;
              _context3.n = 1;
              return _this3.save();
            case 1:
              _this3.isSaveContinue = _context3.v;
              if (_this3.isSaveContinue) {
                _this3.cancel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveContinue = false;
    },
    viewQuote: function viewQuote(quoteId) {
      console.log(quoteId);
      this.setQuoteReturnRoute(this.$route);
      this.editStoreQuote(quoteId);
    },
    addQuote: function addQuote(value) {
      this.isAddQuote = value;
    },
    setupFabButtons: function setupFabButtons() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.fabActions.splice(0, _this4.fabActions.length);
              if (_this4.isSubmitQuoteButtonActive) {
                _this4.fabActions.splice(_this4.fabActions.length, 1, {
                  name: 'submitInvoices',
                  icon: 'currency-usd',
                  color: '#DBA901',
                  tooltip: 'Submit Invoices',
                  visible: true
                });
                _this4.fabActions.splice(_this4.fabActions.length, 1, {
                  name: 'submitQuotes',
                  icon: 'upload',
                  color: '#298A08',
                  tooltip: 'Submit Quotes',
                  visible: true
                });
              }
              if (_this4.entity && _this4.entity.batchStatus !== _enums__WEBPACK_IMPORTED_MODULE_11__["OrmBatchStatusType"].Closed) {
                _this4.fabActions.splice(_this4.fabActions.length, 1, {
                  name: 'toggleAddQuotes',
                  icon: !_this4.isAddQuoteActive ? 'plus' : 'close',
                  color: !_this4.isAddQuoteActive ? '#2c5ba5' : '#DF3A01',
                  tooltip: !_this4.isAddQuoteActive ? 'Manage Quotes' : 'Close Quotes',
                  visible: true
                });
              }
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    submitQuotes: function submitQuotes() {
      // console.log('submitQuotes')
    },
    submitInvoices: function submitInvoices() {
      // console.log('submitInvoices')
    },
    toggleAddQuotes: function toggleAddQuotes() {
      // console.log('toggleAddQuotes')
      this.isAddQuoteActive = !this.isAddQuoteActive;
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this5 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
      var isViewingQuote;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
        while (1) switch (_context5.n) {
          case 0:
            isViewingQuote = to.name === _views_quote_route_types__WEBPACK_IMPORTED_MODULE_17__["default"].QuoteDetail.name; // console.log(isViewingQuote)
            if (isViewingQuote) {
              next();
            } else if (_this5.snapshotDiff && !_this5.isSkipSave && !_this5.isSaveContinue) {
              _this5.$router.replace(from.path);
              _this5.toRoute = to;
              _this5.isUnsavedModalActive = true;
            } else {
              _this5.setReturnRoute({});
              _this5.clearSessionStorage();
              _this5.clearSnapshots(from.params.batchId);
              next();
            }
          case 1:
            return _context5.a(2);
        }
      }, _callee5);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./route-types */ "./src/views/ormbatching/route-types.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./storeMixin */ "./src/views/ormbatching/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./OrmBatchingService */ "./src/views/ormbatching/OrmBatchingService.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _views_quote_route_types__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/views/quote/route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! lodash/orderBy */ "./node_modules/lodash/orderBy.js");
/* harmony import */ var lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_orderBy__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./columns */ "./src/views/ormbatching/columns.js");



























// import { VueFab } from '@/components/VueFab'
// import OrmBatchingViewSideMenu from './OrmBatchingViewSideMenu'


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingView2',
  components: {
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_18__["default"],
    UnsavedModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__["UnsavedModal"]
    // VueFab,
    // OrmBatchingViewSideMenu
  },
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_21__["default"]],
  props: {
    batchId: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {
      entity: null,
      entities: null,
      isUnsavedModalActive: false,
      isSaveContinue: false,
      isSkipSave: false,
      isAddQuote: false,
      isAddQuoteActive: false,
      fabActions: [],
      filter: {
        sortColumn: _columns__WEBPACK_IMPORTED_MODULE_28__["BatchQuoteColumns"][0].name,
        sortOrder: _columns__WEBPACK_IMPORTED_MODULE_28__["BatchQuoteColumns"][0].defaultOrder,
        pageIndex: 1,
        pageSize: 100
      },
      availableQuotes: null,
      removedQuotes: []
    };
  },
  computed: {
    permission: function permission() {
      var _this$$user$permissio;
      return ((_this$$user$permissio = this.$user.permissions) === null || _this$$user$permissio === void 0 ? void 0 : _this$$user$permissio.find(function (p) {
        return p.codeName === 'A130';
      })) || {}; //ORM Batching
    },
    isCanRead: function isCanRead() {
      return this.permission && this.permission.hasRead;
    },
    isCanAdd: function isCanAdd() {
      return this.permission && this.permission.hasAdd;
    },
    isCanEdit: function isCanEdit() {
      return this.permission && this.permission.hasEdit;
    },
    isCanPrint: function isCanPrint() {
      return this.permission && this.permission.hasPrint;
    },
    isBatchCompleted: function isBatchCompleted() {
      var list = [this.ormBatchStatusType.Completed, this.ormBatchStatusType.Closed];
      return this.entity && list.includes(this.entity.batchStatus);
    },
    isBatchCanEdit: function isBatchCanEdit() {
      return this.isCanEdit && !this.isBatchCompleted;
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_20__["OrmBatchStatusType"];
    } // isSubmitQuoteButtonActive() {
    //   let active = this.entity && this.entity.batchStatus !== OrmBatchStatusType.Completed && this.entity.batchStatus !== OrmBatchStatusType.Closed
    //   return active && !this.snapshotDiff //&& !this.isAddQuoteActive
    // },
    // isSubmitInvoiceButtonActive() {
    //   let active = this.entity && this.entity.batchStatus === OrmBatchStatusType.Completed
    //   return active && !this.snapshotDiff
    // }
  },
  watch: {
    entity: {
      handler: function handler(newVal) {
        if (newVal) {
          this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(this.entity));
        }
      },
      deep: true
    }
    // isSubmitQuoteButtonActive: function(newVal, oldVal) {
    //   this.setupFabButtons()
    // },
    // isSubmitInvoiceButtonActive(newVal, oldVal) {
    //   this.setupFabButtons()
    // },
    // isAddQuoteActive: function(newVal, oldVal) {
    //   this.setupFabButtons()
    // }
  },
  created: function created() {
    // this.setupFabButtons()
    this.getEntity();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_20__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_20__["AppHeaderButtonTypes"].Print:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_20__["AppHeaderButtonTypes"].Delete:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_20__["AppHeaderButtonTypes"].Save:
          this.save();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_20__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context.p = 1;
              _this.$showSpinner();
              if (reset) {
                _this.clearSessionStorage();
                _this.clearSnapshots(_this.$route.params.batchId);
              }
              if (_this.currentSnapshot) {
                _context.n = 2;
                break;
              }
              _context.n = 2;
              return _this.getStoreItem(_this.$route.params.batchId);
            case 2:
              _this.entity = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_this.currentSnapshot);
              _this.getBatchQuoteSummaries();
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
              _this.$notification.openMessageXhrError('', _t);
            case 4:
              _this.$hideSpinner();
            case 5:
              return _context.a(2);
          }
        }, _callee, null, [[1, 3]]);
      }))();
    },
    clearSessionStorage: function clearSessionStorage() {},
    save: function save() {
      var _arguments2 = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var isDelete, title, response, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              isDelete = _arguments2.length > 0 && _arguments2[0] !== undefined ? _arguments2[0] : false;
              title = 'Orm Batching';
              _context2.p = 1;
              _this2.$showSpinner('Saving...');
              _this2.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_this2.entity));
              if (!_this2.entity.isNew) {
                _context2.n = 3;
                break;
              }
              _context2.n = 2;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__["default"].postEntity(_this2.entity);
            case 2:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 3:
              if (!_this2.snapshotDiff) {
                _context2.n = 5;
                break;
              }
              _context2.n = 4;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__["default"].putEntity(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_22___default()(_this2.entity), _this2.snapshotDiff);
            case 4:
              response = _context2.v;
              _context2.n = 6;
              break;
            case 5:
              _this2.$notification.openNotificationWithType('warning', title, 'No changes. Not saved');
            case 6:
              _this2.$hideSpinner();
              if (!_this2.isSaveContinue) {
                _context2.n = 7;
                break;
              }
              _this2.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " deleted") : 'Save successful');
              _context2.n = 11;
              break;
            case 7:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].NO_CONTENT)) {
                _context2.n = 9;
                break;
              }
              console.log('saved');
              _context2.n = 8;
              return _this2.getEntity(true);
            case 8:
              _this2.$notification.openNotificationWithType('success', title, isDelete ? "".concat(title, " deleted") : 'Save successful');
              _context2.n = 11;
              break;
            case 9:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CREATED)) {
                _context2.n = 11;
                break;
              }
              _context2.n = 10;
              return _this2.getEntity(true);
            case 10:
              _this2.$notification.openNotificationWithType('success', title, "New ".concat(title, " added"));
            case 11:
              _this2.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_20__["EventHubTypes"].EntitySaved);
              return _context2.a(2, true);
            case 12:
              _context2.p = 12;
              _t2 = _context2.v;
              _this2.$hideSpinner();
              if (_t2.response && _t2.response.request && _t2.response.request.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CONFLICT) {
                _this2.isSaveConflictModalActive = true;
              } else if (_t2.response) {
                _this2.$notification.openMessageXhrError('Orm Batching', _t2);
              } else {
                _this2.$notification.openNotificationWithType('danger', 'ORM Batching', _t2.toString());
              }
              return _context2.a(2, false);
          }
        }, _callee2, null, [[1, 12]]);
      }))();
    },
    cancel: function cancel() {
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue) {
        console.log(this.snapshotDiff);
        this.isUnsavedModalActive = true;
      } else {
        if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else {
          this.$router.push({
            name: _route_types__WEBPACK_IMPORTED_MODULE_19__["default"].OrmBatchingListView.name
          });
        }
      }
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    saveContinue: function saveContinue() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              _this3.isUnsavedModalActive = false;
              _this3.isSaveContinue = true;
              _context3.n = 1;
              return _this3.save();
            case 1:
              _this3.isSaveContinue = _context3.v;
              if (_this3.isSaveContinue) {
                _this3.cancel();
              }
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      this.isSaveContinue = false;
    },
    viewQuote: function viewQuote(quoteId) {
      console.log(quoteId);
      this.setQuoteReturnRoute(this.$route);
      this.editStoreQuote(quoteId);
    },
    sort: function sort(name, order) {
      this.filter.sortColumn = name;
      this.filter.sortOrder = order;
      this.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(this.entities, this.filter.sortColumn, this.filter.sortOrder);
    },
    addQuote: function addQuote(quote) {
      // const removedQuoteIndex = this.removedQuotes.map(q => { return q.quoteId }).indexOf(quote.quoteId)
      // if (removedQuoteIndex >= 0) {
      //   this.removedQuotes.splice(removedQuoteIndex, 1)
      // }
      // this.entities.splice(this.entities.length, 1, quote)
      // this.entities = _orderBy(this.entities, this.filter.sortColumn, this.filter.sortOrder)
      // // this.entities = _orderBy(this.entities, 'quoteNo', '')
    },
    removeQuote: function removeQuote(index, quote) {
      // if (!quote.isNew) {
      //   this.removedQuotes.splice(this.removedQuotes.length, 1, quote)
      // }
      // this.entities.splice(index, 1)
    },
    // async setupFabButtons() {
    //   this.fabActions.splice(0, this.fabActions.length)
    //   if (this.isSubmitInvoiceButtonActive) {
    //     this.fabActions.splice(this.fabActions.length, 1, {
    //       name: 'submitInvoices',
    //       icon: 'currency-usd',
    //       color: '#DBA901',
    //       tooltip: 'Submit Invoices',
    //       visible: true
    //     })
    //   }
    //   if (this.isSubmitQuoteButtonActive) {
    //     this.fabActions.splice(this.fabActions.length, 1, {
    //       name: 'submitQuotes',
    //       icon: 'upload',
    //       color: '#298A08',
    //       tooltip: 'Submit Quotes',
    //       visible: true
    //     })
    //   }
    //   // if (this.entity && this.entity.batchStatus !== OrmBatchStatusType.Closed) {
    //   //   this.fabActions.splice(this.fabActions.length, 1, {
    //   //     name: 'toggleAddQuotes',
    //   //     icon: !this.isAddQuoteActive ? 'plus' : 'close',
    //   //     color: !this.isAddQuoteActive ? '#2c5ba5' : '#DF3A01',
    //   //     tooltip: !this.isAddQuoteActive ? 'Manage Quotes' : 'Close Quotes',
    //   //     visible: true
    //   //   })
    //   // }
    // },
    getBatchQuoteSummaries: function getBatchQuoteSummaries() {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        var results, vm;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isTableLoading = true;
              _context4.n = 1;
              return _OrmBatchingService__WEBPACK_IMPORTED_MODULE_24__["default"].getBatchQuoteSummariesByIds(_this4.entity.batchId, _this4.entity.quoteIds.map(function (q) {
                return q.quoteId;
              }));
            case 1:
              results = _context4.v;
              _this4.entities = lodash_orderBy__WEBPACK_IMPORTED_MODULE_27___default()(results, _this4.filter.sortColumn, _this4.filter.sortOrder);
              vm = _this4;
              _this4.entity.quoteIds.forEach(function (q) {
                if (q.isNew) {
                  var entity = vm.entities.find(function (e) {
                    return e.quoteId === q.quoteId;
                  });
                  if (entity) {
                    entity.isNew = q.isNew;
                  }
                }
              });
              _this4.totalRows = _this4.entities.length;
              _this4.isTableLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    } // submitQuotes() {
    //   // console.log('submitQuotes')
    // },
    // submitInvoices() {
    //   // console.log('submitInvoices')
    // },
    // toggleAddQuotes() {
    //   // console.log('toggleAddQuotes')
    //   this.isAddQuoteActive = !this.isAddQuoteActive
    // }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this5 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
      var isViewingQuote;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
        while (1) switch (_context5.n) {
          case 0:
            isViewingQuote = to.name === _views_quote_route_types__WEBPACK_IMPORTED_MODULE_26__["default"].QuoteDetail.name; // console.log(isViewingQuote)
            if (isViewingQuote) {
              next();
            } else if (_this5.snapshotDiff && !_this5.isSkipSave && !_this5.isSaveContinue) {
              _this5.$router.replace(from.path);
              _this5.toRoute = to;
              _this5.$hideSpinner();
              _this5.isUnsavedModalActive = true;
            } else {
              _this5.setReturnRoute({});
              _this5.clearSessionStorage();
              _this5.clearSnapshots(from.params.batchId);
              next();
            }
          case 1:
            return _context5.a(2);
        }
      }, _callee5);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./route-types */ "./src/views/ormbatching/route-types.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchingViewSideMenu',
  // inject: ['$vv'],
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    entityName: {
      type: String,
      default: ''
    },
    count: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_2__["default"];
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js":
/*!********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js ***!
  \********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchStatistics',
  components: {},
  props: {
    count: 0,
    alr: 0,
    alrLowerThreshold: 0,
    alrUpperThreshold: 0,
    averageLabourUnits: 0,
    averageLabourValues: 0,
    averageNonLabourValues: 0,
    averageTotalExGst: 0,
    adjustedTotal: 0
  },
  data: function data() {
    return {};
  },
  computed: {},
  watch: {},
  created: function created() {},
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/services */ "./src/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../OrmBatchingMixin */ "./src/views/ormbatching/OrmBatchingMixin.js");









/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'OrmBatchStatistics2',
  components: {},
  mixins: [_OrmBatchingMixin__WEBPACK_IMPORTED_MODULE_8__["default"]],
  props: {
    value: null,
    quotes: null,
    count: 0,
    alr: 0,
    alrLowerThreshold: 0,
    alrUpperThreshold: 0,
    // averageLabourUnits: 0,
    // averageLabourValues: 0,
    // averageNonLabourValues: 0,
    averageTotalExGst: 0,
    adjustedTotal: 0,
    adjustedAlr: 0,
    isCanEdit: false
  },
  data: function data() {
    return {
      insurer: null
    };
  },
  computed: {
    actualARC: function actualARC() {
      if (this.quotes.length == 0) return 0.0;
      // const total = this.quotes.reduce((sum, item) => sum + item.totalNotInvoiced, 0)
      var total = this.quotes.reduce(function (sum, item) {
        return sum + item.totalExGST;
      }, 0);
      return total / this.quotes.length;
    },
    ormBatchStatusType: function ormBatchStatusType() {
      return _enums__WEBPACK_IMPORTED_MODULE_7__["OrmBatchStatusType"];
    }
  },
  watch: {},
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (!(_this.value && _this.value.insurerId)) {
              _context.n = 2;
              break;
            }
            _context.n = 1;
            return _services__WEBPACK_IMPORTED_MODULE_6__["InsurerService"].getEntity(_this.value.insurerId);
          case 1:
            _this.insurer = _context.v;
          case 2:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5 ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-vertical"
  }, [_vm.quotes ? _c("article", {
    staticClass: "tile is-child box"
  }, [_c("orm-batch-statistics", {
    attrs: {
      count: _vm.quotes ? _vm.quotes.length : 0,
      alr: _vm.alr,
      "alr-lower-threshold": _vm.innerValue.alrLowerThreshold,
      "alr-upper-threshold": _vm.innerValue.alrUpperThreshold,
      "average-labour-units": _vm.averageLabourUnits,
      "average-labour-values": _vm.averageLabourValues,
      "average-non-labour-values": _vm.averageNonLabourValues,
      "average-total-ex-gst": _vm.averageTotalExGst,
      "adjusted-total": _vm.adjustedTotal
    }
  })], 1) : _vm._e(), _c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("In Scope")]), _c("div", {
    staticClass: "field is-narrow has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.availableQuoteQuery,
      expression: "availableQuoteQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Start typing to search"
    },
    domProps: {
      value: _vm.availableQuoteQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.availableQuoteQuery = $event.target.value;
      }
    }
  }), _vm._m(0)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        _vm.availableQuoteQuery = "";
      }
    }
  }, [_vm._m(1)])])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_vm._m(2), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedAvailableBatchId,
      expression: "selectedAvailableBatchId"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedAvailableBatchId = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    domProps: {
      value: _vm.guid.empty()
    }
  }, [_vm._v("Not Batched")]), _vm._l(_vm.activeBatchIds, function (activeBatchId) {
    return _c("option", {
      key: activeBatchId.value,
      domProps: {
        value: activeBatchId.key
      }
    }, [_vm._v(" " + _vm._s("Batch No. ".concat(activeBatchId.value)) + " ")]);
  })], 2)])])])])])]), _vm.availableBatch ? _c("orm-batch-statistics", {
    attrs: {
      count: _vm.availableQuotes ? _vm.availableQuotes.length : 0,
      alr: _vm.availableAlr,
      "alr-lower-threshold": _vm.availableBatch.alrLowerThreshold,
      "alr-upper-threshold": _vm.availableBatch.alrUpperThreshold,
      "average-labour-units": _vm.availableAverageLabourUnits,
      "average-labour-values": _vm.availableAverageLabourValues,
      "average-non-labour-values": _vm.availableAverageNonLabourValues,
      "average-total-ex-gst": _vm.availableAverageTotalExGst,
      "adjusted-total": _vm.availableAdjustedTotal
    }
  }) : _vm._e(), _vm.availableBatch ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.availableQuoteColumns,
      "page-index": _vm.availableQuoteFilter.pageIndex,
      "page-size": _vm.availableQuoteFilter.pageSize,
      "total-rows": _vm.availableQuoteTotalRows,
      "is-loading": _vm.isAvailableQuoteTableLoading,
      "sort-column": _vm.availableQuoteFilter.sortColumn,
      "sort-order": _vm.availableQuoteFilter.sortOrder,
      draggable: false,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onAvailableQuotePageChange,
      sort: _vm.onAvailableQuoteSort
    }
  }, [_vm._l(_vm.filteredAvailableQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNo))])]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.customerName))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("button", {
      staticClass: "button is-success is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Add to batch"
      },
      on: {
        click: function click($event) {
          return _vm.addToBatch(index, quote);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-plus mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)], 1), _c("article", {
    staticClass: "tile is-child box"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Out Of Scope")]), _c("div", {
    staticClass: "field"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.availableQuoteColumns,
      "page-index": _vm.outOfScopeQuoteFilter.pageIndex,
      "page-size": _vm.outOfScopeQuoteFilter.pageSize,
      "total-rows": _vm.outOfScopeQuoteTotalRows,
      "is-loading": _vm.isOutOfScopQuoteTableLoading,
      "sort-column": _vm.outOfScopeQuoteFilter.sortColumn,
      "sort-order": _vm.outOfScopeQuoteFilter.sortOrder,
      draggable: false,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onAvailableQuotePageChange,
      sort: _vm.onAvailableQuoteSort
    }
  }, [_vm._l(_vm.outOfScopeQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNo))])]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.customerName))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    })]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Source")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);




var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "m-3",
    staticStyle: {
      "max-width": "100vvw"
    }
  }, [_c("orm-batch-statistics", {
    attrs: {
      quotes: _vm.combinedBatchedQuotes,
      count: _vm.combinedBatchedQuotes ? _vm.combinedBatchedQuotes.length : 0,
      alr: _vm.alr,
      "adjusted-alr": _vm.adjustedCombinedAlr,
      "alr-lower-threshold": _vm.innerValue.alrLowerThreshold,
      "alr-upper-threshold": _vm.innerValue.alrUpperThreshold,
      "average-total-ex-gst": _vm.averageTotalExGst,
      "adjusted-total": _vm.adjustedTotal,
      "is-can-edit": _vm.isCanEdit
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  }), _c("article", {
    staticClass: "box setting-page-tile",
    staticStyle: {
      "overflow-x": "auto"
    }
  }, [_c("div", [_c("div", {
    staticClass: "columns is-mobile is-justify-content-space-between"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(0), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right custom-setting",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2,
      disabled: !_vm.isBatchCanEdit
    },
    model: {
      value: _vm.innerValue.perQuoteTotalMin,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "perQuoteTotalMin", $$v);
      },
      expression: "innerValue.perQuoteTotalMin"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(1), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right custom-setting",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2,
      disabled: !_vm.isBatchCanEdit
    },
    model: {
      value: _vm.innerValue.perQuoteTotalMax,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "perQuoteTotalMax", $$v);
      },
      expression: "innerValue.perQuoteTotalMax"
    }
  })], 1)])])])])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(2), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right custom-setting",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2,
      disabled: !_vm.isBatchCanEdit
    },
    model: {
      value: _vm.innerValue.agreedArc,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "agreedArc", $$v);
      },
      expression: "innerValue.agreedArc"
    }
  })], 1)])])])])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(3), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right custom-setting",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2,
      disabled: !_vm.isBatchCanEdit
    },
    model: {
      value: _vm.innerValue.alrLowerThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrLowerThreshold", $$v);
      },
      expression: "innerValue.alrLowerThreshold"
    }
  })], 1)])])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "field is-horizontal"
  }, [_vm._m(4), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("p", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right custom-setting",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2,
      disabled: !_vm.isBatchCanEdit
    },
    model: {
      value: _vm.innerValue.alrUpperThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrUpperThreshold", $$v);
      },
      expression: "innerValue.alrUpperThreshold"
    }
  })], 1)])])])])])])])])]), _c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "pr-1"
  }, [_vm._v("In Batch")]), _c("span", {
    staticClass: "has-text-primary"
  }, [_vm._v("(" + _vm._s(_vm.batchedQuotesTotalRows) + ")")])])]), _vm.isBatchCanEdit ? _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("button", {
    staticClass: "button tooltip ml-5 button-remove",
    attrs: {
      "data-tooltip": "Remove Selected from Batch",
      disabled: !_vm.batchedQuotes.length
    },
    on: {
      click: _vm.removeRangeToBatch
    }
  }, [_vm._v(" Remove from Batch ")])])]) : _vm._e(), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.batchedQuotesQuery,
      expression: "batchedQuotesQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Quote No. or Rego"
    },
    domProps: {
      value: _vm.batchedQuotesQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.batchedQuotesQuery = $event.target.value;
      }
    }
  }), _vm._m(5)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        _vm.batchedQuotesQuery = "";
      }
    }
  }, [_vm._m(6)])])])]), _c("div", {
    staticClass: "column is-narrow pl-0"
  }, [_c("button", {
    staticClass: "button tooltip is-success",
    attrs: {
      "data-tooltip": "Download Excel",
      disabled: !_vm.batchedQuotes.length
    },
    on: {
      click: function click($event) {
        return _vm.exportToExcel(_vm.tableType.INBATCH);
      }
    }
  }, [_c("span", {
    staticClass: "msr msr-24px"
  }, [_vm._v("file_save")])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "table-container"
  }, [_c("bulma-table", {
    ref: "batchedQuotesTable",
    staticClass: "table is-striped is-narrow is-fullwidth is-hoverable",
    attrs: {
      columns: _vm.batchingQuoteColumns,
      "page-index": _vm.batchedQuotesFilter.pageIndex,
      "page-size": _vm.batchedQuotesFilter.pageSize,
      "total-rows": _vm.batchedQuotesTotalRows,
      "is-loading": _vm.isBatchedQuotesTableLoading,
      "sort-column": _vm.batchedQuotesFilter.sortColumn,
      "sort-order": _vm.batchedQuotesFilter.sortOrder,
      draggable: false,
      "show-pagination": false,
      "is-title-checkable": _vm.isBatchCanEdit,
      "title-checkbox-location": "front"
    },
    on: {
      sort: _vm.onBatchedQuotesSort,
      "title-checkbox-changed": _vm.batchedCheckboxChanged
    }
  }, [_vm._l(_vm.filteredBatchedQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_vm.isBatchCanEdit ? _c("td", {
      staticClass: "has-vertical-middle has-text-centered"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: quote.isChecked,
        expression: "quote.isChecked"
      }],
      attrs: {
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(quote.isChecked) ? _vm._i(quote.isChecked, null) > -1 : quote.isChecked
      },
      on: {
        change: [function ($event) {
          var $$a = quote.isChecked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(quote, "isChecked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(quote, "isChecked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(quote, "isChecked", $$c);
          }
        }, _vm.handleBatchedCheckboxChange]
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])])]) : _vm._e(), _c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNoRef))])]), _c("td", [_vm._v(_vm._s(quote.quoteStatus))]), _c("td", [_vm._v(_vm._s(quote.jobStage))]), _c("td", [_vm._v(_vm._s(quote.quoteStatusText))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(quote.jobEnd, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(quote.daysElapsed))]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.fullName))]), _c("td", [_vm._v(_vm._s(quote.insurer))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGST, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered col-1"
    }, [_c("a", {
      staticClass: "button is-dark is-small is-inverted",
      on: {
        mouseover: function mouseover($event) {
          return _vm.getNotesContent(quote.isNoteExists, quote.quoteId);
        },
        mouseout: function mouseout($event) {
          return _vm.resetNotesContent();
        },
        click: function click($event) {
          return _vm.notesClick(quote.quoteId, quote.quoteNoRef);
        }
      }
    }, [_c("span", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          enabled: _vm.showNoteContent,
          placement: "left-start",
          arrow: false,
          allowHTML: true
        },
        expression: "{ enabled: showNoteContent, placement: 'left-start', arrow: false, allowHTML: true }"
      }],
      staticClass: "icon is-medium",
      attrs: {
        content: _vm.notesContent
      }
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.isNoteExists ? "mdi-note-edit has-text-warning" : "mdi-note-edit-outline has-text-grey"]
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]), !_vm.isBatchCompleted ? _c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "pr-1"
  }, [_vm._v("In Scope - Completed")]), _c("span", {
    staticClass: "has-text-primary"
  }, [_vm._v("(" + _vm._s(_vm.inScopeQuotesTotalRows) + ")")])])]), _vm.isBatchCanEdit ? _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("button", {
    staticClass: "button tooltip ml-5 button-add",
    attrs: {
      "data-tooltip": "Add Selected to Batch",
      disabled: !_vm.inScopeQuotes.length
    },
    on: {
      click: function click($event) {
        return _vm.addRangeToBatch(_vm.tableType.INSCOPE);
      }
    }
  }, [_vm._v(" Add to Batch ")])])]) : _vm._e(), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inScopeQuotesQuery,
      expression: "inScopeQuotesQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Quote No. or Rego"
    },
    domProps: {
      value: _vm.inScopeQuotesQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.inScopeQuotesQuery = $event.target.value;
      }
    }
  }), _vm._m(7)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        _vm.inScopeQuotesQuery = "";
      }
    }
  }, [_vm._m(8)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "table-container"
  }, [_c("bulma-table", {
    ref: "inScopeQuotesTable",
    staticClass: "table is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.batchingQuoteColumns,
      "page-index": _vm.inScopeQuotesFilter.pageIndex,
      "page-size": _vm.inScopeQuotesFilter.pageSize,
      "total-rows": _vm.inScopeQuotesTotalRows,
      "is-loading": _vm.isInScopeQuotesTableLoading,
      "sort-column": _vm.inScopeQuotesFilter.sortColumn,
      "sort-order": _vm.inScopeQuotesFilter.sortOrder,
      draggable: false,
      "show-pagination": false,
      "is-title-checkable": _vm.isBatchCanEdit,
      "title-checkbox-location": "front"
    },
    on: {
      sort: _vm.onInScopeQuotesSort,
      "title-checkbox-changed": _vm.inScopeCheckboxChanged
    }
  }, [_vm._l(_vm.filteredInScopeQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_vm.isBatchCanEdit ? _c("td", {
      staticClass: "has-vertical-middle has-text-centered"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: quote.isChecked,
        expression: "quote.isChecked"
      }],
      attrs: {
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(quote.isChecked) ? _vm._i(quote.isChecked, null) > -1 : quote.isChecked
      },
      on: {
        change: [function ($event) {
          var $$a = quote.isChecked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(quote, "isChecked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(quote, "isChecked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(quote, "isChecked", $$c);
          }
        }, _vm.handleInScopeCheckboxChange]
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])])]) : _vm._e(), _c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNoRef))])]), _c("td", [_vm._v(_vm._s(quote.quoteStatus))]), _c("td", [_vm._v(_vm._s(quote.jobStage))]), _c("td", [_vm._v(_vm._s(quote.quoteStatusText))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(quote.jobEnd, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(quote.daysElapsed))]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.fullName))]), _c("td", [_vm._v(_vm._s(quote.insurer))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGST, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered col-1"
    }, [_c("a", {
      staticClass: "button is-dark is-small is-inverted",
      on: {
        mouseover: function mouseover($event) {
          return _vm.getNotesContent(quote.isNoteExists, quote.quoteId);
        },
        mouseout: function mouseout($event) {
          return _vm.resetNotesContent();
        },
        click: function click($event) {
          return _vm.notesClick(quote.quoteId, quote.quoteNoRef);
        }
      }
    }, [_c("span", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          enabled: _vm.showNoteContent,
          placement: "left-start",
          arrow: false,
          allowHTML: true
        },
        expression: "{ enabled: showNoteContent, placement: 'left-start', arrow: false, allowHTML: true }"
      }],
      staticClass: "icon is-medium",
      attrs: {
        content: _vm.notesContent
      }
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.isNoteExists ? "mdi-note-edit has-text-warning" : "mdi-note-edit-outline has-text-grey"]
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]) : _vm._e(), !_vm.isBatchCompleted ? _c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "pr-1"
  }, [_vm._v("In Scope - In Progress")]), _c("span", {
    staticClass: "has-text-primary mr-3"
  }, [_vm._v("(" + _vm._s(_vm.inProgressQuotesTotalRows) + ")")]), _c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.inProgressQuotesAvgCost, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inProgressQuotesQuery,
      expression: "inProgressQuotesQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Quote No. or Rego"
    },
    domProps: {
      value: _vm.inProgressQuotesQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.inProgressQuotesQuery = $event.target.value;
      }
    }
  }), _vm._m(9)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        _vm.inProgressQuotesQuery = "";
      }
    }
  }, [_vm._m(10)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "table-container"
  }, [_c("bulma-table", {
    ref: "inProgressQuotesTable",
    staticClass: "table is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.batchingQuoteColumns,
      "page-index": _vm.inProgressQuotesFilter.pageIndex,
      "page-size": _vm.inProgressQuotesFilter.pageSize,
      "total-rows": _vm.inProgressQuotesTotalRows,
      "is-loading": _vm.isInProgressQuotesTableLoading,
      "sort-column": _vm.inProgressQuotesFilter.sortColumn,
      "sort-order": _vm.inProgressQuotesFilter.sortOrder,
      draggable: false,
      "show-pagination": false,
      "is-title-checkable": false,
      "title-checkbox-location": "front"
    },
    on: {
      sort: _vm.onInProgressQuotesSort,
      "title-checkbox-changed": _vm.inProgressCheckboxChanged
    }
  }, [_vm._l(_vm.filteredInProgressQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      class: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, "orm-batching-background-danger-" + _vm.$theme.name, _vm.isRowHighlighted(quote)),
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNoRef))])]), _c("td", [_vm._v(_vm._s(quote.quoteStatus))]), _c("td", [_vm._v(_vm._s(quote.jobStage))]), _c("td", [_vm._v(_vm._s(quote.quoteStatusText))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(quote.jobEnd, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(quote.daysElapsed))]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.fullName))]), _c("td", [_vm._v(_vm._s(quote.insurer))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGST, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered col-1"
    }, [_c("a", {
      staticClass: "button is-dark is-small is-inverted",
      on: {
        mouseover: function mouseover($event) {
          return _vm.getNotesContent(quote.isNoteExists, quote.quoteId);
        },
        mouseout: function mouseout($event) {
          return _vm.resetNotesContent();
        },
        click: function click($event) {
          return _vm.notesClick(quote.quoteId, quote.quoteNoRef);
        }
      }
    }, [_c("span", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          enabled: _vm.showNoteContent,
          placement: "left-start",
          arrow: false,
          allowHTML: true
        },
        expression: "{ enabled: showNoteContent, placement: 'left-start', arrow: false, allowHTML: true }"
      }],
      staticClass: "icon is-medium",
      attrs: {
        content: _vm.notesContent
      }
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.isNoteExists ? "mdi-note-edit has-text-warning" : "mdi-note-edit-outline has-text-grey"]
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]) : _vm._e(), !_vm.isBatchCompleted ? _c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_c("span", {
    staticClass: "pr-1"
  }, [_vm._v("Out of Scope")]), _c("span", {
    staticClass: "has-text-primary"
  }, [_vm._v("(" + _vm._s(_vm.outScopeQuotesTotalRows) + ")")])])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field is-narrow has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.outScopeQuotesQuery,
      expression: "outScopeQuotesQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Quote No. or Rego"
    },
    domProps: {
      value: _vm.outScopeQuotesQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.outScopeQuotesQuery = $event.target.value;
      }
    }
  }), _vm._m(11)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        _vm.outScopeQuotesQuery = "";
      }
    }
  }, [_vm._m(12)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "table-container"
  }, [_c("bulma-table", {
    ref: "outScopeQuotesTable",
    staticClass: "table is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.batchingQuoteColumns,
      "page-index": _vm.outScopeQuotesFilter.pageIndex,
      "page-size": _vm.outScopeQuotesFilter.pageSize,
      "total-rows": _vm.outScopeQuotesTotalRows,
      "is-loading": _vm.isOutScopeQuotesTableLoading,
      "sort-column": _vm.outScopeQuotesFilter.sortColumn,
      "sort-order": _vm.outScopeQuotesFilter.sortOrder,
      draggable: false,
      "show-pagination": false
    },
    on: {
      sort: _vm.onOutScopeQuotesSort
    }
  }, [_vm._l(_vm.filteredOutScopeQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      class: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, "orm-batching-background-danger-" + _vm.$theme.name, _vm.isRowHighlighted(quote)),
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNoRef))])]), _c("td", [_vm._v(_vm._s(quote.quoteStatus))]), _c("td", [_vm._v(_vm._s(quote.jobStage))]), _c("td", [_vm._v(_vm._s(quote.quoteStatusText))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(quote.jobEnd, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered"
    }, [_vm._v(_vm._s(quote.daysElapsed))]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.fullName))]), _c("td", [_vm._v(_vm._s(quote.insurer))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGST, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-centered col-1"
    }, [_c("a", {
      staticClass: "button is-dark is-small is-inverted",
      on: {
        mouseover: function mouseover($event) {
          return _vm.getNotesContent(quote.isNoteExists, quote.quoteId);
        },
        mouseout: function mouseout($event) {
          return _vm.resetNotesContent();
        },
        click: function click($event) {
          return _vm.notesClick(quote.quoteId, quote.quoteNoRef);
        }
      }
    }, [_c("span", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          enabled: _vm.showNoteContent,
          placement: "left-start",
          arrow: false,
          allowHTML: true
        },
        expression: "{ enabled: showNoteContent, placement: 'left-start', arrow: false, allowHTML: true }"
      }],
      staticClass: "icon is-medium",
      attrs: {
        content: _vm.notesContent
      }
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.isNoteExists ? "mdi-note-edit has-text-warning" : "mdi-note-edit-outline has-text-grey"]
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])]) : _vm._e(), _c("div", {
    ref: "notesList",
    staticClass: "is-hidden"
  }, [_c("ul", {
    staticStyle: {
      "list-style-type": "disc",
      "padding-left": "1rem"
    }
  }, _vm._l(_vm.notes, function (note, index) {
    return _c("li", {
      key: index
    }, [_c("span", {
      staticClass: "is-size-6"
    }, [_vm._v(_vm._s(note.remarks))]), _c("div", {
      staticClass: "is-flex is-align-items-center is-size-7"
    }, [note.firstName || note.displayName ? _c("user-profile-icon", {
      staticClass: "pr-1",
      attrs: {
        "is-text-profile": true,
        "first-name": note.firstName,
        "last-name": note.lastName,
        "display-name": note.displayName,
        width: 20,
        height: 20
      }
    }) : _vm._e(), _c("span", {
      staticClass: "help is-italic has-text-grey"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateTimeLocale(note.remarkDateTime, _vm.$userInfo.locale)))])], 1)]);
  }), 0)])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("label", {
    staticClass: "label has-text-nowrap"
  }, [_vm._v("Total Val (ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("label", {
    staticClass: "label has-text-nowrap"
  }, [_vm._v("to")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("label", {
    staticClass: "label has-text-nowrap"
  }, [_vm._v("Avg Target Cost")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("label", {
    staticClass: "label has-text-nowrap"
  }, [_vm._v("ALR L. Threshold")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-label is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("label", {
    staticClass: "label has-text-nowrap"
  }, [_vm._v("ALR U. Threshold")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile"
  }, [_c("div", {
    staticClass: "tile is-parent is-vertical"
  }, [_c("article", {
    staticClass: "tile is-child box",
    staticStyle: {
      "max-height": "250px"
    }
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Summary")]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch No")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Batch No.",
      precision: 0
    },
    model: {
      value: _vm.innerValue.batchNo,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "batchNo", $$v);
      },
      expression: "innerValue.batchNo"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch Date")]), _c("div", {
    staticClass: "control"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Batch Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.batchDate,
      callback: function callback($$v) {
        _vm.batchDate = $$v;
      },
      expression: "batchDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Min. Batch Size")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Min. Batch Size",
      precision: 0
    },
    model: {
      value: _vm.innerValue.minBatchSize,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "minBatchSize", $$v);
      },
      expression: "innerValue.minBatchSize"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch Status")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.batchStatus,
      expression: "innerValue.batchStatus"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "batchStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.ormBatchStatusType, function (status, propertyName) {
    return _c("option", {
      key: status,
      domProps: {
        value: status
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatOrmBatchStatus(propertyName)) + " ")]);
  }), 0)])])])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Agreed ARC")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.agreedArc,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "agreedArc", $$v);
      },
      expression: "innerValue.agreedArc"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Lower Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.alrLowerThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrLowerThreshold", $$v);
      },
      expression: "innerValue.alrLowerThreshold"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Upper Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.alrUpperThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrUpperThreshold", $$v);
      },
      expression: "innerValue.alrUpperThreshold"
    }
  })], 1)])])]), _c("div", {
    staticClass: "is-divider"
  }), _vm.entities ? _c("orm-batch-statistics", {
    attrs: {
      count: _vm.entities ? _vm.entities.length : 0,
      alr: _vm.alr,
      "alr-lower-threshold": _vm.innerValue.alrLowerThreshold,
      "alr-upper-threshold": _vm.innerValue.alrUpperThreshold,
      "average-labour-units": _vm.averageLabourUnits,
      "average-labour-values": _vm.averageLabourValues,
      "average-non-labour-values": _vm.averageNonLabourValues,
      "average-total-ex-gst": _vm.averageTotalExGst,
      "adjusted-total": _vm.adjustedTotal
    }
  }) : _vm._e()], 1), _c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(0), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.batchQuoteColumns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      draggable: true,
      "draggable-empty": true,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_c("draggable", _vm._b({
    attrs: {
      list: _vm.entities,
      group: "quote",
      tag: "tbody"
    },
    on: {
      change: _vm.itemMoved,
      end: _vm.endMove
    }
  }, "draggable", {
    disabled: !_vm.isRowDraggable,
    chosen: "chosen",
    ghostClass: "draggable-ghost",
    dragClass: "draggable-drag",
    animation: _vm.animationDuration
  }, false), _vm._l(_vm.entities, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      class: {
        "is-new-item": quote.isNew
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNo))])]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !_vm.isAddQuoteActive,
        expression: "!isAddQuoteActive"
      }]
    }, [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !_vm.isAddQuoteActive,
        expression: "!isAddQuoteActive"
      }]
    }, [_vm._v(_vm._s(quote.customerName))]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !_vm.isAddQuoteActive,
        expression: "!isAddQuoteActive"
      }],
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.totalExGst, _vm.$userInfo.locale)))]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.isInvoiceColumnVisible,
        expression: "isInvoiceColumnVisible"
      }],
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [quote.invoiced ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.invoiced ? "mdi-check" : ""]
    })])]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !_vm.isAddQuoteActive,
        expression: "!isAddQuoteActive"
      }]
    }, [_vm._v(_vm._s(_vm.$filters.camelCaseToDescription(_vm.getPropertyNameByValue(_vm.ormQuoteStatusTypes, quote.quoteStatusId))))]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !_vm.isAddQuoteActive,
        expression: "!isAddQuoteActive"
      }]
    }, [_vm._v(_vm._s(quote.qdeStatus))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: quote.excess > quote.totalExGst,
        expression: "quote.excess > quote.totalExGst"
      }],
      staticClass: "icon has-text-danger tooltip is-tooltip-danger is-tooltip-topright",
      attrs: {
        "data-tooltip": "Excess exceeds Total"
      }
    }, [_c("i", {
      staticClass: "mdi mdi-alert mdi-24px"
    })]), _c("button", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.isAddQuoteActive,
        expression: "isAddQuoteActive"
      }],
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Remove from batch"
      },
      on: {
        click: function click($event) {
          return _vm.removeFromBatch(index, quote);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-minus mdi-24px"
    })])])])]);
  }), 0), _c("template", {
    slot: "empty"
  }, [_c("draggable", _vm._b({
    attrs: {
      list: _vm.entities,
      group: "quote",
      tag: "tbody"
    },
    on: {
      change: _vm.itemMoved,
      end: _vm.endMove
    }
  }, "draggable", {
    disabled: !_vm.isRowDraggable,
    chosen: "chosen",
    ghostClass: "draggable-ghost",
    dragClass: "draggable-drag",
    animation: _vm.animationDuration
  }, false), [_c("tr", [_c("td", {
    attrs: {
      colspan: _vm.batchQuoteColumns.length
    }
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])])])], 1)], 2)], 1)]), _c("transition", {
    attrs: {
      name: "custom-classes-transition",
      "enter-active-class": "animated slideInRight",
      "leave-active-class": "animated slideOutRight"
    }
  }, [_c("div", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isAddQuoteActive,
      expression: "isAddQuoteActive"
    }],
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Available Quotes")]), _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Search")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.availableQuoteQuery,
      expression: "availableQuoteQuery"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Start typing to search"
    },
    domProps: {
      value: _vm.availableQuoteQuery
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.availableQuoteQuery = $event.target.value;
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Lower Limit")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: null,
      placeholder: "Total Lower Limit",
      precision: 0
    },
    model: {
      value: _vm.totalLowerLimit,
      callback: function callback($$v) {
        _vm.totalLowerLimit = $$v;
      },
      expression: "totalLowerLimit"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Upper Limit")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Total Upper Limit",
      precision: 0
    },
    model: {
      value: _vm.totalUpperLimit,
      callback: function callback($$v) {
        _vm.totalUpperLimit = $$v;
      },
      expression: "totalUpperLimit"
    }
  })], 1)])]), _c("div", {
    staticClass: "column is-narrow"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field-label is-normal"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Source")])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.selectedAvailableBatchId,
      expression: "selectedAvailableBatchId"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.selectedAvailableBatchId = $event.target.multiple ? $$selectedVal : $$selectedVal[0];
      }
    }
  }, [_c("option", {
    domProps: {
      value: _vm.guid.empty()
    }
  }, [_vm._v("Not Batched")]), _vm._l(_vm.activeBatchIds, function (activeBatchId) {
    return _c("option", {
      key: activeBatchId.value,
      domProps: {
        value: activeBatchId.key
      }
    }, [_vm._v(" " + _vm._s("Batch No. ".concat(activeBatchId.value)) + " ")]);
  })], 2)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: function click($event) {
        return _vm.closeAvailableQuotes();
      }
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close"
  })]), _c("span", [_vm._v("Close")])])])])])])]), _vm.selectedAvailableBatchId !== _vm.guid.empty() ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), _vm.selectedAvailableBatchId !== _vm.guid.empty() && _vm.availableBatch ? _c("div", {
    staticClass: "field"
  }, [_vm.availableQuotes ? _c("orm-batch-statistics", {
    attrs: {
      count: _vm.availableQuotes ? _vm.availableQuotes.length : 0,
      alr: _vm.availableAlr,
      "alr-lower-threshold": _vm.availableBatch.alrLowerThreshold,
      "alr-upper-threshold": _vm.availableBatch.alrUpperThreshold,
      "average-labour-units": _vm.availableAverageLabourUnits,
      "average-labour-values": _vm.availableAverageLabourValues,
      "average-non-labour-values": _vm.availableAverageNonLabourValues,
      "average-total-ex-gst": _vm.availableAverageTotalExGst,
      "adjusted-total": _vm.availableAdjustedTotal
    }
  }) : _vm._e()], 1) : _vm._e(), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field",
    staticStyle: {
      "max-width": "45vw",
      overflow: "auto"
    }
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.availableQuoteColumns,
      "page-index": _vm.availableQuoteFilter.pageIndex,
      "page-size": _vm.availableQuoteFilter.pageSize,
      "total-rows": _vm.availableQuoteTotalRows,
      "is-loading": _vm.isAvailableQuoteTableLoading,
      "sort-column": _vm.availableQuoteFilter.sortColumn,
      "sort-order": _vm.availableQuoteFilter.sortOrder,
      draggable: true,
      "draggable-empty": true,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onAvailableQuotePageChange,
      sort: _vm.onAvailableQuoteSort
    }
  }, [_c("draggable", _vm._b({
    attrs: {
      list: _vm.availableQuotes,
      group: "quote",
      tag: "tbody"
    },
    on: {
      change: _vm.onAvailableQuoteMoved,
      start: _vm.onAvailableQuoteStartMove,
      end: _vm.onAvailableQuoteEndMove
    }
  }, "draggable", {
    disabled: !_vm.isAvailableQuoteRowDraggable,
    chosen: "chosen",
    ghostClass: "draggable-ghost",
    dragClass: "draggable-drag",
    animation: _vm.animationDuration
  }, false), _vm._l(_vm.filteredAvailableQuotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      on: {
        click: function click($event) {
          return _vm.highlightSelectedAvailableQuote(index, $event);
        }
      }
    }, [_c("td", [_vm._v(_vm._s(quote.quoteNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(quote.totalExGst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("button", {
      staticClass: "button is-success is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Add to batch"
      },
      on: {
        click: function click($event) {
          return _vm.addToBatch(index, quote);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-plus mdi-24px"
    })])])])]);
  }), 0), _c("template", {
    slot: "empty"
  }, [_c("draggable", _vm._b({
    attrs: {
      list: _vm.availableQuotes,
      group: "quote",
      tag: "tbody"
    },
    on: {
      change: _vm.itemMoved,
      end: _vm.endMove
    }
  }, "draggable", {
    disabled: !_vm.isAvailableQuoteRowDraggable,
    chosen: "chosen",
    ghostClass: "draggable-ghost",
    dragClass: "draggable-drag",
    animation: _vm.animationDuration
  }, false), [_c("tr", [_c("td", {
    attrs: {
      colspan: _vm.availableQuoteColumns.length
    }
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])])])], 1)], 2)], 1)])])])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Batched Quotes")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Filters ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.batchNo,
      expression: "innerValue.batchNo"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Batch No."
    },
    domProps: {
      value: _vm.innerValue.batchNo
    },
    on: {
      keyup: function keyup($event) {
        if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.onFilterClick();
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.innerValue, "batchNo", $event.target.value);
      }
    }
  })])]), _c("div", {
    staticClass: "field"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      "popover.visibility": "focus",
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Batch Date..."
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedBatchDate,
      callback: function callback($$v) {
        _vm.selectedBatchDate = $$v;
      },
      expression: "selectedBatchDate"
    }
  })], 1), _c("div", {
    staticClass: "field is-expanded"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.batchStatus,
      expression: "innerValue.batchStatus"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "batchStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.ormBatchStatusType, function (status, propertyName) {
    return _c("option", {
      key: status,
      domProps: {
        value: status
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatOrmBatchStatus(propertyName)) + " ")]);
  }), 0)])])])])]), _c("hr"), _c("div", {
    staticClass: "field is-grouped is-pulled-right"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-primary",
    on: {
      click: _vm.onFilterClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]), _c("span", [_vm._v("Filter")])])]), _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: _vm.onResetClick
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-18px"
  })]), _c("span", [_vm._v("Reset")])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _vm.$userInfo ? _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-delete": false,
      "show-save": false,
      "show-cancel": false,
      "show-new": _vm.isCanAdd,
      "show-print": _vm.isCanPrint
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_c("orm-batching-list-side-menu", {
    on: {
      filter: _vm.filterList,
      reset: _vm.resetList
    },
    model: {
      value: _vm.filter,
      callback: function callback($$v) {
        _vm.filter = $$v;
      },
      expression: "filter"
    }
  })], 1), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "tile is-parent"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.entities, function (batch, index) {
    return _c("tr", {
      key: batch.batchNo,
      class: {
        "is-selected": _vm.selectedRow === index
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_vm.isCanRead ? _c("div", {
      class: {
        "is-flex is-align-items-center is-justify-content-space-between": _vm.completedStatus.includes(batch.batchStatus)
      }
    }, [_c("router-link", {
      attrs: {
        to: {
          path: "/ormbatching/batch/".concat(batch.batchId)
        },
        append: ""
      }
    }, [_vm._v(" " + _vm._s(batch.batchNo) + " ")]), _vm.completedStatus.includes(batch.batchStatus) ? _c("i", {
      staticClass: "mdi mdi-lock-outline mdi-20px has-text-danger"
    }) : _vm._e()], 1) : _c("span", [_vm._v(_vm._s(batch.batchNo))])]), _c("td", [_vm._v(_vm._s(_vm.$filters.formatBatchStatus(batch.batchStatus)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": batch.count < batch.minBatchSize
      }
    }, [_vm._v(_vm._s(batch.count) + "/" + _vm._s(batch.minBatchSize))]), _c("td", [_vm._v(_vm._s(_vm.$filters.formatDateLocale(batch.batchDate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(batch.agreedArc, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(batch.averageLabourUnit, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(batch.averageLabourValue, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.$filters.formatNumberWithRoundUp(batch.averageLabourRate, _vm.$userInfo.locale, 1), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(batch.averageRepairCost, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(batch) < 0,
        "has-text-success": _vm.delta(batch) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(batch), _vm.$userInfo.locale)))]), _vm.isCanRead ? _c("td", {
      staticClass: "has-text-centered"
    }, [_c("router-link", {
      attrs: {
        to: {
          path: "/ormbatching/batch/".concat(batch.batchId)
        },
        append: ""
      }
    }, [_c("a", {
      staticClass: "button is-primary is-small is-inverted tooltip",
      attrs: {
        "data-tooltip": "Click to edit"
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-lead-pencil mdi-24px"
    })])])])], 1) : _vm._e()]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)])])]), _c("orm-batching-new-modal", {
    attrs: {
      active: _vm.isNewBatchModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isNewBatchModalActive = $event;
      },
      close: _vm.closeNewBatchModal,
      add: _vm.handleAddNewBatch
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  })], 1) : _vm._e();
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8 ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("base-modal-ex", {
    attrs: {
      active: _vm.isActive,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "animation-duration": _vm.animationDuration,
      "can-cancel": false,
      "min-width": 30,
      "min-height": 50,
      "has-modal-card": ""
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isActive = $event;
      }
    }
  }, [_c("header", {
    staticClass: "modal-card-head"
  }, [_c("p", {
    staticClass: "modal-card-title is-flex-items-center"
  }, [_c("span", [_vm._v("New Batch")])])]), _c("section", {
    staticClass: "modal-card-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns is-multiline"
  }, [_c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Average Cost Target")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2
    },
    model: {
      value: _vm.value.agreedArc,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "agreedArc", $$v);
      },
      expression: "value.agreedArc"
    }
  })], 1)]), _c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Min Batch Size")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0
    },
    model: {
      value: _vm.value.minBatchSize,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "minBatchSize", $$v);
      },
      expression: "value.minBatchSize"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns is-multiline"
  }, [_c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Total Value (ex GST)")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2
    },
    model: {
      value: _vm.value.perQuoteTotalMin,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "perQuoteTotalMin", $$v);
      },
      expression: "value.perQuoteTotalMin"
    }
  })], 1)]), _c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("to")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2
    },
    model: {
      value: _vm.value.perQuoteTotalMax,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "perQuoteTotalMax", $$v);
      },
      expression: "value.perQuoteTotalMax"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "columns is-multiline"
  }, [_c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Lower Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2
    },
    model: {
      value: _vm.value.alrLowerThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "alrLowerThreshold", $$v);
      },
      expression: "value.alrLowerThreshold"
    }
  })], 1)]), _c("div", {
    staticClass: "column is-full-mobile is-half-tablet"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Upper Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      precision: 2
    },
    model: {
      value: _vm.value.alrUpperThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.value, "alrUpperThreshold", $$v);
      },
      expression: "value.alrUpperThreshold"
    }
  })], 1)])])])]), _c("footer", {
    staticClass: "modal-card-foot is-flex is-justify-content-flex-end"
  }, [_c("div", {
    staticClass: "buttons"
  }, [_c("button", {
    staticClass: "button is-success tooltip",
    attrs: {
      "data-tooltip": "Save"
    },
    on: {
      click: _vm.add
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-20px"
  })]), _c("span", [_vm._v("Add")])]), _c("button", {
    staticClass: "button tooltip",
    attrs: {
      "data-tooltip": "Close"
    },
    on: {
      click: _vm.close
    }
  }, [_c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-20px"
  })]), _c("span", [_vm._v("Close")])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_6__);







var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent is-vertical"
  }, [_vm.quotes ? _c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch No")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Batch No.",
      precision: 0
    },
    model: {
      value: _vm.innerValue.batchNo,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "batchNo", $$v);
      },
      expression: "innerValue.batchNo"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch Date")]), _c("div", {
    staticClass: "control"
  }, [_c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Batch Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }], null, false, 3988065790),
    model: {
      value: _vm.batchDate,
      callback: function callback($$v) {
        _vm.batchDate = $$v;
      },
      expression: "batchDate"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Min. Batch Size")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      placeholder: "Min. Batch Size",
      precision: 0
    },
    model: {
      value: _vm.innerValue.minBatchSize,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "minBatchSize", $$v);
      },
      expression: "innerValue.minBatchSize"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Agreed ARC")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.agreedArc,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "agreedArc", $$v);
      },
      expression: "innerValue.agreedArc"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Lower Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.alrLowerThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrLowerThreshold", $$v);
      },
      expression: "innerValue.alrLowerThreshold"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("ALR Upper Threshold")]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      min: 0,
      symbol: "$",
      placeholder: "Agreed ARC",
      precision: 2
    },
    model: {
      value: _vm.innerValue.alrUpperThreshold,
      callback: function callback($$v) {
        _vm.$set(_vm.innerValue, "alrUpperThreshold", $$v);
      },
      expression: "innerValue.alrUpperThreshold"
    }
  })], 1)]), _c("div", {
    staticClass: "field is-narrow"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Batch Status")]), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.innerValue.batchStatus,
      expression: "innerValue.batchStatus"
    }],
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.innerValue, "batchStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.ormBatchStatusType, function (status, propertyName) {
    return _c("option", {
      key: status,
      domProps: {
        value: status
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatOrmBatchStatus(propertyName)) + " ")]);
  }), 0)])])])])]), _c("div", {
    staticClass: "is-divider"
  }), _c("orm-batch-statistics", {
    attrs: {
      count: _vm.quotes ? _vm.quotes.length : 0,
      alr: _vm.alr,
      "alr-lower-threshold": _vm.innerValue.alrLowerThreshold,
      "alr-upper-threshold": _vm.innerValue.alrUpperThreshold,
      "average-labour-units": _vm.averageLabourUnits,
      "average-labour-values": _vm.averageLabourValues,
      "average-non-labour-values": _vm.averageNonLabourValues,
      "average-total-ex-gst": _vm.averageTotalExGst,
      "adjusted-total": _vm.adjustedTotal
    }
  })], 1) : _vm._e(), _c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(0), _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.batchQuoteColumns,
      "page-index": _vm.filter.pageIndex,
      "page-size": _vm.filter.pageSize,
      "total-rows": _vm.totalRows,
      "is-loading": _vm.isTableLoading,
      "sort-column": _vm.filter.sortColumn,
      "sort-order": _vm.filter.sortOrder,
      draggable: false,
      "show-pagination": false
    },
    on: {
      pageChanged: _vm.onPageChange,
      sort: _vm.sort
    }
  }, [_vm._l(_vm.quotes, function (quote, index) {
    return _c("tr", {
      key: quote.quoteId,
      class: {
        "is-new-item": quote.isNew
      },
      on: {
        click: function click($event) {
          return _vm.highlightSelected(index, $event);
        }
      }
    }, [_c("td", [_c("a", {
      attrs: {
        href: "#"
      },
      on: {
        click: function click($event) {
          return _vm.viewQuote(quote.quoteId);
        }
      }
    }, [_vm._v(_vm._s(quote.quoteNo))])]), _c("td", [_vm._v(_vm._s(quote.claimNo))]), _c("td", [_vm._v(_vm._s(quote.rego))]), _c("td", [_vm._v(_vm._s(quote.customerName))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.excess, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumberWithRounding(quote.labourHour, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.rate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.labourTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.partTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.subletTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.miscTotal, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-text-right"
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(quote.totalExGst, _vm.$userInfo.locale)))]), _c("td", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: _vm.isInvoiceColumnVisible,
        expression: "isInvoiceColumnVisible"
      }],
      staticClass: "has-text-centered"
    }, [_c("span", {
      staticClass: "icon",
      class: [quote.invoiced ? "has-text-success" : "has-text-danger"]
    }, [_c("i", {
      staticClass: "mdi mdi-24px",
      class: [quote.invoiced ? "mdi-check" : ""]
    })])]), _c("td", [_vm._v(_vm._s(_vm.$filters.camelCaseToDescription(_vm.getPropertyNameByValue(_vm.ormQuoteStatusTypes, quote.quoteStatusId))))]), _c("td", [_vm._v(_vm._s(quote.qdeStatus))]), _c("td", {
      staticClass: "has-text-right",
      class: {
        "has-text-danger": _vm.delta(quote) < 0,
        "has-text-success": _vm.delta(quote) >= 0
      }
    }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.delta(quote), _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("span", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: quote.excess > quote.totalExGst,
        expression: "quote.excess > quote.totalExGst"
      }],
      staticClass: "icon has-text-danger tooltip is-tooltip-danger is-tooltip-topright",
      attrs: {
        "data-tooltip": "Excess exceeds Total"
      }
    }, [_c("i", {
      staticClass: "mdi mdi-alert mdi-24px"
    })]), _c("button", {
      staticClass: "button is-danger is-small is-inverted tooltip is-tooltip-topright",
      attrs: {
        "data-tooltip": "Remove from batch"
      },
      on: {
        click: function click($event) {
          return _vm.removeFromBatch(index, quote);
        }
      }
    }, [_c("span", {
      staticClass: "icon is-medium"
    }, [_c("i", {
      staticClass: "mdi mdi-minus mdi-24px"
    })])])])]);
  }), _c("template", {
    slot: "empty"
  }, [_c("section", {
    staticClass: "section"
  }, [_c("div", {
    staticClass: "content has-text-grey has-text-centered"
  }, [_c("span", {
    attrs: {
      icon: "icon is-large"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-48px mdi-emoticon-sad"
  })]), _c("p", [_vm._v("Nothing")])])])])], 2)], 1)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Batched Quotes")])])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": true
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("orm-batching-view-side-menu", {
    ref: "sideMenu",
    attrs: {
      "entity-name": "".concat(_vm.entity.batchNo)
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    attrs: {
      "route-name": _vm.$route.name,
      "is-add-quote-active": _vm.isAddQuoteActive
    },
    on: {
      "update:isAddQuoteActive": function updateIsAddQuoteActive($event) {
        _vm.isAddQuoteActive = $event;
      },
      "update:is-add-quote-active": function updateIsAddQuoteActive($event) {
        _vm.isAddQuoteActive = $event;
      },
      "view-quote": _vm.viewQuote
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])]), _c("vue-fab", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.entity,
      expression: "entity"
    }],
    attrs: {
      "main-tooltip": "Batch Actions",
      position: "bottom-right",
      "z-index": 30,
      actions: _vm.fabActions
    },
    on: {
      submitQuotes: _vm.submitQuotes,
      submitInvoices: _vm.submitInvoices,
      toggleAddQuotes: _vm.toggleAddQuotes
    }
  })], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);






var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": false,
      "show-new": false,
      "show-print": false,
      "show-delete": false,
      "show-save": _vm.isCanEdit
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    attrs: {
      "route-name": _vm.$route.name,
      "is-add-quote-active": _vm.isAddQuoteActive,
      quotes: _vm.entities,
      filter: _vm.filter,
      "removed-quotes": _vm.removedQuotes
    },
    on: {
      "update:isAddQuoteActive": function updateIsAddQuoteActive($event) {
        _vm.isAddQuoteActive = $event;
      },
      "update:is-add-quote-active": function updateIsAddQuoteActive($event) {
        _vm.isAddQuoteActive = $event;
      },
      "view-quote": _vm.viewQuote,
      "quote-added": _vm.addQuote,
      "quote-removed": _vm.removeQuote,
      sort: _vm.sort
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4 ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Batch No: " + _vm._s(_vm.entityName) + " ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.OrmBatchingQuotes.name,
        params: {
          batchId: _vm.$route.params.batchId
        }
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_c("span", {
    staticClass: "has-badge-child-offset3"
  }, [_vm._v("Batched Quotes")]), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.count,
      expression: "count"
    }],
    staticClass: "has-badge-rounded has-badge-medium has-badge-info",
    attrs: {
      "data-badge": _vm.count
    }
  })])])], 1), _c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.OrmBatchingAvailableQuotes.name,
        params: {
          batchId: _vm.$route.params.batchId
        }
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_vm._v(" Work In Progress ")])])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45 ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Count")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.count))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Avg Labour (Hrs)")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatNumber(_vm.averageLabourUnits, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_c("span", [_vm._v("ALR")]), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.alr < _vm.alrLowerThreshold || _vm.alr > _vm.alrUpperThreshold,
      expression: "alr < alrLowerThreshold || alr > alrUpperThreshold"
    }],
    staticClass: "icon has-text-danger tooltip is-tooltip-danger",
    attrs: {
      "data-tooltip": _vm.alr < _vm.alrLowerThreshold ? "ALR is below threshold" : "ALR is above threshold"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-alert"
  })])]), _c("div", {
    staticClass: "control",
    class: {
      "has-text-danger": _vm.alr < _vm.alrLowerThreshold || _vm.alr > _vm.alrUpperThreshold
    }
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.alr, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Avg Labour ($)")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.averageLabourValues, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Avg Non-Labour ($)")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.averageNonLabourValues, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Avg Total")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.averageTotalExGst, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Adjusted Total")]), _c("div", {
    staticClass: "control"
  }, [_c("span", [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.adjustedTotal, _vm.$userInfo.locale)))])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm$value$perQuoteTot;
  var _vm = this,
    _c = _vm._self._c;
  return _c("article", {
    staticClass: "box has-sticky-tile"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Batch " + _vm._s(_vm.value.batchNo))])]), _c("div", {
    staticClass: "column is-narrow is-flex is-align-items-center is-justify-content-center"
  }, [_c("div", {
    staticClass: "is-flex is-flex-direction-column"
  }, [_c("span", {}, [_vm._v("Batch Status")]), _c("div", {
    staticClass: "select is-fullwidth is-small"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.batchStatus,
      expression: "value.batchStatus"
    }],
    attrs: {
      disabled: !_vm.isCanEdit
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.value, "batchStatus", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.ormBatchStatusType, function (status, propertyName) {
    return _c("option", {
      key: status,
      domProps: {
        value: status
      }
    }, [_vm._v(" " + _vm._s(_vm.$filters.formatOrmBatchStatus(propertyName)) + " ")]);
  }), 0)])])]), _c("div", {
    staticClass: "column"
  }, [_c("div", {
    staticClass: "is-flex is-flex-direction-row is-justify-content-space-between",
    staticStyle: {
      width: "100%"
    }
  }, [_c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("Batch Total Jobs")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.quotes.length))])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("Total Value Range")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency((_vm$value$perQuoteTot = _vm.value.perQuoteTotalMin) !== null && _vm$value$perQuoteTot !== void 0 ? _vm$value$perQuoteTot : 0, _vm.$userInfo.locale, false, 0)) + " - " + _vm._s(_vm.$filters.formatCurrency(_vm.value.perQuoteTotalMax, _vm.$userInfo.locale, false, 0)))])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("Actual ARC")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.actualARC, _vm.$userInfo.locale)))])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("Target ARC")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.value.agreedArc, _vm.$userInfo.locale)))])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("ALR Threshold")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.value.alrLowerThreshold, _vm.$userInfo.locale)) + " - " + _vm._s(_vm.$filters.formatCurrency(_vm.value.alrUpperThreshold, _vm.$userInfo.locale)))])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v(" Actual Labour Rate ")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold",
    class: {
      "has-text-danger": _vm.alr < _vm.alrLowerThreshold || _vm.alr > _vm.alrUpperThreshold
    }
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.alr, _vm.$userInfo.locale)) + " "), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.alr < _vm.alrLowerThreshold || _vm.alr > _vm.alrUpperThreshold,
      expression: "alr < alrLowerThreshold || alr > alrUpperThreshold"
    }],
    staticClass: "icon has-text-danger tooltip is-tooltip-danger",
    attrs: {
      "data-tooltip": _vm.alr < _vm.alrLowerThreshold ? "ALR is below threshold" : "ALR is above threshold"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-alert"
  })])])]), _c("div", {
    staticClass: "is-flex is-flex-direction-column is-align-items-center"
  }, [_c("span", {
    staticClass: "header-text-divider"
  }, [_vm._v("Estimated Adjusted Labour Rate")]), _c("span", {
    staticClass: "is-size-4 is-size-4 has-text-weight-bold",
    class: {
      "has-text-danger": _vm.adjustedAlr < _vm.alrLowerThreshold || _vm.adjustedAlr > _vm.alrUpperThreshold,
      "has-text-success": _vm.adjustedAlr >= _vm.alrLowerThreshold && _vm.adjustedAlr <= _vm.alrUpperThreshold
    }
  }, [_vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.adjustedAlr, _vm.$userInfo.locale)) + " "), _c("span", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.adjustedAlr < _vm.alrLowerThreshold || _vm.adjustedAlr > _vm.alrUpperThreshold,
      expression: "adjustedAlr < alrLowerThreshold || adjustedAlr > alrUpperThreshold"
    }],
    staticClass: "icon has-text-danger tooltip is-tooltip-danger",
    attrs: {
      "data-tooltip": _vm.adjustedAlr > _vm.alr ? "Increase the labour rate" : "Decrease the labour rate"
    }
  }, [_c("i", {
    staticClass: "mdi mdi-alert"
  })])])])])])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "table[data-v-1033601d] {\n  font-size: 0.9rem; /* Adjust as needed */\n}\n.table-container[data-v-1033601d] {\n  max-width: 96.5vw;\n  overflow-x: auto;\n}\n.has-text-nowrap[data-v-1033601d] {\n  white-space: nowrap;\n}\n.setting-page-tile input.custom-setting[data-v-1033601d] {\n  min-width: 100px;\n  max-width: 130px;\n}\n.button-add[data-v-1033601d] {\n  color: #3291ef !important;\n  border-color: #3291ef !important;\n  background: #fff;\n}\n.button-remove[data-v-1033601d] {\n  color: #d92550 !important;\n  border-color: #d92550 !important;\n  background: #fff;\n}\n.table-container .pretty[data-v-1033601d] {\n  vertical-align: top;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".slideInRight[data-v-746cc3c8] {\n  -webkit-animation: slideInRight 0.5s;\n  /* Safari 4+ */\n  /* Fx 5+ */\n  /* Opera 12+ */\n  animation: slideInRight 0.5s;\n  /* IE 10+, Fx 29+ */\n}\n.slideOutRight[data-v-746cc3c8] {\n  -webkit-animation: slideOutRight 0.5s;\n  /* Safari 4+ */\n  /* Fx 5+ */\n  /* Opera 12+ */\n  animation: slideOutRight 0.5s;\n  /* IE 10+, Fx 29+ */\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "input.is-uppercase[data-v-fea0d7c2] {\n  text-transform: uppercase;\n}\ninput.is-uppercase[data-v-fea0d7c2]::-webkit-input-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-fea0d7c2]::-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-fea0d7c2]:-moz-placeholder {\n  text-transform: none;\n}\ninput.is-uppercase[data-v-fea0d7c2]:-ms-input-placeholder {\n  text-transform: none;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".splitter[data-v-55997686] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  color: lightgray;\n}\n.header-text-divider[data-v-55997686] {\n  border-bottom: 1px solid lightgray;\n}\n.has-sticky-tile[data-v-55997686] {\n  position: sticky;\n  top: 3.25rem;\n  z-index: 31;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5024b548", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("366c6d5f", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("68254b00", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("2c84a6d8", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/components/VueFab/index.js":
/*!****************************************!*\
  !*** ./src/components/VueFab/index.js ***!
  \****************************************/
/*! exports provided: VueFab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VueFab", function() { return VueFab; });
// import VueFab from './vue-fab'
var VueFab = function VueFab(r) {
  return Promise.all(/*! require.ensure | components-chunk */[__webpack_require__.e(4), __webpack_require__.e("components-chunk~quote-detail-chunk"), __webpack_require__.e("components-chunk")]).then((function () {
    return r(__webpack_require__(/*! ./vue-fab.vue */ "./src/components/VueFab/vue-fab.vue"));
  }).bind(null, __webpack_require__)).catch(__webpack_require__.oe);
};


/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes.vue":
/*!**************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5 */ "./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5");
/* harmony import */ var _OrmBatchingAvailableQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingAvailableQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingAvailableQuotes.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js":
/*!**************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5":
/*!********************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5 ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes.vue?vue&type=template&id=008505e5");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes_vue_vue_type_template_id_008505e5__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue":
/*!***************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true */ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true");
/* harmony import */ var _OrmBatchingAvailableQuotes2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true */ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmBatchingAvailableQuotes2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "1033601d",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingAvailableQuotes2.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js":
/*!***************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true":
/*!************************************************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=style&index=0&id=1033601d&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_style_index_0_id_1033601d_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true":
/*!*********************************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingAvailableQuotes2.vue?vue&type=template&id=1033601d&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingAvailableQuotes2_vue_vue_type_template_id_1033601d_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingDetail.vue":
/*!*****************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingDetail.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true */ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true");
/* harmony import */ var _OrmBatchingDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingDetail.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true */ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmBatchingDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "746cc3c8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true":
/*!**************************************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=style&index=0&id=746cc3c8&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_style_index_0_id_746cc3c8_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true":
/*!***********************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingDetail.vue?vue&type=template&id=746cc3c8&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingDetail_vue_vue_type_template_id_746cc3c8_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListSideMenu.vue":
/*!***********************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListSideMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true */ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true");
/* harmony import */ var _OrmBatchingListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingListSideMenu.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true */ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmBatchingListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "fea0d7c2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingListSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true":
/*!********************************************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true ***!
  \********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=style&index=0&id=fea0d7c2&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_style_index_0_id_fea0d7c2_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListSideMenu.vue?vue&type=template&id=fea0d7c2&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListSideMenu_vue_vue_type_template_id_fea0d7c2_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListView.vue":
/*!*******************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListView.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingListView.vue?vue&type=template&id=2124ec6e */ "./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e");
/* harmony import */ var _OrmBatchingListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingListView.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingListView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e":
/*!*************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingListView.vue?vue&type=template&id=2124ec6e */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingListView.vue?vue&type=template&id=2124ec6e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingListView_vue_vue_type_template_id_2124ec6e__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingNewModal.vue":
/*!*******************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingNewModal.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8 */ "./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8");
/* harmony import */ var _OrmBatchingNewModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingNewModal.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingNewModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingNewModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js":
/*!*******************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingNewModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingNewModal.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingNewModal_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8":
/*!*************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8 ***!
  \*************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingNewModal.vue?vue&type=template&id=2cbe1bf8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingNewModal_vue_vue_type_template_id_2cbe1bf8__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingQuotes.vue":
/*!*****************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingQuotes.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingQuotes.vue?vue&type=template&id=510b1442 */ "./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442");
/* harmony import */ var _OrmBatchingQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingQuotes.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingQuotes.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js":
/*!*****************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingQuotes.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingQuotes_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442":
/*!***********************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442 ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingQuotes.vue?vue&type=template&id=510b1442 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingQuotes.vue?vue&type=template&id=510b1442");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingQuotes_vue_vue_type_template_id_510b1442__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView.vue":
/*!***************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingView.vue?vue&type=template&id=3eb0c730 */ "./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730");
/* harmony import */ var _OrmBatchingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingView.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js":
/*!***************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730":
/*!*********************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730 ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingView.vue?vue&type=template&id=3eb0c730 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView.vue?vue&type=template&id=3eb0c730");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView_vue_vue_type_template_id_3eb0c730__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView2.vue":
/*!****************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView2.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingView2.vue?vue&type=template&id=d1006f9c */ "./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c");
/* harmony import */ var _OrmBatchingView2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingView2.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingView2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingView2.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js":
/*!****************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingView2.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c":
/*!**********************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingView2.vue?vue&type=template&id=d1006f9c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingView2.vue?vue&type=template&id=d1006f9c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingView2_vue_vue_type_template_id_d1006f9c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue":
/*!***********************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingViewSideMenu.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4 */ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4");
/* harmony import */ var _OrmBatchingViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchingViewSideMenu.vue?vue&type=script&lang=js */ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchingViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/OrmBatchingViewSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingViewSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingViewSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4":
/*!*****************************************************************************************!*\
  !*** ./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4 ***!
  \*****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/OrmBatchingViewSideMenu.vue?vue&type=template&id=7c6b68b4");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchingViewSideMenu_vue_vue_type_template_id_7c6b68b4__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/columns.js":
/*!******************************************!*\
  !*** ./src/views/ormbatching/columns.js ***!
  \******************************************/
/*! exports provided: Columns, BatchQuoteColumns, AvailableQuoteColumns, BatchingQuoteColumns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Columns", function() { return Columns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BatchQuoteColumns", function() { return BatchQuoteColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvailableQuoteColumns", function() { return AvailableQuoteColumns; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BatchingQuoteColumns", function() { return BatchingQuoteColumns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var Columns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Batch No.', 'batchNo', true, 'desc', 'left'),
// new TableColumn('Insurer', 'insurer', true, 'desc', 'left'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Status', 'batchStatus', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Count', 'count', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Date', 'batchDate', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Agreed ARC', 'agreedArc', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Avg Labour (Hrs)', 'averageLabourUnit', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Avg Labour ($)', 'averageLabourValue', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ALR', 'averageLabourRate', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('ARC', 'averageRepairCost', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Adjustment', 'adjustment', false, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')
// new TableColumn('', 'action', false, 'desc', 'centered')
];
var BatchQuoteColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim No', 'claimNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'rego', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Name', 'customerName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Excess', 'excess', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour (Hrs)', 'labourUnit', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rate', 'rate', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour ($)', 'labourValue', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Part', 'partTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Sublet', 'subletTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Misc', 'miscTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total', 'totalExGst', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Inv\'d', 'invoiced', true, 'desc', 'centered'),
// new TableColumn('Inv No', 'invoiceNo', true, 'desc', 'left'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Status', 'quoteStatusId', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('QDE Status', 'qdeStatus', false, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Diff', 'delta', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var AvailableQuoteColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No.', 'quoteNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim No', 'claimNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'rego', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Name', 'customerName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Excess', 'excess', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour (Hrs)', 'labourUnit', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rate', 'rate', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour ($)', 'labourValue', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Part', 'partTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Sublet', 'subletTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Misc', 'miscTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total', 'totalExGst', true, 'desc', 'right'),
// new TableColumn('Diff', 'delta', true, 'desc', 'right'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('', 'action', false, 'desc', 'centered')];
var BatchingQuoteColumns = [new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote No', 'quoteNoRef', true, 'asc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Status', 'quoteStatus', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Job Stage', 'jobStage', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Quote Status', 'qdeStatus', false, 'desc', 'left'),
// new TableColumn('Severity', 'hasSeverity', true, 'desc', 'centered'),
// new TableColumn('Start Date', 'jobStart', true, 'desc', 'centered'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('End Date', 'jobEnd', true, 'desc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Days Elapsed', 'daysElapsed', true, 'desc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Claim No', 'claimNo', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rego', 'rego', true, 'desc', 'centered'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Name', 'fullName', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Insurer', 'insurer', true, 'desc', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Excess', 'excessInvoice', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour (Hrs)', 'labourHour', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Rate', 'rate', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Labour ($)', 'labourTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Part', 'partTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Sublet', 'subletTotal', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Misc', 'miscTotal', true, 'desc', 'right'),
// new TableColumn('Total Not Invoiced', 'totalNotInvoiced', true, 'desc', 'right'),
// new TableColumn('Debtor Invoice', 'debtorInvoice', true, 'desc', 'right'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Total', 'totalExGST', true, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Diff', 'delta', false, 'desc', 'right'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Notes', 'Notes', false, 'asc', 'centered')
// new TableColumn('In Scope', 'InScope', true, 'asc', 'centered')
];


/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics.vue":
/*!*****************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchStatistics.vue?vue&type=template&id=1fa60d45 */ "./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45");
/* harmony import */ var _OrmBatchStatistics_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchStatistics.vue?vue&type=script&lang=js */ "./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OrmBatchStatistics_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/components/OrmBatchStatistics.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js":
/*!*****************************************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45":
/*!***********************************************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45 ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics.vue?vue&type=template&id=1fa60d45 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics.vue?vue&type=template&id=1fa60d45");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics_vue_vue_type_template_id_1fa60d45__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics2.vue":
/*!******************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics2.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true */ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true");
/* harmony import */ var _OrmBatchStatistics2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OrmBatchStatistics2.vue?vue&type=script&lang=js */ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true */ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _OrmBatchStatistics2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "55997686",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/ormbatching/components/OrmBatchStatistics2.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js":
/*!******************************************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics2.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true":
/*!***************************************************************************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=style&index=0&id=55997686&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_style_index_0_id_55997686_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true":
/*!************************************************************************************************************!*\
  !*** ./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../../node_modules/babel-loader/lib!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/ormbatching/components/OrmBatchStatistics2.vue?vue&type=template&id=55997686&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OrmBatchStatistics2_vue_vue_type_template_id_55997686_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/ormbatching/storeMixin.js":
/*!*********************************************!*\
  !*** ./src/views/ormbatching/storeMixin.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'ormbatching';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff'
  })),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('quotes', {
    setQuoteReturnRoute: 'setReturnRoute',
    editStoreQuote: 'editStoreItem'
  }))
});

/***/ })

}]);
//# sourceMappingURL=ormbatching-chunk.js.map