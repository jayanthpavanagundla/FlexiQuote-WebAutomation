(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[20],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserDetail.vue?vue&type=script&lang=js":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserDetail.vue?vue&type=script&lang=js ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.trim.js */ "./node_modules/core-js/modules/es.string.trim.js");
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../services */ "./src/services/index.js");
/* harmony import */ var _ResetPasswordModal_vue__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./ResetPasswordModal.vue */ "./src/views/user/ResetPasswordModal.vue");



















// import Guid from '../../components/Guid'


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserDetail',
  inject: ['$vv'],
  components: {
    ResetPasswordModal: _ResetPasswordModal_vue__WEBPACK_IMPORTED_MODULE_20__["default"]
  },
  props: {
    value: null,
    //v-model
    isAllowedAccessNewPwa: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      showResetPasswordModal: false,
      localRoles: [],
      originalRoles: [],
      rolesKey: 0,
      emailUniqueError: false,
      usernameUniqueError: false,
      passwordMeetsCriteria: false,
      passwordMessage: '',
      showPassword: false,
      showConfirmPassword: false
    };
  },
  computed: {
    passwordsMatch: function passwordsMatch() {
      return this.value.password === this.value.confirmNewPassword;
    },
    AVAILABLE_ROLES: function AVAILABLE_ROLES() {
      return [{
        name: 'CustomerAdministrators',
        label: 'Administrators',
        isShow: !this.$userInfo.isSystemAdministrator || this.$userInfo.isSupportUser
      }, {
        name: 'CustomerUsers',
        label: 'Users',
        isShow: !this.$userInfo.isSystemAdministrator || this.$userInfo.isSupportUser
      }, {
        name: 'SupportUsers',
        label: 'Support Users',
        isShow: this.$userInfo.isSystemAdministrator && !this.$userInfo.isSupportUser
      }, {
        name: 'Users',
        label: 'Users',
        isShow: this.$userInfo.isSystemAdministrator && !this.$userInfo.isSupportUser
      }, {
        name: 'CustomerMobile',
        label: 'Mobile App Users',
        isShow: this.isAllowedAccessNewPwa
      }];
    },
    isCustomerAdmin: function isCustomerAdmin() {
      var found = (this.value.roles || []).find(function (r) {
        return r.active && !r.isNew;
      });
      if (!found) {
        return false;
      }
      return found.name === 'CustomerAdministrators';
    },
    isMobileAppUser: function isMobileAppUser() {
      return this.localRoles.some(function (role) {
        return role.name === 'CustomerMobile' && role.active;
      });
    },
    $v: function $v() {
      return this.$vv ? this.$vv : this.$v;
    }
  },
  watch: {
    'value.username': function valueUsername(newUsername) {
      if (this.value && this.value.isNew) {
        if (!this.value.profile) {
          this.$set(this.value, 'profile', {});
        }
        this.value.profile.displayName = (newUsername || '').trim();
      }
    },
    'value.email': function valueEmail(newEmail) {
      if (this.value && this.value.isNew) {
        if (!this.value.profile) {
          this.$set(this.value, 'profile', {});
        }
        this.value.profile.assetEmails[0].address = newEmail;
      }
    },
    value: {
      handler: function handler(val) {
        var _this = this;
        if (val) {
          this.localRoles = this.AVAILABLE_ROLES.filter(function (role) {
            return role.isShow;
          }).map(function (role) {
            var found = (_this.value.roles || []).find(function (r) {
              return r.name === role.name;
            });
            return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({
              name: role.name,
              label: role.label
            }, found ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, found) : {
              active: false
            });
          });
          if (this.localRoles.length > 0 && !this.originalRoles.length) {
            this.originalRoles = JSON.parse(JSON.stringify(this.localRoles));
          }
        }
      },
      immediate: true,
      deep: true
    },
    isMobileAppUser: {
      handler: function handler(newVal) {
        this.$emit('mobile-app-user-changed', newVal);
      },
      immediate: true
    },
    isAllowedAccessNewPwa: {
      handler: function handler(newVal) {
        var _this2 = this;
        if (newVal && this.value) {
          this.localRoles = this.AVAILABLE_ROLES.filter(function (role) {
            return role.isShow;
          }).map(function (role) {
            var found = (_this2.value.roles || []).find(function (r) {
              return r.name === role.name;
            });
            return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({
              name: role.name,
              label: role.label
            }, found ? Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_3__["default"])({}, found) : {
              active: false
            });
          });
          this.rolesKey++;
        }
      }
    }
  },
  created: function created() {
    this.originalRoles = JSON.parse(JSON.stringify(this.localRoles));
    // this.checkEmailUnique()
    // this.checkUsernameUnique()
  },
  mounted: function mounted() {
    var _this3 = this;
    this.$on('refreshProfile', function (newEntity) {
      _this3.innerValue = _cloneDeep(newEntity);
    });
    this.$v.detailGroup.$touch();
  },
  methods: {
    validateRoles: function validateRoles(changedRole) {
      var _this4 = this;
      if (changedRole.active) {
        this.localRoles.forEach(function (role) {
          if (role.name !== changedRole.name) {
            role.active = false;
          }
        });
      }
      var activeCount = this.localRoles.filter(function (r) {
        return r.active;
      }).length;
      if (activeCount === 0) {
        this.$notification.openNotificationWithType('danger', 'User', 'User must have at least one role!');
        this.localRoles = JSON.parse(JSON.stringify(this.originalRoles));
        this.rolesKey++;
        return;
      }
      this.localRoles.forEach(function (role) {
        var original = _this4.originalRoles.find(function (r) {
          return r.name === role.name;
        });
        if (original && original.userRoleId) {
          if (original.active && !role.active) {
            role.isDeleted = true;
          } else if (original.active === role.active) {
            role.isDeleted = original.isDeleted;
          }
        } else {
          role.isNew = role.active;
          role.isDeleted = false;
        }
      });
      this.value.roles = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this.localRoles);
      this.originalRoles = JSON.parse(JSON.stringify(this.localRoles));
      this.$emit('input', this.value);
    },
    toggleResetPasswordModal: function toggleResetPasswordModal() {
      this.showResetPasswordModal = !this.showResetPasswordModal;
    },
    // async checkEmailUnique() {
    //   this.emailUniqueError = false
    //   if (!this.value.email || !/^\S+@\S+\.\S+$/.test(this.value.email)) {
    //     return
    //   }
    //   const userId = this.value.isNew ? Guid.empty() : this.value.userId
    //   const isUnique = await UserService.checkEmailValidity(this.value.email, userId)
    //   this.emailUniqueError = !isUnique
    // },
    // async checkUsernameUnique() {
    //   this.usernameUniqueError = false
    //   if (!this.value.isNew) return
    //   if (!this.value.username) {
    //     return
    //   }
    //   const isNotUnique = await UserService.checkUsernameValidity(this.value.username)
    //   this.usernameUniqueError = isNotUnique
    // },
    validatePassword: function validatePassword(password) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!(!password || password.length === 0)) {
                _context.n = 1;
                break;
              }
              _this5.passwordMeetsCriteria = false;
              _this5.passwordMessage = '';
              return _context.a(2);
            case 1:
              _context.n = 2;
              return _services__WEBPACK_IMPORTED_MODULE_19__["UserService"].getPasswordComplexity(password).then(function (result) {
                _this5.passwordMeetsCriteria = result.passwordMeetsCriteria;
                _this5.passwordMessage = result.message;
              });
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    next();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6 ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);



var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_vm._m(0), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Username")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.username,
      expression: "value.username"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$vv.entity.username.$error
    },
    attrs: {
      type: "text",
      autocomplete: "off",
      disabled: !_vm.value.isNew && _vm.isCustomerAdmin
    },
    domProps: {
      value: _vm.value.username
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "username", $event.target.value);
      }
    }
  }), !_vm.$vv.entity.username.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Username is required ")]) : _vm._e(), !_vm.$vv.entity.username.isUniqueUsername ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("This username is already in use. ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Email")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.email,
      expression: "value.email"
    }],
    staticClass: "input",
    class: {
      "is-danger": _vm.$vv.entity.email.$error
    },
    attrs: {
      type: "text",
      autocomplete: "new-email"
    },
    domProps: {
      value: _vm.value.email
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "email", $event.target.value);
      }
    }
  }), !_vm.$vv.entity.email.email ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Please enter a valid email ")]) : _vm._e(), !_vm.$vv.entity.email.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Email is required ")]) : _vm._e(), !_vm.$vv.entity.email.isUniqueEmail ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("This email is already in use. ")]) : _vm._e()])])]), !_vm.value.isNew ? _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Password")]), _c("button", {
    staticClass: "button is-primary tooltip",
    attrs: {
      "data-tooltip": "Reset Password"
    },
    on: {
      click: _vm.toggleResetPasswordModal
    }
  }, [_c("span", [_vm._v("Reset Password")])])])]) : _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Password")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [(_vm.showPassword ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.password,
      expression: "value.password"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.password.$error ? "" : "is-danger",
    attrs: {
      autocomplete: "new-password",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.value.password) ? _vm._i(_vm.value.password, null) > -1 : _vm.value.password
    },
    on: {
      blur: function blur($event) {
        return _vm.validatePassword(_vm.value.password);
      },
      change: function change($event) {
        var $$a = _vm.value.password,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.value, "password", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.value, "password", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.value, "password", $$c);
        }
      }
    }
  }) : (_vm.showPassword ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.password,
      expression: "value.password"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.password.$error ? "" : "is-danger",
    attrs: {
      autocomplete: "new-password",
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.value.password, null)
    },
    on: {
      blur: function blur($event) {
        return _vm.validatePassword(_vm.value.password);
      },
      change: function change($event) {
        return _vm.$set(_vm.value, "password", null);
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.password,
      expression: "value.password"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.password.$error ? "" : "is-danger",
    attrs: {
      autocomplete: "new-password",
      type: _vm.showPassword ? "text" : "password"
    },
    domProps: {
      value: _vm.value.password
    },
    on: {
      blur: function blur($event) {
        return _vm.validatePassword(_vm.value.password);
      },
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "password", $event.target.value);
      }
    }
  }), !_vm.$vv.entity.password.required && _vm.value.isNew ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Password is required ")]) : _vm._e(), !_vm.passwordMeetsCriteria ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v(" " + _vm._s(_vm.passwordMessage) + " ")]) : _vm._e()]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        _vm.showPassword = !_vm.showPassword;
      }
    }
  }, [_c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" " + _vm._s(_vm.showPassword ? "visibility" : "visibility_off") + " ")])])])])])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Confirm Password")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control is-expanded"
  }, [(_vm.showConfirmPassword ? "text" : "password") === "checkbox" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.confirmNewPassword,
      expression: "value.confirmNewPassword"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.confirmNewPassword.$error ? "" : "is-danger",
    attrs: {
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.value.confirmNewPassword) ? _vm._i(_vm.value.confirmNewPassword, null) > -1 : _vm.value.confirmNewPassword
    },
    on: {
      change: function change($event) {
        var $$a = _vm.value.confirmNewPassword,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.value, "confirmNewPassword", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.value, "confirmNewPassword", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.value, "confirmNewPassword", $$c);
        }
      }
    }
  }) : (_vm.showConfirmPassword ? "text" : "password") === "radio" ? _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.confirmNewPassword,
      expression: "value.confirmNewPassword"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.confirmNewPassword.$error ? "" : "is-danger",
    attrs: {
      type: "radio"
    },
    domProps: {
      checked: _vm._q(_vm.value.confirmNewPassword, null)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.value, "confirmNewPassword", null);
      }
    }
  }) : _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.confirmNewPassword,
      expression: "value.confirmNewPassword"
    }],
    staticClass: "input",
    class: !_vm.$vv.entity.confirmNewPassword.$error ? "" : "is-danger",
    attrs: {
      type: _vm.showConfirmPassword ? "text" : "password"
    },
    domProps: {
      value: _vm.value.confirmNewPassword
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.value, "confirmNewPassword", $event.target.value);
      }
    }
  }), _vm.value.password && _vm.value.confirmNewPassword && !_vm.passwordsMatch && _vm.value.isNew ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Passwords do not match.")]) : _vm._e(), !_vm.$vv.entity.confirmNewPassword.required && _vm.value.isNew ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Confirm Password is required ")]) : _vm._e()]), _c("p", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button",
    on: {
      click: function click($event) {
        _vm.showConfirmPassword = !_vm.showConfirmPassword;
      }
    }
  }, [_c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("span", {
    staticClass: "mso mso-24px"
  }, [_vm._v(" " + _vm._s(_vm.showConfirmPassword ? "visibility" : "visibility_off") + " ")])])])])])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Status")]), _c("div", [_c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.active,
      expression: "value.active"
    }],
    attrs: {
      id: "chk-pretty-customer-type",
      name: "chk-pretty-customer-type",
      type: "radio"
    },
    domProps: {
      value: true,
      checked: _vm._q(_vm.value.active, true)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.value, "active", true);
      }
    }
  }), _vm._m(1)]), _c("div", {
    staticClass: "pretty p-default p-round p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.value.active,
      expression: "value.active"
    }],
    attrs: {
      id: "chk-pretty-customer-type",
      name: "chk-pretty-customer-type",
      type: "radio"
    },
    domProps: {
      value: false,
      checked: _vm._q(_vm.value.active, false)
    },
    on: {
      change: function change($event) {
        return _vm.$set(_vm.value, "active", false);
      }
    }
  }), _vm._m(2)])])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half pb-0"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Roles")]), _c("div", {
    key: _vm.rolesKey
  }, _vm._l(_vm.localRoles, function (role, index) {
    return _c("div", {
      key: index
    }, [_c("div", {
      staticClass: "columns"
    }, [_c("div", {
      staticClass: "column"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: role.active,
        expression: "role.active"
      }],
      attrs: {
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(role.active) ? _vm._i(role.active, null) > -1 : role.active
      },
      on: {
        change: [function ($event) {
          var $$a = role.active,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(role, "active", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(role, "active", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(role, "active", $$c);
          }
        }, function ($event) {
          return _vm.validateRoles(role);
        }]
      }
    }), _vm._m(3, true)])]), _c("div", {
      staticClass: "column is-four-fifths"
    }, [_vm._v(" " + _vm._s(role.label) + " "), role.name === "CustomerMobile" ? _c("span", {
      staticClass: "tag is-info is-light ml-2"
    }, [_vm._v(" Mobile users can only flexiquote mobile app and don't have access to the web app. ")]) : _vm._e()])])]);
  }), 0)])]), _c("reset-password-modal", {
    attrs: {
      active: _vm.showResetPasswordModal
    },
    on: {
      close: function close($event) {
        _vm.showResetPasswordModal = false;
      }
    },
    model: {
      value: _vm.value,
      callback: function callback($$v) {
        _vm.value = $$v;
      },
      expression: "value"
    }
  })], 1)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Detail Info")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Active")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("label", [_vm._v("Inactive")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("span", {
    staticClass: "icon mso"
  }, [_vm._v(" check ")]), _c("label")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./src/views/user/UserDetail.vue":
/*!***************************************!*\
  !*** ./src/views/user/UserDetail.vue ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserDetail.vue?vue&type=template&id=2f90d1b6 */ "./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6");
/* harmony import */ var _UserDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserDetail.vue?vue&type=script&lang=js */ "./src/views/user/UserDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/user/UserDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/user/UserDetail.vue?vue&type=script&lang=js":
/*!***************************************************************!*\
  !*** ./src/views/user/UserDetail.vue?vue&type=script&lang=js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6":
/*!*********************************************************************!*\
  !*** ./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6 ***!
  \*********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./UserDetail.vue?vue&type=template&id=2f90d1b6 */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/user/UserDetail.vue?vue&type=template&id=2f90d1b6");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserDetail_vue_vue_type_template_id_2f90d1b6__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=20.js.map