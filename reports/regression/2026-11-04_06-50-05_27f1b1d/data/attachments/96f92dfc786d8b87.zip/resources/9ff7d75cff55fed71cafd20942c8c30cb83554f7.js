(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["receiptpayment-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js":
/*!**************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js ***!
  \**************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.includes.js */ "./node_modules/core-js/modules/es.array.includes.js");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.string.includes.js */ "./node_modules/core-js/modules/es.string.includes.js");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_directives__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/components/directives */ "./src/components/directives/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _columns__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./columns */ "./src/views/receiptpayment/columns.js");
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_BulmaTable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/components/BulmaTable */ "./src/components/BulmaTable/index.js");

















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReceiptPaymentDetail',
  inject: ['$vv'],
  components: {
    BulmaTable: _components_BulmaTable__WEBPACK_IMPORTED_MODULE_16__["default"],
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_15__["default"]
  },
  directives: {
    FocusInserted: _components_directives__WEBPACK_IMPORTED_MODULE_10__["FocusInserted"]
  },
  props: {
    value: null,
    disableChange: {
      type: Boolean,
      default: true
    },
    readOnlyView: {
      type: Boolean
    },
    canPrintStatement: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(this.value),
      isDisable: false,
      buttonText: 'Add',
      totalAmount: 0.0,
      bankAccount: null,
      chequeNumber: '',
      isTitleCheck: false,
      moneyMask: {
        precision: 2
      },
      query: '',
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }]
    };
  },
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    },
    columns: function columns() {
      return _columns__WEBPACK_IMPORTED_MODULE_14__["ReceiptPaymentColumns"];
    },
    activeItems: function activeItems() {
      // return this.innerValue.invoiceItems
      var query = this.query.toLowerCase();
      var results = this.innerValue.invoiceItems ? this.innerValue.invoiceItems.filter(function (q) {
        return q.invoiceRef.toLowerCase().includes(query);
      }) : this.innerValue.invoiceItems;
      return results;
    },
    addButton: function addButton() {
      return {
        'mdi-plus': true
      };
    },
    addButtonClass: function addButtonClass() {
      return {
        // 'is-primary': true
        'is-success': true
        // 'is-loading': this.assetButtonLoading
      };
    }
  },
  watch: {
    innerValue: {
      handler: function handler(newVal, oldVal) {
        this.$emit('input', newVal);
      },
      deep: true
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_12__["EventHubTypes"].EntitySaved);
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_12__["EventHubTypes"].EntitySaved, function () {
      _this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_13___default()(_this.value);
      _this.isTitleCheck = false;
    });
    this.$v.entity.$touch();
  },
  created: function created() {
    var _this2 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (!_this2.disableChange) {
              _this2.isTitleCheck = true;
              _this2.chequeNumber = _this2.innerValue.invoiceItems[0].chequeNo;
              _this2.innerValue.invoiceItems.forEach(function (items) {
                items.receivedAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(items.receivedAmount, 2);
              });
            }
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    printStatement: function printStatement() {
      this.$emit('printStatement');
    },
    titleCheckboxChanged: function titleCheckboxChanged(value) {
      if (this.disableChange) {
        if (value) {
          var filter = this.activeItems.filter(function (id) {
            return id.isChecked === false;
          });
          if (filter.length === this.activeItems.length) {
            this.activeItems.forEach(function (item) {
              item.isChecked = true;
              item.receivedAmount = item.receivedAmount !== 0 ? item.receivedAmount : Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(item.balance, 2);
            });
          } else {
            filter.forEach(function (item) {
              item.isChecked = true;
              item.receivedAmount = item.receivedAmount !== 0 ? item.receivedAmount : Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(item.balance, 2);
            });
          }
        } else {
          var _filter = this.activeItems.filter(function (i) {
            return i.isChecked === true;
          });
          if (_filter.length === this.activeItems.length) {
            this.activeItems.forEach(function (item) {
              item.isChecked = false;
              item.receivedAmount = 0;
            });
          }
        }
        this.calculateTotal();
      }
    },
    reset: function reset() {
      this.query = '';
      this.calculateTotal();
    },
    //Calculating Total Amount
    calculateTotal: function calculateTotal() {
      this.innerValue.totalAmount = 0.0;
      for (var i = 0; i < this.activeItems.length; i++) {
        this.innerValue.totalAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(this.innerValue.totalAmount, 2) + Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(this.activeItems[i].receivedAmount, 2), 2);
      }
    },
    addReceivedAmount: function addReceivedAmount(check, balance, index) {
      if (this.disableChange) {
        if (check) {
          this.activeItems[index].receivedAmount = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_11__["roundAwayFromZero"])(balance, 2);
          this.activeItems[index].chequeNo = this.chequeNumber;
        } else {
          this.activeItems[index].receivedAmount = 0.0;
          this.activeItems[index].chequeNo = '';
        }
        this.checkTitleCheck(check);
        this.calculateTotal();
      }
    },
    checkTitleCheck: function checkTitleCheck(check) {
      var filter = this.activeItems.filter(function (id) {
        return id.isChecked === !check;
      });
      if (filter.length === 0 && check) {
        this.isTitleCheck = true;
      } else {
        this.isTitleCheck = false;
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js":
/*!****************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js ***!
  \****************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/components/AppSideMenu */ "./src/components/AppSideMenu/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./route-types */ "./src/views/receiptpayment/route-types.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReceiptPaymentSideMenu',
  components: {
    AppSideMenu: _components_AppSideMenu__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  mixins: [_components_mixins_filters__WEBPACK_IMPORTED_MODULE_2__["NumberFiltersMixin"]],
  props: {
    entityName: {
      type: String,
      default: ''
    }
  },
  data: function data() {
    return {};
  },
  computed: {
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_1__["default"];
    }
  },
  mounted: function mounted() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js":
/*!************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js ***!
  \************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.push.js */ "./node_modules/core-js/modules/es.array.push.js");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _ReceiptPaymentSideMenu__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./ReceiptPaymentSideMenu */ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue");
/* harmony import */ var _ReceiptPaymentService__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./ReceiptPaymentService */ "./src/views/receiptpayment/ReceiptPaymentService.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./route-types */ "./src/views/receiptpayment/route-types.js");
/* harmony import */ var _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @/components/AppDetailHeader */ "./src/components/AppDetailHeader/index.js");
/* harmony import */ var _views_quickinvoice_QuickInvoiceService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @/views/quickinvoice/QuickInvoiceService */ "./src/views/quickinvoice/QuickInvoiceService.js");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
/* harmony import */ var _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../receiptentry/route-types */ "./src/views/receiptentry/route-types.js");
/* harmony import */ var _components_http_status__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @/components/http-status */ "./src/components/http-status/index.js");
/* harmony import */ var _components_EventBus__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @/components/EventBus */ "./src/components/EventBus.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./storeMixin */ "./src/views/receiptpayment/storeMixin.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! lodash/isEmpty */ "./node_modules/lodash/isEmpty.js");
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/components/printpreview/route-types */ "./src/components/printpreview/route-types.js");
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");
/* harmony import */ var _store_utils__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @/store/utils */ "./src/store/utils/index.js");
/* harmony import */ var _components_mixins_filters__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @/components/mixins/filters */ "./src/components/mixins/filters/index.js");
/* harmony import */ var _classes_viewmodels__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/classes/viewmodels */ "./src/classes/viewmodels/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _ReceiptPaymentValidation__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./ReceiptPaymentValidation */ "./src/views/receiptpayment/ReceiptPaymentValidation.js");







































var title = 'Receipt Entry';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ReceiptPaymentView',
  components: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({
    AppDetailHeader: _components_AppDetailHeader__WEBPACK_IMPORTED_MODULE_21__["default"]
  }, _ReceiptPaymentSideMenu__WEBPACK_IMPORTED_MODULE_18__["default"].name, _ReceiptPaymentSideMenu__WEBPACK_IMPORTED_MODULE_18__["default"]), "UnsavedModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__["UnsavedModal"]), "ConfirmModal", _components_BulmaModal__WEBPACK_IMPORTED_MODULE_23__["ConfirmModal"]),
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_28__["default"], _components_mixins_filters__WEBPACK_IMPORTED_MODULE_35__["DateTimeFiltersMixin"], _ReceiptPaymentValidation__WEBPACK_IMPORTED_MODULE_38__["default"]],
  props: {
    returnUrl: String,
    type: String
  },
  data: function data() {
    return {
      entity: null,
      isUnsavedModalActive: false,
      // isSaveConflictModalActive: false,
      isSkipSave: false,
      isSaveContinue: false,
      toRoute: null,
      // stores "to" route of beforeRouteLeave
      isSaveButton: false,
      counter: 0,
      isConfirmModalActive: false
    };
  },
  computed: {
    validateError: function validateError() {
      return this.$v.$error || this.$v.receiptEntryGroup.$error;
    },
    canPrintStatement: function canPrintStatement() {
      return this.entity && Array.isArray(this.entity.invoiceItems) ? this.entity.invoiceItems.some(function (i) {
        return i.isChecked === true;
      }) : false;
    }
  },
  watch: {
    'entity.invoiceItems': {
      handler: lodash_debounce__WEBPACK_IMPORTED_MODULE_30___default()(function (newVal) {
        if (newVal) {
          this.$forceUpdate();
          // this.saveSnapshot(_cloneDeep(this.entity))
          this.isSaveContinue = false;
          this.isSaveButton = false;
          var found = this.entity.invoiceItems.find(function (id) {
            return id.isChecked === true;
          });
          if (found) {
            this.isSaveButton = true;
          }
        }
      }, 500),
      deep: true
    }
  },
  beforeDestroy: function beforeDestroy() {
    if (lodash_isEmpty__WEBPACK_IMPORTED_MODULE_31___default()(this.returnRoute)) {
      this.setReadOnlyView(false);
    }
    // this.clearSessionStorage()
    // this.clearSnapshots(this.entity.itemQuickId)
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            if (_this.returnUrl) {
              _this.persistQueries();
              _this.replaceRoute(_this.$route.params.AssetId);
            }
            _context.n = 1;
            return _this.getEntity();
          case 1:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  mounted: function mounted() {},
  methods: {
    onHeaderButtonClicked: function onHeaderButtonClicked(action) {
      switch (action) {
        case _enums__WEBPACK_IMPORTED_MODULE_27__["AppHeaderButtonTypes"].AddNew:
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_27__["AppHeaderButtonTypes"].Print:
          this.print1();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_27__["AppHeaderButtonTypes"].Delete:
          this.entity.deleted = true;
          this.save(true);
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_27__["AppHeaderButtonTypes"].Save:
          // this.confirmSave()
          this.directSave();
          break;
        case _enums__WEBPACK_IMPORTED_MODULE_27__["AppHeaderButtonTypes"].Cancel:
          this.cancel();
          break;
      }
    },
    getEntity: function getEntity() {
      var _arguments = arguments,
        _this2 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2() {
        var reset, _t;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              reset = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              _context2.p = 1;
              _this2.$showSpinner();
              if (reset) {
                _this2.clearSessionStorage();
                _this2.clearSnapshots(_this2.$route.params.AssetId);
              }
              if (_this2.currentSnapshot) {
                _context2.n = 2;
                break;
              }
              _context2.n = 2;
              return _this2.getStoreItem(_this2.$route.params.AssetId);
            case 2:
              _this2.entity = _this2.currentSnapshot;
              _context2.n = 4;
              break;
            case 3:
              _context2.p = 3;
              _t = _context2.v;
              _this2.$notification.openMessageXhrError('', _t);
            case 4:
              _this2.$hideSpinner();
              // await this.getStoreItem(this.$route.params.AssetId)
              // this.entity = _cloneDeep(this.currentSnapshot)
            case 5:
              return _context2.a(2);
          }
        }, _callee2, null, [[1, 3]]);
      }))();
    },
    directSave: function directSave() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var result;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (!_this3.validateError) {
                _context3.n = 1;
                break;
              }
              _this3.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
              return _context3.a(2, false);
            case 1:
              _context3.n = 2;
              return _this3.save();
            case 2:
              result = _context3.v;
              return _context3.a(2, result);
          }
        }, _callee3);
      }))();
    },
    confirmSave: function confirmSave() {
      if (this.validateError) {
        this.$notification.openNotificationWithType('danger', title, 'Validation errors. Please fix before saving');
        return false;
      }
      this.isConfirmModalActive = true;
    },
    saveEntity: function saveEntity(confirmSave) {
      var _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this4.isConfirmModalActive = false;
              if (confirmSave === 'ok') {
                _this4.save();
              } else if (confirmSave === 'print') {
                _this4.print1();
              }
            case 1:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    save: function save(isDelete) {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee5() {
        var response, found, _t2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              _context5.p = 0;
              _this5.$showSpinner('Saving...');
              _this5.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_this5.entity));
              if (!_this5.entity.isNew) {
                _context5.n = 2;
                break;
              }
              _context5.n = 1;
              return _ReceiptPaymentService__WEBPACK_IMPORTED_MODULE_19__["default"].putReceiptPayment(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_this5.entity), _this5.snapshotDiff);
            case 1:
              response = _context5.v;
              _context5.n = 5;
              break;
            case 2:
              if (!_this5.snapshotDiff) {
                _context5.n = 4;
                break;
              }
              _context5.n = 3;
              return _ReceiptPaymentService__WEBPACK_IMPORTED_MODULE_19__["default"].putReceiptPayment(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(_this5.entity), _this5.snapshotDiff);
            case 3:
              response = _context5.v;
              _context5.n = 5;
              break;
            case 4:
              _this5.$notification.openNotificationWithType('warning', title, 'No changes detected. Not saved');
              return _context5.a(2, false);
            case 5:
              _this5.$hideSpinner();
              if (!_this5.isSaveContinue) {
                _context5.n = 7;
                break;
              }
              found = _this5.entity.invoiceItems.find(function (id) {
                return id.isChecked === true;
              });
              if (found) {
                //await this.print1()
                _this5.$notification.success('Receipt Entry', isDelete ? 'Receipt Entry set to In-Active' : 'Save successful');
              }
              _context5.n = 6;
              return _this5.getEntity(true);
            case 6:
              _context5.n = 13;
              break;
            case 7:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].OK)) {
                _context5.n = 9;
                break;
              }
              _context5.n = 8;
              return _this5.getEntity(true);
            case 8:
              _this5.$notification.success('Receipt Entry', isDelete ? 'Receipt Entry set to In-Active' : 'Save successful');
              _this5.entity.totalAmount = 0;
              _this5.isSaveButton = false;
              _context5.n = 13;
              break;
            case 9:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].NO_CONTENT)) {
                _context5.n = 11;
                break;
              }
              _context5.n = 10;
              return _this5.getEntity(true);
            case 10:
              _this5.$notification.success('Receipt Entry', isDelete ? 'Receipt Entry set to In-Active' : 'Save successful');
              _this5.$router.push({
                name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_24__["default"].ReceiptEntryListView.name
              });
              _context5.n = 13;
              break;
            case 11:
              if (!(response && response.status === _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CREATED)) {
                _context5.n = 13;
                break;
              }
              _this5.isUnsavedModalActive = false;
              _context5.n = 12;
              return _this5.getEntity(true);
            case 12:
              _this5.$notification.success('Receipt Entry', isDelete ? 'Receipt Entry set to In-Active' : 'Save successful');
              _this5.entity.totalAmount = 0;
            case 13:
              // reloadData()

              _this5.$eventHub.$emit(_enums__WEBPACK_IMPORTED_MODULE_27__["EventHubTypes"].EntitySaved);
              return _context5.a(2, true);
            case 14:
              _context5.p = 14;
              _t2 = _context5.v;
              _components_EventBus__WEBPACK_IMPORTED_MODULE_26__["default"].$emit('serviceError', _t2.response.status);
              if (_t2.response.status !== _components_http_status__WEBPACK_IMPORTED_MODULE_25__["default"].CONFLICT) {
                _this5.$notification.openMessageXhrError('Receipt Entry', _t2);
              }
              return _context5.a(2, false);
            case 15:
              _context5.p = 15;
              _this5.$hideSpinner();
              return _context5.f(15);
            case 16:
              return _context5.a(2);
          }
        }, _callee5, null, [[0, 14, 15, 16]]);
      }))();
    },
    deleteEntity: function deleteEntity(saveEntity) {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this6.entity.deleted = true;
              if (saveEntity) {
                _this6.save(true);
              }
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    cancel: function cancel() {
      this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(this.entity));
      if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue && this.isSaveButton && !this.readOnlyView) {
        this.isUnsavedModalActive = true;
      } else {
        if (this.returnUrl) {
          this.clearSessionStorage();
          this.clearSnapshots(this.entity.invoiceId);
          window.location.href = "".concat("").concat(this.returnUrl);
        } else if (this.toRoute) {
          this.$router.push(this.toRoute.fullPath);
        } else if (this.returnRoute && !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_31___default()(this.returnRoute)) {
          this.$router.push(this.returnRoute.fullPath);
        } else {
          this.$router.push({
            name: _receiptentry_route_types__WEBPACK_IMPORTED_MODULE_24__["default"].ReceiptEntryListView.name
          });
        }
      }
    },
    print: function print() {
      var params = {
        reportname: 'rptTableItemsQuick',
        RecordID: this.entity.assetId,
        CompanyID: this.$userInfo.companyId
      };
      var url = "".concat("", "/modules/reports/printpreview.aspx?") + Object.keys(params).map(function (e) {
        return "".concat(e, "=").concat(params[e]);
      }).join('&');
      window.open(url, '_blank');
    },
    saveContinue: function saveContinue() {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee7() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              _this7.isUnsavedModalActive = false;
              _this7.isSaveContinue = true;
              _context7.n = 1;
              return _this7.save();
            case 1:
              _this7.isSaveContinue = _context7.v;
              if (_this7.isSaveContinue) {
                _this7.cancel();
              }
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    print1: function print1() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee8() {
        var partsXml, customerId, assetType, params, keyValuePairs, parameterId, assetEmail, emailer, routeData;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              //Parse XML
              partsXml = _this8.generatePartsXml(); //Get CustomerId
              if (!_this8.entity.customerId) {
                customerId = _this8.entity.insurerId;
                assetType = _enums__WEBPACK_IMPORTED_MODULE_27__["AssetTypes"].Insurer;
              } else {
                customerId = _this8.entity.customerId;
                assetType = _enums__WEBPACK_IMPORTED_MODULE_27__["AssetTypes"].Customer;
              }

              //Set Parametters
              params = Object.assign({
                REPORTTITLE: 'OFFICIAL RECEIPT',
                reportDocId: _this8.$lzstring.compressToBase64(partsXml),
                COMPANYNAME: _this8.$userInfo.companyName,
                CustomerId: customerId,
                CompanyID: _this8.$userInfo.companyId,
                TotalAmount: _this8.entity.totalAmount
              });
              keyValuePairs = _classes_viewmodels__WEBPACK_IMPORTED_MODULE_36__["KeyValuePairModel"].convertToKeyValuePairs(params);
              _this8.addReportParameters(keyValuePairs);
              parameterId = _this8.$guid.newGuid();
              _store_utils__WEBPACK_IMPORTED_MODULE_34__["default"].setLocalStorage(parameterId, 'parameters', keyValuePairs);
              _context8.n = 1;
              return _views_quickinvoice_QuickInvoiceService__WEBPACK_IMPORTED_MODULE_22__["default"].getAssetEmail(customerId, assetType);
            case 1:
              assetEmail = _context8.v;
              emailer = new _classes__WEBPACK_IMPORTED_MODULE_33__["Emailer"]();
              if (assetEmail) {
                emailer.toEmails.push(assetEmail);
              }
              emailer.assetId = customerId;
              emailer.assetTypes = [_enums__WEBPACK_IMPORTED_MODULE_27__["AssetTypes"].Customer, _enums__WEBPACK_IMPORTED_MODULE_27__["AssetTypes"].Insurer];
              emailer.subject = 'Receipt Payment to ' + _this8.entity.companyName;
              emailer.reportName = 'ReceiptPayment_' + _this8.entity.companyName;
              _this8.addEmailer(emailer);
              _store_utils__WEBPACK_IMPORTED_MODULE_34__["default"].setLocalStorage(emailer.id, 'emailer', emailer);
              routeData = _this8.$router.resolve({
                name: _components_printpreview_route_types__WEBPACK_IMPORTED_MODULE_32__["default"].PrintPreview.name,
                params: {
                  reportName: 'AT_OfficialReceiptList'
                },
                query: {
                  parameterId: parameterId,
                  emailerId: emailer.id,
                  isNewTab: true
                }
              });
              window.open(routeData.href, '_blank');
            case 2:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    generatePartsXml: function generatePartsXml() {
      var xmlDoc = document.implementation.createDocument('', '', null);
      var mode;
      var reference;
      var bsb = '';
      var officialReceiptListElement = xmlDoc.createElement('AT_OfficialReceiptList');
      for (var i = 0; i < this.entity.invoiceItems.length; i++) {
        if (this.entity.invoiceItems[i].isChecked) {
          var officialReceiptElement = xmlDoc.createElement('OfficialReceiptList');
          var invNoElement = xmlDoc.createElement('InvNo');
          var invDateAmountElement = xmlDoc.createElement('InvDate');
          var invAmountElement = xmlDoc.createElement('InvAmount');
          var balanceElement = xmlDoc.createElement('Balance');
          var paymentElement = xmlDoc.createElement('Payment');
          var referenceElement = xmlDoc.createElement('Reference');
          var modeElement = xmlDoc.createElement('mode');
          var bsbElement = xmlDoc.createElement('bsb');
          if (this.readOnlyView && Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_37__["roundAwayFromZero"])(this.entity.invoiceItems[i].balance, 2) === 0 || this.entity.isNew && Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_37__["roundAwayFromZero"])(this.entity.invoiceItems[i].balance, 2) === Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_37__["roundAwayFromZero"])(this.entity.invoiceItems[i].receivedAmount, 2)) {
            mode = 'Full';
          } else {
            mode = 'Partial';
          }
          if (!this.entity.invoiceItems[i].chequeNo) {
            reference = '';
          } else {
            reference = this.entity.invoiceItems[i].chequeNo;
          }
          var currentBalance = this.readOnlyView ? this.entity.invoiceItems[i].balance : this.entity.invoiceItems[i].balance - this.entity.invoiceItems[i].receivedAmount;
          invNoElement.innerHTML = this.entity.invoiceItems[i].invoiceRef.escapeXml();
          invDateAmountElement.innerHTML = this.formatDateLocale(this.entity.invoiceItems[i].invoiceDate, this.$userInfo.locale).toString().escapeXml();
          invAmountElement.innerHTML = this.entity.invoiceItems[i].invoiceIncGst.toString().escapeXml();
          balanceElement.innerHTML = currentBalance.toString().escapeXml();
          paymentElement.innerHTML = this.entity.invoiceItems[i].receivedAmount.toString().escapeXml();
          referenceElement.innerHTML = reference.escapeXml();
          modeElement.innerHTML = mode.escapeXml();
          bsbElement.innerHTML = bsb.escapeXml();
          officialReceiptElement.appendChild(invNoElement);
          officialReceiptElement.appendChild(invDateAmountElement);
          officialReceiptElement.appendChild(invAmountElement);
          officialReceiptElement.appendChild(balanceElement);
          officialReceiptElement.appendChild(paymentElement);
          officialReceiptElement.appendChild(referenceElement);
          officialReceiptElement.appendChild(modeElement);
          officialReceiptElement.appendChild(bsbElement);
          officialReceiptListElement.appendChild(officialReceiptElement);
        }
      }
      xmlDoc.appendChild(officialReceiptListElement);
      return new XMLSerializer().serializeToString(xmlDoc);
    },
    formatDateLocale: function formatDateLocale(value, locale) {
      var format = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '2-digit';
      var date = new Date(Date.parse("".concat(value)));
      var options = {
        year: 'numeric',
        month: format,
        day: '2-digit'
      };
      if (Intl) {
        return Intl.DateTimeFormat(locale, options).format(date);
      } else {
        return date.toLocaleDateString(locale, options);
      }
    },
    skipSave: function skipSave() {
      this.isUnsavedModalActive = false;
      this.isSkipSave = true;
      this.cancel();
    },
    redirectToRoute: function redirectToRoute() {
      if (this.toRoute) {
        this.$router.push(this.toRoute.fullPath);
      } else if (!this.entity.isNew) {
        this.cancel();
      }
    },
    closeModal: function closeModal() {
      this.isUnsavedModalActive = false;
      // this.isSaveConflictModalActive = false
      this.isSaveContinue = false;
      this.toRoute = null;
    },
    reloadData: function reloadData() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee9() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              // this.isSaveConflictModalActive = false
              _this9.isSaveContinue = false;
              _context9.n = 1;
              return _this9.getEntity(true);
            case 1:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    persistQueries: function persistQueries() {
      if (this.returnUrl) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|receiptpayment|returnUrl"), this.returnUrl);
      }
      if (this.type) {
        sessionStorage.setItem("".concat(this.$userInfo.sessionId, "|receiptentry|type"), this.type);
      }
    },
    removeQueries: function removeQueries() {
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|receiptentry|returnUrl"));
      sessionStorage.removeItem("".concat(this.$userInfo.sessionId, "|receiptentry|type"));
    },
    clearSessionStorage: function clearSessionStorage() {
      this.removeQueries();
    },
    replaceRoute: function replaceRoute(id) {
      var newMeta = Object.assign(this.$route.meta, {
        returnUrl: this.returnUrl,
        type: this.type
      });
      this.$router.replace({
        name: _route_types__WEBPACK_IMPORTED_MODULE_20__["default"].ReceiptPaymentDetail.name,
        params: {
          AssetId: id
        },
        meta: newMeta
      });
    },
    clearRouteMeta: function clearRouteMeta() {
      // Reset returnUrl meta in case user clicked on other V2
      if (this.$route.meta.returnUrl) {
        this.$route.meta.returnUrl = null;
      }
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    this.saveSnapshot(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_29___default()(this.entity));
    if (this.snapshotDiff && !this.isSkipSave && !this.isSaveContinue && this.isSaveButton && !this.readOnlyView) {
      this.$router.replace(from.path);
      this.toRoute = to;
      this.isUnsavedModalActive = true;
    } else {
      // Clean vuex store for now
      this.clearSnapshots(this.entity.assetId);
      this.clearSessionStorage();
      this.clearRouteMeta();
      this.setReturnRoute({});
      next();
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_1__);


var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "m-3"
  }, [_c("article", {
    staticClass: "box"
  }, [_c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column"
  }, [_vm.innerValue.firstName != null && _vm.innerValue.firstName != "" || _vm.innerValue.lastName != "" && _vm.value.lastName != null ? _c("p", {
    staticClass: "title"
  }, [_vm._v("Invoices for " + _vm._s(_vm.innerValue.title) + " " + _vm._s(_vm.innerValue.firstName) + " " + _vm._s(_vm.innerValue.lastName))]) : _vm.innerValue.companyName != null || _vm.innerValue.companyName != "" ? _c("p", {
    staticClass: "title"
  }, [_vm._v("Invoices for " + _vm._s(_vm.innerValue.companyName))]) : _c("p", {
    staticClass: "title"
  }, [_vm._v("Invoices")]), _vm.innerValue.totalAmount === "" ? _c("p", {
    staticClass: "subtitle"
  }, [_vm._v(" Total Amount: $0.00")]) : _c("p", {
    staticClass: "subtitle"
  }, [_vm._v(" Total Amount: $" + _vm._s(_vm.$filters.formatNumber(_vm.innerValue.totalAmount, _vm.$userInfo.locale)))]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control has-icons-left has-icons-right"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.query,
      expression: "query"
    }],
    staticClass: "input",
    attrs: {
      type: "text",
      placeholder: "Start typing to filter"
    },
    domProps: {
      value: _vm.query
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.query = $event.target.value;
      }
    }
  }), _vm._m(0)]), _c("div", {
    staticClass: "control"
  }, [_c("a", {
    staticClass: "button is-primary is-outlined tooltip",
    attrs: {
      "data-tooltip": "Reset search"
    },
    on: {
      click: function click($event) {
        return _vm.reset();
      }
    }
  }, [_vm._m(1)])])])]), _c("div", {
    staticClass: "column is-narrow is-align-self-top"
  }, [_c("button", {
    staticClass: "button is-primary",
    attrs: {
      disabled: !_vm.canPrintStatement
    },
    on: {
      click: function click($event) {
        return _vm.printStatement();
      }
    }
  }, [_c("span", {
    staticClass: "msr msr-24px mr-2"
  }, [_vm._v(" print ")]), _vm._v(" Print Statement ")])])]), _vm.activeItems.length > 0 ? _c("bulma-table", {
    staticClass: "table is-bordered is-striped is-narrow is-fullwidth",
    attrs: {
      columns: _vm.columns,
      "total-rows": _vm.activeItems.length,
      "is-loading": false,
      "is-title-checkable": true,
      "title-checkbox-location": "front",
      "show-pagination": false,
      "is-title-checked": _vm.isTitleCheck
    },
    on: {
      "update:isTitleChecked": function updateIsTitleChecked($event) {
        _vm.isTitleCheck = $event;
      },
      "update:is-title-checked": function updateIsTitleChecked($event) {
        _vm.isTitleCheck = $event;
      },
      "title-checkbox-changed": _vm.titleCheckboxChanged
    }
  }, _vm._l(_vm.activeItems, function (item, index) {
    return _c("tr", {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: !item.isDeleted,
        expression: "!item.isDeleted"
      }],
      key: item.invoiceId
    }, [_c("td", {
      staticClass: "has-vertical-middle has-text-centered is-content-width"
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.isChecked,
        expression: "item.isChecked"
      }],
      attrs: {
        id: "report".concat(index),
        name: "report".concat(index),
        disabled: _vm.readOnlyView,
        type: "checkbox"
      },
      domProps: {
        checked: Array.isArray(item.isChecked) ? _vm._i(item.isChecked, null) > -1 : item.isChecked
      },
      on: {
        change: [function ($event) {
          var $$a = item.isChecked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(item, "isChecked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(item, "isChecked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(item, "isChecked", $$c);
          }
        }, function ($event) {
          return _vm.addReceivedAmount(item.isChecked, item.balance, index);
        }]
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]), _c("label", {
      attrs: {
        for: "report".concat(index),
        "data-label-empty": ""
      }
    })]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(item.invoiceRef))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatDateLocale(item.invoiceDate, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.invoiceIncGst, _vm.$userInfo.locale)))]), _c("td", {
      staticClass: "has-vertical-middle"
    }, [_vm._v(_vm._s(_vm.$filters.formatNumber(item.balance, _vm.$userInfo.locale)))]), _c("td", {
      attrs: {
        width: "12%"
      }
    }, [item.isChecked ? _c("vue-numeric", {
      directives: [{
        name: "tippy",
        rawName: "v-tippy",
        value: {
          theme: "danger",
          enabled: item.isChecked && !_vm.$v.entity.invoiceItems.$each[index].receivedAmount.validAmount
        },
        expression: "{ theme: 'danger', enabled: item.isChecked && !$v.entity.invoiceItems.$each[index].receivedAmount.validAmount }"
      }],
      staticClass: "input has-text-right",
      class: {
        "is-danger": _vm.$v.entity.invoiceItems.$each[index].receivedAmount.$error
      },
      attrs: {
        minus: true,
        placeholder: "Amount Required",
        precision: 2,
        disabled: _vm.readOnlyView,
        content: "Received Amount cannot be zero"
      },
      on: {
        input: function input($event) {
          return _vm.calculateTotal();
        }
      },
      model: {
        value: item.receivedAmount,
        callback: function callback($$v) {
          _vm.$set(item, "receivedAmount", _vm._n($$v));
        },
        expression: "item.receivedAmount"
      }
    }) : _c("vue-numeric", {
      staticClass: "input has-text-right",
      attrs: {
        minus: true,
        min: 0.0,
        precision: 2,
        disabled: "true"
      },
      model: {
        value: item.receivedAmount,
        callback: function callback($$v) {
          _vm.$set(item, "receivedAmount", _vm._n($$v));
        },
        expression: "item.receivedAmount"
      }
    })], 1), _c("td", {
      attrs: {
        width: "20%"
      }
    }, [_c("v-date-picker", {
      attrs: {
        "is-dark": _vm.$theme.isDark,
        masks: _vm.formats,
        attributes: _vm.attrs,
        locale: _vm.$userInfo.locale,
        "min-date": _vm.$company.setting.allowInvoicePreviousMonth ? null : _vm.$filters.firstDayOfMonth(),
        timezone: _vm.$filters.getIanaTimezone()
      },
      on: {
        input: function input($event) {
          item.receivedDate = _vm.$filters.fromISOWithCurrentTime($event.toISOString());
        }
      },
      scopedSlots: _vm._u([{
        key: "default",
        fn: function fn(_ref) {
          var inputValue = _ref.inputValue,
            inputEvents = _ref.inputEvents;
          return [_c("div", {
            staticClass: "control has-icons-left"
          }, [item.isChecked && !_vm.readOnlyView ? _c("input", _vm._g({
            directives: [{
              name: "tippy",
              rawName: "v-tippy",
              value: {
                theme: "danger",
                enabled: item.isChecked && !_vm.$v.entity.invoiceItems.$each[index].receivedDate.required
              },
              expression: "{ theme: 'danger', enabled: item.isChecked && !$v.entity.invoiceItems.$each[index].receivedDate.required }"
            }],
            staticClass: "input",
            class: {
              "is-danger": _vm.$v.entity.invoiceItems.$each[index].receivedDate.$error
            },
            attrs: {
              type: "text",
              placeholder: "Received Date",
              content: "Received Date is required",
              readonly: ""
            },
            domProps: {
              value: inputValue
            }
          }, inputEvents)) : _c("input", {
            staticClass: "input",
            attrs: {
              type: "text",
              placeholder: "Received Date",
              disabled: _vm.readOnlyView || !item.isChecked,
              readonly: ""
            },
            domProps: {
              value: _vm.$filters.formatDateLocale(item.receivedDate, _vm.$userInfo.locale)
            }
          }), _c("span", {
            staticClass: "icon is-small is-left"
          }, [_c("i", {
            staticClass: "mdi mdi-calendar mdi- 18px"
          })])])];
        }
      }], null, true),
      model: {
        value: item.receivedDate,
        callback: function callback($$v) {
          _vm.$set(item, "receivedDate", $$v);
        },
        expression: "item.receivedDate"
      }
    })], 1), _c("td", {
      staticClass: "has-vertical-middle has-text-right"
    }, [_c("div", {
      staticClass: "control"
    }, [item.isChecked ? _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.chequeNo,
        expression: "item.chequeNo"
      }],
      staticClass: "input",
      attrs: {
        placeholder: "Reference",
        disabled: _vm.readOnlyView,
        maxlength: 12
      },
      domProps: {
        value: item.chequeNo
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "chequeNo", $event.target.value);
        }
      }
    }) : _c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: item.chequeNo,
        expression: "item.chequeNo"
      }],
      staticClass: "input",
      attrs: {
        disabled: "",
        placeholder: "Reference"
      },
      domProps: {
        value: item.chequeNo
      },
      on: {
        input: function input($event) {
          if ($event.target.composing) return;
          _vm.$set(item, "chequeNo", $event.target.value);
        }
      }
    })])])]);
  }), 0) : _vm._e()], 1)]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-left"
  }, [_c("i", {
    staticClass: "mdi mdi-magnify mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("app-side-menu", {
    attrs: {
      "min-width": 18,
      "fixed-menu": false
    }
  }, [_c("aside", {
    staticClass: "menu",
    attrs: {
      slot: "side-menu"
    },
    slot: "side-menu"
  }, [_c("p", {
    staticClass: "menu-label"
  }, [_c("span", {
    staticClass: "title is-6"
  }, [_vm._v(" Receipt Payment ")])]), _c("ul", {
    staticClass: "menu-list"
  }, [_c("li", [_c("router-link", {
    attrs: {
      to: {
        name: _vm.routeTypes.ReceiptPaymentDetail.name,
        query: _vm.$route.query
      },
      "active-class": "is-active",
      exact: ""
    }
  }, [_c("span", [_vm._v(" Invoices ")])])], 1)])])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);

var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_c("app-detail-header", {
    attrs: {
      "show-toggle": true,
      "show-new": false,
      "show-print": _vm.readOnlyView,
      "show-delete": false,
      "show-save": _vm.isSaveButton && !_vm.readOnlyView
    },
    on: {
      appDetailHeaderButtonClicked: _vm.onHeaderButtonClicked
    }
  }), _c("div", {
    staticClass: "columns is-gapless"
  }, [_c("div", {
    staticClass: "column is-narrow"
  }, [_vm.entity ? _c("receipt-payment-side-menu", {
    ref: "sideMenu",
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1), _c("div", {
    staticClass: "column"
  }, [_vm.entity ? _c("router-view", {
    key: _vm.$route.fullPath,
    ref: "currentChild",
    attrs: {
      "disable-change": _vm.entity.isNew,
      "is-tiled": false,
      "route-name": _vm.$route.name,
      "read-only-view": _vm.readOnlyView,
      "can-print-statement": _vm.canPrintStatement
    },
    on: {
      printStatement: function printStatement($event) {
        return _vm.print1();
      }
    },
    model: {
      value: _vm.entity,
      callback: function callback($$v) {
        _vm.entity = $$v;
      },
      expression: "entity"
    }
  }) : _vm._e()], 1)]), _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmModalActive,
      "ok-text": "Save & Print",
      "cancel-text": "Print",
      "close-text": "Close",
      "show-close": true
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmModalActive = $event;
      },
      ok: function ok($event) {
        return _vm.saveEntity("ok");
      },
      cancel: function cancel($event) {
        return _vm.saveEntity("print");
      },
      close: function close($event) {
        return _vm.saveEntity("close");
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Do you want to Save and Print?")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v(" This will save your selected Receipt Payment and Print. ")])]), _c("unsaved-modal", {
    attrs: {
      active: _vm.isUnsavedModalActive
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isUnsavedModalActive = $event;
      },
      close: function close($event) {
        return _vm.closeModal();
      },
      skipSave: function skipSave($event) {
        return _vm.skipSave();
      },
      saveContinue: function saveContinue($event) {
        return _vm.saveContinue();
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Unsaved Changes")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_vm._v("There are unsaved changes. Please select action below")])])], 1);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/lodash/isEmpty.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isEmpty.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseKeys = __webpack_require__(/*! ./_baseKeys */ "./node_modules/lodash/_baseKeys.js"),
    getTag = __webpack_require__(/*! ./_getTag */ "./node_modules/lodash/_getTag.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "./node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "./node_modules/lodash/isArrayLike.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "./node_modules/lodash/isBuffer.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "./node_modules/lodash/_isPrototype.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "./node_modules/lodash/isTypedArray.js");

/** `Object#toString` result references. */
var mapTag = '[object Map]',
    setTag = '[object Set]';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if `value` is an empty object, collection, map, or set.
 *
 * Objects are considered empty if they have no own enumerable string keyed
 * properties.
 *
 * Array-like values such as `arguments` objects, arrays, buffers, strings, or
 * jQuery-like collections are considered empty if they have a `length` of `0`.
 * Similarly, maps and sets are considered empty if they have a `size` of `0`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is empty, else `false`.
 * @example
 *
 * _.isEmpty(null);
 * // => true
 *
 * _.isEmpty(true);
 * // => true
 *
 * _.isEmpty(1);
 * // => true
 *
 * _.isEmpty([1, 2, 3]);
 * // => false
 *
 * _.isEmpty({ 'a': 1 });
 * // => false
 */
function isEmpty(value) {
  if (value == null) {
    return true;
  }
  if (isArrayLike(value) &&
      (isArray(value) || typeof value == 'string' || typeof value.splice == 'function' ||
        isBuffer(value) || isTypedArray(value) || isArguments(value))) {
    return !value.length;
  }
  var tag = getTag(value);
  if (tag == mapTag || tag == setTag) {
    return !value.size;
  }
  if (isPrototype(value)) {
    return !baseKeys(value).length;
  }
  for (var key in value) {
    if (hasOwnProperty.call(value, key)) {
      return false;
    }
  }
  return true;
}

module.exports = isEmpty;


/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentDetail.vue":
/*!***********************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentDetail.vue ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true */ "./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true");
/* harmony import */ var _ReceiptPaymentDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReceiptPaymentDetail.vue?vue&type=script&lang=js */ "./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReceiptPaymentDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2b8ca994",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/receiptpayment/ReceiptPaymentDetail.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js":
/*!***********************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentDetail.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentDetail_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true":
/*!*****************************************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentDetail.vue?vue&type=template&id=2b8ca994&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentDetail_vue_vue_type_template_id_2b8ca994_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue":
/*!*************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentSideMenu.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a */ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a");
/* harmony import */ var _ReceiptPaymentSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReceiptPaymentSideMenu.vue?vue&type=script&lang=js */ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReceiptPaymentSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/receiptpayment/ReceiptPaymentSideMenu.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js":
/*!*************************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentSideMenu.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentSideMenu_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a":
/*!*******************************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a ***!
  \*******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentSideMenu.vue?vue&type=template&id=97e5270a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentSideMenu_vue_vue_type_template_id_97e5270a__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentValidation.js":
/*!**************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentValidation.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__);


// const validAmount = function (value, parentVm) {
//   console.log('valid ' + parentVm)
//   const isChecked = parentVm.invoiceItems.$each.isChecked
//   return isChecked ? value !== 0 : true
// }

/* harmony default export */ __webpack_exports__["default"] = ({
  provide: function provide() {
    return {
      $vv: this.$v
    };
  },
  validations: {
    receiptEntryGroup: ['entity.invoiceItems'],
    entity: {
      invoiceItems: {
        $each: {
          receivedAmount: {
            required: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["requiredIf"])(function (model) {
              //requiredIf (first parameter (model) is the model/object)
              return model.isChecked;
            }),
            validAmount: function validAmount(value, model) {
              // first parameter (value) is the value of field, second parameter (model) is current model/object
              var isChecked = model.isChecked;
              return isChecked ? value !== 0 : true;
            }
          },
          receivedDate: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_0__["required"]
          }
        }
      }
    }
  }
});

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentView.vue":
/*!*********************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentView.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReceiptPaymentView.vue?vue&type=template&id=abd55a6c */ "./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c");
/* harmony import */ var _ReceiptPaymentView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReceiptPaymentView.vue?vue&type=script&lang=js */ "./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ReceiptPaymentView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/receiptpayment/ReceiptPaymentView.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js":
/*!*********************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentView.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentView_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c":
/*!***************************************************************************************!*\
  !*** ./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c ***!
  \***************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./ReceiptPaymentView.vue?vue&type=template&id=abd55a6c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/receiptpayment/ReceiptPaymentView.vue?vue&type=template&id=abd55a6c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReceiptPaymentView_vue_vue_type_template_id_abd55a6c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/receiptpayment/columns.js":
/*!*********************************************!*\
  !*** ./src/views/receiptpayment/columns.js ***!
  \*********************************************/
/*! exports provided: ReceiptPaymentColumns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiptPaymentColumns", function() { return ReceiptPaymentColumns; });
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var ReceiptPaymentColumns = [
// new TableColumn('', 'action', false, 'desc', 'centered'),
new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Invoice No', 'invoiceRef', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Invoice Date', 'invoiceDate', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Invoice Amount', 'invoiceIncGst', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Balance', 'balance', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Received Amount', 'recordAmount', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Received Date', 'receivedDate', false, '', 'left'), new _classes__WEBPACK_IMPORTED_MODULE_0__["TableColumn"]('Reference', 'chequeNo', false, '', 'left')
// new TableColumn('Bank Account', 'bankAccount', false, '', 'left')
];


/***/ }),

/***/ "./src/views/receiptpayment/route-types.js":
/*!*************************************************!*\
  !*** ./src/views/receiptpayment/route-types.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _classes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/classes */ "./src/classes/index.js");

var ReceiptPaymentRoutes = {
  ReceiptPaymentView: new _classes__WEBPACK_IMPORTED_MODULE_0__["ComponentRoute"]('/receiptpayment/:AssetId', 'ReceiptPaymentView'),
  ReceiptPaymentDetail: new _classes__WEBPACK_IMPORTED_MODULE_0__["ComponentRoute"]('/receiptpayment/:AssetId', 'ReceiptPaymentDetail')
};
/* harmony default export */ __webpack_exports__["default"] = (ReceiptPaymentRoutes);

/***/ }),

/***/ "./src/views/receiptpayment/storeMixin.js":
/*!************************************************!*\
  !*** ./src/views/receiptpayment/storeMixin.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");


var moduleName = 'receiptpayment';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(moduleName, {
    returnRoute: 'returnRoute',
    snapshots: 'snapshots',
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    snapshotDiff: 'snapshotDiff',
    readOnlyView: 'readOnlyView'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['licenceExpired'])),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])(moduleName, ['getStoreItem', 'addStoreItem', 'saveSnapshot', 'clearSnapshots', 'setReturnRoute', 'setReadOnlyView'])), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    setPrintPreviewReturnRoute: 'setReturnRoute',
    addEmailer: 'addEmailer',
    removeEmailer: 'removeEmailer'
  })), Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapActions"])('printpreview', {
    addReportParameters: 'addParameters',
    removeReportParameters: 'removeParameters'
  }))
});

/***/ })

}]);
//# sourceMappingURL=receiptpayment-chunk.js.map