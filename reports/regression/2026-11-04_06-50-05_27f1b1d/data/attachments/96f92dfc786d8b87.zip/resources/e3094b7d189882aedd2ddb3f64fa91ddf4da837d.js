(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[19],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js":
/*!***************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js ***!
  \***************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.string.pad-start.js */ "./node_modules/core-js/modules/es.string.pad-start.js");
/* harmony import */ var core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_pad_start_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/debounce */ "./node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _storeMixin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./storeMixin */ "./src/views/companysetting/storeMixin.js");










/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CompanyLicenseSetting',
  mixins: [_storeMixin__WEBPACK_IMPORTED_MODULE_9__["default"]],
  data: function data() {
    return {
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      autoUpdate: null,
      companyLicense: {},
      expiryDate: '',
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['DD/MM/YYYY'],
        data: ['DD/MM/YYYY'],
        dayPopover: null
      },
      isNew: false
    };
  },
  computed: {
    companyLicenseTypes: function companyLicenseTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_7__["CompanyLicenseTypes"];
    }
  },
  watch: {
    companyLicense: {
      handler: function handler(val) {
        this.$v.$touch();
        this.saveSnapshot({
          entity: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default()(val)
        });
        if (typeof this.autoUpdate === 'function') this.autoUpdate(val);
      },
      deep: true
    }
  },
  created: function created() {
    var _this = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee() {
      var newCompany, _t, _t2, _t3, _t4;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context) {
        while (1) switch (_context.n) {
          case 0:
            _this.$showSpinner();
            if (!(_this.$route.params.companyId === 'new')) {
              _context.n = 4;
              break;
            }
            _this.isNew = true;
            newCompany = _this.$store.getters['companysetting/newCompany'];
            if (!(newCompany && newCompany.companyLicense)) {
              _context.n = 1;
              break;
            }
            _this.companyLicense = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default()(newCompany.companyLicense);
            _context.n = 3;
            break;
          case 1:
            _t = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default.a;
            _context.n = 2;
            return _this.getStoreItem({
              serviceFunction: 'getNewCompanyLicense'
            });
          case 2:
            _t2 = _context.v;
            _this.companyLicense = _t(_t2);
          case 3:
            _context.n = 6;
            break;
          case 4:
            _t3 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default.a;
            _context.n = 5;
            return _this.getStoreItem({
              serviceFunction: 'getCompanyLicense',
              params: _this.$route.params.companyId
            });
          case 5:
            _t4 = _context.v;
            _this.companyLicense = _t3(_t4);
          case 6:
            _this.initializeAutoUpdate();
            _this.$hideSpinner();
          case 7:
            return _context.a(2);
        }
      }, _callee);
    }))();
  },
  methods: {
    expireDateInputEvent: function expireDateInputEvent(event) {
      if (!event || !this.companyLicense) return;
      var d = event instanceof Date ? event : new Date(event);
      if (isNaN(d.getTime())) return;
      var yyyy = d.getFullYear();
      var mm = String(d.getMonth() + 1).padStart(2, '0');
      var dd = String(d.getDate()).padStart(2, '0');
      this.companyLicense.expiryDate = "".concat(yyyy, "-").concat(mm, "-").concat(dd);
    },
    disableAutoUpdate: function disableAutoUpdate() {
      if (typeof this.autoUpdate === 'function' && typeof this.autoUpdate.cancel === 'function') {
        this.autoUpdate.cancel();
      }
      this.autoUpdate = function () {};
    },
    initializeAutoUpdate: function initializeAutoUpdate() {
      var _this2 = this;
      this.autoUpdate = lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default()(/*#__PURE__*/function () {
        var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee2(value) {
          var _t5;
          return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context2) {
            while (1) switch (_context2.n) {
              case 0:
                _t5 = _this2.snapshotDiff;
                if (!_t5) {
                  _context2.n = 1;
                  break;
                }
                _context2.n = 1;
                return _this2.updateLicense(value);
              case 1:
                return _context2.a(2);
            }
          }, _callee2);
        }));
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), this.debounceDelay);
    },
    updateLicense: function updateLicense(license) {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee3() {
        var _t6, _t7;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              if (_this3.$userInfo.isSystemAccount) {
                _context3.n = 1;
                break;
              }
              return _context3.a(2);
            case 1:
              if (_this3.snapshotDiff) {
                _context3.n = 2;
                break;
              }
              return _context3.a(2);
            case 2:
              _this3.$v.$touch();
              if (!_this3.$v.$error) {
                _context3.n = 3;
                break;
              }
              return _context3.a(2);
            case 3:
              if (!_this3.isNew) {
                _context3.n = 4;
                break;
              }
              _this3.setStateProperty({
                key: 'companyLicense',
                value: license
              });
              return _context3.a(2);
            case 4:
              license.deepDiff = JSON.stringify(_this3.snapshotDiff);
              console.log("license.deepDiff: ".concat(license.deepDiff));
              _t6 = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_5___default.a;
              _context3.n = 5;
              return _this3.editStoreItem({
                serviceFunction: 'updateCompanyLicense',
                entity: license,
                params: _this3.$route.params.companyId
              });
            case 5:
              _t7 = _context3.v;
              _this3.companyLicense = _t6(_t7);
              if (_this3.toastNotificationEnabled) {
                _this3.openToastNotification();
              }
            case 6:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    }
  },
  beforeRouteLeave: function beforeRouteLeave(to, from, next) {
    var _this4 = this;
    return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().m(function _callee4() {
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])().w(function (_context4) {
        while (1) switch (_context4.n) {
          case 0:
            _this4.disableAutoUpdate();
            _this4.toastNotificationEnabled = true;
            _context4.n = 1;
            return _this4.updateLicense(_this4.companyLicense);
          case 1:
            _this4.clearSnapshots();
            _this4.toastNotificationEnabled = false;
            next();
          case 2:
            return _context4.a(2);
        }
      }, _callee4);
    }))();
  },
  validations: {
    companyLicense: {
      maxUsers: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["required"],
        maxValueValue: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["maxValue"])(100)
      },
      concurrentUsers: {
        required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["required"],
        maxValueValue: Object(vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_8__["maxValue"])(100)
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);





var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", [_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator || _vm.$userInfo.isSystemAdministrator ? _c("div", {
    staticClass: "tile is-parent pl-1"
  }, [_c("article", {
    staticClass: "tile is-child box"
  }, [_c("div", {
    staticClass: "columns is-flex is-align-items-center"
  }, [_vm._m(0), !_vm.hasError && _vm.showSavingStatus && !_vm.toastNotificationEnabled ? _c("div", {
    staticClass: "column is-flex is-justify-content-flex-end is-align-items-center"
  }, [_vm.saving ? _c("span", {
    staticClass: "button is-loading is-white",
    staticStyle: {
      height: "27px"
    }
  }) : _c("span", {
    staticClass: "text has-text-success"
  }, [_c("span", {
    staticClass: "mso mso-18px"
  }, [_vm._v("check_circle")])]), _c("span", {
    staticClass: "is-size-6",
    class: _vm.saving ? "has-text-warning" : "has-text-success"
  }, [_vm._v(_vm._s(_vm.savingStatus))])]) : _vm._e()]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Max Users")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: _vm.companyLicense.maxUsers,
      expression: "companyLicense.maxUsers",
      modifiers: {
        number: true
      }
    }],
    staticClass: "input",
    attrs: {
      type: "number",
      disabled: !_vm.$userInfo.isSystemAccount
    },
    domProps: {
      value: _vm.companyLicense.maxUsers
    },
    on: {
      blur: [function ($event) {
        return _vm.$v.companyLicense.maxUsers.$touch();
      }, function ($event) {
        return _vm.$forceUpdate();
      }],
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyLicense, "maxUsers", _vm._n($event.target.value));
      }
    }
  }), _vm.$v.companyLicense.maxUsers.$dirty && !_vm.$v.companyLicense.maxUsers.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Max User required ")]) : _vm._e(), _vm.$v.companyLicense.maxUsers.$dirty && !_vm.$v.companyLicense.maxUsers.maxValueValue ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Max number 100 ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Concurrent Users")]), _c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: _vm.companyLicense.concurrentUsers,
      expression: "companyLicense.concurrentUsers",
      modifiers: {
        number: true
      }
    }],
    staticClass: "input",
    attrs: {
      type: "number",
      disabled: !_vm.$userInfo.isSystemAccount
    },
    domProps: {
      value: _vm.companyLicense.concurrentUsers
    },
    on: {
      blur: [function ($event) {
        return _vm.$v.companyLicense.concurrentUsers.$touch();
      }, function ($event) {
        return _vm.$forceUpdate();
      }],
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.companyLicense, "concurrentUsers", _vm._n($event.target.value));
      }
    }
  }), _vm.$v.companyLicense.concurrentUsers.$dirty && !_vm.$v.companyLicense.concurrentUsers.required ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Concurrent User required ")]) : _vm._e(), _vm.$v.companyLicense.concurrentUsers.$dirty && !_vm.$v.companyLicense.concurrentUsers.maxValueValue ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Max number 100 ")]) : _vm._e()])])]), _c("div", {
    staticClass: "field columns"
  }, [_c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("License Type")]), _c("div", {
    staticClass: "control is-fullwidth"
  }, [_c("span", {
    staticClass: "select is-fullwidth"
  }, [_c("select", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.companyLicense.licenseType,
      expression: "companyLicense.licenseType"
    }],
    attrs: {
      disabled: !_vm.$userInfo.isSystemAccount
    },
    on: {
      change: function change($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function (o) {
          return o.selected;
        }).map(function (o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.companyLicense, "licenseType", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      }
    }
  }, _vm._l(_vm.companyLicenseTypes, function (type, typeIndex) {
    return _c("option", {
      key: typeIndex,
      domProps: {
        value: type
      }
    }, [_vm._v(" " + _vm._s(type) + " ")]);
  }), 0)])])]), _c("div", {
    staticClass: "column is-half"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Expire Date")]), _c("v-date-picker", {
    staticClass: "is-fullwidth",
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale
    },
    on: {
      input: _vm.expireDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field has-addons"
        }, [_c("div", {
          staticClass: "control is-expanded has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Expiry date",
            disabled: !_vm.$userInfo.isSystemAccount
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("span", {
          staticClass: "mso mso-18px"
        }, [_vm._v("calendar_month")])])])])];
      }
    }], null, false, 587075840),
    model: {
      value: _vm.companyLicense.expiryDate,
      callback: function callback($$v) {
        _vm.$set(_vm.companyLicense, "expiryDate", $$v);
      },
      expression: "companyLicense.expiryDate"
    }
  })], 1)])])]) : _c("div", {
    staticClass: "is-flex is-justify-content-center pt-5"
  }, [_c("div", {
    staticClass: "notification is-danger is-flex is-justify-content-center is-size-4",
    staticStyle: {
      width: "50%"
    }
  }, [_vm._v(" You do not have permissions on this page ")])])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("License")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./src/views/companysetting/CompanyLicenseSetting.vue":
/*!************************************************************!*\
  !*** ./src/views/companysetting/CompanyLicenseSetting.vue ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c */ "./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c");
/* harmony import */ var _CompanyLicenseSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CompanyLicenseSetting.vue?vue&type=script&lang=js */ "./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CompanyLicenseSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__["render"],
  _CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/companysetting/CompanyLicenseSetting.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js":
/*!************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyLicenseSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyLicenseSetting.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyLicenseSetting_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c":
/*!******************************************************************************************!*\
  !*** ./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c ***!
  \******************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/companysetting/CompanyLicenseSetting.vue?vue&type=template&id=2ae0146c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CompanyLicenseSetting_vue_vue_type_template_id_2ae0146c__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);
//# sourceMappingURL=19.js.map