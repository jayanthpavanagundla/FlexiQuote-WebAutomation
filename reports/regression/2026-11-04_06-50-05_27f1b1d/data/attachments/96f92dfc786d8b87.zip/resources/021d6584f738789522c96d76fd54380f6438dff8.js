(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["quote-invoice-chunk"],{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/regenerator.js */ "./node_modules/@babel/runtime/helpers/esm/regenerator.js");
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.array.find.js */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/es.array.reduce.js */ "./node_modules/core-js/modules/es.array.reduce.js");
/* harmony import */ var core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reduce_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es.array.sort.js */ "./node_modules/core-js/modules/es.array.sort.js");
/* harmony import */ var core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_sort_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es.iterator.every.js */ "./node_modules/core-js/modules/es.iterator.every.js");
/* harmony import */ var core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_every_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! core-js/modules/es.iterator.find.js */ "./node_modules/core-js/modules/es.iterator.find.js");
/* harmony import */ var core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_find_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! core-js/modules/es.iterator.for-each.js */ "./node_modules/core-js/modules/es.iterator.for-each.js");
/* harmony import */ var core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! core-js/modules/es.iterator.map.js */ "./node_modules/core-js/modules/es.iterator.map.js");
/* harmony import */ var core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_map_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! core-js/modules/es.iterator.reduce.js */ "./node_modules/core-js/modules/es.iterator.reduce.js");
/* harmony import */ var core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
/* harmony import */ var core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_number_constructor_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! core-js/modules/es.string.replace.js */ "./node_modules/core-js/modules/es.string.replace.js");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _components_VueNumeric__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @/components/VueNumeric */ "./src/components/VueNumeric/index.js");
/* harmony import */ var _components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @/components/utils/AccountingFunctions */ "./src/components/utils/AccountingFunctions.js");
/* harmony import */ var _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @/views/quickinvoice/QuickInvoiceService.js */ "./src/views/quickinvoice/QuickInvoiceService.js");
/* harmony import */ var _components_Guid__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @/components/Guid */ "./src/components/Guid.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! vue-multiselect */ "./node_modules/vue-multiselect/dist/vue-multiselect.min.js");
/* harmony import */ var vue_multiselect__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(vue_multiselect__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./services */ "./src/views/quote/services/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @/enums */ "./src/enums/index.js");
/* harmony import */ var _route_types__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./route-types */ "./src/views/quote/route-types.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! deep-diff */ "./node_modules/deep-diff/index.js");
/* harmony import */ var deep_diff__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(deep_diff__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! lodash/cloneDeep */ "./node_modules/lodash/cloneDeep.js");
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./mixins/QuoteInvoiceStoreMixin */ "./src/views/quote/mixins/QuoteInvoiceStoreMixin.js");
/* harmony import */ var _mixins_QuoteInvoiceValidationMixin__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./mixins/QuoteInvoiceValidationMixin */ "./src/views/quote/mixins/QuoteInvoiceValidationMixin.js");
/* harmony import */ var _QuoteService__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./QuoteService */ "./src/views/quote/QuoteService.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./components */ "./src/views/quote/components/index.js");
/* harmony import */ var _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! @/components/BulmaMessage/BulmaMessage.vue */ "./src/components/BulmaMessage/BulmaMessage.vue");
/* harmony import */ var _components_BulmaModal__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @/components/BulmaModal */ "./src/components/BulmaModal/index.js");
















































/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'QuoteInvoice',
  components: {
    VueNumeric: _components_VueNumeric__WEBPACK_IMPORTED_MODULE_29__["default"],
    Multiselect: vue_multiselect__WEBPACK_IMPORTED_MODULE_33___default.a,
    InvoiceNoSearchModal: _components__WEBPACK_IMPORTED_MODULE_43__["InvoiceNoSearchModal"],
    BulmaMessage: _components_BulmaMessage_BulmaMessage_vue__WEBPACK_IMPORTED_MODULE_44__["default"],
    ConfirmModal: _components_BulmaModal__WEBPACK_IMPORTED_MODULE_45__["ConfirmModal"]
  },
  mixins: [_mixins_QuoteInvoiceStoreMixin__WEBPACK_IMPORTED_MODULE_40__["default"], _mixins_QuoteInvoiceValidationMixin__WEBPACK_IMPORTED_MODULE_41__["default"]],
  props: {
    value: null,
    readOnlyView: {
      type: Boolean,
      default: false
    },
    animationIn: {
      type: String,
      default: 'fadeIn'
    },
    animationOut: {
      type: String,
      default: 'fadeOut'
    },
    animationDuration: {
      type: [String, Number],
      default: 0.3
    }
  },
  data: function data() {
    var _this$value, _this$value2, _this$value3, _this$value4;
    return {
      innerValue: lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(this.value) || {},
      gstPaid: false,
      excess: (_this$value = this.value) === null || _this$value === void 0 ? void 0 : _this$value.excess,
      ownerContribution: (_this$value2 = this.value) === null || _this$value2 === void 0 ? void 0 : _this$value2.ownerContribution,
      discount: (_this$value3 = this.value) === null || _this$value3 === void 0 ? void 0 : _this$value3.discount,
      gst: this.value ? Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.value.totalExGst * this.value.gstRate / 100) : 0,
      excessWithGst: (_this$value4 = this.value) === null || _this$value4 === void 0 ? void 0 : _this$value4.excessWithGst,
      overrides: {
        labourTotal: 0,
        rrTotal: 0,
        repairTotal: 0,
        rwaTotal: 0,
        paintTotal: 0,
        fgTotal: 0,
        crushTotal: 0,
        cdTotal: 0,
        mechTotal: 0,
        pdrRrTotal: 0,
        pdrReTotal: 0
      },
      selectedAsset: null,
      assets: [],
      isAssetLoading: false,
      assetFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty(),
        assetName: '',
        showCustomer: true,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      invoice: null,
      tabInvoiceType: _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Quote,
      isLoadingInvoice: false,
      // isUpdateInvoice: false,
      // baseInvoice: null,
      insurerAsset: null,
      customerAsset: null,
      quotesTotals: [],
      gstInvoice: null,
      isGstInvoiceOn: false,
      selectedGstAsset: null,
      gstAssets: [],
      isGstAssetLoading: false,
      gstAssetFilter: {
        assetId: _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty(),
        assetName: '',
        showCustomer: true,
        showInsurer: true,
        pageIndex: 1,
        pageSize: 50
      },
      selectedInvoiceDate: null,
      isInvoiceNoSearchModalActive: false,
      formats: {
        title: 'MMMM YYYY',
        weekdays: 'W',
        navMonths: 'MMM',
        input: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        data: ['L', 'DD-MM-YYYY', 'DD/MM/YYYY'],
        dayPopover: 'L'
      },
      attrs: [{
        key: 'today',
        highlight: {
          backgroundColor: '#ff8080'
        },
        popover: {
          label: 'Today'
        },
        dates: new Date()
      }],
      isGenerateInvoiceModalActive: false,
      modalInvoices: [],
      isConfirmVoidActive: false
    };
  },
  computed: {
    showSave: function showSave() {
      return !!deep_diff__WEBPACK_IMPORTED_MODULE_38___default.a.diff(this.innerValue, this.value);
    },
    routeTypes: function routeTypes() {
      return _route_types__WEBPACK_IMPORTED_MODULE_37__["default"];
    },
    invoiceTypes: function invoiceTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"];
    },
    isInvoiced: function isInvoiced() {
      return this.invoice !== null;
    },
    hasRaisedInvoice: function hasRaisedInvoice() {
      return !!this.invoice && !this.invoice.isNew && !this.invoice.deleted;
    },
    canVoidInvoice: function canVoidInvoice() {
      var _this$innerValue;
      return this.$user.hasDelete(this.$route.meta.id) && !this.readOnlyView && !this.isUpdateInvoice && this.hasRaisedInvoice && !this.invoice.gstPaidDate && !((_this$innerValue = this.innerValue) !== null && _this$innerValue !== void 0 && _this$innerValue.readOnly);
    },
    canPrintInvoice: function canPrintInvoice() {
      return this.$user.hasPrint(this.$route.meta.id) && this.hasRaisedInvoice;
    },
    invoicePayerTypes: function invoicePayerTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"];
    },
    totalExGst: function totalExGst() {
      return this.invoice.totalExGst;
    },
    totalIncGst: function totalIncGst() {
      return this.invoice.totalIncGst;
    },
    totalPayableIncGst: function totalPayableIncGst() {
      return this.invoice.totalIncGst;
    },
    showAsset: function showAsset() {
      var _this$assetFilter, _this$assetFilter2;
      return {
        customer: ((_this$assetFilter = this.assetFilter) === null || _this$assetFilter === void 0 ? void 0 : _this$assetFilter.showCustomer) || false,
        insurer: ((_this$assetFilter2 = this.assetFilter) === null || _this$assetFilter2 === void 0 ? void 0 : _this$assetFilter2.showInsurer) || false
      };
    },
    invoiceNoReference: function invoiceNoReference() {
      return this.invoice ? "".concat(this.invoice.prefix).concat(this.invoice.invoiceNo).concat(this.invoice.suffix, "/").concat(this.invoice.invoiceType) : '';
    },
    isNewInvoice: function isNewInvoice() {
      return this.invoice && this.invoice.isNew;
    },
    isDirty: function isDirty() {
      var diff = deep_diff__WEBPACK_IMPORTED_MODULE_38___default.a.diff(this.baseInvoice, this.invoice, function (path, key) {
        return path.length === 0 && ~['isDirty'].indexOf(key);
      });
      return diff !== undefined;
    },
    isQuoteTotalDirty: function isQuoteTotalDirty() {
      var baseSnapshot = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(this.baseSnapshot);
      var currentSnapshot = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(this.currentSnapshot);
      return baseSnapshot.totalExGst !== currentSnapshot.totalExGst;
    },
    isPnetAuthorityNoRequired: function isPnetAuthorityNoRequired() {
      var _this$innerValue2, _this$innerValue3;
      return !((_this$innerValue2 = this.innerValue) !== null && _this$innerValue2 !== void 0 && _this$innerValue2.isAudaBridge) && ((_this$innerValue3 = this.innerValue) === null || _this$innerValue3 === void 0 ? void 0 : _this$innerValue3.isPnet);
    },
    // FQ-2776: was `jobStage === AuthorityPending`, but jobStage is shared across the whole
    // quote family (QuoteService.cs:760, FQ-720) so it cannot say whether THIS quote is
    // authorised. Use the quote's own authorisedDate, the same signal the modal uses.
    isCurrentEstimageQuoteUnauthorised: function isCurrentEstimageQuoteUnauthorised() {
      return this.isEstimageQuoteUnauthorised(this.innerValue);
    },
    invoiceValues: function invoiceValues() {
      if (this.invoice) {
        return this.invoice.excessAmount + this.invoice.ownerContribution + this.invoice.quoteDiscount;
      } else {
        return 0;
      }
    },
    overrideValues: function overrideValues() {
      if (this.invoice) {
        return this.invoice.rrOverride + this.invoice.repairOverride + this.invoice.paintOverride + this.invoice.rwaOverride + this.invoice.fgOverride + this.invoice.crushOverride + this.invoice.cdOverride + this.invoice.mechOverride + this.invoice.pdrRrOverride + this.invoice.pdrReOverride + this.invoice.labourTotal;
      } else {
        return 0;
      }
    },
    hasExcessInvoice: function hasExcessInvoice() {
      var _this$innerValue4;
      var index = (_this$innerValue4 = this.innerValue) === null || _this$innerValue4 === void 0 || (_this$innerValue4 = _this$innerValue4.invoices) === null || _this$innerValue4 === void 0 ? void 0 : _this$innerValue4.findIndex(function (i) {
        return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Excess && !i.deleted;
      });
      return index >= 0;
    },
    quotesLabourTotal: function quotesLabourTotal() {
      var _this$innerValue5;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue5 = this.innerValue) === null || _this$innerValue5 === void 0 ? void 0 : _this$innerValue5.labourTotal) || 0) + this.includedQuotesLabourTotal);
    },
    quotesRrTotal: function quotesRrTotal() {
      var _this$innerValue6;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue6 = this.innerValue) === null || _this$innerValue6 === void 0 ? void 0 : _this$innerValue6.rrTotal) || 0) + this.includedQuotesRrTotal);
    },
    quotesRepairTotal: function quotesRepairTotal() {
      var _this$innerValue7;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue7 = this.innerValue) === null || _this$innerValue7 === void 0 ? void 0 : _this$innerValue7.repairTotal) || 0) + this.includedQuotesRepairTotal);
    },
    quotesRwaTotal: function quotesRwaTotal() {
      var _this$innerValue8;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue8 = this.innerValue) === null || _this$innerValue8 === void 0 ? void 0 : _this$innerValue8.rwaTotal) || 0) + this.includedQuotesRwaTotal);
    },
    quotesPaintTotal: function quotesPaintTotal() {
      var _this$innerValue9;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue9 = this.innerValue) === null || _this$innerValue9 === void 0 ? void 0 : _this$innerValue9.paintTotal) || 0) + this.includedQuotesPaintTotal);
    },
    quotesFgTotal: function quotesFgTotal() {
      var _this$innerValue0;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue0 = this.innerValue) === null || _this$innerValue0 === void 0 ? void 0 : _this$innerValue0.fgTotal) || 0) + this.includedQuotesFgTotal);
    },
    quotesCrushTotal: function quotesCrushTotal() {
      var _this$innerValue1;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue1 = this.innerValue) === null || _this$innerValue1 === void 0 ? void 0 : _this$innerValue1.crushTotal) || 0) + this.includedQuotesCrushTotal);
    },
    quotesCdTotal: function quotesCdTotal() {
      var _this$innerValue10;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue10 = this.innerValue) === null || _this$innerValue10 === void 0 ? void 0 : _this$innerValue10.cdTotal) || 0) + this.includedQuotesCdTotal);
    },
    quotesMechTotal: function quotesMechTotal() {
      var _this$innerValue11;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue11 = this.innerValue) === null || _this$innerValue11 === void 0 ? void 0 : _this$innerValue11.mechTotal) || 0) + this.includedQuotesMechTotal);
    },
    quotesOpgTotal: function quotesOpgTotal() {
      var _this$innerValue12;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue12 = this.innerValue) === null || _this$innerValue12 === void 0 ? void 0 : _this$innerValue12.opgTotal) || 0) + this.includedQuotesOpgTotal);
    },
    quotesPartTotal: function quotesPartTotal() {
      var _this$innerValue13;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue13 = this.innerValue) === null || _this$innerValue13 === void 0 ? void 0 : _this$innerValue13.partTotal) || 0) + this.includedQuotesPartTotal);
    },
    quotesMiscTotal: function quotesMiscTotal() {
      var _this$innerValue14;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue14 = this.innerValue) === null || _this$innerValue14 === void 0 ? void 0 : _this$innerValue14.miscTotal) || 0) + this.includedQuotesMiscTotal);
    },
    quotesSubletTotal: function quotesSubletTotal() {
      var _this$innerValue15;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue15 = this.innerValue) === null || _this$innerValue15 === void 0 ? void 0 : _this$innerValue15.sublTotal) || 0) + this.includedQuotesSubletTotal);
    },
    hasOverrides: function hasOverrides() {
      var vm = this;
      return Object.keys(this.overrides).some(function (key, index) {
        return vm.overrides[key] !== 0;
      });
    },
    overrideKeys: function overrideKeys() {
      var vm = this;
      return Object.keys(this.overrides).filter(function (o) {
        return vm.overrides['labourTotal'] === 0 ? o !== 'labourTotal' : o !== 'rrTotal' && o !== 'repairTotal' && o !== 'rwaTotal' && o !== 'paintTotal';
      });
    },
    quotesTotalExGst: function quotesTotalExGst() {
      var vm = this;
      // const hasOverrides = Object.keys(this.overrides).some(function(key, index) {
      //   return vm.overrides[key] !== 0
      // })
      if (!this.hasOverrides) {
        var _this$innerValue16;
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue16 = this.innerValue) === null || _this$innerValue16 === void 0 ? void 0 : _this$innerValue16.totalExGst) || 0) + this.includedQuotesTotalExGst);
      } else {
        var _this$innerValue17, _this$innerValue18, _this$innerValue19, _this$innerValue20;
        var quotesTotalExGst = (((_this$innerValue17 = this.innerValue) === null || _this$innerValue17 === void 0 ? void 0 : _this$innerValue17.partTotal) || 0) + (((_this$innerValue18 = this.innerValue) === null || _this$innerValue18 === void 0 ? void 0 : _this$innerValue18.miscTotal) || 0) + (((_this$innerValue19 = this.innerValue) === null || _this$innerValue19 === void 0 ? void 0 : _this$innerValue19.sublTotal) || 0) + (((_this$innerValue20 = this.innerValue) === null || _this$innerValue20 === void 0 ? void 0 : _this$innerValue20.opgTotal) || 0);
        quotesTotalExGst += this.includedQuotesPartTotal + this.includedQuotesMiscTotal + this.includedQuotesSubletTotal + this.includedQuotesOpgTotal;
        // console.log('quotesTotalExGst', quotesTotalExGst)
        this.overrideKeys.forEach(function (key, index) {
          // console.log(key, vm.overrides[key])
          if (vm.overrides[key] !== 0) {
            quotesTotalExGst += vm.overrides[key];
            // console.log('override', key, quotesTotalExGst, vm.overrides[key])
          } else {
            var _vm$innerValue;
            var includedQuotesTotal = vm.invoiceIncludedQuotes.reduce(function (total, quote) {
              // console.log('quote[key]', quote, quote[key])
              return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + (quote[key] !== undefined ? quote[key] : 0));
            }, 0);
            quotesTotalExGst += ((_vm$innerValue = vm.innerValue) === null || _vm$innerValue === void 0 ? void 0 : _vm$innerValue[key]) || 0 + includedQuotesTotal;
            // console.log('override 1', key, quotesTotalExGst, vm.innerValue[key])
          }
        });
        return quotesTotalExGst;
      }
    },
    quotesTotalIncGst: function quotesTotalIncGst() {
      var _this$innerValue21;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue21 = this.innerValue) === null || _this$innerValue21 === void 0 ? void 0 : _this$innerValue21.totalIncGst) || 0) + this.includedQuotesTotalIncGst);
    },
    quotesExcessTotal: function quotesExcessTotal() {
      var _this$innerValue22;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue22 = this.innerValue) === null || _this$innerValue22 === void 0 ? void 0 : _this$innerValue22.excess) || 0) + this.includedQuotesExcessTotal);
    },
    quotesOwnerContributionTotal: function quotesOwnerContributionTotal() {
      var _this$innerValue23;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue23 = this.innerValue) === null || _this$innerValue23 === void 0 ? void 0 : _this$innerValue23.ownersContribution) || 0) + this.includedQuotesOwnerContributionTotal);
    },
    quotesDiscountTotal: function quotesDiscountTotal() {
      var _this$innerValue24;
      return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((((_this$innerValue24 = this.innerValue) === null || _this$innerValue24 === void 0 ? void 0 : _this$innerValue24.discount) || 0) + this.includedQuotesDiscountTotal);
    },
    includedQuotesLabourTotal: function includedQuotesLabourTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.labourTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesRrTotal: function includedQuotesRrTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.rrTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesRepairTotal: function includedQuotesRepairTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.repairTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesRwaTotal: function includedQuotesRwaTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.rwaTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesPaintTotal: function includedQuotesPaintTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.paintTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesFgTotal: function includedQuotesFgTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.fgTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesCrushTotal: function includedQuotesCrushTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.crushTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesCdTotal: function includedQuotesCdTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.cdTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesMechTotal: function includedQuotesMechTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.mechTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesOpgTotal: function includedQuotesOpgTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.opgTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesPartTotal: function includedQuotesPartTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.partTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesMiscTotal: function includedQuotesMiscTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.miscTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesSubletTotal: function includedQuotesSubletTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.sublTotal);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesTotalExGst: function includedQuotesTotalExGst() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.totalExGst);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesTotalIncGst: function includedQuotesTotalIncGst() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.totalIncGst);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesExcessTotal: function includedQuotesExcessTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + (quote.subQuoteNo === 0 ? quote.excess : 0));
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesOwnerContributionTotal: function includedQuotesOwnerContributionTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.ownerContribution);
        }, 0);
      } else {
        return 0;
      }
    },
    includedQuotesDiscountTotal: function includedQuotesDiscountTotal() {
      if (this.invoiceIncludedQuotes.length > 0) {
        return this.invoiceIncludedQuotes.reduce(function (total, quote) {
          return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(total + quote.discount);
        }, 0);
      } else {
        return 0;
      }
    },
    baseInvoice: function baseInvoice() {
      if (this.baseSnapshot) {
        var baseInvoice = this.baseSnapshot.invoices.find(function (i) {
          return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Quote && !i.deleted;
        });
        return lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(baseInvoice);
      }
    },
    quoteTypes: function quoteTypes() {
      return _enums__WEBPACK_IMPORTED_MODULE_36__["QuoteTypes"];
    },
    firstDayOfMonth: function firstDayOfMonth() {
      if (this.$company.setting.allowInvoicePreviousMonth) {
        return null;
      }
      var invoiceDate = new Date();
      if (!this.invoice.isNew) {
        invoiceDate = new Date("".concat(this.invoice.invoiceDate));
        return this.$filters.firstDayOfMonth(invoiceDate.getFullYear(), invoiceDate.getMonth());
      } else {
        return this.$filters.firstDayOfMonth();
      }
    },
    // invoiceGst() {
    //   if (!this.innerValue.excessWithGst) {
    //     return roundAwayFromZero(((this.quotesTotalExGst - this.invoice.quoteDiscount) * this.innerValue.gstRate) / 100)
    //   } else {
    //     return roundAwayFromZero((this.invoice.totalExGst * this.invoice.gstRate) / 100)
    //   }
    // }
    // gstChanged() {
    //   if (this.invoice && this.baseInvoice) {
    //     // return this.invoice.gst !== this.baseInvoice.gst
    //     return this.gst !== this.invoice.gst
    //   } else {
    //     return false
    //   }
    // }
    invTotalExGst: function invTotalExGst() {
      if (this.invoice.excessAmount && this.excessWithGst) {
        return this.invoiceTotal - this.invoice.quoteDiscount - this.invoice.excessAmount - this.invoice.ownerContribution;
      }
      return this.invoiceTotal - this.invoice.quoteDiscount;
    },
    isSuppQuote: function isSuppQuote() {
      return this.value.subQuoteNo > 0;
    },
    showGstRate: function showGstRate() {
      return this.invTotalExGst * (this.invoice.gstRate / 100) === this.invoice.gst;
    },
    invoiceTotal: function invoiceTotal() {
      //const ownerContribution = this.innerValue.excessWithGst ?
      //  this.invoice.ownerContribution : this.invoice.ownerContribution + this.invoice.ownerContribution * (this.invoice.gstRate/100)
      //return (
      //  this.invoice.totalExGst +
      //  this.invoice.quoteDiscount +
      //  this.invoice.excessAmount  +
      //  ownerContribution)
      var ownerContribution = this.innerValue.excessWithGst ? this.invoice.ownerContribution : this.invoice.ownerContribution + this.invoice.ownerContribution * (this.invoice.gstRate / 100);
      return this.invoice.totalExGst + this.invoice.quoteDiscount + this.invoice.excessAmount + ownerContribution;
    },
    isMainQuote: function isMainQuote() {
      return this.value.subQuoteNo == 0;
    },
    disableExcessWithGst: function disableExcessWithGst() {
      return !this.isUpdateInvoice || this.hasExcessInvoice || this.isSuppQuote || !this.$user.info.isSupportUser;
    },
    isOrm: function isOrm() {
      return this.value.orm !== null && this.value.orm !== undefined;
    },
    disableOwnerContribution: function disableOwnerContribution() {
      // return !this.isUpdateInvoice || this.hasExcessInvoice || this.isSuppQuote ||
      //   ((this.value.isAudaNet || this.isOrm) && !this.$user.info.isSupportUser)
      return !this.isUpdateInvoice || this.hasExcessInvoice || this.isSuppQuote || (this.value.isAudaNet || this.isOrm) && !this.$user.info.isSupportUser;
    },
    hasSupp: function hasSupp() {
      return this.innerValue.subQuoteNos.some(function (a) {
        return a.key > 0;
      });
    }
  },
  watch: {
    // innerValue: {
    //   handler: function(newVal, oldVal) {
    //     this.$emit('input', newVal)
    //   },
    //   deep: true
    // },
    showAsset: function showAsset(newVal, oldVal) {
      if (!newVal.customer && !newVal.insurer) {
        this.assetFilter.showCustomer = !oldVal.customer;
        this.assetFilter.showInsurer = !oldVal.insurer;
      }
      this.getAssetDropdown();
    },
    excessWithGst: function excessWithGst(newVal, oldVal) {
      if (this.isUpdateInvoice) {
        // Reset fixedGst
        this.fixedGst = false;
        if (newVal) {
          var quotetotalExGst = this.quotesTotalExGst - this.invoice.quoteDiscount - this.invoice.ownerContribution;
          var gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(quotetotalExGst * this.innerValue.gstRate / 100);
          this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(gst - this.invoice.excessAmount * this.innerValue.gstRate / 100);
        } else {
          var _quotetotalExGst = this.quotesTotalExGst - this.invoice.quoteDiscount;
          var _gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(_quotetotalExGst * this.innerValue.gstRate / 100);
          this.invoice.gst = _gst;
        }
        this.innerValue.excessWithGst = newVal;
      }
    },
    invoiceValues: function invoiceValues() {
      if (this.invoice && this.isUpdateInvoice) {
        // console.log('watch invoiceValues')
        this.recalculateTotals();
      }
    },
    'overrides.labourTotal': function overridesLabourTotal(newVal, oldVal) {
      if (newVal !== 0 && this.isUpdateInvoice) {
        this.overrides.rrTotal = 0;
        this.overrides.repairTotal = 0;
        this.overrides.rwaTotal = 0;
        this.overrides.paintTotal = 0;
      }
    },
    'overrides.rrTotal': function overridesRrTotal(newVal, oldVal) {
      if (newVal !== 0 && this.isUpdateInvoice) {
        this.overrides.labourTotal = 0;
      }
    },
    'overrides.repairTotal': function overridesRepairTotal(newVal, oldVal) {
      if (newVal !== 0 && this.isUpdateInvoice) {
        this.overrides.labourTotal = 0;
      }
    },
    'overrides.rwaTotal': function overridesRwaTotal(newVal, oldVal) {
      if (newVal !== 0 && this.isUpdateInvoice) {
        this.overrides.labourTotal = 0;
      }
    },
    'overrides.paintTotal': function overridesPaintTotal(newVal, oldVal) {
      if (newVal !== 0 && this.isUpdateInvoice) {
        this.overrides.labourTotal = 0;
      }
    },
    overrides: {
      handler: function handler() {
        if (this.invoice && this.isUpdateInvoice) {
          var vm = this;
          Object.keys(this.overrides).forEach(function (key, index) {
            vm.invoice[_QuoteService__WEBPACK_IMPORTED_MODULE_42__["OverrideMappings"][key]] = vm.overrides[key];
          });
          this.recalculateTotals();
        }
      },
      deep: true
    },
    'invoice.excessAmount': function invoiceExcessAmount(newVal, oldVal) {
      if (this.isUpdateInvoice && newVal !== undefined && !this.hasExcessInvoice && this.isMainQuote) {
        this.innerValue.excess = newVal;
      }
    },
    'invoice.ownerContribution': function invoiceOwnerContribution(newVal, oldVal) {
      if (this.isUpdateInvoice && newVal !== undefined && !this.hasExcessInvoice && this.isMainQuote) {
        this.innerValue.ownersContribution = newVal;
      }
    },
    'invoice.quoteDiscount': function invoiceQuoteDiscount(newVal, oldVal) {
      if (this.isUpdateInvoice && newVal !== undefined) {
        this.invoice.sdTotals = newVal;
      }
      if (this.isUpdateInvoice && newVal !== undefined && !this.hasExcessInvoice && this.isMainQuote) {
        this.innerValue.discount = newVal;
      }
    },
    'invoice.gst': function invoiceGst(newVal, oldVal) {
      if (this.invoice && this.isUpdateInvoice) {
        if (!this.innerValue.excessWithGst) {
          var ownerContributionGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.ownerContribution * this.invoice.gstRate / 100);
          var quotesTotalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.quotesTotalExGst - this.invoice.quoteDiscount - this.invoice.excessAmount - this.invoice.ownerContribution - ownerContributionGst);
          this.invoice.totalExGst = quotesTotalExGst;
          this.invoice.totalIncGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.totalExGst + this.invoice.gst);
        } else {
          this.invoice.totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.quotesTotalExGst - this.invoice.excessAmount - this.invoice.quoteDiscount - this.invoice.ownerContribution);
          this.invoice.totalIncGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.totalExGst + this.invoice.gst);
        }
      }
    },
    isDirty: function isDirty(newVal) {
      if (this.invoice && this.isUpdateInvoice) {
        this.invoice.isDirty = newVal;
      }
    },
    'invoice.invoicePayingType': function invoiceInvoicePayingType(newVal, oldVal) {
      // if (!oldVal || !this.invoice) {
      //   return
      // }
      // console.log('watch invoice.invoicePayingType', newVal, oldVal)
      // if (this.invoice.invoicePayingType === InvoicePayerTypes.Insurer && this.insurerAsset) {
      //   this.invoice.assetId = this.insurerAsset.assetId
      //   this.invoice.assetName = this.insurerAsset.assetName
      //   this.invoice.assetType = this.insurerAsset.assetType
      //   this.assetFilter.assetId = Guid.empty()
      //   this.selectedAsset = null
      // } else if (this.invoice.invoicePayingType === InvoicePayerTypes.Private && this.customerAsset) {
      //   this.invoice.assetId = this.customerAsset.assetId
      //   this.invoice.assetName = this.customerAsset.assetName
      //   this.invoice.assetType = this.customerAsset.assetType
      //   this.assetFilter.assetId = Guid.empty()
      //   this.selectedAsset = null
      // } else if (this.invoice.invoicePayingType === InvoicePayerTypes.ThirdParty) {
      //   this.invoice.assetId = Guid.empty()
      //   this.invoice.assetName = ''
      //   this.invoice.assetType = ''
      // }
    },
    includedQuotesTotalExGst: function includedQuotesTotalExGst(newVal, oldVal) {
      if (this.innerValue && this.invoice && this.currentSnapshot && this.isUpdateInvoice) {
        // console.log('includedQuotesTotalExGst', this.currentSnapshot)
        this.updateInvoice();
      }
    },
    selectedInvoiceDate: function selectedInvoiceDate(newVal, oldVal) {
      if (newVal && this.isUpdateInvoice) {
        this.invoice.invoiceDate = newVal.toISOString().split('.')[0] + 'Z';
        if (this.gstInvoice) {
          this.gstInvoice.invoiceDate = newVal.toISOString().split('.')[0] + 'Z';
        }
      } else if (this.isUpdateInvoice) {
        this.invoice.invoiceDate = null;
        if (this.gstInvoice) {
          this.gstInvoice.invoiceDate = null;
        }
      }
    }
  },
  created: function created() {
    var _this$innerValue25, _this$$v;
    if ((_this$innerValue25 = this.innerValue) !== null && _this$innerValue25 !== void 0 && _this$innerValue25.isAssessmentEnabled) {
      this.$router.replace({
        name: 'QuoteAssessmentInvoice',
        params: {
          quoteId: this.$route.params.quoteId
        }
      });
      return;
    }
    if ((_this$$v = this.$v) !== null && _this$$v !== void 0 && (_this$$v = _this$$v.entity) !== null && _this$$v !== void 0 && _this$$v.invoices) {
      this.$v.entity.invoices.$touch();
    }
    this.getIncludedQuotesTotals();
    this.getAssets();
    this.getInvoice();
  },
  mounted: function mounted() {
    var _this = this;
    this.$eventHub.$on(_enums__WEBPACK_IMPORTED_MODULE_36__["EventHubTypes"].EntitySaved, function () {
      _this.reloadInvoice();
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventHub.$off(_enums__WEBPACK_IMPORTED_MODULE_36__["EventHubTypes"].EntitySaved);
  },
  methods: {
    // FQ-2776: an EstImage quote is only invoiceable once it carries an authority of its own.
    // A supplementary no longer inherits the main quote's authorisedDate, so a null date here
    // means EstImage has not authorised this sub-quote.
    // PCK-651: only for quotes actually loaded from EstImage (JobId set), not every quote for an
    // EstImage insurer. The current quote carries `estimage`; quotesTotals rows carry isEstimageLoaded.
    isEstimageQuoteUnauthorised: function isEstimageQuoteUnauthorised(quote) {
      var isEstimageLoaded = quote !== null && quote !== void 0 && quote.estimage ? quote.estimage.jobId != null : !!(quote !== null && quote !== void 0 && quote.isEstimageLoaded);
      return isEstimageLoaded && !(quote !== null && quote !== void 0 && quote.authorisedDate);
    },
    estimageUnauthorisedLabel: function estimageUnauthorisedLabel(subQuoteNo) {
      return subQuoteNo === 0 ? 'Main' : "Add-".concat(subQuoteNo);
    },
    saveInvoice: function saveInvoice() {
      var _this2 = this;
      var diff = deep_diff__WEBPACK_IMPORTED_MODULE_38___default.a.diff(this.innerValue, this.value);
      if (!!diff) {
        this.$emit('input', this.innerValue);
        this.$nextTick(function () {
          _this2.$emit('save');
        });
        return;
      }
      if (!this.isUpdateInvoice) {
        this.$emit('save');
      } else {
        this.updateInvoice();
      }
    },
    voidInvoice: function voidInvoice() {
      this.isConfirmVoidActive = true;
    },
    confirmVoidInvoice: function confirmVoidInvoice() {
      var _this3 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _this3.isConfirmVoidActive = false;
              _context.n = 1;
              return _this3.deleteInvoice();
            case 1:
              _this3.$emit('input', _this3.innerValue);
              _this3.$nextTick(function () {
                _this3.$emit('save');
              });
            case 2:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    printInvoice: function printInvoice() {
      this.$emit('printInvoice');
    },
    getInvoice: function getInvoice() {
      var _arguments = arguments,
        _this4 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee2() {
        var cancel, baseSnapshot, _this4$innerValue$inv, _this4$innerValue$inv2, _this4$innerValue$inv3, key;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              cancel = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : false;
              if (_this4.innerValue) {
                _context2.n = 1;
                break;
              }
              return _context2.a(2);
            case 1:
              _this4.isLoadingInvoice = true;
              baseSnapshot = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(_this4.baseSnapshot); // this.baseInvoice = _cloneDeep(baseSnapshot.invoices.find(i => i.invoiceType === InvoiceTypes.Quote && !i.deleted))
              if (!cancel) {
                _this4.invoice = (_this4$innerValue$inv = _this4.innerValue.invoices) === null || _this4$innerValue$inv === void 0 ? void 0 : _this4$innerValue$inv.find(function (i) {
                  return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Quote && !i.deleted;
                });
                _this4.gstInvoice = (_this4$innerValue$inv2 = _this4.innerValue.invoices) === null || _this4$innerValue$inv2 === void 0 ? void 0 : _this4$innerValue$inv2.find(function (i) {
                  return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Gst && !i.deleted;
                });
                _this4.isGstInvoiceOn = _this4.gstInvoice && true;
                _this4.excessWithGst = _this4.innerValue.excessWithGst;
              } else {
                // const currentSnapshot = _cloneDeep(this.currentSnapshot)
                _this4.innerValue.excess = baseSnapshot.excess;
                _this4.innerValue.ownersContribution = baseSnapshot.ownersContribution;
                _this4.innerValue.discount = baseSnapshot.discount;
                _this4.innerValue.excessWithGst = baseSnapshot.excessWithGst;
                _this4.innerValue.quoteChanged = baseSnapshot.quoteChanged;
                _this4.excessWithGst = _this4.innerValue.excessWithGst;
                for (key in _this4.baseInvoice) {
                  if (_this4.baseInvoice.hasOwnProperty(key)) {
                    _this4.invoice[key] = _this4.baseInvoice[key];
                  }
                }
                // Reset GST Invoice if any
                _this4.gstInvoice = (_this4$innerValue$inv3 = _this4.innerValue.invoices) === null || _this4$innerValue$inv3 === void 0 ? void 0 : _this4$innerValue$inv3.find(function (i) {
                  return i.invoiceType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Gst && !i.deleted;
                });
                if (_this4.gstInvoice && _this4.gstInvoice.isNew) {
                  _this4.toggleGstInvoice(false);
                }
                _this4.isGstInvoiceOn = _this4.gstInvoice && true;
              }
              if (_this4.invoice) {
                if (_this4.invoice.invoicePayingType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"].ThirdParty) {
                  // Set selectedAsset
                  _this4.assetFilter.assetId = _this4.invoice.assetId;
                  _this4.getAssetDropdown();
                }
                _this4.selectedInvoiceDate = new Date("".concat(_this4.invoice.invoiceDate));
                if (_this4.isUpdateInvoice) {
                  _this4.updateInvoice();
                } else {
                  // console.log(this.invoice.gst, this.calculateGst())
                  _this4.fixedGst = _this4.invoice.gst !== _this4.calculateGst();
                }

                //Display Override amounts
                _this4.overrides.labourTotal = _this4.invoice.labourOverride;
                _this4.overrides.rrTotal = _this4.invoice.rrOverride;
                _this4.overrides.repairTotal = _this4.invoice.repairOverride;
                _this4.overrides.rwaTotal = _this4.invoice.rwaOverride;
                _this4.overrides.paintTotal = _this4.invoice.paintOverride;
                _this4.overrides.fgTotal = _this4.invoice.fgOverride;
                _this4.overrides.crushTotal = _this4.invoice.crushOverride;
                _this4.overrides.cdTotal = _this4.invoice.cdOverride;
                _this4.overrides.mechTotal = _this4.invoice.mechOverride;
              }
              if (_this4.gstInvoice) {
                _this4.gstAssetFilter.assetId = _this4.gstInvoice.assetId;
                _this4.getGstAssetDropdown();
              }
              _this4.isLoadingInvoice = false;
            case 2:
              return _context2.a(2);
          }
        }, _callee2);
      }))();
    },
    calculateGst: function calculateGst() {
      var ownerContributionGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.ownerContribution * this.invoice.gstRate / 100);
      if (!this.innerValue.excessWithGst) {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((this.invoice.totalExGst + this.invoice.excessAmount + this.invoice.ownerContribution + ownerContributionGst) * this.innerValue.gstRate / 100);
      } else {
        return Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.totalExGst * this.innerValue.gstRate / 100);
      }
    },
    getAssets: function getAssets() {
      var _this5 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee3() {
        var insurerAssetFilter, customerAssetFilter, insurers, customers, _yield$Promise$all, _yield$Promise$all2;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              insurerAssetFilter = {
                assetId: _this5.innerValue.insurerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              customerAssetFilter = {
                assetId: _this5.innerValue.customerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              _context3.n = 1;
              return Promise.all([_views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(insurerAssetFilter), _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(customerAssetFilter)]);
            case 1:
              _yield$Promise$all = _context3.v;
              _yield$Promise$all2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_yield$Promise$all, 2);
              insurers = _yield$Promise$all2[0];
              customers = _yield$Promise$all2[1];
              _this5.insurerAsset = insurers[0];
              _this5.customerAsset = customers[0];
            case 2:
              return _context3.a(2);
          }
        }, _callee3);
      }))();
    },
    getAssetDropdown: function getAssetDropdown() {
      var _this6 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee4() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              _this6.isAssetLoading = true;
              _context4.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(_this6.assetFilter);
            case 1:
              _this6.assets = _context4.v;
              if (_this6.assetFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty()) {
                _this6.selectedAsset = _this6.assets.find(function (c) {
                  return c.assetId === _this6.assetFilter.assetId;
                });
              }
              _this6.isAssetLoading = false;
            case 2:
              return _context4.a(2);
          }
        }, _callee4);
      }))();
    },
    getAssetDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_34___default()(/*#__PURE__*/function () {
      var _ref = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee5(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context5) {
          while (1) switch (_context5.n) {
            case 0:
              this.isAssetLoading = true;
              this.assetFilter.assetName = query;
              _context5.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(this.assetFilter);
            case 1:
              this.assets = _context5.v;
              this.isAssetLoading = false;
            case 2:
              return _context5.a(2);
          }
        }, _callee5, this);
      }));
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), 500),
    selectAsset: function selectAsset(selected) {
      var _this7 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee6() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context6) {
          while (1) switch (_context6.n) {
            case 0:
              _this7.invoice.assetId = selected.assetId;
              _this7.invoice.assetType = selected.assetType;
              _this7.invoice.invoiceGlCode = selected.assetGlCode;
              _this7.invoice.assetName = selected.assetName;
              _this7.assetFilter.assetId = selected.assetId;
            case 1:
              return _context6.a(2);
          }
        }, _callee6);
      }))();
    },
    removeAsset: function removeAsset(removed) {
      this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
      this.invoice.assetType = '';
      this.invoice.invoiceGlCode = '';
      this.invoice.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
      this.invoice.assetName = '';
      this.getAssetDropdown();
    },
    tabClicked: function tabClicked(invoiceType) {
      this.tabInvoiceType = invoiceType;
    },
    editInvoice: function editInvoice() {
      this.updateInvoice();
      // this.isUpdateInvoice = true
      this.setIsUpdateInvoice(true);
    },
    updateInvoice: function updateInvoice() {
      var reset = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
      // console.log('updateInvoice, reset:', reset)
      this.excessWithGst = this.innerValue.excessWithGst;
      this.invoice.gstRate = this.innerValue.gstRate;
      this.invoice.labourTotal = this.quotesLabourTotal;
      this.invoice.rrTotal = this.quotesRrTotal;
      this.invoice.repairTotal = this.quotesRepairTotal;
      this.invoice.rwaTotals = this.quotesRwaTotal;
      this.invoice.paintTotal = this.quotesPaintTotal;
      this.invoice.fgTotal = this.quotesFgTotal;
      this.invoice.crushTotal = this.quotesCrushTotal;
      this.invoice.cdTotal = this.quotesCdTotal;
      this.invoice.mechTotal = this.quotesMechTotal;
      this.invoice.opgTotal = this.quotesOpgTotal;
      this.invoice.partTotal = this.quotesPartTotal;
      this.invoice.miscTotal = this.quotesMiscTotal;
      this.invoice.subletTotal = this.quotesSubletTotal;
      if (reset) {
        this.invoice.excessAmount = this.quotesExcessTotal;
        this.invoice.ownerContribution = this.quotesOwnerContributionTotal;
        this.invoice.quoteDiscount = this.quotesDiscountTotal; //this.innerValue.discount
      }
      this.recalculateTotals(reset);
      this.innerValue.quoteChanged = false;
      this.invoice.isDirty = true;
    },
    recalculateTotals: function recalculateTotals() {
      var reset = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
      if (!this.innerValue.excessWithGst) {
        var ownerContributionGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.ownerContribution * this.invoice.gstRate / 100);
        var quotesTotalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.quotesTotalExGst - this.invoice.quoteDiscount - this.invoice.excessAmount - this.invoice.ownerContribution - ownerContributionGst);
        this.invoice.totalExGst = quotesTotalExGst;
        if (reset && !this.isFixedGst) {
          this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])((this.quotesTotalExGst - this.invoice.quoteDiscount) * this.innerValue.gstRate / 100);
        }
        this.invoice.totalIncGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.totalExGst + this.invoice.gst);
      } else {
        this.invoice.totalExGst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.quotesTotalExGst - this.invoice.excessAmount - this.invoice.quoteDiscount - this.invoice.ownerContribution);
        if (reset && !this.isFixedGst) {
          this.invoice.gst = Object(_components_utils_AccountingFunctions__WEBPACK_IMPORTED_MODULE_30__["roundAwayFromZero"])(this.invoice.totalExGst * this.invoice.gstRate / 100);
        }
        this.invoice.totalIncGst = this.invoice.totalExGst + this.invoice.gst;
      }
    },
    cancelInvoice: function cancelInvoice() {
      // this.isUpdateInvoice = false
      this.fixedGst = false;
      this.resetOverrides();
      this.setIsUpdateInvoice(false);
      this.getIncludedQuotesTotals();
      this.getInvoice(true);
    },
    addInvoice: function addInvoice() {
      var _this8 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee7() {
        var _this8$$company$jobNS;
        var hasInvoiced, combined, allDisabled;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context7) {
          while (1) switch (_context7.n) {
            case 0:
              // this.isUpdateInvoice = true
              _this8.innerValue.jobStage = _enums__WEBPACK_IMPORTED_MODULE_36__["JobStageTypes"].Closed;
              _this8.innerValue.subJobStage = (_this8$$company$jobNS = _this8.$company.jobNSubJobStages.find(function (stage) {
                return stage.jobStage === 10 && stage.subJobStageEnum === 'Completed';
              })) === null || _this8$$company$jobNS === void 0 ? void 0 : _this8$$company$jobNS.subJobStageId;
              _this8.setIsUpdateInvoice(true);
              _this8.isLoadingInvoice = true;
              _context7.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_35__["QuoteInvoiceService"].getNewEntity();
            case 1:
              _this8.invoice = _context7.v;
              _this8.existingInvoice = _this8.innerValue.invoices.find(function (i) {
                return !i.isNew && !i.deleted;
              });
              if (_this8.existingInvoice) {
                _this8.invoice.invoiceNo = _this8.existingInvoice.invoiceNo;
              }

              // New invoice values
              _this8.updateInvoice(true);
              _this8.invoice.invoiceType = _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Quote;
              _this8.invoice.assetId = _this8.innerValue.insurerId;
              _this8.invoice.assetType = _enums__WEBPACK_IMPORTED_MODULE_36__["AssetTypes"].Insurer;
              _this8.invoice.invoicePayingType = _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"].Insurer;
              _this8.selectedInvoiceDate = new Date(); //new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())

              _this8.invoice.includedQuotes.splice(_this8.invoice.includedQuotes.length, 1, _this8.innerValue.quoteId);
              _this8.innerValue.invoices.splice(_this8.innerValue.invoices.length, 1, _this8.invoice);
              _this8.gstPaid = false;
              _this8.getIncludedQuotesTotals();
              _this8.isLoadingInvoice = false;
              if (_this8.hasSupp) {
                hasInvoiced = _this8.quotesTotals.some(function (x) {
                  return x.isInvoiced == true;
                });
                combined = [Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _this8.innerValue.invoice), {}, {
                  subQuoteNo: _this8.innerValue.subQuoteNo,
                  selected: true,
                  disabled: true // already raised
                })].concat(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_this8.quotesTotals.map(function (item) {
                  // FQ-2776: never pre-select or allow selection of an unauthorised EstImage supp
                  var unauthorised = _this8.isEstimageQuoteUnauthorised(item);
                  return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, item), {}, {
                    unauthorised: unauthorised,
                    selected: unauthorised ? false : !hasInvoiced ? true : item.isInvoiced,
                    disabled: item.isInvoiced || unauthorised
                  });
                }))).sort(function (a, b) {
                  return a.subQuoteNo - b.subQuoteNo;
                });
                _this8.modalInvoices = combined;
                // Check if all invoices are disabled
                allDisabled = combined.every(function (inv) {
                  return inv.disabled;
                });
                if (allDisabled) {
                  _this8.isGenerateInvoiceModalActive = false;
                } else if (combined.filter(function (inv) {
                  return !inv.isInvoiced;
                }).length > 1) {
                  _this8.isGenerateInvoiceModalActive = true;
                }
              }
            case 2:
              return _context7.a(2);
          }
        }, _callee7);
      }))();
    },
    cancelGenerateInvoice: function cancelGenerateInvoice() {
      var _this9 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee8() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              _this9.isGenerateInvoiceModalActive = false;
              if (!(_this9.invoice && _this9.invoice.isNew)) {
                _context8.n = 1;
                break;
              }
              _context8.n = 1;
              return _this9.deleteInvoice();
            case 1:
              return _context8.a(2);
          }
        }, _callee8);
      }))();
    },
    deleteInvoice: function deleteInvoice() {
      var _this0 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee9() {
        var index, _index, baseSnapshot;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              if (_this0.invoice.isNew) {
                index = _this0.innerValue.invoices.map(function (obj) {
                  return obj.invoiceId;
                }).indexOf(_this0.invoice.invoiceId);
                _this0.innerValue.invoices.splice(index, 1);
                _this0.invoice = null;
              } else {
                _this0.invoice.deleted = true;
                _this0.invoice.isDeleted = true;
              }
              if (_this0.gstInvoice) {
                if (_this0.gstInvoice.isNew) {
                  _index = _this0.innerValue.invoices.map(function (obj) {
                    return obj.invoiceId;
                  }).indexOf(_this0.gstInvoice.invoiceId);
                  _this0.innerValue.invoices.splice(_index, 1);
                  _this0.gstInvoice = null;
                } else {
                  _this0.gstInvoice.deleted = true;
                  _this0.gstInvoice.isDeleted = true;
                }
                _this0.gstAssetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
                _this0.selectedGstAsset = null;
              }
              baseSnapshot = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(_this0.baseSnapshot);
              _this0.innerValue.jobStage = baseSnapshot.jobStage;
              _this0.innerValue.subJobStage = baseSnapshot.subJobStage;
              _this0.innerValue.quoteChanged = baseSnapshot.quoteChanged;
              _this0.isGstInvoiceOn = false;
              _this0.fixedGst = false;
              _this0.resetOverrides();
              _this0.setIsUpdateInvoice(false);
              _context9.n = 1;
              return _this0.getIncludedQuotesTotals(true);
            case 1:
              _this0.getInvoice();
            case 2:
              return _context9.a(2);
          }
        }, _callee9);
      }))();
    },
    updateTotal: function updateTotal() {
      var updateGst = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
    } // if (this.isUpdateInvoice) {
    //   this.updateInvoice(false)
    //   const quotetotalExGst = this.quotesTotalExGst - this.invoice.quoteDiscount
    //   if (updateGst) {
    //     this.invoice.gst = roundAwayFromZero((quotetotalExGst * this.innerValue.gstRate) / 100)
    //   }
    //   const ownerContributionIncGst = roundAwayFromZero(
    //     this.invoice.ownerContribution + roundAwayFromZero((this.invoice.ownerContribution * this.invoice.gstRate) / 100)
    //   )
    //   this.invoice.totalIncGst = roundAwayFromZero(quotetotalExGst + this.invoice.gst - this.invoice.excessAmount - ownerContributionIncGst)
    //   this.invoice.totalExGst = roundAwayFromZero(this.invoice.totalIncGst - this.invoice.gst)
    // }
    ,
    onInvoicePayerTypeClick: function onInvoicePayerTypeClick(payerType) {
      if (payerType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"].Insurer && this.insurerAsset) {
        // console.log('Insurer')
        this.invoice.assetId = this.insurerAsset.assetId;
        this.invoice.assetName = this.insurerAsset.assetName;
        this.invoice.assetType = this.insurerAsset.assetType;
        this.invoice.invoiceGlCode = this.insurerAsset.assetGlCode;
        this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
        this.selectedAsset = null;
      } else if (payerType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"].Private && this.customerAsset) {
        this.invoice.assetId = this.customerAsset.assetId;
        this.invoice.assetName = this.customerAsset.assetName;
        this.invoice.assetType = this.customerAsset.assetType;
        this.invoice.invoiceGlCode = this.customerAsset.assetGlCode;
        this.assetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
        this.selectedAsset = null;
      } else if (payerType === _enums__WEBPACK_IMPORTED_MODULE_36__["InvoicePayerTypes"].ThirdParty) {
        // console.log('ThirdParty')
        this.invoice.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
        this.invoice.assetName = '';
        this.invoice.assetType = '';
        this.getAssetDropdown();
      }
    },
    getIncludedQuotesTotals: function getIncludedQuotesTotals() {
      var _arguments2 = arguments,
        _this1 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee0() {
        var isDelete, quoteIds, vm, quotesTotals;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context0) {
          while (1) switch (_context0.n) {
            case 0:
              isDelete = _arguments2.length > 0 && _arguments2[0] !== undefined ? _arguments2[0] : false;
              if (!(_this1.innerValue.subQuoteNos.length > 1)) {
                _context0.n = 2;
                break;
              }
              quoteIds = _this1.innerValue.subQuoteNos.filter(function (q) {
                return q.key !== _this1.innerValue.subQuoteNo;
              }).map(function (q) {
                return q.value;
              });
              vm = _this1;
              _context0.n = 1;
              return _QuoteService__WEBPACK_IMPORTED_MODULE_42__["default"].getIncludedQuotesTotals(quoteIds);
            case 1:
              quotesTotals = _context0.v;
              _this1.quotesTotals.splice(0, _this1.quotesTotals.length);
              quotesTotals.forEach(function (quoteTotal) {
                // console.log(quoteTotal)
                var invoice = vm.innerValue.invoices.find(function (i) {
                  return i.invoiceId === quoteTotal.invoiceId;
                });
                if (invoice && quoteTotal.invoiceId === invoice.invoiceId && invoice.deleted) {
                  quoteTotal.isInvoiced = false;
                  quoteTotal.invoiceNo = '';
                  quoteTotal.invoiceId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
                }
                vm.quotesTotals.splice(quotesTotals.length, 1, quoteTotal);
              });
              if (!_this1.isUpdateInvoice || isDelete) {
                _this1.clearInvoiceIncludedQuotes();
                _this1.quotesTotals.forEach(function (q) {
                  if (vm.invoice && q.invoiceId === vm.invoice.invoiceId) {
                    vm.addInvoiceIncludedQuotes(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(q));
                  }
                });
              }
            case 2:
              return _context0.a(2);
          }
        }, _callee0);
      }))();
    },
    includeQuote: function includeQuote(quoteTotal, checked) {
      // FQ-2776: never attach an unauthorised EstImage sub-quote
      if (checked && this.isEstimageQuoteUnauthorised(quoteTotal)) {
        return;
      }
      if (checked) {
        this.addInvoiceIncludedQuotes(quoteTotal);
        this.invoice.includedQuotes.splice(this.invoice.includedQuotes.length, 1, quoteTotal.quoteId);
      } else {
        this.removeInvoiceIncludedQuotes(quoteTotal);
        var index = this.invoice.includedQuotes.findIndex(function (quoteId) {
          return quoteId === quoteTotal.quoteId;
        });
        this.invoice.includedQuotes.splice(index, 1);
      }
    },
    toggleGstInvoice: function toggleGstInvoice(checked) {
      var _this10 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee1() {
        var utcDate, index;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              if (!checked) {
                _context1.n = 2;
                break;
              }
              _context1.n = 1;
              return _services__WEBPACK_IMPORTED_MODULE_35__["QuoteInvoiceService"].getNewEntity();
            case 1:
              _this10.gstInvoice = _context1.v;
              if (_this10.invoice) {
                _this10.gstInvoice.invoiceNo = _this10.invoice.invoiceNo;
                _this10.gstInvoice.gst = _this10.invoice.gst;
              } else {
                _this10.gstInvoice.gst = _this10.innerValue.gst;
              }
              utcDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).toISOString();
              _this10.gstInvoice.invoiceDate = utcDate.split('.')[0] + 'Z';
              _this10.gstInvoice.totalExGst = _this10.gstInvoice.gst;
              _this10.gstInvoice.totalIncGst = _this10.gstInvoice.gst;
              _this10.gstInvoice.invoiceType = _enums__WEBPACK_IMPORTED_MODULE_36__["InvoiceTypes"].Gst;
              _this10.gstInvoice.assetId = '';
              _this10.gstInvoice.assetType = '';
              _this10.gstInvoice.invoicePayingType = 1;
              _this10.gstInvoice.includedQuotes.splice(_this10.gstInvoice.includedQuotes.length, 1, _this10.innerValue.quoteId);
              _this10.innerValue.invoices.splice(_this10.innerValue.invoices.length, 1, _this10.gstInvoice);
              _this10.fixedGst = true;
              _this10.invoice.gst = 0;
              _context1.n = 3;
              break;
            case 2:
              // Delete/Remove existing GST invoice
              if (_this10.invoice.isNew) {
                _this10.fixedGst = false;
                _this10.recalculateTotals();
              } else {
                _this10.invoice.gst = _this10.baseInvoice.gst;
                _this10.fixedGst = _this10.invoice.gst !== _this10.calculateGst();
              }
              if (_this10.gstInvoice.isNew) {
                index = _this10.innerValue.invoices.map(function (obj) {
                  return obj.quoteItemId;
                }).indexOf(_this10.gstInvoice.invoiceId);
                _this10.innerValue.invoices.splice(index, 1);
                _this10.gstInvoice = null;
              } else {
                _this10.gstInvoice.deleted = true;
                _this10.gstInvoice.isDeleted = true;
              }
              _this10.gstAssetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
              _this10.selectedGstAsset = null;
            case 3:
              _this10.getGstAssetDropdown();
            case 4:
              return _context1.a(2);
          }
        }, _callee1);
      }))();
    },
    getGstAssets: function getGstAssets() {
      var _this11 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee10() {
        var insurerAssetFilter, customerAssetFilter, insurers, customers, _yield$Promise$all3, _yield$Promise$all4;
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context10) {
          while (1) switch (_context10.n) {
            case 0:
              insurerAssetFilter = {
                assetId: _this11.innerValue.insurerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              customerAssetFilter = {
                assetId: _this11.innerValue.customerId,
                assetName: '',
                showCustomer: true,
                showInsurer: true,
                pageIndex: 1,
                pageSize: 1
              };
              _context10.n = 1;
              return Promise.all([_views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(insurerAssetFilter), _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(customerAssetFilter)]);
            case 1:
              _yield$Promise$all3 = _context10.v;
              _yield$Promise$all4 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_yield$Promise$all3, 2);
              insurers = _yield$Promise$all4[0];
              customers = _yield$Promise$all4[1];
              _this11.insurerAsset = insurers[0];
              _this11.customerAsset = customers[0];
            case 2:
              return _context10.a(2);
          }
        }, _callee10);
      }))();
    },
    getGstAssetDropdown: function getGstAssetDropdown() {
      var _this12 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee11() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context11) {
          while (1) switch (_context11.n) {
            case 0:
              _this12.isGstAssetLoading = true;
              _context11.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(_this12.gstAssetFilter);
            case 1:
              _this12.gstAssets = _context11.v;
              if (_this12.gstAssetFilter.assetId !== _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty()) {
                _this12.selectedGstAsset = _this12.gstAssets.find(function (c) {
                  return c.assetId === _this12.gstAssetFilter.assetId;
                });
              }
              _this12.isGstAssetLoading = false;
            case 2:
              return _context11.a(2);
          }
        }, _callee11);
      }))();
    },
    getGstAssetDropdownFilter: lodash_debounce__WEBPACK_IMPORTED_MODULE_34___default()(/*#__PURE__*/function () {
      var _ref2 = Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee12(query) {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context12) {
          while (1) switch (_context12.n) {
            case 0:
              this.isGstAssetLoading = true;
              this.gstAssetFilter.assetName = query;
              _context12.n = 1;
              return _views_quickinvoice_QuickInvoiceService_js__WEBPACK_IMPORTED_MODULE_31__["default"].getAssetDropdownProto(this.gstAssetFilter);
            case 1:
              this.gstAssets = _context12.v;
              this.isGstAssetLoading = false;
            case 2:
              return _context12.a(2);
          }
        }, _callee12, this);
      }));
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }(), 500),
    selectGstAsset: function selectGstAsset(selected) {
      var _this13 = this;
      return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_4__["default"])(/*#__PURE__*/Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().m(function _callee13() {
        return Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_regenerator_js__WEBPACK_IMPORTED_MODULE_3__["default"])().w(function (_context13) {
          while (1) switch (_context13.n) {
            case 0:
              _this13.gstInvoice.assetId = selected.assetId;
              _this13.gstInvoice.assetType = selected.assetType;
              _this13.gstInvoice.invoiceGlCode = selected.assetGlCode;
              _this13.gstInvoice.assetName = selected.assetName;
              _this13.gstAssetFilter.assetId = selected.assetId;
            case 1:
              return _context13.a(2);
          }
        }, _callee13);
      }))();
    },
    removeGstAsset: function removeGstAsset(removed) {
      this.gstAssetFilter.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
      this.gstInvoice.assetType = '';
      this.gstInvoice.invoiceGlCode = '';
      this.gstInvoice.assetId = _components_Guid__WEBPACK_IMPORTED_MODULE_32__["default"].empty();
      this.gstInvoice.assetName = '';
      this.getAssetDropdown();
    },
    reloadInvoice: function reloadInvoice() {
      // console.log('reloadInvoice')
      this.innerValue = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_39___default()(this.value);
      this.getIncludedQuotesTotals();
      this.getInvoice();
    },
    resetOverrides: function resetOverrides() {
      this.overrides.labourTotal = 0;
      this.overrides.rrTotal = 0;
      this.overrides.repairTotal = 0;
      this.overrides.rwaTotal = 0;
      this.overrides.paintTotal = 0;
      this.overrides.fgTotal = 0;
      this.overrides.crushTotal = 0;
      this.overrides.cdTotal = 0;
      this.overrides.mechTotal = 0;
      this.overrides.pdrRrTotal = 0;
      this.overrides.pdrReTotal = 0;
    },
    showChangeInvoiceNoModal: function showChangeInvoiceNoModal() {
      this.isInvoiceNoSearchModalActive = true;
    },
    changeInvoiceNo: function changeInvoiceNo(invoiceNo) {
      ;
      this.isInvoiceNoSearchModalActive = false, this.invoice.invoiceNo = invoiceNo;
      this.invoice.invoiceNoRef = "".concat(this.invoice.invoiceNo, "/1");
      // PCK-205: tell the API to keep this number rather than assign the next one on first save
      this.invoice.isInvoiceNoChanged = true;
      this.innerValue.invoices.forEach(function (inv) {
        inv.invoiceNo = invoiceNo;
      });
    },
    invoiceDateInputEvent: function invoiceDateInputEvent(event) {
      this.selectedInvoiceDate = this.$filters.fromISOWithCurrentTime(event.toISOString());
    },
    handleQuoteClick: function handleQuoteClick(event, quote) {
      event.preventDefault(); // Prevents checkbox default
      // this.isGenerateInvoiceModalActive = true
    },
    handleModalInvoiceClick: function handleModalInvoiceClick(event, invoice) {
      // FQ-2776: an unauthorised EstImage sub-quote can never be ticked
      if (invoice.unauthorised) {
        event.preventDefault();
        invoice.selected = false;
        return;
      }
      invoice.selected = event.target.checked;
    },
    handleAdd: function handleAdd() {
      var _this14 = this;
      this.modalInvoices.forEach(function (item) {
        // FQ-2776: never attach an unauthorised EstImage sub-quote, however it got selected
        if (item.unauthorised) {
          item.selected = false;
          var unauthIndex = _this14.invoice.includedQuotes.findIndex(function (quoteId) {
            return quoteId === item.quoteId;
          });
          if (unauthIndex > -1) {
            _this14.removeInvoiceIncludedQuotes(item);
            _this14.invoice.includedQuotes.splice(unauthIndex, 1);
          }
        } else if (!item.disabled) {
          if (item.selected) {
            _this14.addInvoiceIncludedQuotes(item);
            _this14.invoice.includedQuotes.splice(_this14.invoice.includedQuotes.length, 1, item.quoteId);
          } else {
            var index = _this14.invoice.includedQuotes.findIndex(function (quoteId) {
              return quoteId === item.quoteId;
            });
            if (index > -1) {
              _this14.removeInvoiceIncludedQuotes(item);
              _this14.invoice.includedQuotes.splice(index, 1);
            }
          }
        }
      });
      this.isGenerateInvoiceModalActive = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.iterator.constructor.js */ "./node_modules/core-js/modules/es.iterator.constructor.js");
/* harmony import */ var core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.iterator.filter.js */ "./node_modules/core-js/modules/es.iterator.filter.js");
/* harmony import */ var core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.iterator.some.js */ "./node_modules/core-js/modules/es.iterator.some.js");
/* harmony import */ var core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_iterator_some_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_7__);








var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "grid is-col-min-15"
  }, [_c("div", {
    staticClass: "cell is-flex"
  }, [_c("div", {
    staticClass: "is-flex-grow-1 is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("div", {
    staticClass: "columns"
  }, [_c("div", {
    staticClass: "column"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Invoice "), _vm.hasRaisedInvoice ? _c("span", {
    staticClass: "tag is-success is-light ml-2"
  }, [_vm._v("Invoiced")]) : _vm._e(), _vm.isPnetAuthorityNoRequired && !_vm.innerValue.pnet.authorityNo ? _c("span", {
    staticClass: "notification is-danger is-light is-size-7 p-2"
  }, [_vm._v(" PNET Authority No. is not present. Quote cannot be invoiced. ")]) : _vm._e()])]), _c("div", {
    staticClass: "column is-narrow"
  }, [!_vm.isLoadingInvoice ? _c("div", {
    staticClass: "buttons"
  }, [_c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.$user.hasEdit(_vm.$route.meta.id) && !_vm.readOnlyView && !_vm.isUpdateInvoice && _vm.invoice && !_vm.invoice.gstPaidDate && !_vm.innerValue.readOnly,
      expression: "$user.hasEdit($route.meta.id) && !readOnlyView && !isUpdateInvoice && invoice && !invoice.gstPaidDate && !innerValue.readOnly"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : "Update Invoice",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        !_vm.$licenceExpired && _vm.editInvoice();
      }
    }
  }, [_vm._m(0)]), _c("button", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.showSave && !_vm.$licenceExpired,
      expression: "showSave && !$licenceExpired"
    }],
    staticClass: "button is-info",
    on: {
      click: function click($event) {
        return _vm.saveInvoice();
      }
    }
  }, [_vm._m(1), _c("span", [_vm._v("Raise Invoice")])]), _vm.$user.hasAdd(_vm.$route.meta.id) && !_vm.invoice && !_vm.readOnlyView ? _c("span", {
    staticClass: "tooltip is-tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": _vm.$licenceExpired ? "Disabled, as your licence has expired" : _vm.isCurrentEstimageQuoteUnauthorised ? "EstImage authorisation required" : "New Invoice"
    }
  }, [_c("a", {
    staticClass: "button",
    attrs: {
      disabled: _vm.$licenceExpired || _vm.isPnetAuthorityNoRequired && !_vm.innerValue.pnet.authorityNo || _vm.isCurrentEstimageQuoteUnauthorised ? true : false
    },
    on: {
      click: function click($event) {
        _vm.$licenceExpired || _vm.isPnetAuthorityNoRequired && !_vm.innerValue.pnet.authorityNo || _vm.isCurrentEstimageQuoteUnauthorised ? "" : _vm.addInvoice();
      }
    }
  }, [_vm._m(2)])]) : _vm._e(), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.invoice && _vm.invoice.isNew,
      expression: "invoice && invoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Delete Invoice"
    },
    on: {
      click: function click($event) {
        return _vm.deleteInvoice();
      }
    }
  }, [_vm._m(3)]), _vm.canVoidInvoice ? _c("button", {
    staticClass: "button is-danger is-outlined",
    class: {
      "tooltip is-tooltip-bottom": _vm.$licenceExpired
    },
    attrs: {
      "data-tooltip": "Disabled, as your licence has expired",
      disabled: _vm.$licenceExpired
    },
    on: {
      click: function click($event) {
        return _vm.voidInvoice();
      }
    }
  }, [_vm._m(4), _c("span", [_vm._v("Void Invoice")])]) : _vm._e(), _vm.canPrintInvoice ? _c("button", {
    staticClass: "button is-outlined",
    class: "is-outlined-btn-".concat(_vm.$theme.name),
    on: {
      click: function click($event) {
        return _vm.printInvoice();
      }
    }
  }, [_vm._m(5), _c("span", [_vm._v("Print Invoice")])]) : _vm._e(), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isUpdateInvoice && _vm.invoice && !_vm.invoice.isNew,
      expression: "isUpdateInvoice && invoice && !invoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Update from quote"
    },
    on: {
      click: function click($event) {
        return _vm.updateInvoice();
      }
    }
  }, [_vm._m(6)]), _c("a", {
    directives: [{
      name: "show",
      rawName: "v-show",
      value: _vm.isUpdateInvoice && _vm.invoice && !_vm.invoice.isNew,
      expression: "isUpdateInvoice && invoice && !invoice.isNew"
    }],
    staticClass: "button tooltip is-tooltip-bottom",
    attrs: {
      "data-tooltip": "Cancel"
    },
    on: {
      click: function click($event) {
        return _vm.cancelInvoice();
      }
    }
  }, [_vm._m(7)])]) : _vm._e(), _vm.invoice && _vm.invoice.gstPaidDate ? _c("span", {
    staticClass: "tag is-warning is-pulled-right tooltip is-tooltip-warning",
    attrs: {
      "data-tooltip": "GST has been paid"
    }
  }, [_vm._v("GST paid on " + _vm._s(_vm.$filters.formatDateTimezone(_vm.invoice.gstPaidDate, _vm.$userInfo.locale)))]) : _vm._e()])]), _vm.invoice && !_vm.isLoadingInvoice ? _c("div", {
    staticClass: "field"
  }, [_vm.quotesTotals.filter(function (q) {
    return q.isInvoiced === false || q.invoiceId === _vm.invoice.invoiceId;
  }).length > 0 ? _c("label", {
    staticClass: "label"
  }, [_vm._v("Includes")]) : _vm._e(), _c("div", {
    staticClass: "control is-narrow"
  }, _vm._l(_vm.quotesTotals.filter(function (q) {
    return q.isInvoiced === false || q.invoiceId === _vm.invoice.invoiceId;
  }), function (quote) {
    return _c("div", {
      key: quote.subQuoteNo
    }, [_c("input", {
      staticClass: "is-checkradio",
      attrs: {
        type: "checkbox",
        id: "Add".concat(quote.subQuoteNo),
        disabled: !_vm.isUpdateInvoice || _vm.isPnetAuthorityNoRequired && !quote.pnetAuthorityNo || _vm.isEstimageQuoteUnauthorised(quote) && quote.invoiceId !== _vm.invoice.invoiceId
      },
      domProps: {
        checked: _vm.getIncludedStatus(quote)
      },
      on: {
        click: function click($event) {
          return _vm.includeQuote(quote, $event.target.checked);
        }
      }
    }), _c("label", {
      attrs: {
        for: "Add".concat(quote.subQuoteNo)
      }
    }, [_vm._v(_vm._s(quote.subQuoteNo === 0 ? "Main" : "Add-".concat(quote.subQuoteNo)))]), _vm.isPnetAuthorityNoRequired && !quote.pnetAuthorityNo ? _c("span", {
      staticClass: "notification is-danger is-light is-size-7 p-1"
    }, [_vm._v("PNET Authority No. is not present. " + _vm._s(quote.subQuoteNo === 0 ? "Main" : "Add-".concat(quote.subQuoteNo)) + " cannot be invoiced.")]) : _vm._e(), _vm.isEstimageQuoteUnauthorised(quote) && quote.invoiceId !== _vm.invoice.invoiceId ? _c("span", {
      staticClass: "notification is-danger is-light is-size-7 p-1"
    }, [_vm._v("EstImage authorisation required. " + _vm._s(_vm.estimageUnauthorisedLabel(quote.subQuoteNo)) + " cannot be invoiced.")]) : _vm._e()]);
  }), 0)]) : _vm._e(), _vm.invoice && _vm.quotesTotals.filter(function (q) {
    return q.isInvoiced === false || q.invoiceId === _vm.invoice.invoiceId;
  }).length > 0 ? _c("div", {
    staticClass: "is-divider"
  }) : _vm._e(), !_vm.invoice && _vm.isLoadingInvoice ? _c("div", {
    staticClass: "section"
  }, [_c("span", {
    staticClass: "is-loading-image has-text-grey has-text-centered"
  })]) : _vm.invoice ? _c("div", {
    staticStyle: {
      height: "93%",
      "align-self": "stretch"
    }
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice No.")]), _c("div", {
    staticClass: "field has-addons"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      placeholder: "Invoice No.",
      readonly: ""
    },
    domProps: {
      value: _vm.invoiceNoReference
    }
  })]), _vm.isUpdateInvoice && (_vm.$userInfo.isSupportUser || _vm.$userInfo.isCustomerAdministrator) ? _c("div", {
    staticClass: "control"
  }, [_c("button", {
    staticClass: "button is-warning is-inverted tooltip is-tooltip-warning",
    attrs: {
      "data-tooltip": "Change invoice no."
    },
    on: {
      click: _vm.showChangeInvoiceNoModal
    }
  }, [_vm._m(8)])]) : _vm._e()])]), !_vm.isUpdateInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      readonly: ""
    },
    domProps: {
      value: _vm.$filters.formatDateTimezone(_vm.selectedInvoiceDate, _vm.$userInfo.locale)
    }
  })]) : _vm.$userInfo && !_vm.gstPaid && _vm.selectedInvoiceDate ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Invoice Date")]), _c("v-date-picker", {
    attrs: {
      "is-dark": _vm.$theme.isDark,
      masks: _vm.formats,
      attributes: _vm.attrs,
      locale: _vm.$userInfo.locale,
      "min-date": _vm.firstDayOfMonth,
      timezone: _vm.$filters.getIanaTimezone()
    },
    on: {
      input: _vm.invoiceDateInputEvent
    },
    scopedSlots: _vm._u([{
      key: "default",
      fn: function fn(_ref) {
        var inputValue = _ref.inputValue,
          inputEvents = _ref.inputEvents;
        return [_c("div", {
          staticClass: "field"
        }, [_c("div", {
          staticClass: "control has-icons-left"
        }, [_c("input", _vm._g({
          staticClass: "input",
          attrs: {
            type: "text",
            placeholder: "Invoice Date",
            readonly: ""
          },
          domProps: {
            value: inputValue
          }
        }, inputEvents)), _c("span", {
          staticClass: "icon is-small is-left"
        }, [_c("i", {
          staticClass: "mdi mdi-calendar mdi-18px"
        })])])])];
      }
    }]),
    model: {
      value: _vm.selectedInvoiceDate,
      callback: function callback($$v) {
        _vm.selectedInvoiceDate = $$v;
      },
      expression: "selectedInvoiceDate"
    }
  })], 1) : _vm._e()]), _c("div", {
    staticClass: "is-divider"
  }), !_vm.isUpdateInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("input", {
    staticClass: "input is-static",
    attrs: {
      type: "text",
      readonly: ""
    },
    domProps: {
      value: _vm.invoice.assetName
    }
  })]) : _vm._e(), _vm.isUpdateInvoice && _vm.invoice.invoicePayingType === _vm.invoicePayerTypes.ThirdParty ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("div", {
    staticClass: "is-flex"
  }, [_c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-customer"
    }
  }, [_vm._v("Customer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showCustomer,
      expression: "assetFilter.showCustomer"
    }],
    attrs: {
      id: "chk-customer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showCustomer) ? _vm._i(_vm.assetFilter.showCustomer, null) > -1 : _vm.assetFilter.showCustomer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showCustomer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showCustomer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showCustomer", $$c);
        }
      }
    }
  }), _vm._m(9)])]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2 pl-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-insurer"
    }
  }, [_vm._v("Insurer")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.assetFilter.showInsurer,
      expression: "assetFilter.showInsurer"
    }],
    attrs: {
      id: "chk-insurer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.assetFilter.showInsurer) ? _vm._i(_vm.assetFilter.showInsurer, null) > -1 : _vm.assetFilter.showInsurer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.assetFilter.showInsurer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.assetFilter, "showInsurer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.assetFilter, "showInsurer", $$c);
        }
      }
    }
  }), _vm._m(10)])])])]), _c("div", {
    staticClass: "control is-expanded"
  }, [_vm.assets ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.invoices.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Select a payer",
      options: _vm.assets,
      loading: _vm.isAssetLoading,
      "internal-search": false,
      "options-limit": _vm.assetFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectAsset,
      remove: _vm.removeAsset,
      "search-change": _vm.getAssetDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetType == 1,
            "is-info": props.option.assetType == 4
          }
        }, [_vm._v(" " + _vm._s(props.option.assetType == 1 ? "Customer" : "Insurer") + " ")]), _c("span", [_vm._v(_vm._s("".concat(props.option.assetName)))])];
      }
    }], null, false, 2502510241),
    model: {
      value: _vm.selectedAsset,
      callback: function callback($$v) {
        _vm.selectedAsset = $$v;
      },
      expression: "selectedAsset"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Payer not found.")])]) : _vm._e(), _vm.$v.entity && _vm.$v.entity.invoices.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Payer is required.")]) : _vm._e()], 1)]) : _vm._e(), _vm.isUpdateInvoice ? _c("div", {
    staticClass: "field"
  }, [_vm.invoice.invoicePayingType !== _vm.invoicePayerTypes.ThirdParty ? _c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]) : _vm._e(), _c("div", {
    staticClass: "control"
  }, [_c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.invoicePayingType,
      expression: "invoice.invoicePayingType"
    }],
    attrs: {
      type: "radio",
      name: "rd-payerType1"
    },
    domProps: {
      value: _vm.invoicePayerTypes.Insurer,
      checked: _vm._q(_vm.invoice.invoicePayingType, _vm.invoicePayerTypes.Insurer)
    },
    on: {
      click: function click($event) {
        return _vm.onInvoicePayerTypeClick(_vm.invoicePayerTypes.Insurer);
      },
      change: function change($event) {
        return _vm.$set(_vm.invoice, "invoicePayingType", _vm.invoicePayerTypes.Insurer);
      }
    }
  }), _vm._m(11)]), _c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.invoicePayingType,
      expression: "invoice.invoicePayingType"
    }],
    attrs: {
      type: "radio",
      name: "rd-payerType1",
      disabled: !_vm.customerAsset
    },
    domProps: {
      value: _vm.invoicePayerTypes.Private,
      checked: _vm._q(_vm.invoice.invoicePayingType, _vm.invoicePayerTypes.Private)
    },
    on: {
      click: function click($event) {
        return _vm.onInvoicePayerTypeClick(_vm.invoicePayerTypes.Private);
      },
      change: function change($event) {
        return _vm.$set(_vm.invoice, "invoicePayingType", _vm.invoicePayerTypes.Private);
      }
    }
  }), _vm._m(12)]), _c("div", {
    staticClass: "pretty p-default p-round p-bigger p-smooth"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.invoicePayingType,
      expression: "invoice.invoicePayingType"
    }],
    attrs: {
      type: "radio",
      name: "rd-payerType1"
    },
    domProps: {
      value: _vm.invoicePayerTypes.ThirdParty,
      checked: _vm._q(_vm.invoice.invoicePayingType, _vm.invoicePayerTypes.ThirdParty)
    },
    on: {
      click: function click($event) {
        return _vm.onInvoicePayerTypeClick(_vm.invoicePayerTypes.ThirdParty);
      },
      change: function change($event) {
        return _vm.$set(_vm.invoice, "invoicePayingType", _vm.invoicePayerTypes.ThirdParty);
      }
    }
  }), _vm._m(13)])]), !_vm.customerAsset ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Private invoice disabled. Customer has been deleted")]) : _vm._e()]) : _vm._e(), _c("div", {
    staticClass: "is-divider"
  }), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Excess")]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pr-1 is-size-7",
    class: {
      "pretty-checkbox-label": !_vm.disableExcessWithGst
    },
    attrs: {
      for: "chk-invoiceExcessWtihGst"
    }
  }, [_vm._v("Excess with GST")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.excessWithGst,
      expression: "excessWithGst"
    }],
    attrs: {
      id: "chk-invoiceExcessWtihGst",
      type: "checkbox",
      disabled: _vm.disableExcessWithGst
    },
    domProps: {
      checked: Array.isArray(_vm.excessWithGst) ? _vm._i(_vm.excessWithGst, null) > -1 : _vm.excessWithGst
    },
    on: {
      change: function change($event) {
        var $$a = _vm.excessWithGst,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.excessWithGst = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.excessWithGst = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.excessWithGst = $$c;
        }
      }
    }
  }), _vm._m(14)])])]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateInvoice || _vm.hasExcessInvoice || _vm.isSuppQuote
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      }
    },
    model: {
      value: _vm.invoice.excessAmount,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "excessAmount", _vm._n($$v));
      },
      expression: "invoice.excessAmount"
    }
  })], 1)]), _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Owner Contribution")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: _vm.disableOwnerContribution
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      }
    },
    model: {
      value: _vm.invoice.ownerContribution,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "ownerContribution", _vm._n($$v));
      },
      expression: "invoice.ownerContribution"
    }
  })], 1)])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "field-body"
  }, [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Discount")]), _c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      "min:": 0,
      precision: 2,
      disabled: !_vm.isUpdateInvoice || _vm.isSuppQuote
    },
    on: {
      input: function input($event) {
        return _vm.updateTotal();
      }
    },
    model: {
      value: _vm.invoice.quoteDiscount,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "quoteDiscount", _vm._n($$v));
      },
      expression: "invoice.quoteDiscount"
    }
  })], 1), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "is-flex is-justify-content-space-between"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("GST")]), _c("div", {
    staticClass: "is-flex is-align-items-center is-justify-content-end mb-2"
  }, [_c("label", {
    staticClass: "pretty-checkbox-label pr-1 is-size-7",
    attrs: {
      for: "chk-fixed-gst"
    }
  }, [_vm._v("Fixed")]), _c("div", {
    staticClass: "pretty p-icon p-round p-smooth m-0"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.fixedGst,
      expression: "fixedGst"
    }],
    attrs: {
      id: "chk-fixed-gst",
      type: "checkbox",
      disabled: !_vm.isUpdateInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.fixedGst) ? _vm._i(_vm.fixedGst, null) > -1 : _vm.fixedGst
    },
    on: {
      change: function change($event) {
        var $$a = _vm.fixedGst,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.fixedGst = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.fixedGst = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.fixedGst = $$c;
        }
      }
    }
  }), _vm._m(15)])])]), _c("div", {
    staticClass: "control"
  }, [_c("vue-numeric", {
    staticClass: "input has-text-right",
    attrs: {
      minus: true,
      precision: 2,
      disabled: !_vm.isUpdateInvoice || _vm.isGstInvoiceOn
    },
    model: {
      value: _vm.invoice.gst,
      callback: function callback($$v) {
        _vm.$set(_vm.invoice, "gst", _vm._n($$v));
      },
      expression: "invoice.gst"
    }
  })], 1)])])]), _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.exported,
      expression: "invoice.exported"
    }],
    staticClass: "is-checkradio",
    attrs: {
      type: "checkbox",
      id: "invoice-exported",
      disabled: _vm.readOnlyView || !_vm.$userInfo.isSupportUser || !_vm.isUpdateInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.invoice.exported) ? _vm._i(_vm.invoice.exported, null) > -1 : _vm.invoice.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.invoice.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.invoice, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.invoice, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.invoice, "exported", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "invoice-exported"
    }
  }, [_vm._v("Exported")])])]), _c("div", {
    staticClass: "columns has-text-right"
  }, [_c("div", {
    staticClass: "column is-three-quarters"
  }, [_vm._m(16), _vm.invoice.quoteDiscount ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Discount")]) : _vm._e(), _vm.invoice.excessAmount && _vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Excess")]) : _vm._e(), _vm.invoice.ownerContribution && _vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Owner Cont.")]) : _vm._e(), _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("GST "), _vm.showGstRate ? _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(" + _vm._s(_vm.invoice.gstRate) + "%)")]) : _vm._e()]), _vm.invoice.ownerContribution && !_vm.excessWithGst || _vm.invoice.excessAmount && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]) : _vm._e(), _vm.invoice.ownerContribution && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Owner Cont. "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]) : _vm._e(), _vm.invoice.excessAmount && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Excess")]) : _vm._e(), _vm._m(17)]), _c("div", {
    staticClass: "column is-one-quarters"
  }, [_c("span", {
    staticClass: "label has-text-success has-text-weight-normal"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.invoiceTotal, _vm.$userInfo.locale)))]), _vm.invoice.quoteDiscount ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.quoteDiscount, _vm.$userInfo.locale)))]) : _vm._e(), _vm.invoice.excessAmount && _vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.excessAmount, _vm.$userInfo.locale)))]) : _vm._e(), _vm.invoice.ownerContribution && _vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.ownerContribution, _vm.$userInfo.locale)))]) : _vm._e(), _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm.invoice.gst > 0 ? _c("span", [_vm._v("+")]) : _vm._e(), _vm._v(" " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.gst, _vm.$userInfo.locale)))]), _vm.invoice.ownerContribution && !_vm.excessWithGst || _vm.invoice.excessAmount && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.invTotalExGst + _vm.invoice.gst, _vm.$userInfo.locale)))]) : _vm._e(), _vm.invoice.ownerContribution && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.ownerContribution * (_vm.invoice.gstRate / 100 + 1), _vm.$userInfo.locale)))]) : _vm._e(), _vm.invoice.excessAmount && !_vm.excessWithGst ? _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("- " + _vm._s(_vm.$filters.formatCurrency(_vm.invoice.excessAmount, _vm.$userInfo.locale)))]) : _vm._e(), _c("span", {
    staticClass: "label has-text-success"
  }, [_vm._v(_vm._s(_vm.$filters.formatCurrency(_vm.totalPayableIncGst, _vm.$userInfo.locale)))])])]), _c("div", {
    staticClass: "is-divider"
  }), _vm.invoice && !_vm.isLoadingInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-narrow"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.isGstInvoiceOn,
      expression: "isGstInvoiceOn"
    }],
    staticClass: "is-checkradio",
    attrs: {
      type: "checkbox",
      id: "gstInvoice",
      disabled: !_vm.isUpdateInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.isGstInvoiceOn) ? _vm._i(_vm.isGstInvoiceOn, null) > -1 : _vm.isGstInvoiceOn
    },
    on: {
      click: function click($event) {
        return _vm.toggleGstInvoice($event.target.checked);
      },
      change: function change($event) {
        var $$a = _vm.isGstInvoiceOn,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.isGstInvoiceOn = $$a.concat([$$v]));
          } else {
            $$i > -1 && (_vm.isGstInvoiceOn = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.isGstInvoiceOn = $$c;
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "gstInvoice"
    }
  }, [_vm._v("GST Invoice")])])]) : _vm._e(), _vm.isUpdateInvoice && _vm.isGstInvoiceOn ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control is-pulled-right"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.gstAssetFilter.showCustomer,
      expression: "gstAssetFilter.showCustomer"
    }],
    staticClass: "is-checkradio is-small is-circle is-success is-rtl",
    class: {
      "has-background-color": _vm.gstAssetFilter.showCustomer
    },
    attrs: {
      id: "chk-gstCustomer",
      name: "chk-gstCustomer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.gstAssetFilter.showCustomer) ? _vm._i(_vm.gstAssetFilter.showCustomer, null) > -1 : _vm.gstAssetFilter.showCustomer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.gstAssetFilter.showCustomer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.gstAssetFilter, "showCustomer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.gstAssetFilter, "showCustomer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.gstAssetFilter, "showCustomer", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "chk-gstCustomer"
    }
  }, [_vm._v("Customer")]), _c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.gstAssetFilter.showInsurer,
      expression: "gstAssetFilter.showInsurer"
    }],
    staticClass: "is-checkradio is-small is-circle is-info is-rtl",
    class: {
      "has-background-color": _vm.gstAssetFilter.showInsurer
    },
    attrs: {
      id: "chk-gstInsurer",
      name: "chk-gstInsurer",
      type: "checkbox"
    },
    domProps: {
      checked: Array.isArray(_vm.gstAssetFilter.showInsurer) ? _vm._i(_vm.gstAssetFilter.showInsurer, null) > -1 : _vm.gstAssetFilter.showInsurer
    },
    on: {
      change: function change($event) {
        var $$a = _vm.gstAssetFilter.showInsurer,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.gstAssetFilter, "showInsurer", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.gstAssetFilter, "showInsurer", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.gstAssetFilter, "showInsurer", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "chk-gstInsurer"
    }
  }, [_vm._v("Insurer")])])]) : _vm._e(), _vm.isUpdateInvoice && _vm.isGstInvoiceOn ? _c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("div", {
    staticClass: "control is-expanded"
  }, [_vm.assets ? _c("multiselect", {
    class: {
      "is-danger": _vm.$v.entity.invoices.$error
    },
    attrs: {
      "deselect-label": "Can't remove this value",
      "track-by": "assetId",
      label: "assetName",
      placeholder: "Select a payer",
      options: _vm.gstAssets,
      loading: _vm.isGstAssetLoading,
      "internal-search": false,
      "options-limit": _vm.gstAssetFilter.pageSize,
      searchable: true,
      "show-labels": false,
      "allow-empty": true
    },
    on: {
      select: _vm.selectGstAsset,
      remove: _vm.removeGstAsset,
      "search-change": _vm.getGstAssetDropdownFilter
    },
    scopedSlots: _vm._u([{
      key: "option",
      fn: function fn(props) {
        return [_c("span", {
          staticClass: "tag is-pulled-right",
          class: {
            "is-success": props.option.assetType == 1,
            "is-info": props.option.assetType == 4
          }
        }, [_vm._v(" " + _vm._s(props.option.assetType == 1 ? "Customer" : "Insurer") + " ")]), _c("span", [_vm._v(_vm._s("".concat(props.option.assetName)))])];
      }
    }], null, false, 2502510241),
    model: {
      value: _vm.selectedGstAsset,
      callback: function callback($$v) {
        _vm.selectedGstAsset = $$v;
      },
      expression: "selectedGstAsset"
    }
  }, [_c("span", {
    staticClass: "has-text-danger",
    attrs: {
      slot: "noResult"
    },
    slot: "noResult"
  }, [_vm._v("Payer not found.")])]) : _vm._e(), _vm.$v.entity && _vm.$v.entity.invoices.$error ? _c("span", {
    staticClass: "help is-danger"
  }, [_vm._v("Payer is required.")]) : _vm._e()], 1)]) : !_vm.isUpdateInvoice && _vm.gstInvoice ? _c("div", [_c("label", {
    staticClass: "label"
  }, [_vm._v("Payer")]), _c("span", [_vm._v(_vm._s(_vm.gstInvoice.assetName))])]) : _vm._e(), _vm.$userInfo.isSupportUser && _vm.gstInvoice ? _c("div", {
    staticClass: "field"
  }, [_c("div", {
    staticClass: "control"
  }, [_c("input", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.gstInvoice.exported,
      expression: "gstInvoice.exported"
    }],
    staticClass: "is-checkradio",
    attrs: {
      type: "checkbox",
      id: "gstInvoice-exported",
      disabled: !_vm.isUpdateInvoice
    },
    domProps: {
      checked: Array.isArray(_vm.gstInvoice.exported) ? _vm._i(_vm.gstInvoice.exported, null) > -1 : _vm.gstInvoice.exported
    },
    on: {
      change: function change($event) {
        var $$a = _vm.gstInvoice.exported,
          $$el = $event.target,
          $$c = $$el.checked ? true : false;
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && _vm.$set(_vm.gstInvoice, "exported", $$a.concat([$$v]));
          } else {
            $$i > -1 && _vm.$set(_vm.gstInvoice, "exported", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
          }
        } else {
          _vm.$set(_vm.gstInvoice, "exported", $$c);
        }
      }
    }
  }), _c("label", {
    attrs: {
      for: "gstInvoice-exported"
    }
  }, [_vm._v("Exported")])])]) : _vm._e()]) : _vm._e()])])]), _c("div", {
    staticClass: "cell is-flex"
  }, [_c("article", {
    staticClass: "box is-flex-grow-1"
  }, [_c("p", {
    staticClass: "title"
  }, [_vm._v("Remarks")]), _vm.invoice && !_vm.isLoadingInvoice ? _c("div", [_c("div", {
    staticClass: "field"
  }, [_c("label", {
    staticClass: "label"
  }, [_vm._v("Remark")]), _c("div", {
    staticClass: "control"
  }, [_c("textarea", {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.invoice.invoiceRemark,
      expression: "invoice.invoiceRemark"
    }],
    staticClass: "textarea",
    attrs: {
      placeholder: "",
      disabled: !_vm.isUpdateInvoice
    },
    domProps: {
      value: _vm.invoice.invoiceRemark
    },
    on: {
      input: function input($event) {
        if ($event.target.composing) return;
        _vm.$set(_vm.invoice, "invoiceRemark", $event.target.value);
      }
    }
  })])]), false ? undefined : _vm._e()]) : _vm._e()])]), _vm.isConfirmVoidActive ? _c("confirm-modal", {
    attrs: {
      active: _vm.isConfirmVoidActive,
      "ok-text": "Yes",
      "ok-class": "is-success",
      "cancel-text": "No"
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isConfirmVoidActive = $event;
      },
      ok: function ok($event) {
        return _vm.confirmVoidInvoice();
      },
      cancel: function cancel($event) {
        _vm.isConfirmVoidActive = false;
      }
    }
  }, [_c("p", {
    attrs: {
      slot: "text-title"
    },
    slot: "text-title"
  }, [_vm._v("Void Invoice")]), _c("p", {
    attrs: {
      slot: "text-content"
    },
    slot: "text-content"
  }, [_c("span", [_vm._v("Are you sure you want to void the invoice? Proceeding will result in voiding invoice: ")]), _c("span", {
    staticClass: "bold-text"
  }, [_vm._v(_vm._s(_vm.invoiceNoReference))])])]) : _vm._e(), _vm.isInvoiceNoSearchModalActive ? _c("invoice-no-search-modal", {
    attrs: {
      active: _vm.isInvoiceNoSearchModalActive,
      "invoice-type": 1
    },
    on: {
      "update:active": function updateActive($event) {
        _vm.isInvoiceNoSearchModalActive = $event;
      },
      ok: _vm.changeInvoiceNo,
      close: function close($event) {
        _vm.isInvoiceNoSearchModalActive = false;
      }
    }
  }) : _vm._e(), _c("BulmaMessage", {
    attrs: {
      type: "is-info",
      title: "Create New Invoice",
      closable: true
    },
    on: {
      close: function close($event) {
        _vm.isGenerateInvoiceModalActive = false;
      }
    },
    scopedSlots: _vm._u([{
      key: "title",
      fn: function fn() {
        return [_vm._v(" Create New Invoice ")];
      },
      proxy: true
    }, {
      key: "footer",
      fn: function fn() {
        return [_c("button", {
          staticClass: "button is-danger",
          on: {
            click: function click($event) {
              return _vm.cancelGenerateInvoice();
            }
          }
        }, [_vm._v(" Cancel ")]), _c("button", {
          staticClass: "button is-primary",
          on: {
            click: function click($event) {
              return _vm.handleAdd();
            }
          }
        }, [_vm._v(" Add ")])];
      },
      proxy: true
    }]),
    model: {
      value: _vm.isGenerateInvoiceModalActive,
      callback: function callback($$v) {
        _vm.isGenerateInvoiceModalActive = $$v;
      },
      expression: "isGenerateInvoiceModalActive"
    }
  }, [_vm.modalInvoices.some(function (inv) {
    return inv.disabled && !inv.unauthorised && inv.subQuoteNo !== _vm.value.subQuoteNo;
  }) ? _c("div", [_c("p", {
    staticClass: "is-size-7 has-text-grey mb-2"
  }, [_vm._v("Already invoiced:")]), _c("div", {
    staticClass: "control is-flex justify-content-start"
  }, _vm._l(_vm.modalInvoices.filter(function (inv) {
    return inv.disabled && !inv.unauthorised && inv.subQuoteNo !== _vm.value.subQuoteNo;
  }), function (inv) {
    return _c("div", {
      key: inv.subQuoteNo,
      staticClass: "p-2",
      staticStyle: {
        opacity: "0.6"
      }
    }, [_c("label", {
      staticClass: "checkbox toggle-style",
      attrs: {
        for: "ModalAdd".concat(inv.subQuoteNo)
      }
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger pr-1"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: inv.selected,
        expression: "inv.selected"
      }],
      attrs: {
        type: "checkbox",
        disabled: "",
        id: "ModalAdd".concat(inv.subQuoteNo)
      },
      domProps: {
        value: inv.selected,
        checked: Array.isArray(inv.selected) ? _vm._i(inv.selected, inv.selected) > -1 : inv.selected
      },
      on: {
        change: function change($event) {
          var $$a = inv.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = inv.selected,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(inv, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(inv, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(inv, "selected", $$c);
          }
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]), _vm._v(" " + _vm._s(inv.subQuoteNo === 0 ? "Main" : "Add-".concat(inv.subQuoteNo)) + " ")])]);
  }), 0), _c("div", {
    staticClass: "is-divider"
  })]) : _vm._e(), _c("p", [_vm._v("Available for Invoicing: main / supplementaries")]), _vm.modalInvoices.some(function (inv) {
    return !inv.disabled || inv.unauthorised || inv.disabled && inv.subQuoteNo === _vm.value.subQuoteNo;
  }) ? _c("div", {
    staticClass: "mb-4"
  }, [_c("div", {
    staticClass: "control is-flex justify-content-start"
  }, _vm._l(_vm.modalInvoices.filter(function (inv) {
    return !inv.disabled || inv.unauthorised || inv.disabled && inv.subQuoteNo === _vm.value.subQuoteNo;
  }), function (inv) {
    return _c("div", {
      key: inv.subQuoteNo,
      staticClass: "p-2"
    }, [_c("label", {
      staticClass: "checkbox toggle-style",
      attrs: {
        for: "ModalAdd".concat(inv.subQuoteNo)
      }
    }, [_c("div", {
      staticClass: "pretty p-icon p-curve p-smooth m-0 p-bigger pr-1"
    }, [_c("input", {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: inv.selected,
        expression: "inv.selected"
      }],
      attrs: {
        type: "checkbox",
        disabled: inv.disabled,
        id: "ModalAdd".concat(inv.subQuoteNo)
      },
      domProps: {
        value: inv.selected,
        checked: Array.isArray(inv.selected) ? _vm._i(inv.selected, inv.selected) > -1 : inv.selected
      },
      on: {
        click: function click($event) {
          return _vm.handleModalInvoiceClick($event, inv);
        },
        change: function change($event) {
          var $$a = inv.selected,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = inv.selected,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(inv, "selected", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(inv, "selected", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(inv, "selected", $$c);
          }
        }
      }
    }), _c("div", {
      staticClass: "state p-primary"
    }, [_c("i", {
      staticClass: "icon mdi mdi-check"
    }), _c("label")])]), _vm._v(" " + _vm._s(inv.subQuoteNo === 0 ? "Main" : "Add-".concat(inv.subQuoteNo)) + " ")])]);
  }), 0), _vm._l(_vm.modalInvoices.filter(function (inv) {
    return inv.unauthorised;
  }), function (inv) {
    return _c("div", {
      key: "unauth".concat(inv.subQuoteNo),
      staticClass: "notification is-danger is-light is-size-7 p-1 mt-2"
    }, [_vm._v(" EstImage authorisation required. " + _vm._s(_vm.estimageUnauthorisedLabel(inv.subQuoteNo)) + " cannot be invoiced. ")]);
  })], 2) : _vm._e()])], 1);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-playlist-check mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-success"
  }, [_c("i", {
    staticClass: "mdi mdi-plus mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-danger"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-delete mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon"
  }, [_c("i", {
    staticClass: "mdi mdi-printer mdi-18px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-primary"
  }, [_c("i", {
    staticClass: "mdi mdi-refresh mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon has-text-warning"
  }, [_c("i", {
    staticClass: "mdi mdi-close mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "icon is-medium"
  }, [_c("i", {
    staticClass: "mdi mdi-pencil-outline mdi-24px"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-success"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", [_vm._v("Insurer")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", [_vm._v("Private")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary-o"
  }, [_c("label", [_vm._v("3rd Party")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "state p-primary"
  }, [_c("i", {
    staticClass: "icon mdi mdi-check"
  }), _c("label")]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "label has-text-weight-normal"
  }, [_vm._v("Total "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Ex GST)")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c("span", {
    staticClass: "label"
  }, [_vm._v("Total Payable "), _c("span", {
    staticClass: "subtext"
  }, [_vm._v("(Inc GST)")])]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".is-divider[data-v-597cfb7e] {\n  margin: 1.2em 0;\n}\n.is-bottom[data-v-597cfb7e] {\n  height: 280px;\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n  -ms-flex-item-align: stretch;\n      align-self: stretch;\n  justify-self: stretch;\n}\n.subtext[data-v-597cfb7e] {\n  font-size: 10px;\n}\n.bold-text[data-v-597cfb7e] {\n  font-weight: bold;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader??ref--9-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--9-oneOf-1-2!./node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__(/*! ../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("5ae2a008", content, false, {"sourceMap":false,"shadowMode":false});
// Hot Module Replacement
if(false) {}

/***/ }),

/***/ "./src/views/quote/QuoteInvoice.vue":
/*!******************************************!*\
  !*** ./src/views/quote/QuoteInvoice.vue ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true */ "./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true");
/* harmony import */ var _QuoteInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./QuoteInvoice.vue?vue&type=script&lang=js */ "./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport *//* harmony import */ var _QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true */ "./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _QuoteInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_1__["default"],
  _QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"],
  _QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "597cfb7e",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/views/quote/QuoteInvoice.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js":
/*!******************************************************************!*\
  !*** ./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInvoice.vue?vue&type=script&lang=js */ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=script&lang=js");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_script_lang_js__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true":
/*!***************************************************************************************************!*\
  !*** ./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader??ref--9-oneOf-1-0!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/src??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true */ "./node_modules/vue-style-loader/index.js?!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=style&index=0&id=597cfb7e&lang=scss&scoped=true");
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_style_index_0_id_597cfb7e_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true":
/*!************************************************************************************!*\
  !*** ./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"39db8e56-vue-loader-template"}!../../../node_modules/cache-loader/dist/cjs.js??ref--13-0!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../node_modules/cache-loader/dist/cjs.js??ref--1-0!../../../node_modules/vue-loader/lib??vue-loader-options!./QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true */ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"39db8e56-vue-loader-template\"}!./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/views/quote/QuoteInvoice.vue?vue&type=template&id=597cfb7e&scoped=true");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_cache_loader_dist_cjs_js_cacheDirectory_node_modules_cache_vue_loader_cacheIdentifier_39db8e56_vue_loader_template_node_modules_cache_loader_dist_cjs_js_ref_13_0_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_QuoteInvoice_vue_vue_type_template_id_597cfb7e_scoped_true__WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./src/views/quote/mixins/QuoteInvoiceStoreMixin.js":
/*!**********************************************************!*\
  !*** ./src/views/quote/mixins/QuoteInvoiceStoreMixin.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");



var moduleName = 'quotes';
/* harmony default export */ __webpack_exports__["default"] = ({
  computed: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapGetters"])(moduleName, {
    baseSnapshot: 'baseSnapshot',
    currentSnapshot: 'currentSnapshot',
    isUpdateInvoice: 'isUpdateInvoice',
    isUpdateExcessInvoice: 'isUpdateExcessInvoice',
    invoiceIncludedQuotes: 'invoiceIncludedQuotes',
    isFixedGst: 'isFixedGst',
    invoiceExtraCharge: 'invoiceExtraCharge'
  })), {}, {
    fixedGst: {
      get: function get() {
        return this.isFixedGst;
      },
      set: function set(value) {
        this.setIsFixedGst(value);
      }
    },
    extraCharge: {
      get: function get() {
        return this.invoiceExtraCharge;
      },
      set: function set(value) {
        this.setInvoiceExtraCharge(value);
      }
    }
  }),
  methods: Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_home_runner_work_flexiquote_flexiquote_apps_web_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapActions"])(moduleName, ['setIsUpdateInvoice', 'setIsUpdateExcessInvoice', 'setIsFixedGst', 'addInvoiceIncludedQuotes', 'removeInvoiceIncludedQuotes', 'clearInvoiceIncludedQuotes', 'setInvoiceExtraCharge'])), {}, {
    getIncludedStatus: function getIncludedStatus(quote) {
      var isIncluded = this.invoiceIncludedQuotes.findIndex(function (s) {
        return s.quoteId === quote.quoteId;
      }) >= 0;
      return isIncluded;
    }
  })
});

/***/ }),

/***/ "./src/views/quote/mixins/QuoteInvoiceValidationMixin.js":
/*!***************************************************************!*\
  !*** ./src/views/quote/mixins/QuoteInvoiceValidationMixin.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  inject: ['$vv'],
  computed: {
    $v: function $v() {
      return this.$vv || this.$v;
    }
  }
});

/***/ })

}]);
//# sourceMappingURL=quote-invoice-chunk.js.map